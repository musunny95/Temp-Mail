(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    var p, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ea = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        t = {},
        fa = {},
        u = function(a, b, c) {
            if (!c || null != a) {
                c = fa[b];
                if (null == c) return a[b];
                c = a[c];
                return void 0 !== c ? c : a[b]
            }
        },
        w = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = 1 === d.length;
                var e = d[0],
                    f;!a && e in t ? f = t : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = ea && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? ba(t, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (void 0 === fa[d] && (a = 1E9 * Math.random() >>> 0, fa[d] = ea ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        };
    w("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    w("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, t.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ha(aa(this))
                }
            })
        }
        return a
    }, "es6");
    var ha = function(a) {
            a = {
                next: a
            };
            a[u(t.Symbol, "iterator")] = function() {
                return this
            };
            return a
        },
        ia = function(a) {
            return a.raw = a
        },
        x = function(a) {
            var b = "undefined" != typeof t.Symbol && u(t.Symbol, "iterator") && a[u(t.Symbol, "iterator")];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        y = function(a) {
            if (!(a instanceof Array)) {
                a = x(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ka = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        la = ea && "function" == typeof u(Object, "assign") ? u(Object, "assign") : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) ka(d, e) && (a[e] = d[e])
            }
            return a
        };
    w("Object.assign", function(a) {
        return a || la
    }, "es6");
    var ma = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        na;
    if (ea && "function" == typeof Object.setPrototypeOf) na = Object.setPrototypeOf;
    else {
        var oa;
        a: {
            var pa = {
                    a: !0
                },
                qa = {};
            try {
                qa.__proto__ = pa;
                oa = qa.a;
                break a
            } catch (a) {}
            oa = !1
        }
        na = oa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var sa = na,
        z = function(a, b) {
            a.prototype = ma(b.prototype);
            a.prototype.constructor = a;
            if (sa) sa(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.nb = b.prototype
        },
        ta = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    w("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    }, "es6");
    w("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = x(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!ka(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!ka(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && ka(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && ka(g, d) && ka(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && ka(g, d) && ka(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    w("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(x([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = u(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new t.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.s ? l.s.value = k : (l.s = {
                next: this[1],
                C: this[1].C,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.s), this[1].C.next = l.s, this[1].C = l.s, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.s && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.s.C.next = h.s.next, h.s.next.C = h.s.C, h.s.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].C = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).s
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).s) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = u(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[u(t.Symbol, "iterator")] = u(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && ka(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            s: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    s: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return ha(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.C;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.C = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    w("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    }, "es6");
    w("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ka(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    w("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    w("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    var ua = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    w("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== ua(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    w("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(x([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = u(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new t.Map;
            if (c) {
                c = x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return u(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return u(this.g, "values").call(this.g)
        };
        b.prototype.keys = u(b.prototype, "values");
        b.prototype[u(t.Symbol, "iterator")] = u(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    w("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    w("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    w("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return u(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    w("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return u(Number, "isInteger").call(Number, b) && Math.abs(b) <= u(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    var va = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[u(t.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    w("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return va(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    w("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return va(this, function(b) {
                return b
            })
        }
    }, "es6");
    w("Array.prototype.values", function(a) {
        return a ? a : function() {
            return va(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    w("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof t.Symbol && u(t.Symbol, "iterator") && b[u(t.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    w("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ka(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    w("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    w("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = ua(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    w("globalThis", function(a) {
        return a || da
    }, "es_2020");
    w("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? u(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var B = this || self,
        xa = function(a, b) {
            var c = wa("CLOSURE_FLAGS");
            a = c && c[a];
            return null != a ? a : b
        },
        wa = function(a) {
            a = a.split(".");
            for (var b = B, c = 0; c < a.length; c++)
                if (b = b[a[c]], null == b) return null;
            return b
        },
        ya = function(a, b, c) {
            a = a.split(".");
            c = c || B;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };

    function Aa(a) {
        B.setTimeout(function() {
            throw a;
        }, 0)
    };
    var Ba = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Da = function(a, b) {
            var c = 0;
            a = Ba(String(a)).split(".");
            b = Ba(String(b)).split(".");
            for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
                var f = a[e] || "",
                    g = b[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    c = Ca(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Ca(0 == f[2].length, 0 == g[2].length) || Ca(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == c)
            }
            return c
        },
        Ca = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var Ea = xa(610401301, !1),
        Fa = xa(572417392, !0);
    var Ga, Ha = B.navigator;
    Ga = Ha ? Ha.userAgentData || null : null;

    function Ia(a) {
        return Ea ? Ga ? Ga.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function C(a) {
        var b;
        a: {
            if (b = B.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function Ja() {
        return Ea ? !!Ga && 0 < Ga.brands.length : !1
    }

    function Ka() {
        return Ja() ? Ia("Chromium") : (C("Chrome") || C("CriOS")) && !(Ja() ? 0 : C("Edge")) || C("Silk")
    };
    var La = function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        },
        Ma = function(a, b) {
            return Array.prototype.map.call(a, b, void 0)
        };

    function Na(a, b) {
        a: {
            for (var c = "string" === typeof a ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    };
    var Oa = function(a) {
        Oa[" "](a);
        return a
    };
    Oa[" "] = function() {};
    var Pa = Ja() ? !1 : C("Trident") || C("MSIE");
    !C("Android") || Ka();
    Ka();
    C("Safari") && (Ka() || (Ja() ? 0 : C("Coast")) || (Ja() ? 0 : C("Opera")) || (Ja() ? 0 : C("Edge")) || (Ja() ? Ia("Microsoft Edge") : C("Edg/")) || Ja() && Ia("Opera"));
    var Qa = {},
        Ra = null,
        Ta = function(a) {
            var b = [];
            Sa(a, function(c) {
                b.push(c)
            });
            return b
        },
        Sa = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Ra[l];
                    if (null != m) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            Ua();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        Ua = function() {
            if (!Ra) {
                Ra = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Qa[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === Ra[f] && (Ra[f] = e)
                    }
                }
            }
        };
    var Va = "undefined" !== typeof Uint8Array,
        Wa = !Pa && "function" === typeof btoa;

    function Xa() {
        return "function" === typeof BigInt
    }
    var Ya = !Fa,
        Za = !Fa;
    var F = 0,
        $a = 0;

    function ab(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = x(bb(c, a)), b = c.next().value, a = c.next().value, c = b);
        F = c >>> 0;
        $a = a >>> 0
    }

    function cb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else Xa() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), c = b + db(c) + db(a));
        return c
    }

    function db(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function eb() {
        var a = F,
            b = $a;
        b & 2147483648 ? Xa() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = x(bb(a, b)), a = b.next().value, b = b.next().value, a = "-" + cb(a, b)) : a = cb(a, b);
        return a
    }

    function bb(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function G(a) {
        return Array.prototype.slice.call(a)
    };

    function fb(a) {
        return "function" === typeof t.Symbol && "symbol" === typeof(0, t.Symbol)() ? (0, t.Symbol)() : a
    }
    var H = fb(),
        gb = fb("0di");
    var hb = H ? function(a, b) {
        a[H] |= b
    } : function(a, b) {
        void 0 !== a.A ? a.A |= b : Object.defineProperties(a, {
            A: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };

    function ib(a) {
        var b = I(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = G(a)), J(a, b | 1))
    }
    var jb = H ? function(a, b) {
        a[H] &= ~b
    } : function(a, b) {
        void 0 !== a.A && (a.A &= ~b)
    };

    function K(a, b, c) {
        return c ? a | b : a & ~b
    }
    var I = H ? function(a) {
            return a[H] | 0
        } : function(a) {
            return a.A | 0
        },
        L = H ? function(a) {
            return a[H]
        } : function(a) {
            return a.A
        },
        J = H ? function(a, b) {
            a[H] = b
        } : function(a, b) {
            void 0 !== a.A ? a.A = b : Object.defineProperties(a, {
                A: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function kb() {
        var a = [];
        hb(a, 1);
        return a
    }

    function lb(a, b) {
        J(b, (a | 0) & -14591)
    }

    function mb(a, b) {
        J(b, (a | 34) & -14557)
    }

    function nb(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var ob = {},
        pb = {};

    function qb(a) {
        return !(!a || "object" !== typeof a || a.kb !== pb)
    }

    function rb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var sb, tb = !Fa;

    function ub(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = I(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? u(b, "includes").call(b, c) : b.has(c)))) return !1;
        J(a, d | 1);
        return !0
    }
    var vb, wb = [];
    J(wb, 55);
    vb = Object.freeze(wb);

    function xb(a) {
        if (a & 2) throw Error();
    }
    Object.freeze(new function() {});
    Object.freeze(new function() {});
    var yb = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var zb;

    function Ab(a) {
        if (zb) throw Error("");
        zb = a
    }

    function Bb(a) {
        if (zb) try {
            zb(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Cb() {
        var a = Db();
        zb ? B.setTimeout(function() {
            Bb(a)
        }, 0) : Aa(a)
    }

    function Eb(a) {
        a = Error(a);
        yb(a, "warning");
        Bb(a);
        return a
    }

    function Db() {
        var a = Error();
        yb(a, "incident");
        return a
    };

    function Fb(a) {
        if (null != a && "boolean" !== typeof a) {
            var b = typeof a;
            throw Error("Expected boolean but got " + ("object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null") + ": " + a);
        }
        return a
    }
    var Gb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Hb(a) {
        var b = typeof a;
        return "number" === b ? u(Number, "isFinite").call(Number, a) : "string" !== b ? !1 : Gb.test(a)
    }

    function Ib(a) {
        null != a && (u(Number, "isFinite").call(Number, a) || Cb());
        return a
    }

    function Jb(a) {
        if ("number" !== typeof a) throw Eb("int32");
        if (!u(Number, "isFinite").call(Number, a)) throw Eb("int32");
        return a | 0
    }

    function Kb(a) {
        return null == a ? a : Jb(a)
    }

    function Lb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return u(Number, "isFinite").call(Number, a) ? a | 0 : void 0
    }

    function Mb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return u(Number, "isFinite").call(Number, a) ? a >>> 0 : void 0
    }

    function Nb(a) {
        if (null != a) {
            var b = !!b;
            if (!Hb(a)) throw Eb("int64");
            "string" === typeof a ? a = Ob(a) : b ? (a = u(Math, "trunc").call(Math, a), u(Number, "isSafeInteger").call(Number, a) ? a = String(a) : (b = String(a), Pb(b) ? a = b : (ab(a), a = eb()))) : a = Qb(a)
        }
        return a
    }

    function Pb(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function Qb(a) {
        a = u(Math, "trunc").call(Math, a);
        if (!u(Number, "isSafeInteger").call(Number, a)) {
            ab(a);
            var b = F,
                c = $a;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    }

    function Ob(a) {
        var b = u(Math, "trunc").call(Math, Number(a));
        if (u(Number, "isSafeInteger").call(Number, b)) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        if (!Pb(a)) {
            if (16 > a.length) ab(Number(a));
            else if (Xa()) a = BigInt(a), F = Number(a & BigInt(4294967295)) >>> 0, $a = Number(a >> BigInt(32) & BigInt(4294967295));
            else {
                b = +("-" === a[0]);
                $a = F = 0;
                for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), $a *= 1E6, F = 1E6 * F + d, 4294967296 <= F && ($a += u(Math, "trunc").call(Math, F / 4294967296), $a >>>= 0, F >>>= 0);
                b && (b = x(bb(F, $a)), a = b.next().value, b = b.next().value, F = a, $a = b)
            }
            a = eb()
        }
        return a
    }

    function Rb(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function M(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function Sb(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Tb(a, b, c) {
        if (null != a && "object" === typeof a && a.X === ob) return a;
        if (Array.isArray(a)) {
            var d = I(a),
                e = d;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== d && J(a, e);
            return new b(a)
        }
    };
    var Ub;

    function Vb(a, b) {
        Ub = b;
        a = new a(b);
        Ub = void 0;
        return a
    }

    function N(a, b, c) {
        null == a && (a = Ub);
        Ub = void 0;
        if (null == a) {
            var d = 96;
            c ? (a = [c], d |= 512) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = I(a);
            if (d & 64) return a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error();
            a: {
                c = d;
                if (d = a.length) {
                    var e = d - 1;
                    if (rb(a[e])) {
                        c |= 256;
                        b = e - (+!!(c & 512) - 1);
                        if (1024 <= b) throw Error();
                        d = c & -16760833 | (b & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, d - (+!!(c & 512) - 1));
                    if (1024 < b) throw Error();
                    d = c & -16760833 | (b & 1023) << 14
                } else d = c
            }
        }
        J(a, d);
        return a
    };

    function Wb(a, b) {
        return Xb(b)
    }

    function Xb(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return tb || !ub(a, void 0, 9999) ? a : void 0;
                    if (Va && null != a && a instanceof Uint8Array) {
                        if (Wa) {
                            for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                            b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                            a = btoa(b)
                        } else {
                            void 0 === b && (b = 0);
                            Ua();
                            b = Qa[b];
                            c = Array(Math.floor(a.length / 3));
                            d = b[64] || "";
                            for (var e = 0, f = 0; e < a.length - 2; e += 3) {
                                var g = a[e],
                                    h = a[e + 1],
                                    k = a[e + 2],
                                    l = b[g >> 2];
                                g = b[(g & 3) << 4 | h >> 4];
                                h = b[(h & 15) << 2 | k >> 6];
                                k = b[k & 63];
                                c[f++] = l + g + h + k
                            }
                            l = 0;
                            k = d;
                            switch (a.length - e) {
                                case 2:
                                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                                case 1:
                                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
                            }
                            a = c.join("")
                        }
                        return a
                    }
                }
        }
        return a
    };

    function Yb(a, b, c) {
        a = G(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function Zb(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && I(a) & 1 ? void 0 : f && I(a) & 2 ? a : $b(a, b, c, void 0 !== d, e, f);
            else if (rb(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Zb(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function $b(a, b, c, d, e, f) {
        var g = d || c ? I(a) : 0;
        d = d ? !!(g & 32) : void 0;
        a = G(a);
        for (var h = 0; h < a.length; h++) a[h] = Zb(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function ac(a) {
        return a.X === ob ? a.toJSON() : Xb(a)
    };

    function bc(a, b, c) {
        c = void 0 === c ? mb : c;
        if (null != a) {
            if (Va && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = I(a);
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (J(a, (d | 34) & -12293), a) : $b(a, bc, d & 4 ? mb : c, !0, !1, !0)
            }
            a.X === ob && (c = a.h, d = L(c), a = d & 2 ? a : Vb(a.constructor, cc(c, d, !0)));
            return a
        }
    }

    function cc(a, b, c) {
        var d = c || b & 2 ? mb : lb,
            e = !!(b & 32);
        a = Yb(a, b, function(f) {
            return bc(f, e, d)
        });
        hb(a, 32 | (c ? 2 : 0));
        return a
    }

    function dc(a) {
        var b = a.h,
            c = L(b);
        return c & 2 ? Vb(a.constructor, cc(b, c, !1)) : a
    };
    var fc = function(a, b) {
            a = a.h;
            return ec(a, L(a), b)
        },
        ec = function(a, b, c, d) {
            if (-1 === c) return null;
            if (c >= nb(b)) {
                if (b & 256) return a[a.length - 1][c]
            } else {
                var e = a.length;
                if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
                b = c + (+!!(b & 512) - 1);
                if (b < e) return a[b]
            }
        },
        P = function(a, b, c) {
            var d = a.h,
                e = L(d);
            xb(e);
            O(d, e, b, c);
            return a
        };

    function O(a, b, c, d, e) {
        var f = nb(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && J(a, e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function gc(a, b, c, d) {
        var e = b & 2,
            f = ec(a, b, c);
        Array.isArray(f) || (f = vb);
        var g = !(d & 2);
        d = !(d & 1);
        var h = !!(b & 32),
            k = I(f);
        0 !== k || !h || e || g ? k & 1 || (k |= 1, J(f, k)) : (k |= 33, J(f, k));
        e ? (a = !1, k & 2 || (hb(f, 34), a = !!(4 & k)), (d || a) && Object.freeze(f)) : (e = !!(2 & k) || !!(2048 & k), d && e ? (f = G(f), d = 1, h && !g && (d |= 32), J(f, d), O(a, b, c, f)) : g && k & 32 && !e && jb(f, 32));
        return f
    }

    function hc(a, b, c) {
        a = a.h;
        var d = L(a),
            e = 2 & d ? 1 : 2,
            f = gc(a, d, b, 1);
        d = L(a);
        var g = I(f),
            h = g,
            k = !!(2 & g),
            l = !!(4 & g),
            m = k && l;
        if (!(4 & g)) {
            if (l || Object.isFrozen(f)) f = G(f), h = 0, g = ic(g, d, !1), k = !!(2 & g), d = O(a, d, b, f);
            for (var n = l = 0; l < f.length; l++) {
                var q = c(f[l]);
                null != q && (f[n++] = q)
            }
            n < l && (f.length = n);
            c = K(g, 4096, !1);
            g = c = K(c, 8192, !1);
            g = K(g, 20, !0)
        }
        m || ((c = 1 === e) && (g = K(g, 2, !0)), g !== h && J(f, g), (c || k) && Object.freeze(f));
        2 === e && k && (f = G(f), g = ic(g, d, !1), J(f, g), O(a, d, b, f));
        return f
    }

    function jc(a, b, c, d) {
        var e = a.h,
            f = L(e);
        xb(f);
        if (null == c) return O(e, f, b), a;
        var g = I(c),
            h = g,
            k = !!(2 & g) || Object.isFrozen(c),
            l = !k && !1;
        if (!(4 & g))
            for (g = 21, k && (c = G(c), h = 0, g = ic(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (c = G(c), h = 0, g = ic(g, f, !0));
        g !== h && J(c, g);
        O(e, f, b, c);
        return a
    }

    function Q(a, b, c, d) {
        var e = a.h,
            f = L(e);
        xb(f);
        O(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }
    var lc = function(a, b, c, d) {
            var e = a.h,
                f = L(e);
            xb(f);
            (c = kc(e, f, c)) && c !== b && null != d && (f = O(e, f, c));
            O(e, f, b, d);
            return a
        },
        mc = function(a, b, c) {
            a = a.h;
            return kc(a, L(a), b) === c ? c : -1
        },
        nc = function(a, b) {
            a = a.h;
            return kc(a, L(a), b)
        };

    function kc(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != ec(a, b, f) && (0 !== d && (b = O(a, b, d)), d = f)
        }
        return d
    }
    var oc = function(a, b, c, d) {
            a = a.h;
            var e = L(a),
                f = ec(a, e, c, d);
            b = Tb(f, b, e);
            b !== f && null != b && O(a, e, c, b, d);
            return b
        },
        pc = function(a, b) {
            (a = oc(a, b, 1, !1)) ? b = a: (a = b[gb]) ? b = a : (a = new b, hb(a.h, 34), b = b[gb] = a);
            return b
        },
        R = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            b = oc(a, b, c, d);
            if (null == b) return b;
            a = a.h;
            var e = L(a);
            if (!(e & 2)) {
                var f = dc(b);
                f !== b && (b = f, O(a, e, c, b, d))
            }
            return b
        },
        S = function(a, b, c) {
            a = a.h;
            var d = L(a),
                e = !!(2 & d),
                f = e ? 1 : 2,
                g = 1 === f;
            f = 2 === f;
            var h = !!(2 & d) && f,
                k = gc(a, d, c, 3);
            d = L(a);
            var l = I(k),
                m = !!(2 & l),
                n = !!(4 & l),
                q = !!(32 & l),
                r = m && n || !!(2048 & l);
            if (!n) {
                var A = k,
                    v = d,
                    D = !!(2 & l);
                D && (v = K(v, 2, !0));
                for (var E = !D, ja = !0, za = 0, ra = 0; za < A.length; za++) {
                    var wc = Tb(A[za], b, v);
                    if (wc instanceof b) {
                        if (!D) {
                            var Td = !!(I(wc.h) & 2);
                            E && (E = !Td);
                            ja && (ja = Td)
                        }
                        A[ra++] = wc
                    }
                }
                ra < za && (A.length = ra);
                l = K(l, 4, !0);
                l = K(l, 16, ja);
                l = K(l, 8, E);
                J(A, l);
                m && !h && (Object.freeze(k), r = !0)
            }
            b = l;
            h = !!(8 & l) || g && !k.length;
            if (!e && !h) {
                r && (k = G(k), r = !1, b = 0, l = ic(l, d, !1), d = O(a, d, c, k));
                e = k;
                h = l;
                for (m = 0; m < e.length; m++) A = e[m], l = dc(A), A !== l && (e[m] = l);
                h = K(h, 8, !0);
                l = h = K(h, 16, !e.length)
            }
            r || (g ? l = K(l, !k.length || 16 & l && (!n || q) ? 2 : 2048, !0) : l = K(l, 32, !1), l !== b && J(k, l), g && (Object.freeze(k), r = !0));
            f && r && (k = G(k), l = ic(l, d, !1), J(k, l), O(a, d, c, k));
            return k
        },
        qc = function(a, b, c) {
            null == c && (c = void 0);
            return P(a, b, c)
        },
        rc = function(a, b, c, d) {
            null == d && (d = void 0);
            return lc(a, b, c, d)
        },
        sc = function(a, b, c) {
            var d = a.h,
                e = L(d);
            xb(e);
            if (null == c) return O(d, e, b), a;
            for (var f = I(c), g = f, h = !!(2 & f) || !!(2048 & f), k = h || Object.isFrozen(c), l = !0, m = !0, n = 0; n < c.length; n++) {
                var q = c[n];
                h || (q = !!(I(q.h) & 2), l && (l = !q), m && (m = q))
            }
            h || (f = K(f, 5, !0), f = K(f, 8, l), f = K(f, 16, m));
            k && f !== g && (c = G(c), g = 0, f = ic(f, e, !0));
            f !== g && J(c, f);
            O(d, e, b, c);
            return a
        };

    function ic(a, b, c) {
        a = K(a, 2, !!(2 & b));
        a = K(a, 32, !!(32 & b) && c);
        return a = K(a, 2048, !1)
    }

    function tc(a, b) {
        return null != a ? a : b
    }
    var uc = function(a, b) {
            a = fc(a, b);
            return tc(null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0, !1)
        },
        vc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return tc(Lb(fc(a, b)), c)
        },
        xc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return tc(Mb(fc(a, b)), c)
        },
        yc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            a = fc(a, b);
            var d;
            null == a ? d = a : Hb(a) ? "number" === typeof a ? d = Qb(a) : d = Ob(a) : d = void 0;
            return tc(d, c)
        },
        zc = function(a, b) {
            var c = void 0 === c ? 0 : c;
            a = a.h;
            var d = L(a),
                e = ec(a, d, b);
            var f = null == e || "number" === typeof e ? e : "NaN" === e || "Infinity" === e || "-Infinity" === e ? Number(e) : void 0;
            null != f && f !== e && O(a, d, b, f);
            return tc(f, c)
        },
        T = function(a, b) {
            return tc(Sb(fc(a, b)), "")
        },
        U = function(a, b) {
            return tc(fc(a, b), 0)
        };
    var V = function(a, b, c) {
        this.h = N(a, b, c)
    };
    V.prototype.toJSON = function() {
        if (sb) var a = Ac(this, this.h, !1);
        else a = $b(this.h, ac, void 0, void 0, !1, !1), a = Ac(this, a, !0);
        return a
    };
    var Bc = function(a) {
        sb = !0;
        try {
            return JSON.stringify(a.toJSON(), Wb)
        } finally {
            sb = !1
        }
    };
    V.prototype.X = ob;

    function Ac(a, b, c) {
        var d = a.constructor.m,
            e = L(c ? a.h : b),
            f = nb(e),
            g = !1;
        if (d && tb) {
            if (!c) {
                b = G(b);
                var h;
                if (b.length && rb(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            u(Object, "assign").call(Object, b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = L(a.h);
            a = nb(h);
            h = +!!(h & 512) - 1;
            for (var k, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l += h;
                    var n = f[l];
                    null == n ? f[l] = c ? vb : kb() : c && n !== vb && ib(n)
                } else k || (n = void 0, f.length && rb(n = f[f.length - 1]) ? k = n : f.push(k = {})), n = k[l], null == k[l] ? k[l] = c ? vb : kb() : c && n !== vb && ib(n)
        }
        k = b.length;
        if (!k) return b;
        var q;
        if (rb(f = b[k - 1])) {
            a: {
                var r = f;c = {};a = !1;
                for (var A in r)
                    if (Object.prototype.hasOwnProperty.call(r, A)) {
                        h = r[A];
                        if (Array.isArray(h)) {
                            m = h;
                            if (!Za && ub(h, d, +A) || !Ya && qb(h) && 0 === h.size) h = null;
                            h != m && (a = !0)
                        }
                        null != h ? c[A] = h : a = !0
                    }
                if (a) {
                    for (var v in c) {
                        r = c;
                        break a
                    }
                    r = null
                }
            }
            r != f && (q = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            A = k - 1;
            f = b[A];
            if (!(null == f || !Za && ub(f, d, A - e) || !Ya && qb(f) && 0 === f.size)) break;
            var D = !0
        }
        if (!q && !D) return b;
        var E;
        g ? E = b : E = Array.prototype.slice.call(b, 0, k);
        b = E;
        g && (b.length = k);
        r && b.push(r);
        return b
    };

    function Cc() {
        var a = !W(Dc).g,
            b = Ec();
        if (!a) throw Error(b && b() || String(a));
    }
    var Fc = void 0;

    function Ec() {
        var a = Fc;
        Fc = void 0;
        return a
    };

    function Gc(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                hb(b, 32);
                b = Vb(a, b)
            }
            return b
        }
    };
    var Hc = function(a) {
        this.h = N(a)
    };
    z(Hc, V);
    Hc.m = [6, 4];
    var Ic = function(a) {
        this.h = N(a)
    };
    z(Ic, V);
    var Jc = Gc(Ic);
    Ic.m = [4, 5, 6];
    var Mc = function(a, b) {
        this.g = a === Kc && b || "";
        this.i = Lc
    };
    Mc.prototype.toString = function() {
        return this.g
    };
    var Lc = {},
        Kc = {};
    var Nc = function(a) {
            this.g = a;
            this.defaultValue = !1
        },
        Oc = function(a) {
            this.g = a;
            this.defaultValue = 0
        };
    var Pc = new Nc(203);
    var Qc = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var Rc = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };
    var W = function(a) {
        var b = "U";
        if (a.U && a.hasOwnProperty(b)) return a.U;
        b = new a;
        return a.U = b
    };
    var Sc = function() {
        var a = {};
        this.i = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.g = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.l = function() {}
    };

    function Tc(a) {
        return W(Sc).i(a.g, a.defaultValue)
    }

    function Uc() {
        var a = Vc;
        return W(Sc).j(a.g, a.defaultValue)
    };

    function Wc(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var Xc = function(a) {
        this.g = a
    };
    Xc.prototype.toString = function() {
        return this.g + ""
    };
    var Yc = function(a) {
            return a instanceof Xc && a.constructor === Xc ? a.g : "type_error:TrustedResourceUrl"
        },
        Zc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        $c = {},
        ad = function(a, b, c) {
            if (null == c) return b;
            if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
            for (var d in c)
                if (Object.prototype.hasOwnProperty.call(c, d)) {
                    var e = c[d];
                    e = Array.isArray(e) ? e : [e];
                    for (var f = 0; f < e.length; f++) {
                        var g = e[f];
                        null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                    }
                }
            return b
        };
    var bd = {},
        cd = function(a) {
            this.g = a
        };
    cd.prototype.toString = function() {
        return this.g.toString()
    };
    var dd = function() {
        return Ea && Ga ? !Ga.mobile && (C("iPad") || C("Android") || C("Silk")) : C("iPad") || C("Android") && !C("Mobile") || C("Silk")
    };
    var ed = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        fd = function(a) {
            return a ? decodeURI(a) : a
        },
        gd = /#|$/,
        hd = function(a, b) {
            var c = a.search(gd);
            a: {
                var d = 0;
                for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                    var f = a.charCodeAt(d - 1);
                    if (38 == f || 63 == f)
                        if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                    d += e + 1
                }
                d = -1
            }
            if (0 > d) return null;
            e = a.indexOf("&", d);
            if (0 > e || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
        };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function id(a) {
        var b, c;
        return (a = null == (c = (b = a.document).querySelector) ? void 0 : c.call(b, "script[nonce]")) ? a.nonce || a.getAttribute("nonce") || "" : ""
    };

    function jd(a, b) {
        a.src = Yc(b);
        (b = id(a.ownerDocument && a.ownerDocument.defaultView || window)) && a.setAttribute("nonce", b)
    };

    function kd(a, b) {
        a.write(b instanceof cd && b.constructor === cd ? b.g : "type_error:SafeHtml")
    };
    var ld = function(a) {
            try {
                var b;
                if (b = !!a && null != a.location.href) a: {
                    try {
                        Oa(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        md = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = void 0 === c ? B : c;
            for (var d = 0; c && 40 > d++ && (!b && !ld(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e != c) {
                        c = e;
                        break a
                    }
                } catch (f) {}
                c = null
            }
        },
        nd = function(a) {
            var b = a;
            md(function(c) {
                b = c;
                return !1
            });
            return b
        },
        od = function(a) {
            return ld(a.top) ? a.top : null
        },
        pd = function() {
            if (!t.globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                t.globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        },
        qd = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        rd = function(a) {
            var b = a.length;
            if (0 == b) return 0;
            for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
            return 0 < c ? c : 4294967296 + c
        },
        sd = /^(-?[0-9.]{1,30})$/,
        td = Qc(function() {
            return (Ea && Ga ? Ga.mobile : !dd() && (C("iPod") || C("iPhone") || C("Android") || C("IEMobile"))) ? 2 : dd() ? 1 : 0
        });

    function ud(a, b) {
        if (a.length && b.head) {
            a = x(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = vd("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    }
    var wd = function(a) {
            if ("number" !== typeof a.goog_pvsid) try {
                var b = Object,
                    c = b.defineProperty,
                    d = void 0;
                d = void 0 === d ? Math.random : d;
                var e = Math.floor(d() * Math.pow(2, 52));
                c.call(b, a, "goog_pvsid", {
                    value: e,
                    configurable: !1
                })
            } catch (f) {}
            return Number(a.goog_pvsid) || -1
        },
        vd = function(a, b) {
            b = void 0 === b ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function xd(a, b) {
        b = void 0 === b ? {} : b;
        a = '<script src="' + yd(Yc(a).toString()) + '"';
        b.async && (a += " async");
        b.Aa && (a += ' custom-element="' + yd(b.Aa) + '"');
        b.defer && (a += " defer");
        b.id && (a += ' id="' + yd(b.id) + '"');
        b.nonce && (a += ' nonce="' + yd(b.nonce) + '"');
        b.type && (a += ' type="' + yd(b.type) + '"');
        return new cd(a + ">\x3c/script>", bd)
    }

    function yd(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    };

    function zd(a) {
        var b = a.split(/\?|#/),
            c = /\?/.test(a) ? "?" + b[1] : "";
        return {
            path: b[0],
            Ja: c,
            hash: /#/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    }

    function Ad(a) {
        var b = ta.apply(1, arguments);
        if (0 === b.length) return new Xc(a[0], $c);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return new Xc(c, $c)
    }

    function Bd(a, b) {
        a = zd(Yc(a).toString());
        var c = a.Ja,
            d = c.length ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return new Xc(a.path + c + a.hash, $c)
    };
    var Cd = {
        ab: 0,
        Za: 1,
        Wa: 2,
        Ra: 3,
        Xa: 4,
        Sa: 5,
        Ya: 6,
        Ua: 7,
        Va: 8,
        Qa: 9,
        Ta: 10,
        bb: 11
    };
    var Dd = {
        eb: 0,
        fb: 1,
        cb: 2
    };
    var Ed = function(a) {
        this.h = N(a)
    };
    z(Ed, V);
    Ed.prototype.getVersion = function() {
        return vc(this, 2)
    };
    Ed.m = [3];

    function Fd(a) {
        return Ta(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (p = b.toString(2), u(p, "padStart")).call(p, 8, "0")
        }).join("")
    }

    function Gd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }

    function Hd(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Id(a) {
        var b = Fd(a + "A"),
            c = Gd(b.slice(0, 6));
        a = Gd(b.slice(6, 12));
        var d = new Ed;
        c = Q(d, 1, Kb(c), 0);
        a = Q(c, 2, Kb(a), 0);
        b = b.slice(12);
        c = Gd(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (0 === e.length) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = 0 === Gd(e[0]);
            e = e.slice(1);
            var h = Jd(e, b),
                k = 0 === d.length ? 0 : d[d.length - 1];
            k = Hd(h) + k;
            e = e.slice(h.length);
            if (g) d.push(k);
            else {
                g = Jd(e, b);
                h = Hd(g);
                for (var l = 0; l <= h; l++) d.push(k + l);
                e = e.slice(g.length)
            }
        }
        if (0 < e.length) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return jc(a, 3, d, Jb)
    }

    function Jd(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    var Kd = function(a) {
        this.h = N(a)
    };
    z(Kd, V);
    Kd.prototype.getVersion = function() {
        return vc(this, 1)
    };
    var Ld = function(a) {
        this.h = N(a)
    };
    z(Ld, V);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    var Md = "a".charCodeAt(),
        Nd = Wc(Cd),
        Od = Wc(Dd);
    var Pd = function(a) {
        this.h = N(a)
    };
    z(Pd, V);
    var Qd = function() {
            var a = new Pd;
            return Q(a, 1, Nb(0), "0")
        },
        Rd = function(a) {
            var b = yc(a, 1);
            a = vc(a, 2);
            return new Date(1E3 * b + a / 1E6)
        };
    var Sd = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.i = a;
            this.g = 0
        },
        Wd = function(a) {
            var b = X(a, 16);
            return !0 === !!X(a, 1) ? (a = Ud(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : Vd(a, b)
        },
        Ud = function(a) {
            for (var b = X(a, 12), c = []; b--;) {
                var d = !0 === !!X(a, 1),
                    e = X(a, 16);
                if (d)
                    for (d = X(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        Vd = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (X(a, 1)) {
                    var f = e + 1;
                    if (c && -1 === c.indexOf(f)) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        X = function(a, b) {
            if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.i.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    Sd.prototype.skip = function(a) {
        this.g += a
    };
    var Yd = function(a, b) {
            try {
                var c = Ta(a.split(".")[0]).map(function(e) {
                        return (p = e.toString(2), u(p, "padStart")).call(p, 8, "0")
                    }).join(""),
                    d = new Sd(c);
                c = {};
                c.tcString = a;
                c.gdprApplies = !0;
                d.skip(78);
                c.cmpId = X(d, 12);
                c.cmpVersion = X(d, 12);
                d.skip(30);
                c.tcfPolicyVersion = X(d, 6);
                c.isServiceSpecific = !!X(d, 1);
                c.useNonStandardStacks = !!X(d, 1);
                c.specialFeatureOptins = Xd(Vd(d, 12, Od), Od);
                c.purpose = {
                    consents: Xd(Vd(d, 24, Nd), Nd),
                    legitimateInterests: Xd(Vd(d, 24, Nd), Nd)
                };
                c.purposeOneTreatment = !!X(d, 1);
                c.publisherCC = String.fromCharCode(Md + X(d, 6)) + String.fromCharCode(Md + X(d, 6));
                c.vendor = {
                    consents: Xd(Wd(d), b),
                    legitimateInterests: Xd(Wd(d), b)
                };
                return c
            } catch (e) {
                return null
            }
        },
        Xd = function(a, b) {
            var c = {};
            if (Array.isArray(b) && 0 !== b.length) {
                b = x(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = -1 !== a.indexOf(d)
            } else
                for (a = x(a), d = a.next(); !d.done; d = a.next()) c[d.value] = !0;
            delete c[0];
            return c
        };
    var Zd = function(a) {
        this.h = N(a)
    };
    z(Zd, V);

    function $d(a, b) {
        var c = function(d) {
            var e = {};
            return [(e[d.xa] = d.ta, e)]
        };
        return JSON.stringify([a.filter(function(d) {
            return d.V
        }).map(c), b.toJSON(), a.filter(function(d) {
            return !d.V
        }).map(c)])
    }
    var ae = function(a, b) {
        var c = new Zd;
        a = Q(c, 1, Ib(a), 0);
        b = Q(a, 2, M(b), "");
        a = b.h;
        c = L(a);
        this.l = c & 2 ? b : Vb(b.constructor, cc(a, c, !0))
    };
    var be = function(a) {
        this.h = N(a)
    };
    z(be, V);
    var ce = function(a) {
        this.h = N(a)
    };
    z(ce, V);
    var de = function(a, b) {
            return Q(a, 1, Ib(b), 0)
        },
        ee = function(a, b) {
            return Q(a, 2, Ib(b), 0)
        };
    var fe = function(a) {
        this.h = N(a)
    };
    z(fe, V);
    var ge = [1, 2];
    var he = function(a) {
        this.h = N(a)
    };
    z(he, V);
    var ie = function(a, b) {
            return qc(a, 1, b)
        },
        je = function(a, b) {
            return sc(a, 2, b)
        },
        ke = function(a, b) {
            return jc(a, 4, b, Jb)
        },
        le = function(a, b) {
            return sc(a, 5, b)
        },
        me = function(a, b) {
            return Q(a, 6, Ib(b), 0)
        };
    he.m = [2, 4, 5];
    var ne = function(a) {
        this.h = N(a)
    };
    z(ne, V);
    ne.m = [5];
    var oe = [1, 2, 3, 4];
    var pe = function(a) {
        this.h = N(a)
    };
    z(pe, V);
    pe.m = [2, 3];
    var qe = function(a) {
        this.h = N(a)
    };
    z(qe, V);
    qe.prototype.getTagSessionCorrelator = function() {
        return yc(this, 2)
    };
    var se = function(a) {
            var b = new qe;
            return rc(b, 4, re, a)
        },
        re = [4, 5, 7, 8];
    var te = function(a) {
        this.h = N(a)
    };
    z(te, V);
    te.m = [3];
    var ue = function(a) {
        this.h = N(a)
    };
    z(ue, V);
    ue.m = [4, 5];
    var ve = function(a) {
        this.h = N(a)
    };
    z(ve, V);
    ve.prototype.getTagSessionCorrelator = function() {
        return yc(this, 1)
    };
    ve.m = [2];
    var we = function(a) {
        this.h = N(a)
    };
    z(we, V);
    var xe = [4, 6];
    var ye = function() {
        ae.apply(this, arguments)
    };
    z(ye, ae);
    var ze = function() {
        ye.apply(this, arguments)
    };
    z(ze, ye);
    ze.prototype.Oa = function() {
        this.F.apply(this, y(ta.apply(0, arguments).map(function(a) {
            return {
                V: !0,
                xa: 2,
                ta: a.toJSON()
            }
        })))
    };
    ze.prototype.Y = function() {
        this.F.apply(this, y(ta.apply(0, arguments).map(function(a) {
            return {
                V: !0,
                xa: 4,
                ta: a.toJSON()
            }
        })))
    };
    var Ae = function(a, b) {
        if (t.globalThis.fetch) t.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var Be = function(a, b, c, d, e, f, g, h) {
        ze.call(this, a, b);
        this.M = c;
        this.K = d;
        this.I = e;
        this.G = f;
        this.J = g;
        this.j = h;
        this.g = [];
        this.i = null;
        this.o = !1
    };
    z(Be, ze);
    var Ce = function(a) {
        null !== a.i && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = $d(a.g, a.l);
            a.K(a.M + "?e=1", b);
            a.g = []
        }
    };
    Be.prototype.F = function() {
        var a = ta.apply(0, arguments),
            b = this;
        this.J && 65536 <= $d(this.g.concat(a), this.l).length && Ce(this);
        this.j && !this.o && (this.o = !0, this.j.g(function() {
            Ce(b)
        }));
        this.g.push.apply(this.g, y(a));
        this.g.length >= this.G && Ce(this);
        this.g.length && null === this.i && (this.i = setTimeout(function() {
            Ce(b)
        }, this.I))
    };
    var De = function(a, b, c, d, e, f) {
        Be.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", Ae, void 0 === c ? 1E3 : c, void 0 === d ? 100 : d, (void 0 === e ? !1 : e) && !!t.globalThis.fetch, f)
    };
    z(De, Be);
    var Ee = new Nc(501898423),
        Fe = new Nc(579875511),
        Ge = new Oc(523264412),
        He = new Oc(24),
        Vc = new function(a, b) {
            b = void 0 === b ? [] : b;
            this.g = a;
            this.defaultValue = b
        }(1934, ["As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U/roYjp4Yau0T3YSuc63vmAs/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"]);
    var Ie = function(a) {
        this.h = N(a)
    };
    z(Ie, V);
    var Je = function(a) {
        this.h = N(a)
    };
    z(Je, V);
    var Ke = function(a) {
        this.h = N(a)
    };
    z(Ke, V);
    var Le = function(a) {
        this.h = N(a)
    };
    z(Le, V);
    var Me = Gc(Le);
    Le.m = [7];
    var Ne = function(a) {
        this.g = a || {
            cookie: ""
        }
    };
    Ne.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.lb;
            d = c.mb || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Ha
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    Ne.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Ba(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    Ne.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    Ne.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Ba(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) c = b[a], this.get(c), this.set(c, "", {
            Ha: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Oe(a) {
        a = Pe(a);
        try {
            var b = a ? Me(a) : null
        } catch (c) {
            b = null
        }
        return b ? R(b, Ke, 4) || null : null
    }

    function Pe(a) {
        a = (new Ne(a)).get("FCCDCF", "");
        if (a)
            if (u(a, "startsWith").call(a, "%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    var Qe = function(a) {
            this.g = a;
            this.i = null
        },
        Se = function(a) {
            a.__uspapiPostMessageReady || Re(new Qe(a))
        },
        Re = function(a) {
            a.i = function(b) {
                var c = "string" === typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__uspapiCall;
                e && "getUSPData" === e.command && a.g.__uspapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__uspapiReturn = {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                })
            };
            a.g.addEventListener("message", a.i);
            a.g.__uspapiPostMessageReady = !0
        };
    [].concat(y(new t.Map([
        [8, "usca"],
        [9, "usva"],
        [10, "usco"],
        [12, "usct"],
        [11, "usut"]
    ]))).sort(function(a, b) {
        return a[0] - b[0]
    }).map(function(a) {
        return a[1]
    });
    var Te, Ue = new Kd;
    Te = Q(Ue, 1, Kb(1), 0);
    var Ve = new Ld;
    qc(Ve, 1, Te);
    Wc(Cd).map(function(a) {
        return Number(a)
    });
    Wc(Dd).map(function(a) {
        return Number(a)
    });
    var We = function(a) {
            this.g = a;
            this.i = null
        },
        Ye = function(a) {
            a.__tcfapiPostMessageReady || Xe(new We(a))
        },
        Xe = function(a) {
            a.i = function(b) {
                var c = "string" == typeof b.data;
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = "removeEventListener" === e.command ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.g.addEventListener("message", a.i);
            a.g.__tcfapiPostMessageReady = !0
        };
    var Ze = function(a) {
        this.h = N(a)
    };
    z(Ze, V);
    var $e = function(a) {
        this.h = N(a)
    };
    z($e, V);
    var af = Gc($e);
    $e.m = [2];

    function bf(a, b, c) {
        function d(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 4));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function e(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function f(m) {
            if (12 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(8, 12));
            m = k(m);
            return "1" + n + m + "N"
        }

        function g(m) {
            for (var n = [], q = 0, r = 0; r < m.length / 2; r++) n.push(Gd(m.slice(q, q + 2))), q += 2;
            return n
        }

        function h(m) {
            return m.every(function(n) {
                return 1 === n
            }) ? "Y" : "N"
        }

        function k(m) {
            return m.some(function(n) {
                return 1 === n
            }) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = Fd(a[0]);
        var l = Gd(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== l) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };
    var cf = function(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = vd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var ff = function(a, b) {
            this.g = a;
            this.o = b;
            b = Pe(this.g.document);
            try {
                var c = b ? Me(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = R(b, Je, 5) || null, b = S(b, Ie, 7), b = df(null != b ? b : []), c = {
                na: c,
                qa: b
            }) : c = {
                na: null,
                qa: null
            };
            b = c;
            c = ef(this, b.qa);
            b = b.na;
            if (null != b && null != Sb(fc(b, 2)) && 0 !== T(b, 2).length) {
                var d = void 0 !== oc(b, Pd, 1, !1) ? R(b, Pd, 1) : Qd();
                b = {
                    L: T(b, 2),
                    S: Rd(d)
                }
            } else b = null;
            this.l = b && c ? c.S > b.S ? c.L : b.L : b ? b.L : c ? c.L : null;
            this.i = (c = Oe(a.document)) && null != Sb(fc(c, 1)) ? T(c, 1) : null;
            this.j = (a = Oe(a.document)) && null != Sb(fc(a, 2)) ? T(a, 2) : null
        },
        jf = function(a) {
            var b = Tc(Fe);
            a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new ff(a, b), gf(a), hf(a))
        },
        gf = function(a) {
            !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", cf(a.g, "__uspapiLocator"), ya("__uspapi", function() {
                return a.G.apply(a, y(ta.apply(0, arguments)))
            }, a.g), Se(a.g))
        };
    ff.prototype.G = function(a, b, c) {
        "function" === typeof c && "getUSPData" === a && c({
            version: 1,
            uspString: this.l
        }, !0)
    };
    var df = function(a) {
            a = u(a, "find").call(a, function(b) {
                return 13 === U(b, 1)
            });
            if (null == a ? 0 : null != Sb(fc(a, 2))) try {
                return af(T(a, 2))
            } catch (b) {}
            return null
        },
        ef = function(a, b) {
            if (null == b || null == Sb(fc(b, 1)) || 0 === T(b, 1).length || 0 == S(b, Ze, 2).length) return null;
            var c = T(b, 1);
            try {
                var d = Id(c.split("~")[0]);
                var e = u(c, "includes").call(c, "~") ? c.split("~").slice(1) : []
            } catch (f) {
                return null
            }
            b = S(b, Ze, 2).reduce(function(f, g) {
                return yc(kf(f), 1) > yc(kf(g), 1) ? f : g
            });
            d = hc(d, 3, Lb).indexOf(vc(b, 1));
            return -1 === d || d >= e.length ? null : {
                L: bf(e[d], vc(b, 1), a.o),
                S: Rd(kf(b))
            }
        },
        kf = function(a) {
            return void 0 !== oc(a, Pd, 2, !1) ? R(a, Pd, 2) : Qd()
        },
        hf = function(a) {
            !a.i || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", cf(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], ya("__tcfapi", function() {
                return a.F.apply(a, y(ta.apply(0, arguments)))
            }, a.g), Ye(a.g))
        };
    ff.prototype.F = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("function" === typeof c)
            if (b && (2.1 < b || 1 >= b)) c(null, !1);
            else switch (b = this.g.__tcfapiEventListeners, a) {
                case "getTCData":
                    !d || Array.isArray(d) && d.every(function(e) {
                        return "number" === typeof e
                    }) ? c(lf(this, d, null), !0) : c(null, !1);
                    break;
                case "ping":
                    c({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    a = b.push(c);
                    c(lf(this, null, a - 1), !0);
                    break;
                case "removeEventListener":
                    b[d] ? (b[d] = null, c(!0)) : c(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    c(null, !1)
            }
    };
    var lf = function(a, b, c) {
        if (!a.i) return null;
        b = Yd(a.i, b);
        b.addtlConsent = null != a.j ? a.j : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    };
    var mf = function(a) {
        return "string" === typeof a
    };
    var nf = function(a, b) {
        var c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var of = null;
    var pf = function(a) {
        this.h = N(a)
    };
    z(pf, V);
    pf.m = [2, 8];
    var qf = [3, 4, 5],
        rf = [6, 7];

    function sf(a) {
        return null != a ? !a : a
    }

    function tf(a, b) {
        for (var c = !1, d = 0; d < a.length; d++) {
            var e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function uf(a, b) {
        var c = S(a, pf, 2);
        if (!c.length) return vf(a, b);
        a = U(a, 1);
        if (1 === a) return sf(uf(c[0], b));
        c = Ma(c, function(d) {
            return function() {
                return uf(d, b)
            }
        });
        switch (a) {
            case 2:
                return tf(c, !1);
            case 3:
                return tf(c, !0)
        }
    }

    function vf(a, b) {
        var c = nc(a, qf);
        a: {
            switch (c) {
                case 3:
                    var d = U(a, mc(a, qf, 3));
                    break a;
                case 4:
                    d = U(a, mc(a, qf, 4));
                    break a;
                case 5:
                    d = U(a, mc(a, qf, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = b.apply;
                var f = hc(a, 8, Sb);
                var g = e.call(b, null, y(f))
            } catch (h) {
                return
            }
            e = U(a, 1);
            if (4 === e) return !!g;
            if (5 === e) return null != g;
            if (12 === e) a = T(a, mc(a, rf, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = zc(a, mc(a, rf, 6));
                        break a;
                    case 5:
                        a = T(a, mc(a, rf, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === e) return g === a;
                if (9 === e) return null != g && 0 === Da(String(g), a);
                if (null != g) switch (e) {
                    case 7:
                        return g < a;
                    case 8:
                        return g > a;
                    case 12:
                        return mf(a) && mf(g) && (new RegExp(a)).test(g);
                    case 10:
                        return null != g && -1 === Da(String(g), a);
                    case 11:
                        return null != g && 1 === Da(String(g), a)
                }
            }
        }
    }

    function wf(a, b) {
        return !a || !(!b || !uf(a, b))
    };
    var xf = function(a) {
        this.h = N(a)
    };
    z(xf, V);
    xf.m = [4];
    var yf = function(a) {
        this.h = N(a)
    };
    z(yf, V);
    var zf = function(a) {
        this.h = N(a)
    };
    z(zf, V);
    var Af = Gc(zf);
    zf.m = [5];
    var Bf = [1, 2, 3, 6, 7];
    var Cf = function(a, b, c) {
            var d = void 0 === d ? new De(6, "unknown", b) : d;
            this.o = a;
            this.l = c;
            this.i = d;
            this.g = [];
            this.j = 0 < a && pd() < 1 / a
        },
        Ef = function(a, b, c, d, e, f) {
            if (a.j) {
                var g = ee(de(new ce, b), c);
                b = me(je(ie(le(ke(new he, d), e), g), a.g.slice()), f);
                b = se(b);
                a.i.Y(Df(a, b));
                if (1 === f || 3 === f || 4 === f && !a.g.some(function(h) {
                        return U(h, 1) === U(g, 1) && U(h, 2) === c
                    })) a.g.push(g), 100 < a.g.length && a.g.shift()
            }
        },
        Ff = function(a, b, c, d) {
            if (a.j && a.l) {
                var e = new pe;
                b = sc(e, 2, b);
                c = sc(b, 3, c);
                d && Q(c, 1, Kb(d), 0);
                d = new qe;
                d = rc(d, 7, re, c);
                a.i.Y(Df(a, d))
            }
        },
        Gf = function(a, b, c, d) {
            if (a.j) {
                var e = new be;
                b = P(e, 1, Kb(b));
                c = P(b, 2, Kb(c));
                d = P(c, 3, Ib(d));
                c = new qe;
                d = rc(c, 8, re, d);
                a.i.Y(Df(a, d))
            }
        },
        Df = function(a, b) {
            var c = Date.now();
            c = u(Number, "isFinite").call(Number, c) ? Math.round(c) : 0;
            b = Q(b, 1, Nb(c), "0");
            c = wd(window);
            b = Q(b, 2, Nb(c), "0");
            return Q(b, 6, Nb(a.o), "0")
        };
    var Hf = function() {
        var a = {};
        this.u = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var If = /^true$/.test("false");

    function Jf(a, b) {
        switch (b) {
            case 1:
                return U(a, mc(a, Bf, 1));
            case 2:
                return U(a, mc(a, Bf, 2));
            case 3:
                return U(a, mc(a, Bf, 3));
            case 6:
                return U(a, mc(a, Bf, 6));
            default:
                return null
        }
    }

    function Kf(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return uc(a, 1);
            case 7:
                return T(a, 3);
            case 2:
                return zc(a, 2);
            case 3:
                return T(a, 3);
            case 6:
                return hc(a, 4, Sb);
            default:
                return null
        }
    }
    var Lf = Qc(function() {
        if (!If) return {};
        try {
            var a;
            var b = void 0 === b ? window : b;
            try {
                var c = b.sessionStorage
            } catch (e) {
                c = null
            }
            var d = null == (a = c) ? void 0 : a.getItem("GGDFSSK");
            if (d) return JSON.parse(d)
        } catch (e) {}
        return {}
    });

    function Mf(a, b, c, d) {
        var e = d = void 0 === d ? 0 : d,
            f, g;
        W(Nf).j[e] = null != (g = null == (f = W(Nf).j[e]) ? void 0 : f.add(b)) ? g : (new t.Set).add(b);
        e = Lf();
        if (null != e[b]) return e[b];
        b = Of(d)[b];
        if (!b) return c;
        b = Af(JSON.stringify(b));
        b = Pf(b);
        a = Kf(b, a);
        return null != a ? a : c
    }

    function Pf(a) {
        var b = W(Hf).u;
        if (b) {
            var c = Na(S(a, yf, 5), function(f) {
                return wf(R(f, pf, 1), b)
            });
            if (c) {
                var d;
                return null != (d = R(c, xf, 2)) ? d : null
            }
        }
        var e;
        return null != (e = R(a, xf, 4)) ? e : null
    }
    var Nf = function() {
        this.i = {};
        this.l = [];
        this.j = {};
        this.g = new t.Map
    };

    function Qf(a, b, c) {
        return !!Mf(1, a, void 0 === b ? !1 : b, c)
    }

    function Rf(a, b, c) {
        b = void 0 === b ? 0 : b;
        a = Number(Mf(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Sf(a, b, c) {
        b = void 0 === b ? "" : b;
        a = Mf(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function Tf(a, b, c) {
        b = void 0 === b ? [] : b;
        a = Mf(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Of(a) {
        return W(Nf).i[a] || (W(Nf).i[a] = {})
    }

    function Uf(a, b) {
        var c = Of(b);
        qd(a, function(d, e) {
            return c[e] = d
        })
    }

    function Vf(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = [],
            g = [];
        La(b, function(h) {
            var k = Of(h);
            La(a, function(l) {
                var m = nc(l, Bf),
                    n = Jf(l, m);
                if (n) {
                    var q, r, A;
                    var v = null != (A = null == (q = W(Nf).g.get(h)) ? void 0 : null == (r = q.get(n)) ? void 0 : r.slice(0)) ? A : [];
                    a: {
                        q = new ne;
                        switch (m) {
                            case 1:
                                lc(q, 1, oe, Ib(n));
                                break;
                            case 2:
                                lc(q, 2, oe, Ib(n));
                                break;
                            case 3:
                                lc(q, 3, oe, Ib(n));
                                break;
                            case 6:
                                lc(q, 4, oe, Ib(n));
                                break;
                            default:
                                m = void 0;
                                break a
                        }
                        jc(q, 5, v, Jb);m = q
                    }
                    if (v = m) {
                        var D;
                        v = !(null == (D = W(Nf).j[h]) || !D.has(n))
                    }
                    v && f.push(m);
                    if (D = m) {
                        var E;
                        D = !(null == (E = W(Nf).g.get(h)) || !E.has(n))
                    }
                    D && g.push(m);
                    e || (E = W(Nf), E.g.has(h) || E.g.set(h, new t.Map), E.g.get(h).has(n) || E.g.get(h).set(n, []), d && E.g.get(h).get(n).push(d));
                    k[n] = l.toJSON()
                }
            })
        });
        (f.length || g.length) && Ff(c, f, g, null != d ? d : void 0)
    }

    function Wf(a, b) {
        var c = Of(b);
        La(a, function(d) {
            var e = Af(JSON.stringify(d)),
                f = nc(e, Bf);
            (e = Jf(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function Xf() {
        return Ma(u(Object, "keys").call(Object, W(Nf).i), function(a) {
            return Number(a)
        })
    }

    function Yf(a) {
        var b = W(Nf).l;
        0 <= Array.prototype.indexOf.call(b, a, void 0) || Uf(Of(4), a)
    };

    function Y(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Zf(a, b, c) {
        return b[a] || c
    }

    function $f(a) {
        Y(5, Qf, a);
        Y(6, Rf, a);
        Y(7, Sf, a);
        Y(8, Tf, a);
        Y(13, Wf, a);
        Y(15, Yf, a)
    }

    function ag(a) {
        Y(4, function(b) {
            W(Hf).u = b
        }, a);
        Y(9, function(b, c) {
            var d = W(Hf);
            null == d.u[3][b] && (d.u[3][b] = c)
        }, a);
        Y(10, function(b, c) {
            var d = W(Hf);
            null == d.u[4][b] && (d.u[4][b] = c)
        }, a);
        Y(11, function(b, c) {
            var d = W(Hf);
            null == d.u[5][b] && (d.u[5][b] = c)
        }, a);
        Y(14, function(b) {
            for (var c = W(Hf), d = x([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, u(Object, "assign").call(Object, c.u[e], b[e])
        }, a)
    }

    function bg(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var cg = function() {};
    cg.prototype.i = function() {};
    cg.prototype.g = function() {
        return []
    };
    var dg = function(a, b, c) {
        a.i = function(d, e) {
            Zf(2, b, function() {
                return []
            })(d, c, e)
        };
        a.g = function() {
            return Zf(3, b, function() {
                return []
            })(c)
        }
    };

    function eg(a, b) {
        try {
            var c = a.split(".");
            a = B;
            for (var d = 0, e; null != a && d < c.length; d++) e = a, a = a[c[d]], "function" === typeof a && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var fg = {},
        gg = {},
        hg = {},
        ig = {},
        jg = (ig[3] = (fg[8] = function(a) {
            try {
                return null != wa(a)
            } catch (b) {}
        }, fg[9] = function(a) {
            try {
                var b = wa(a)
            } catch (c) {
                return
            }
            if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
            return a
        }, fg[10] = function() {
            return window === window.top
        }, fg[6] = function(a) {
            var b = W(cg).g();
            return 0 <= Array.prototype.indexOf.call(b, Number(a), void 0)
        }, fg[27] = function(a) {
            a = eg(a, "boolean");
            return void 0 !== a ? a : void 0
        }, fg[60] = function(a) {
            try {
                return !!B.document.querySelector(a)
            } catch (b) {}
        }, fg[69] = function(a) {
            var b = B.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(p = c.features(), u(p, "includes")).call(p, a))
        }, fg[70] = function(a) {
            var b = B.document;
            b = void 0 === b ? document : b;
            var c;
            return !(null == (c = b.featurePolicy) || !(p = c.allowedFeatures(), u(p, "includes")).call(p, a))
        }, fg), ig[4] = (gg[3] = function() {
            return td()
        }, gg[6] = function(a) {
            a = eg(a, "number");
            return void 0 !== a ? a : void 0
        }, gg), ig[5] = (hg[2] = function() {
            return window.location.href
        }, hg[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, hg[4] = function(a) {
            a = eg(a, "string");
            return void 0 !== a ? a : void 0
        }, hg), ig);

    function kg() {
        var a = void 0 === a ? B : a;
        return a.ggeac || (a.ggeac = {})
    };
    var lg = function(a) {
        this.h = N(a)
    };
    z(lg, V);
    lg.prototype.getId = function() {
        return vc(this, 1)
    };
    lg.m = [2];
    var mg = function(a) {
        this.h = N(a)
    };
    z(mg, V);
    mg.m = [2];
    var ng = function(a) {
        this.h = N(a)
    };
    z(ng, V);
    ng.m = [2];
    var og = function(a) {
        this.h = N(a)
    };
    z(og, V);
    var pg = function(a) {
        this.h = N(a)
    };
    z(pg, V);
    pg.m = [1, 4, 2, 3];

    function qg(a) {
        var b = {};
        return rg((b[0] = new t.Map, b[1] = new t.Map, b[2] = new t.Map, b), a)
    }

    function rg(a, b) {
        for (var c = new t.Map, d = x(u(a[1], "entries").call(a[1])), e = d.next(); !e.done; e = d.next()) {
            var f = x(e.value);
            e = f.next().value;
            f = f.next().value;
            f = f[f.length - 1];
            c.set(e, f.wa + f.ua * f.va)
        }
        b = x(b);
        for (d = b.next(); !d.done; d = b.next())
            for (d = d.value, e = S(d, mg, 2), e = x(e), f = e.next(); !f.done; f = e.next())
                if (f = f.value, 0 !== S(f, lg, 2).length) {
                    var g = xc(f, 8);
                    if (U(f, 4) && !U(f, 13)) {
                        var h = void 0;
                        g = null != (h = c.get(U(f, 4))) ? h : 0;
                        h = xc(f, 1) * S(f, lg, 2).length;
                        c.set(U(f, 4), g + h)
                    }
                    h = [];
                    for (var k = 0; k < S(f, lg, 2).length; k++) {
                        var l = {
                            wa: g,
                            ua: xc(f, 1),
                            va: S(f, lg, 2).length,
                            Ia: k,
                            pa: U(d, 1),
                            N: f,
                            D: S(f, lg, 2)[k]
                        };
                        h.push(l)
                    }
                    sg(a[2], U(f, 10), h) || sg(a[1], U(f, 4), h) || sg(a[0], S(f, lg, 2)[0].getId(), h)
                }
        return a
    }

    function sg(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        var d;
        (d = a.get(b)).push.apply(d, y(c));
        return !0
    };

    function tg(a) {
        a = void 0 === a ? pd() : a;
        return function(b) {
            return rd(b + " + " + a) % 1E3
        }
    };
    var ug = [12, 13, 20],
        vg = function(a, b, c, d) {
            d = void 0 === d ? {} : d;
            var e = void 0 === d.T ? !1 : d.T;
            d = void 0 === d.Ma ? [] : d.Ma;
            this.H = a;
            this.B = c;
            this.l = {};
            this.T = e;
            a = {};
            this.g = (a[b] = [], a[4] = [], a);
            this.i = {};
            this.j = {};
            var f;
            if (null === of ) { of = "";
                try {
                    b = "";
                    try {
                        b = B.top.location.hash
                    } catch (g) {
                        b = B.location.hash
                    }
                    b && ( of = (f = b.match(/\bdeid=([\d,]+)/)) ? f[1] : "")
                } catch (g) {}
            }
            if (f = of )
                for (f = x(f.split(",") || []), b = f.next(); !b.done; b = f.next())(b = Number(b.value)) && (this.i[b] = !0);
            d = x(d);
            for (f = d.next(); !f.done; f = d.next()) this.i[f.value] = !0
        },
        xg = function(a, b, c, d) {
            var e = [],
                f;
            if (f = 9 !== b) a.l[b] ? f = !0 : (a.l[b] = !0, f = !1);
            if (f) return Ef(a.B, b, c, e, [], 4), e;
            f = u(ug, "includes").call(ug, b);
            for (var g = [], h = W(Hf).u, k = [], l = x([0, 1, 2]), m = l.next(); !m.done; m = l.next()) {
                m = m.value;
                for (var n = x(u(a.H[m], "entries").call(a.H[m])), q = n.next(); !q.done; q = n.next()) {
                    var r = x(q.value);
                    q = r.next().value;
                    r = r.next().value;
                    var A = q,
                        v = r;
                    q = new fe;
                    r = v.filter(function(ra) {
                        return ra.pa === b && !!a.i[ra.D.getId()] && wf(R(ra.N, pf, 3), h) && wf(R(ra.D, pf, 3), h)
                    });
                    if (r.length)
                        for (q = x(r), v = q.next(); !v.done; v = q.next()) k.push(v.value.D);
                    else if (!a.T) {
                        r = void 0;
                        2 === m ? (r = d[1], lc(q, 2, ge, Ib(A))) : r = d[0];
                        var D = void 0,
                            E = void 0;
                        r = null != (E = null == (D = r) ? void 0 : D(String(A))) ? E : 2 === m && 1 === U(v[0].N, 11) ? void 0 : d[0](String(A));
                        if (void 0 !== r) {
                            A = x(v);
                            for (v = A.next(); !v.done; v = A.next())
                                if (v = v.value, v.pa === b) {
                                    D = r - v.wa;
                                    var ja = v;
                                    E = ja.ua;
                                    var za = ja.va;
                                    ja = ja.Ia;
                                    0 <= D && D < E * za && D % za === ja && wf(R(v.N, pf, 3), h) && wf(R(v.D, pf, 3), h) && (D = U(v.N, 13), 0 !== D && void 0 !== D && (E = a.j[String(D)], void 0 !== E && E !== v.D.getId() ? Gf(a.B, a.j[String(D)], v.D.getId(), D) : a.j[String(D)] = v.D.getId()), k.push(v.D))
                                }
                            0 !== nc(q, ge) && (Q(q, 3, Kb(r), 0), g.push(q))
                        }
                    }
                }
            }
            d = x(k);
            for (k = d.next(); !k.done; k = d.next()) k = k.value, l = k.getId(), e.push(l), wg(a, l, f ? 4 : c), Vf(S(k, zf, 2), f ? Xf() : [c], a.B, l);
            Ef(a.B, b, c, e, g, 1);
            return e
        },
        wg = function(a, b, c) {
            a.g[c] || (a.g[c] = []);
            a = a.g[c];
            u(a, "includes").call(a, b) || a.push(b)
        },
        yg = function(a, b) {
            b = b.map(function(c) {
                return new ng(c)
            }).filter(function(c) {
                return !u(ug, "includes").call(ug, U(c, 1))
            });
            a.H = rg(a.H, b)
        },
        zg = function(a, b) {
            Y(1, function(c) {
                a.i[c] = !0
            }, b);
            Y(2, function(c, d, e) {
                return xg(a, c, d, e)
            }, b);
            Y(3, function(c) {
                return (a.g[c] || []).concat(a.g[4])
            }, b);
            Y(12, function(c) {
                return void yg(a, c)
            }, b);
            Y(16, function(c, d) {
                return void wg(a, c, d)
            }, b)
        };
    var Ag = function() {
            this.g = function() {}
        },
        Bg = function(a, b) {
            a.g = Zf(14, b, function() {})
        };

    function Cg(a) {
        W(Ag).g(a)
    };
    var Dg, Eg, Fg, Gg, Hg, Ig;

    function Jg(a) {
        var b = a.Da,
            c = a.u,
            d = a.config,
            e = void 0 === a.za ? kg() : a.za,
            f = void 0 === a.ma ? 0 : a.ma,
            g = void 0 === a.B ? new Cf(null != (Gg = null == (Dg = R(b, og, 5)) ? void 0 : yc(Dg, 2)) ? Gg : 0, null != (Hg = null == (Eg = R(b, og, 5)) ? void 0 : yc(Eg, 4)) ? Hg : 0, null != (Ig = null == (Fg = R(b, og, 5)) ? void 0 : uc(Fg, 3)) ? Ig : !1) : a.B;
        a = void 0 === a.H ? qg(S(b, ng, 2)) : a.H;
        e.hasOwnProperty("init-done") ? (Zf(12, e, function() {})(S(b, ng, 2).map(function(h) {
            return h.toJSON()
        })), Zf(13, e, function() {})(S(b, zf, 1).map(function(h) {
            return h.toJSON()
        }), f), c && Zf(14, e, function() {})(c), Kg(f, e)) : (zg(new vg(a, f, g, d), e), $f(e), ag(e), bg(e), Kg(f, e), Vf(S(b, zf, 1), [f], g, void 0, !0), If = If || !(!d || !d.hb), Cg(jg), c && Cg(c))
    }

    function Kg(a, b) {
        var c = b = void 0 === b ? kg() : b;
        dg(W(cg), c, a);
        Lg(b, a);
        a = b;
        Bg(W(Ag), a);
        W(Sc).l()
    }

    function Lg(a, b) {
        var c = W(Sc);
        c.i = function(d, e) {
            return Zf(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.g = function(d, e) {
            return Zf(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.o = function(d, e) {
            return Zf(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.j = function(d, e) {
            return Zf(8, a, function() {
                return []
            })(d, e, b)
        };
        c.l = function() {
            Zf(15, a, function() {})(b)
        }
    };
    var Mg = ia(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        Ng = function() {
            var a = void 0 === a ? "jserror" : a;
            var b = void 0 === b ? .01 : b;
            var c = void 0 === c ? Ad(Mg) : c;
            this.j = a;
            this.i = b;
            this.g = c
        };

    function Og(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = vd("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, !1);
                e.removeEventListener && e.removeEventListener("error", f, !1)
            };
            Rc(e, "load", f);
            Rc(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }
    var Qg = function(a) {
            var b = void 0 === b ? !1 : b;
            var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=gpt_inv_ver";
            qd(a, function(d, e) {
                if (d || 0 === d) c += "&" + e + "=" + encodeURIComponent("" + d)
            });
            Pg(c, b)
        },
        Pg = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : Og(c, a, void 0 === b ? !1 : b, void 0 === d ? !1 : d)
        };

    function Rg(a) {
        a = void 0 === a ? B : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var Sg = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        Tg = function(a, b) {
            var c = Rg(b);
            c && Sg({
                label: a,
                type: 9,
                value: c
            }, b)
        },
        Ug = function(a, b, c) {
            var d = !1;
            d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = Rg(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && Sg(u(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (Rg() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        },
        Vg = function(a, b) {
            return Ug(a, b, function(c, d) {
                var e = new Ng;
                var f = void 0 === f ? e.i : f;
                var g = void 0 === g ? e.j : g;
                Math.random() > f || (d.error && d.meta && d.id || (d = new nf(d, {
                    context: c,
                    id: g
                })), B.google_js_errors = B.google_js_errors || [], B.google_js_errors.push(d), B.error_rep_loaded || (f = B.document, c = vd("SCRIPT", f), jd(c, e.g), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), B.error_rep_loaded = !0))
            })
        };

    function Z(a, b) {
        return null == b ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function Wg(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function Xg() {
        var a = new t.Set;
        var b = window.googletag;
        b = (null == b ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = x(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function Yg(a) {
        a = a.id;
        return null != a && (Xg().has(a) || u(a, "startsWith").call(a, "google_ads_iframe_") || u(a, "startsWith").call(a, "aswift"))
    }

    function Zg(a, b, c) {
        if (!a.sources) return !1;
        switch ($g(a)) {
            case 2:
                var d = ah(a);
                if (d) return c.some(function(f) {
                    return bh(d, f)
                });
                break;
            case 1:
                var e = ch(a);
                if (e) return b.some(function(f) {
                    return bh(e, f)
                })
        }
        return !1
    }

    function $g(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function ch(a) {
        return dh(a, function(b) {
            return b.currentRect
        })
    }

    function ah(a) {
        return dh(a, function(b) {
            return b.previousRect
        })
    }

    function dh(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function bh(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }
    var eh = function() {
            var a = {
                oa: !0
            };
            a = void 0 === a ? {
                oa: !1
            } : a;
            this.j = this.i = this.O = this.M = this.G = 0;
            this.ia = this.fa = Number.NEGATIVE_INFINITY;
            this.g = [];
            this.J = {};
            this.ca = 0;
            this.I = Infinity;
            this.aa = this.da = this.ea = this.ga = this.la = this.o = this.ka = this.R = this.l = 0;
            this.ba = !1;
            this.P = this.K = this.F = 0;
            this.B = null;
            this.ha = !1;
            this.Z = function() {};
            var b = document.querySelector("[data-google-query-id]");
            this.ja = b ? b.getAttribute("data-google-query-id") : null;
            this.ya = a
        },
        fh, gh, jh = function() {
            var a = new eh;
            if (Tc(Pc)) {
                var b = window;
                if (!b.google_plmetrics && window.PerformanceObserver) {
                    b.google_plmetrics = !0;
                    b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                    a.ya.oa && b.push("event");
                    b = x(b);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        var d = {
                            type: c,
                            buffered: !0
                        };
                        "event" === c && (d.durationThreshold = 40);
                        hh(a).observe(d)
                    }
                    ih(a)
                }
            }
        },
        hh = function(a) {
            a.B || (a.B = new PerformanceObserver(Vg(640, function(b) {
                kh(a, b)
            })));
            return a.B
        },
        ih = function(a) {
            var b = Vg(641, function() {
                    var d = document;
                    2 === (d.prerendering ? 3 : {
                        visible: 1,
                        hidden: 2,
                        prerender: 3,
                        preview: 4,
                        unloaded: 5
                    }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && lh(a)
                }),
                c = Vg(641, function() {
                    return void lh(a)
                });
            document.addEventListener("visibilitychange", b);
            document.addEventListener("pagehide", c);
            a.Z = function() {
                document.removeEventListener("visibilitychange", b);
                document.removeEventListener("pagehide", c);
                hh(a).disconnect()
            }
        },
        lh = function(a) {
            if (!a.ha) {
                a.ha = !0;
                hh(a).takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += Wg("cls", a.G), b += Wg("mls", a.M), b += Z("nls", a.O), window.LayoutShiftAttribution && (b += Wg("cas", a.o), b += Z("nas", a.ga), b += Wg("was", a.la)), b += Wg("wls", a.R), b += Wg("tls", a.ka));
                window.LargestContentfulPaint && (b += Z("lcp", a.ea), b += Z("lcps", a.da));
                window.PerformanceEventTiming && a.ba && (b += Z("fid", a.aa));
                window.PerformanceLongTaskTiming && (b += Z("cbt", a.F), b += Z("mbt", a.K), b += Z("nlt", a.P));
                for (var c = 0, d = x(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) Yg(e.value) && c++;
                b += Z("nif", c);
                c = window.google_unique_id;
                b += Z("ifi", "number" === typeof c ? c : 0);
                c = W(cg).g();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (B === B.top ? 1 : 0);
                b += a.ja ? "&qqid=" + encodeURIComponent(a.ja) : Z("pvsid", wd(B));
                window.googletag && (b += "&gpt=1");
                c = Math.min(a.g.length - 1, Math.floor((a.B ? a.ca : performance.interactionCount || 0) / 50));
                0 <= c && (c = a.g[c].latency, 0 <= c && (b += Z("inp", c)));
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.Z()
            }
        },
        mh = function(a, b, c, d) {
            if (!b.hadRecentInput) {
                a.G += Number(b.value);
                Number(b.value) > a.M && (a.M = Number(b.value));
                a.O += 1;
                if (c = Zg(b, c, d)) a.o += b.value, a.ga++;
                if (5E3 < b.startTime - a.fa || 1E3 < b.startTime - a.ia) a.fa = b.startTime, a.i = 0, a.j = 0;
                a.ia = b.startTime;
                a.i += b.value;
                c && (a.j += b.value);
                a.i > a.R && (a.R = a.i, a.la = a.j, a.ka = b.startTime + b.duration)
            }
        },
        kh = function(a, b) {
            var c = fh !== window.scrollX || gh !== window.scrollY ? [] : nh,
                d = oh();
            b = x(b.getEntries());
            for (var e = b.next(), f = {}; !e.done; f = {
                    v: f.v
                }, e = b.next()) switch (f.v = e.value, e = f.v.entryType, e) {
                case "layout-shift":
                    mh(a, f.v, c, d);
                    break;
                case "largest-contentful-paint":
                    e = f.v;
                    a.ea = Math.floor(e.renderTime || e.loadTime);
                    a.da = e.size;
                    break;
                case "first-input":
                    e = f.v;
                    a.aa = Number((e.processingStart - e.startTime).toFixed(3));
                    a.ba = !0;
                    a.g.some(function(g) {
                        return function(h) {
                            return u(h, "entries").some(function(k) {
                                return g.v.duration === k.duration && g.v.startTime === k.startTime
                            })
                        }
                    }(f)) || ph(a, f.v);
                    break;
                case "longtask":
                    e = Math.max(0, f.v.duration - 50);
                    a.F += e;
                    a.K = Math.max(a.K, e);
                    a.P += 1;
                    break;
                case "event":
                    ph(a, f.v);
                    break;
                default:
                    throw Error("unexpected value " + e + "!");
            }
        },
        ph = function(a, b) {
            qh(a, b);
            var c = a.g[a.g.length - 1],
                d = a.J[b.interactionId];
            if (d || 10 > a.g.length || b.duration > c.latency) d ? (u(d, "entries").push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
                id: b.interactionId,
                latency: b.duration,
                entries: [b]
            }, a.J[b.id] = b, a.g.push(b)), a.g.sort(function(e, f) {
                return f.latency - e.latency
            }), a.g.splice(10).forEach(function(e) {
                delete a.J[e.id]
            })
        },
        qh = function(a, b) {
            b.interactionId && (a.I = Math.min(a.I, b.interactionId), a.l = Math.max(a.l, b.interactionId), a.ca = a.l ? (a.l - a.I) / 7 + 1 : 0)
        },
        oh = function() {
            var a = u(Array, "from").call(Array, document.getElementsByTagName("iframe")).filter(Yg),
                b = [].concat(y(Xg())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return null !== c
                });
            fh = window.scrollX;
            gh = window.scrollY;
            return nh = [].concat(y(a), y(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        nh = [];
    var rh = function(a) {
        this.h = N(a)
    };
    z(rh, V);
    rh.prototype.getVersion = function() {
        return T(this, 2)
    };
    var sh = function(a) {
        this.h = N(a)
    };
    z(sh, V);
    var th = function(a, b) {
            return P(a, 2, M(b))
        },
        uh = function(a, b) {
            return P(a, 3, M(b))
        },
        vh = function(a, b) {
            return P(a, 4, M(b))
        },
        wh = function(a, b) {
            return P(a, 5, M(b))
        },
        xh = function(a, b) {
            return P(a, 9, M(b))
        },
        yh = function(a, b) {
            return sc(a, 10, b)
        },
        zh = function(a, b) {
            return P(a, 11, Fb(b))
        },
        Ah = function(a, b) {
            return P(a, 1, M(b))
        },
        Bh = function(a, b) {
            return P(a, 7, Fb(b))
        };
    sh.m = [10, 6];
    var Ch = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Dh(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function Eh(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function Fh(a) {
        if (!Eh(a)) return null;
        var b = Dh(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Ch).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Gh(a) {
        var b;
        return zh(yh(wh(th(Ah(vh(Bh(xh(uh(new sh, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new rh;
            d = P(d, 1, M(c.brand));
            return P(d, 2, M(c.version))
        })) || []), a.wow64 || !1)
    }

    function Hh(a) {
        var b, c;
        return null != (c = null == (b = Fh(a)) ? void 0 : b.then(function(d) {
            return Gh(d)
        })) ? c : null
    };

    function Ih(a, b) {
        var c = {};
        b = (c[0] = tg(b.Ka), c);
        W(cg).i(a, b)
    };
    var Jh = {},
        Kh = (Jh[253] = !1, Jh[246] = [], Jh[150] = "", Jh[221] = !1, Jh[36] = /^true$/.test("false"), Jh[172] = null, Jh[260] = void 0, Jh[251] = null, Jh),
        Dc = function() {
            this.g = !1
        };

    function Lh(a) {
        W(Dc).g = !0;
        return Kh[a]
    }

    function Mh(a, b) {
        W(Dc).g = !0;
        Kh[a] = b
    };
    var Nh = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;

    function Oh(a) {
        return a ? !Nh.test(a.src) : !0
    };

    function Ph(a) {
        var b = a.Ga,
            c = a.Pa,
            d = a.Fa,
            e = a.Ca,
            f = a.Ea,
            g = Oh(a.ra);
        a = {};
        var h = {},
            k = {};
        return k[3] = (a[3] = function() {
            return !g
        }, a[59] = function() {
            var l = ta.apply(0, arguments),
                m = u(l, "includes"),
                n = String,
                q;
            var r = void 0 === r ? window : r;
            var A;
            r = null != (A = null == (q = fd(r.location.href.match(ed)[3] || null)) ? void 0 : q.split(".")) ? A : [];
            q = 2 > r.length ? null : "uk" === r[r.length - 1] ? 3 > r.length ? null : rd(r.splice(r.length - 3).join(".")) : rd(r.splice(r.length - 2).join("."));
            return m.call(l, n(q))
        }, a[61] = function() {
            return d
        }, a[63] = function() {
            return d || ".google.ch" === f
        }, a[73] = function(l) {
            return u(c, "includes").call(c, Number(l))
        }, a), k[4] = (h[1] = function() {
            return e
        }, h[4] = function() {
            if (sd.test("0")) {
                var l = Number("0");
                l = isNaN(l) ? null : l
            } else l = null;
            return l || 0
        }, h[13] = function() {
            return b || 0
        }, h), k[5] = {}, k
    };

    function Qh(a, b) {
        var c = new pg(Lh(246));
        if (!S(c, zf, 1).length && S(a, zf, 1).length) {
            var d = S(a, zf, 1);
            sc(c, 1, d)
        }!S(c, ng, 2).length && S(a, ng, 2).length && (d = S(a, ng, 2), sc(c, 2, d));
        void 0 === oc(c, og, 5, !1) && void 0 !== oc(a, og, 5, !1) && (a = R(a, og, 5), qc(c, 5, a));
        Jg({
            Da: c,
            u: Ph(b),
            ma: 2
        })
    };

    function Rh(a, b, c, d, e) {
        a = a.location.host;
        var f = hd(b.src, "domain");
        b = hd(b.src, "network-code");
        if (a || f || b) {
            var g = {};
            a && (g.ippd = a);
            f && (g.pppd = f);
            b && (g.pppnc = b);
            W(Sc).g(Ge.g, Ge.defaultValue) && (g.ppc_eid = W(Sc).g(Ge.g, Ge.defaultValue).toString());
            a = g
        } else a = void 0;
        if (a) {
            c = [c ? new Mc(Kc, "https://pagead2.googlesyndication.com") : new Mc(Kc, "https://securepubads.g.doubleclick.net"), new Mc(Kc, "/pagead/ppub_config")];
            f = "";
            for (b = 0; b < c.length; b++) g = c[b], f += g instanceof Mc && g.constructor === Mc && g.i === Lc ? g.g : "type_error:Const";
            c = new Xc(f, $c);
            c = Zc.exec(Yc(c).toString());
            f = c[3] || "";
            c = new Xc(c[1] + ad("?", c[2] || "", a) + ad("#", f), $c);
            Sh(c, d, e)
        } else e(new t.globalThis.Error("no provided or inferred data"))
    }

    function Sh(a, b, c) {
        var d = new t.globalThis.XMLHttpRequest;
        d.open("GET", a.toString(), !0);
        d.withCredentials = !1;
        d.onload = function() {
            300 > d.status ? (Tg("13", window), b(204 === d.status ? "" : d.responseText)) : c(new t.globalThis.Error("resp:" + d.status))
        };
        d.onerror = function() {
            return void c(new t.globalThis.Error("s:" + d.status + " rs:" + d.readyState))
        };
        d.send()
    };
    var Th = function() {
            this.l = [];
            this.j = []
        },
        Wh = function(a, b, c, d, e) {
            if (nd(b) === od(b) && c) {
                Uh(a);
                var f = null == e ? void 0 : T(pc(e, Hc), 1);
                f && f.length && u(b.location.hostname, "includes").call(b.location.hostname, f) ? Vh(a, void 0, e) : Rh(b.top, c, d, function(g) {
                    return void Vh(a, g)
                }, function(g) {
                    Vh(a, void 0, void 0, g)
                })
            }
        },
        Uh = function(a) {
            Lh(260);
            Mh(260, function(b) {
                void 0 !== a.g || a.i ? b(a.g, a.i) : a.l.push(b)
            })
        },
        Vh = function(a, b, c, d) {
            a.g = null != b ? b : null == c ? void 0 : Bc(c);
            a.o = c;
            !a.o && a.g && a.j.length && (a.o = Jc(a.g));
            a.i = d;
            b = x(a.l);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.g, a.i);
            b = x(a.j);
            for (c = b.next(); !c.done; c = b.next()) c = c.value, c(a.o, a.i);
            a.l.length = 0;
            a.j.length = 0
        };
    var Xh = function(a) {
        this.h = N(a)
    };
    z(Xh, V);
    var Yh = Gc(Xh);
    Xh.m = [10];
    var $h = function() {
            return [].concat(y(u(Zh, "values").call(Zh))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        Zh = new t.Map;

    function ai(a, b, c) {
        if (a.Na) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new we,
                e = new ve;
            try {
                var f = wd(window);
                Q(e, 1, Nb(f), "0")
            } catch (q) {}
            try {
                var g = W(cg).g();
                jc(e, 2, g, Jb)
            } catch (q) {}
            try {
                Q(e, 3, M(window.document.URL), "")
            } catch (q) {}
            f = qc(d, 2, e);
            g = new ue;
            b = Q(g, 1, Ib(b), 0);
            try {
                var h = mf(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                Q(b, 2, M(h), "")
            } catch (q) {}
            try {
                var k = mf(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                Q(b, 3, M(k), "")
            } catch (q) {}
            try {
                var l = mf(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && jc(b, 4, l.split(/\n\s*/), Rb)
            } catch (q) {}
            h = qc(f, 1, b);
            k = new te;
            try {
                Q(k, 1, M(a.W || a.sa), "")
            } catch (q) {}
            try {
                var m = $h();
                Q(k, 2, Kb(m), 0)
            } catch (q) {}
            try {
                var n = [].concat(y(u(Zh, "keys").call(Zh)));
                jc(k, 3, n, Rb)
            } catch (q) {}
            rc(h, 4, xe, k);
            Q(h, 5, Nb(a.Ba), "0");
            a.La.Oa(h)
        }
    };

    function bi(a, b) {
        try {
            var c = Ec();
            if (!mf(a)) {
                var d = c ? c() + "\n" : "";
                throw Error(d + String(a));
            }
            return Yh(a)
        } catch (e) {
            return ai(b, 838, e), new Xh
        }
    };

    function ci() {
        var a;
        return null != (a = B.googletag) ? a : B.googletag = {
            cmd: []
        }
    }

    function di(a, b) {
        var c = ci();
        c.hasOwnProperty(a) || (c[a] = b)
    };
    var ei = ia(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl.js"]),
        fi = ia(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", ".js"]),
        gi = ia(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl.js"]),
        hi = ia(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", ".js"]);

    function ii() {
        var a = "undefined" === typeof sttc ? void 0 : sttc,
            b = ji();
        Ab(function(v) {
            ai(b, 1189, v)
        });
        var c = ci();
        a = bi(a, b);
        Cc();
        u(Object, "assign").call(Object, Kh, c._vars_);
        c._vars_ = Kh;
        a && (uc(a, 3) && Mh(36, !0), uc(a, 5) && Mh(221, !0), T(a, 6) && Mh(150, T(a, 6)));
        var d = pc(a, pg),
            e = {
                Fa: uc(a, 5),
                Ga: vc(a, 2),
                Pa: hc(a, 10, Lb),
                Ca: vc(a, 7),
                Ea: T(a, 6)
            };
        a = R(a, Ic, 9);
        var f, g = null != (f = c.fifWin) ? f : window,
            h = g.document;
        f = c.fifWin ? window : g;
        di("_loaded_", !0);
        var k = ki(b);
        di("cmd", []);
        var l, m = null != (l = li(h)) ? l : mi(h);
        ni(d, g, u(Object, "assign").call(Object, {}, {
            ra: m
        }, e), k);
        try {
            jh()
        } catch (v) {}
        Tg("1", g);
        l = oi(k, m);
        d = !1;
        if (!pi(h)) {
            e = "gpt-impl-" + Math.random();
            try {
                kd(h, xd(l, {
                    id: e,
                    nonce: id(window)
                }))
            } catch (v) {}
            h.getElementById(e) && (Tc(Ee) ? d = !0 : c._loadStarted_ = !0)
        }
        if (Tc(Ee) ? !d : !c._loadStarted_) {
            var n = vd("SCRIPT");
            jd(n, l);
            n.async = !0;
            h = c.fifWin ? f.document : h;
            l = h.body;
            d = h.documentElement;
            var q, r, A = null != (r = null != (q = h.head) ? q : l) ? r : d;
            "complete" !== f.document.readyState && c.fifWin ? Rc(f, "load", function() {
                return void A.appendChild(n)
            }) : A.appendChild(n);
            Tc(Ee) || (c._loadStarted_ = !0)
        }
        if (f === f.top) try {
            jf(f)
        } catch (v) {
            ai(k, 1209, v)
        }
        Wh(new Th, f, m, qi(m), a)
    }

    function ji() {
        return {
            sa: "1",
            W: "m202312060101",
            Ka: wd(window),
            La: new De(11, "m202312060101"),
            Na: .01 > pd(),
            Ba: 100
        }
    }

    function ki(a) {
        var b = new Mc(Kc, "1");
        var c = a.W;
        /m\d+/.test(c) ? c = Number(c.substring(1)) : (c && Qg({
            mjsv: c
        }), c = void 0);
        return u(Object, "assign").call(Object, {}, a, {
            gb: b,
            ib: c,
            jb: new Mc(Kc, "m202312060101")
        })
    }

    function li(a) {
        return (a = a.currentScript) ? a : null
    }

    function mi(a) {
        var b;
        a = x(null != (b = a.scripts) ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, u(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function oi(a, b) {
        var c = a.sa;
        a = a.W;
        b = qi(b) ? a ? Ad(ei, a) : Ad(fi, c) : a ? Ad(gi, a) : Ad(hi, c);
        return (c = W(Sc).g(He.g, He.defaultValue)) ? Bd(b, new t.Map([
            ["cb", c]
        ])) : b
    }

    function ni(a, b, c, d) {
        Mh(172, c.ra);
        Qh(a, c);
        Ih(12, d);
        Ih(5, d);
        (a = Hh(b)) && a.then(function(e) {
            return void Mh(251, Bc(e))
        });
        ud(Uc(), b.document)
    }

    function pi(a) {
        var b = li(a);
        return "complete" === a.readyState || "loaded" === a.readyState || !(null == b || !b.async)
    }

    function qi(a) {
        return !(null == a || !a.src) && "pagead2.googlesyndication.com" === fd(a.src.match(ed)[3] || null)
    };
    try {
        ii()
    } catch (a) {
        try {
            ai(ji(), 420, a)
        } catch (b) {}
    };
}).call(this.googletag && googletag.fifWin ? googletag.fifWin.parent : this, "[[[[577939489,null,null,[1]],[null,7,null,[null,0.1]],[476475256,null,null,[1]],[null,427198696,null,[null,1]],[null,578655462,null,[null,20]],[571050247,null,null,[1]],[570864697,null,null,[1]],[573236024,null,null,[1]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,1916,null,[null,0.001]],[null,377289019,null,[null,10000]],[576957572,null,null,[1]],[null,529,null,[null,20]],[null,573282293,null,[null,0.01]],[549005203,null,null,[1]],[579875511,null,null,[1]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[45401685,null,null,[1]],[561164161,null,null,[1]],[null,550718589,null,[null,250],[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[null,500]]]],[531615531,null,null,null,[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[1]]]],[null,532520346,null,[null,120]],[557870754,null,null,[1]],[null,553562174,null,[null,10]],[31077334,null,null,[1]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,376149757,null,[null,0.0025]],[570764855,null,null,[1]],[null,null,579921177,[null,null,\"control_1\\\\\\\\.\\\\\\\\d\"]],[null,570764854,null,[null,50]],[578725095,null,null,[1]],[377936516,null,null,[1]],[null,null,2,[null,null,\"1-0-40\"]],[null,506394061,null,[null,100]],[526684968,null,null,[1]],[568353453,null,null,[1]],[null,null,null,[],null,489],[392065905,null,null,null,[[[4,null,68],[1]]]],[null,360245595,null,[null,500]],[45397804,null,null,[1]],[45398607,null,null,[1]],[null,397316938,null,[null,1000]],[563462360,null,null,[1]],[555237688,null,null,[],[[[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,27,null,null,null,null,[\"isSecureContext\"]]]]]],[1]]]],[555237686,null,null,[]],[507033477,null,null,[1]],[552803605,null,null,[1]],[null,514795754,null,[null,2]],[564724551,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[0-6])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[567489814,null,null,[1]],[45415915,null,null,[1]],[582661286,null,null,[1]],[582287318,null,null,[1]],[564852646,null,null,[1]],[587029311,null,null,[1]],[null,null,null,[null,null,null,[\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A\/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U\/roYjp4Yau0T3YSuc63vmAs\/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[1000,[[31072561]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[12,null,null,null,4,null,\"FLEDGE_GAM_EXTERNAL_TESTER\",[\"navigator.userAgent\"]]]]],[1,[[31075124,[[null,514795754,null,[null,4]]]]],[4,null,74,null,null,null,null,[\"1585821863\",\"3976716532\"]],59],[null,[[31078990,[[540043576,null,null,[1]]]]]],[10,[[31079632],[31079633],[31079634,[[null,514795754,null,[null,4]]]]],[2,[[4,null,9,null,null,null,null,[\"fetch\"]],[4,null,9,null,null,null,null,[\"navigator.getInterestGroupAdAuctionData\"]],[1,[[12,null,null,null,4,null,\"Chrome\\\\\/115\",[\"navigator.userAgent\"]]]],[1,[[4,null,63]]],[1,[[4,null,74,null,null,null,null,[\"1585821863\",\"3976716532\"]]]]]],59],[1000,[[31079785,null,[4,null,6,null,null,null,null,[\"31079783\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[1000,[[31079786,null,[4,null,6,null,null,null,null,[\"31079784\"]]]],[4,null,8,null,null,null,null,[\"navigator.cookieDeprecationLabel\"]],101,null,null,null,null,null,null,null,null,15],[10,[[31079962],[31079963]]],[1,[[31080084],[31080085],[31080086,[[null,514795754,null,[null,4]]]]],[2,[[4,null,9,null,null,null,null,[\"fetch\"]],[4,null,9,null,null,null,null,[\"navigator.getInterestGroupAdAuctionData\"]],[1,[[12,null,null,null,4,null,\"Chrome\\\\\/115\",[\"navigator.userAgent\"]]]],[1,[[4,null,63]]],[1,[[4,null,74,null,null,null,null,[\"1585821863\",\"3976716532\"]]]]]],59],[1000,[[31080126,null,[4,null,6,null,null,null,null,[\"31080124\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31080127,null,[4,null,6,null,null,null,null,[\"31080125\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31080130,null,[4,null,6,null,null,null,null,[\"31080129\"]]]],[4,null,8,null,null,null,null,[\"__gpp\"]],88,null,null,null,null,null,null,null,null,9],[1000,[[31080138,null,[4,null,6,null,null,null,null,[\"31079958\"]]]],[2,[[4,null,8,null,null,null,null,[\"__tcfapi\"]],[3,[[4,null,8,null,null,null,null,[\"document.browsingTopics\"]],[4,null,8,null,null,null,null,[\"sharedStorage\"]]]]]],106,null,null,null,null,null,null,null,null,17],[1000,[[31080139,null,[4,null,6,null,null,null,null,[\"31079959\"]]]],[2,[[4,null,8,null,null,null,null,[\"__tcfapi\"]],[3,[[4,null,8,null,null,null,null,[\"document.browsingTopics\"]],[4,null,8,null,null,null,null,[\"sharedStorage\"]]]]]],106,null,null,null,null,null,null,null,null,17],[null,[[44798283,[[null,514795754,null,[null,4]]]]],[2,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,63]]]]],59],[50,[[44807746],[44807747,[[547020083,null,null,[1]]]]],null,105],[10,[[44807748,[[547020083,null,null,[1]]]],[95320512]],null,105],[null,[[676982960],[676982998]]]]],[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31078663,null,[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[4,null,8,null,null,null,null,[\"document.browsingTopics\"]]]]]]],[1000,[[31078664,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]]],[1000,[[31078665,null,[2,[[4,null,8,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]],[1000,[[31078666,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]]],[1000,[[31078667,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]]],[1000,[[31078668,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[1000,[[31078669,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]]],[1000,[[31078670,null,[4,null,70,null,null,null,null,[\"shared-storage\"]]]]],[1000,[[31078671,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]]]]],[5,[[50,[[31067420],[31067421,[[360245597,null,null,[]]]],[31077191],[44776367],[44804780],[44806358]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[100,[[31077976],[31077978,[[null,564509649,null,[null,2]]]]]],[10,[[31079088],[44776366],[44779256]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[50,[[31079233],[31079234,[[570864697,null,null,[]]]]],null,98],[50,[[31079239],[31079240,[[571050247,null,null,[]]]]],null,97],[1,[[31079732],[31079733]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[50,[[31079783],[31079784,[[570764855,null,null,[]]]]],null,100],[50,[[31079795],[31079796,[[360245597,null,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[25,[[31079925],[31079926,[[579191270,null,null,[1]]]],[31079927,[[579191270,null,null,[1]],[585711694,null,null,[1]]]]]],[100,[[31079956],[31079957,[[561985307,null,null,[1]]]],[44809527,[[561985307,null,null,[1]]]]]],[50,[[31079958],[31079959,[[577861852,null,null,[1]]]]]],[1000,[[31079960,null,[2,[[2,[[8,null,null,1,null,-1],[7,null,null,1,null,10]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31079961,null,[2,[[2,[[8,null,null,1,null,9],[7,null,null,1,null,20]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31080056,[[null,24,null,[null,31080056]]],[6,null,null,13,null,31080056]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31080057,[[null,24,null,[null,31080057]]],[6,null,null,13,null,31080057]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[100,[[31080078],[31080079,[[582338617,null,null,[1]]]]]],[100,[[31080120],[31080121,[[583216404,null,null,[1]]]]]],[50,[[31080122],[31080123,[[564509650,null,null,[1]]]]]],[50,[[31080124],[31080125,[[540043576,null,null,[1]]]],[31080129,[[null,null,null,[null,null,null,[\"gpp\",\"gpp_sid\"]],null,489],[540043576,null,null,[1]]]]]],[50,[[95320408],[95320409,[[561694963,null,null,[1]]]]]]]],[25,[[10,[[31068825],[31068826,[[null,462420536,null,[null,0.1]]]]]]]],[2,[[10,[[31079976],[31079977,[[586382198,null,null,[]],[null,575880738,null,[null,1]]]]],null,null,null,null,null,600,null,102],[50,[[31080115],[31080116],[31080117]],null,null,null,null,null,300,null,102]]],[4,[[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]],null,78]]]],null,null,[null,1000,1,1000]],null,null,null,null,\".google.com.bd\",267,2021,[[\"mail.tm\",null,\"https:\/\/mail.tm\/\",null,null,[\"15184186\",\"22758166583\"]],[],[],[31079723],null,[[\"15184186\",[[\"crwdcntrl.net\",\"https:\/\/tags.crwdcntrl.net\/lt\/c\/16589\/sync.min.js\"],[\"openx\",\"https:\/\/oa.openxcdn.net\/esp.js\"],[\"openxtest\",\"https:\/\/oa.openxcdn.net\/esp.js\"],[\"liveramp.com\"],[\"uidapi.com\"],[\"rtbhouse\",\"https:\/\/invstatic101.creativecdn.com\/encrypted-signals\/encrypted-tag-g.js\"],[\"id5-sync.com\",\"https:\/\/cdn.id5-sync.com\/api\/1.0\/esp.js\"],[\"pubcid.org\",\"https:\/\/cdn.jsdelivr.net\/gh\/prebid\/shared-id\/pubcid.js\/docs\/pubcid.min.js\"]]]],null,[]]]")