(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var ca, ea, ha, ja, na, pa, sa, va, ua, wa, xa, za, Ba, Ca, Ea, Ga, Ka, La, Ma, Na, Qa, Xa, fb, ib, kb, mb, qb, tb, xb, zb, Db, Gb, Ib, Kb, Lb, Qb, Sb, Rb, Ub, Vb, Mb, Wb, Xb, $b, ac, fc, gc, hc, ic, jc, kc, oc, pc, sc, tc, uc, wc, xc, Cc, Ec, Bc, Gc, Ic, Kc, Mc, Nc, Oc, Pc, Qc, Rc, Tc, Yc, ad, bd, cd, Wc, dd, Vc, Uc, ed, fd, gd, hd, id, jd, kd, nd, md, pd, qd, sd, wd, xd, zd, Ad, Bd, Dd, Cd, Jd, Ld, Kd, Nd, Md, Od, Qd, yd, Vd, Wd, $d, be, de, ee, he, ie, je, ke, ne, oe, ae, pe, qe, se, te, ue, ye, ze, Ae, we, Ge, xe, He, Me, Oe, Qe, Se, Te, Ue, af, bf, cf, jf, kf, mf, nf, of , pf, qf, sf, uf, vf, yf, zf, Af, Df, Ff, Hf, Jf, Lf, Nf, Qf, Rf, Sf, Tf, Vf, Wf, Yf, Zf, ag, cg, dg, eg, fg, ig, kg, og, mg, sg, tg, ug, qg, rg, vg, wg, xg, Ag, Bg, Gg, Hg, Og, Pg, Sg, Wg, $g, ch, eh, gh, hh, ih, jh, kh, lh, nh, qh, rh, xh, Eh, Hh, Kh, L, Lh, Rh, Ph, hi, ji, li, mi, ni, si, vi, Ei, Hi, Ji, Ii, Qi, Ri, Si, Ti, Ki, Ui, Li, Wi, Xi, Zi, $i, bj, aj, dj, ij, gj, jj, sj, vj, nj, oj, wj, zj, xj, Cj, Dj, Ej, Hj, Ij, Nj, Oj, Zj, fk, dk, ek, kk, ok, qk, rk, sk, uk, yk, Hk, Bk, vk, Qk, Ok, Pk, Sk, Uk, Xk, P, Zk, $k, al, cl, el, fl, nl, ol, ql, rl, wl, yl, zl, Dl, Hl, Il, Jl, Ll, Pl, Ul, Zl, $l, bm, cm, gm, hm, im, mm, fm, om, pm, qm, sm, vm, xm, ym, zm, Am, Cm, Dm, Fm, Hm, Im, Gm, Mm, Nm, Rm, Sm, Um, bn, dn, fn, jn, hn, gn, rn, un, vn, wn, xn, zn, Bn, Fn, Jn, Kn, Ln, On, Rn, Qn, Un, $n, ao, co, lo, ko, oo, ro, eo, Do, Eo, Ho, Go, Jo, Lo, No, Po, Ro, Xo, bp, cp, fp, ip, gp, hp, kp, lp, mp, pp, qp, rp, sp, up, wp, Ap, Bp, Cp, Dp, Ep, Fp, Gp, Hp, Jp, Kp, Lp, Pp, Zp, Sp, $p, aq, cq, gq, oq, hq, iq, eq, rq, uq, wq, xq, zq, Fq, Iq, Kq, Lq, Qq, Sq, Uq, Xq, qa, Yq, Zq, ar, $q, br, cr, er, gr, hr, jr, lr, pr, mr, qr, rr, tr, ur, vr, wr, xr, yr, Gr, Hr, Ir, Jr, Pr, Sr, Ur, Wr, Xr, Yr, as, As, Hs, Ls, Ms, ut, xt, Ft, At, Ct, It, Ht, Kt, Mt, Lt, Ot, Wt, $t, eu, ju, lu, mu, nu, pu, qu, ru, su, uu, vu, wu, Du, Eu, Fu, pb, Hu, Ku, Iu, Ju, Lu, Mu;
    ca = function(a) {
        return function() {
            return _.aa[a].apply(this, arguments)
        }
    };
    ea = function(a) {
        return a ? a.passive && da() ? a : a.capture || !1 : !1
    };
    ha = function(a, b) {
        b = _.fa(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    _.ia = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    ja = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    na = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.ka(e) ? "o" + _.ma(e) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    pa = function(a, b) {
        a.sort(b || _.oa)
    };
    sa = function(a) {
        for (var b = qa, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.oa;
        pa(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    va = function(a, b) {
        if (!_.ta(a) || !_.ta(b) || a.length != b.length) return !1;
        for (var c = a.length, d = ua, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.oa = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    ua = function(a, b) {
        return a === b
    };
    wa = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    xa = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = xa.apply(null, ja(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    za = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Ba = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ca = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ea = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Da.length; f++) c = Da[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Ga = function() {
        var a = _.t.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Ka = function(a) {
        return Ha ? Ia ? Ia.brands.some(function(b) {
            return (b = b.brand) && _.Ja(b, a)
        }) : !1 : !1
    };
    La = function(a) {
        return _.Ja(Ga(), a)
    };
    Ma = function() {
        return Ha ? !!Ia && 0 < Ia.brands.length : !1
    };
    Na = function() {
        return Ma() ? Ka("Chromium") : (La("Chrome") || La("CriOS")) && !(Ma() ? 0 : La("Edge")) || La("Silk")
    };
    Qa = function(a) {
        return new Oa(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.Va = function(a) {
        var b = void 0 === b ? Ra : b;
        a: if (b = void 0 === b ? Ra : b, !(a instanceof _.Sa)) {
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof Oa && d.Rk(a)) {
                    a = _.Ta(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.Ua
    };
    Xa = function(a) {
        for (var b = _.Wa.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return _.Ta(c.join(""))
    };
    _.Za = function(a) {
        a: if (Ya) {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        } else b: {
            b = document.createElement("a");
            try {
                b.href = a
            } catch (c) {
                b = void 0;
                break b
            }
            b = b.protocol;b = ":" === b || "" === b ? "https:" : b
        }
        if ("javascript:" !== b) return a
    };
    _.ab = function(a) {
        return a instanceof _.Sa ? _.$a(a) : _.Za(a)
    };
    _.db = function(a, b) {
        b = _.ab(b);
        void 0 !== b && (a.href = b)
    };
    _.eb = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    fb = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    ib = function(a, b) {
        a.textContent = _.hb(b);
        fb(a)
    };
    kb = function(a, b) {
        a.src = _.jb(b);
        fb(a)
    };
    mb = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.v.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            kb(g, a);
            c && "complete" !== b.document.readyState ? _.lb(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    qb = function(a) {
        var b, c, d, e, f, g;
        return _.nb(function(h) {
            switch (h.g) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.g + ("&tv=" + a.m + "&st=") + a.Wc, c = void 0, h.l = 2, h.yield(ob(b), 4);
                case 4:
                    c = h.m;
                    h.g = 3;
                    h.l = 0;
                    break;
                case 2:
                    pb(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.Dd || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.l ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.v,
                        Cj: c.bg_hash_basename,
                        Bj: c.bg_binary,
                        Wk: a.g + "_" + a.m,
                        Dd: d,
                        Wc: a.Wc,
                        Je: e,
                        jf: f,
                        Ie: g
                    }) : h.return(void 0)
            }
        })
    };
    tb = function(a) {
        var b;
        return _.nb(function(c) {
            if (1 == c.g) return c.yield(qb(a), 2);
            if (b = c.m) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.Cj, g._bgp_ = b.Bj, g._li_ = b.Wk, g._jk_ = b.Dd, g._st_ = b.Wc, g._rc_ = b.Je, g._dl_ = b.jf, g._g2_ = b.Ie, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = rb(sb, {
                    basename: d
                });
                mb(d)
            }
            return c.return(b)
        })
    };
    xb = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (ub) {
            if (b && (vb ? !a.g() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a))) throw Error("Found an unpaired surrogate");
            a = (wb || (wb = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    zb = function(a) {
        _.t.setTimeout(function() {
            throw a;
        }, 0)
    };
    Db = function(a) {
        if (!Ab) return Bb(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Gb = function(a) {
        return Fb[a] || ""
    };
    Ib = function(a) {
        return Hb && null != a && a instanceof Uint8Array
    };
    Kb = function(a) {
        if (a !== Jb) throw Error("illegal external caller");
    };
    Lb = function() {
        return "function" === typeof BigInt
    };
    Qb = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.z(Mb(c, a)), b = c.next().value, a = c.next().value, c = b);
        Nb = c >>> 0;
        Ob = a >>> 0
    };
    Sb = function(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else Lb() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), c = b + Rb(c) + Rb(a));
        return c
    };
    Rb = function(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    };
    Ub = function() {
        var a = Nb,
            b = Ob;
        b & 2147483648 ? Lb() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = _.z(Mb(a, b)), a = b.next().value, b = b.next().value, a = "-" + Sb(a, b)) : a = Sb(a, b);
        return a
    };
    Vb = function(a) {
        if (16 > a.length) Qb(Number(a));
        else if (Lb()) a = BigInt(a), Nb = Number(a & BigInt(4294967295)) >>> 0, Ob = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            Ob = Nb = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), Ob *= 1E6, Nb = 1E6 * Nb + d, 4294967296 <= Nb && (Ob += _.A(Math, "trunc").call(Math, Nb / 4294967296), Ob >>>= 0, Nb >>>= 0);
            b && (b = _.z(Mb(Nb, Ob)), a = b.next().value, b = b.next().value, Nb = a, Ob = b)
        }
    };
    Mb = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    Wb = function(a) {
        return Array.prototype.slice.call(a)
    };
    Xb = function(a) {
        return "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : a
    };
    $b = function(a) {
        var b = Yb(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Wb(a)), Zb(a, b | 1))
    };
    ac = function(a, b, c) {
        return c ? a | b : a & ~b
    };
    fc = function() {
        var a = [];
        bc(a, 1);
        return a
    };
    gc = function(a) {
        bc(a, 34);
        return a
    };
    hc = function(a) {
        bc(a, 32);
        return a
    };
    ic = function(a, b) {
        Zb(b, (a | 0) & -14591)
    };
    jc = function(a, b) {
        Zb(b, (a | 34) & -14557)
    };
    kc = function(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    oc = function(a) {
        return !(!a || "object" !== typeof a || a.Xk !== lc)
    };
    pc = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    sc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new qc(a, Jb) : rc();
            else if (a.constructor !== qc)
            if (Ib(a)) {
                var d;
                c ? d = 0 == a.length ? rc() : new qc(a, Jb) : d = a.length ? new qc(new Uint8Array(a), Jb) : rc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    tc = function(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = Yb(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? _.A(b, "includes").call(b, c) : b.has(c)))) return !1;
        Zb(a, d | 1);
        return !0
    };
    uc = function(a) {
        if (a & 2) throw Error();
    };
    wc = function(a) {
        if (vc) throw Error("");
        vc = a
    };
    xc = function(a) {
        if (vc) try {
            vc(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    };
    Cc = function() {
        var a = Bc();
        vc ? _.t.setTimeout(function() {
            xc(a)
        }, 0) : zb(a)
    };
    Ec = function(a) {
        a = Error(a);
        Dc(a, "warning");
        xc(a);
        return a
    };
    Bc = function() {
        var a = Error();
        Dc(a, "incident");
        return a
    };
    _.Fc = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number, found " + typeof a + ": " + a);
        return a
    };
    Gc = function(a) {
        if (null == a || "number" === typeof a) return a;
        if ("NaN" === a || "Infinity" === a || "-Infinity" === a) return Number(a)
    };
    Ic = function(a) {
        if ("boolean" !== typeof a) throw Error("Expected boolean but got " + Hc(a) + ": " + a);
        return a
    };
    Kc = function(a) {
        if (null == a || "boolean" === typeof a) return a;
        if ("number" === typeof a) return !!a
    };
    Mc = function(a) {
        var b = typeof a;
        return "number" === b ? _.A(Number, "isFinite").call(Number, a) : "string" !== b ? !1 : Lc.test(a)
    };
    Nc = function(a) {
        _.A(Number, "isFinite").call(Number, a) || Cc();
        return a
    };
    Oc = function(a) {
        return a
    };
    Pc = function(a) {
        if ("number" !== typeof a) throw Ec("int32");
        if (!_.A(Number, "isFinite").call(Number, a)) throw Ec("int32");
        return a | 0
    };
    Qc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return _.A(Number, "isFinite").call(Number, a) ? a | 0 : void 0
    };
    Rc = function(a) {
        if ("number" !== typeof a) throw Ec("uint32");
        if (!_.A(Number, "isFinite").call(Number, a)) throw Ec("uint32");
        return a >>> 0
    };
    _.Sc = function(a) {
        return null == a ? a : Rc(a)
    };
    Tc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return _.A(Number, "isFinite").call(Number, a) ? a >>> 0 : void 0
    };
    _.Xc = function(a, b) {
        b = !!b;
        if (!Mc(a)) throw Ec("int64");
        return "string" === typeof a ? Uc(a) : b ? Vc(a) : Wc(a)
    };
    Yc = function(a) {
        return null == a ? a : _.Xc(a)
    };
    ad = function(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    };
    bd = function(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    };
    cd = function(a) {
        if (0 > a) {
            Qb(a);
            var b = Sb(Nb, Ob);
            a = Number(b);
            return _.A(Number, "isSafeInteger").call(Number, a) ? a : b
        }
        if (ad(String(a))) return a;
        Qb(a);
        return 4294967296 * Ob + (Nb >>> 0)
    };
    Wc = function(a) {
        a = _.A(Math, "trunc").call(Math, a);
        if (!_.A(Number, "isSafeInteger").call(Number, a)) {
            Qb(a);
            var b = Nb,
                c = Ob;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    };
    dd = function(a) {
        a = _.A(Math, "trunc").call(Math, a);
        return 0 <= a && _.A(Number, "isSafeInteger").call(Number, a) ? a : cd(a)
    };
    Vc = function(a) {
        a = _.A(Math, "trunc").call(Math, a);
        if (_.A(Number, "isSafeInteger").call(Number, a)) a = String(a);
        else {
            var b = String(a);
            bd(b) ? a = b : (Qb(a), a = Ub())
        }
        return a
    };
    Uc = function(a) {
        var b = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, b)) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        bd(a) || (Vb(a), a = Ub());
        return a
    };
    ed = function(a) {
        var b = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, b) && 0 <= b) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        ad(a) || (Vb(a), a = Sb(Nb, Ob));
        return a
    };
    fd = function(a) {
        if (null == a) return a;
        if (Mc(a)) {
            var b;
            "number" === typeof a ? b = Wc(a) : b = Uc(a);
            return b
        }
    };
    gd = function(a, b) {
        b = void 0 === b ? !1 : b;
        if (null == a) return a;
        if (Mc(a)) return "string" === typeof a ? Uc(a) : b ? Vc(a) : Wc(a)
    };
    hd = function(a) {
        var b = !!b;
        if (!Mc(a)) throw Ec("uint64");
        "string" === typeof a ? a = ed(a) : b ? (a = _.A(Math, "trunc").call(Math, a), 0 <= a && _.A(Number, "isSafeInteger").call(Number, a) ? a = String(a) : (b = String(a), ad(b) ? a = b : (Qb(a), a = Sb(Nb, Ob)))) : a = dd(a);
        return a
    };
    id = function(a) {
        if ("string" !== typeof a) throw Error();
        return a
    };
    jd = function(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    };
    kd = function(a) {
        return null == a || "string" === typeof a ? a : void 0
    };
    nd = function(a, b, c, d) {
        if (null != a && "object" === typeof a && a.ng === ld) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? md(b) : new b : void 0;
        var e = c = Yb(a);
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && Zb(a, e);
        return new b(a)
    };
    md = function(a) {
        var b = a[od];
        if (b) return b;
        b = new a;
        gc(b.C);
        return a[od] = b
    };
    pd = function(a, b, c) {
        if (b) return Ic(a);
        var d;
        return null != (d = Kc(a)) ? d : c ? !1 : void 0
    };
    qd = function(a, b, c) {
        if (b) return id(a);
        var d;
        return null != (d = kd(a)) ? d : c ? "" : void 0
    };
    sd = function(a, b) {
        rd = b;
        a = new a(b);
        rd = void 0;
        return a
    };
    wd = function(a) {
        switch (typeof a) {
            case "boolean":
                return td || (td = [0, void 0, !0]);
            case "number":
                return 0 < a ? void 0 : 0 === a ? vd || (vd = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    };
    _.B = function(a, b, c) {
        null == a && (a = rd);
        rd = void 0;
        if (null == a) {
            var d = 96;
            c ? (a = [c], d |= 512) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = Yb(a);
            if (d & 64) return a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error();
            a: {
                c = d;
                if (d = a.length) {
                    var e = d - 1;
                    if (pc(a[e])) {
                        c |= 256;
                        b = e - (+!!(c & 512) - 1);
                        if (1024 <= b) throw Error();
                        d = c & -16760833 | (b & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, d - (+!!(c & 512) - 1));
                    if (1024 < b) throw Error();
                    d = c & -16760833 | (b & 1023) << 14
                } else d = c
            }
        }
        Zb(a, d);
        return a
    };
    xd = function(a) {
        return a
    };
    zd = function(a, b, c, d, e, f) {
        a = nd(a, d, c, f);
        e && (a = yd(a));
        return a
    };
    Ad = function(a) {
        return a
    };
    Bd = function(a) {
        return [a, this.get(a)]
    };
    Dd = function(a, b) {
        return Cd(b)
    };
    Cd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return Ed || !tc(a, void 0, 9999) ? a : void 0;
                    if (Ib(a)) return Db(a);
                    if (a instanceof qc) return Fd(a);
                    if (a instanceof Gd) return a = Hd(a), Id || 0 !== a.length ? a : void 0
                }
        }
        return a
    };
    Jd = function(a, b, c) {
        a = Wb(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    };
    Ld = function(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Yb(a) & 1 ? void 0 : f && Yb(a) & 2 ? a : Kd(a, b, c, void 0 !== d, e, f);
            else if (pc(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Ld(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    };
    Kd = function(a, b, c, d, e, f) {
        var g = d || c ? Yb(a) : 0;
        d = d ? !!(g & 32) : void 0;
        a = Wb(a);
        for (var h = 0; h < a.length; h++) a[h] = Ld(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    };
    Nd = function(a) {
        return Ld(a, Md, void 0, void 0, !1, !1)
    };
    Md = function(a) {
        return a.ng === ld ? a.toJSON() : a instanceof Gd ? Hd(a, Nd) : Cd(a)
    };
    Od = function(a, b, c) {
        c = void 0 === c ? jc : c;
        if (null != a) {
            if (Hb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Yb(a);
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Zb(a, (d | 34) & -12293), a) : Kd(a, Od, d & 4 ? jc : c, !0, !1, !0)
            }
            a.ng === ld ? (c = a.C, d = Pd(c), a = d & 2 ? a : sd(a.constructor, Qd(c, d, !0))) : a instanceof Gd && (c = gc(Rd(a, Od)), a = new Gd(c, a.tf, a.Ed, a.Vg));
            return a
        }
    };
    _.Sd = function(a) {
        var b = a.C;
        return sd(a.constructor, Qd(b, Pd(b), !1))
    };
    Qd = function(a, b, c) {
        var d = c || b & 2 ? jc : ic,
            e = !!(b & 32);
        a = Jd(a, b, function(f) {
            return Od(f, e, d)
        });
        bc(a, 32 | (c ? 2 : 0));
        return a
    };
    yd = function(a) {
        var b = a.C,
            c = Pd(b);
        return c & 2 ? sd(a.constructor, Qd(b, c, !1)) : a
    };
    _.Td = function(a) {
        var b = a.C,
            c = Pd(b);
        return c & 2 ? a : sd(a.constructor, Qd(b, c, !0))
    };
    Vd = function(a, b, c) {
        if (!(4 & b)) return !0;
        if (null == c) return !1;
        0 === c && (4096 & b || 8192 & b) && 5 > (a.constructor[Ud] = (a.constructor[Ud] | 0) + 1) && Cc();
        return 0 === c ? !1 : !(c & b)
    };
    Wd = function(a, b, c, d, e) {
        var f = kc(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && Zb(a, e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    };
    $d = function(a, b, c, d, e) {
        var f = b & 2,
            g = Xd(a, b, c, e);
        Array.isArray(g) || (g = Yd);
        var h = !(d & 2);
        d = !(d & 1);
        var k = !!(b & 32),
            l = Yb(g);
        0 !== l || !k || f || h ? l & 1 || (l |= 1, Zb(g, l)) : (l |= 33, Zb(g, l));
        f ? (a = !1, l & 2 || (gc(g), a = !!(4 & l)), (d || a) && Object.freeze(g)) : (f = !!(2 & l) || !!(2048 & l), d && f ? (g = Wb(g), d = 1, k && !h && (d |= 32), Zb(g, d), Wd(a, b, c, g, e)) : h && l & 32 && !f && Zd(g, 32));
        return g
    };
    be = function(a, b, c, d, e, f, g) {
        var h = a.C,
            k = Pd(h);
        d = 2 & k ? 1 : d;
        f = !!f;
        var l = $d(h, k, b, 1 | (f ? 2 : 0), e);
        k = Pd(h);
        var m = Yb(l),
            n = m,
            p = !!(2 & m),
            r = !!(4 & m),
            w = p && r;
        if (Vd(a, m, g)) {
            if (r || Object.isFrozen(l)) l = Wb(l), n = 0, m = ae(m, k, f), p = !!(2 & m), k = Wd(h, k, b, l, e);
            for (r = a = 0; a < l.length; a++) {
                var u = c(l[a]);
                null != u && (l[r++] = u)
            }
            r < a && (l.length = r);
            c = ac(m, 4096, !1);
            m = c = ac(c, 8192, !1);
            m = ac(m, 20, !0);
            g && (m = ac(m, g, !0))
        }
        w || ((g = 1 === d) && (m = ac(m, 2, !0)), m !== n && Zb(l, m), (g || p) && Object.freeze(l));
        2 === d && p && (l = Wb(l), m = ae(m, k, f), Zb(l, m), Wd(h, k, b, l, e));
        var x;
        f ? x = l : x = l;
        return x
    };
    de = function(a) {
        return sc(a, !0, !0)
    };
    ee = function(a) {
        return sc(a, !0, !1)
    };
    he = function() {
        var a;
        return null != (a = fe) ? a : fe = new Gd(gc([]), void 0, void 0, void 0, ge)
    };
    ie = function(a, b, c, d, e, f) {
        var g = b & 2;
        a: {
            var h = c,
                k = b & 2;c = !1;
            if (null == h) {
                if (k) {
                    a = he();
                    break a
                }
                h = []
            } else if (h.constructor === Gd) {
                if (0 == (h.ee & 2) || k) {
                    a = h;
                    break a
                }
                h = Rd(h)
            } else Array.isArray(h) ? c = !!(Yb(h) & 2) : h = [];
            if (k) {
                if (!h.length) {
                    a = he();
                    break a
                }
                c || (c = !0, gc(h))
            } else if (c) {
                c = !1;
                k = Wb(h);
                for (h = 0; h < k.length; h++) {
                    var l = k[h] = Wb(k[h]);
                    Array.isArray(l[1]) && (l[1] = gc(l[1]))
                }
                h = k
            }
            c || (Yb(h) & 64 ? Zd(h, 32) : 32 & b && hc(h));f = new Gd(h, e, qd, f);Wd(a, b, d, f, !1);a = f
        }
        if (null == a) return a;
        !g && e && (a.Hj = !0);
        return a
    };
    je = function(a, b, c) {
        a = a.C;
        var d = Pd(a);
        return ie(a, d, Xd(a, d, b), b, void 0, c)
    };
    ke = function(a, b, c) {
        a = a.C;
        var d = Pd(a);
        return ie(a, d, Xd(a, d, b), b, c)
    };
    _.le = function(a, b, c, d) {
        var e = a.C,
            f = Pd(e);
        uc(f);
        if (null == c) return Wd(e, f, b), a;
        var g = Yb(c),
            h = g,
            k = !!(2 & g) || Object.isFrozen(c),
            l = !k && !1;
        if (Vd(a, g))
            for (g = 21, k && (c = Wb(c), h = 0, g = ae(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (c = Wb(c), h = 0, g = ae(g, f, !0));
        g !== h && Zb(c, g);
        Wd(e, f, b, c);
        return a
    };
    _.me = function(a, b, c, d) {
        var e = a.C,
            f = Pd(e);
        uc(f);
        Wd(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    };
    ne = function(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != Xd(a, b, f) && (0 !== d && (b = Wd(a, b, d)), d = f)
        }
        return d
    };
    oe = function(a, b, c, d, e, f, g) {
        var h = 1 === e;
        e = 2 === e;
        f = !!f;
        var k = !!(2 & b) && e,
            l = $d(a, b, d, 3);
        b = Pd(a);
        var m = Yb(l),
            n = !!(2 & m),
            p = !!(4 & m),
            r = !!(32 & m),
            w = n && p || !!(2048 & m);
        if (!p) {
            var u = l,
                x = b,
                y;
            (y = !!(2 & m)) && (x = ac(x, 2, !0));
            for (var C = !y, D = !0, E = 0, J = 0; E < u.length; E++) {
                var M = nd(u[E], c, !1, x);
                if (M instanceof c) {
                    if (!y) {
                        var K = !!(Yb(M.C) & 2);
                        C && (C = !K);
                        D && (D = K)
                    }
                    u[J++] = M
                }
            }
            J < E && (u.length = J);
            m = ac(m, 4, !0);
            m = ac(m, 16, D);
            m = ac(m, 8, C);
            Zb(u, m);
            n && !k && (Object.freeze(l), w = !0)
        }
        c = m;
        k = !!(8 & m) || h && !l.length;
        if (g && !k) {
            w && (l = Wb(l), w = !1, c = 0, m = ae(m, b, f), b = Wd(a, b, d, l));
            g = l;
            k = m;
            for (n = 0; n < g.length; n++) u = g[n], m = yd(u), u !== m && (g[n] = m);
            k = ac(k, 8, !0);
            m = k = ac(k, 16, !g.length)
        }
        w || (h ? m = ac(m, !l.length || 16 & m && (!p || r) ? 2 : 2048, !0) : f || (m = ac(m, 32, !1)), m !== c && Zb(l, m), h && (Object.freeze(l), w = !0));
        e && w && (l = Wb(l), m = ae(m, b, f), Zb(l, m), Wd(a, b, d, l));
        return l
    };
    ae = function(a, b, c) {
        a = ac(a, 2, !!(2 & b));
        a = ac(a, 32, !!(32 & b) && c);
        return a = ac(a, 2048, !1)
    };
    pe = function(a, b, c, d) {
        a = a.C;
        var e = Pd(a);
        uc(e);
        b = oe(a, e, c, b, 2);
        c = null != d ? d : new c;
        b.push(c);
        Yb(c.C) & 2 ? Zd(b, 8) : Zd(b, 16);
        return c
    };
    qe = function(a, b) {
        return null != a ? a : b
    };
    se = function(a, b, c) {
        var d = a.constructor.aa,
            e = Pd(c ? a.C : b),
            f = kc(e),
            g = !1;
        if (d && Ed) {
            if (!c) {
                b = Wb(b);
                var h;
                if (b.length && pc(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            _.A(Object, "assign").call(Object, b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = Pd(a.C);
            a = kc(h);
            h = +!!(h & 512) - 1;
            for (var k, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l += h;
                    var n = f[l];
                    null == n ? f[l] = c ? Yd : fc() : c && n !== Yd && $b(n)
                } else k || (n = void 0, f.length && pc(n = f[f.length - 1]) ? k = n : f.push(k = {})), n = k[l], null == k[l] ? k[l] = c ? Yd : fc() : c && n !== Yd && $b(n)
        }
        k = b.length;
        if (!k) return b;
        var p;
        if (pc(f = b[k - 1])) {
            a: {
                var r = f;c = {};a = !1;
                for (var w in r)
                    if (Object.prototype.hasOwnProperty.call(r, w)) {
                        h = r[w];
                        if (Array.isArray(h)) {
                            m = h;
                            if (!re && tc(h, d, +w) || !Id && oc(h) && 0 === h.size) h = null;
                            h != m && (a = !0)
                        }
                        null != h ? c[w] = h : a = !0
                    }
                if (a) {
                    for (var u in c) {
                        r = c;
                        break a
                    }
                    r = null
                }
            }
            r != f && (p = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            w = k - 1;
            f = b[w];
            if (!(null == f || !re && tc(f, d, w - e) || !Id && oc(f) && 0 === f.size)) break;
            var x = !0
        }
        if (!p && !x) return b;
        var y;
        g ? y = b : y = Array.prototype.slice.call(b, 0, k);
        b = y;
        g && (b.length = k);
        r && b.push(r);
        return b
    };
    te = function(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        bc(b, 128);
        return sd(a, hc(b))
    };
    ue = function(a, b, c) {
        a[b] = c
    };
    ye = function(a) {
        var b = a[ve];
        if (!b) {
            var c = we(a);
            b = function(d, e) {
                return xe(d, e, c)
            };
            a[ve] = b
        }
        return b
    };
    ze = function(a) {
        return a.g
    };
    Ae = function(a, b) {
        var c, d, e = a.g;
        return function(f, g, h) {
            return e(f, g, h, d || (d = we(b).g), c || (c = ye(b)))
        }
    };
    we = function(a) {
        var b = a[Be];
        if (b) return b;
        b = a[Be] = {};
        var c = ze,
            d = Ae;
        var e = void 0 === e ? ue : e;
        b.g = wd(a[0]);
        var f = 0,
            g = a[++f];
        g && g.constructor === Object && (b.kk = g, g = a[++f], "function" === typeof g && (b.l = g, b.m = a[++f], g = a[++f]));
        for (var h = {}; Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];) {
            for (var k = 0; k < g.length; k++) h[g[k]] = g;
            g = a[++f]
        }
        for (k = 1; void 0 !== g;) {
            "number" === typeof g && (k += g, g = a[++f]);
            var l = void 0;
            if (g instanceof Ce) var m = g;
            else m = De, f--;
            if (m.ij) {
                g = a[++f];
                l = a;
                var n = f;
                "function" == typeof g && (g = g(), l[n] = g);
                l = g
            }
            g = a[++f];
            n = k + 1;
            "number" === typeof g && 0 > g && (n -= g, g = a[++f]);
            for (; k < n; k++) {
                var p = h[k];
                e(b, k, l ? d(m, l, p) : c(m, p))
            }
        }
        Ee in a && Be in a && (a.length = 0);
        return b
    };
    Ge = function(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.kk)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof Ce ? c : [Fe, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    var e = ye(c),
                        f = we(c).g;
                    c = (c = a.m) ? c(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };
    xe = function(a, b, c) {
        for (var d = Pd(a), e = +!!(d & 512) - 1, f = a.length, g = f + (d & 256 ? -1 : 0), h = d & 512 ? 1 : 0; h < g; h++) {
            var k = a[h];
            if (null != k) {
                var l = h - e,
                    m = Ge(c, l);
                m && m(b, k, l)
            }
        }
        if (d & 256) {
            a = a[f - 1];
            for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (d = +n, _.A(Number, "isNaN").call(Number, d) || (e = a[n], null != e && (f = Ge(c, d)) && f(b, e, d)))
        }
    };
    He = function(a) {
        return new Ce(a, !1)
    };
    Me = function(a, b, c) {
        a: if (null != b) {
            if (Mc(b)) {
                if ("string" === typeof b) {
                    b = Uc(b);
                    break a
                }
                if ("number" === typeof b) {
                    b = Wc(b);
                    break a
                }
            }
            b = void 0
        }null != b && ("string" === typeof b && Ie(b), null != b && (Je(a.g, 8 * c), "number" === typeof b ? (a = a.g, Qb(b), Ke(a, Nb, Ob)) : (c = Ie(b), Ke(a.g, c.m, c.g))))
    };
    Oe = function(a, b, c, d, e) {
        b = b instanceof _.F ? b.C : Array.isArray(b) ? _.B(b, d[0], d[1]) : void 0;
        if (null != b) {
            Je(a.g, 8 * c + 2);
            c = a.g.end();
            Ne(a, c);
            c.push(a.m);
            e(b, a);
            e = c.pop();
            for (e = a.m + a.g.length() - e; 127 < e;) c.push(e & 127 | 128), e >>>= 7, a.m++;
            c.push(e);
            a.m++
        }
    };
    Qe = function(a) {
        var b = Pe;
        Pe = void 0;
        if (!a) throw Error(b && b() || String(a));
    };
    Se = function(a) {
        return function() {
            var b = new Re;
            xe(this.C, b, we(a));
            Ne(b, b.g.end());
            for (var c = new Uint8Array(b.m), d = b.l, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.l = [c];
            return c
        }
    };
    Te = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = sd(a, hc(b))
            }
            return b
        }
    };
    Ue = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    _.G = function(a) {
        return _.Ye(Ze).m(a.g, a.defaultValue)
    };
    _.$e = function(a) {
        return _.Ye(Ze).l(a.g, a.defaultValue)
    };
    af = function(a) {
        return _.Ye(Ze).v(a.g, a.defaultValue)
    };
    bf = function(a) {
        return _.Ye(Ze).J(a.g, a.defaultValue)
    };
    cf = function(a) {
        var b = a.split(/\?|#/),
            c = /\?/.test(a) ? "?" + b[1] : "";
        return {
            path: b[0],
            Nd: c,
            hash: /#/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    };
    _.ef = function(a) {
        var b = _.Wa.apply(1, arguments);
        if (0 === b.length) return df(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return df(c)
    };
    _.ff = function(a, b) {
        a = cf(_.jb(a).toString());
        var c = a.Nd,
            d = c.length ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return df(a.path + c + a.hash)
    };
    jf = function(a) {
        return new _.gf(JSON.stringify(a).replace(/</g, "\\u003C"), hf)
    };
    kf = function(a) {
        a = void 0 === a ? _.t : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    mf = function(a) {
        return lf(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (_.H = b.toString(2), _.A(_.H, "padStart")).call(_.H, 8, "0")
        }).join("")
    };
    nf = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }; of = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };
    pf = function(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    qf = function(a, b) {
        var c = function(d) {
            var e = {};
            return [(e[d.Yc] = d.Nc, e)]
        };
        return JSON.stringify([a.filter(function(d) {
            return d.rc
        }).map(c), b.toJSON(), a.filter(function(d) {
            return !d.rc
        }).map(c)])
    };
    sf = function(a, b, c, d, e, f) {
        try {
            var g = a.g,
                h = _.rf("SCRIPT", g);
            h.async = !0;
            kb(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", function() {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", function() {
                0 < c ? sf(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (k) {
            f()
        }
    };
    uf = function(a, b, c, d) {
        c = void 0 === c ? function() {} : c;
        d = void 0 === d ? function() {} : d;
        sf(tf(a), b, 0, !1, c, d)
    };
    vf = function(a) {
        return a[_.A(_.v.Symbol, "iterator")]()
    };
    yf = function(a) {
        var b = wf(xf(a.location.href));
        a = b.get("fcconsent");
        b = b.get("fc");
        return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
    };
    zf = function(a) {
        var b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = wf(xf(a.location.href)).get("fctype")) && -1 !== b.indexOf(a) ? a : null
    };
    Af = function(a) {
        a && "function" == typeof a.ua && a.ua()
    };
    Df = function(a) {
        a = Bf(a.data.__fciReturn);
        return {
            payload: a,
            Cg: _.Cf(a, 1)
        }
    };
    Ff = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.rf("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && ha(a.google_image_requests, f);
                _.Ef(f, "load", g);
                _.Ef(f, "error", g)
            };
            _.lb(f, "load", g);
            _.lb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    Hf = function() {
        var a = Gf;
        return function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    Jf = function() {
        var a = If;
        return function(b) {
            return b instanceof a
        }
    };
    Lf = function(a) {
        return function(b) {
            if (!Kf(b)) return !1;
            for (var c = _.z(_.A(Object, "entries").call(Object, a)), d = c.next(); !d.done; d = c.next()) {
                var e = _.z(d.value);
                d = e.next().value;
                e = e.next().value;
                if (!(d in b)) {
                    if (!0 === e.In) continue;
                    return !1
                }
                if (!e(b[d])) return !1
            }
            return !0
        }
    };
    Nf = function() {
        return function(a) {
            return Array.isArray(a)
        }
    };
    Qf = function() {
        return function(a) {
            return Of(a) ? a.every(function(b) {
                return Pf(b)
            }) : !1
        }
    };
    Rf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Cg: b.__uspapiReturn.callId
        }
    };
    Sf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Cg: b.__gppReturn.callId
        }
    };
    Tf = function(a) {
        return !a || 1 === a.length && -1 === a[0]
    };
    Vf = function(a, b) {
        b = void 0 === b ? window : b;
        if (Uf(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    Wf = function(a) {
        return "null" !== a.origin
    };
    Yf = function(a, b, c) {
        b = Uf(b) && Wf(c) ? c.document.cookie : null;
        return null === b ? null : (new Xf({
            cookie: b
        })).get(a) || ""
    };
    Zf = function(a, b, c) {
        return b[a] || c
    };
    ag = function(a) {
        _.Ye($f).l(a)
    };
    _.bg = function() {
        return _.Ye($f).v()
    };
    cg = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.H = c.allowedFeatures(), _.A(_.H, "includes")).call(_.H, a))
    };
    dg = function(a, b, c) {
        return !!(a && "runAdAuction" in b && b.runAdAuction instanceof Function && cg("run-ad-auction", c))
    };
    eg = function(a, b) {
        return !!(a && "browsingTopics" in b && b.browsingTopics instanceof Function && cg("browsing-topics", b))
    };
    fg = function(a, b, c) {
        c = void 0 === c ? b.document : c;
        return !!(a && "sharedStorage" in b && b.sharedStorage && cg("shared-storage", c))
    };
    ig = function(a) {
        a = void 0 === a ? _.gg() : a;
        return function(b) {
            return _.hg(b + " + " + a) % 1E3
        }
    };
    kg = function(a) {
        _.Ye(jg).g(a)
    };
    og = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.t : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        lg(_.Ye($f), a);
        mg(b);
        ng(_.Ye(jg), b);
        _.Ye(Ze).g()
    };
    mg = function(a) {
        var b = _.Ye(Ze);
        b.m = function(c, d) {
            return Zf(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.l = function(c, d) {
            return Zf(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.v = function(c, d) {
            return Zf(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.J = function(c, d) {
            return Zf(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.g = function() {
            Zf(15, a, function() {})(2)
        }
    };
    sg = function(a, b, c, d) {
        var e = new _.pg,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.Ef(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (m) {}
            },
            h = qg(a);
        return h ? (_.lb(a, "message", g), f = c(h), e.promise) : (c = rg(a)) ? (f = String(Math.floor(2147483647 * _.gg())), _.lb(a, "message", g), b(c, f), e.promise) : null
    };
    tg = function(a) {
        return sg(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    ug = function(a) {
        return !!qg(a) || !!rg(a)
    };
    qg = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    rg = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    vg = function(a) {
        var b, c;
        return null != (c = (_.H = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.A(_.H, "find")).call(_.H, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    wg = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    xg = function(a, b, c) {
        var d, e;
        return null != (e = null != (d = null == b ? void 0 : b.get((void 0 === c ? 0 : c) ? wg(a) : a)) ? d : null == b ? void 0 : b.get(_.hg(a))) ? e : 0
    };
    Ag = function(a, b, c) {
        var d, e, f, g, h;
        return _.nb(function(k) {
            if (1 == k.g) return d = c ? a.filter(function(l) {
                return !l.Tb
            }) : a, k.yield(_.v.Promise.all(d.map(function(l) {
                return l.Ab.promise
            })), 2);
            if (a.length === d.length) return k.return();
            e = a.filter(function(l) {
                return l.Tb
            });
            if (_.G(yg)) {
                f = _.z(b);
                for (g = f.next(); !g.done; g = f.next()) h = g.value, zg(h);
                return k.yield(_.v.Promise.all(e.map(function(l) {
                    return l.Ab.promise
                })), 0)
            }
            return k.yield(_.v.Promise.race([_.v.Promise.all(e.map(function(l) {
                return l.Ab.promise
            })), new _.v.Promise(function(l) {
                return void setTimeout(l, c)
            })]), 0)
        })
    };
    Bg = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var e;
                b.googletag.queryIds = null != (e = b.googletag.queryIds) ? e : [];
                b.googletag.queryIds.push(c);
                500 < b.googletag.queryIds.length && b.googletag.queryIds.shift()
            }
        } catch (f) {}
    };
    _.Cg = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.Fg = function(a) {
        var b = _.Dg(a);
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    Gg = function(a, b, c) {
        b = void 0 === b ? 420 : b;
        return (a = _.Dg(a, void 0 === c ? !1 : c)) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    Hg = function(a) {
        return (a = _.Fg(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.Ig = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.Jg = function(a) {
        return _.Ig(a).clientHeight
    };
    _.Dg = function(a, b) {
        var c = _.Ig(a).clientWidth;
        return (void 0 === b ? 0 : b) ? c * _.Kg(a) : c
    };
    _.Lg = function(a, b) {
        var c = _.Ig(a);
        return b ? (a = _.Jg(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    };
    _.Mg = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    _.Ng = function(a) {
        var b = a.kf,
            c = a.ue,
            d = a.Re,
            e = a.lf,
            f = a.ve;
        a = a.Se;
        for (var g = [], h = 0; h < a; h++)
            for (var k = 0; k < d; k++) {
                var l = d - 1,
                    m = a - 1;
                g.push({
                    x: b + (0 === l ? 0 : k / l) * (c - b),
                    y: e + (0 === m ? 0 : h / m) * (f - e)
                })
            }
        return g
    };
    Og = function(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };
    _.Ug = function(a) {
        var b = a.ka,
            c = a.qg,
            d = a.Me,
            e = a.fh,
            f = a.Ja,
            g = a.Jj,
            h = a.mm;
        a = 0;
        try {
            a |= b !== b.top ? 512 : 0;
            var k = Math.min(b.screen.width || 0, b.screen.height || 0);
            a |= k ? 320 > k ? 8192 : 0 : 2048;
            a |= b.navigator && Pg(b.navigator.userAgent) ? 1048576 : 0;
            if (c) {
                k = a;
                var l = b.innerHeight;
                var m = ((void 0 === h ? 0 : h) ? _.Kg(b) * l : l) >= c;
                var n = k | (m ? 0 : 1024)
            } else n = a | (_.Cg(b) ? 0 : 8);
            a = n;
            a |= Gg(b, d, h);
            h || (a |= Hg(b))
        } catch (p) {
            a |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = _.Ng({
                    kf: 0,
                    ue: b.innerWidth,
                    Re: 3,
                    lf: 0,
                    ve: Math.min(Math.round(b.innerWidth / 320 * 50), Qg) + 15,
                    Se: 3
                });
                null != Rg(Sg(b, c), d) && (a |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, n = Math.min(Math.round(b.innerWidth / 320 * 50), Qg) + 15, m = _.Ng({
                    kf: 0,
                    ue: d,
                    Re: 3,
                    lf: e - n,
                    ve: e,
                    Se: 3
                }), 25 < n && m.push({
                    x: d - 25,
                    y: e - 25
                }), null != Rg(Sg(b, c), m) && (a |= 16777216)
        }
        g && null != _.Tg(b, void 0 === f ? null : f) && (a |= 16777216);
        return a
    };
    Pg = function(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    };
    _.Tg = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = _.Ng({
            kf: 0,
            ue: a.innerWidth,
            Re: 10,
            lf: c - 66,
            ve: c,
            Se: 10
        });
        return Rg(Sg(a, b), c)
    };
    Sg = function(a, b) {
        return new _.Vg(a, {
            Ch: Wg(a, void 0 === b ? null : b)
        })
    };
    Wg = function(a, b) {
        if (b = void 0 === b ? null : b) {
            var c = b;
            return function(d, e, f) {
                var g, h;
                _.Xg(c, "ach_evt", {
                    tn: d.tagName,
                    id: null != (g = d.getAttribute("id")) ? g : "",
                    cls: null != (h = d.getAttribute("class")) ? h : "",
                    ign: String(f),
                    pw: a.innerWidth,
                    ph: a.innerHeight,
                    x: e.x,
                    y: e.y
                }, !0, 1)
            }
        }
    };
    _.Yg = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    };
    _.Zg = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    $g = function(a, b) {
        b = void 0 === b ? _.t : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    _.ah = function(a) {
        a = void 0 === a ? _.t : a;
        var b = Math.min($g("domLoading", a) || Infinity, $g("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max($g("responseEnd", a), $g("navigationStart", a)) : b
    };
    ch = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.bh(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    eh = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.dh(d, function(e) {
                    return !_.A(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = ch(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    gh = function(a, b) {
        return null !== _.fh(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && b.has(c)
        }, !0)
    };
    hh = function(a, b) {
        return _.fh(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position
        }, !0)
    };
    ih = function(a) {
        return Math.round(10 * Math.round(a / 10))
    };
    jh = function(a) {
        return a.position + "-" + ih(a.ga) + "x" + ih(a.ma) + "-" + ih(a.scrollY + a.Qc) + "Y"
    };
    kh = function(a) {
        return "f-" + jh({
            position: a.position,
            Qc: a.Qc,
            scrollY: 0,
            ga: a.ga,
            ma: a.ma
        })
    };
    lh = function(a, b) {
        a = Math.min(null != a ? a : Infinity, null != b ? b : Infinity);
        return Infinity !== a ? a : 0
    };
    nh = function(a, b, c) {
        var d = _.mh(c.ka).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.min(e.bottom + 10, c.ma),
                    g = Math.max(e.left - 10, 0),
                    h = Math.min(e.right + 10, c.ga),
                    k = .3 * c.ga;
                for (e = Math.max(e.top - 10, 0); e <= f; e += 10) {
                    if (0 < h && g < k) {
                        var l = kh({
                            position: "left",
                            Qc: e,
                            ga: c.ga,
                            ma: c.ma
                        });
                        b.set(l, lh(b.get(l), g))
                    }
                    if (g < c.ga && h > c.ga - k) {
                        l = kh({
                            position: "right",
                            Qc: e,
                            ga: c.ga,
                            ma: c.ma
                        });
                        var m = c.ga - h;
                        b.set(l, lh(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    };
    _.ph = function(a) {
        if (1200 > a.ga || 650 > a.ma) return null;
        var b = _.mh(a.ka).sideRailAvailableSpace;
        if (!a.Th) {
            var c = {
                    ka: a.ka,
                    ga: a.ga,
                    ma: a.ma,
                    hc: a.hc
                },
                d = "f-" + ih(c.ga) + "x" + ih(c.ma);
            if (!b.has(d)) {
                b.set(d, 0);
                _.mh(c.ka).sideRailProcessedFixedElements.clear();
                d = new _.v.Set([].concat(_.oh(_.A(Array, "from").call(Array, c.ka.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]"))), _.oh(c.hc)));
                for (var e = c.ka, f = [], g = _.z(e.document.querySelectorAll("*")), h = g.next(); !h.done; h = g.next()) {
                    h = h.value;
                    var k = e.getComputedStyle(h, null);
                    "fixed" === k.position && "none" !== k.display && "hidden" !== k.visibility && f.push(h)
                }
                e = _.z(f);
                for (f = e.next(); !f.done; f = e.next()) f = f.value, gh(f, d) || nh(f, b, c)
            }
        }
        c = [];
        e = .9 * a.ma;
        f = _.Mg(a.ka);
        g = d = (a.ma - e) / 2;
        h = e / 7;
        for (k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            var n = g;
            var p = a.position,
                r = {
                    ka: a.ka,
                    ga: a.ga,
                    ma: a.ma,
                    hc: a.hc
                },
                w = kh({
                    position: p,
                    Qc: n,
                    ga: r.ga,
                    ma: r.ma
                }),
                u = jh({
                    position: p,
                    Qc: n,
                    scrollY: f,
                    ga: r.ga,
                    ma: r.ma
                });
            if (!b.has(u)) {
                var x = "left" === p ? 20 : r.ga - 20,
                    y = x;
                p = .3 * r.ga / 5 * ("left" === p ? 1 : -1);
                for (var C = 0; 6 > C; C++) {
                    var D = Og(r.ka.document, {
                            x: Math.round(y),
                            y: Math.round(n)
                        }),
                        E = gh(D, r.hc),
                        J = hh(D, r.ka);
                    if (!E && null !== J) {
                        nh(J, b, r);
                        b.delete(u);
                        break
                    }
                    E || (E = D.offsetHeight >= .25 * r.ma, E = D.offsetWidth >= .9 * r.ga && E);
                    if (E) b.set(u, Math.round(Math.abs(y - x) + 20));
                    else if (y !== x) y -= p, p /= 2;
                    else {
                        b.set(u, 0);
                        break
                    }
                    y += p
                }
            }
            n = lh(b.get(w), b.get(u));
            m.call(l, n);
            g += h
        }
        b = a.Ji;
        f = a.position;
        e = Math.round(e / 8);
        d = Math.round(d);
        g = a.minWidth;
        a = a.minHeight;
        l = [];
        h = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (k = 0; k < c.length; k++) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[k];) l.pop();
            h[k] = 0 === l.length ? 0 : l[l.length - 1] + 1;
            l.push(k)
        }
        l = [];
        m = c.length - 1;
        k = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (n = m; 0 <= n; n--) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[n];) l.pop();
            k[n] = 0 === l.length ? m : l[l.length - 1] - 1;
            l.push(n)
        }
        l = null;
        for (m = 0; m < c.length; m++)
            if (n = {
                    position: f,
                    width: Math.round(c[m]),
                    height: Math.round((k[m] - h[m] + 1) * e),
                    offsetY: d + h[m] * e
                }, r = n.width >= g && n.height >= a, 0 === b && r) {
                l = n;
                break
            } else 1 === b && r && (!l || n.width * n.height > l.width * l.height) && (l = n);
        return l
    };
    qh = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    rh = function() {
        var a = Date.now();
        return _.A(Number, "isFinite").call(Number, a) ? Math.round(a) : 0
    };
    xh = function(a) {
        var b = new sh;
        var c = rh();
        b = _.th(b, 1, c);
        b = _.th(b, 2, a.pvsid);
        b = _.uh(b, 3, a.wb || a.ab);
        c = _.bg();
        b = _.le(b, 4, c, Pc);
        b = _.th(b, 5, a.Zh);
        a = _.uh(b, 12, a.Nf);
        var d;
        if (b = null == (d = _.v.globalThis.performance) ? void 0 : d.memory) {
            d = new vh;
            try {
                _.th(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.th(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.th(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.wh(a, 10, d);
        return a
    };
    Eh = function(a) {
        var b = _.ah();
        if (a.yc) {
            var c = a.Ga,
                d = c.xc,
                e = xh(a),
                f = new yh;
            b = _.th(f, 2, b);
            f = new zh;
            f = _.Ah(f, 1, a.yc);
            f = _.Bh(f, 2, a.Zh);
            f = _.Ah(f, 3, a.Mi);
            f = _.Bh(f, 4, a.Yh);
            f = _.Ah(f, 5, a.Mg);
            a = _.Bh(f, 6, a.Sf);
            a = _.wh(b, 3, a);
            e = _.Ch(e, 6, Dh, a);
            d.call(c, e)
        }
    };
    Hh = function(a) {
        if (!a.yc) return function() {};
        var b = rh();
        a.Ga.xc(Fh(xh(a)));
        return function() {
            var c = a.Ga,
                d = c.xc,
                e = xh(a);
            var f = new Gh;
            var g = rh() - b;
            f = _.th(f, 1, g);
            e = _.Ch(e, 14, Dh, f);
            return void d.call(c, e)
        }
    };
    Kh = function(a) {
        var b = void 0 === b ? _.gg() : b;
        a.Ol && (.25 > b ? (Ih(a.Ga, {
            value: 1,
            uf: "ONE"
        }), Jh(a.Ga, {
            value: b,
            nf: "A"
        })) : .5 > b ? (Ih(a.Ga, {
            value: 2,
            uf: "TWO"
        }), Jh(a.Ga, {
            value: b,
            nf: "B"
        })) : .75 > b ? (Ih(a.Ga, {
            value: 3,
            uf: "THREE"
        }), Jh(a.Ga, {
            value: b,
            nf: "C"
        })) : (Ih(a.Ga, {
            value: 6,
            uf: "SIX"
        }), Jh(a.Ga, {
            value: b,
            nf: "D"
        })))
    };
    L = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Wa.apply(0, arguments),
                f = Lh(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.yc && a.Mi) {
                    var h = a.Ga,
                        k = h.xc,
                        l = xh(a);
                    var m = _.th(l, 5, a.Yh);
                    var n = new Mh;
                    var p = _.I(n, 1, b);
                    var r = _.Bh(p, 2, g);
                    var w = _.Ch(m, 9, Dh, r);
                    k.call(h, w)
                }
            } catch (u) {}
            return f
        }
    };
    Lh = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Wa.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.Ye(Nh);
            try {
                var l = _.G(Oh);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (m) {
                try {
                    if (g) Ph.call(this, a, 110, m);
                    else if (Ph.call(this, a, b, m), !d) throw m;
                } catch (n) {
                    if (_.Qh(h), !g && !d) throw m;
                }
            }
            return f
        }
    };
    Rh = function(a, b, c, d) {
        return Lh(a, b, c, void 0 === d ? !1 : d)()
    };
    Ph = function(a, b, c) {
        if (a.Mg) {
            c = _.Sh(c) ? c.error : c;
            var d = new Th,
                e = new Uh;
            try {
                var f = _.Wh(window);
                _.th(e, 1, f)
            } catch (p) {}
            try {
                var g = _.bg();
                _.le(e, 2, g, Pc)
            } catch (p) {}
            try {
                _.uh(e, 3, window.document.URL)
            } catch (p) {}
            f = _.wh(d, 2, e);
            g = new Yh;
            b = _.I(g, 1, b);
            try {
                var h = Pf(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                _.uh(b, 2, h)
            } catch (p) {}
            try {
                var k = Pf(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                _.uh(b, 3, k)
            } catch (p) {}
            try {
                var l = Pf(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && _.Zh(b, 4, l.split(/\n\s*/))
            } catch (p) {}
            h = _.wh(f, 1, b);
            k = new $h;
            try {
                _.uh(k, 1, a.wb || a.ab)
            } catch (p) {}
            try {
                var m = ai();
                _.Bh(k, 2, m)
            } catch (p) {}
            try {
                var n = [].concat(_.oh(_.A(bi, "keys").call(bi)));
                _.Zh(k, 3, n)
            } catch (p) {}
            _.Ch(h, 4, ci, k);
            _.th(h, 5, a.Sf);
            a.Ga.Kl(h)
        }
    };
    hi = function(a, b, c) {
        var d, e;
        return null != (e = null == (d = _.A(a, "find").call(a, function(f) {
            f = _.di(f, ei, 1);
            return fi(f, 1) <= b && fi(f, 2) <= c
        })) ? void 0 : _.gi(d, ei, 2)) ? e : null
    };
    ji = function(a, b, c) {
        var d;
        "number" === typeof b && "number" === typeof c && _.gi(a, ii, 6).length ? d = hi(_.gi(a, ii, 6), b, c) : d = _.gi(a, ei, 5);
        return d
    };
    li = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = ki(!1, b), c = ji(a, b.width, b.height));
        null != c || (c = ji(a));
        return null == c ? [] : c.map(function(d) {
            return _.N(d, 3) ? "fluid" : [fi(d, 1), fi(d, 2)]
        })
    };
    mi = function(a) {
        var b = [],
            c = !1;
        a = _.z(li(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    ni = function(a) {
        return 0 !== a && 1 !== a && !(_.H = [8, 9], _.A(_.H, "includes")).call(_.H, a)
    };
    _.qi = function(a) {
        _.Ye(oi).g = !0;
        return pi[a]
    };
    si = function(a) {
        var b = a.document;
        return ri(a) ? b.URL : b.referrer
    };
    vi = function(a) {
        try {
            return ti(a, window.top)
        } catch (b) {
            return new _.ui(-12245933, -12245933)
        }
    };
    Ei = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.Bi(Ci, a), a = new _.Di(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    Hi = function(a, b) {
        for (var c = {}, d = _.z(_.A(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = _.Sd(b[e]),
                g = _.Ye(Fi),
                h = g.g.get(e);
            null == h ? h = ++_.Ye(Nh).l : g.g.delete(e);
            _.Gi(f, 20, _.Sc(h));
            c[e] = f
        }
        return {
            W: _.Sd(a),
            R: c
        }
    };
    Ji = function() {
        for (var a = "", b = _.z(Ii()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    Ii = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    Qi = function(a, b, c, d) {
        var e = Ki(b, a) || Li(b, a);
        if (!e) return null;
        var f = vi(e),
            g = e === Li(b, a),
            h = Mi(function() {
                var p = g ? Li(b, a) : e;
                return p && Ni(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = li(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min(null != (m = Oi(k("padding-top"))) ? m : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min(null != (n = Oi(k("padding-left"))) ? n : 0, d))
            }
        }
        return f && Pi(e) ? f : new _.ui(-12245933, -12245933)
    };
    Ri = function(a, b, c, d) {
        var e = Li(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = Qi(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    Si = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    Ti = function(a) {
        return Si(a) + "__container__"
    };
    Ki = function(a, b) {
        var c;
        return (null == (c = Li(a, b)) ? void 0 : c.querySelector('[id="' + Ti(a) + '"]')) || null
    };
    Ui = function(a, b) {
        var c, d;
        return null != (d = null == (c = Ki(a, b)) ? void 0 : c.querySelector('iframe[id="' + Si(a) + '"]')) ? d : null
    };
    Li = function(a, b) {
        b = void 0 === b ? document : b;
        return Vi().l.get(a) || b.getElementById(a.getDomId())
    };
    Wi = function(a) {
        return Math.round(Number(Oi(a)))
    };
    Xi = function(a) {
        var b = a.parentElement;
        return !b || 1 >= b.children.length ? !1 : _.A(Array, "from").call(Array, b.children).some(function(c) {
            return c !== a && !(_.H = ["script", "style"], _.A(_.H, "includes")).call(_.H, c.tagName.toLowerCase())
        })
    };
    Zi = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.Yi(a, c), a = a.parentElement
    };
    $i = function(a, b, c, d, e) {
        _.Yi(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.Yi(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.Yi(a, f)), !0) : !1
    };
    bj = function(a, b, c, d, e, f, g, h, k, l) {
        window.setTimeout(function() {
            var m = mi(d);
            if (window.IntersectionObserver) {
                var n, p = null != (n = Ui(c, b)) ? n : Li(c, b);
                m = aj(a, b, c, e, f, g, m, h, k, l, p);
                (new window.IntersectionObserver(m, {
                    threshold: .98
                })).observe(p)
            }
        }, 500)
    };
    aj = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window.location && "#flexibleAdSlotTest" === window.location.hash ? 1 : _.$e(cj);
        return Lh(a, 459, function(p, r) {
            (p = null == p ? void 0 : p[0]) && dj(a, b, c, d, e, f, g, h, k, l, r, m, p, n)
        })
    };
    dj = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        var w = p.boundingClientRect,
            u = p.intersectionRatio,
            x = window.innerWidth,
            y = w.left,
            C = w.right,
            D = 0 > y + 2,
            E = 0 < C - (x + 2);
        (.98 <= u || D || E) && ej(k, function(J) {
            m.unobserve(n);
            var M = D || E;
            var K = new fj;
            gj(n, M) && K.set(10);
            if (void 0 !== h && Xi(n)) {
                var X, ba = null == (X = Li(c, b)) ? void 0 : X.parentElement,
                    la;
                X = ba ? null == (la = Ni(ba, window)) ? void 0 : la.width : void 0;
                h !== X && K.set(16)
            }
            M ? (K.set(8), M = hj(K)) : M = ij(b, c, u, K);
            la = jj(c, n, f);
            K = la.Nk;
            la = la.Qk;
            kj(J, a);
            lj(J, "qid", l);
            lj(J, "iu", c.getAdUnitPath());
            lj(J, "e", String(M));
            D && lj(J, "ofl", String(y));
            E && lj(J, "ofr", String(C - x));
            lj(J, "ret", e + "x" + f);
            lj(J, "req", g);
            lj(J, "bm", String(d));
            lj(J, "efh", Number(K));
            lj(J, "stk", Number(la));
            lj(J, "ifi", mj(window))
        }, r)
    };
    ij = function(a, b, c, d) {
        var e = Ui(b, a) || Li(b, a);
        try {
            var f = e.getBoundingClientRect(),
                g = f.left,
                h = f.top,
                k = f.width,
                l = f.height,
                m = Li(b, a),
                n = Ni(m, window);
            if ("hidden" === n.visibility || "none" === n.display) return hj(d);
            var p = Wi(n.getPropertyValue("border-top-width") || 0) + 1;
            b = g + k;
            f = h + l;
            c = (1 - c) * l;
            var r = a.elementsFromPoint(g + p + 2, h + c + p);
            var w = a.elementsFromPoint(b - p - 2, h + c + p);
            var u = a.elementsFromPoint(b - p - 2, f - c - p);
            var x = a.elementsFromPoint(g + p + 2, f - c - p);
            var y = a.elementsFromPoint(b / 2, f - c - p)
        } catch (D) {
            return d.set(1), hj(d)
        }
        if (!(r && r.length && w && w.length && u && u.length && x && x.length && y && y.length)) return d.set(7), hj(d);
        a = function(D, E) {
            for (var J = !1, M = 0; M < D.length; M++) {
                var K = D[M];
                if (J) {
                    var X = Ni(K, window);
                    if ("hidden" !== X.visibility && !nj(K) && !C(e, K)) {
                        d.set(E);
                        "absolute" === X.position && d.set(11);
                        break
                    }
                } else e === K && (J = !0)
            }
        };
        oj(e) && d.set(9);
        var C = function(D, E) {
            return pj(D, E) || pj(E, D)
        };
        g = r[0];
        e === g || C(e, g) || nj(g) || d.set(2);
        g = w[0];
        e === g || C(e, g) || nj(g) || d.set(3);
        g = u[0];
        e === g || C(e, g) || nj(g) || d.set(4);
        g = x[0];
        e === g || C(e, g) || nj(g) || d.set(5);
        if (nj(e)) return hj(d);
        a(r, 12);
        a(w, 13);
        a(u, 14);
        a(x, 15);
        a(y, 6);
        return hj(d)
    };
    gj = function(a, b) {
        var c = !1,
            d = !1;
        return qj(a, function(e, f) {
            d = d || "scroll" === e.overflowX || "auto" === e.overflowX;
            c = c || "flex" === e.display;
            return b && c && d || "listbox" === f.role
        })
    };
    jj = function(a, b, c) {
        var d = (a = Li(a)) && Ni(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        rj(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = sj(k, _.t, -1, -1);
                else {
                    l = l && l.height;
                    var m = (l && _.A(l, "endsWith").call(l, "px") ? Wi(l) : 0) >= c;
                    !l || m || "string" === typeof l && _.A(tj, "includes").call(tj, l) || (e = !1)
                }
            f || (k = Ni(k, _.t), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            Nk: e,
            Qk: f
        }
    };
    sj = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.A(tj, "includes").call(tj, e.height) || (null == e ? 0 : e.maxHeight) && !_.A(uj, "includes").call(uj, e.maxHeight) || vj(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.A(tj, "includes").call(tj, g) || !!f && !_.A(uj, "includes").call(uj, f)
        }, c, d) ? !1 : !0
    };
    vj = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (D) {
                    if (15 == D.code) throw D.styleSheet = k, D;
                }
                h = l
            } catch (D) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var m = h[l],
                        n, p = c;
                    if (!(n = f.call(a, m.selectorText) && p(m))) a: {
                        var r = void 0;p = a;
                        var w = c,
                            u = e,
                            x = null != (r = m.cssRules) ? r : [];
                        for (r = 0; r < Math.min(x.length, u); r++) {
                            var y = x[r],
                                C = w;
                            if (f.call(p, y.selectorText) && C(y)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (D) {}
        }
        return !1
    };
    nj = function(a) {
        return qj(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    oj = function(a) {
        return qj(a, function(b) {
            var c;
            return (_.H = ["left", "right"], _.A(_.H, "includes")).call(_.H, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    wj = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    zj = function(a) {
        a = xj(a);
        return _.yj(a)
    };
    xj = function(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a
    };
    Cj = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = Aj.g();
        0 === e.g && (e.g = .001 > Math.random() ? 2 : 1);
        2 === e.g && (e = {}, Bj(_.A(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(_.Wh(window)), e.em = c, e.lid = b, e.eids = _.bg().join(), e), d), "esp"))
    };
    Dj = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.v.Promise(function(c) {
            var d = function() {
                c(b());
                _.Ef(a, "load", d)
            };
            _.lb(a, "load", d)
        })
    };
    Ej = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    Hj = function(a, b) {
        return _.gi(a, Fj, 2).some(function(c) {
            return _.Gj(c, 1) === b && null != _.Gj(c, 2)
        })
    };
    Ij = function(a, b) {
        return _.gi(a, Fj, 2).some(function(c) {
            return _.Gj(c, 1) === b && null != _.Gj(c, 2)
        })
    };
    Nj = function(a, b, c, d) {
        if (b)
            for (var e = _.z(Ej(b)), f = e.next(), g = {}; !f.done; g = {
                    nc: g.nc
                }, f = e.next())
                if (g.nc = f.value, (f = Jj().get(g.nc, b).zc) && !Ij(a, g.nc)) {
                    var h = Kj(f);
                    if (2 !== h && 3 !== h) {
                        h = !1;
                        if (c) {
                            var k = /^(\d+)$/.exec(g.nc);
                            if (k && !(h = _.A(c.split(","), "includes").call(c.split(","), k[1]))) continue;
                            if (!h && !c.split(",").some(function(l) {
                                    return function(m) {
                                        var n;
                                        return null == d ? void 0 : null == (n = d.get(m)) ? void 0 : n.has(l.nc)
                                    }
                                }(g))) continue
                        }
                        Lj(f, 9, h);
                        h = _.Gj(f, 2);
                        Mj(a, 2, Fj, f);
                        f = {};
                        Cj(19, g.nc, null, (f.hs = h ? "1" : "0", f))
                    }
                }
    };
    Oj = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    Zj = function(a, b, c, d, e) {
        var f, g, h, k, l, m, n, p, r, w, u, x, y;
        return _.nb(function(C) {
            return 1 == C.g ? (f = new Pj, g = new Qj(a, c, e), O(f, g), O(f, new Rj(g.o, void 0, d, e)), h = new Sj(g.j, e), O(f, h), k = new Tj(h.j, e), O(f, k), l = new Uj(b, k.j, e), O(f, l), O(f, new Rj(l.o, void 0, d, e)), m = new Vj(l.j, l.F, 300, 1E3, e), O(f, m), O(f, new Rj(m.j, void 0, d, e)), n = new Wj(e), O(f, n), p = new Xj(n.output, k.o, e), O(f, p), r = new Uj(b, p.j, e), O(f, r), w = new Rj(r.j, void 0, d, e), O(f, w), Yj(f), y = a, C.yield(m.j.promise, 2)) : C.return({
                id: y,
                collectorGeneratedData: null != (x = null == (u = C.m) ? void 0 : _.Gj(u, 2)) ? x : null
            })
        })
    };
    fk = function(a, b, c, d) {
        var e = {};
        e = void 0 === e ? ak : e;
        bk() !== ck(window) ? Cj(16, "") : dk(a, "encryptedSignalProviders", c) && dk(a, "secureSignalProviders", c) || (Cj(38, ""), ek(a, "encryptedSignalProviders", b, e, c, d), ek(a, "secureSignalProviders", b, e, c, function() {}))
    };
    dk = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    ek = function(a, b, c, d, e, f) {
        var g, h = new gk(null != (g = a[b]) ? g : [], c, "secureSignalProviders" === b, f, d);
        a[b] = new hk(h);
        h.addErrorHandler(e)
    };
    kk = function(a, b) {
        var c = new Pj,
            d = new Wj(b);
        a = new ik(d.output, a, b);
        jk(c, [d, a]);
        Yj(c)
    };
    ok = function(a, b, c, d, e) {
        var f = b.toString();
        if (lk.has(f)) return null;
        lk.add(f);
        f = new Pj;
        a = new Qj(a, c, e);
        var g = new Rj(a.o, c, d, e),
            h = new mk(a.j, e),
            k = new Sj(h.j, e);
        b = new nk(k.j, b, e);
        c = new Rj(b.j, c, d, e);
        jk(f, [a, g, h, k, b, c]);
        Yj(f);
        return f
    };
    qk = function(a, b, c) {
        c = void 0 === c ? pk : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.lb(a, "load", function() {
            return void c(a, b)
        }))
    };
    rk = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    sk = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    uk = function(a) {
        if (a === a.top || _.tk(a.top)) return _.v.Promise.resolve({
            status: 4
        });
        var b = rk(a);
        if (!b) return _.v.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && sk(a.document.referrer)) return _.v.Promise.resolve({
            status: 3
        });
        var c = new _.pg;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                te: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    yk = function(a, b) {
        var c = vk(a);
        return c.messageChannelSendRequestFn ? _.v.Promise.resolve(c.messageChannelSendRequestFn) : new _.v.Promise(function(d) {
            function e(k) {
                return h.g(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.rf("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            b && (f.credentialless = !0);
            f.src = _.jb(wk).toString();
            var g = (new URL(wk.toString())).origin,
                h = xk({
                    destination: a,
                    mb: f,
                    origin: g,
                    tb: "goog:gRpYw:doubleclick"
                });
            h.g("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    Hk = function(a, b, c, d) {
        var e = {
            skipTopicsObservation: _.G(zk),
            includeBuyerTopics: _.G(Ak)
        };
        e = void 0 === e ? {} : e;
        var f = Bk(d),
            g = f.ke,
            h = f.je;
        b = vk(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && va(k, g)));
            else if (Hf()(k)) l || (l = k !== g);
            else return c.sb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var m = new Ck;
                var n = _.Dk(m, 2, _.Yg());
                k instanceof Uint8Array ? Ek(n, 1, Fk, sc(k, !1, !1)) : Ek(n, 3, Fk, null == k ? k : Nc(k));
                d.setItem("goog:cached:topics", Gk(n))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = a);
        return g && !h ? _.v.Promise.resolve(g) : b.getTopicsPromise
    };
    Bk = function(a) {
        if (!a) return {
            ke: null,
            je: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                ke: null,
                je: !0
            };
            var c = Ik(b),
                d = Jk(c, Fk);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    e = Kk(Lk(c, Mk(c, Fk, 1)));
                    break;
                case 3:
                    e = _.Nk(c, Mk(c, Fk, 3), 0);
                    break;
                default:
                    _.eb(d)
            }
            var f = _.Cf(c, 2) + 6048E5 < _.Yg();
            return {
                ke: e,
                je: f
            }
        } catch (g) {
            return {
                ke: null,
                je: !0
            }
        }
    };
    vk = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    Qk = function(a) {
        if (Na()) {
            var b = a.document.documentElement.lang;
            Ok(a) ? Pk(_.Wh(a), !0, "", b) : (new MutationObserver(function(c, d) {
                Ok(a) && (Pk(_.Wh(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    Ok = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    Pk = function(a, b, c, d) {
        Bj({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    Sk = function(a) {
        var b = "";
        Rk(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    Uk = function(a) {
        var b = Tk(a, 500, 300);
        var c = a.navigator;
        var d = c.userAgent;
        var e = c.platform;
        c = c.product;
        !/Win|Mac|Linux|iPad|iPod|iPhone/.test(e) && /^Opera/.test(d) ? d = !1 : /Win/.test(e) && /Trident/.test(d) && 11 <= a.document.documentMode ? d = !0 : (a = (/WebKit\/(\d+)/.exec(d) || [0, 0])[1], e = (/rv:(\d+\.\d+)/.exec(d) || [0, 0])[1], d = !a && "Gecko" === c && 27 <= e && !/ rv: 1\.8([^.] |\.0) /.test(d) || 536 <= a ? !0 : !1);
        return d && !b
    };
    Xk = function(a, b) {
        var c = Vk.get(a);
        c || (b = c = b(), Wk.set(b, a), Vk.set(a, b));
        return c
    };
    P = function(a) {
        return function() {
            return new Yk(a, [].concat(_.oh(_.Wa.apply(0, arguments))))
        }
    };
    Zk = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Zk(b) : String(b)
        }).join(", ") + "]"
    };
    $k = function(a, b) {
        b = Zk(b);
        b = b.substring(1, b.length - 1);
        return new Yk(96, [a, b])
    };
    al = function(a) {
        return (_.H = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable gameManualInterstitialSlotReady gameManualInterstitialSlotClosed".split(" "), _.A(_.H, "includes")).call(_.H, a) ? a : null
    };
    cl = function(a, b, c) {
        return Xk(c, function() {
            return new bl(a, b, c)
        })
    };
    el = function(a, b, c) {
        return Xk(c, function() {
            return new dl(a, b, c)
        })
    };
    fl = function(a, b, c, d) {
        "string" === typeof a ? b.setClickUrl(a) : Q(d, $k("Slot.setClickUrl", [a]), c)
    };
    nl = function(a, b, c, d, e) {
        if ("string" !== typeof a || gl(a)) Q(e, $k("Slot.setTargeting", [a, b]), c);
        else {
            var f = [];
            Array.isArray(b) ? f = b : _.ta(b) ? f = _.A(Array, "from").call(Array, b) : b && (f = [b]);
            f = f.map(String);
            (b = (_.H = hl(d), _.A(_.H, "find")).call(_.H, function(g) {
                return _.Gj(g, 1) === a
            })) ? il(b, f): (b = il(jl(new ll, a), f), Mj(d, 9, ll, b));
            e.info(ml(a, f.join(), d.getAdUnitPath()), c)
        }
    };
    ol = function(a, b, c, d) {
        if (null != a && "object" === typeof a)
            for (var e = _.z(_.A(Object, "keys").call(Object, a)), f = e.next(); !f.done; f = e.next()) f = f.value, nl(f, a[f], b, c, d);
        else d.error($k("Slot.updateTargetingFromMap", [a]), b)
    };
    ql = function(a, b, c, d) {
        return "string" !== typeof a ? (Q(d, $k("Slot.getTargeting", [a]), b), []) : (b = (_.H = hl(c), _.A(_.H, "find")).call(_.H, function(e) {
            return _.Gj(e, 1) === a
        })) ? pl(b).slice() : []
    };
    rl = function(a) {
        return hl(a).map(function(b) {
            return _.R(b, 1)
        })
    };
    wl = function(a, b, c, d) {
        if (void 0 === a) _.Gi(c, 9), d.info(sl(b.getAdUnitPath()), b);
        else {
            var e = hl(c),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.Gj(g, 1) === a
                });
            0 > f ? Q(d, tl(a, b.getAdUnitPath()), b) : (e.splice(f, 1), _.ul(c, 9, e), d.info(vl(a, b.getAdUnitPath()), b))
        }
    };
    yl = function(a, b, c) {
        return Xk(c, function() {
            return new xl(a, b, c, c.g)
        })
    };
    zl = function(a) {
        return _.A(Object, "assign").call(Object, {}, a, _.A(Object, "fromEntries").call(Object, _.A(Object, "entries").call(Object, a).map(function(b) {
            b = _.z(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    Dl = function() {
        var a = {},
            b = zl(Al);
        a.OutOfPageFormat = b;
        b = zl(Bl);
        a.TrafficSource = b;
        b = zl(Cl);
        a.Taxonomy = b;
        return a
    };
    Hl = function(a, b, c, d, e) {
        if ("string" === typeof a && a.length && void 0 !== El()[a] && "string" === typeof b) {
            var f = (_.H = c.Ma(), _.A(_.H, "find")).call(_.H, function(g) {
                return _.Gj(g, 1) === a
            });
            f ? il(f, [b]) : (f = Fl(jl(new ll, a), b), Mj(c, 14, ll, f));
            e.info(Gl(a, String(b), d))
        } else Q(e, $k("PubAdsService.set", [a, b]))
    };
    Il = function(a, b, c) {
        return "string" !== typeof a ? (Q(c, $k("PubAdsService.get", [a])), null) : (b = (b = (_.H = b.Ma(), _.A(_.H, "find")).call(_.H, function(d) {
            return _.Gj(d, 1) === a
        })) && pl(b)) ? b[0] : null
    };
    Jl = function(a) {
        return a.Ma().map(function(b) {
            return _.R(b, 1)
        })
    };
    Ll = function() {
        for (var a = af(Kl) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Pl = function() {
        if (Ml) return Ml;
        for (var a = bf(Nl), b = [], c = 0; c < a.length; c += 2) Ol(a[c], a[c + 1], b);
        return Ml = b.join("&")
    };
    Ul = function(a, b) {
        if (!b || !_.ka(b)) return null;
        var c = !1,
            d = new Ql;
        _.Rl(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? Lj(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? Lj(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? Lj(d, 3, b.sandbox) : c = g = !0;
                    break;
                default:
                    g = !0
            }
            g && a.error(Sl("setSafeFrameConfig", Tl(b), f, Tl(e)))
        });
        return c ? null : d
    };
    Zl = function(a) {
        var b = new Ql;
        a = _.z(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) null != Yl(c, 1) && Lj(b, 1, _.N(c, 1)), null != Yl(c, 2) && Lj(b, 2, _.N(c, 2)), null != Yl(c, 3) && Lj(b, 3, _.N(c, 3));
        return b
    };
    $l = function(a, b) {
        var c = {};
        b = (c[0] = ig(b.pvsid), c);
        return _.Ye($f).m(a, b)
    };
    bm = function(a, b) {
        var c;
        return null == (c = _.am(a, "__gads", b)) ? void 0 : _.A(c.split(":"), "find").call(c.split(":"), function(d) {
            return 0 === d.indexOf("ID=")
        })
    };
    cm = function(a, b, c, d) {
        (c = bm(c, d)) ? (d = {}, b = (d[0] = ig(b.pvsid), d[1] = ig(c), d), _.Ye($f).m(a, b)) : $l(a, b)
    };
    gm = function(a) {
        var b = a.key,
            c = a.value,
            d = a.Ba,
            e = a.serviceName,
            f = a.Ql,
            g = a.Ya,
            h = a.P;
        a = a.context;
        var k = null;
        "string" === typeof c ? k = [c] : Array.isArray(c) ? k = c : _.ta(c) && (k = _.A(Array, "from").call(Array, c));
        var l = "string" === typeof b && !gl(b);
        k = k && xa(k);
        var m, n = null != (m = null == k ? void 0 : k.every(function(p) {
            return "string" === typeof p
        })) ? m : !1;
        if (l && n) {
            c = k;
            m = (_.H = _.gi(d, ll, 2), _.A(_.H, "find")).call(_.H, function(p) {
                return _.Gj(p, 1) === b
            });
            if ("gpt-beta" === b) {
                if (f) {
                    Q(h, dm(c.join()));
                    return
                }
                if (m) {
                    Q(h, em(c.join()));
                    return
                }
                c = fm(c, g, a)
            }
            m ? il(m, c) : (f = il(jl(new ll, b), c), Mj(d, 2, ll, f));
            h.info(ml(b, c.join(), e))
        } else Q(h, $k("PubAdsService.setTargeting", [b, c]))
    };
    hm = function(a, b, c) {
        return "string" !== typeof a ? (Q(c, $k("PubAdsService.getTargeting", [a])), []) : (b = (_.H = _.gi(b, ll, 2), _.A(_.H, "find")).call(_.H, function(d) {
            return _.Gj(d, 1) === a
        })) ? pl(b).slice() : []
    };
    im = function(a) {
        return _.gi(a, ll, 2).map(function(b) {
            return _.R(b, 1)
        })
    };
    mm = function(a, b, c, d) {
        if (void 0 === a) _.Gi(b, 2), d.info(jm(c));
        else if ("gpt-beta" === a) Q(d, km(a));
        else {
            var e = _.gi(b, ll, 2),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.Gj(g, 1) === a
                });
            0 > f ? Q(d, tl(a, c)) : (e.splice(f, 1), _.ul(b, 2, e), d.info(lm(a, c)))
        }
    };
    fm = function(a, b, c) {
        var d = [];
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            b.g = e;
            var f = $l(9, c);
            1 === f.length && (d.push(e), d.push(e + "-" + f[0]))
        }
        return d
    };
    om = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = nm.exec(null != (b = null == (a = _.qi(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    pm = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    qm = function(a, b) {
        var c = b.g;
        return a.map(function(d) {
            return _.A(c, "find").call(c, function(e) {
                return e.g === d
            })
        }).filter(Jf())
    };
    sm = function() {
        Object.defineProperty(window, "google_DisableInitialLoad", {
            get: function() {
                rm();
                return !0
            },
            set: function() {
                rm()
            },
            configurable: !0
        })
    };
    vm = function(a, b, c, d, e, f) {
        var g = tm(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.Ba;
        if (!f || !g) return Q(b, $k("PubAdsService.definePassback", [d, e])), null;
        Lj(g, 17, !0);
        c.slotAdded(f, g);
        return {
            ri: yl(a, b, new um(a, f, c)),
            Ba: g
        }
    };
    xm = function(a, b, c, d, e) {
        return Xk(c, function() {
            return new wm(a, b, c, d, e)
        })
    };
    ym = function(a, b, c, d, e) {
        "string" !== typeof a || "string" !== typeof b || void 0 === El()[a] ? Q(e, $k("Slot.set", [a, b]), c) : (c = (_.H = d.Ma(), _.A(_.H, "find")).call(_.H, function(f) {
            return _.Gj(f, 1) === a
        })) ? il(c, [b]) : (b = Fl(jl(new ll, a), b), Mj(d, 3, ll, b))
    };
    zm = function(a, b, c, d) {
        return "string" !== typeof a ? (Q(d, $k("Slot.get", [a]), b), null) : (b = (b = (_.H = c.Ma(), _.A(_.H, "find")).call(_.H, function(e) {
            return _.Gj(e, 1) === a
        })) && pl(b)) ? b[0] : null
    };
    Am = function(a) {
        return a.Ma().map(function(b) {
            return _.R(b, 1)
        })
    };
    Cm = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(Bm) : "fluid" === a
    };
    Dm = function(a) {
        return Array.isArray(a) && 2 === a.length && Bm(a[0]) && Bm(a[1])
    };
    Fm = function(a) {
        if (Array.isArray(a)) {
            var b = new ei;
            b = _.Gi(b, 1, _.Sc(a[0]));
            a = _.Gi(b, 2, _.Sc(a[1]))
        } else a = Em();
        return a
    };
    Hm = function(a) {
        var b = [];
        if (Gm(a)) b.push(Fm(a));
        else if (Array.isArray(a)) {
            a = _.z(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, Gm(c) ? b.push(Fm(c)) : va(c, ["fluid"]) && b.push(Em())
        }
        return b
    };
    Im = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return Hm(a)
    };
    Gm = function(a) {
        return _.G(Jm) ? Array.isArray(a) && 2 === a.length ? a.every(Km) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    Mm = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new Lm("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!Dm(b)) throw new Lm("Size must be an array of two non-negative integers");
        var c = new ei;
        c = _.Gi(c, 1, _.Sc(b[0]));
        b = _.Gi(c, 2, _.Sc(b[1]));
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = Hm(a[1]), 0 === a.length) throw new Lm("At least one slot size must be present");
        c = new ii;
        b = _.wh(c, 1, b);
        return _.ul(b, 2, a)
    };
    Nm = function() {
        var a;
        return null != (a = _.t.googletag) ? a : _.t.googletag = {
            cmd: []
        }
    };
    Rm = function(a, b) {
        _.G(Om) ? (_.Gi(a, 28), null !== b && Kf(b) && _.A(Object, "hasOwn").call(Object, b, "enabled") && (b = b.enabled, Pm(b) && (b = Qm(b), _.wh(a, 28, b)))) : void 0 === b || null === b ? _.Gi(a, 28) : (b = b.enabled, Pm(b) ? (b = Qm(b), _.wh(a, 28, b)) : void 0 !== b && null !== b || _.Gi(a, 28))
    };
    Sm = function(a, b) {
        if (!b) return [];
        var c = [];
        b = _.z((_.H = je(b, 26, qd), _.A(_.H, "values")).call(_.H));
        for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            try {
                c.push(JSON.parse(d))
            } catch (e) {
                Ph(a, 1023, e)
            }
        }
        return c
    };
    Um = function(a, b, c) {
        return Xk(c, function() {
            return new Tm(a, b, c)
        })
    };
    bn = function(a, b, c, d, e, f, g) {
        var h = new Pj,
            k = new Vm(a, g);
        O(h, k);
        e = new Wm(a, d, e);
        O(h, e);
        e = new Xm(a, b, d, f, k.hb);
        O(h, e);
        g = new Ym(a, b, c, d, g, f, k.hb);
        O(h, g);
        if (_.G(Zm)) {
            b = new $m(a, b, c, d, f, k.hb);
            O(h, b);
            var l = b.j
        }
        a = new an(a, k.hb, g.j, e.j, l);
        O(h, a);
        Yj(h);
        return {
            hb: a.output,
            Fa: h
        }
    };
    dn = function(a, b) {
        return Xk(b, function() {
            return new cn(a, b)
        })
    };
    fn = function(a, b, c) {
        var d = Lh(a, 77, function() {
            var e = b.cmd;
            if (!e || Array.isArray(e)) {
                var f = new en(c);
                b.cmd = dn(a, f);
                null != e && e.length && f.push.apply(f, e)
            }
        });
        b.fifWin && "complete" !== document.readyState ? _.lb(window, "load", function() {
            return window.setTimeout(d, 0)
        }) : d()
    };
    jn = function(a) {
        var b = window;
        "complete" === _.t.document.readyState ? Rh(a, 94, function() {
            Nm()._pubconsole_disable_ || null !== gn(b) && hn(a, b)
        }) : _.lb(_.t, "load", Lh(a, 94, function() {
            Nm()._pubconsole_disable_ || null !== gn(b) && hn(a, b)
        }))
    };
    hn = function(a, b) {
        b = void 0 === b ? _.t : b;
        if (!kn) {
            var c = new ln("gpt_pubconsole_loaded");
            kj(c, a);
            lj(c, "param", String(gn(b)));
            lj(c, "api", String(mn));
            nn(c);
            _.on(b.document, pn);
            kn = !0
        }
    };
    gn = function(a) {
        var b = si(a),
            c;
        return null != (c = (_.H = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.A(_.H, "find")).call(_.H, function(d) {
            return null !== qn(b, d)
        })) ? c : null
    };
    rn = function() {
        Nm()._pubconsole_disable_ = !0
    };
    un = function() {
        sn && (Nm().console.openConsole(tn), tn = void 0, sn = !1)
    };
    vn = function(a) {
        switch (Number(a)) {
            case 0:
                return "";
            case 1:
                return "Out-of-page creative";
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            case 7:
                return "Game Manual Interstitial";
            case 4:
                return "Rewarded";
            case 8:
            case 9:
                return "Side Rail";
            default:
                return ""
        }
    };
    wn = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(_.Gj(a, 1)), c.push(mi(a)), c.push(_.Gj(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.hg(c.join(":")).toString() : "0"
    };
    xn = function(a) {
        if (!_.tk(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    zn = function(a, b, c, d, e) {
        var f = void 0,
            g = Lh(a.context, b, e);
        _.lb(c, d, g) && (f = function() {
            return void _.Ef(c, d, g)
        }, _.yn(a, f));
        return f
    };
    Bn = function(a) {
        a = (_.tk(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!An(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    Fn = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        var p = {
                ya: new Cn,
                La: new Cn,
                he: new Cn,
                Qh: new Cn
            },
            r = new Pj;
        b = new Dn(a, b, c.width, k, l, n);
        O(r, b);
        a = new En(a, d, e, f, h, k, g, b.B, b.o, m, n, p.ya, p.La, p.he, p.Qh);
        O(r, a);
        Yj(r);
        return {
            Fa: r,
            Qg: p
        }
    };
    Jn = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window,
            p = {
                Rd: new Gn
            },
            r = new Pj,
            w = new Hn(a, n, e);
        O(r, w);
        a = new In(a, n.document, c, d, b, g, e, f, h, k, w.output, l, m, p.Rd);
        O(r, a);
        Yj(r);
        return {
            Fa: r,
            Qg: p
        }
    };
    Kn = function(a, b, c, d) {
        var e = _.rf("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    Ln = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    On = function(a, b, c) {
        var d = new _.v.Map;
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            var f = b[e.getDomId()];
            f = Mn(f, Nn, 28) ? _.di(f, Nn, 28) : _.di(c, Nn, 34);
            var g = void 0;
            d.set(e, (null == (g = f) ? 0 : null != Yl(g, 1)) ? _.N(f, 1) ? 2 : 1 : 0)
        }
        return d
    };
    Rn = function(a, b, c) {
        var d, e, f = [],
            g = [];
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (d = d.value, 1 === b.get(d)) f.push(null), g.push(null);
            else {
                var h = c,
                    k = Li(d);
                d = Pn((null == k ? void 0 : k.parentElement) && Ni(k.parentElement, h) || null);
                if (!d || 1 === d[0] && 1 === d[3]) {
                    var l = e = d = void 0,
                        m = null != (l = null == k ? void 0 : k.parentElement) ? l : null;
                    l = null != (e = Ei(m)) ? e : new _.Di(0, 0);
                    Qn(l, m, h, 100);
                    e = null != (d = Ei(k)) ? d : new _.Di(0, 0);
                    Qn(e, k, h, 1); - 1 === l.height && (e.height = -1);
                    d = l;
                    d = d.width + "x" + d.height;
                    e = e.width + "x" + e.height
                } else e = d = "-1x-1";
                f.push(d);
                g.push(e)
            }
        return {
            el: f,
            Ul: g
        }
    };
    Qn = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !Sn(b, c, d))) {
                    a: {
                        do {
                            var g = Ni(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    Un = function(a, b, c) {
        var d = 0 !== (0, _.Tn)(),
            e = ki(!0, c, d).width,
            f = [],
            g = [],
            h = [];
        if (null !== c && c != c.top) {
            var k = ki(!1, c).width;
            (-12245933 === e || -12245933 === k || k < e) && h.push(8)
        } - 12245933 !== e && (1.5 * e < c.document.documentElement.scrollWidth ? h.push(10) : d && 1.5 * c.outerWidth < e && h.push(10));
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (k = d.value, 1 === b.get(k)) f.push(null), g.push(null);
            else {
                d = new fj;
                var l = Li(k);
                k = 0;
                var m = !1,
                    n = !1,
                    p = !1;
                if (l) {
                    for (var r = 0, w = l; w && 100 > r; r++, w = w.parentElement) {
                        var u = Ni(w, c);
                        if (u) {
                            var x = u,
                                y = x.display,
                                C = x.overflowX;
                            if ("visible" !== x.overflowY && (d.set(2), (x = Ei(w)) && (k = k ? Math.min(k, x.width) : x.width), d.get(9))) break;
                            Ln(u) && d.set(9);
                            "none" === y && d.set(7);
                            "IFRAME" === w.nodeName && (u = parseInt(u.width, 10), u < e && (d.set(8), k = k ? Math.min(u, k) : u));
                            n || (n = "scroll" === C || "auto" === C);
                            m || (m = "flex" === y);
                            p || (p = "listbox" === w.role)
                        } else d.set(3)
                    }
                    if (!p) {
                        if (m = n && m) l = l.getBoundingClientRect().left, m = l > e || 0 > l;
                        p = m
                    }
                    p && d.set(11)
                } else d.set(1);
                l = _.z(h);
                for (m = l.next(); !m.done; m = l.next()) d.set(m.value);
                f.push(hj(d));
                g.push(k)
            }
        return {
            tk: f,
            dl: g
        }
    };
    $n = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = _.z(e);
            g = a.next();
            for (f = {}; !g.done; f = {
                    df: f.df
                }, g = a.next()) {
                e = g.value;
                g = e.code;
                e = e.bids;
                var h = void 0;
                if (g && null != (h = e) && h.length && (g = xg(g, b), f.df = g / 1E6, !(0 >= g))) {
                    h = void 0;
                    e = _.z(null != (h = e) ? h : []);
                    var k = e.next();
                    for (h = {}; !k.done; h = {
                            Bb: h.Bb,
                            cg: h.cg
                        }, k = e.next()) k = k.value, h.cg = "function" === typeof k.getFloor ? k.getFloor : void 0, h.Bb = Vn(Wn(Xn(new Yn, 4), g), c), k.getFloor = function(l, m) {
                        return function(n) {
                            4 === _.Nk(l.Bb, 1, 0) && Xn(l.Bb, 1);
                            var p, r = null == (p = l.cg) ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.df
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Nk(l.Bb, 1, 0) && (n = Wn(Xn(l.Bb, 6), 1E6 * r.floor), Zn(n, 3, r.currency)), r) : (r.floor || 0) > m.df ? (1 === _.Nk(l.Bb, 1, 0) && Wn(Xn(l.Bb, 5), 1E6 * r.floor), r) : n : n
                        }
                    }(h, f), d.set(k.getFloor, h.Bb)
                }
            }
        }
    };
    ao = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return Nm().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    co = function(a, b) {
        return Xk(b, function() {
            return new bo(a, b)
        })
    };
    lo = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(w) {
                        return (_.H = pl(w), _.A(_.H, "includes")).call(_.H, r)
                    })
                }), g.length)) {
                var m, n;
                f = null == (m = e.adUnits) ? void 0 : null == (n = _.A(m, "find").call(m, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : n.mediaTypes;
                m = _.z(g);
                for (n = m.next(); !n.done; n = m.next()) n = n.value, g = eo(n, d, f), g = fo(a, go(Lj(ho(io(new jo, n.bidder), 1), 6, !0), g)), ko(n.bidder, e, g), "number" === typeof n.timeToRespond && _.Dk(g, 2, Math.round(n.timeToRespond))
            }
        }
    };
    ko = function(a, b, c) {
        for (var d = []; a && !_.A(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.Zh(c, 10, d)
    };
    oo = function(a, b, c) {
        null != mo(a, 3) || (c === b.getAdUnitPath() ? _.no(a, 3, 1) : c === b.getDomId() && _.no(a, 3, 2))
    };
    ro = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Nk(f, 1, 0)) && _.wh(b, 5, f);
        Mn(a, Yn, 5) || (f ? 1 === _.Nk(f, 1, 0) ? po(a, f) : po(a, Wn(Xn(Vn(new Yn, e), 1), xg(c, d, _.G(qo)))) : po(a, Xn(Vn(new Yn, e), xg(c, d, _.G(qo)) ? 2 : 3)))
    };
    eo = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            m = a.adUnitCode,
            n = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var w = new so;
        "number" === typeof d && (_.Dk(w, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.Cf(w, 2) || _.Dk(w, 8, d)));
        "string" === typeof f && Zn(w, 3, f);
        (_.H = ["string", "number"], _.A(_.H, "includes")).call(_.H, typeof h) && to(w, uo(new vo, String(h)));
        if ("object" === typeof k)
            for (b = _.A(Object, "fromEntries").call(Object, b.map(function(y) {
                    return [_.Gj(y, 1), pl(y)]
                })), f = _.z(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.z(_.A(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.z(g.value);
                    var u = g.next().value;
                    g = g.next().value;
                    u = (u + h).slice(0, 20);
                    var x = void 0;
                    if (null != (x = b[u]) && x.length)
                        if (b[u][0] === String(g)) d.push(u);
                        else {
                            d = [];
                            break
                        }
                }
                wo(w, _.xo(w, 4, 2).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.no(w, 5, 1);
                break;
            case "native":
                _.no(w, 5, 2);
                ej("hbyg_nat", function(y) {
                    lj(y, "pub_url", document.URL);
                    lj(y, "b", l);
                    lj(y, "auc", null != m ? m : "");
                    lj(y, "hmt", Number(!!c));
                    var C;
                    lj(y, "hat", Number(!!(null == c ? 0 : null == (C = c.native) ? 0 : C.adTemplate)))
                }, _.$e(yo));
                break;
            case "video":
                _.no(w, 5, 3)
        }
        _.A(Number, "isFinite").call(Number, r) && _.A(Number, "isFinite").call(Number, a) && zo(w, Ao(Bo(new Co, Math.round(a)), Math.round(r)));
        "string" === typeof n && Zn(w, 1, n);
        return w
    };
    Do = function(a, b) {
        var c = new _.v.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.z(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.oh(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.z(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).Fl = f)
            }
        }
        d = new _.v.Map;
        a = _.z(_.A(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.z(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.Fl, g && h && d.set(f, {
            latency: h - g,
            Uh: !1
        });
        e = _.z(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.Uh = !0;
        return d
    };
    Eo = function(a, b) {
        for (var c = new fj, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return hj(c)
    };
    Ho = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.qd ? "" : c.qd;
        c = void 0 === c.za ? "," : c.za;
        if (_.G(Fo)) return Go(a, b);
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    Go = function(a, b) {
        return a.map(function(c) {
            return b(c)
        })
    };
    Jo = function(a, b, c, d, e, f, g) {
        if (f) {
            var h = {
                    Og: new Cn
                },
                k = new Pj;
            a = new Io(a, b, c, d, e, f, g, h);
            O(k, a);
            Yj(k);
            return {
                zj: h,
                Fa: k
            }
        }
    };
    Lo = function(a, b, c, d, e) {
        if (b && !(.01 < Math.random())) {
            var f = new Pj;
            O(f, new Ko(a, c, b.Pb, d, e));
            Yj(f)
        }
    };
    No = function(a, b) {
        var c;
        return !(null != (c = Mo(b, 22)) ? !c : !_.N(a, 15))
    };
    Po = function(a) {
        var b;
        var c = new Oo;
        c = _.th(c, 2, a.pvsid);
        c = _.uh(c, 3, a.ab);
        c = _.uh(c, 6, a.Nf);
        var d = null != (b = a.En) ? b : _.Yg();
        b = _.th(c, 1, d);
        c = _.bg();
        b = _.le(b, 4, c, Pc);
        a.payload && (c = a.payload(), _.wh(b, 7, c));
        a.Vc && _.th(b, 5, a.Vc);
        return b
    };
    Ro = function(a, b, c, d) {
        for (var e = _.z(_.A(Object, "entries").call(Object, Qo)), f = e.next(); !f.done; f = e.next()) {
            var g = _.z(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && Q(a, g(String(c), d))
        }
    };
    Xo = function(a, b, c) {
        a.Ll && a.Ga.Ki(Po(_.A(Object, "assign").call(Object, {}, a, {
            Vc: a.cl,
            payload: function() {
                var d = new So;
                var e = d.C;
                var f = Pd(e),
                    g = ne(e, f, To),
                    h = Uo(d, Vo, 1);
                g && 1 !== g && Wd(e, f, g);
                e = _.Wo(h, 1, b);
                _.Wo(e, 2, c);
                return d
            }
        })))
    };
    bp = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && Uf(c)) {
            c = c ? Vf(c) : null;
            var d = !1,
                e = _.G(_.Yo);
            d = void 0 === d ? !1 : d;
            e = void 0 === e ? !1 : e;
            var f = 0;
            try {
                f |= a !== a.top ? 512 : 0;
                var g;
                if (!(g = !a.navigator)) {
                    var h = a.navigator;
                    g = "brave" in h && "isBrave" in h.brave || !1
                }
                f |= g || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                f |= Gg(a, 2500, e);
                e || (f |= Hg(a));
                0 < b && (d ? c && Zo(c) || (f |= 4194304) : !_.$o(_.ap(c, b)) && (f |= 134217728))
            } catch (k) {
                f |= 32
            }
            a = f
        } else a = 4194304;
        return a
    };
    cp = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42;
            case 7:
                return 10;
            case 8:
                return 3;
            case 9:
                return 4
        }
    };
    fp = function(a, b, c) {
        a = cp(a);
        if (!a) return null;
        if (10 === a) return 0;
        var d = 0;
        if (!(_.H = [11, 10], _.A(_.H, "includes")).call(_.H, a)) {
            d |= b !== b.top ? 512 : 0;
            var e = _.mh(b);
            e = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && e.adCount ? 1 == a || 2 == a ? !(!e.adCount[1] && !e.adCount[2]) : (e = e.adCount[a]) ? 1 <= e : !1 : !1;
            e && (d |= 64);
            if (d) return d
        }
        if (2 === a || 1 === a) {
            var f = {
                ka: b,
                Me: _.dp,
                fh: c ? a : void 0,
                mm: _.G(_.ep)
            };
            0 === (0, _.Tn)() && (f.Me = 3E3, f.qg = 650);
            d |= _.Ug(f)
        } else if (8 === a) d |= bp(b);
        else if (3 === a || 4 === a) {
            e = a;
            e = void 0 === e ? null : e;
            c = b !== b.top ? 512 : 0;
            Pg(null == (f = b.navigator) ? void 0 : f.userAgent) && (c |= 1048576);
            f = b.innerWidth;
            1200 > f && (c |= 65536);
            var g = b.innerHeight;
            650 > g && (c |= 2097152);
            e && 0 === c && (e = 3 === e ? "left" : "right", (f = _.ph({
                ka: b,
                Th: !0,
                Ji: 1,
                position: e,
                ga: f,
                ma: g,
                hc: new _.v.Set,
                minWidth: 120,
                minHeight: 500
            })) ? _.mh(b).sideRailPlasParam.set(e, f.width + "x" + f.height + "_" + String(e).charAt(0)) : c |= 16);
            d |= c
        } else 11 !== a && 42 !== a && (d |= 32);
        d || (b = _.mh(b), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return d
    };
    ip = function(a, b, c, d) {
        var e = d.wh,
            f = d.adUnitPath;
        d = void 0 === d.pb ? !1 : d.pb;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && gp(e)) ? hp(a, b, f, c, {
            Ib: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            pb: d
        }) : (b.error($k("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    gp = function(a) {
        switch (a) {
            case 6:
                return !0;
            case 7:
                return !0;
            default:
                return !!An(Al, function(b) {
                    return b === a
                })
        }
    };
    hp = function(a, b, c, d, e) {
        var f = e.format;
        c = d.add(a, b, c, [1, 1], {
            Ib: e.Ib,
            format: f,
            pb: e.pb
        });
        a = c.slotId;
        b = c.Ba;
        c = c.wj;
        a && b && (_.no(b, 15, c ? 2 : f), _.yn(a, function() {
            var g = window,
                h = cp(f);
            if (h) {
                g = _.mh(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    kp = function(a, b, c, d, e, f, g, h) {
        var k = new Pj;
        a = new jp(a, b, c, d, e, f, g, h);
        O(k, a);
        Yj(k);
        return k
    };
    lp = function(a, b) {
        var c;
        return !(null != (c = Mo(a, 11)) ? !c : !_.N(b, 10))
    };
    mp = function(a, b, c, d) {
        if (a = Li(a, b)) {
            var e;
            if (c = null != (e = Mo(c, 24)) ? e : _.N(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.t.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    pp = function(a, b) {
        var c = b.K,
            d = b.O;
        b = b.U;
        a = _.z(a.X);
        for (var e = a.next(); !e.done; e = a.next())
            if (e = e.value, _.np(c, e)) {
                var f = d,
                    g = f.W;
                f = f.R[e.getDomId()];
                lp(f, g) && mp(e, b, f, g);
                op(c, e);
                var h = void 0,
                    k = void 0;
                null != (h = null != (k = Mo(f, 10)) ? k : _.N(g, 11)) && h && mp(e, b, f, g)
            }
        return {}
    };
    qp = function(a, b, c, d) {
        Q(a, Sl("googletag.setConfig.commerce", Tl(b), c, Tl(d)))
    };
    rp = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    sp = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    up = function(a, b, c) {
        var d = new Pj;
        a = new tp(a, b, c);
        O(d, a);
        Yj(d)
    };
    wp = function(a, b) {
        var c, d, e, f, g;
        return _.nb(function(h) {
            c = a;
            d = c.Hc;
            e = b;
            f = e.Zf;
            return (null != (g = d) ? g : f.Hc()) ? h.return(vp(f)) : h.return(null)
        })
    };
    Ap = function(a, b, c) {
        var d = window,
            e = new Pj;
        d = new xp(d);
        _.S(e, d);
        a = new yp(a, d, c, _.qi(150));
        O(e, a);
        b = new zp(879, wp, {
            Hc: b ? a.Ic : void 0
        }, {
            Zf: d,
            Kn: !!b
        }, void 0, e.o.g);
        b = O(e, b).output;
        Yj(e);
        return {
            Ic: a.Ic,
            Fh: b,
            Fa: e
        }
    };
    Bp = function(a) {
        if (61440 >= a.length) return {
            url: a,
            eh: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            eh: a.length - b.length + 8
        }
    };
    Cp = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    Dp = function(a, b) {
        b = void 0 === b ? window : b;
        return !!Cp(a, b)
    };
    Ep = function(a) {
        var b, c;
        return null != (c = null == (b = _.A(a, "find").call(a, function(d) {
            return "page_url" === _.Gj(d, 1)
        })) ? void 0 : pl(b)[0]) ? c : null
    };
    Fp = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    Gp = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Rk(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    Hp = function(a, b) {
        var c = b.R;
        return !!Ep(b.W.Ma()) || a.some(function(d) {
            return null !== Ep(c[d.getDomId()].Ma())
        })
    };
    Jp = function() {
        var a = void 0 === a ? window : a;
        Ip = _.Yg(a)
    };
    Kp = function(a, b) {
        var c = _.rf("DIV");
        c.id = a;
        c.textContent = b;
        _.Yi(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    Lp = function(a, b) {
        if ("undefined" !== typeof IntersectionObserver) return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    Pp = function(a, b, c, d, e) {
        var f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        if (!b) return {
            jg: e
        };
        var g = null != Mp(b, 1) ? null != Np(b) && 0 !== (0, _.Tn)() ? Mp(b, 1) * Np(b) : Mp(b, 1) : null;
        if (null == g) return {
            jg: e
        };
        b = new Pj;
        a = new Op(a, d, c, g, e, f);
        O(b, a);
        Yj(b);
        return {
            jg: a.output,
            Uk: b
        }
    };
    Zp = function(a, b, c, d, e) {
        var f = window,
            g = new Pj,
            h = O(g, new Qp(a, b, Rp, function(m) {
                return Sp("i-adframe-load", m.detail.data)
            })),
            k = O(g, new Qp(a, b, Rp, function(m) {
                return Sp("i-dismiss", m.detail.data)
            }));
        h = 0 < _.$e(Tp) ? O(g, new Up(a, h.output, void 0)).output : h.output;
        h = O(g, new Vp(a, b, c, h));
        O(g, new Wp(a, f, d, e, h.output));
        if (f.top === f) var l = O(g, new Xp(a, f, h.output)).output;
        O(g, new Yp(a, b, c, h.output, k.output, l));
        return g
    };
    Sp = function(a, b) {
        try {
            var c = JSON.parse(b);
            return "sth" === c.googMsgType && c.msg_type === a
        } catch (d) {}
        return !1
    };
    $p = function(a, b) {
        a.kg.log(576944485, Po, _.A(Object, "assign").call(Object, {}, a, b))
    };
    aq = function(a) {
        return window.IntersectionObserver && new IntersectionObserver(a, {
            threshold: [.5]
        })
    };
    cq = function(a, b, c) {
        return new bq(c, a, Rp, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    gq = function(a, b, c) {
        if (Kf(a) && _.A(Object, "keys").call(Object, a).some(function(d) {
                return (_.H = _.A(Object, "values").call(Object, dq), _.A(_.H, "includes")).call(_.H, Number(d))
            })) return !0;
        eq("taxonomies", a, b, c);
        return !1
    };
    oq = function(a, b, c, d) {
        if (hq(_.A(b, "values"), d, b)) {
            var e = iq(a, _.A(b, "values"), d, b);
            e.size && (b = (_.H = _.gi(c, jq, 1), _.A(_.H, "find")).call(_.H, function(f) {
                return _.Nk(f, 1, 0) === a
            }), e = [].concat(_.oh(e)), b ? kq(b, e) : lq(c, kq(mq(new jq, a), e)), d.info(nq(Tl(e), Tl(a))))
        }
    };
    hq = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        eq("taxonomyData.values", a, b, c);
        return !1
    };
    iq = function(a, b, c, d) {
        if (!Qf()(b)) return eq("taxonomyData.values", b, c, d), new _.v.Set;
        d = new _.v.Set;
        var e = !1;
        b = _.z(b);
        for (var f = b.next(); !f.done; f = b.next()) {
            f = f.value;
            if (10 <= d.size) {
                e = !0;
                break
            }
            d.add(f)
        }
        e && Q(c, pq(Tl(a), Tl(10)));
        return d
    };
    eq = function(a, b, c, d) {
        Q(c, Sl("googletag.setConfig.pps", Tl(d), a, Tl(b)))
    };
    rq = function(a) {
        return qq.has(a)
    };
    uq = function(a, b) {
        if (3 === _.sq(b)) {
            var c = {
                    Kd: new Gn
                },
                d = new Pj;
            O(d, new tq(a, b, c.Kd));
            Yj(d);
            return {
                Fa: d,
                ql: c
            }
        }
    };
    wq = function(a, b, c, d, e, f) {
        if (b) {
            var g = {
                    Dg: new Cn
                },
                h = new Pj;
            O(h, new vq(a, b, c, g, d, e, f));
            Yj(h);
            return {
                Fa: h,
                ef: g
            }
        }
    };
    xq = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.A(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    zq = function(a, b) {
        var c = _.$e(yq);
        Math.random() <= c && Bj(b, a)
    };
    Fq = function(a, b, c) {
        var d = {};
        if (!c) return b.error(Aq("missing data-rendering attribute")), d;
        try {
            var e = Bq(Cq(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : Mn(f, Dq, 1)) ? (b = _.I(new Eq, 4, 1), b = _.I(b, 2, 7), a = _.uh(b, 3, a.wb || a.ab), b = _.di(e, Dq, 1), a = _.wh(a, 5, b), a = _.Ah(a, 6, !0), d.Vl = a) : b.error(Aq("invalid data-rendering attribute"));
        var g;
        d.Dl = null == (g = e) ? void 0 : _.R(g, 2);
        var h;
        d.Bf = null == (h = e) ? void 0 : _.R(h, 3);
        return d
    };
    Iq = function(a, b) {
        var c = qn(b, "ai");
        if (!c || 0 === c.length) return _.v.Promise.resolve(b);
        var d = Gq();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.v.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.pg;
                var g = e.resolve;
                e = e.promise;
                Hq(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Lh(a, h, k)
                });
                return e
            }
        }
        return _.v.Promise.resolve(b)
    };
    Kq = function(a, b, c, d) {
        var e, f, g;
        return _.nb(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            g = d.replace("?", _.Jq("", (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f)) + "&");
            return h.return(Iq(a, g))
        })
    };
    Lq = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.v.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.pg;
                var g = d.resolve;
                d = d.promise;
                Hq(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return Lh(a, h, k)
                });
                return d
            }
        }
        return _.v.Promise.resolve(b)
    };
    Qq = function(a, b) {
        var c = window;
        var d = void 0 === d ? tb : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = Gq(),
                g;
            null == (g = f ? new Mq(function(k, l) {
                return Lh(a, k, l)
            }, function() {}) : void 0) || g.na();
            var h = xq(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.T(e, h);
            e.prototype.connectedCallback = function() {
                var k = Fq(a, b, this.dataset.rendering),
                    l = k.Vl,
                    m = k.Dl;
                k = k.Bf;
                l && d(Nq(window, l));
                m && Lq(a, m, f).then(function(n) {
                    return void Oq(n)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Bf = k, this.addEventListener("click", this.g)) : Q(b, Pq(k)))
            };
            e.prototype.g = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && Kq(a, this, k, this.Bf).then(function(m) {
                    return void Oq(m)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    Sq = function(a) {
        Rq = a
    };
    Uq = function(a, b, c, d) {
        fk(b, d, function(e, f) {
            Ph(a, e, f);
            var g, h;
            null == (h = (g = window.console).error) || h.call(g, f)
        }, function() {
            return void Q(c, Tq())
        })
    };
    Xq = function(a, b, c, d, e, f) {
        var g = window,
            h = new Pj;
        b = 8 === b ? 3 : 4;
        c = new Vq(a, c);
        O(h, c);
        O(h, new Wq(a, g, b, c.output, d, e, f));
        Yj(h);
        return h
    };
    qa = function(a, b) {
        a: {
            b = b[0];a = a[0];
            for (var c = _.oa, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.oa(b.length, a.length)
        }
        return b
    };
    Yq = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.A(a, "includes").call(a, 0)
    };
    Zq = function(a) {
        if (Yq(a)) return {
            size: [],
            Hg: !0
        };
        if (Array.isArray(a) && 0 < a.length && "number" !== typeof a[0]) {
            var b = !1;
            a = a.filter(function(c) {
                c = Yq(c);
                b = b || c;
                return !c
            });
            return {
                size: a,
                Hg: b
            }
        }
        return {
            size: a,
            Hg: !1
        }
    };
    ar = function(a, b) {
        var c = b.R;
        return Ho(a, function(d) {
            return $q(c[d.getDomId()]).join("&")
        }, {
            za: "|"
        })
    };
    $q = function(a) {
        a = br(a);
        var b = [];
        _.Rl(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    br = function(a) {
        for (var b = {}, c = _.z(hl(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[_.R(d, 1)] = pl(d);
        a = _.xo(a, 8, 2);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    cr = function(a) {
        var b = !1,
            c = _.gi(a, ll, 2).map(function(d) {
                var e = _.R(d, 1);
                b = "excl_cat" === e;
                d = pl(d);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.xo(a, 3, 2);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    er = function(a, b, c, d, e) {
        if (c) {
            var f = {
                    Xd: new Cn,
                    Yd: new Cn,
                    Zc: new Cn
                },
                g = new Pj;
            O(g, new dr(a, b, c, d, f, e));
            Yj(g);
            return {
                Fa: g,
                bm: f
            }
        }
    };
    gr = function(a, b, c) {
        var d = window;
        if (_.G(zk) && b) {
            var e = new Pj;
            O(e, new fr(a, d, b, c));
            Yj(e);
            return e
        }
    };
    hr = function(a) {
        return "gads_privacy_sandbox_td_buyerlist__" + a
    };
    jr = function(a, b) {
        return a.filter(function(c) {
            return ir(c, 2) > b
        })
    };
    lr = function(a, b) {
        a = new _.v.Map(a.map(function(e) {
            return [_.R(e, 1), e]
        }));
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = a.get(_.R(c, 1));
            d ? kr(d, Math.max(ir(c, 2), ir(d, 2))) : a.set(_.R(c, 1), c)
        }
        return _.A(Array, "from").call(Array, _.A(a, "values").call(a))
    };
    pr = function(a, b, c) {
        var d = Date.now();
        if (mr(a, b, c)) return new _.v.Map;
        b = new _.v.Map(_.A(Object, "entries").call(Object, a).filter(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return _.A(k, "startsWith").call(k, "gads_privacy_sandbox_td_buyerlist__") && l
        }).map(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return [k, nr(l)]
        }));
        c = _.z(b);
        for (var e = c.next(); !e.done; e = c.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            f = f.next().value;
            var g = _.gi(f, or, 1),
                h = jr(g, d);
            0 === h.length ? (b.delete(e), a.removeItem(e)) : h.length < g.length && (_.ul(f, 1, h), a.setItem(e, Gk(f)))
        }
        return b
    };
    mr = function(a, b, c) {
        if (!_.N(b, 3)) return !1;
        b = String(_.hg(c + "-" + _.R(b, 2) + _.R(b, 4) + _.N(b, 3)));
        if (a.getItem("gads_privacy_sandbox_tcf_hash") === b) return !1;
        c = _.z(_.A(Object, "keys").call(Object, a).filter(function(e) {
            return _.A(e, "startsWith").call(e, "gads_privacy_sandbox_td_buyerlist__")
        }));
        for (var d = c.next(); !d.done; d = c.next()) a.removeItem(d.value);
        a.setItem("gads_privacy_sandbox_tcf_hash", b);
        return !0
    };
    qr = function(a) {
        return (_.H = ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"], _.A(_.H, "includes")).call(_.H, a)
    };
    rr = function(a) {
        return (_.H = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.A(_.H, "includes")).call(_.H, a)
    };
    tr = function(a, b, c, d, e) {
        if (b) {
            var f = b.Nb,
                g = b.Al;
            if (b.Sg && 4 === f) {
                b = new Cn;
                f = new Cn;
                if (!g) return b.D({
                    kind: 1,
                    reason: 1
                }), f.D(!1), {
                    Ui: {
                        Bi: b,
                        Nh: f
                    }
                };
                g = new Pj;
                a = new sr(a, c, d, e, b, f);
                O(g, a);
                Yj(g);
                return {
                    Ui: {
                        Bi: b,
                        Nh: f
                    },
                    hm: g
                }
            }
        }
    };
    ur = function(a) {
        var b = a.Jf,
            c = a.zb,
            d = void 0 === a.hh ? [] : a.hh,
            e = a.interestGroupBuyers;
        a = a.Ec;
        var f = {};
        void 0 !== a && (f["https://googleads.g.doubleclick.net"] = a, f["https://td.doubleclick.net"] = a);
        e = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            trustedScoringSignalsUrl: "https://securepubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != e ? e : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: a,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.g.promise,
            sellerTimeout: 50,
            sellerCurrency: "USD",
            perBuyerCurrencies: b.perBuyerCurrencies.promise,
            perBuyerExperimentGroupIds: f,
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise,
            perBuyerCumulativeTimeouts: b.perBuyerCumulativeTimeouts.promise
        };
        e.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        c = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: a,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            perBuyerCumulativeTimeouts: {},
            componentAuctions: [e].concat(_.oh(d)),
            resolveToConfig: b.resolveToConfig.promise
        };
        c.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        return c
    };
    vr = function(a, b) {
        b = b.Jf;
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        b.directFromSellerSignals.resolve(a.directFromSellerSignals);
        b.directFromSellerSignalsHeaderAdSlot.resolve(a.directFromSellerSignalsHeaderAdSlot);
        b.resolveToConfig.resolve(!!a.resolveToConfig);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.A(c, "find").call(c, function(g) {
                return rr(g.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.g.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {});
            var e;
            b.perBuyerCumulativeTimeouts.resolve(null != (e = a.perBuyerCumulativeTimeouts) ? e : {});
            var f;
            b.perBuyerCurrencies.resolve(null != (f = a.perBuyerCurrencies) ? f : {})
        } else b.auctionSignals.resolve(void 0), b.g.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({}), b.perBuyerCumulativeTimeouts.resolve({}), b.perBuyerCurrencies.resolve({})
    };
    wr = function(a, b) {
        return a.map(function(c) {
            var d = new or;
            c = _.uh(d, 1, c);
            return kr(c, b)
        })
    };
    xr = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.N(c, 18),
            f = _.N(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.R(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.N(c, 4) && (d += "&is_plog=1");
        (e = _.R(c, 11)) && (d += "&ecrs=" + e);
        if (null == c ? 0 : _.R(c, 19)) d += "&cid=" + encodeURIComponent(_.R(c, 19));
        (null == c ? 0 : _.N(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        Oq(d)
    };
    yr = function(a, b, c, d, e) {
        a.Cb.D(e);
        a.ya.D(c);
        a.La.D(d);
        null == b || b.D(!1)
    };
    Gr = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r, w, u;
        return _.nb(function(x) {
            if (1 == x.g) return ("string" !== typeof a || _.A(a, "startsWith").call(a, "urn:")) && zr.deprecatedURNToURL && zr.deprecatedReplaceInURN ? x.yield(zr.deprecatedURNToURL(a), 2) : x.return();
            c = x.m;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(Ar)) ? f : []).forEach(function(y) {
                d[y] = e
            });
            g = b.Ak || "";
            (null != (h = c.match(Br)) ? h : []).forEach(function(y) {
                d[y] = g
            });
            k = b.uj || "";
            (null != (l = c.match(Cr)) ? l : []).forEach(function(y) {
                d[y] = k
            });
            m = b.rj || "";
            (null != (n = c.match(Dr)) ? n : []).forEach(function(y) {
                d[y] = m
            });
            p = b.pj || "";
            (null != (r = c.match(Er)) ? r : []).forEach(function(y) {
                d[y] = p
            });
            w = b.Cl || "";
            (null != (u = c.match(Fr)) ? u : []).forEach(function(y) {
                d[y] = w
            });
            return x.yield(zr.deprecatedReplaceInURN(a, d), 0)
        })
    };
    Hr = function(a, b, c, d, e, f, g, h) {
        var k = 3 === b,
            l = 2 === b,
            m = 1 === b,
            n = f.getEscapedQemQueryId(),
            p = _.R(f, 6);
        ej("run_ad_auction_stats", function(r) {
            kj(r, a);
            lj(r, "duration_ms", c);
            lj(r, "applied_timeout_ms", d);
            lj(r, "timed_out", l ? 1 : 0);
            lj(r, "error", k ? 1 : 0);
            lj(r, "auction_skipped", m ? 1 : 0);
            lj(r, "auction_winner", h ? 1 : 0);
            lj(r, "thread_release_only", _.N(f, 15) ? 1 : 0);
            lj(r, "winner_qid", null != n ? n : "");
            lj(r, "xfpQid", null != p ? p : "");
            lj(r, "publisher_tag", "gpt");
            e && lj(r, "parallel", "1");
            0 < g && lj(r, "nc", g)
        }, 1)
    };
    Ir = function(a, b, c, d, e) {
        var f = e.getEscapedQemQueryId(),
            g = _.R(e, 6);
        ej("run_ad_auction_complete", function(h) {
            kj(h, a);
            lj(h, "duration_ms", Math.round(d));
            lj(h, "applied_timeout_ms", c);
            lj(h, "auction_has_winner", b);
            f && lj(h, "winner_qid", f);
            g && lj(h, "xfpQid", g)
        }, 1)
    };
    Jr = function(a, b) {
        var c = b.getEscapedQemQueryId(),
            d = _.R(b, 6);
        ej("pre_run_ad_auction_ping", function(e) {
            kj(e, a);
            lj(e, "winner_qid", null != c ? c : "");
            lj(e, "xfpQid", null != d ? d : "");
            lj(e, "publisher_tag", "gpt")
        }, 1)
    };
    Pr = function(a, b, c, d) {
        var e = Li(a, document);
        e && Bg(e, window, d, !0);
        Kr(_.Ye(Nh), "5", Lr(c.R[a.getDomId()], 20));
        Mr(a, Nr, 801, {
            oh: null,
            isBackfill: !1
        });
        if (_.np(b, a) && !Ui(a, document)) {
            b = c.W;
            c = c.R[a.getDomId()];
            var f;
            (null != (f = Mo(c, 10)) ? f : _.N(b, 11)) && mp(a, document, c, b)
        }
        Mr(a, Or, 825, {
            isEmpty: !0
        })
    };
    Sr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
        if (dg(window.isSecureContext, window.navigator, window.document) && !_.G(Qr) && u) {
            u = {
                Rd: new Gn,
                ya: new Cn,
                La: new Cn,
                Jc: new Cn
            };
            var y = new Pj;
            O(y, new Rr(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x));
            Yj(y);
            return {
                Fa: y,
                im: u
            }
        }
    };
    Ur = function(a) {
        if (!_.G(Tr)) return null;
        var b = new _.v.Set;
        a = _.z(_.A(a, "values").call(a));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, _.N(c, 2) && _.gi(c, or, 1).forEach(function(d) {
            b.add(_.R(d, 1))
        });
        return 0 < b.size ? _.A(Array, "from").call(Array, b) : null
    };
    Wr = function(a, b, c, d, e, f, g, h, k) {
        if (b) {
            var l = b.Nb;
            if (b.Sg && 0 !== l) return b = new Pj, a = new Vr(a, l, c, d, e, f, g, h, k), O(b, a), Yj(b), {
                gm: a.j,
                fm: b
            }
        }
    };
    Xr = function() {
        for (var a = _.z(_.A(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (_.Ja(d, "/tag/js/gpt.js") || _.Ja(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), ib(c, new _.gf(b.textContent, hf)), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    Yr = function(a, b) {
        b = _.z(_.A(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.z(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    as = function(a, b, c) {
        var d = [];
        c = [].concat(_.oh(c.X)).slice();
        if (b) {
            if (!Array.isArray(b)) return Q(a, $k("googletag.destroySlots", [b])), !1;
            na(b);
            d = c.filter(function(e) {
                return _.A(b, "includes").call(b, e.g)
            })
        } else d = c;
        if (!d.length) return !1;
        Zr(d);
        $r(d);
        return !0
    };
    As = function(a, b, c, d, e, f, g, h, k, l) {
        var m = Nm(),
            n, p, r = L(a, 74, function(u, x, y) {
                return e.defineSlot(a, b, u, x, y)
            }),
            w = {};
        r = (w._loaded_ = !0, w.cmd = [], w._vars_ = m._vars_, w.evalScripts = function() {
            try {
                Xr()
            } catch (y) {
                Ph(a, 297, y);
                var u, x;
                null == (u = window.console) || null == (x = u.error) || x.call(u, y)
            }
        }, w.display = L(a, 95, function(u) {
            bs(c, u, e)
        }), w.defineOutOfPageSlot = L(a, 73, function(u, x) {
            return (u = ip(a, b, e, {
                wh: x,
                adUnitPath: u
            })) ? u.g : null
        }), w.getVersion = L(a, 946, function() {
            return a.tc ? String(a.tc) : a.ab
        }), w.pubads = L(a, 947, function() {
            return xm(a, b, c, e, h)
        }), w.companionAds = L(a, 816, function() {
            null != n || (n = new cs(a, b, c, f));
            return cl(a, b, n)
        }), w.content = L(a, 817, function() {
            null != p || (p = new ds(a, b, g));
            return el(a, b, p)
        }), w.setAdIframeTitle = L(a, 729, Sq), w.getEventLog = L(a, 945, function() {
            return new es(a, b)
        }), w.sizeMapping = L(a, 90, function() {
            return new fs(a, b)
        }), w.enableServices = L(a, 91, function() {
            for (var u = _.z(ps), x = u.next(); !x.done; x = u.next()) x = x.value, x.enabled && b.info(qs()), rs(x)
        }), w.destroySlots = L(a, 75, function(u) {
            return as(b, u, e)
        }), w.enums = Dl(), w.defineSlot = r, w.defineUnit = r, w.getWindowsThatCanCommunicateWithHostpageLibrary = L(a, 955, function(u) {
            return ss(k, u).map(function(x) {
                var y;
                return null == (y = Ui(x, document)) ? void 0 : y.contentWindow
            }).filter(function(x) {
                return !!x
            })
        }), w.disablePublisherConsole = L(a, 93, rn), w.onPubConsoleJsLoad = L(a, 731, un), w.openConsole = L(a, 732, function(u) {
            mn = !0;
            var x;
            (null == (x = Nm()) ? 0 : x.console) ? Nm().console.openConsole(u): (u && (tn = u), sn = !0, hn(a))
        }), w.setConfig = L(a, 1034, function(u) {
            if (Kf(u)) {
                var x = u.commerce;
                if (null === x) x = Uo(d, ts, 33), _.Gi(x, 1);
                else if (void 0 !== x) {
                    var y = Uo(d, ts, 33);
                    if (_.ka(x)) {
                        var C = x.query,
                            D = x.categories,
                            E = x.productIds,
                            J = x.filter,
                            M = _.Sd(us(y, vs, 1));
                        null === C ? _.Gi(M, 1) : rp(C) ? Zn(M, 1, C) : void 0 !== C && qp(b, x, "query", C);
                        null === D ? _.Gi(M, 2) : sp(D) ? _.Zh(M, 2, D) : void 0 !== D && qp(b, x, "categories", D);
                        null === E ? _.Gi(M, 3) : sp(E) ? _.Zh(M, 3, E) : void 0 !== E && qp(b, x, "productIds", E);
                        null === J ? _.Gi(M, 4) : rp(J) ? Zn(M, 4, J) : void 0 !== J && qp(b, x, "filter", J);
                        null != _.Gj(M, 1) || _.xo(M, 2, 2).length ? _.wh(y, 1, M) : Q(b, ws())
                    } else Q(b, $k("googletag.setConfig.commerce", [x]))
                }
                if (_.A(Object, "hasOwn").call(Object, u, "pps"))
                    if (C = u.pps, null === C) x = Uo(d, ts, 33), _.Gi(x, 2);
                    else if (x = Uo(Uo(d, ts, 33), xs, 2), _.Gi(x, 1), Kf(C) && C.hasOwnProperty("taxonomies") ? y = !0 : (Q(b, $k("googletag.setConfig.pps", [C])), y = !1), y)
                    if (y = C.taxonomies, null === y) eq("taxonomies", y, b, C);
                    else if (gq(y, b, C))
                    for (C = _.z(_.A(Object, "entries").call(Object, y)), D = C.next(); !D.done; D = C.next()) {
                        D = _.z(D.value);
                        var K = D.next().value;
                        D = D.next().value;
                        E = x;
                        J = b;
                        var X = y;
                        if (null == K) eq("taxonomy", K, J, X);
                        else {
                            M = Number(K);
                            var ba = M,
                                la = J,
                                ra = X;
                            (_.H = _.A(Object, "values").call(Object, Cl), _.A(_.H, "includes")).call(_.H, Number(ba)) ? K = !0 : (eq("taxonomy", K, la, ra), K = !1);
                            K && (null == D ? eq("taxonomyData", D, J, X) : (K = J, Kf(D) && D.hasOwnProperty("values") ? X = !0 : (eq("taxonomyData", D, K, X), X = !1), X && oq(M, D, E, J)))
                        }
                    }
                _.A(Object, "hasOwn").call(Object, u, "adExpansion") && (_.Gi(d, 34), x = u.adExpansion, null !== x && Kf(x) && _.A(Object, "hasOwn").call(Object, x, "enabled") && (x = x.enabled, Pm(x) && (x = Qm(x), _.wh(d, 34, x))));
                if (_.A(Object, "hasOwn").call(Object, u, "privacyTreatments")) {
                    u = u.privacyTreatments;
                    _.Gi(d, 36);
                    a: {
                        if (null !== u && Kf(u) && _.A(Object, "hasOwn").call(Object, u, "treatments")) {
                            u = u.treatments;
                            if (ys(u) && u.every(rq)) {
                                u = {
                                    treatments: u
                                };
                                break a
                            }
                            Q(b, $k("googletag.setConfig", [u]))
                        }
                        u = void 0
                    }
                    x = u;
                    if (void 0 !== x) {
                        u = new _.v.Set;
                        x = _.z(x.treatments);
                        for (y = x.next(); !y.done; y = x.next()) {
                            y = y.value;
                            a: {
                                switch (y) {
                                    case "disablePersonalization":
                                        C = 1;
                                        break a
                                }
                                C = void 0
                            }
                            void 0 === C ? Q(b, $k("googletag.setConfig", [y])) : u.add(C)
                        }
                        if (u.size) {
                            x = new zs;
                            y = x.C;
                            C = Yb(y);
                            uc(Pd(x.C));
                            y = $d(y, C, 1, 2, !1);
                            if (Array.isArray(u))
                                for (C = 0; C < u.length; C++) y.push(Nc(u[C]));
                            else
                                for (u = _.z(u), C = u.next(); !C.done; C = u.next()) y.push(Nc(C.value));
                            _.wh(d, 36, x)
                        }
                    }
                }
            } else Q(b, $k("googletag.setConfig", [u]))
        }), w.apiReady = !0, w);
        Uq(a, m, b, l);
        Yr(m, r)
    };
    Hs = function(a) {
        var b = window,
            c = new Pj,
            d = new Bs(a, b);
        d = O(c, d).output;
        var e = new Pj;
        var f = new Cs(a, b);
        O(e, f);
        Yj(e);
        e = {
            kl: f.j
        };
        _.G(Ds) && O(c, new Es(a, b));
        if (Na()) {
            f = {
                wi: new Cn
            };
            var g = new Pj;
            O(g, new Fs(a, window, f.wi));
            Yj(g);
            a = f
        } else a = void 0;
        g = _.G(Qr);
        f = b.navigator;
        b = dg(b.isSecureContext, b.navigator, b.document);
        b = !g && b;
        g = _.$e(Gs);
        b = {
            Sg: b,
            Nb: g,
            Al: !!f.getInterestGroupAdAuctionData
        };
        Yj(c);
        return {
            jl: e,
            vl: a,
            qe: d,
            dm: b
        }
    };
    Ls = function(a, b, c, d, e) {
        var f = new Pj,
            g = O(f, new Qp(a, e, Is));
        c = O(f, new Js(a, c, d, g.output));
        O(f, new Ks(a, c.output, b, e));
        Yj(f);
        return f
    };
    Ms = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    ut = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D) {
        var E = new Pj,
            J = ki(!0, window),
            M = k.W,
            K = k.R[e.getDomId()],
            X = D.qe,
            ba = null == C ? void 0 : C.qf,
            la = new Ns(a, window);
        O(E, la);
        var ra = m.Fk,
            Aa = m.pm,
            ya = m.sk,
            Pa = m.ec,
            Fa = m.vj,
            Cb = m.Kk,
            bb = m.sf,
            yb = m.zk,
            cc = m.Xf,
            Jc = m.he,
            mc = m.lm,
            Zc = m.Tk,
            $c = m.Ug,
            ce = m.Ik,
            dc = m.ek,
            cb = m.ya,
            Vh = m.Ti;
        C = m.Qd;
        D = m.Nj;
        var kl = m.Ij,
            Mf = new Cn;
        Mf.D(p);
        var Eg = new Os(a, window.top, Mf);
        O(E, Eg);
        var Xh = new Ps(a, Qs(K), J.height, cc, ra);
        O(E, Xh);
        var nc = new Rs(a, e, Li(e, n), e.getDomId(), Ti(e), n.documentElement, Qs(K), h, f);
        Ss(E, nc);
        m = new Cn;
        m.Ka(nc.l.promise.then(function(fq) {
            return fq.output
        }));
        nc = new Ts(a, cb, Fa, Cb, bb);
        O(E, nc);
        cb = new Us(a, _.di(M, Vs, 5));
        O(E, cb);
        Aa = Fn(a, window.location.hash, J, e.getAdUnitPath(), K, f, Xh.output, Jc, Aa, ra, nc.output, m);
        ra = Aa.Qg;
        _.S(E, Aa.Fa);
        bb = new Ws(a, M, K, Fa, bb, ra.Qh);
        O(E, bb);
        if (f = Sr(a, e, Eg.output, K, h, p, f, ra.ya, ra.La, m, r, k, y, Pa, Vh, g, w)) {
            _.S(E, f.Fa);
            var ud = f.im
        }
        var yc, gb;
        f = null != (gb = null == (yc = ud) ? void 0 : yc.ya) ? gb : ra.ya;
        var ec, Le;
        yc = null != (Le = null == (ec = ud) ? void 0 : ec.La) ? Le : ra.La;
        var zc;
        ec = null == (zc = ud) ? void 0 : zc.Rd;
        var Ac;
        ud = null == (Ac = ud) ? void 0 : Ac.Jc;
        Ac = new Xs(a, e, M, K, Qs(K), n, h, m, bb.output, yc, ya, ec);
        O(E, Ac);
        zc = new Ys(a, Ac.output);
        O(E, zc);
        zc = new Zs(a, e, J, h, zc.output, cb.j, ec);
        O(E, zc);
        zc = new $s(a, zc.output, Ac.output, cb.j, ec);
        O(E, zc);
        cb = Jn(a, J, e, K, m, Ac.output, ya, yc, ra.he, Pa, ec);
        J = cb.Qg;
        _.S(E, cb.Fa);
        mc = new at(a, M, K, f, bb.output, mc);
        O(E, mc);
        cb = new bt(a, window, dc, la.output, ec);
        O(E, cb);
        Le = new ct(a, Qs(K), n);
        O(E, Le);
        dc = new dt(a, x, Qs(K), cc, yb, ec);
        O(E, dc);
        Zc = new et(a, Zc, ud, Mf, ec);
        O(E, Zc);
        (ba = gr(a, ba, kl)) && _.S(E, ba);
        l = new ft(a, e, h, k, u, l, window, f, bb.output, zc.output, m, Ac.output, yc, Pa, ya, mc.output, Cb, $c, J.Rd, cb.output, Le.output, dc.output, Vh, X, ec);
        O(E, l);
        X = new gt(a, window, e, l.o, Mf);
        O(E, X);
        X = Qs(K);
        switch (X) {
            case 2:
            case 3:
                _.G(ht) ? O(E, new jt(a, h, Qs(K), e, window, cc, l.j, m, dc.output, yc)) : O(E, new kt(a, h, Qs(K), e, window, cc, l.j, m, dc.output, yc));
                break;
            case 5:
                O(E, new lt(a, e, k.dd, yb, n, l.j, m, Eg.output, dc.output, y));
                break;
            case 4:
                k = new mt(a, e, u, window, l.j, m);
                _.S(E, k);
                Yj(k);
                break;
            case 7:
                Ss(E, Zp(a, e, u, l.j, m));
                break;
            case 8:
            case 9:
                (k = Xq(a, X, x, l.j, Ac.output, yc)) && _.S(E, k)
        }
        k = new nt(a, e, l.j, n, u);
        O(E, k);
        k = new ot(a, e, pt(h, e), window.top);
        O(E, k);
        _.S(E, Ls(a, u, n, l.j, e));
        h = new qt(a, pt(h, e), window.top, l.j, la.output, k.output, k.j);
        O(E, h);
        O(E, new rt(a, e, ya, Fa, $c, l.j, Ac.output, l.B));
        e = new st(a, window, ce, l.j, Ac.output, m);
        O(E, e);
        _.S(E, kp(a, n, Nm(), M, c, b, d, D));
        O(E, new tt(a, Nm(), M, b, c, d, C));
        return E
    };
    xt = function(a, b, c) {
        var d = null;
        try {
            var e = vt(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.W,
                    h = c.R[f.getDomId()],
                    k;
                f = null == (k = Ri(f, h, b.document, No(g, h))) ? void 0 : k.y;
                k = ki(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++wt
            })
        } catch (f) {}
        return d
    };
    Ft = function(a) {
        return Rh(a.ha.context, 1132, function() {
            if (a.ia.X.length) {
                var b = new _.v.Set(bf(yt));
                for (var c = _.z(_.N(a.ha.V, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id".split(" ") : []), d = c.next(); !d.done; d = c.next()) b.add(d.value);
                d = new _.v.Map;
                c = _.z(zt);
                for (var e = c.next(); !e.done; e = c.next()) e = e.value, e(a, d);
                c = "https://" + (At(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
                d = _.z(d);
                for (e = d.next(); !e.done; e = d.next()) {
                    var f = _.z(e.value);
                    e = f.next().value;
                    var g = f.next().value;
                    f = g.value;
                    g = void 0 === g.options ? {} : g.options;
                    (new RegExp("[?&]" + e + "=")).test(c);
                    if (!b.has(e) && null != f) {
                        var h = void 0 === g.za ? "," : g.za,
                            k = void 0 === g.Ea ? !1 : g.Ea,
                            l = void 0 === g.Lb ? !1 : g.Lb;
                        if (f = "object" !== typeof f ? null == f || !k && 0 === f ? null : encodeURIComponent(f) : Array.isArray(f) && f.length ? _.G(Fo) && l || _.G(Bt) ? Ct(f, g) : encodeURIComponent(f.join(h)) : null) "?" !== c[c.length - 1] && (c += "&"), c += e + "=" + f
                    }
                }
                if (1 === _.$e(Dt) || 2 === _.$e(Dt)) b = _.$e(Et), b = 0 >= b ? "" : (_.H = _.A(Array, "from").call(Array, {
                    length: Math.ceil(b / 8)
                }), _.A(_.H, "fill")).call(_.H, "testdata").join("").substring(0, b), 2 === _.$e(Dt) && (c += "&dblt=" + b);
                b = c
            } else b = "";
            return b
        })
    };
    At = function(a) {
        var b = a.ha.V,
            c, d;
        a = null != (d = null == (c = Gt(a.ia.O.W)) ? void 0 : _.N(c, 9)) ? d : !1;
        c = _.N(b, 8);
        return a || c || !Uf(b)
    };
    Ct = function(a, b) {
        var c = void 0 === b.za ? "," : b.za,
            d = void 0 === b.ld ? "" : b.ld,
            e = void 0 === b.Ea ? !1 : b.Ea,
            f = !1;
        a = a.map(function(g) {
            f || (f = !!g);
            return String(0 === g && e ? g : g || d)
        });
        return f || e ? encodeURIComponent(a.join(c)) : null
    };
    It = function(a, b, c) {
        b = Ht(b, c);
        switch (b) {
            case 0:
                a();
                break;
            case 1:
                c.setTimeout(a, 0);
                break;
            case 2:
                c.scheduler.yield().then(a);
                break;
            default:
                _.eb(b)
        }
    };
    Ht = function(a, b) {
        if (0 === a) return 0;
        a = _.$e(Jt);
        switch (a) {
            case 0:
                return 0;
            case 1:
                return 1;
            case 6:
                var c;
                return (null == (c = b.scheduler) ? 0 : c.yield) ? 2 : 1;
            case 5:
                var d;
                return (null == (d = b.scheduler) ? 0 : d.yield) ? 2 : 0;
            default:
                _.eb(a)
        }
    };
    Kt = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.Wa.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.oh(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.nb(function(l) {
                if (1 == l.g) return d && clearTimeout(d), d = 0, f = new _.pg, g = b(f.resolve), h = ++e, l.yield(0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.yn(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    Mt = function(a, b) {
        a = a.X;
        var c = b.K,
            d = b.eb;
        b = b.Pk;
        if (!a.length) return {
            Od: []
        };
        for (var e = _.z(a), f = e.next(); !f.done; f = e.next()) op(c, f.value);
        return b ? {
            Od: []
        } : d ? (c = qh(a[0].getAdUnitPath()), {
            Od: Lt(a, c)
        }) : {
            Od: a.map(function(g) {
                return {
                    networkCode: qh(g.getAdUnitPath()),
                    X: [g]
                }
            })
        }
    };
    Lt = function(a, b) {
        var c = [];
        a = wa(a, function(f) {
            return qh(f.getAdUnitPath())
        });
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                networkCode: d,
                X: e
            }) : c.push({
                networkCode: d,
                X: e
            })
        }
        return c
    };
    Ot = function(a, b) {
        a = a.X;
        var c = function(d) {
            return !!li(b.R[d.getDomId()]).length
        };
        return {
            Ni: a.filter(c),
            Xi: a.filter(Nt(c))
        }
    };
    Wt = function() {
        var a = new Pt;
        var b = (new Qt).setCorrelator(_.Wh(_.t));
        var c = _.bg().join();
        b = _.uh(b, 5, c);
        b = _.I(b, 2, 1);
        a = _.wh(a, 1, b);
        b = new Rt;
        c = _.G(St);
        b = _.Ah(b, 7, c);
        c = _.G(Tt);
        b = _.Ah(b, 8, c);
        c = _.G(Ut);
        b = _.Ah(b, 9, c);
        b = _.Ah(b, 10, !0);
        c = _.G(Vt);
        b = _.Ah(b, 13, c);
        b = _.Ah(b, 16, !0);
        a = _.wh(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    $t = function() {
        var a = _.G(Xt) ? _.ef(Yt) : _.ef(Zt);
        _.on(document, a)
    };
    eu = function(a, b) {
        var c = au() || bu() ? 1 : _.gg(),
            d = .001 > c;
        d ? (b.j = !0, ag(31067358)) : .002 > c && ag(31067357);
        $l(23, a);
        a = 1E-4 > c;
        b = _.$e(cu);
        var e = 0 < b && c < b,
            f = _.$e(du);
        return {
            yc: d,
            Zh: 1E3,
            Mi: a,
            Yh: 1E4,
            Mg: d,
            Sf: 1E3,
            Nl: e,
            wl: b,
            Ll: 0 < f && c < 1 / f,
            cl: f,
            Ol: d,
            mh: c
        }
    };
    ju = function(a, b) {
        var c = _.A(Object, "assign").call(Object, {}, a);
        a = a.mh;
        c = (delete c.mh, c);
        var d = b.wb;
        /m\d+/.test(d) ? d = Number(d.substring(1)) : (d && Bj({
            mjsv: d
        }, "gpt_inv_ver"), d = void 0);
        var e = window.document.URL,
            f = _.$e(fu);
        f = new gu(4, b.wb, f);
        return _.A(Object, "assign").call(Object, {}, b, c, {
            On: new hu(b)
        }, {
            tc: d,
            Ga: f,
            Nf: e,
            Hn: 2012,
            kg: new iu(f, a)
        })
    };
    _.ku = function(a) {
        var b;
        a = (null != (b = void 0 === a ? null : a) ? b : window).googletag;
        return (null == a ? 0 : a.apiReady) ? a : void 0
    };
    _.aa = [];
    lu = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    mu = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    nu = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.ou = nu(this);
    pu = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.v = {};
    qu = {};
    _.A = function(a, b, c) {
        if (!c || null != a) {
            c = qu[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    ru = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.v ? f = _.v : f = _.ou;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = pu && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? mu(_.v, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === qu[d] && (a = 1E9 * Math.random() >>> 0, qu[d] = pu ? _.ou.Symbol(d) : "$jscp$" + a + "$" + d), mu(f, qu[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    ru("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            mu(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    ru("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.v.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.ou[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && mu(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return su(lu(this))
                }
            })
        }
        return a
    }, "es6");
    su = function(a) {
        a = {
            next: a
        };
        a[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.tu = function(a) {
        return a.raw = a
    };
    uu = function(a, b) {
        a.raw = b;
        return a
    };
    _.z = function(a) {
        var b = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && a[_.A(_.v.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: lu(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.oh = function(a) {
        if (!(a instanceof Array)) {
            a = _.z(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    vu = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    wu = pu && "function" == typeof _.A(Object, "assign") ? _.A(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) vu(d, e) && (a[e] = d[e])
        }
        return a
    };
    ru("Object.assign", function(a) {
        return a || wu
    }, "es6");
    var xu = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        yu = function() {
            function a() {
                function c() {}
                new c;
                Reflect.construct(c, [], function() {});
                return new c instanceof c
            }
            if (pu && "undefined" != typeof Reflect && Reflect.construct) {
                if (a()) return Reflect.construct;
                var b = Reflect.construct;
                return function(c, d, e) {
                    c = b(c, d);
                    e && Reflect.setPrototypeOf(c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = xu(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        zu;
    if (pu && "function" == typeof _.A(Object, "setPrototypeOf")) zu = _.A(Object, "setPrototypeOf");
    else {
        var Au;
        a: {
            var Bu = {
                    a: !0
                },
                Cu = {};
            try {
                Cu.__proto__ = Bu;
                Au = Cu.a;
                break a
            } catch (a) {}
            Au = !1
        }
        zu = Au ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    Du = zu;
    _.T = function(a, b) {
        a.prototype = xu(b.prototype);
        a.prototype.constructor = a;
        if (Du) Du(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Wl = b.prototype
    };
    Eu = function() {
        this.j = !1;
        this.v = null;
        this.m = void 0;
        this.g = 1;
        this.H = this.l = 0;
        this.J = null
    };
    Fu = function(a) {
        if (a.j) throw new TypeError("Generator is already running");
        a.j = !0
    };
    Eu.prototype.G = function(a) {
        this.m = a
    };
    var Gu = function(a, b) {
        a.J = {
            exception: b,
            Mk: !0
        };
        a.g = a.l || a.H
    };
    Eu.prototype.return = function(a) {
        this.J = {
            return: a
        };
        this.g = this.H
    };
    Eu.prototype.yield = function(a, b) {
        this.g = b;
        return {
            value: a
        }
    };
    pb = function(a) {
        a.l = 0;
        var b = a.J.exception;
        a.J = null;
        return b
    };
    Hu = function(a) {
        this.g = new Eu;
        this.m = a
    };
    Ku = function(a, b) {
        Fu(a.g);
        var c = a.g.v;
        if (c) return Iu(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.g.return);
        a.g.return(b);
        return Ju(a)
    };
    Iu = function(a, b, c, d) {
        try {
            var e = b.call(a.g.v, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.g.j = !1, e;
            var f = e.value
        } catch (g) {
            return a.g.v = null, Gu(a.g, g), Ju(a)
        }
        a.g.v = null;
        d.call(a.g, f);
        return Ju(a)
    };
    Ju = function(a) {
        for (; a.g.g;) try {
            var b = a.m(a.g);
            if (b) return a.g.j = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.g.m = void 0, Gu(a.g, c)
        }
        a.g.j = !1;
        if (a.g.J) {
            b = a.g.J;
            a.g.J = null;
            if (b.Mk) throw b.exception;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    Lu = function(a) {
        this.next = function(b) {
            Fu(a.g);
            a.g.v ? b = Iu(a, a.g.v.next, b, a.g.G) : (a.g.G(b), b = Ju(a));
            return b
        };
        this.throw = function(b) {
            Fu(a.g);
            a.g.v ? b = Iu(a, a.g.v["throw"], b, a.g.G) : (Gu(a.g, b), b = Ju(a));
            return b
        };
        this.return = function(b) {
            return Ku(a, b)
        };
        this[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        }
    };
    Mu = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.v.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.v.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.nb = function(a) {
        return Mu(new Lu(new Hu(a)))
    };
    _.Wa = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    ru("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    ru("Reflect.construct", function() {
        return yu
    }, "es6");
    ru("Reflect.setPrototypeOf", function(a) {
        return a ? a : Du ? function(b, c) {
            try {
                return Du(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    ru("Promise", function(a) {
        function b() {
            this.g = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.m = function(g) {
            if (null == this.g) {
                this.g = [];
                var h = this;
                this.l(function() {
                    h.J()
                })
            }
            this.g.push(g)
        };
        var d = _.ou.setTimeout;
        b.prototype.l = function(g) {
            d(g, 0)
        };
        b.prototype.J = function() {
            for (; this.g && this.g.length;) {
                var g = this.g;
                this.g = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.v(l)
                    }
                }
            }
            this.g = null
        };
        b.prototype.v = function(g) {
            this.l(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.m = 0;
            this.l = void 0;
            this.g = [];
            this.G = !1;
            var h = this.v();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.v = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.sa),
                reject: g(this.J)
            }
        };
        e.prototype.sa = function(g) {
            if (g === this) this.J(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.I(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.B(g) : this.j(g)
            }
        };
        e.prototype.B = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.J(k);
                return
            }
            "function" == typeof h ? this.M(h, g) : this.j(g)
        };
        e.prototype.J = function(g) {
            this.H(2, g)
        };
        e.prototype.j = function(g) {
            this.H(1, g)
        };
        e.prototype.H = function(g, h) {
            if (0 != this.m) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.m);
            this.m = g;
            this.l = h;
            2 === this.m && this.F();
            this.L()
        };
        e.prototype.F = function() {
            var g = this;
            d(function() {
                if (g.o()) {
                    var h = _.ou.console;
                    "undefined" !== typeof h && h.error(g.l)
                }
            }, 1)
        };
        e.prototype.o = function() {
            if (this.G) return !1;
            var g = _.ou.CustomEvent,
                h = _.ou.Event,
                k = _.ou.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.ou.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.l;
            return k(g)
        };
        e.prototype.L = function() {
            if (null != this.g) {
                for (var g = 0; g < this.g.length; ++g) f.m(this.g[g]);
                this.g = null
            }
        };
        var f = new b;
        e.prototype.I = function(g) {
            var h = this.v();
            g.me(h.resolve, h.reject)
        };
        e.prototype.M = function(g, h) {
            var k = this.v();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(w) {
                    try {
                        l(p(w))
                    } catch (u) {
                        m(u)
                    }
                } : r
            }
            var l, m, n = new e(function(p, r) {
                l = p;
                m = r
            });
            this.me(k(g, l), k(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.me = function(g, h) {
            function k() {
                switch (l.m) {
                    case 1:
                        g(l.l);
                        break;
                    case 2:
                        h(l.l);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.m);
                }
            }
            var l = this;
            null == this.g ? f.m(k) : this.g.push(k);
            this.G = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.z(g), m = l.next(); !m.done; m = l.next()) c(m.value).me(h, k)
            })
        };
        e.all = function(g) {
            var h = _.z(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function n(w) {
                    return function(u) {
                        p[w] = u;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).me(n(p.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    ru("Object.setPrototypeOf", function(a) {
        return a || Du
    }, "es6");
    ru("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.z(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!vu(g, d)) {
                var k = new b;
                mu(g, d, {
                    value: k
                })
            }
            if (!vu(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && vu(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && vu(g, d) && vu(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && vu(g, d) && vu(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    ru("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.z([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.A(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.v.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = _.z(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.Ra ? l.Ra.value = k : (l.Ra = {
                next: this[1],
                Eb: this[1].Eb,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.Ra), this[1].Eb.next = l.Ra, this[1].Eb = l.Ra, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.Ra && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.Ra.Eb.next = h.Ra.next, h.Ra.next.Eb = h.Ra.Eb, h.Ra.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Eb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).Ra
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).Ra) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.A(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[_.A(_.v.Symbol, "iterator")] = _.A(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && vu(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            Ra: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    Ra: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return su(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.Eb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Eb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var Nu = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.A(_.v.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    ru("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Nu(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    ru("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Nu(this, function(b) {
                return b
            })
        }
    }, "es6");
    var Ou = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    ru("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var Pu = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                Mh: e,
                Zi: f
            }
        }
        return {
            Mh: -1,
            Zi: void 0
        }
    };
    ru("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return Pu(this, b, c).Zi
        }
    }, "es6");
    ru("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    }, "es6");
    ru("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) vu(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    ru("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    ru("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.A(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    ru("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Ou(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    ru("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.z([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.A(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new _.v.Map;
            if (c) {
                c = _.z(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return _.A(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return _.A(this.g, "values").call(this.g)
        };
        b.prototype.keys = _.A(b.prototype, "values");
        b.prototype[_.A(_.v.Symbol, "iterator")] = _.A(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    ru("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    ru("Number.EPSILON", function() {
        return Math.pow(2, -52)
    }, "es6");
    ru("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    ru("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    ru("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isInteger").call(Number, b) && Math.abs(b) <= _.A(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    ru("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    }, "es6");
    ru("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Nu(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    ru("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && b[_.A(_.v.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    ru("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    }, "es6");
    var Qu = function(a) {
        return a ? a : _.A(Array.prototype, "fill")
    };
    ru("Int8Array.prototype.fill", Qu, "es6");
    ru("Uint8Array.prototype.fill", Qu, "es6");
    ru("Uint8ClampedArray.prototype.fill", Qu, "es6");
    ru("Int16Array.prototype.fill", Qu, "es6");
    ru("Uint16Array.prototype.fill", Qu, "es6");
    ru("Int32Array.prototype.fill", Qu, "es6");
    ru("Uint32Array.prototype.fill", Qu, "es6");
    ru("Float32Array.prototype.fill", Qu, "es6");
    ru("Float64Array.prototype.fill", Qu, "es6");
    ru("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) vu(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    ru("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    ru("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ou(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    ru("globalThis", function(a) {
        return a || _.ou
    }, "es_2020");
    ru("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ou(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? _.A(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    ru("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.T(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    ru("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.A(Array, "from").call(Array, b);
            return _.v.Promise.all(b.map(function(c) {
                return _.v.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.v.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    ru("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return Pu(this, b, c).Mh
        }
    }, "es6");
    ru("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.A(_.v.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.A(_.v.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    ru("Object.hasOwn", function(a) {
        return a ? a : function(b, c) {
            return Object.prototype.hasOwnProperty.call(b, c)
        }
    }, "es_next");
    ru("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    ru("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.A(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    ru("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    ru("Math.sign", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            return 0 === b || isNaN(b) ? b : 0 < b ? 1 : -1
        }
    }, "es6");
    ru("String.fromCodePoint", function(a) {
        return a ? a : function(b) {
            for (var c = "", d = 0; d < arguments.length; d++) {
                var e = Number(arguments[d]);
                if (0 > e || 1114111 < e || e !== Math.floor(e)) throw new RangeError("invalid_code_point " + e);
                65535 >= e ? c += String.fromCharCode(e) : (e -= 65536, c += String.fromCharCode(e >>> 10 & 1023 | 55296), c += String.fromCharCode(e & 1023 | 56320))
            }
            return c
        }
    }, "es6");
    ru("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    var Ru, Hc, Su, Tu, Uu, Vu;
    _.t = this || self;
    Ru = function(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = _.t, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    };
    Hc = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    };
    _.ta = function(a) {
        var b = Hc(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.ka = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    _.ma = function(a) {
        return Object.prototype.hasOwnProperty.call(a, Su) && a[Su] || (a[Su] = ++Tu)
    };
    Su = "closure_uid_" + (1E9 * Math.random() >>> 0);
    Tu = 0;
    Uu = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    Vu = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.Wu = function(a, b, c) {
        _.Wu = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Uu : Vu;
        return _.Wu.apply(null, arguments)
    };
    _.Xu = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    var Yu;
    var cv, $u, Zu;
    _.av = function(a, b) {
        this.g = a === Zu && b || "";
        this.m = $u
    };
    _.av.prototype.nb = !0;
    _.av.prototype.Xa = function() {
        return this.g
    };
    _.av.prototype.toString = function() {
        return this.g
    };
    _.bv = function(a) {
        return a instanceof _.av && a.constructor === _.av && a.m === $u ? a.g : "type_error:Const"
    };
    cv = function(a) {
        return new _.av(Zu, a)
    };
    $u = {};
    Zu = {};
    var sb = cv("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var dv, Nt, Mi;
    dv = function() {
        return !0
    };
    Nt = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    Mi = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.ev = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    _.fv = function(a, b) {
        var c = 0,
            d = !1,
            e = [],
            f = function() {
                c = 0;
                d && (d = !1, g())
            },
            g = function() {
                c = _.t.setTimeout(f, b);
                var h = e;
                e = [];
                a.apply(void 0, h)
            };
        return function(h) {
            e = arguments;
            c ? d = !0 : g()
        }
    };
    var da;
    _.gv = {
        passive: !0
    };
    da = Mi(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.t.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.lb = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, ea(d)), !0) : !1
    };
    _.Ef = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, ea(d)), !0) : !1
    };
    _.fa = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.hv = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.bh = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.iv = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    _.dh = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var Dc = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Da = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var jv = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var hf;
    hf = {};
    _.gf = function(a) {
        this.g = a;
        this.nb = !0
    };
    _.gf.prototype.toString = function() {
        return this.g.toString()
    };
    _.gf.prototype.Xa = function() {
        return this.g.toString()
    };
    _.hb = function(a) {
        return a instanceof _.gf && a.constructor === _.gf ? a.g : "type_error:SafeScript"
    };
    var rb, pv, ov, lv, qv, df, mv;
    _.kv = function(a) {
        this.g = a
    };
    _.kv.prototype.toString = function() {
        return this.g + ""
    };
    _.kv.prototype.nb = !0;
    _.kv.prototype.Xa = function() {
        return this.g.toString()
    };
    _.nv = function(a, b) {
        a = lv.exec(_.jb(a).toString());
        var c = a[3] || "";
        return df(a[1] + mv("?", a[2] || "", b) + mv("#", c))
    };
    _.jb = function(a) {
        return a instanceof _.kv && a.constructor === _.kv ? a.g : "type_error:TrustedResourceUrl"
    };
    rb = function(a, b) {
        var c = _.bv(a);
        if (!ov.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(pv, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.av ? _.bv(d) : encodeURIComponent(String(d))
        });
        return df(a)
    };
    pv = /%{(\w+)}/g;
    ov = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    lv = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    qv = {};
    df = function(a) {
        return new _.kv(a, qv)
    };
    mv = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var rv, gl, sv, Av, uv, vv, wv, xv, yv, zv, tv;
    rv = function(a, b) {
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    };
    gl = function(a) {
        return /^[\s\xa0]*$/.test(a)
    };
    sv = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };
    Av = function(a) {
        if (!tv.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(uv, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(vv, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(wv, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(xv, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(yv, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(zv, "&#0;"));
        return a
    };
    uv = /&/g;
    vv = /</g;
    wv = />/g;
    xv = /"/g;
    yv = /'/g;
    zv = /\x00/g;
    tv = /[\x00&<>"']/;
    _.Ja = function(a, b) {
        return -1 != a.indexOf(b)
    };
    var Bv, Cv, Ev, Gv;
    _.Sa = function(a) {
        this.g = a
    };
    _.Sa.prototype.toString = function() {
        return this.g.toString()
    };
    _.Sa.prototype.nb = !0;
    _.Sa.prototype.Xa = function() {
        return this.g.toString()
    };
    _.$a = function(a) {
        return a instanceof _.Sa && a.constructor === _.Sa ? a.g : "type_error:SafeUrl"
    };
    Bv = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    Cv = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.Dv = function(a) {
        if (a instanceof _.Sa) return a;
        a = "object" == typeof a && a.nb ? a.Xa() : String(a);
        Cv.test(a) ? a = _.Ta(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(Bv) ? _.Ta(a) : null);
        return a
    };
    try {
        new URL("s://g"), Ev = !0
    } catch (a) {
        Ev = !1
    }
    _.Fv = Ev;
    Gv = {};
    _.Ta = function(a) {
        return new _.Sa(a, Gv)
    };
    _.Ua = _.Ta("about:invalid#zClosurez");
    _.Hv = {};
    _.Iv = function(a) {
        this.g = a;
        this.nb = !0
    };
    _.Iv.prototype.Xa = function() {
        return this.g
    };
    _.Iv.prototype.toString = function() {
        return this.g.toString()
    };
    _.Jv = new _.Iv("", _.Hv);
    _.Kv = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Lv = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Mv = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    var Nv;
    Nv = {};
    _.Ov = function(a) {
        this.g = a;
        this.nb = !0
    };
    _.Ov.prototype.toString = function() {
        return this.g.toString()
    };
    _.Ov.prototype.Xa = function() {
        return this.g
    };
    _.Pv = function(a) {
        return a instanceof _.Ov && a.constructor === _.Ov ? a.g : "type_error:SafeStyleSheet"
    };
    var Ha = Ru(610401301, !1),
        Qv = Ru(572417392, !0);
    var Ia, Rv = _.t.navigator;
    Ia = Rv ? Rv.userAgentData || null : null;
    var Sv, Vv, $v, Wv, bw, Xv, Zv;
    Sv = {};
    _.Tv = function(a) {
        this.g = a;
        this.nb = !0
    };
    _.Tv.prototype.Xa = function() {
        return this.g.toString()
    };
    _.Tv.prototype.toString = function() {
        return this.g.toString()
    };
    _.Uv = function(a) {
        return a instanceof _.Tv && a.constructor === _.Tv ? a.g : "type_error:SafeHtml"
    };
    Vv = function(a) {
        return a instanceof _.Tv ? a : _.yj(Av("object" == typeof a && a.nb ? a.Xa() : String(a)))
    };
    _.Yv = function(a) {
        if (!Wv.test(a)) throw Error("");
        if (a.toUpperCase() in Xv) throw Error("");
    };
    $v = function(a) {
        var b = Vv(Zv),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = Vv(e), c.push(_.Uv(e).toString()))
            };
        a.forEach(d);
        return _.yj(c.join(_.Uv(b).toString()))
    };
    _.aw = function(a) {
        return $v(Array.prototype.slice.call(arguments))
    };
    _.yj = function(a) {
        return new _.Tv(a, Sv)
    };
    _.cw = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!Wv.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.av) f = _.bv(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in bw)
                                if (f instanceof _.kv) f = _.jb(f).toString();
                                else if (f instanceof _.Sa) f = _.$a(f);
                            else if ("string" === typeof f) f = (_.Dv(f) || _.Ua).Xa();
                            else throw Error("");
                        }
                        f.nb && (f = f.Xa());
                        f = g + '="' + Av(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === jv[a.toLowerCase()] ? b += ">" : (c = _.aw(c), b += ">" + _.Uv(c).toString() + "</" + a + ">");
        return _.yj(b)
    };
    Wv = /^[a-zA-Z0-9-]+$/;
    bw = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    Xv = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    Zv = new _.Tv(_.t.trustedTypes && _.t.trustedTypes.emptyHTML || "", Sv);
    _.dw = _.yj("<br>");
    var Oa = function(a) {
            this.Rk = a
        },
        Ra = [Qa("data"), Qa("http"), Qa("https"), Qa("mailto"), Qa("ftp"), new Oa(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })],
        Ya = "function" === typeof URL;
    var ew = {
            Om: 0,
            Rm: 1,
            Mm: 2,
            Nm: 3,
            0: "FORMATTED_HTML_CONTENT",
            1: "HTML_FORMATTED_CONTENT",
            2: "EMBEDDED_INTERNAL_CONTENT",
            3: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        fw = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + ew[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.T(fw, Error);
    var ob = function(a) {
        return new _.v.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var wb, vb = "function" === typeof String.prototype.g,
        ub = "undefined" !== typeof TextEncoder;
    _.gw = function(a) {
        _.gw[" "](a);
        return a
    };
    _.gw[" "] = function() {};
    var hw = function(a, b) {
        try {
            return _.gw(a[b]), !0
        } catch (c) {}
        return !1
    };
    var iw, kw, lw, mw, nw, ow;
    iw = Ma() ? !1 : La("Opera");
    _.jw = Ma() ? !1 : La("Trident") || La("MSIE");
    kw = La("Edge");
    lw = La("Gecko") && !(_.Ja(Ga().toLowerCase(), "webkit") && !La("Edge")) && !(La("Trident") || La("MSIE")) && !La("Edge");
    mw = _.Ja(Ga().toLowerCase(), "webkit") && !La("Edge");
    nw = function() {
        var a = _.t.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var pw = "",
            qw = function() {
                var a = Ga();
                if (lw) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (kw) return /Edge\/([\d\.]+)/.exec(a);
                if (_.jw) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (mw) return /WebKit\/(\S+)/.exec(a);
                if (iw) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();qw && (pw = qw ? qw[1] : "");
        if (_.jw) {
            var rw = nw();
            if (null != rw && rw > parseFloat(pw)) {
                ow = String(rw);
                break a
            }
        }
        ow = pw
    }
    var sw = ow,
        tw;
    if (_.t.document && _.jw) {
        var uw = nw();
        tw = uw ? uw : parseInt(sw, 10) || void 0
    } else tw = void 0;
    var vw = tw;
    !La("Android") || Na();
    Na();
    La("Safari") && (Na() || (Ma() ? 0 : La("Coast")) || (Ma() ? 0 : La("Opera")) || (Ma() ? 0 : La("Edge")) || (Ma() ? Ka("Microsoft Edge") : La("Edg/")) || Ma() && Ka("Opera"));
    var ww = {},
        xw = null,
        yw = lw || mw || "function" == typeof _.t.btoa,
        Bb = function(a, b) {
            void 0 === b && (b = 0);
            zw();
            b = ww[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        Aw = function(a, b) {
            if (yw && !b) a = _.t.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Bb(c, b)
            }
            return a
        },
        Cq = function(a) {
            var b = "";
            Bw(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        lf = function(a) {
            var b = [];
            Bw(a, function(c) {
                b.push(c)
            });
            return b
        },
        Cw = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : _.Ja("=.", a[b - 1]) && (c = _.Ja("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Bw(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Bw = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = xw[l];
                    if (null != m) return m;
                    if (!gl(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            zw();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        zw = function() {
            if (!xw) {
                xw = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    ww[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === xw[f] && (xw[f] = e)
                    }
                }
            }
        };
    var Hb = "undefined" !== typeof Uint8Array,
        Ab = !_.jw && "function" === typeof btoa,
        Dw = /[-_.]/g,
        Fb = {
            "-": "+",
            _: "/",
            ".": "="
        },
        Ew, Jb = {};
    var Fw, qc = function(a, b) {
            Kb(b);
            this.fa = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        rc = function() {
            return Fw || (Fw = new qc(null, Jb))
        },
        Fd = function(a) {
            var b = a.fa;
            return null == b ? "" : "string" === typeof b ? b : a.fa = Db(b)
        },
        Kk = function(a) {
            Kb(Jb);
            var b = a.fa;
            if (null != b && !Ib(b))
                if ("string" === typeof b)
                    if (Ab) {
                        Dw.test(b) && (b = b.replace(Dw, Gb));
                        b = atob(b);
                        for (var c = new Uint8Array(b.length), d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                        b = c
                    } else b = Cw(b);
            else b = null;
            return (a = null == b ? b : a.fa = b) ? new Uint8Array(a) : Ew || (Ew = new Uint8Array(0))
        };
    qc.prototype.isEmpty = function() {
        return null == this.fa
    };
    var Id = !Qv,
        re = !Qv;
    var Nb = 0,
        Ob = 0,
        Gw;
    var Hw = function(a, b) {
            this.m = a >>> 0;
            this.g = b >>> 0
        },
        Jw = function(a) {
            if (!a) return Iw || (Iw = new Hw(0, 0));
            if (!/^\d+$/.test(a)) return null;
            Vb(a);
            return new Hw(Nb, Ob)
        },
        Iw, Kw = function(a, b) {
            this.m = a >>> 0;
            this.g = b >>> 0
        },
        Ie = function(a) {
            if (!a) return Lw || (Lw = new Kw(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            Vb(a);
            return new Kw(Nb, Ob)
        },
        Lw;
    var Mw = function() {
        this.g = []
    };
    Mw.prototype.length = function() {
        return this.g.length
    };
    Mw.prototype.end = function() {
        var a = this.g;
        this.g = [];
        return a
    };
    var Ke = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.g.push(b)
        },
        Je = function(a, b) {
            for (; 127 < b;) a.g.push(b & 127 | 128), b >>>= 7;
            a.g.push(b)
        },
        Nw = function(a, b) {
            if (0 <= b) Je(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.g.push(b & 127 | 128), b >>= 7;
                a.g.push(1)
            }
        };
    var Re = function() {
            this.l = [];
            this.m = 0;
            this.g = new Mw
        },
        Ne = function(a, b) {
            0 !== b.length && (a.l.push(b), a.m += b.length)
        },
        Ow = function(a, b, c) {
            Je(a.g, 8 * b + 2);
            Je(a.g, c.length);
            Ne(a, a.g.end());
            Ne(a, c)
        };
    var Ce = function(a, b) {
        this.g = a;
        this.ij = b
    };
    var Pw = Xb(),
        od = Xb("0di"),
        Ud = Xb("0dg");
    var bc = Pw ? function(a, b) {
            a[Pw] |= b
        } : function(a, b) {
            void 0 !== a.ob ? a.ob |= b : Object.defineProperties(a, {
                ob: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        },
        Zd = Pw ? function(a, b) {
            a[Pw] &= ~b
        } : function(a, b) {
            void 0 !== a.ob && (a.ob &= ~b)
        },
        Yb = Pw ? function(a) {
            return a[Pw] | 0
        } : function(a) {
            return a.ob | 0
        },
        Pd = Pw ? function(a) {
            return a[Pw]
        } : function(a) {
            return a.ob
        },
        Zb = Pw ? function(a, b) {
            a[Pw] = b
        } : function(a, b) {
            void 0 !== a.ob ? a.ob = b : Object.defineProperties(a, {
                ob: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };
    var ld = {},
        lc = {},
        Qw, Ed = !Qv,
        Yd, Rw = [];
    Zb(Rw, 55);
    Yd = Object.freeze(Rw);
    var Sw = function(a, b, c) {
        this.l = 0;
        this.g = a;
        this.m = b;
        this.v = c
    };
    Sw.prototype.next = function() {
        if (this.l < this.g.length) {
            var a = this.g[this.l++];
            return {
                done: !1,
                value: this.m ? this.m.call(this.v, a) : a
            }
        }
        return {
            done: !0,
            value: void 0
        }
    };
    Sw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return new Sw(this.g, this.m, this.v)
    };
    var ge = {};
    Object.freeze(new function() {});
    Object.freeze(new function() {});
    var vc;
    var Lc = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
    var rd, td, vd;
    var Tw = function() {
            try {
                var a = function() {
                    return yu(_.v.Map, [], this.constructor)
                };
                _.T(a, _.v.Map);
                new a;
                return !1
            } catch (b) {
                return !0
            }
        }(),
        Uw = function() {
            this.g = new _.v.Map
        };
    _.q = Uw.prototype;
    _.q.get = function(a) {
        return this.g.get(a)
    };
    _.q.set = function(a, b) {
        this.g.set(a, b);
        this.size = this.g.size;
        return this
    };
    _.q.delete = function(a) {
        a = this.g.delete(a);
        this.size = this.g.size;
        return a
    };
    _.q.clear = function() {
        this.g.clear();
        this.size = this.g.size
    };
    _.q.has = function(a) {
        return this.g.has(a)
    };
    _.q.entries = function() {
        return _.A(this.g, "entries").call(this.g)
    };
    _.q.keys = function() {
        return _.A(this.g, "keys").call(this.g)
    };
    _.q.values = function() {
        return _.A(this.g, "values").call(this.g)
    };
    _.q.forEach = function(a, b) {
        return this.g.forEach(a, b)
    };
    Uw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    var Vw = function() {
            if (Tw) return _.A(Object, "setPrototypeOf").call(Object, Uw.prototype, _.v.Map.prototype), Object.defineProperties(Uw.prototype, {
                size: {
                    value: 0,
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }
            }), Uw;
            var a = function() {
                return yu(_.v.Map, [], this.constructor)
            };
            _.T(a, _.v.Map);
            return a
        }(),
        Gd = function(a, b, c, d) {
            c = void 0 === c ? xd : c;
            d = void 0 === d ? xd : d;
            var e = Vw.call(this) || this;
            var f = Yb(a);
            f |= 64;
            Zb(a, f);
            e.ee = f;
            e.tf = b;
            e.Ed = c || xd;
            e.Vg = e.tf ? zd : d || xd;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    k = c(h[0], !1, !0),
                    l = h[1];
                b ? void 0 === l && (l = null) : l = d(h[1], !1, !0, void 0, void 0, f);
                Vw.prototype.set.call(e, k, l)
            }
            return e
        };
    _.T(Gd, Vw);
    var Ww = function(a) {
            if (a.ee & 2) throw Error("Cannot mutate an immutable Map");
        },
        Hd = function(a, b) {
            b = void 0 === b ? Ad : b;
            return Rd(a, b)
        },
        Rd = function(a, b) {
            b = void 0 === b ? Ad : b;
            var c = [];
            a = _.A(Vw.prototype, "entries").call(a);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.q = Gd.prototype;
    _.q.clear = function() {
        Ww(this);
        Vw.prototype.clear.call(this)
    };
    _.q.delete = function(a) {
        Ww(this);
        return Vw.prototype.delete.call(this, this.Ed(a, !0, !1))
    };
    _.q.entries = function() {
        var a = _.A(Array, "from").call(Array, _.A(Vw.prototype, "keys").call(this));
        return new Sw(a, Bd, this)
    };
    _.q.keys = function() {
        return _.A(Vw.prototype, "keys").call(this)
    };
    _.q.values = function() {
        var a = _.A(Array, "from").call(Array, _.A(Vw.prototype, "keys").call(this));
        return new Sw(a, Gd.prototype.get, this)
    };
    _.q.forEach = function(a, b) {
        var c = this;
        Vw.prototype.forEach.call(this, function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    _.q.set = function(a, b) {
        Ww(this);
        a = this.Ed(a, !0, !1);
        return null == a ? this : null == b ? (Vw.prototype.delete.call(this, a), this) : Vw.prototype.set.call(this, a, this.Vg(b, !0, !0, this.tf, !1, this.ee))
    };
    _.q.has = function(a) {
        return Vw.prototype.has.call(this, this.Ed(a, !1, !1))
    };
    _.q.get = function(a) {
        a = this.Ed(a, !1, !1);
        var b = Vw.prototype.get.call(this, a);
        if (void 0 !== b) {
            var c = this.tf;
            return c ? (c = this.Vg(b, !1, !0, c, this.Hj, this.ee), c !== b && Vw.prototype.set.call(this, a, c), c) : b
        }
    };
    Gd.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    Gd.prototype.toJSON = void 0;
    Gd.prototype.Xk = lc;
    var mo, Xd, Mn, Np, Yl, Lk, fe, Ek, Mk, Jk, Uo, Xw, us, Mj, Mp, fi, Yw, Zw, Lr, ir, ax, cx, dx, Mo, ex, fx, gx, Lj, Zn, hx;
    mo = function(a, b) {
        a = a.C;
        return Xd(a, Pd(a), b)
    };
    Xd = function(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= kc(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    };
    _.Gi = function(a, b, c) {
        var d = a.C,
            e = Pd(d);
        uc(e);
        Wd(d, e, b, c);
        return a
    };
    Mn = function(a, b, c) {
        return void 0 !== Xw(a, b, c, !1)
    };
    Np = function(a) {
        a = a.C;
        var b = Pd(a),
            c = Xd(a, b, 3),
            d = Gc(c);
        null != d && d !== c && Wd(a, b, 3, d);
        return d
    };
    Yl = function(a, b) {
        return Kc(mo(a, b))
    };
    Lk = function(a, b) {
        a = a.C;
        var c = Pd(a),
            d = Xd(a, c, b),
            e = sc(d, !0, !!(c & 34));
        null != e && e !== d && Wd(a, c, b, e);
        return null == e ? rc() : e
    };
    _.Zh = function(a, b, c) {
        return _.le(a, b, c, id)
    };
    Ek = function(a, b, c, d) {
        var e = a.C,
            f = Pd(e);
        uc(f);
        (c = ne(e, f, c)) && c !== b && null != d && (f = Wd(e, f, c));
        Wd(e, f, b, d);
        return a
    };
    Mk = function(a, b, c) {
        a = a.C;
        return ne(a, Pd(a), b) === c ? c : -1
    };
    Jk = function(a, b) {
        a = a.C;
        return ne(a, Pd(a), b)
    };
    Uo = function(a, b, c) {
        a = a.C;
        var d = Pd(a);
        uc(d);
        var e = Xd(a, d, c);
        b = yd(nd(e, b, !0, d));
        e !== b && Wd(a, d, c, b);
        return b
    };
    Xw = function(a, b, c, d) {
        a = a.C;
        var e = Pd(a),
            f = Xd(a, e, c, d);
        b = nd(f, b, !1, e);
        b !== f && null != b && Wd(a, e, c, b, d);
        return b
    };
    us = function(a, b, c) {
        return (a = Xw(a, b, c, !1)) ? a : md(b)
    };
    _.di = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = Xw(a, b, c, d);
        if (null == b) return b;
        a = a.C;
        var e = Pd(a);
        if (!(e & 2)) {
            var f = yd(b);
            f !== b && (b = f, Wd(a, e, c, b, d))
        }
        return b
    };
    _.gi = function(a, b, c) {
        a = a.C;
        var d = Pd(a),
            e = !!(2 & d);
        return oe(a, d, b, c, e ? 1 : 2, !1, !e)
    };
    _.wh = function(a, b, c) {
        null == c && (c = void 0);
        return _.Gi(a, b, c)
    };
    _.Ch = function(a, b, c, d) {
        null == d && (d = void 0);
        return Ek(a, b, c, d)
    };
    _.ul = function(a, b, c) {
        var d = a.C,
            e = Pd(d);
        uc(e);
        if (null == c) return Wd(d, e, b), a;
        for (var f = Yb(c), g = f, h = !!(2 & f) || !!(2048 & f), k = h || Object.isFrozen(c), l = !0, m = !0, n = 0; n < c.length; n++) {
            var p = c[n];
            h || (p = !!(Yb(p.C) & 2), l && (l = !p), m && (m = p))
        }
        h || (f = ac(f, 5, !0), f = ac(f, 8, l), f = ac(f, 16, m));
        k && f !== g && (c = Wb(c), g = 0, f = ae(f, e, !0));
        f !== g && Zb(c, f);
        Wd(d, e, b, c);
        return a
    };
    Mj = function(a, b, c, d) {
        pe(a, b, c, d);
        return a
    };
    Mp = function(a, b) {
        return Qc(mo(a, b))
    };
    fi = function(a, b) {
        return Tc(mo(a, b))
    };
    Yw = function(a, b) {
        a = mo(a, b);
        var c;
        null == a ? c = a : Mc(a) ? "number" === typeof a ? c = dd(a) : c = ed(a) : c = void 0;
        return c
    };
    Zw = function(a, b) {
        return be(a, b, fd, 2, void 0, void 0, 0)
    };
    _.Gj = function(a, b) {
        return kd(mo(a, b))
    };
    _.xo = function(a, b, c, d, e) {
        return be(a, b, kd, c, d, e)
    };
    _.N = function(a, b, c) {
        return qe(Yl(a, b), void 0 === c ? !1 : c)
    };
    _.$w = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return qe(Mp(a, b), c)
    };
    Lr = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return qe(fi(a, b), c)
    };
    _.Cf = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return qe(fd(mo(a, b)), c)
    };
    ir = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return qe(Yw(a, b), c)
    };
    _.R = function(a, b) {
        return qe(_.Gj(a, b), "")
    };
    _.Nk = function(a, b, c) {
        return qe(mo(a, b), void 0 === c ? 0 : c)
    };
    ax = function(a, b, c) {
        a = _.xo(a, b, 3, void 0, !0);
        if ("number" !== typeof c || 0 > c || c >= a.length) throw Error();
        return a[c]
    };
    cx = function(a) {
        return _.Cf(a, Mk(a, bx, 3))
    };
    dx = function(a, b) {
        return _.R(a, Mk(a, b, 2))
    };
    Mo = function(a, b) {
        a = Yl(a, b);
        return null == a ? void 0 : a
    };
    ex = function(a, b) {
        a = Mp(a, b);
        return null == a ? void 0 : a
    };
    fx = function(a, b) {
        a = _.Gj(a, b);
        return null == a ? void 0 : a
    };
    gx = function(a, b) {
        a = mo(a, b);
        return null == a ? void 0 : a
    };
    Lj = function(a, b, c) {
        return _.Gi(a, b, null == c ? c : Ic(c))
    };
    _.Ah = function(a, b, c) {
        return _.me(a, b, null == c ? c : Ic(c), !1)
    };
    _.Wo = function(a, b, c) {
        return _.Gi(a, b, null == c ? c : Pc(c))
    };
    _.Bh = function(a, b, c) {
        return _.me(a, b, null == c ? c : Pc(c), 0)
    };
    _.Dk = function(a, b, c) {
        return _.Gi(a, b, Yc(c))
    };
    _.th = function(a, b, c) {
        return _.me(a, b, Yc(c), "0")
    };
    Zn = function(a, b, c) {
        return _.Gi(a, b, jd(c))
    };
    _.uh = function(a, b, c) {
        return _.me(a, b, jd(c), "")
    };
    _.no = function(a, b, c) {
        return _.Gi(a, b, null == c ? c : Nc(c))
    };
    _.I = function(a, b, c) {
        return _.me(a, b, null == c ? c : Nc(c), 0)
    };
    hx = function(a, b, c) {
        var d = a.C,
            e = Pd(d);
        uc(e);
        b = $d(d, e, b, 2);
        d = Yb(b);
        c = id(c, !!(4 & d) && !!(4096 & d));
        b.push(c);
        return a
    };
    _.F = function(a, b, c) {
        this.C = _.B(a, b, c)
    };
    _.F.prototype.toJSON = function() {
        if (Qw) var a = se(this, this.C, !1);
        else a = Kd(this.C, Md, void 0, void 0, !1, !1), a = se(this, a, !0);
        return a
    };
    var Gk = function(a) {
        Qw = !0;
        try {
            return JSON.stringify(a.toJSON(), Dd)
        } finally {
            Qw = !1
        }
    };
    _.F.prototype.ng = ld;
    var ve = (0, _.v.Symbol)(),
        Be = (0, _.v.Symbol)(),
        Ee = (0, _.v.Symbol)(),
        ix = He(function(a, b, c) {
            b = Gc(b);
            null != b && (Je(a.g, 8 * c + 5), a = a.g, c = Gw || (Gw = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), Ob = 0, b = Nb = c.getUint32(0, !0), a.g.push(b >>> 0 & 255), a.g.push(b >>> 8 & 255), a.g.push(b >>> 16 & 255), a.g.push(b >>> 24 & 255))
        }),
        jx = He(Me),
        kx = He(Me),
        lx = He(function(a, b, c) {
            a: if (null != b) {
                if (Mc(b)) {
                    if ("string" === typeof b) {
                        b = ed(b);
                        break a
                    }
                    if ("number" === typeof b) {
                        b = dd(b);
                        break a
                    }
                }
                b = void 0
            }null != b && ("string" === typeof b && Jw(b), null != b && (Je(a.g, 8 * c), "number" === typeof b ? (a = a.g, Qb(b), Ke(a, Nb, Ob)) : (c = Jw(b), Ke(a.g, c.m, c.g))))
        }),
        mx = He(function(a, b, c) {
            b = Qc(b);
            null != b && null != b && (Je(a.g, 8 * c), Nw(a.g, b))
        }),
        nx = He(function(a, b, c) {
            b = Kc(b);
            null != b && (Je(a.g, 8 * c), a.g.g.push(b ? 1 : 0))
        }),
        ox = He(function(a, b, c) {
            b = kd(b);
            null != b && Ow(a, c, xb(b))
        }),
        px;
    px = new Ce(function(a, b, c) {
        if (Array.isArray(b)) {
            var d = Yb(b);
            if (!(d & 4)) {
                for (var e = 0, f = 0; e < b.length; e++) {
                    var g = kd(b[e]);
                    null != g && (b[f++] = g)
                }
                f < e && (b.length = f);
                Zb(b, (d | 5) & -12289);
                d & 2 && Object.freeze(b)
            }
        } else b = void 0;
        if (null != b)
            for (d = 0; d < b.length; d++) e = b[d], null != e && Ow(a, c, xb(e))
    }, !1);
    var Fe = new Ce(Oe, !0),
        De = new Ce(Oe, !0),
        qx;
    qx = new Ce(function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) Oe(a, b[f], c, d, e)
    }, !0);
    var rx = He(function(a, b, c) {
        b = Qc(b);
        null != b && (b = parseInt(b, 10), Je(a.g, 8 * c), Nw(a.g, b))
    });
    var Pe = void 0;
    var Dq = function(a) {
        this.C = _.B(a)
    };
    _.T(Dq, _.F);
    var Eq = function(a) {
        this.C = _.B(a)
    };
    _.T(Eq, _.F);
    var sx = function(a) {
            this.g = a.m;
            this.m = a.l;
            this.v = a.v;
            this.Dd = a.Dd;
            this.A = a.A;
            this.Wc = a.Wc;
            this.Je = a.Je;
            this.jf = a.jf;
            this.Ie = a.Ie;
            this.l = a.g
        },
        tx = function(a, b, c) {
            this.m = a;
            this.l = b;
            this.v = c;
            this.A = window;
            this.Wc = "env";
            this.Je = "n";
            this.jf = "0";
            this.Ie = "1";
            this.g = !0
        };
    tx.prototype.build = function() {
        return new sx(this)
    };
    var Nq = function(a, b) {
        var c = void 0 === _.N(b, 6) ? !0 : _.N(b, 6),
            d, e, f = Ue(_.Nk(b, 2, 0)),
            g = _.R(b, 3);
        a: switch (_.Nk(b, 4, 0)) {
            case 1:
                var h = "pt";
                break a;
            case 2:
                h = "cr";
                break a;
            default:
                h = ""
        }
        f = new tx(f, g, h);
        b = null != (e = null == (d = _.di(b, Dq, 5)) ? void 0 : _.R(d, 1)) ? e : "";
        f.Dd = b;
        f.g = c;
        f.A = a;
        return f.build()
    };
    var vo = function(a) {
        this.C = _.B(a)
    };
    _.T(vo, _.F);
    vo.prototype.getId = function() {
        return _.R(this, 1)
    };
    var uo = function(a, b) {
            return Zn(a, 1, b)
        },
        ux = [0, ox];
    var Co = function(a) {
        this.C = _.B(a)
    };
    _.T(Co, _.F);
    Co.prototype.getWidth = function() {
        return _.$w(this, 1)
    };
    var Bo = function(a, b) {
        return _.Wo(a, 1, b)
    };
    Co.prototype.getHeight = function() {
        return _.$w(this, 2)
    };
    var Ao = function(a, b) {
            return _.Wo(a, 2, b)
        },
        vx = [0, mx, -1];
    var wx = [0, kx, nx];
    var so = function(a) {
        this.C = _.B(a)
    };
    _.T(so, _.F);
    var wo = function(a, b) {
            _.Zh(a, 4, b)
        },
        to = function(a, b) {
            _.wh(a, 6, b)
        },
        zo = function(a, b) {
            _.wh(a, 7, b)
        };
    so.aa = [4];
    var xx = [0, ox, kx, ox, px, rx, ux, vx, kx, wx];
    var Yn = function(a) {
        this.C = _.B(a)
    };
    _.T(Yn, _.F);
    var Xn = function(a, b) {
            return _.no(a, 1, b)
        },
        Vn = function(a, b) {
            return Lj(a, 4, b)
        },
        Wn = function(a, b) {
            return _.Wo(a, 2, b)
        },
        yx = [0, rx, mx, ox, nx];
    var jo = function(a) {
        this.C = _.B(a)
    };
    _.T(jo, _.F);
    var io = function(a, b) {
            return Zn(a, 1, b)
        },
        go = function(a, b) {
            return Mj(a, 3, so, b)
        },
        ho = function(a, b) {
            return _.no(a, 4, b)
        };
    jo.prototype.Hh = function() {
        return _.Nk(this, 7, 0)
    };
    jo.aa = [10, 3];
    var zx = [0, ox, kx, qx, xx, rx, yx, nx, rx, 2, px];
    var Ax = function(a) {
        this.C = _.B(a)
    };
    _.T(Ax, _.F);
    var Bx = [0, rx, nx];
    var Cx = function(a) {
        this.C = _.B(a)
    };
    _.T(Cx, _.F);
    var fo = function(a, b) {
            return pe(a, 2, jo, b)
        },
        po = function(a, b) {
            _.wh(a, 5, b)
        },
        Dx = function(a, b) {
            _.wh(a, 9, b)
        };
    Cx.aa = [2];
    var Ex = [0, rx, qx, zx, rx, ox, yx, ox, nx, mx, Bx];
    var Fx = function(a) {
        this.C = _.B(a)
    };
    _.T(Fx, _.F);
    var Gx = function(a) {
        var b = new Cx;
        b = _.no(b, 1, 1);
        return pe(a, 1, Cx, b)
    };
    Fx.aa = [1];
    Fx.prototype.g = Se([0, qx, Ex]);
    var Hx = function(a) {
        this.C = _.B(a)
    };
    _.T(Hx, _.F);
    var bx = [2, 3];
    var Ix = function(a) {
        this.C = _.B(a)
    };
    _.T(Ix, _.F);
    Ix.aa = [1];
    var Jx = function(a) {
        this.C = _.B(a)
    };
    _.T(Jx, _.F);
    Jx.aa = [1];
    var Kx = function(a) {
        this.C = _.B(a)
    };
    _.T(Kx, _.F);
    var Lx = [2, 3];
    var Mx = function(a) {
        this.C = _.B(a)
    };
    _.T(Mx, _.F);
    Mx.aa = [2];
    var Nx = function(a) {
        this.C = _.B(a)
    };
    _.T(Nx, _.F);
    Nx.aa = [6, 4];
    var Ox = function(a) {
        this.C = _.B(a)
    };
    _.T(Ox, _.F);
    Ox.aa = [4, 5];
    var Px = function(a) {
        this.C = _.B(a)
    };
    _.T(Px, _.F);
    var Qx = function(a) {
        this.C = _.B(a)
    };
    _.T(Qx, _.F);
    Qx.prototype.He = function() {
        return us(this, Px, 2)
    };
    Qx.aa = [1];
    var Rx = function(a) {
        this.C = _.B(a)
    };
    _.T(Rx, _.F);
    var Sx = function(a) {
        this.C = _.B(a)
    };
    _.T(Sx, _.F);
    Sx.aa = [1];
    var Tx = function(a) {
        this.C = _.B(a)
    };
    _.T(Tx, _.F);
    var Ux = [0, rx, kx];
    var Vx = function(a) {
        this.C = _.B(a)
    };
    _.T(Vx, _.F);
    var Wx = [0, jx];
    var Xx = function(a) {
        this.C = _.B(a)
    };
    _.T(Xx, _.F);
    Xx.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 1)
    };
    var Yx = [0, ox, Wx, Ux];
    var Zx = function(a) {
        this.C = _.B(a)
    };
    _.T(Zx, _.F);
    Zx.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    _.$x = function(a) {
        this.C = _.B(a)
    };
    _.T(_.$x, _.F);
    _.$x.aa = [5];
    _.ay = function(a) {
        this.C = _.B(a)
    };
    _.T(_.ay, _.F);
    _.ay.prototype.Ee = ca(0);
    _.ay.prototype.ud = ca(1);
    _.ay.prototype.Ge = ca(2);
    _.ay.aa = [15];
    var by = function(a) {
        this.C = _.B(a)
    };
    _.T(by, _.F);
    by.prototype.getAdUnitPath = function() {
        return _.R(this, 2)
    };
    var cy = function(a) {
        this.C = _.B(a)
    };
    _.T(cy, _.F);
    var dy = [5, 7, 8, 9];
    var ey = function(a) {
        this.C = _.B(a)
    };
    _.T(ey, _.F);
    var fy = function(a) {
        this.C = _.B(a)
    };
    _.T(fy, _.F);
    fy.aa = [4, 5, 6];
    var gy = function(a) {
        this.C = _.B(a)
    };
    _.T(gy, _.F);
    gy.prototype.getValue = function() {
        return _.R(this, 2)
    };
    gy.prototype.ag = function() {
        return null != _.Gj(this, 2)
    };
    var hy = function(a) {
        this.C = _.B(a)
    };
    _.T(hy, _.F);
    hy.aa = [13];
    var iy = function(a) {
        this.C = _.B(a)
    };
    _.T(iy, _.F);
    iy.aa = [15, 13];
    var jy = function(a) {
        this.C = _.B(a)
    };
    _.T(jy, _.F);
    var ky = function(a) {
            var b = new jy;
            return _.no(b, 1, a)
        },
        ly = [0, rx];
    var Fj = function(a) {
        this.C = _.B(a)
    };
    _.T(Fj, _.F);
    var my = function(a) {
            var b = new Fj;
            return Zn(b, 1, a)
        },
        ny = function(a) {
            var b = window.Date.now();
            b = _.A(Number, "isFinite").call(Number, b) ? Math.round(b) : 0;
            return _.Dk(a, 3, b)
        };
    Fj.prototype.fb = function(a) {
        return _.wh(this, 10, a)
    };
    var oy = Te(Fj),
        py = [0, ox, -1, kx, mx, -2, kx, ix, nx, ly, nx];
    var qy = [0, 1, [0, lx, -2], -1, ox, -1, nx, [0, 3, rx, ox], kx];
    var ry = function(a) {
        this.C = _.B(a)
    };
    _.T(ry, _.F);
    ry.aa = [1, 2];
    ry.prototype.g = Se([0, qx, qy, qx, py]);
    var sy = function(a) {
        this.C = _.B(a)
    };
    _.T(sy, _.F);
    var ty = function(a) {
        this.C = _.B(a)
    };
    _.T(ty, _.F);
    ty.prototype.getValue = function() {
        return _.R(this, 1)
    };
    ty.prototype.ag = function() {
        return null != _.Gj(this, 1)
    };
    ty.prototype.getVersion = function() {
        return _.Nk(this, 5, 0)
    };
    var uy = function(a) {
        this.C = _.B(a)
    };
    _.T(uy, _.F);
    var vy = function(a) {
        this.C = _.B(a)
    };
    _.T(vy, _.F);
    vy.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    var wy = function(a) {
        this.C = _.B(a)
    };
    _.T(wy, _.F);
    var xy = function(a) {
        this.C = _.B(a)
    };
    _.T(xy, _.F);
    var yy = function(a) {
        this.C = _.B(a)
    };
    _.T(yy, _.F);
    yy.prototype.getContentUrl = function() {
        return _.R(this, 2)
    };
    yy.aa = [11];
    var zy = function(a) {
        this.C = _.B(a)
    };
    _.T(zy, _.F);
    zy.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 4)
    };
    zy.aa = [2];
    var Ay = function(a) {
        this.C = _.B(a)
    };
    _.T(Ay, _.F);
    var By = function(a) {
        this.C = _.B(a)
    };
    _.T(By, _.F);
    var Cy = function(a) {
        this.C = _.B(a)
    };
    _.T(Cy, _.F);
    var Dy = function(a) {
        this.C = _.B(a)
    };
    _.T(Dy, _.F);
    var Ey = function(a) {
        this.C = _.B(a)
    };
    _.T(Ey, _.F);
    Ey.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 2)
    };
    var Fy = function(a) {
        this.C = _.B(a)
    };
    _.T(Fy, _.F);
    var Gy = function(a) {
        this.C = _.B(a)
    };
    _.T(Gy, _.F);
    var Hy = function(a) {
        this.C = _.B(a)
    };
    _.T(Hy, _.F);
    Hy.prototype.getWidth = function() {
        return _.$w(this, 9)
    };
    Hy.prototype.getHeight = function() {
        return _.$w(this, 10)
    };
    Hy.aa = [3, 7, 27, 11];
    var Iy = function(a) {
        this.C = _.B(a)
    };
    _.T(Iy, _.F);
    Iy.prototype.getHeight = function() {
        return Mp(this, 6)
    };
    Iy.prototype.getWidth = function() {
        return Mp(this, 7)
    };
    Iy.prototype.getEscapedQemQueryId = function() {
        return _.Gj(this, 34)
    };
    Iy.aa = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63, 67];
    var Jy = [39, 48];
    var Ky = function(a) {
        this.C = _.B(a)
    };
    _.T(Ky, _.F);
    var Bq = Te(Ky);
    var Ly = function(a) {
        this.C = _.B(a)
    };
    _.T(Ly, _.F);
    var My = Te(Ly);
    Ly.aa = [1, 2, 3];
    var Ny = window;
    var Rt = function(a) {
        this.C = _.B(a)
    };
    _.T(Rt, _.F);
    Rt.aa = [15];
    var Qt = function(a) {
        this.C = _.B(a)
    };
    _.T(Qt, _.F);
    Qt.prototype.getCorrelator = function() {
        return _.Cf(this, 1)
    };
    Qt.prototype.setCorrelator = function(a) {
        return _.th(this, 1, a)
    };
    var Pt = function(a) {
        this.C = _.B(a)
    };
    _.T(Pt, _.F);
    var Py, Qy, Ry;
    _.Oy = function(a, b) {
        this.g = a;
        this.defaultValue = void 0 === b ? !1 : b
    };
    Py = function(a, b) {
        this.g = a;
        this.defaultValue = void 0 === b ? 0 : b
    };
    Qy = function(a, b) {
        this.g = a;
        this.defaultValue = void 0 === b ? "" : b
    };
    Ry = function(a) {
        var b = void 0 === b ? [] : b;
        this.g = a;
        this.defaultValue = b
    };
    var Sy, Uy;
    Sy = new _.Oy(564509651);
    _.Ty = new _.Oy(564509650);
    Uy = new _.Oy(1958);
    _.Ye = function(a) {
        var b = "oc";
        if (a.oc && a.hasOwnProperty(b)) return a.oc;
        b = new a;
        return a.oc = b
    };
    var Ze = function() {
        var a = {};
        this.m = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.l = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.v = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.J = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.g = function() {}
    };
    var Vy = _.jw || mw;
    _.Wy = Mi(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.Uv(Zv);
        return !b.parentElement
    });
    _.ui = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    _.ui.prototype.equals = function(a) {
        return a instanceof _.ui && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    _.ui.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.ui.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.ui.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.Di = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.q = _.Di.prototype;
    _.q.aspectRatio = function() {
        return this.width / this.height
    };
    _.q.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Xy, Yy, $y;
    Xy = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)
    };
    Yy = 2147483648 * Math.random() | 0;
    _.Zy = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    $y = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var tf, dz, cz, gz, iz, nz;
    tf = function(a) {
        return a ? new _.az(_.bz(a)) : Yu || (Yu = new _.az)
    };
    dz = function(a, b) {
        za(b, function(c, d) {
            c && "object" == typeof c && c.nb && (c = c.Xa());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : cz.hasOwnProperty(d) ? a.setAttribute(cz[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    cz = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.fz = function(a) {
        a = a.document;
        a = _.ez(a) ? a.documentElement : a.body;
        return new _.Di(a.clientWidth, a.clientHeight)
    };
    gz = function(a) {
        return a.scrollingElement ? a.scrollingElement : !mw && _.ez(a) ? a.documentElement : a.body || a.documentElement
    };
    _.hz = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    iz = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!_.ta(f) || _.ka(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.ka(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.hv(g ? _.ia(f) : f, d)
            }
        }
    };
    _.jz = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.ez = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.kz = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.lz = function(a) {
        var b;
        if (Vy && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.ka(b) && 1 == b.nodeType ? b : null
    };
    _.mz = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    _.bz = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    nz = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.hz(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.fh = function(a, b, c, d) {
        a && !c && (a = a.parentNode);
        for (c = 0; a && (null == d || c <= d);) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    };
    _.az = function(a) {
        this.g = a || _.t.document || document
    };
    _.q = _.az.prototype;
    _.q.Bk = function(a) {
        return "string" === typeof a ? this.g.getElementById(a) : a
    };
    _.q.um = _.az.prototype.Bk;
    _.q.getElementsByTagName = function(a, b) {
        return (b || this.g).getElementsByTagName(String(a))
    };
    _.q.createElement = function(a) {
        return _.jz(this.g, a)
    };
    _.q.createTextNode = function(a) {
        return this.g.createTextNode(String(a))
    };
    _.q.append = function(a, b) {
        iz(_.bz(a), a, arguments)
    };
    _.q.oj = _.kz;
    _.q.contains = _.mz;
    var pz = function() {
            return Ha && Ia ? Ia.mobile : !oz() && (La("iPod") || La("iPhone") || La("Android") || La("IEMobile"))
        },
        oz = function() {
            return Ha && Ia ? !Ia.mobile && (La("iPad") || La("Android") || La("Silk")) : La("iPad") || La("Android") && !La("Mobile") || La("Silk")
        };
    var rz, Ol, sz, qn;
    _.qz = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    rz = function(a) {
        return a ? decodeURI(a) : a
    };
    Ol = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Ol(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    _.Jq = function(a, b) {
        var c = [];
        for (d in b) Ol(d, b[d], c);
        b = c.join("&");
        if (b) {
            c = a.indexOf("#");
            0 > c && (c = a.length);
            var d = a.indexOf("?");
            if (0 > d || d > c) {
                d = c;
                var e = ""
            } else e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    };
    sz = /#|$/;
    qn = function(a, b) {
        var c = a.search(sz);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var Rk, bk, tz, ck, Ni, An, bu, au, vz, wz, Oi, xz, yz, zz, Az, Bz, Cz, Dz, Ez, Fz, pj, rj, qj, Pn, Gz, Iz, Jz, Kz, Lz, Mz, Nz, Km, Bm, Oz, Tl, Pz, Qz;
    _.tk = function(a) {
        try {
            return !!a && null != a.location.href && hw(a, "foo")
        } catch (b) {
            return !1
        }
    };
    Rk = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.t : d;
        c = (void 0 === c ? 0 : c) ? tz(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.tk(c) || !a(c));) c = tz(c)
    };
    bk = function() {
        var a = window;
        Rk(function(b) {
            a = b;
            return !1
        });
        return a
    };
    tz = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    ck = function(a) {
        return _.tk(a.top) ? a.top : null
    };
    _.on = function(a, b) {
        var c = _.rf("SCRIPT", a);
        kb(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    Ni = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.gg = function() {
        if (!_.v.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.v.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.Rl = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.uz = function(a) {
        var b = [];
        _.Rl(a, function(c) {
            b.push(c)
        });
        return b
    };
    An = function(a, b) {
        return Ca(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.hg = function(a) {
        var b = a.length;
        if (0 == b) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    };
    bu = Mi(function() {
        return _.dh(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], vz) || 1E-4 > Math.random()
    });
    au = Mi(function() {
        return vz("MSIE")
    });
    vz = function(a) {
        return _.Ja(Ga(), a)
    };
    wz = /^([0-9.]+)px$/;
    Oi = function(a) {
        return (a = wz.exec(a)) ? +a[1] : null
    };
    xz = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    yz = function() {
        var a = _.t.location.href;
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    zz = {
        ym: "allow-forms",
        zm: "allow-modals",
        Am: "allow-orientation-lock",
        Bm: "allow-pointer-lock",
        Cm: "allow-popups",
        Dm: "allow-popups-to-escape-sandbox",
        Em: "allow-presentation",
        Fm: "allow-same-origin",
        Gm: "allow-scripts",
        Hm: "allow-top-navigation",
        Im: "allow-top-navigation-by-user-activation"
    };
    Az = Mi(function() {
        return _.uz(zz)
    });
    Bz = function(a) {
        var b = Az();
        return a.length ? _.bh(b, function(c) {
            return !(0 <= _.fa(a, c))
        }) : b
    };
    Cz = function() {
        var a = _.rf("IFRAME"),
            b = {};
        _.hv(Az(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    Dz = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && _.Ja(a, "[native code]")
    };
    Ez = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = tz(a))) break
        }
        return null
    };
    Fz = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.rf("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.Tn = Mi(function() {
        return pz() ? 2 : oz() ? 1 : 0
    });
    pj = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.Yi = function(a, b) {
        _.Rl(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    rj = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    qj = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = Ni(a, window);
            if (d) {
                if (b(d, a)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Pn = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.iv(a, parseFloat)
    };
    Gz = {};
    _.Hz = (Gz["http://googleads.g.doubleclick.net"] = !0, Gz["http://pagead2.googlesyndication.com"] = !0, Gz["https://googleads.g.doubleclick.net"] = !0, Gz["https://pagead2.googlesyndication.com"] = !0, Gz);
    Iz = function(a) {
        _.t.console && _.t.console.warn && _.t.console.warn(a)
    };
    Jz = [];
    Kz = function() {
        var a = Jz;
        Jz = [];
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    Lz = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    Mz = function() {
        var a = void 0 === a ? Math.random : a;
        return Math.floor(a() * Math.pow(2, 52))
    };
    _.Wh = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Mz(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Nz = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (Jz.push(b), 1 == Jz.length && (_.v.Promise ? _.v.Promise.resolve().then(Kz) : window.setImmediate ? setImmediate(Kz) : setTimeout(Kz, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    Km = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    Bm = function(a) {
        return 0 === a || Km(a)
    };
    Oz = function(a) {
        return new _.v.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    };
    Tl = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.rf = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Pz = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.tk(a) && (b = a);
        return b
    };
    _.Kg = function(a) {
        return Na() && pz() ? Qz(a, !0) : 1
    };
    Qz = function(a, b) {
        var c = (void 0 === b ? 0 : b) ? ck(a) : a;
        if (!c) return 1;
        a = 0 === (0, _.Tn)();
        b = !!c.document.querySelector('meta[name=viewport][content*="width=device-width"]');
        var d = c.innerWidth;
        c = c.outerWidth;
        if (0 === d) return 1;
        var e = Math.round(100 * (c / d + _.A(Number, "EPSILON"))) / 100;
        return 1 === e && _.G(Sy) ? 1 : a || b ? e : Math.round(100 * (c / d / .4 + _.A(Number, "EPSILON"))) / 100
    };
    _.Rz = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.Rz.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.Rz.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.Sz = function(a) {
        return new _.Rz(a.top, a.right, a.bottom, a.left)
    };
    _.Rz.prototype.contains = function(a) {
        return this && a ? a instanceof _.Rz ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    _.Rz.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.Rz.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.Rz.prototype.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var Tz = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        Uz = function(a) {
            return new _.Rz(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        Vz = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new Tz(c, e, d - c, a - e)
            }
            return null
        };
    Tz.prototype.contains = function(a) {
        return a instanceof _.ui ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    Tz.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Tz.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Tz.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Wz = function(a) {
        return (a = void 0 === a ? kf() : a) ? _.tk(a.master) ? a.master : null : null
    };
    var Zz, aA, Ci, bA, cA, ti;
    _.Yz = function(a, b, c) {
        if ("string" === typeof b)(b = _.Xz(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.Xz(c, d);
                f && (c.style[f] = e)
            }
    };
    Zz = {};
    _.Xz = function(a, b) {
        var c = Zz[b];
        if (!c) {
            var d = _.Zy(b);
            c = d;
            void 0 === a.style[d] && (d = (mw ? "Webkit" : lw ? "Moz" : _.jw ? "ms" : null) + $y(d), void 0 !== a.style[d] && (c = d));
            Zz[b] = c
        }
        return c
    };
    _.$z = function(a, b) {
        var c = _.bz(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    aA = function(a, b) {
        return _.$z(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    Ci = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    bA = function(a) {
        if (_.jw && !(8 <= Number(vw))) return a.offsetParent;
        var b = _.bz(a),
            c = aA(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = aA(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    cA = function(a) {
        var b = _.bz(a),
            c = new _.ui(0, 0);
        var d = b ? _.bz(b) : document;
        d = !_.jw || 9 <= Number(vw) || _.ez(tf(d).g) ? d.documentElement : d.body;
        if (a == d) return c;
        a = Ci(a);
        d = tf(b).g;
        b = gz(d);
        d = d.parentWindow || d.defaultView;
        b = _.jw && d.pageYOffset != b.scrollTop ? new _.ui(b.scrollLeft, b.scrollTop) : new _.ui(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    ti = function(a, b) {
        var c = new _.ui(0, 0),
            d = _.hz(_.bz(a));
        if (!hw(d, "parent")) return c;
        do {
            var e = d == b ? cA(a) : _.dA(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.dA = function(a) {
        a = Ci(a);
        return new _.ui(a.left, a.top)
    };
    _.eA = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.Bi = function(a, b) {
        if ("none" != aA(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.fA = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = mw && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Ci(a), new _.Di(a.right - a.left, a.bottom - a.top)) : new _.Di(b, c)
    };
    var mj;
    _.gA = _.tu(["//fonts.googleapis.com/css"]);
    mj = function(a) {
        a = Wz(kf(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var hA = function(a) {
        this.C = _.B(a)
    };
    _.T(hA, _.F);
    var iA = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var jA = function(a) {
        this.C = _.B(a)
    };
    _.T(jA, _.F);
    jA.prototype.getVersion = function() {
        return _.$w(this, 2)
    };
    jA.aa = [3];
    var kA = function(a) {
        this.C = _.B(a)
    };
    _.T(kA, _.F);
    var lA = function(a) {
        this.C = _.B(a)
    };
    _.T(lA, _.F);
    var mA = function(a) {
        this.C = _.B(a)
    };
    _.T(mA, _.F);
    mA.prototype.getVersion = function() {
        return _.$w(this, 1)
    };
    var nA = function(a) {
        this.C = _.B(a)
    };
    _.T(nA, _.F);
    var oA = function(a) {
        this.C = _.B(a)
    };
    _.T(oA, _.F);
    var pA = function(a) {
        var b = new oA;
        return _.wh(b, 1, a)
    };
    var qA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        rA = qA.reduce(function(a, b) {
            return a + b
        });
    var sA = function(a) {
        this.C = _.B(a)
    };
    _.T(sA, _.F);
    var tA = function(a) {
        this.C = _.B(a)
    };
    _.T(tA, _.F);
    tA.prototype.getVersion = function() {
        return _.$w(this, 1)
    };
    var uA = function(a) {
        this.C = _.B(a)
    };
    _.T(uA, _.F);
    var vA = function(a) {
        this.C = _.B(a)
    };
    _.T(vA, _.F);
    var wA = function(a) {
        var b = new vA;
        return _.wh(b, 1, a)
    };
    var xA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        yA = xA.reduce(function(a, b) {
            return a + b
        });
    var zA = function(a) {
        this.C = _.B(a)
    };
    _.T(zA, _.F);
    var AA = function(a) {
        this.C = _.B(a)
    };
    _.T(AA, _.F);
    var BA = function(a) {
        this.C = _.B(a)
    };
    _.T(BA, _.F);
    BA.prototype.getVersion = function() {
        return _.$w(this, 1)
    };
    var CA = function(a) {
        this.C = _.B(a)
    };
    _.T(CA, _.F);
    var DA = function(a) {
        this.C = _.B(a)
    };
    _.T(DA, _.F);
    var EA = function(a) {
        var b = new DA;
        return _.wh(b, 1, a)
    };
    var FA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        GA = FA.reduce(function(a, b) {
            return a + b
        });
    var HA = function(a) {
        this.C = _.B(a)
    };
    _.T(HA, _.F);
    var IA = function(a) {
        this.C = _.B(a)
    };
    _.T(IA, _.F);
    IA.prototype.getVersion = function() {
        return _.$w(this, 1)
    };
    var JA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        KA = JA.reduce(function(a, b) {
            return a + b
        });
    var LA = function(a) {
        this.C = _.B(a)
    };
    _.T(LA, _.F);
    var MA = function(a, b) {
        var c = new LA;
        a = _.I(c, 1, a);
        b = _.uh(a, 2, b);
        this.J = _.Td(b)
    };
    var NA = function(a) {
        this.C = _.B(a)
    };
    _.T(NA, _.F);
    var OA = [1, 2, 3];
    var PA = function(a) {
        this.C = _.B(a)
    };
    _.T(PA, _.F);
    var QA = [2, 4];
    var RA = function(a) {
        this.C = _.B(a)
    };
    _.T(RA, _.F);
    var SA = function(a) {
        var b = new RA;
        return _.uh(b, 1, a)
    };
    RA.aa = [4];
    var TA = function(a) {
        this.C = _.B(a)
    };
    _.T(TA, _.F);
    var UA = function(a) {
        this.C = _.B(a)
    };
    _.T(UA, _.F);
    var Mh = function(a) {
        this.C = _.B(a)
    };
    _.T(Mh, _.F);
    var zh = function(a) {
        this.C = _.B(a)
    };
    _.T(zh, _.F);
    var yh = function(a) {
        this.C = _.B(a)
    };
    _.T(yh, _.F);
    var vh = function(a) {
        this.C = _.B(a)
    };
    _.T(vh, _.F);
    var Gh = function(a) {
        this.C = _.B(a)
    };
    _.T(Gh, _.F);
    var VA = function(a) {
        this.C = _.B(a)
    };
    _.T(VA, _.F);
    var WA = function(a) {
        this.C = _.B(a)
    };
    _.T(WA, _.F);
    var sh = function(a) {
        this.C = _.B(a)
    };
    _.T(sh, _.F);
    sh.prototype.getTagSessionCorrelator = function() {
        return _.Cf(this, 2)
    };
    var Fh = function(a) {
        var b = new VA;
        return _.Ch(a, 13, Dh, b)
    };
    sh.aa = [4];
    var Dh = [6, 7, 8, 9, 11, 13, 14];
    var XA = function(a) {
        this.C = _.B(a)
    };
    _.T(XA, _.F);
    var Vo = function(a) {
        this.C = _.B(a)
    };
    _.T(Vo, _.F);
    var So = function(a) {
        this.C = _.B(a)
    };
    _.T(So, _.F);
    var YA = function(a) {
            var b = new So;
            return _.Ch(b, 2, To, a)
        },
        To = [1, 2, 3, 4];
    var Oo = function(a) {
        this.C = _.B(a)
    };
    _.T(Oo, _.F);
    Oo.prototype.getTagSessionCorrelator = function() {
        return _.Cf(this, 2)
    };
    Oo.aa = [4];
    var $h = function(a) {
        this.C = _.B(a)
    };
    _.T($h, _.F);
    $h.aa = [3];
    var Yh = function(a) {
        this.C = _.B(a)
    };
    _.T(Yh, _.F);
    Yh.aa = [4, 5];
    var Uh = function(a) {
        this.C = _.B(a)
    };
    _.T(Uh, _.F);
    Uh.prototype.getTagSessionCorrelator = function() {
        return _.Cf(this, 1)
    };
    Uh.aa = [2];
    var Th = function(a) {
        this.C = _.B(a)
    };
    _.T(Th, _.F);
    var ci = [4, 6];
    var ZA = function(a) {
        this.C = _.B(a)
    };
    _.T(ZA, _.F);
    ZA.prototype.getTagSessionCorrelator = function() {
        return _.Cf(this, 1)
    };
    ZA.prototype.getMessageId = function() {
        return _.Nk(this, 8, 0)
    };
    ZA.prototype.getMessageArgs = function(a) {
        return ax(this, 9, a)
    };
    ZA.aa = [2, 9];
    var $A = function() {
            MA.apply(this, arguments)
        },
        Jh, Ih;
    _.T($A, MA);
    Jh = function(a, b) {
        var c = void 0 === b.value ? 1 : b.value,
            d = b.nf;
        b = SA("lAzCEe");
        var e = new NA;
        d = Ek(e, 1, OA, jd(d));
        b = Mj(b, 4, NA, d);
        d = new PA;
        c = Ek(d, 4, QA, _.Fc(c));
        c = _.wh(b, 3, c);
        a.Lg(c)
    };
    Ih = function(a, b) {
        var c = void 0 === b.value ? 1 : b.value,
            d = b.uf;
        b = SA("uWt0se");
        var e = new NA;
        d = Ek(e, 1, OA, jd(d));
        b = Mj(b, 4, NA, d);
        d = new PA;
        c = Ek(d, 2, QA, Yc(Math.round(c)));
        c = _.wh(b, 3, c);
        a.Lg(c)
    };
    _.aB = function() {
        $A.apply(this, arguments)
    };
    _.T(_.aB, $A);
    _.q = _.aB.prototype;
    _.q.Kl = function() {
        this.m.apply(this, _.oh(_.Wa.apply(0, arguments).map(function(a) {
            return {
                rc: !0,
                Yc: 2,
                Nc: a.toJSON()
            }
        })))
    };
    _.q.xc = function() {
        this.m.apply(this, _.oh(_.Wa.apply(0, arguments).map(function(a) {
            return {
                rc: !0,
                Yc: 5,
                Nc: a.toJSON()
            }
        })))
    };
    _.q.Ki = function() {
        this.m.apply(this, _.oh(_.Wa.apply(0, arguments).map(function(a) {
            return {
                rc: !0,
                Yc: 15,
                Nc: a.toJSON()
            }
        })))
    };
    _.q.Li = ca(3);
    _.q.Ml = function() {
        this.m.apply(this, _.oh(_.Wa.apply(0, arguments).map(function(a) {
            return {
                rc: !0,
                Yc: 17,
                Nc: a.toJSON()
            }
        })))
    };
    _.q.Lg = function() {
        this.m.apply(this, _.oh(_.Wa.apply(0, arguments).map(function(a) {
            return {
                rc: !1,
                Yc: 1,
                Nc: a.toJSON()
            }
        })))
    };
    var bB = function(a, b) {
        if (_.v.globalThis.fetch) _.v.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var cB = function(a, b, c, d, e, f, g, h) {
        _.aB.call(this, a, b);
        this.o = c;
        this.L = d;
        this.B = e;
        this.G = f;
        this.H = g;
        this.v = h;
        this.g = [];
        this.l = null;
        this.j = !1
    };
    _.T(cB, _.aB);
    var dB = function(a) {
        null !== a.l && (clearTimeout(a.l), a.l = null);
        if (a.g.length) {
            var b = qf(a.g, a.J);
            a.L(a.o + "?e=1", b);
            a.g = []
        }
    };
    cB.prototype.m = function() {
        var a = _.Wa.apply(0, arguments),
            b = this;
        this.H && 65536 <= qf(this.g.concat(a), this.J).length && dB(this);
        this.v && !this.j && (this.j = !0, eB(this.v, function() {
            dB(b)
        }));
        this.g.push.apply(this.g, _.oh(a));
        this.g.length >= this.G && dB(this);
        this.g.length && null === this.l && (this.l = setTimeout(function() {
            dB(b)
        }, this.B))
    };
    var gu = function(a, b, c, d, e, f) {
        cB.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", bB, void 0 === c ? 1E3 : c, void 0 === d ? 100 : d, (void 0 === e ? !1 : e) && !!_.v.globalThis.fetch, f)
    };
    _.T(gu, cB);
    var Om, cj, fB, gB, yo, hB, qo, iB, jB, Et, Dt, Jt, kB, du, lB, mB, nB, oB, pB, qB, rB, sB, tB, uB, vB, wB, xB, cu, yB, zB, AB, BB, CB, yq, DB, Zm, EB, yg, Bt, Fo, KB, LB, NB, Oh, ht, Tp, OB, PB, QB, RB, SB, TB, UB, VB, WB, XB, YB, ZB, $B, Nl, Kl, yt, cC, dC, eC, Jm, fC, gC, fu, Ak, hC, iC, jC, kC, zk, lC, Qr, mC, Gs, nC, oC, pC, qC, rC, Tr, sC, tC, uC, vC, wC, xC, yC, Tt, Ut, zC, Vt, St, AC, BC, Ds, Xt, CC;
    Om = new _.Oy(577939489, !0);
    cj = new Py(7, .1);
    fB = new _.Oy(212);
    gB = new _.Oy(561694963);
    yo = new Py(474069761);
    hB = new Py(462420536);
    qo = new _.Oy(476475256, !0);
    iB = new Py(427198696, 1);
    jB = new Py(438663674);
    Et = new Py(45409629);
    Dt = new Py(522348973);
    Jt = new Py(550605190);
    kB = new Py(564509649);
    du = new Py(578655462, 20);
    _.ep = new _.Oy(571050247, !0);
    _.Yo = new _.Oy(570864697, !0);
    lB = new _.Oy(558225291);
    mB = new _.Oy(577861852);
    nB = new _.Oy(573236024);
    oB = new _.Oy(580562135);
    pB = new Py(494575051);
    qB = new Ry(489560439);
    rB = new Ry(505762507);
    sB = new _.Oy(453);
    tB = new _.Oy(454);
    uB = new Py(377289019, 1E4);
    vB = new _.Oy(579191270);
    wB = new _.Oy(585711694);
    xB = new Py(529, 20);
    cu = new Py(573282293, .01);
    yB = new Qy(10);
    zB = new _.Oy(489217043);
    AB = new _.Oy(549005203, !0);
    BB = new _.Oy(495013820);
    CB = new _.Oy(586127656);
    yq = new Py(447000223, .01);
    DB = new _.Oy(360245597, !0);
    Zm = new _.Oy(540043576);
    EB = new _.Oy(471855283);
    yg = new _.Oy(465118388);
    Bt = new _.Oy(45401686);
    Fo = new _.Oy(45401685, !0);
    _.FB = new _.Oy(479390945);
    _.GB = new _.Oy(518650310);
    _.HB = new _.Oy(547020083);
    _.IB = new _.Oy(561164161, !0);
    _.JB = new Py(550718589, 250);
    KB = new _.Oy(586382198);
    LB = new Py(575880738);
    _.MB = new _.Oy(531615531);
    NB = new _.Oy(581976587);
    Oh = new _.Oy(85);
    ht = new _.Oy(524098256);
    Tp = new Py(532520346, 120);
    OB = new _.Oy(557870754, !0);
    PB = new Py(553562174, 10);
    QB = new Ry(466086960);
    RB = new Py(398776877, 6E4);
    SB = new Py(374201269, 6E4);
    TB = new Py(371364213, 6E4);
    UB = new _.Oy(570764855, !0);
    VB = new Qy(579921177, "control_1\\.\\d");
    WB = new Py(570764854, 50);
    XB = new _.Oy(578725095, !0);
    YB = new _.Oy(453275889);
    ZB = new _.Oy(377936516, !0);
    $B = new Py(24);
    Nl = new Ry(1);
    Kl = new Qy(2, "1-0-40");
    _.aC = new Py(506394061, 100);
    _.bC = new _.Oy(526684968, !0);
    yt = new Ry(489);
    cC = new _.Oy(392065905);
    dC = new Py(360245595, 500);
    eC = new _.Oy(561985307);
    Jm = new _.Oy(45397804, !0);
    fC = new _.Oy(45398607, !0);
    gC = new _.Oy(424117738);
    fu = new Py(397316938, 1E3);
    Ak = new _.Oy(531493729);
    hC = new _.Oy(563462360, !0);
    iC = new _.Oy(555237688);
    jC = new _.Oy(555237687);
    kC = new _.Oy(555237686);
    zk = new _.Oy(507033477, !0);
    lC = new _.Oy(552803605, !0);
    Qr = new _.Oy(399705355);
    mC = new _.Oy(45420038);
    Gs = new Py(514795754, 2);
    nC = new _.Oy(583216404);
    oC = new _.Oy(564724551);
    pC = new _.Oy(567489814, !0);
    qC = new _.Oy(45415915, !0);
    rC = new _.Oy(582661286);
    Tr = new _.Oy(582338617);
    sC = new _.Oy(582287318);
    tC = new _.Oy(564852646, !0);
    uC = new _.Oy(587029311);
    vC = new _.Oy(501);
    wC = new _.Oy(439828594);
    xC = new _.Oy(483962503);
    yC = new _.Oy(506738118);
    Tt = new _.Oy(77);
    Ut = new _.Oy(78);
    zC = new _.Oy(83);
    Vt = new _.Oy(80);
    St = new _.Oy(76);
    AC = new _.Oy(84);
    BC = new _.Oy(1958);
    Ds = new _.Oy(1973);
    Xt = new _.Oy(188);
    CC = new _.Oy(485990406);
    Ba({
        cn: 0,
        bn: 1,
        Ym: 2,
        Tm: 3,
        Zm: 4,
        Um: 5,
        an: 6,
        Wm: 7,
        Xm: 8,
        Sm: 9,
        Vm: 10,
        dn: 11
    }).map(function(a) {
        return Number(a)
    });
    Ba({
        fn: 0,
        gn: 1,
        en: 2
    }).map(function(a) {
        return Number(a)
    });
    var DC = function(a, b) {
        this.g = vf(a);
        this.m = b
    };
    DC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    DC.prototype.next = function() {
        var a = this.g.next();
        return {
            value: a.done ? void 0 : this.m.call(void 0, a.value),
            done: a.done
        }
    };
    var EC = function(a, b) {
            return new DC(a, b)
        },
        FC = function(a) {
            this.m = a;
            this.g = 0
        };
    FC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    FC.prototype.next = function() {
        for (; this.g < this.m.length;) {
            var a = this.m[this.g].next();
            if (!a.done) return a;
            this.g++
        }
        return {
            done: !0
        }
    };
    var GC = function() {
        return new FC(_.Wa.apply(0, arguments).map(vf))
    };
    var HC = _.t.URL,
        IC;
    try {
        new HC("http://example.com"), IC = !0
    } catch (a) {
        IC = !1
    }
    var JC = IC,
        KC = function(a) {
            this.g = new _.v.Map;
            0 == a.indexOf("?") && (a = a.substring(1));
            a = _.z(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                1 < c.length && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.g.get(b);
                null == c && (c = [], this.g.set(b, c));
                c.push(d)
            }
        };
    KC.prototype.get = function(a) {
        return (a = this.g.get(a)) && a.length ? a[0] : null
    };
    KC.prototype.getAll = function(a) {
        return [].concat(_.oh(this.g.get(a) || []))
    };
    KC.prototype.has = function(a) {
        return this.g.has(a)
    };
    KC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return GC.apply(null, _.oh(EC(this.g, function(a) {
            var b = a[0];
            return EC(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    KC.prototype.toString = function() {
        return LC(this)
    };
    var LC = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.A(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        NC = function(a) {
            var b = _.jz(document, "A");
            try {
                _.db(b, _.Ta(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if ("" === c || ":" === c || ":" != c[c.length - 1]) throw Error(a + " is not a valid URL.");
            if (!MC.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            MC.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        xf = function(a) {
            if (JC) {
                try {
                    var b = new HC(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = MC.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                "null" == b.origin && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a);
                return b
            }
            return NC(a)
        },
        MC = new _.v.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        wf = function(a) {
            return JC && a.searchParams ? a.searchParams : new KC(a.search)
        };
    var OC = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.rf("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var PC = function(a) {
        this.C = _.B(a)
    };
    _.T(PC, _.F);
    PC.aa = [1, 2];
    var QC = function(a) {
        this.C = _.B(a)
    };
    _.T(QC, _.F);
    var Bf = Te(QC);
    _.U = function() {
        this.J = this.J;
        this.sa = this.sa
    };
    _.U.prototype.J = !1;
    _.U.prototype.ua = function() {
        this.J || (this.J = !0, this.m())
    };
    _.S = function(a, b) {
        _.yn(a, _.Xu(Af, b))
    };
    _.yn = function(a, b) {
        a.J ? b() : (a.sa || (a.sa = []), a.sa.push(b))
    };
    _.U.prototype.m = function() {
        if (this.sa)
            for (; this.sa.length;) this.sa.shift()()
    };
    var RC = function(a, b, c, d) {
        _.U.call(this);
        this.B = b;
        this.o = c;
        this.L = d;
        this.j = new _.v.Map;
        this.F = 0;
        this.l = new _.v.Map;
        this.H = new _.v.Map;
        this.G = void 0;
        this.v = a
    };
    _.T(RC, _.U);
    RC.prototype.m = function() {
        delete this.g;
        this.j.clear();
        this.l.clear();
        this.H.clear();
        this.G && (_.Ef(this.v, "message", this.G), delete this.G);
        delete this.v;
        delete this.L;
        _.U.prototype.m.call(this)
    };
    var SC = function(a) {
            if (a.g) return a.g;
            a.o && a.o(a.v) ? a.g = a.v : a.g = Ez(a.v, a.B);
            var b;
            return null != (b = a.g) ? b : null
        },
        UC = function(a, b, c) {
            if (SC(a))
                if (a.g === a.v)(b = a.j.get(b)) && b(a.g, c);
                else {
                    var d = a.l.get(b);
                    if (d && d.Kc) {
                        TC(a);
                        var e = ++a.F;
                        a.H.set(e, {
                            uc: d.uc,
                            Wj: d.Gd(c),
                            ll: "addEventListener" === b
                        });
                        a.g.postMessage(d.Kc(c, e), "*")
                    }
                }
        },
        TC = function(a) {
            a.G || (a.G = function(b) {
                try {
                    var c = a.L ? a.L(b) : void 0;
                    if (c) {
                        var d = c.Cg,
                            e = a.H.get(d);
                        if (e) {
                            e.ll || a.H.delete(d);
                            var f;
                            null == (f = e.uc) || f.call(e, e.Wj, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.lb(a.v, "message", a.G))
        };
    var VC = function(a, b) {
            var c = {
                cb: function(d) {
                    d = Bf(d);
                    b.Hb({
                        ac: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        WC = {
            Gd: function(a) {
                return a.Hb
            },
            Kc: function(a, b) {
                return {
                    __fciCall: {
                        callId: b,
                        command: a.command,
                        spsp: a.spsp || void 0
                    }
                }
            },
            uc: function(a, b) {
                a({
                    ac: b
                })
            }
        },
        xp = function(a) {
            _.U.call(this);
            this.g = this.l = !1;
            this.caller = new RC(a, "googlefcPresent", void 0, Df);
            this.caller.j.set("getDataWithCallback", VC);
            this.caller.l.set("getDataWithCallback", WC)
        };
    _.T(xp, _.U);
    xp.prototype.m = function() {
        this.caller.ua();
        _.U.prototype.m.call(this)
    };
    xp.prototype.Hc = function(a) {
        if (void 0 === a ? 0 : a) return !1;
        this.l || (this.g = !!SC(this.caller), this.l = !0);
        return this.g
    };
    var vp = function(a) {
            return new _.v.Promise(function(b) {
                a.Hc() && UC(a.caller, "getDataWithCallback", {
                    command: "loaded",
                    Hb: function(c) {
                        b(c.ac)
                    }
                })
            })
        },
        XC = function(a, b) {
            a.Hc() && UC(a.caller, "getDataWithCallback", {
                command: "prov",
                spsp: Gk(b),
                Hb: function() {}
            })
        };
    var YC = function(a, b, c, d, e) {
            Ff(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        Bj = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.Rl(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            Oq(d, c)
        },
        Oq = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : YC(c, a, void 0, b, d)
        };
    var ZC = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        $C = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.l = a;
            this.g = null;
            this.j = {};
            this.L = 0;
            var c;
            this.H = null != (c = b.timeoutMs) ? c : 500;
            var d;
            this.G = null != (d = b.Aj) ? d : !1;
            this.v = null
        };
    _.T($C, _.U);
    $C.prototype.m = function() {
        this.j = {};
        this.v && (_.Ef(this.l, "message", this.v), delete this.v);
        delete this.j;
        delete this.l;
        delete this.g;
        _.U.prototype.m.call(this)
    };
    var bD = function(a) {
        return "function" === typeof a.l.__tcfapi || null != aD(a)
    };
    $C.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.G
            },
            d = _.ev(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.H && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.H));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = ZC(c), c.internalBlockOnErrors = b.G, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            cD(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    $C.prototype.removeEventListener = function(a) {
        a && a.listenerId && cD(this, "removeEventListener", null, a.listenerId)
    };
    var dD = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        cD = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.l.__tcfapi) a = a.l.__tcfapi, a(b, 2, c, d);
            else if (aD(a)) {
                lE(a);
                var e = ++a.L;
                a.j[e] = c;
                a.g && (c = {}, a.g.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        aD = function(a) {
            if (a.g) return a.g;
            a.g = Ez(a.l, "__tcfapiLocator");
            return a.g
        },
        lE = function(a) {
            a.v || (a.v = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.j[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.lb(a.l, "message", a.v))
        },
        mE = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = ZC(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Bj({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        nE = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return dD(a, c)
            })
        };
    var oE = function(a, b, c) {
            this.g = a;
            this.l = b;
            this.m = void 0 === c ? function() {} : c
        },
        pE = function(a, b, c) {
            return new oE(a, b, c)
        };
    oE.prototype.start = function(a) {
        if (this.g === this.g.top) try {
            OC(this.g), qE(this, a)
        } catch (b) {}
    };
    var qE = function(a, b) {
            var c = yf(a.g),
                d = zf(a.g),
                e = {};
            c = (e.fc = c, e.fctype = d, e);
            c = rE(a.l, c);
            uf(a.g, c, function() {
                a.m(!0)
            }, function() {
                a.m(!1)
            });
            b && XC(new xp(a.g), b)
        },
        rE = function(a, b) {
            var c = cv("https://fundingchoicesmessages.google.com/i/%{id}");
            b = _.A(Object, "assign").call(Object, {}, b, {
                ers: 3
            });
            return _.nv(rb(c, {
                id: a
            }), b)
        };
    var sE = _.v.Promise;
    var tE = function(a) {
        this.m = a
    };
    tE.prototype.send = function(a, b, c) {
        this.m.then(function(d) {
            d.send(a, b, c)
        })
    };
    tE.prototype.g = function(a, b) {
        return this.m.then(function(c) {
            return c.g(a, b)
        })
    };
    var uE = function(a) {
        this.data = a
    };
    var vE = function(a) {
        this.m = a
    };
    vE.prototype.send = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        wE(d.port1, b);
        this.m.postMessage(a, [d.port2].concat(c))
    };
    vE.prototype.g = function(a, b) {
        var c = this;
        return new sE(function(d) {
            c.send(a, d, b)
        })
    };
    var xE = function(a, b) {
            wE(a, b);
            return new vE(a)
        },
        wE = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new uE(c.data, xE(c.ports[0])))
            })
        };
    var xk = function(a) {
            var b = a.mb,
                c = void 0 === a.tb ? "ZNWN1d" : a.tb,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.Te ? void 0 : a.Te;
            return yE({
                destination: a.destination,
                Hh: function() {
                    return b.contentWindow
                },
                bl: zE(a.origin),
                tb: c,
                onMessage: d,
                Te: e
            })
        },
        yE = function(a) {
            var b = a.destination,
                c = a.Hh,
                d = a.bl,
                e = void 0 === a.Wd ? void 0 : a.Wd,
                f = a.tb,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.Te ? void 0 : a.Te,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new tE(new sE(function(l, m) {
                var n = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", n, !1), e && p.data.t !== e ? m(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(xE(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", n, !1)
            }))
        },
        zE = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var Pf = function(a) {
            return "string" === typeof a
        },
        Pm = function(a) {
            return "boolean" === typeof a
        },
        Kf = function(a) {
            return !!a && ("object" === typeof a || "function" === typeof a)
        },
        ys = Nf(),
        Of = Nf();
    var AE = navigator,
        BE = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        CE = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return BE(a.toLowerCase())
        },
        DE = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        EE = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        FE = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var ri = function(a) {
            return !!a && a.top == a
        },
        Tk = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (ri(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var fj = function() {
        this.data = [];
        this.g = -1
    };
    fj.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.A(Number, "isInteger").call(Number, a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
    };
    fj.prototype.get = function(a) {
        return !!this.data[a]
    };
    var hj = function(a) {
        -1 === a.g && (a.g = a.data.reduce(function(b, c, d) {
            return b + (c ? Math.pow(2, d) : 0)
        }, 0));
        return a.g
    };
    _.Sh = function(a) {
        return !!(a.error && a.meta && a.id)
    };
    var GE = function(a, b) {
            (0, a.__uspapi)("getUSPData", 1, function(c, d) {
                b.Hb({
                    ac: null != c ? c : void 0,
                    xe: d ? void 0 : 2
                })
            })
        },
        HE = {
            Gd: function(a) {
                return a.Hb
            },
            Kc: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            uc: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    ac: null != (c = b.returnValue) ? c : void 0,
                    xe: b.success ? void 0 : 2
                })
            }
        },
        IE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500;
            this.caller = new RC(a, "__uspapiLocator", function(d) {
                return "function" === typeof d.__uspapi
            }, Rf);
            this.caller.j.set("getDataWithCallback", GE);
            this.caller.l.set("getDataWithCallback", HE)
        };
    _.T(IE, _.U);
    IE.prototype.m = function() {
        this.caller.ua();
        _.U.prototype.m.call(this)
    };
    var JE = function(a, b) {
        var c = {};
        if (SC(a.caller)) {
            var d = _.ev(function() {
                b(c)
            });
            UC(a.caller, "getDataWithCallback", {
                Hb: function(e) {
                    e.xe || (c = e.ac);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    };
    var Xf = function(a) {
            this.g = a || {
                cookie: ""
            }
        },
        ME = function() {
            var a = KE;
            if (!_.t.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                lg: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            LE(a, "TESTCOOKIESENABLED");
            return !0
        };
    Xf.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Pn;
            d = c.Il || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.lg
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    Xf.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = sv(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var LE = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            lg: 0,
            path: c,
            domain: d
        })
    };
    Xf.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    Xf.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = sv(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) LE(this, b[a])
    };
    var KE = new Xf("undefined" == typeof document ? null : document);
    var NE = function(a, b) {
        this.g = a;
        this.options = b
    };
    var OE = function(a, b) {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        PE = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        QE = function(a, b) {
            (0, a.__gpp)("getSection", function(c) {
                b.Hb({
                    ac: null != c ? c : void 0,
                    xe: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        RE = {
            Gd: function(a) {
                return a.listener
            },
            Kc: function(a, b) {
                a = {};
                return a.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, a
            },
            uc: function(a, b) {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        SE = {
            Gd: function(a) {
                return a.listener
            },
            Kc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            uc: function(a, b) {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                null == a || a(c, b.success)
            }
        },
        TE = {
            Gd: function(a) {
                return a.Hb
            },
            Kc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "getSection",
                    version: "1.1",
                    parameter: a.apiPrefix
                }, c
            },
            uc: function(a, b) {
                b = b.__gppReturn;
                var c;
                a({
                    ac: null != (c = b.returnValue) ? c : void 0,
                    xe: b.success ? void 0 : 2
                })
            }
        },
        UE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.caller = new RC(a, "__gppLocator", function(d) {
                return "function" === typeof d.__gpp
            }, Sf);
            this.caller.j.set("addEventListener", OE);
            this.caller.l.set("addEventListener", RE);
            this.caller.j.set("removeEventListener", PE);
            this.caller.l.set("removeEventListener", SE);
            this.caller.j.set("getDataWithCallback", QE);
            this.caller.l.set("getDataWithCallback", TE);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500
        };
    _.T(UE, _.U);
    UE.prototype.m = function() {
        this.caller.ua();
        _.U.prototype.m.call(this)
    };
    UE.prototype.addEventListener = function(a) {
        var b = this,
            c = _.ev(function() {
                a(VE, !0)
            }),
            d = -1 === this.timeoutMs ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        UC(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    if (void 0 === (null == (g = e.pingData) ? void 0 : g.gppVersion) || "1" === e.pingData.gppVersion || "1.0" === e.pingData.gppVersion) {
                        b.removeEventListener(e.listenerId);
                        var h = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 1,
                                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                applicableSections: [-1]
                            }
                        }
                    } else Array.isArray(e.pingData.applicableSections) && 0 !== e.pingData.applicableSections.length ? h = e : (b.removeEventListener(e.listenerId), h = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(h, f)
                } catch (k) {
                    if (null == e ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (l) {
                        a(WE, !0);
                        return
                    }
                    a(XE, !0)
                }
            }
        })
    };
    UE.prototype.removeEventListener = function(a) {
        UC(this.caller, "removeEventListener", {
            listenerId: a
        })
    };
    var YE = function(a) {
            if (!a) return !1;
            var b = mf(a.split("~")[0] + "A"),
                c = nf(b.slice(0, 6)),
                d = nf(b.slice(6, 12)),
                e = new jA;
            var f = _.Bh(e, 1, c);
            var g = _.Bh(f, 2, d);
            for (var h = b.slice(12), k = nf(h.slice(0, 12)), l = [], m = h.slice(12).replace(/0+$/, ""), n = 0; n < k; n++) {
                if (0 === m.length) throw Error("Found " + n + " of " + k + " sections [" + l + "] but reached end of input [" + h + "]");
                var p = 0 === nf(m[0]);
                m = m.slice(1);
                var r = pf(m, h),
                    w = 0 === l.length ? 0 : l[l.length - 1],
                    u = of (r) + w;
                m = m.slice(r.length);
                if (p) l.push(u);
                else {
                    for (var x = pf(m, h), y = of (x), C = 0; C <= y; C++) l.push(u + C);
                    m = m.slice(x.length)
                }
            }
            if (0 < m.length) throw Error("Found " + k + " sections [" + l + "] but has remaining input [" + m + "], entire input [" + h + "]");
            var D = _.le(g, 3, l, Pc);
            var E = _.A(a, "includes").call(a, "~") ? a.split("~").slice(1) : [];
            for (var J = 0; J < be(D, 3, Qc, 2).length; ++J) {
                var M = be(D, 3, Qc, 2)[J],
                    K = E[J];
                switch (M) {
                    case 8:
                        if (0 === K.length) throw Error("Cannot decode empty USCA section string");
                        var X = K.split(".");
                        if (2 < X.length) throw Error("Expected at most 1 sub-section but got " + (X.length - 1) + " when decoding " + K);
                        var ba = void 0,
                            la = void 0,
                            ra = void 0,
                            Aa = void 0,
                            ya = void 0,
                            Pa = void 0,
                            Fa = void 0,
                            Cb = void 0,
                            bb = void 0,
                            yb = void 0,
                            cc = void 0,
                            Jc = void 0,
                            mc = void 0,
                            Zc = void 0,
                            $c = void 0,
                            ce = void 0,
                            dc = void 0,
                            cb = void 0,
                            Vh = void 0,
                            kl = void 0,
                            Mf = void 0,
                            Eg = void 0,
                            Xh = void 0,
                            nc = mf(X[0]),
                            ud = nf(nc.slice(0, 6));
                        nc = nc.slice(6);
                        if (1 !== ud) throw Error("Unable to decode unsupported USCA Section specification version " + ud + " - only version 1 is supported.");
                        if (nc.length < rA)
                            if (nc.length + 8 >= rA) nc += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + rA + " but was " + (nc.length + 8));
                        for (var yc = 0, gb = [], ec = 0; ec < qA.length; ec++) {
                            var Le = qA[ec];
                            gb.push(nf(nc.slice(yc, yc + Le)));
                            yc += Le
                        }
                        var zc = new mA;
                        Xh = _.Bh(zc, 1, ud);
                        var Ac = gb.shift();
                        Eg = _.I(Xh, 2, Ac);
                        var fq = gb.shift();
                        Mf = _.I(Eg, 3, fq);
                        var SS = gb.shift();
                        kl = _.I(Mf, 4, SS);
                        var TS = gb.shift();
                        Vh = _.I(kl, 5, TS);
                        var US = gb.shift();
                        cb = _.I(Vh, 6, US);
                        var VS = new lA,
                            WS = gb.shift();
                        dc = _.I(VS, 1, WS);
                        var XS = gb.shift();
                        ce = _.I(dc, 2, XS);
                        var YS = gb.shift();
                        $c = _.I(ce, 3, YS);
                        var ZS = gb.shift();
                        Zc = _.I($c, 4, ZS);
                        var $S = gb.shift();
                        mc = _.I(Zc, 5, $S);
                        var aT = gb.shift();
                        Jc = _.I(mc, 6, aT);
                        var bT = gb.shift();
                        cc = _.I(Jc, 7, bT);
                        var cT = gb.shift();
                        yb = _.I(cc, 8, cT);
                        var dT = gb.shift();
                        bb = _.I(yb, 9, dT);
                        Cb = _.wh(cb, 7, bb);
                        var eT = new kA,
                            fT = gb.shift();
                        Fa = _.I(eT, 1, fT);
                        var gT = gb.shift();
                        Pa = _.I(Fa, 2, gT);
                        ya = _.wh(Cb, 8, Pa);
                        var hT = gb.shift();
                        Aa = _.I(ya, 9, hT);
                        var iT = gb.shift();
                        ra = _.I(Aa, 10, iT);
                        var jT = gb.shift();
                        la = _.I(ra, 11, jT);
                        var kT = gb.shift();
                        var eD = ba = _.I(la, 12, kT);
                        if (1 === X.length) var fD = pA(eD);
                        else {
                            var lT = pA(eD),
                                gD = void 0,
                                hD = void 0,
                                iD = void 0,
                                wi = mf(X[1]);
                            if (3 > wi.length) throw Error("Invalid GPC Segment [" + wi + "]. Expected length 3, but was " + wi.length + ".");
                            var Vl = nf(wi.slice(0, 2));
                            if (0 > Vl || 1 < Vl) throw Error("Attempting to decode unknown GPC segment subsection type " + Vl + ".");
                            iD = Vl + 1;
                            var mT = nf(wi.charAt(2)),
                                nT = new nA;
                            hD = _.I(nT, 2, iD);
                            gD = _.Ah(hD, 1, !!mT);
                            fD = _.wh(lT, 2, gD)
                        }
                        var jD = _.di(fD, mA, 1);
                        if (1 === _.Nk(jD, 5, 0) || 1 === _.Nk(jD, 6, 0)) return !0;
                        break;
                    case 10:
                        if (0 === K.length) throw Error("Cannot decode empty USCO section string.");
                        var xi = K.split(".");
                        if (2 < xi.length) throw Error("Expected at most 2 segments but got " + xi.length + " when decoding " + K);
                        var oT = void 0,
                            kD = void 0,
                            lD = void 0,
                            mD = void 0,
                            nD = void 0,
                            oD = void 0,
                            pD = void 0,
                            qD = void 0,
                            rD = void 0,
                            sD = void 0,
                            tD = void 0,
                            uD = void 0,
                            vD = void 0,
                            wD = void 0,
                            xD = void 0,
                            yD = void 0,
                            zD = void 0,
                            AD = void 0,
                            Ve = mf(xi[0]),
                            gs = nf(Ve.slice(0, 6));
                        Ve = Ve.slice(6);
                        if (1 !== gs) throw Error("Unable to decode unsupported USCO Section specification version " + gs + " - only version 1 is supported.");
                        if (Ve.length < yA)
                            if (Ve.length + 8 >= yA) Ve += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + yA + " but was " + (Ve.length + 8));
                        for (var hs = 0, Tb = [], is = 0; is < xA.length; is++) {
                            var BD = xA[is];
                            Tb.push(nf(Ve.slice(hs, hs + BD)));
                            hs += BD
                        }
                        var pT = new tA;
                        AD = _.Bh(pT, 1, gs);
                        var qT = Tb.shift();
                        zD = _.I(AD, 2, qT);
                        var rT = Tb.shift();
                        yD = _.I(zD, 3, rT);
                        var sT = Tb.shift();
                        xD = _.I(yD, 4, sT);
                        var tT = Tb.shift();
                        wD = _.I(xD, 5, tT);
                        var uT = Tb.shift();
                        vD = _.I(wD, 6, uT);
                        var vT = new sA,
                            wT = Tb.shift();
                        uD = _.I(vT, 1, wT);
                        var xT = Tb.shift();
                        tD = _.I(uD, 2, xT);
                        var yT = Tb.shift();
                        sD = _.I(tD, 3, yT);
                        var zT = Tb.shift();
                        rD = _.I(sD, 4, zT);
                        var AT = Tb.shift();
                        qD = _.I(rD, 5, AT);
                        var BT = Tb.shift();
                        pD = _.I(qD, 6, BT);
                        var CT = Tb.shift();
                        oD = _.I(pD, 7, CT);
                        nD = _.wh(vD, 7, oD);
                        var DT = Tb.shift();
                        mD = _.I(nD, 8, DT);
                        var ET = Tb.shift();
                        lD = _.I(mD, 9, ET);
                        var FT = Tb.shift();
                        kD = _.I(lD, 10, FT);
                        var GT = Tb.shift();
                        var CD = oT = _.I(kD, 11, GT);
                        if (1 === xi.length) var DD = wA(CD);
                        else {
                            var HT = wA(CD),
                                ED = void 0,
                                FD = void 0,
                                GD = void 0,
                                yi = mf(xi[1]);
                            if (3 > yi.length) throw Error("Invalid GPC Segment [" + yi + "]. Expected length 3, but was " + yi.length + ".");
                            var Wl = nf(yi.slice(0, 2));
                            if (0 > Wl || 1 < Wl) throw Error("Attempting to decode unknown GPC segment subsection type " + Wl + ".");
                            GD = Wl + 1;
                            var IT = nf(yi.charAt(2)),
                                JT = new uA;
                            FD = _.I(JT, 2, GD);
                            ED = _.Ah(FD, 1, !!IT);
                            DD = _.wh(HT, 2, ED)
                        }
                        var HD = _.di(DD, tA, 1);
                        if (1 === _.Nk(HD, 5, 0) || 1 === _.Nk(HD, 6, 0)) return !0;
                        break;
                    case 12:
                        if (0 === K.length) throw Error("Cannot decode empty usct section string.");
                        var zi = K.split(".");
                        if (2 < zi.length) throw Error("Expected at most 2 segments but got " + zi.length + " when decoding " + K);
                        var KT = void 0,
                            ID = void 0,
                            JD = void 0,
                            KD = void 0,
                            LD = void 0,
                            MD = void 0,
                            ND = void 0,
                            OD = void 0,
                            PD = void 0,
                            QD = void 0,
                            RD = void 0,
                            SD = void 0,
                            TD = void 0,
                            UD = void 0,
                            VD = void 0,
                            WD = void 0,
                            XD = void 0,
                            YD = void 0,
                            ZD = void 0,
                            $D = void 0,
                            aE = void 0,
                            bE = void 0,
                            We = mf(zi[0]),
                            js = nf(We.slice(0, 6));
                        We = We.slice(6);
                        if (1 !== js) throw Error("Unable to decode unsupported USCT Section specification version " + js + " - only version 1 is supported.");
                        if (We.length < GA)
                            if (We.length + 8 >= GA) We += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + GA + " but was " + (We.length + 8));
                        for (var ks = 0, Eb = [], ls = 0; ls < FA.length; ls++) {
                            var cE = FA[ls];
                            Eb.push(nf(We.slice(ks, ks + cE)));
                            ks += cE
                        }
                        var LT = new BA;
                        bE = _.Bh(LT, 1, js);
                        var MT = Eb.shift();
                        aE = _.I(bE, 2, MT);
                        var NT = Eb.shift();
                        $D = _.I(aE, 3, NT);
                        var OT = Eb.shift();
                        ZD = _.I($D, 4, OT);
                        var PT = Eb.shift();
                        YD = _.I(ZD, 5, PT);
                        var QT = Eb.shift();
                        XD = _.I(YD, 6, QT);
                        var RT = new AA,
                            ST = Eb.shift();
                        WD = _.I(RT, 1, ST);
                        var TT = Eb.shift();
                        VD = _.I(WD, 2, TT);
                        var UT = Eb.shift();
                        UD = _.I(VD, 3, UT);
                        var VT = Eb.shift();
                        TD = _.I(UD, 4, VT);
                        var WT = Eb.shift();
                        SD = _.I(TD, 5, WT);
                        var XT = Eb.shift();
                        RD = _.I(SD, 6, XT);
                        var YT = Eb.shift();
                        QD = _.I(RD, 7, YT);
                        var ZT = Eb.shift();
                        PD = _.I(QD, 8, ZT);
                        OD = _.wh(XD, 7, PD);
                        var $T = new zA,
                            aU = Eb.shift();
                        ND = _.I($T, 1, aU);
                        var bU = Eb.shift();
                        MD = _.I(ND, 2, bU);
                        var cU = Eb.shift();
                        LD = _.I(MD, 3, cU);
                        KD = _.wh(OD, 8, LD);
                        var dU = Eb.shift();
                        JD = _.I(KD, 9, dU);
                        var eU = Eb.shift();
                        ID = _.I(JD, 10, eU);
                        var fU = Eb.shift();
                        var dE = KT = _.I(ID, 11, fU);
                        if (1 === zi.length) var eE = EA(dE);
                        else {
                            var gU = EA(dE),
                                fE = void 0,
                                gE = void 0,
                                hE = void 0,
                                Ai = mf(zi[1]);
                            if (3 > Ai.length) throw Error("Invalid GPC Segment [" + Ai + "]. Expected length 3, but was " + Ai.length + ".");
                            var Xl = nf(Ai.slice(0, 2));
                            if (0 > Xl || 1 < Xl) throw Error("Attempting to decode unknown GPC segment subsection type " + Xl + ".");
                            hE = Xl + 1;
                            var hU = nf(Ai.charAt(2)),
                                iU = new CA;
                            gE = _.I(iU, 2, hE);
                            fE = _.Ah(gE, 1, !!hU);
                            eE = _.wh(gU, 2, fE)
                        }
                        var iE = _.di(eE, BA, 1);
                        if (1 === _.Nk(iE, 5, 0) || 1 === _.Nk(iE, 6, 0)) return !0;
                        break;
                    case 9:
                        if (0 === K.length) throw Error("Cannot decode empty USVA section string.");
                        var Xe = mf(K),
                            ms = nf(Xe.slice(0, 6));
                        Xe = Xe.slice(6);
                        if (1 !== ms) throw Error("Unable to decode unsupported USVA Section specification version " + ms + " - only version 1 is supported.");
                        if (Xe.length < KA)
                            if (Xe.length + 8 >= KA) Xe += "00000000";
                            else throw Error("Expected bitstring minus version plus padding to be at least of length " + KA + " but was " + (Xe.length + 8));
                        for (var ns = 0, Pb = [], os = 0; os < JA.length; os++) {
                            var jE = JA[os];
                            Pb.push(nf(Xe.slice(ns, ns + jE)));
                            ns += jE
                        }
                        var jU = ms,
                            kU = new IA;
                        var lU = _.Bh(kU, 1, jU);
                        var mU = Pb.shift();
                        var nU = _.I(lU, 2, mU);
                        var oU = Pb.shift();
                        var pU = _.I(nU, 3, oU);
                        var qU = Pb.shift();
                        var rU = _.I(pU, 4, qU);
                        var sU = Pb.shift();
                        var tU = _.I(rU, 5, sU);
                        var uU = Pb.shift();
                        var vU = _.I(tU, 6, uU);
                        var wU = new HA,
                            xU = Pb.shift();
                        var yU = _.I(wU, 1, xU);
                        var zU = Pb.shift();
                        var AU = _.I(yU, 2, zU);
                        var BU = Pb.shift();
                        var CU = _.I(AU, 3, BU);
                        var DU = Pb.shift();
                        var EU = _.I(CU, 4, DU);
                        var FU = Pb.shift();
                        var GU = _.I(EU, 5, FU);
                        var HU = Pb.shift();
                        var IU = _.I(GU, 6, HU);
                        var JU = Pb.shift();
                        var KU = _.I(IU, 7, JU);
                        var LU = Pb.shift();
                        var MU = _.I(KU, 8, LU);
                        var NU = _.wh(vU, 7, MU);
                        var OU = Pb.shift();
                        var PU = _.I(NU, 8, OU);
                        var QU = Pb.shift();
                        var RU = _.I(PU, 9, QU);
                        var SU = Pb.shift();
                        var TU = _.I(RU, 10, SU);
                        var UU = Pb.shift(),
                            kE = _.I(TU, 11, UU);
                        if (1 === _.Nk(kE, 5, 0) || 1 === _.Nk(kE, 6, 0)) return !0
                }
            }
            return !1
        },
        XE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        VE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        WE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };
    var Lm = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, Lm.prototype)
    };
    _.T(Lm, Error);
    Lm.prototype.name = "PublisherInputError";
    var ZE = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, ZE.prototype)
    };
    _.T(ZE, Error);
    ZE.prototype.name = "ServerError";
    var $E = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, $E.prototype)
    };
    _.T($E, Error);
    $E.prototype.name = "NetworkError";
    var aF = null,
        bF = function() {
            if (null === aF) {
                aF = "";
                try {
                    var a = "";
                    try {
                        a = _.t.top.location.hash
                    } catch (c) {
                        a = _.t.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        aF = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return aF
        };
    var $f = function() {};
    $f.prototype.g = function() {};
    $f.prototype.l = function() {};
    $f.prototype.m = function() {
        return []
    };
    $f.prototype.v = function() {
        return []
    };
    var lg = function(a, b) {
        a.g = Zf(1, b, function() {});
        a.m = function(c, d) {
            return Zf(2, b, function() {
                return []
            })(c, 2, d)
        };
        a.v = function() {
            return Zf(3, b, function() {
                return []
            })(2)
        };
        a.l = function(c) {
            Zf(16, b, function() {})(c, 2)
        }
    };
    var jg = function() {
            this.g = function() {}
        },
        ng = function(a, b) {
            a.g = Zf(14, b, function() {})
        };
    var ki = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.Di(b.innerWidth, b.innerHeight)).round() : _.fz(b || window).round()
            } catch (d) {
                return new _.Di(-12245933, -12245933)
            }
        },
        cF = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        vt = function(a, b) {
            b = void 0 === b ? _.t : b;
            a = a.scrollingElement || cF(a);
            return new _.ui(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        Pi = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var dF = function(a) {
        this.C = _.B(a)
    };
    _.T(dF, _.F);
    var Uf = function(a) {
            return _.N(a, 5)
        },
        eF = function(a, b) {
            Lj(a, 13, b)
        },
        fF = function(a, b) {
            Lj(a, 12, b)
        },
        gF = function(a, b) {
            return _.le(a, 10, b, _.Xc)
        },
        hF = function(a, b) {
            return Zn(a, 11, b)
        };
    dF.aa = [10];
    var jF, kF, lF;
    _.iF = function(a) {
        this.g = a;
        this.m = 0
    };
    jF = function(a, b) {
        if (0 === a.m) {
            if (_.am(a, "__gads", b)) b = !0;
            else {
                var c = a.g;
                Uf(b) && Wf(c) && (new Xf(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === Yf("GoogleAdServingTest", b, a.g)) {
                    var d = a.g;
                    Uf(b) && Wf(d) && LE(new Xf(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.m = b ? 2 : 1
        }
        return 2 === a.m
    };
    _.am = function(a, b, c) {
        return c ? Yf(b, c, a.g) : null
    };
    kF = function(a, b, c, d) {
        if (d) {
            var e = _.Cf(c, 2) - Date.now() / 1E3;
            e = {
                lg: Math.max(e, 0),
                path: _.R(c, 3),
                domain: _.R(c, 4),
                Il: !1
            };
            c = c.getValue();
            a = a.g;
            Uf(d) && Wf(a) && (new Xf(a.document)).set(b, c, e)
        }
    };
    lF = function(a, b, c) {
        if (c && Yf(b, c, a.g)) {
            var d = a.g.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.z(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.g, Uf(c) && Wf(f) && LE(new Xf(f.document), b, "/", e.value)
        }
    };
    var mF = {},
        nF = (mF[3] = df(_.bv(cv("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), mF);
    ({})[3] = df(_.bv(cv("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var oF = function(a) {
            this.g = a;
            this.m = Xy()
        },
        pF = function(a) {
            var b = {};
            _.hv(a, function(c) {
                b[c.g] = c.m
            });
            return b
        };
    _.qF = _.tu(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
    var rF = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.tb = a;
        this.status = 1;
        this.v = b;
        this.l = c;
        this.F = d;
        this.Bd = !!e;
        this.j = Math.random();
        this.G = {};
        this.g = null;
        this.L = (0, _.Wu)(this.B, this);
        this.H = f
    };
    _.T(rF, _.U);
    rF.prototype.B = function(a) {
        if (!("*" !== this.l && a.origin !== this.l || !this.Bd && a.source != this.v)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.ka(b) && (a = b.i, b.c === this.tb && a != this.j)) {
                if (2 !== this.status) try {
                    this.status = 2, sF(this), this.g && (this.g(), this.g = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.ka(b)) && this.G.hasOwnProperty(a)) this.G[a](b)
            }
        }
    };
    var sF = function(a) {
        var b = {};
        b.c = a.tb;
        b.i = a.j;
        a.H && (b.e = a.H);
        a.v.postMessage(JSON.stringify(b), a.l)
    };
    rF.prototype.o = function() {
        if (1 === this.status) {
            try {
                this.v.postMessage && sF(this)
            } catch (a) {}
            window.setTimeout((0, _.Wu)(this.o, this), 50)
        }
    };
    rF.prototype.connect = function(a) {
        a && (this.g = a);
        _.lb(window, "message", this.L);
        this.F && this.o()
    };
    var tF = function(a, b, c) {
        a.G[b] = c
    };
    rF.prototype.send = function(a, b) {
        var c = {};
        c.c = this.tb;
        c.i = this.j;
        c.s = a;
        c.p = b;
        try {
            this.v.postMessage(JSON.stringify(c), this.l)
        } catch (d) {}
    };
    rF.prototype.m = function() {
        this.status = 3;
        _.Ef(window, "message", this.L);
        _.U.prototype.m.call(this)
    };
    var uF = new _.v.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        vF = new _.v.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var wF = function(a) {
        this.C = _.B(a)
    };
    _.T(wF, _.F);
    var xF = Te(wF);
    var yF = function(a) {
        this.C = _.B(a)
    };
    _.T(yF, _.F);
    var zF = function(a) {
        this.C = _.B(a)
    };
    _.T(zF, _.F);
    var AF, BF, CF, DF;
    _.sq = function(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    };
    AF = function(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };
    BF = function(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    };
    CF = function(a, b) {
        if (3 == _.sq(b)) return !1;
        a();
        return !0
    };
    DF = function(a, b) {
        var c = !0;
        c = void 0 === c ? !1 : c;
        if (!CF(a, b))
            if (c) {
                var d = function() {
                    _.Ef(b, "prerenderingchange", d);
                    a()
                };
                _.lb(b, "prerenderingchange", d)
            } else {
                var e = !1,
                    f = AF(b),
                    g = function() {
                        !e && CF(a, b) && (e = !0, _.Ef(b, f, g))
                    };
                f && _.lb(b, f, g)
            }
    };
    var Mq = function(a, b) {
        this.g = a;
        this.l = b;
        this.m = {}
    };
    Mq.prototype.na = function() {
        var a = this;
        Gq() && (document.addEventListener("touchstart", function(b) {
            a.g(902, function() {
                a.m[b.touches[0].identifier] = Date.now()
            })()
        }, _.gv), document.addEventListener("touchend", function(b) {
            a.g(902, function() {
                var c = b.changedTouches[0],
                    d = c.clientX,
                    e = c.clientY,
                    f = c.force;
                c = a.m[c.identifier];
                if (void 0 !== c) try {
                    var g = Gq(),
                        h = {
                            x: d,
                            y: e,
                            duration_ms: Date.now() - c
                        };
                    if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.A(Object, "assign").call(Object, {}, h, {
                        type: 1,
                        force: f
                    })));
                    else {
                        var k, l, m;
                        null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (m = l.reportGmaTouchEvent) || m.postMessage(h)
                    }
                } catch (n) {
                    a.l("paw_sigs", {
                        msg: "reportTouchError",
                        err: n instanceof Error ? n.message : "nonError"
                    })
                }
            })()
        }, _.gv))
    };
    var Hq = function(a, b, c, d, e) {
            var f = 200,
                g = zq;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.gg())),
                k = 0,
                l = function(m) {
                    try {
                        var n = "object" === typeof m.data ? m.data : JSON.parse(m.data);
                        h === n.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), n.signal ? c(n.signal) : n.error && d(n.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == m.data ? "null" : 500 < m.data.length ? m.data.substring(0, 500) : m.data
                        })
                    }
                };
            window.addEventListener("message", function(m) {
                e(903, function() {
                    l(m)
                })()
            });
            a.postMessage(_.A(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        Gq = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    _.pg = function() {
        var a = this;
        this.promise = new _.v.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var HF, GF, JF, IF;
    _.EF = function() {
        this.l = "&";
        this.m = {};
        this.v = 0;
        this.g = []
    };
    _.FF = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    HF = function(a, b, c, d, e) {
        var f = [];
        _.Rl(a, function(g, h) {
            (g = GF(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    GF = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(GF(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(HF(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    JF = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = IF(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.g.length; f++)
            for (var g = a.g[f], h = a.m[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = HF(h[k], a.l, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.l;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    IF = function(a) {
        var b = 1,
            c;
        for (c in a.m) b = c.length > b ? c.length : b;
        return 3997 - b - a.l.length - 1
    };
    _.KF = function() {
        this.g = Math.random()
    };
    _.Xg = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.g : Math.random()) < (e || .001)) try {
            if (c instanceof _.EF) var f = c;
            else f = new _.EF, _.Rl(c, function(h, k) {
                var l = f,
                    m = l.v++;
                h = _.FF(k, h);
                l.g.push(m);
                l.m[m] = h
            });
            var g = JF(f, "/pagead/gen_204?id=" + b + "&");
            g && YC(_.t, g)
        } catch (h) {}
    };
    var LF = function(a) {
        this.C = _.B(a)
    };
    _.T(LF, _.F);
    var MF = function(a, b) {
        return _.Zh(a, 1, b)
    };
    LF.aa = [1];
    var NF = function(a) {
        this.C = _.B(a)
    };
    _.T(NF, _.F);
    NF.aa = [1];
    var OF = function(a) {
        this.C = _.B(a)
    };
    _.T(OF, _.F);
    var PF = function(a, b) {
        return _.I(a, 1, b)
    };
    var QF = function(a) {
        this.C = _.B(a)
    };
    _.T(QF, _.F);
    var RF = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, RF.prototype);
        this.name = "InputError"
    };
    _.T(RF, Error);
    var SF = function() {
            this.bb = !1
        },
        TF = function() {
            SF.apply(this, arguments);
            this.g = [];
            this.Pd = new _.pg
        };
    _.T(TF, SF);
    var VF = function(a, b) {
            a.bb || (a.bb = !0, a.Pc = b, a.Pd.resolve(b), _.G(EB) && UF(a))
        },
        WF = function(a, b) {
            a.bb = !0;
            a.We = b;
            a.Pd.reject(b);
            _.G(EB) && UF(a)
        },
        UF = function(a) {
            for (var b = _.z(a.g), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.Pc);
            a.g.length = 0
        };
    TF.prototype.oe = function() {
        this.g.length = 0
    };
    var eB = function(a, b) {
        _.G(EB) && a.g.push(b)
    };
    _.ou.Object.defineProperties(TF.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Pd.promise
            }
        },
        yb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.bb
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.We
            }
        }
    });
    var Cn = function() {
        TF.apply(this, arguments)
    };
    _.T(Cn, TF);
    _.q = Cn.prototype;
    _.q.D = function(a) {
        VF(this, a)
    };
    _.q.Aa = function(a) {
        VF(this, null != a ? a : null)
    };
    _.q.Z = function() {
        VF(this, null)
    };
    _.q.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            VF(b, c)
        })
    };
    _.q.fb = function(a) {
        this.bb || (this.bb = !0, this.Pc = null, this.We = a, this.Pd.reject(a), _.G(EB) && UF(this))
    };
    var XF = function() {
        TF.apply(this, arguments)
    };
    _.T(XF, TF);
    XF.prototype.D = function(a) {
        VF(this, a)
    };
    XF.prototype.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            return void VF(b, c)
        })
    };
    XF.prototype.fb = function(a) {
        this.bb || (this.bb = !0, this.We = a, this.Pd.reject(a))
    };
    var YF = function() {
        XF.apply(this, arguments)
    };
    _.T(YF, XF);
    YF.prototype.Aa = function(a) {
        VF(this, null != a ? a : null)
    };
    YF.prototype.Z = function() {
        VF(this, null)
    };
    YF.prototype.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.Aa(c)
        })
    };
    var ZF = function(a) {
        this.bb = !1;
        this.Mb = a
    };
    _.T(ZF, SF);
    ZF.prototype.yb = function() {
        return this.Mb.bb
    };
    ZF.prototype.ag = function() {
        return null != this.Mb.Pc
    };
    _.ou.Object.defineProperties(ZF.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Mb.We
            }
        }
    });
    var $F = function(a) {
        ZF.call(this, a);
        this.Mb = a
    };
    _.T($F, ZF);
    _.ou.Object.defineProperties($F.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Mb.Pc
            }
        }
    });
    var aG = function(a) {
        ZF.call(this, a);
        this.Mb = a
    };
    _.T(aG, ZF);
    _.ou.Object.defineProperties(aG.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Mb.Pc) ? a : null
            }
        }
    });
    var bG = function() {
        ZF.apply(this, arguments)
    };
    _.T(bG, ZF);
    _.ou.Object.defineProperties(bG.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Mb.Pc) ? a : null
            }
        }
    });
    var Gn = function() {
        TF.apply(this, arguments)
    };
    _.T(Gn, TF);
    Gn.prototype.notify = function() {
        VF(this, null)
    };
    var cG = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        dG = function(a, b) {
            b = void 0 === b ? !1 : b;
            TF.call(this);
            var c = this;
            this.l = a;
            this.m = 0;
            if (_.G(EB)) {
                a = _.z(this.l);
                for (var d = a.next(), e = {}; !d.done; e = {
                        Md: e.Md
                    }, d = a.next()) e.Md = d.value, eB(e.Md, function(f) {
                    return function(g) {
                        c.m += 1;
                        f.Md.error ? WF(c, f.Md.error) : b || null !== g ? VF(c, null != g ? g : null) : c.m === c.l.length && VF(c, null)
                    }
                }(e))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    WF(c, g);
                    return null
                })
            }), _.A(_.v.Promise, "any").call(_.v.Promise, a).then(function(f) {
                c.bb || VF(c, f)
            }, function() {
                c.bb || VF(c, null)
            })
        };
    _.T(dG, TF);
    var eG = function(a, b) {
        TF.call(this);
        this.timeoutMs = a;
        this.defaultValue = b
    };
    _.T(eG, TF);
    var zg = function(a) {
        setTimeout(function() {
            var b;
            VF(a, null != (b = a.defaultValue) ? b : null)
        }, a.timeoutMs)
    };
    var fG = function(a) {
        _.U.call(this);
        this.G = a;
        this.g = [];
        this.l = [];
        this.j = [];
        this.v = []
    };
    _.T(fG, _.U);
    var gG = function(a, b, c) {
        a.l.push({
            Tb: void 0 === c ? !1 : c,
            Ab: b
        });
        _.G(EB) && eB(b, a.G)
    };
    fG.prototype.m = function() {
        this.g.length = 0;
        this.j.length = 0;
        if (_.G(EB))
            for (var a = _.z(this.l), b = a.next(); !b.done; b = a.next()) b.value.Ab.oe();
        this.l.length = 0;
        this.v.length = 0;
        _.U.prototype.m.call(this)
    };
    var iG = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.id = a;
        this.timeoutMs = b;
        this.L = c;
        this.Ha = this.Ca = this.wa = this.started = !1;
        this.v = new fG(function() {
            hG(d)
        });
        _.S(this, this.v)
    };
    _.T(iG, _.U);
    iG.prototype.start = function() {
        var a = this,
            b;
        return _.nb(function(c) {
            if (1 == c.g) {
                if (a.started) return c.return();
                a.started = !0;
                c.l = 2;
                return c.yield(Ag(a.v.l, a.v.v, a.timeoutMs), 4)
            }
            if (2 != c.g) {
                if (!a.J) {
                    for (var d = 0, e = _.z(a.v.j), f = e.next(); !f.done; f = e.next()) {
                        if (!f.value.ag()) throw Error("missing input: " + a.id + "/" + d);
                        ++d
                    }
                    a.g()
                }
                c.g = 0;
                c.l = 0
            } else {
                b = pb(c);
                if (a.J) return c.return();
                b instanceof RF ? a.G(b) : b instanceof Error && (a.L ? a.L(a.id, b) : a.H(b), a.l(b));
                c.g = 0
            }
        })
    };
    var hG = function(a) {
            if (!a.started && a.wa) try {
                var b = a.v.l,
                    c = a.timeoutMs ? b.filter(function(k) {
                        return !k.Tb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.Tb
                    }),
                    e, f = null == (e = _.A(b, "find").call(b, function(k) {
                        return void 0 !== k.Ab.error
                    })) ? void 0 : e.Ab.error;
                if (f) throw a.started = !0, f;
                if (!c.some(function(k) {
                        return !k.Ab.yb
                    })) {
                    if (d.length)
                        if (_.G(yg)) {
                            for (var g = _.z(a.v.v), h = g.next(); !h.done; h = g.next()) zg(h.value);
                            if (d.some(function(k) {
                                    return !k.Ab.yb
                                })) return
                        } else if (a.Ca || (a.Ca = !0, setTimeout(function() {
                            a.Ha = !0;
                            hG(a)
                        }, a.timeoutMs)), d.some(function(k) {
                            return !k.Ab.yb
                        }) && !a.Ha) return;
                    a.started = !0;
                    a.g()
                }
            } catch (k) {
                a.J || (k instanceof RF ? a.G(k) : k instanceof Error && (a.L ? a.L(a.id, k) : a.H(k), a.l(k)))
            }
        },
        V = function(a, b) {
            b = void 0 === b ? new Cn : b;
            a.v.g.push(b);
            return b
        },
        jG = function(a) {
            var b = void 0 === b ? new XF : b;
            a.v.g.push(b);
            return b
        },
        kG = function(a) {
            var b = void 0 === b ? new YF : b;
            a.v.g.push(b);
            return b
        },
        lG = function(a, b) {
            b = void 0 === b ? new Gn : b;
            a.v.g.push(b);
            return b
        },
        W = function(a, b) {
            gG(a.v, b);
            b = new $F(b);
            a.v.j.push(b);
            return b
        },
        Y = function(a, b) {
            gG(a.v, b);
            return new aG(b)
        },
        mG = function(a, b) {
            if (_.G(yg)) {
                if (a.timeoutMs) {
                    var c = new eG(a.timeoutMs, void 0);
                    b = new dG([b, c], !0);
                    gG(a.v, b, !0);
                    a.v.v.push(c);
                    return new aG(b)
                }
                gG(a.v, b);
                return new aG(b)
            }
            gG(a.v, b, !0);
            return new aG(b)
        },
        nG = function(a, b) {
            gG(a.v, b)
        },
        oG = function(a, b) {
            if (_.G(yg))
                if (a.timeoutMs) {
                    var c = new eG(a.timeoutMs);
                    b = new dG([b, c], !0);
                    gG(a.v, b, !0);
                    a.v.v.push(c)
                } else nG(a, b);
            else gG(a.v, b, !0)
        },
        pG = function(a, b) {
            b = new dG(b);
            gG(a.v, b);
            b = new $F(b);
            a.v.j.push(b);
            return b
        };
    iG.prototype.G = function() {};
    iG.prototype.l = function(a) {
        if (!this.L && this.v.g.length) {
            a = new RF(a.message);
            for (var b = _.z(this.v.g), c = b.next(); !c.done; c = b.next()) c = c.value, c.yb || WF(c, a)
        }
    };
    var qG = function(a, b, c, d, e, f) {
        iG.call(this, a, e, f);
        this.f = b;
        this.B = d;
        a = {};
        c = _.z(_.A(Object, "entries").call(Object, c));
        for (b = c.next(); !b.done; b = c.next()) d = _.z(b.value), b = d.next().value, (d = d.next().value) && (a[b] = W(this, d));
        this.o = a
    };
    _.T(qG, iG);
    qG.prototype.g = function() {
        for (var a = this.f, b = {}, c = _.z(_.A(Object, "entries").call(Object, this.o)), d = c.next(); !d.done; d = c.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            b[d] = e.value
        }
        a = a.call(this, b, this.B);
        this.j(a)
    };
    qG.prototype.H = function() {};
    var zp = function(a, b, c, d, e, f) {
        qG.call(this, a, b, c, d, e, f);
        this.output = V(this, new Cn)
    };
    _.T(zp, qG);
    zp.prototype.j = function(a) {
        this.output.Ka(a)
    };
    var rG = function(a, b, c, d, e, f, g) {
        qG.call(this, a, b, c, d, f, g);
        this.finished = new Gn;
        a = _.A(Object, "keys").call(Object, e);
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this[b.value] = V(this)
    };
    _.T(rG, qG);
    rG.prototype.j = function(a) {
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (var b = a.next(); !b.done; b = a.next()) {
            var c = _.z(b.value);
            b = c.next().value;
            c = c.next().value;
            VF(this[b], c)
        }
        this.finished.notify()
    };
    var sG = function(a) {
        this.g = void 0 === a ? function() {} : a
    };
    var Pj = function(a) {
        a = void 0 === a ? new sG : a;
        _.U.call(this);
        this.o = a;
        this.j = [];
        this.G = [];
        this.B = {};
        this.v = [];
        this.l = new _.pg;
        this.g = {}
    };
    _.T(Pj, _.U);
    var O = function(a, b) {
            _.S(a, b);
            a.j.push(b);
            return b
        },
        jk = function(a, b) {
            b = _.z(b);
            for (var c = b.next(); !c.done; c = b.next()) O(a, c.value)
        },
        tG = function(a, b, c, d, e, f) {
            b = new rG(b, c, d, e, f, void 0, a.o.g);
            return O(a, b)
        },
        Ss = function(a, b) {
            a.G.push(b);
            _.S(a, b)
        },
        Yj = function(a) {
            var b, c, d, e, f, g, h, k, l, m, n, p;
            return _.nb(function(r) {
                switch (r.g) {
                    case 1:
                        if (!a.v.length) {
                            r.g = 2;
                            break
                        }
                        return r.yield(_.v.Promise.all(a.v.map(function(w) {
                            return w.l.promise
                        })), 2);
                    case 2:
                        b = _.z(a.j);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.G(EB) ? (d.wa = !0, hG(d)) : d.start();
                        e = _.z(a.G);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, Yj(g);
                        if (!a.g) {
                            r.g = 4;
                            break
                        }
                        h = _.A(Object, "keys").call(Object, a.g);
                        if (!h.length) {
                            r.g = 4;
                            break
                        }
                        return r.yield(_.v.Promise.all(_.A(Object, "values").call(Object, a.g).map(function(w) {
                            return w.promise
                        })), 6);
                    case 6:
                        for (k = r.m, l = 0, m = _.z(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.B[p] = k[l++];
                    case 4:
                        return a.l.resolve(a.B), r.return(a.l.promise)
                }
            })
        };
    Pj.prototype.m = function() {
        _.U.prototype.m.call(this);
        this.j.length = 0;
        this.G.length = 0;
        this.v.length = 0
    };
    var uG = function(a) {
        this.C = _.B(a)
    };
    _.T(uG, _.F);
    uG.aa = [1];
    var vG = [0, qx, Yx];
    var wG = function(a) {
        this.C = _.B(a)
    };
    _.T(wG, _.F);
    wG.aa = [1, 2];
    wG.prototype.g = Se([0, qx, Yx, qx, vG]);
    var yG, xG;
    yG = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new xG;
        this.sideRailProcessedFixedElements = new _.v.Set;
        this.sideRailAvailableSpace = new _.v.Map;
        this.sideRailPlasParam = new _.v.Map
    };
    _.mh = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.v.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.v.Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.v.Map)) : a.google_reactive_ads_global_state = new yG;
        return a.google_reactive_ads_global_state
    };
    xG = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var CG, EG, AG;
    _.zG = function(a) {
        this.g = _.mh(a).floatingAdsStacking
    };
    _.BG = function(a, b) {
        return new AG(a, b)
    };
    CG = function(a) {
        a = _.uz(a.g.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    _.DG = function(a, b) {
        a.g.maxZIndexListeners.push(b);
        b(CG(a))
    };
    EG = function(a) {
        var b = CG(a);
        _.hv(a.g.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    AG = function(a, b) {
        this.m = a;
        this.l = b;
        this.g = null
    };
    _.FG = function(a) {
        if (null == a.g) {
            var b = a.m,
                c = a.l,
                d = b.g.nextRestrictionId++;
            b.g.maxZIndexRestrictions[d] = c;
            EG(b);
            a.g = d
        }
    };
    _.GG = function(a) {
        if (null != a.g) {
            var b = a.m;
            delete b.g.maxZIndexRestrictions[a.g];
            EG(b);
            a.g = null
        }
    };
    _.dp = 728 * 1.38;
    var Rg, HG;
    _.Vg = function(a, b) {
        b = void 0 === b ? {} : b;
        this.ka = a;
        this.Ba = b
    };
    _.IG = function(a, b) {
        var c = Og(a.ka.document, b);
        if (c) {
            var d;
            if (!(d = HG(a, c, b))) a: {
                d = a.ka.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    var e = HG(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    };
    Rg = function(a, b) {
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next())
            if (c = _.IG(a, c.value)) return c;
        return null
    };
    HG = function(a, b, c) {
        if ("fixed" !== aA(b, "position")) return null;
        var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= _.Bi(_.fA, b).width && 1 >= _.Bi(_.fA, b).height || a.Ba.ck && !a.Ba.ck(b) ? !0 : !1;
        a.Ba.Ch && a.Ba.Ch(b, c, d);
        return d ? null : b
    };
    var Qg = 90 * 1.38;
    var JG, KG, LG;
    JG = _.tu(["* { pointer-events: none; }"]);
    KG = function(a, b) {
        var c = _.rf("STYLE", a);
        c.textContent = _.Pv(new _.Ov(JG[0], Nv));
        null == a || a.head.appendChild(c);
        setTimeout(function() {
            null == a || a.head.removeChild(c)
        }, b)
    };
    _.MG = function(a, b, c) {
        if (!a.body) return null;
        var d = new LG;
        d.apply(a, b);
        return function() {
            var e = c || 0;
            0 < e && KG(b.document, e);
            _.Yz(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.l,
                position: d.v,
                top: d.J
            });
            b.scrollTo(0, d.m)
        }
    };
    LG = function() {
        this.g = this.J = this.v = this.l = null;
        this.m = 0
    };
    LG.prototype.apply = function(a, b) {
        this.l = a.body.style.overflow;
        this.v = a.body.style.position;
        this.J = a.body.style.top;
        this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.m = _.Mg(b);
        _.Yz(a.body, "top", -this.m + "px")
    };
    var Zo;
    Zo = function(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            var b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return "__storage_test__" === b
        } catch (c) {
            return !1
        }
    };
    _.ap = function(a, b) {
        return 0 >= b || null == a || !Zo(a) ? null : eh(a, b)
    };
    _.$o = function(a) {
        return !!a && 1 > a.length
    };
    var ln = function(a) {
            var b = void 0 === b ? _.Wh(_.t) : b;
            this.id = a;
            this.g = .001 > Math.random();
            this.Nd = {
                pvsid: String(b)
            }
        },
        NG = function(a) {
            a = qh(a);
            var b;
            bi.set(a, (null != (b = bi.get(a)) ? b : 0) + 1)
        },
        ai = function() {
            return [].concat(_.oh(_.A(bi, "values").call(bi))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        lj = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.Nd[b] = c : delete a.Nd[b])
        },
        nn = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if (OG()) b = !0;
            else {
                var c = a.g;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && YC(window, PG(a) || "", void 0, !0)
        },
        PG = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.Rl(a.Nd, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        QG = function(a) {
            var b = [].concat(_.oh(_.A(bi, "keys").call(bi)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? lj(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), lj(a, "nw_id", b.join()))
        },
        kj = function(a, b) {
            lj(a, "vrg", String(b.tc || b.ab));
            QG(a);
            lj(a, "nslots", ai().toString());
            b = _.bg();
            b.length && lj(a, "eid", b.join());
            lj(a, "pub_url", document.URL)
        },
        ej = function(a, b, c) {
            c = void 0 === c ? .001 : c;
            if (void 0 === c || 0 > c || 1 < c) c = .001;
            Math.random() < c && (a = new ln(a), b(a), nn(a))
        },
        bi = new _.v.Map,
        OG = Mi(function() {
            return !!yz()
        });
    var RG = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.slotId = e;
        this.taskId = void 0;
        this.uniqueId = Math.random()
    };
    var SG, TG, UG, VG, WG;
    SG = _.t.performance;
    TG = !!(SG && SG.mark && SG.measure && SG.clearMarks);
    UG = Mi(function() {
        var a;
        if (a = TG) a = bF(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    VG = function(a, b) {
        this.m = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.m = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.g = UG() || (null != c ? c : Math.random() < a)
    };
    _.Qh = function(a) {
        a && SG && UG() && (SG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), SG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    WG = function(a, b, c, d, e, f) {
        a.g && (b = new RG(b, c, d, void 0 === e ? 0 : e, f), !a.g || 2048 < a.m.length || a.m.push(b))
    };
    VG.prototype.start = function(a, b) {
        if (!this.g) return null;
        a = new RG(a, b, _.Zg() || _.Yg());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        SG && UG() && SG.mark(b);
        return a
    };
    VG.prototype.end = function(a) {
        if (this.g && "number" === typeof a.value) {
            a.duration = (_.Zg() || _.Yg()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            SG && UG() && SG.mark(b);
            !this.g || 2048 < this.m.length || this.m.push(a)
        }
    };
    var Kr = function(a, b, c) {
        var d = _.Zg();
        d && WG(a, b, 9, d, 0, c)
    };
    var Nh = function() {
        VG.call(this, _.G(Oh) || _.G(AC) ? 1 : 0, _.t);
        this.l = 0;
        var a = _.G(Oh) || _.G(AC);
        _.t.google_measure_js_timing = a || _.t.google_measure_js_timing
    };
    _.T(Nh, VG);
    _.XG = function(a) {
        this.context = a
    };
    _.XG.prototype.Fb = function(a, b) {
        return Rh(this.context, a, b)
    };
    _.XG.prototype.va = function(a, b) {
        return Lh(this.context, a, b)
    };
    _.XG.prototype.sb = function(a, b) {
        Ph(this.context, a, b);
        return !1
    };
    _.XG.prototype.Uc = ca(4);
    var YG = {},
        ZG = (YG.companion_ads = "companionAds", YG.content = "content", YG.publisher_ads = "pubads", YG);
    var Nn = function(a) {
        this.C = _.B(a)
    };
    _.T(Nn, _.F);
    var Qm = function(a) {
        var b = new Nn;
        return Lj(b, 1, a)
    };
    var Vs = function(a) {
        this.C = _.B(a)
    };
    _.T(Vs, _.F);
    var zs = function(a) {
        this.C = _.B(a)
    };
    _.T(zs, _.F);
    zs.aa = [1];
    var Ql = function(a) {
        this.C = _.B(a)
    };
    _.T(Ql, _.F);
    var ll = function(a) {
        this.C = _.B(a)
    };
    _.T(ll, _.F);
    var jl = function(a, b) {
            return Zn(a, 1, b)
        },
        pl = function(a) {
            return _.xo(a, 2, 2)
        },
        il = function(a, b) {
            return _.Zh(a, 2, b)
        },
        Fl = function(a, b) {
            return hx(a, 2, b)
        };
    ll.aa = [2];
    var vs = function(a) {
        this.C = _.B(a)
    };
    _.T(vs, _.F);
    vs.aa = [2, 3];
    var jq = function(a) {
        this.C = _.B(a)
    };
    _.T(jq, _.F);
    var mq = function(a, b) {
            return _.no(a, 1, b)
        },
        kq = function(a, b) {
            return _.Zh(a, 2, b)
        };
    jq.aa = [2];
    var xs = function(a) {
        this.C = _.B(a)
    };
    _.T(xs, _.F);
    var lq = function(a, b) {
        Mj(a, 1, jq, b)
    };
    xs.aa = [1];
    var ts = function(a) {
        this.C = _.B(a)
    };
    _.T(ts, _.F);
    var $G = function(a) {
        this.C = _.B(a)
    };
    _.T($G, _.F);
    $G.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.no(this, 5, a)
    };
    $G.prototype.clearTagForChildDirectedTreatment = function() {
        return _.Gi(this, 5)
    };
    $G.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.no(this, 6, a)
    };
    var aH = function(a) {
        this.C = _.B(a)
    };
    _.T(aH, _.F);
    aH.prototype.getCategoryExclusions = function(a) {
        return ax(this, 3, a)
    };
    aH.prototype.Ma = function() {
        return _.gi(this, ll, 14)
    };
    aH.prototype.kc = function() {
        return _.di(this, Ql, 18)
    };
    var Gt = function(a) {
        return _.di(a, $G, 25)
    };
    aH.prototype.getCorrelator = function() {
        return ir(this, 26)
    };
    aH.prototype.setCorrelator = function(a) {
        return _.Gi(this, 26, null == a ? a : hd(a))
    };
    aH.prototype.He = function() {
        return us(this, ts, 33)
    };
    aH.aa = [2, 3, 14];
    var Fi = function() {
        this.g = new _.v.Map
    };
    var bH = {},
        pi = (bH[253] = !1, bH[246] = [], bH[150] = "", bH[221] = !1, bH[36] = /^true$/.test("false"), bH[172] = null, bH[260] = void 0, bH[251] = null, bH),
        oi = function() {
            this.g = !1
        };
    var cH = function() {
            this.m = {};
            this.g = new aH;
            this.l = new _.v.Map;
            this.g.setCorrelator(Mz());
            _.qi(36) && Lj(this.g, 15, !0)
        },
        dH = function(a) {
            var b = Vi(),
                c = a.getDomId();
            if (c && !b.m.hasOwnProperty(c)) {
                var d = _.Ye(Fi),
                    e = ++_.Ye(Nh).l;
                d.g.set(c, e);
                _.Gi(a, 20, _.Sc(e));
                b.m[c] = a
            }
        },
        eH = function(a, b) {
            return a.m[b]
        },
        Vi = function() {
            return _.Ye(cH)
        };
    var fH = Mi(Ji);
    var tj = ["auto", "inherit", "100%"],
        uj = tj.concat(["none"]),
        gH = [2, 1];
    var Sn = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        rj(a, function(e) {
            return d = sj(e, b, 10, 10)
        }, c);
        return d
    };
    var hH = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var iH = function(a, b, c, d, e, f) {
            this.l = _.Sz(a);
            this.m = _.Sz(b);
            this.v = c;
            this.g = _.Sz(d);
            this.J = e;
            this.j = f
        },
        jH = function(a) {
            return JSON.stringify({
                windowCoords_t: a.l.top,
                windowCoords_r: a.l.right,
                windowCoords_b: a.l.bottom,
                windowCoords_l: a.l.left,
                frameCoords_t: a.m.top,
                frameCoords_r: a.m.right,
                frameCoords_b: a.m.bottom,
                frameCoords_l: a.m.left,
                styleZIndex: a.v,
                allowedExpansion_t: a.g.top,
                allowedExpansion_r: a.g.right,
                allowedExpansion_b: a.g.bottom,
                allowedExpansion_l: a.g.left,
                xInView: a.J,
                yInView: a.j
            })
        },
        kH = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Rz(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = cA(a);
            d = _.Bi(_.fA, a);
            var e = new Tz(c.x, c.y, d.width, d.height);
            c = Uz(e);
            d = String(aA(a, "zIndex"));
            var f = new _.Rz(0, Infinity, Infinity, 0);
            for (var g = tf(a), h = g.g.body, k = g.g.documentElement, l = gz(g.g); a = bA(a);)
                if (!(_.jw && 0 == a.clientWidth || mw && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != aA(a, "overflow")) {
                    var m = cA(a),
                        n = new _.ui(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.g;
            g = _.fz(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new Tz(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? Vz(e, f) : null;
            g = a = 0;
            l && !(new _.Di(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Rz(0, 0, 0, 0);
            if (h = f)(e = Vz(e, f)) ? (k = Uz(f), m = Uz(e), h = m.right != k.left && k.right != m.left, k = m.bottom != k.top && k.bottom != m.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Rz(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new iH(b, c, d, l, a, g)
        };
    var lH = function(a) {
        this.J = a;
        this.v = null;
        this.o = this.status = 0;
        this.m = null;
        this.tb = "sfchannel" + a
    };
    lH.prototype.hg = function() {
        return 2 == this.o
    };
    var mH = function(a) {
        this.g = a
    };
    mH.prototype.getValue = function(a, b) {
        return null == this.g[a] || null == this.g[a][b] ? null : this.g[a][b]
    };
    var nH = function(a, b) {
        this.ye = a;
        this.ze = b;
        this.m = this.g = !1
    };
    var oH = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.m = a;
        this.l = b;
        this.v = c;
        this.permissions = d;
        this.metadata = e;
        this.J = f;
        this.Bd = g;
        this.hostpageLibraryTokens = h;
        this.g = ""
    };
    var pH = function(a, b) {
        this.m = a;
        this.v = b
    };
    pH.prototype.g = function(a) {
        this.v && a && (a.sentinel = this.v);
        return JSON.stringify(a)
    };
    var qH = function(a, b, c) {
        pH.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.T(qH, pH);
    qH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m,
            version: this.version
        })
    };
    var rH = function(a, b, c, d) {
        pH.call(this, a, void 0 === d ? "" : d);
        this.J = b;
        this.l = c
    };
    _.T(rH, pH);
    rH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m,
            initialWidth: this.J,
            initialHeight: this.l
        })
    };
    var sH = function(a, b, c) {
        pH.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.T(sH, pH);
    sH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m,
            description: this.description
        })
    };
    var tH = function(a, b, c, d) {
        pH.call(this, a, void 0 === d ? "" : d);
        this.l = b;
        this.push = c
    };
    _.T(tH, pH);
    tH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m,
            expand_t: this.l.top,
            expand_r: this.l.right,
            expand_b: this.l.bottom,
            expand_l: this.l.left,
            push: this.push
        })
    };
    var uH = function(a, b) {
        pH.call(this, a, void 0 === b ? "" : b)
    };
    _.T(uH, pH);
    uH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m
        })
    };
    var vH = function(a, b, c) {
        pH.call(this, a, void 0 === c ? "" : c);
        this.J = b
    };
    _.T(vH, pH);
    vH.prototype.g = function() {
        var a = {
            uid: this.m,
            newGeometry: jH(this.J)
        };
        return pH.prototype.g.call(this, a)
    };
    var wH = function(a, b, c, d, e, f) {
        vH.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.l = d;
        this.push = e
    };
    _.T(wH, vH);
    wH.prototype.g = function() {
        var a = {
            uid: this.m,
            success: this.success,
            newGeometry: jH(this.J),
            expand_t: this.l.top,
            expand_r: this.l.right,
            expand_b: this.l.bottom,
            expand_l: this.l.left,
            push: this.push
        };
        this.v && (a.sentinel = this.v);
        return JSON.stringify(a)
    };
    var xH = function(a, b, c, d) {
        pH.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.T(xH, pH);
    xH.prototype.g = function() {
        return pH.prototype.g.call(this, {
            uid: this.m,
            width: this.width,
            height: this.height
        })
    };
    var yH = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Rk(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var zH, CH, DH, BH;
    zH = function() {
        this.g = []
    };
    _.AH = function(a) {
        return a + "px"
    };
    CH = function(a, b, c, d, e) {
        a.g.push(new BH(b, c, d, e))
    };
    DH = function(a) {
        for (var b = a.g.length - 1; 0 <= b; b--) {
            var c = a.g[b];
            c.m ? (c.l.style.removeProperty(c.g), c.l.style.setProperty(c.g, String(c.v), c.J)) : c.l.style[c.g] = c.v
        }
        a.g.length = 0
    };
    BH = function(a, b, c, d) {
        this.l = a;
        this.g = (this.m = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
        this.v = this.m ? a.style.getPropertyValue(this.g) : a.style[this.g];
        this.J = this.m ? a.style.getPropertyPriority(this.g) : void 0;
        this.m ? (a.style.removeProperty(this.g), a.style.setProperty(this.g, String(c), d)) : a.style[this.g] = String(c)
    };
    var EH, FH;
    EH = function(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    FH = function() {
        var a = window,
            b = _.Zg(a);
        b && EH({
            label: "2",
            type: 9,
            value: b
        }, a)
    };
    _.GH = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = d || window,
            g = "undefined" !== typeof queueMicrotask;
        return function() {
            e && g && queueMicrotask(function() {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var h = _.Zg(),
                k = 3;
            try {
                var l = b.apply(this, arguments)
            } catch (m) {
                k = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && h && EH(_.A(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (_.Zg() || 0) - h,
                    type: k
                }, e && g && {
                    taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                }), f)
            }
            return l
        }
    };
    var LH = function(a) {
        lH.call(this, a.uniqueId);
        var b = this;
        this.G = a.kg;
        this.L = 1 === a.size;
        this.M = new nH(a.permissions.ye && !this.L, a.permissions.ze && !this.L);
        this.j = a.Bg;
        var c;
        this.la = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.Ha = "file:" == c ? "*" : c + "//" + d;
        this.oa = !!a.Bd;
        this.T = a.Gi ? "//" + a.Gi + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.Ca = a.mb ? "*" : "https:" + this.T;
        this.da = HH(a);
        this.l = new zH;
        IH(this, a.Bg, a.size);
        this.v = this.ca = kH(a.Bg);
        this.F = a.Hl || "1-0-40";
        var e;
        this.wa = null != (e = a.Gj) ? e : "";
        JH(this, a);
        this.B = _.GH(412, function() {
            return KH(b)
        }, a.lb);
        this.sa = -1;
        this.H = 0;
        var f = _.GH(415, function() {
            b.g && (b.g.name = "", a.li && a.li(), _.Ef(b.g, "load", f))
        }, a.lb);
        _.lb(this.g, "load", f);
        this.dg = _.GH(413, this.dg, a.lb);
        this.Eg = _.GH(417, this.Eg, a.lb);
        this.Ig = _.GH(419, this.Ig, a.lb);
        this.Vf = _.GH(411, this.Vf, a.lb);
        this.Df = _.GH(409, this.Df, a.lb);
        this.I = _.GH(410, this.I, a.lb);
        this.wg = _.GH(416, this.wg, a.lb);
        this.m = new rF(this.tb, this.g.contentWindow, this.Ca, !1);
        tF(this.m, "init_done", (0, _.Wu)(this.dg, this));
        tF(this.m, "register_done", (0, _.Wu)(this.Eg, this));
        tF(this.m, "report_error", (0, _.Wu)(this.Ig, this));
        tF(this.m, "expand_request", (0, _.Wu)(this.Vf, this));
        tF(this.m, "collapse_request", (0, _.Wu)(this.Df, this));
        tF(this.m, "creative_geometry_update", (0, _.Wu)(this.I, this));
        this.m.connect((0, _.Wu)(this.wg, this))
    };
    _.T(LH, lH);
    var IH = function(a, b, c) {
            a.L ? (b.style.width = _.eA("100%", !0), b.style.height = _.eA("auto", !0)) : (b.style.width = _.eA(c.width, !0), b.style.height = _.eA(c.height, !0))
        },
        JH = function(a, b) {
            var c = b.mb,
                d = b.content,
                e = b.yd,
                f = b.size,
                g = void 0 === b.zd ? "3rd party ad content" : b.zd,
                h = b.Ae;
            b = b.zf;
            var k = {
                shared: {
                    sf_ver: a.F,
                    ck_on: ME() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.F + ";" + d.length + ";" + d;
            k = new oH(a.J, a.Ha, a.ca, a.M, new mH(k), a.L, a.oa, a.la);
            var l = {};
            l.uid = k.m;
            l.hostPeerName = k.l;
            l.initialGeometry = jH(k.v);
            var m = k.permissions;
            m = JSON.stringify({
                expandByOverlay: m.ye,
                expandByPush: m.ze,
                readCookie: m.g,
                writeCookie: m.m
            });
            l = (l.permissions = m, l.metadata = JSON.stringify(k.metadata.g), l.reportCreativeGeometry = k.J, l.isDifferentSourceWindow = k.Bd, l.goog_safeframe_hlt = pF(k.hostpageLibraryTokens), l);
            k.g && (l.sentinel = k.g);
            k = JSON.stringify(l);
            l = f.width;
            f = f.height;
            a.L && (f = l = 0);
            m = {};
            e = (m.id = e, m.title = g, m.name = d + k, m.scrolling = "no", m.marginWidth = "0", m.marginHeight = "0", m.width = String(l), m.height = String(f), m["data-is-safeframe"] = "true", m);
            void 0 === c && (g = a.wa, f = a.T, (d = g) && (d = "?" + d), f = (void 0 === f ? "//tpc.googlesyndication.com" : f) + ("/safeframe/" + a.F + "/html/container.html" + d), (d = yH(_.hz(_.bz(a.j)))) && (f += (g ? "&" : "?") + "n=" + d), e.src = "https:" + f);
            null !== a.da && (e.sandbox = a.da);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.g = c, dz(a.g, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ea(c, e), h = _.rf("IFRAME"), dz(h, c), a.g = h);
            a.L && (a.g.style.minWidth = "100%");
            a.j.appendChild(a.g)
        };
    _.q = LH.prototype;
    _.q.wg = function() {
        _.lb(window, "resize", this.B);
        _.lb(window, "scroll", this.B)
    };
    _.q.dg = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new qH(b.uid, b.version, b.sentinel);
            if (this.J !== c.m || this.F !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.G) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.q.Eg = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.J !== (new rH(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).m) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.G) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.q.Ig = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new sH(b.uid, b.description, b.sentinel);
            if (this.J !== c.m) throw Error("Wrong source container");
            var d;
            null == (d = this.G) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.G) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.q.Vf = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.o) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new tH(b.uid, new _.Rz(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.J !== c.m) throw Error("Wrong source container");
            if (!(0 <= c.l.top && 0 <= c.l.left && 0 <= c.l.bottom && 0 <= c.l.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.M.ze || !c.push && this.M.ye) {
                var e = c.l,
                    f = c.push,
                    g = this.v = kH(this.g);
                if (e.top <= g.g.top && e.right <= g.g.right && e.bottom <= g.g.bottom && e.left <= g.g.left) {
                    if (!f)
                        for (var h = this.g.parentNode; h && h.style; h = h.parentNode) CH(this.l, h, "overflowX", "visible", "important"), CH(this.l, h, "overflowY", "visible", "important");
                    var k = Uz(new Tz(0, 0, this.v.m.getWidth(), this.v.m.getHeight()));
                    _.ka(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    CH(this.l, this.j, "position", "relative");
                    CH(this.l, this.g, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        CH(this.l, this.j, "width", _.AH(l));
                        var m = k.getHeight();
                        CH(this.l, this.j, "height", _.AH(m))
                    } else CH(this.l, this.g, "zIndex", "10000");
                    var n = k.getWidth();
                    CH(this.l, this.g, "width", _.AH(n));
                    var p = k.getHeight();
                    CH(this.l, this.g, "height", _.AH(p));
                    CH(this.l, this.g, "left", _.AH(k.left));
                    CH(this.l, this.g, "top", _.AH(k.top));
                    this.o = 2;
                    this.v = kH(this.g);
                    d = !0
                } else d = !1
            }
            a = d;
            this.m.send("expand_response", (new wH(this.J, a, this.v, c.l, c.push)).g());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (w) {
            var r;
            null == (r = this.G) || r.error("Invalid EXPAND_REQUEST message. Reason: " + w.message)
        }
    };
    _.q.Df = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (!this.hg()) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid)) throw Error("Cannot parse JSON message");
            if (this.J !== (new uH(b.uid, b.sentinel)).m) throw Error("Wrong source container");
            DH(this.l);
            this.o = 0;
            this.g && (this.v = kH(this.g));
            this.m.send("collapse_response", (new vH(this.J, this.v)).g())
        } catch (d) {
            var c;
            null == (c = this.G) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var KH = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.H) {
            case 0:
                MH(a);
                a.sa = window.setTimeout((0, _.Wu)(a.ba, a), 1E3);
                a.H = 1;
                break;
            case 1:
                a.H = 2;
                break;
            case 2:
                a.H = 2
        }
    };
    LH.prototype.I = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ka(b) || !wj(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new xH(b.uid, b.width, b.height, b.sentinel);
            if (this.J !== c.m) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.L) d !== this.g.height && (this.g.height = d, KH(this));
            else {
                var e;
                null == (e = this.G) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.G) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    LH.prototype.ba = function() {
        if (1 == this.status || 2 == this.status) switch (this.H) {
            case 1:
                this.H = 0;
                break;
            case 2:
                MH(this), this.sa = window.setTimeout((0, _.Wu)(this.ba, this), 1E3), this.H = 1
        }
    };
    var MH = function(a) {
            a.v = kH(a.g);
            a.m.send("geometry_update", (new vH(a.J, a.v)).g())
        },
        HH = function(a) {
            var b = null;
            a.Ii && (b = a.Ii);
            return null == b ? null : b.join(" ")
        },
        NH = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        OH = ["allow-top-navigation"],
        PH = ["allow-same-origin"],
        QH = Bz([].concat(_.oh(NH), _.oh(OH)));
    Bz([].concat(_.oh(NH), _.oh(PH)));
    Bz([].concat(_.oh(NH), _.oh(OH), _.oh(PH)));
    var RH = _.tu(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        SH = {
            Sk: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.mf) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.mf)) throw new RangeError("Invalid subdomain: " + a.mf);
                return df("https://" + a.mf + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            Rn: function(a) {
                return _.ef(RH, a)
            }
        };
    var TH = function() {};
    TH.g = function() {
        throw Error("Must be overridden");
    };
    var Aj = function() {
        this.g = 0
    };
    _.T(Aj, TH);
    Aj.oc = void 0;
    Aj.g = function() {
        return Aj.oc ? Aj.oc : Aj.oc = new Aj
    };
    var UH = function() {
            this.cache = {}
        },
        Jj = function() {
            VH || (VH = new UH);
            return VH
        },
        Kj = function(a) {
            var b = fd(mo(a, 3));
            if (!b) return 3;
            if (void 0 === _.Gj(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    UH.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            zc: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            Cj(6, a, null == (d = g) ? void 0 : d.message);
            return {
                zc: null,
                success: !1
            }
        }
        if (!c) return {
            zc: null,
            success: !0
        };
        try {
            var e = oy(c);
            this.cache[a] = e;
            return {
                zc: e,
                success: !0
            }
        } catch (g) {
            var f;
            Cj(5, a, null == (f = g) ? void 0 : f.message);
            return {
                zc: null,
                success: !1
            }
        }
    };
    UH.prototype.set = function(a, b) {
        var c = _.Gj(a, 1),
            d = "_GESPSK-" + c;
        ny(a);
        try {
            b.setItem(d, Gk(a))
        } catch (f) {
            var e;
            Cj(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var VH = null;
    var WH = function(a, b) {
        iG.call(this, a);
        this.id = a;
        this.B = b
    };
    _.T(WH, iG);
    WH.prototype.H = function(a) {
        this.B(this.id, a)
    };
    var Rj = function(a, b, c, d) {
        WH.call(this, 1041, d);
        this.j = b;
        this.F = W(this, a);
        c && (this.o = Y(this, c))
    };
    _.T(Rj, WH);
    Rj.prototype.g = function() {
        var a = this.F.value,
            b, c, d = null != (c = this.j) ? c : null == (b = this.o) ? void 0 : b.value;
        d && Jj().set(a, d) && null != _.Gj(a, 2) && Cj(27, _.Gj(a, 1))
    };
    var Tj = function(a, b) {
        WH.call(this, 1048, b);
        this.j = V(this);
        this.o = V(this);
        this.F = W(this, a)
    };
    _.T(Tj, WH);
    Tj.prototype.g = function() {
        var a = this.F.value,
            b = function(c) {
                var d = {};
                Cj(c, _.Gj(a, 1), null, (d.tic = String(Math.round((Date.now() - fd(mo(a, 3))) / 6E4)), d))
            };
        switch (Kj(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.o.D(a);
                break;
            case 2:
                b(26);
                this.j.D(a);
                break;
            case 3:
                Cj(9, _.Gj(a, 1));
                this.j.D(a);
                break;
            case 4:
                b(23), this.j.D(a)
        }
    };
    var XH = function(a, b) {
        WH.call(this, 1094, b);
        this.j = lG(this);
        this.o = W(this, a)
    };
    _.T(XH, WH);
    XH.prototype.g = function() {
        var a = this.o.value;
        if (a) {
            if (void 0 !== a)
                for (var b = _.z(_.A(Object, "keys").call(Object, a)), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, _.A(c, "startsWith").call(c, "_GESPSK")) try {
                        a.removeItem(c)
                    } catch (d) {}
            VH = new UH;
            this.j.notify()
        }
    };
    var ik = function(a, b, c) {
        WH.call(this, 1049, c);
        this.j = b;
        nG(this, a)
    };
    _.T(ik, WH);
    ik.prototype.g = function() {
        for (var a = _.z(Ej(this.j)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = Jj().get(b, this.j).zc;
            if (c) {
                var d = Kj(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = Jj();
                    c = _.Gj(c, 1);
                    try {
                        this.j.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        Cj(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    Cj(40, b)
                }
            }
        }
    };
    var Qj = function(a, b, c) {
        WH.call(this, 1027, c);
        this.pe = a;
        this.F = b;
        this.j = V(this);
        this.o = V(this)
    };
    _.T(Qj, WH);
    Qj.prototype.g = function() {
        var a = Jj().get(this.pe, this.F).zc;
        a || (a = ny(my(this.pe)), this.o.D(a.fb(ky(100))));
        this.j.D(a)
    };
    var ak = {};
    var mk = function(a, b) {
        WH.call(this, 1036, b);
        this.j = V(this);
        this.o = W(this, a)
    };
    _.T(mk, WH);
    mk.prototype.g = function() {
        var a = this.o.value;
        0 !== Kj(a) && this.j.D(a)
    };
    var Xj = function(a, b, c) {
        WH.call(this, 1046, c);
        this.output = lG(this);
        this.j = V(this);
        this.o = W(this, b);
        nG(this, a)
    };
    _.T(Xj, WH);
    Xj.prototype.g = function() {
        this.j.D(this.o.value)
    };
    var Uj = function(a, b, c) {
        WH.call(this, 1047, c);
        this.collectorFunction = a;
        this.j = V(this);
        this.o = V(this);
        this.F = V(this);
        this.I = W(this, b)
    };
    _.T(Uj, WH);
    Uj.prototype.g = function() {
        var a = this,
            b = this.I.value,
            c = _.Gj(b, 1);
        Cj(18, c);
        try {
            var d = _.Yg();
            this.collectorFunction().then(function(e) {
                Cj(29, c, null, {
                    delta: String(_.Yg() - d)
                });
                a.j.D(Zn(b, 2, e));
                a.F.Aa(e)
            }).catch(function(e) {
                Cj(28, c, Oj(e));
                a.o.D(b.fb(ky(106)))
            })
        } catch (e) {
            Cj(1, c, Oj(e)), this.o.D(b.fb(ky(107)))
        }
    };
    var Sj = function(a, b) {
        WH.call(this, 1028, b);
        this.j = V(this);
        this.o = W(this, a)
    };
    _.T(Sj, WH);
    Sj.prototype.g = function() {
        var a = this.o.value,
            b = _.Gj(a, 1);
        null != fd(mo(a, 3)) || Cj(35, b);
        this.j.D(a)
    };
    var Vj = function(a, b, c, d, e) {
        WH.call(this, 1050, e);
        this.I = c;
        this.F = d;
        this.j = V(this);
        this.o = W(this, a);
        this.M = Y(this, b)
    };
    _.T(Vj, WH);
    Vj.prototype.g = function() {
        var a = this.o.value,
            b = _.Gj(a, 1),
            c = this.M.value;
        if (null == c) Cj(41, b), a.fb(ky(111)), this.j.D(a);
        else if ("string" !== typeof c) Cj(21, b), this.j.D(a.fb(ky(113)));
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.F : this.I)) {
                var d = {};
                Cj(12, b, null, (d.sl = String(c.length), d));
                b = a.fb(ky(108));
                _.Gi(b, 2)
            } else c.length || Cj(20, b), _.Gi(a, 10);
            this.j.D(a)
        }
    };
    var Wj = function(a) {
        WH.call(this, 1046, a);
        this.output = lG(this)
    };
    _.T(Wj, WH);
    Wj.prototype.g = function() {
        var a = this;
        Dj().then(function() {
            a.output.notify()
        })
    };
    var YH = function(a, b, c, d) {
        WH.call(this, 1059, d);
        this.I = b;
        this.F = c;
        this.j = V(this);
        this.M = W(this, a);
        this.o = Y(this, c)
    };
    _.T(YH, WH);
    YH.prototype.g = function() {
        var a = this.o.value;
        if (a) {
            var b = this.M.value,
                c = b.id,
                d = b.collectorFunction,
                e;
            b = null != (e = b.networkCode) ? e : c;
            c = {};
            Cj(42, b, null, (c.ea = String(Number(this.I)), c));
            this.j.Ka(Zj(b, d, a, this.F, this.B))
        }
    };
    var ZH = function(a, b) {
        WH.call(this, 1057, b);
        this.j = a;
        this.o = V(this);
        this.F = V(this)
    };
    _.T(ZH, WH);
    ZH.prototype.g = function() {
        if (this.j)
            if ("object" !== typeof this.j) Cj(46, "UNKNOWN_COLLECTOR_ID"), $H(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.j.id,
                    b = this.j.networkCode;
                a && b && (delete this.j.id, Cj(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, Cj(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), $H(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.j.collectorFunction ? (Cj(14, a), $H(this, a, 105)) : (_.H = bf(rB), _.A(_.H, "includes")).call(_.H, a) ? (Cj(22, a), $H(this, a, 104)) : this.F.D(this.j)
            }
        else Cj(39, "UNKNOWN_COLLECTOR_ID"), $H(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var $H = function(a, b, c) {
        a.o.D(my(b).fb(ky(c)))
    };
    var gk = function(a, b, c, d, e) {
        var f = document;
        f = void 0 === f ? document : f;
        e = void 0 === e ? ak : e;
        this.g = b;
        this.l = c;
        this.U = f;
        this.H = d;
        this.G = e;
        this.j = [];
        this.J = [];
        this.v = [];
        this.m = 0;
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    gk.prototype.push = function(a) {
        var b = this;
        this.l || this.H();
        var c = function(f, g) {
            return void aI(b, f, g)
        };
        a = new ZH(a, c);
        var d = new Rj(a.o, void 0, this.g, c);
        c = new YH(a.F, this.l, this.g, c, this.G);
        var e = new Pj;
        jk(e, [a, d, c]);
        Yj(e);
        a = c.j.promise;
        this.j.push(a);
        d = _.z(this.J);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    gk.prototype.addOnSignalResolveCallback = function(a) {
        this.J.push(a);
        for (var b = _.z(this.j), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    gk.prototype.addErrorHandler = function(a) {
        this.v.push(a)
    };
    gk.prototype.clearAllCache = function() {
        var a = this,
            b = this.U.currentScript instanceof HTMLScriptElement ? this.U.currentScript.src : "";
        if (1 === this.m) {
            var c = {};
            Cj(49, "", null, (c.url = b, c))
        } else if (c = String(_.hg(null != b ? b : "")), (_.H = bf(qB), _.A(_.H, "includes")).call(_.H, c)) c = {}, Cj(48, "", null, (c.url = b, c));
        else {
            var d = new Pj;
            c = new XH(this.g, function(e, f) {
                return void aI(a, e, f)
            });
            O(d, c);
            Yj(d);
            this.m = 1;
            setTimeout(function() {
                a.m = 0
            }, 1E3 * _.$e(pB));
            d = {};
            Cj(43, "", null, (d.url = b, d));
            return c.j.promise
        }
    };
    var aI = function(a, b, c) {
            a = _.z(a.v);
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, d(b, c)
        },
        hk = function(a) {
            this.push = function(b) {
                a.push(b)
            };
            this.addOnSignalResolveCallback = function(b) {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = function(b) {
                a.addErrorHandler(b)
            };
            this.clearAllCache = function() {
                a.clearAllCache()
            }
        };
    var nk = function(a, b, c) {
        WH.call(this, 1035, c);
        this.o = b;
        this.j = V(this);
        this.F = W(this, a)
    };
    _.T(nk, WH);
    nk.prototype.g = function() {
        var a = this,
            b = this.F.value,
            c = _.Gj(b, 1),
            d = this.o.toString(),
            e = {};
        Cj(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        kb(f, this.o);
        var g = function() {
            var h = {};
            Cj(31, c, null, (h.url = d, h));
            a.j.D(b.fb(ky(109)));
            _.Ef(f, "error", g)
        };
        document.head.appendChild(f);
        _.lb(f, "error", g)
    };
    var lk = new _.v.Set;
    var pk = function(a, b) {
        try {
            tb(Nq(a, b))
        } catch (c) {}
    };
    var bI = function(a) {
        this.C = _.B(a)
    };
    _.T(bI, _.F);
    bI.prototype.g = Se([0, kx, -3, nx]);
    var cI = [.05, .1, .2, .5],
        dI = [0, .5, 1],
        eI = function(a) {
            a = ck(a);
            if (!a) return -1;
            try {
                var b = cF(a.document);
                var c = new _.Di(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.Di(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        fI = function(a, b) {
            return 0 >= a || 0 >= b ? [] : cI.map(function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        hI = function(a) {
            this.J = a.A;
            this.v = a.Ib;
            this.G = a.timer;
            this.l = null;
            this.g = a.lb;
            this.m = gI(this);
            this.j = a.Sl || !1;
            this.Rf = a.Rf || !1
        },
        iI = function() {
            var a;
            return !!window.IntersectionObserver && Dz(null == (a = window.performance) ? void 0 : a.now)
        };
    hI.prototype.getSlotId = function() {
        return this.l
    };
    var kI = function(a, b) {
            if (a.m) {
                if (null != a.l) {
                    try {
                        jI(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.g && a.g(c)
                    }
                    a.m && a.m.unobserve(a.v)
                }
                a.l = b;
                a.m.observe(a.v)
            }
        },
        gI = function(a) {
            if (!_.t.IntersectionObserver) return null;
            var b = a.v.offsetWidth * a.v.offsetHeight,
                c = eI(a.J);
            b = [].concat(_.oh(dI), _.oh(fI(c, b)));
            na(b);
            return new _.t.IntersectionObserver(function(d) {
                try {
                    for (var e = eI(a.J), f = _.z(d), g = f.next(); !g.done; g = f.next()) {
                        var h = g.value,
                            k = h.boundingClientRect.width * h.boundingClientRect.height,
                            l = h.intersectionRect.width * h.intersectionRect.height,
                            m = Math.round(h.time);
                        if (!a.Rf || _.A(Number, "isSafeInteger").call(Number, k) && _.A(Number, "isSafeInteger").call(Number, l) && _.A(Number, "isSafeInteger").call(Number, e) && _.A(Number, "isSafeInteger").call(Number, m)) a.j && jI(a, m, k, l, e, h.isIntersecting);
                        else {
                            var n = d = void 0;
                            null == (n = (d = a).g) || n.call(d, Error("invalid geometry: " + k + " | " + l + " | " + e + " | " + m))
                        }
                    }
                } catch (p) {
                    a.g && a.g(p)
                }
            }, {
                threshold: b
            })
        },
        jI = function(a, b, c, d, e, f) {
            if (null == a.l) throw Error("Not Attached.");
            var g = new bI;
            c = _.Dk(g, 1, c);
            d = _.Dk(c, 2, d);
            e = _.Dk(d, 3, e);
            b = _.Dk(e, 4, b);
            f = Lj(b, 5, f);
            f = Bb(f.g(), 4);
            WG(a.G, "1", 10, f, void 0, a.l)
        };
    var lI = function(a, b) {
            this.g = a;
            this.m = b
        },
        mI = function(a) {
            if (a.g.frames.google_ads_top_frame) return !0;
            var b = Fz(a.g);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.m
                })
            }, !1);
            return !0
        };
    var Ck = function(a) {
        this.C = _.B(a)
    };
    _.T(Ck, _.F);
    var Ik = Te(Ck),
        Fk = [1, 3];
    var Gf = {
        zn: 0,
        vn: 1,
        wn: 9,
        rn: 2,
        sn: 3,
        yn: 5,
        xn: 7,
        un: 10
    };
    var nI = _.tu(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        wk = _.ef(nI);
    var oI = function() {
            this.id = "goog_" + Yy++
        },
        pI = function(a) {
            _.U.call(this);
            this.context = a;
            this.l = new _.v.Map
        };
    _.T(pI, _.U);
    pI.prototype.m = function() {
        _.U.prototype.m.call(this);
        this.l.clear()
    };
    pI.prototype.listen = function(a, b) {
        var c = this;
        if (this.J) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.l.get(d)) ? void 0 : e.add(b)) ? f : new _.v.Set([b]);
        this.l.set(d, g);
        return function() {
            return void qI(c, a, b)
        }
    };
    var rI = function(a) {
            var b = Is;
            var c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.v.Promise(function(d) {
                var e = a.listen(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        qI = function(a, b, c) {
            var d;
            return !(null == (d = a.l.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        },
        Mr = function(a, b, c, d) {
            var e, f, g, h, k, l, m, n;
            _.nb(function(p) {
                e = "string" === typeof b ? b : b.id;
                f = a.l.get(e);
                if (null == (g = f) || !g.size) return p.return();
                h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                    detail: d,
                    bubbles: !0,
                    cancelable: !0
                }) : function() {
                    var r = document.createEvent("CustomEvent");
                    r.initCustomEvent(e, !0, !0, d);
                    return r
                }();
                k = [];
                l = _.z(f);
                m = l.next();
                for (n = {}; !m.done; n = {
                        Ke: n.Ke
                    }, m = l.next()) n.Ke = m.value, k.push(new _.v.Promise(function(r) {
                    return function(w) {
                        return _.nb(function(u) {
                            if (1 == u.g) return u.yield(0, 2);
                            Rh(a.context, c, function() {
                                a.l.has(e) && f.has(r.Ke) && (0, r.Ke)(h)
                            }, !0);
                            w();
                            u.g = 0
                        })
                    }
                }(n)));
                return p.yield(_.v.Promise.all(k), 0)
            })
        },
        sI = new oI,
        tI = new oI,
        Nr = new oI,
        uI = new oI,
        Or = new oI,
        vI = new oI,
        wI = new oI,
        Rp = new oI,
        Is = new oI,
        xI = new oI;
    var yI = function() {
            this.data = void 0;
            this.status = 0;
            this.g = []
        },
        zI = function(a) {
            a.data = void 0;
            a.status = 1
        };
    yI.prototype.oe = function() {
        this.g = []
    };
    var AI, EI, HI, pt, II, DI, CI, BI, op;
    AI = function() {
        this.g = new _.v.Map;
        this.j = 0;
        this.m = new _.v.Map;
        this.te = null;
        this.v = this.l = this.L = this.G = 0;
        this.Be = null;
        this.H = new yI;
        this.J = new yI
    };
    EI = function(a, b) {
        a.g.get(b) || (a.g.set(b, {
            wc: !0,
            zg: "",
            fd: "",
            Di: 0,
            xg: [],
            yg: [],
            mc: !1
        }), _.yn(b, function() {
            a.g.delete(b);
            BI(a, b)
        }), b.listen(tI, function(c) {
            c = c.detail;
            var d = a.g.get(b);
            d.zg = _.Gj(c, 33) || "";
            d.mc = !0;
            CI(a, b, function() {
                return void(d.zg = "")
            });
            DI(a, b, function() {
                return void(d.mc = !1)
            })
        }))
    };
    _.np = function(a, b) {
        var c;
        return null == (c = a.g.get(b)) ? void 0 : c.wc
    };
    _.FI = function(a, b) {
        if (a = a.g.get(b)) a.wc = !1
    };
    _.GI = function(a, b) {
        if (a = a.g.get(b)) a.wc = !0
    };
    HI = function(a, b) {
        if (!b.length) return [];
        var c = qh(b[0].getAdUnitPath());
        b.every(function(g) {
            return qh(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.z(a.g);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            (f = f.next().value.zg) && qh(e.getAdUnitPath()) === c && !_.A(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    pt = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.g.get(b)) ? void 0 : c.fd) ? d : ""
    };
    II = function(a, b) {
        return (a = a.g.get(b)) ? a.Di - 1 : 0
    };
    DI = function(a, b, c) {
        (a = a.g.get(b)) && a.xg.push(c)
    };
    CI = function(a, b, c) {
        (a = a.g.get(b)) && a.yg.push(c)
    };
    BI = function(a, b) {
        if (a = a.g.get(b))
            for (b = a.yg.slice(), a.yg.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    op = function(a, b) {
        if (a = a.g.get(b))
            for (b = a.xg.slice(), a.xg.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    AI.prototype.mc = function(a) {
        var b, c;
        return null != (c = null == (b = this.g.get(a)) ? void 0 : b.mc) ? c : !1
    };
    var JI = function(a, b, c) {
            if (a = a.g.get(b)) a.Ci = c
        },
        KI = function(a, b) {
            if (a = a.g.get(b)) {
                var c;
                null == (c = a.Ci) || c.ua();
                delete a.Ci
            }
        };
    var Wk = new _.v.Map,
        Vk = new _.v.Map;
    var Yk = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Yk.prototype.getMessageId = function() {
        return this.messageId
    };
    Yk.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var LI = P(2),
        MI = P(3),
        NI = P(4),
        OI = P(5),
        PI = P(6),
        QI = P(12),
        RI = P(14),
        SI = P(16),
        sl = P(19),
        TI = P(20),
        UI = P(23),
        VI = P(26),
        WI = P(28),
        XI = P(149),
        YI = P(30),
        ZI = P(31),
        $I = P(34),
        aJ = P(35),
        Gl = P(36),
        qs = P(38),
        bJ = P(40),
        cJ = P(48),
        dJ = P(50),
        eJ = P(60),
        fJ = P(63),
        gJ = P(64),
        hJ = P(66),
        iJ = P(68),
        jJ = P(69),
        kJ = P(70),
        lJ = P(71),
        mJ = P(78),
        nJ = P(80),
        lm = P(82),
        tl = P(84),
        oJ = P(85),
        pJ = P(87),
        ml = P(88),
        qJ = P(92),
        rJ = P(93),
        sJ = P(99),
        vl = P(103),
        jm = P(104),
        tJ = P(105),
        dm = P(106),
        em = P(107),
        km = P(108),
        uJ = P(113),
        vJ = P(114),
        wJ = P(115),
        xJ = P(117),
        yJ = P(118),
        zJ = P(120),
        AJ = P(119),
        Sl = P(121),
        BJ = P(122),
        CJ = P(123),
        Aq = P(125),
        DJ = P(126),
        EJ = P(127),
        FJ = P(144),
        nq = P(129),
        pq = P(132),
        GJ = P(134),
        HJ = P(135),
        IJ = P(136),
        JJ = P(137),
        KJ = P(138),
        LJ = P(139),
        MJ = P(140),
        Pq = P(142),
        NJ = P(143),
        OJ = P(145),
        PJ = P(147),
        ws = P(148),
        QJ = P(150),
        RJ = P(152),
        SJ = P(153),
        TJ = P(154),
        Tq = P(155),
        UJ = P(156),
        VJ = P(157),
        WJ = P(158),
        XJ = P(159),
        YJ = P(160);
    var ZJ = function(a, b, c) {
        var d = this;
        this.addEventListener = L(a, 86, function(e, f) {
            if ("function" !== typeof f) return Q(b, $k("Service.addEventListener", [e, f])), d;
            var g = al(e);
            if (!g) return Q(b, rJ(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = L(a, 904, function(e, f) {
            var g = al(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : Q(b, $k("Service.removeEventListener", [e, f]))
        });
        this.getSlots = L(a, 573, function() {
            return c.g.map(function(e) {
                return e.g
            })
        });
        this.getSlotIdMap = L(a, 574, function() {
            for (var e = {}, f = _.z(c.g), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.g;
            return e
        });
        this.getName = L(a, 575, function() {
            return c.getName()
        })
    };
    var bl = function(a, b, c) {
        ZJ.call(this, a, b, c);
        this.setRefreshUnfilledSlots = L(a, 59, function(d) {
            c.setRefreshUnfilledSlots(d)
        });
        this.notifyUnfilledSlots = L(a, 69, function(d) {
            c.wc && $J(c, aK(c, d))
        });
        this.refreshAllSlots = L(a, 60, function() {
            c.wc && $J(c)
        });
        this.setVideoSession = L(a, 61, function(d, e, f) {
            c.G = e;
            c.o = f;
            "number" === typeof d && (e = Vi().g, _.Gi(e, 29, null == d ? d : hd(d)))
        });
        this.getDisplayAdsCorrelator = L(a, 62, function() {
            return String(Yw(Vi().g, 26))
        });
        this.getVideoStreamCorrelator = L(a, 63, function() {
            var d = Vi().g;
            d = ir(d, 29);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = L(a, 64, function(d) {
            var e = _.A(c.g, "find").call(c.g, function(f) {
                return f.g === d
            });
            return !!e && bK(c, e)
        });
        this.onImplementationLoaded = L(a, 65, function() {
            c.P.info(cJ("GPT CompanionAds"))
        });
        this.slotRenderEnded = L(a, 67, function(d, e, f) {
            var g = _.A(c.g, "find").call(c.g, function(h) {
                return h.g === d
            });
            return g && cK(c, g, e, f)
        })
    };
    _.T(bl, ZJ);
    var dl = function(a, b, c) {
        ZJ.call(this, a, b, c);
        this.setContent = L(a, 72, function(d) {
            var e = _.A(c.g, "find").call(c.g, function(f) {
                return f.g === d
            });
            b.error(FJ(), e)
        })
    };
    _.T(dl, ZJ);
    var xl = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = Vi().g,
            h = eH(Vi(), f.getDomId());
        this.set = L(a, 83, function(k, l) {
            "page_url" === k && l && (k = [il(jl(new ll, k), [String(l)])], _.ul(h, 3, k));
            return e
        });
        this.get = L(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, m;
            return null != (m = null == (l = (_.H = h.Ma(), _.A(_.H, "find")).call(_.H, function(n) {
                return _.Gj(n, 1) === k
            })) ? void 0 : pl(l)[0]) ? m : null
        });
        this.setClickUrl = L(a, 79, function(k) {
            fl(k, h, f, b);
            return e
        });
        this.setTargeting = L(a, 81, function(k, l) {
            nl(k, l, f, h, b);
            return e
        });
        this.updateTargetingFromMap = L(a, 85, function(k) {
            ol(k, f, h, b);
            return e
        });
        this.display = L(a, 78, function() {
            var k = Hi(g, Vi().m);
            var l = void 0 === l ? document : l;
            var m;
            null != (m = k.R[f.getDomId()]) && Lj(m, 19, !0);
            m = f.getDomId();
            m = Av(m);
            var n = {
                id: m
            };
            var p = void 0 === p ? Zv : p;
            var r = _.A(Object, "assign").call(Object, {}, n);
            m = n.id;
            var w = n.style;
            n = n.data;
            r = (delete r.id, delete r.style, delete r.data, r);
            if (_.A(Object, "keys").call(Object, r).length) throw Error("Invalid attribute(s): " + _.A(Object, "keys").call(Object, r));
            m = {
                id: m,
                style: w ? w : void 0
            };
            if (n)
                for (w = _.z(_.A(n, "entries").call(n)), n = w.next(); !n.done; n = w.next()) r = _.z(n.value), n = r.next().value, r = r.next().value, Qe(hH.test(n)), m[n] = r;
            _.Yv("div");
            p = _.cw("div", m, p);
            l.write(_.Uv(p));
            Li(f, l) && (rs(d), EI(d.K, f), dK(d, k, f))
        });
        this.setTagForChildDirectedTreatment = L(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = Gt(g) || new $G;
                l.setTagForChildDirectedTreatment(k);
                _.wh(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = L(a, 567, function(k) {
            "boolean" === typeof k ? Lj(h, 12, k) : Q(b, $k("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = L(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = Gt(g) || new $G;
                l.setTagForUnderAgeOfConsent(k);
                _.wh(g, 25, l)
            }
            return e
        })
    };
    var dq = {
        qn: 0,
        nn: 1,
        on: 2,
        pn: 3
    };
    var Al = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5,
            GAME_MANUAL_INTERSTITIAL: 7,
            LEFT_SIDE_RAIL: 8,
            RIGHT_SIDE_RAIL: 9
        },
        Cl = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        Bl = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var El = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var eK = "",
        Ml = null;
    var um = function(a, b, c) {
        pI.call(this, a);
        this.slotId = b;
        this.g = c
    };
    _.T(um, pI);
    um.prototype.getSlotId = function() {
        return this.slotId
    };
    var If = function(a, b, c, d) {
        pI.call(this, a);
        this.adUnitPath = b;
        this.Ib = d;
        this.g = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.T(If, pI);
    _.q = If.prototype;
    _.q.getId = function() {
        return this.id
    };
    _.q.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.q.getName = function() {
        return this.adUnitPath
    };
    _.q.toString = function() {
        return this.getId()
    };
    _.q.getDomId = function() {
        return this.Ib
    };
    var fK = function(a, b) {
        a.g = b
    };
    var nm = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var rm = _.ev(function() {
            return void Iz("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        gK = _.ev(function() {
            return void Iz("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        hK = _.ev(function() {
            return void Iz("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        wm = function(a, b, c, d, e) {
            ZJ.call(this, a, b, c);
            var f = this,
                g = Vi().g,
                h = Vi().m,
                k = !1;
            this.setTargeting = L(a, 1, function(l, m) {
                gm({
                    key: l,
                    value: m,
                    Ba: g,
                    serviceName: c.getName(),
                    Ql: c.enabled,
                    Ya: e,
                    P: b,
                    context: a
                });
                return f
            });
            this.clearTargeting = L(a, 2, function(l) {
                mm(l, g, c.getName(), b);
                return f
            });
            this.getTargeting = L(a, 38, function(l) {
                return hm(l, g, b)
            });
            this.getTargetingKeys = L(a, 39, function() {
                return im(g)
            });
            this.setCategoryExclusion = L(a, 3, function(l) {
                "string" !== typeof l || gl(l) ? Q(b, $k("PubAdsService.setCategoryExclusion", [l])) : ((_.H = _.xo(g, 3, 2), _.A(_.H, "includes")).call(_.H, l) || hx(g, 3, l), b.info(oJ(l)));
                return f
            });
            this.clearCategoryExclusions = L(a, 4, function() {
                _.Gi(g, 3);
                b.info(pJ());
                return f
            });
            this.disableInitialLoad = L(a, 5, function() {
                Lj(g, 4, !0);
                k || (k = !0, sm())
            });
            this.enableSingleRequest = L(a, 6, function() {
                if (c.enabled && !_.N(g, 6)) return Q(b, eJ("PubAdsService.enableSingleRequest")), !1;
                b.info(fJ("single request"));
                Lj(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = L(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = L(a, 8, function() {
                Iz("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = L(a, 485, function(l) {
                var m = new Vs;
                m = _.Wo(m, 1, 800);
                m = _.Wo(m, 2, 400);
                m = _.Gi(m, 3, _.Fc(3));
                if (_.ka(l)) {
                    var n = l.fetchMarginPercent;
                    "number" === typeof n && (0 <= n ? _.Wo(m, 1, n) : -1 === n && _.Gi(m, 1));
                    n = l.renderMarginPercent;
                    "number" === typeof n && (0 <= n ? _.Wo(m, 2, n) : -1 === n && _.Gi(m, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.Gi(m, 3, _.Fc(l)) : -1 === l && _.Gi(m, 3, _.Fc(1)))
                }
                window.IntersectionObserver || !Mp(m, 1) && !Mp(m, 2) ? _.wh(g, 5, m) : Q(b, QJ())
            });
            this.setCentering = L(a, 9, function(l) {
                l = !!l;
                b.info(gJ("centering", String(l)));
                Lj(g, 15, l)
            });
            this.definePassback = L(a, 10, function(l, m) {
                return (l = vm(a, b, c, l, m, d)) && l.ri
            });
            this.refresh = L(a, 11, function() {
                var l = _.Wa.apply(0, arguments),
                    m = _.z(l),
                    n = m.next().value;
                m = m.next().value;
                m = void 0 === m ? {} : m;
                n && !Array.isArray(n) || !_.ka(m) || m.changeCorrelator && "boolean" !== typeof m.changeCorrelator ? Q(b, $k("PubAdsService.refresh", l)) : (m && !1 === m.changeCorrelator || g.setCorrelator(Mz()), n = n ? qm(n, c) : c.g, c.refresh(Hi(g, h), n) || Q(b, $k("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = L(a, 12, function() {
                Lj(g, 21, !0);
                iK(c, g)
            });
            this.setVideoContent = L(a, 13, function(l, m) {
                jK(c, l, m, g)
            });
            this.collapseEmptyDivs = L(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                l = void 0 === l ? !1 : l;
                Lj(g, 11, !0);
                l = !!l;
                Lj(g, 10, l);
                b.info(mJ(String(l)));
                return !!_.N(g, 11)
            });
            this.clear = L(a, 15, function(l) {
                if (Array.isArray(l)) return kK(c, g, h, qm(l, c));
                if (void 0 === l) return kK(c, g, h, c.g);
                Q(b, $k("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = L(a, 16, function(l) {
                "string" !== typeof l ? Q(b, $k("PubAdsService.setLocation", [l])) : Zn(g, 8, l);
                return f
            });
            this.setCookieOptions = L(a, 17, function() {
                gK();
                return f
            });
            this.setTagForChildDirectedTreatment = L(a, 18, function(l) {
                hK();
                if (1 !== l && 0 !== l) return Q(b, BJ("PubadsService.setTagForChildDirectedTreatment", Tl(l), "0,1")), f;
                var m = Gt(g) || new $G;
                m.setTagForChildDirectedTreatment(l);
                _.wh(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = L(a, 19, function() {
                hK();
                var l = Gt(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.wh(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = L(a, 20, function(l) {
                l = String(l);
                b.info(gJ("PPID", l));
                Zn(g, 16, l);
                return f
            });
            this.set = L(a, 21, function(l, m) {
                Hl(l, m, g, c.getName(), b);
                return f
            });
            this.get = L(a, 22, function(l) {
                return Il(l, g, b)
            });
            this.getAttributeKeys = L(a, 23, function() {
                return Jl(g)
            });
            this.display = L(a, 24, function(l, m, n, p) {
                return void c.display(l, m, d, n, p)
            });
            this.updateCorrelator = L(a, 25, function() {
                Iz(pm("update"));
                Q(b, wJ());
                g.setCorrelator(Mz());
                return f
            });
            this.defineOutOfPagePassback = L(a, 35, function(l) {
                l = vm(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.no(l.Ba, 15, 1);
                return l.ri
            });
            this.setForceSafeFrame = L(a, 36, function(l) {
                "boolean" !== typeof l ? Q(b, $k("PubAdsService.setForceSafeFrame", [Tl(l)])) : Lj(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = L(a, 37, function(l) {
                var m = Ul(b, l);
                m ? _.wh(g, 18, m) : Q(b, $k("PubAdsService.setSafeFrameConfig", [l]));
                return f
            });
            this.setRequestNonPersonalizedAds = L(a, 445, function(l) {
                hK();
                if (0 !== l && 1 !== l) return Q(b, BJ("PubAdsService.setRequestNonPersonalizedAds", Tl(l), "0,1")), f;
                var m = Gt(g) || new $G;
                Lj(m, 8, !!l);
                _.wh(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = L(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                hK();
                if (2 !== l && 0 !== l && 1 !== l) return Q(b, BJ("PubadsService.setTagForUnderAgeOfConsent", Tl(l), "2,0,1")), f;
                var m = Gt(g) || new $G;
                m.setTagForUnderAgeOfConsent(l);
                _.wh(g, 25, m);
                return f
            });
            this.getCorrelator = L(a, 27, function() {
                return String(Yw(g, 26))
            });
            this.getTagSessionCorrelator = L(a, 631, function() {
                return _.Wh(_.t)
            });
            this.getVideoContent = L(a, 30, function() {
                return lK(c, g)
            });
            this.getVersion = L(a, 568, function() {
                return a.tc ? String(a.tc) : a.ab
            });
            this.forceExperiment = L(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = L(a, 28, function(l) {
                Iz(pm("set"));
                Q(b, vJ());
                if (ri(window)) return f;
                if (!Km(l)) return Q(b, $k("PubadsService.setCorrelator", [Tl(l)])), f;
                l = g.setCorrelator(l);
                Lj(l, 27, !0);
                return f
            });
            this.markAsAmp = L(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = L(a, 571, function() {
                return !!_.N(g, 6)
            });
            this.setImaContent = L(a, 328, function(l, m) {
                null != _.Gj(g, 22) ? jK(c, l, m, g) : (Lj(g, 21, !0), iK(c, g), "string" === typeof l && Zn(g, 19, l), "string" === typeof m && Zn(g, 20, m))
            });
            this.getImaContent = L(a, 329, function() {
                return null != _.Gj(g, 22) ? lK(c, g) : c.enabled ? {
                    vid: _.R(g, 19) || "",
                    cmsid: _.R(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = L(a, 572, function() {
                return !!_.N(g, 4)
            });
            this.setPrivacySettings = L(a, 648, function(l) {
                if (!_.ka(l)) return Q(b, $k("PubAdsService.setPrivacySettings", [l])), f;
                var m = l.restrictDataProcessing,
                    n = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    w = l.nonPersonalizedAds,
                    u = l.userOptedOutOfPersonalization,
                    x = l.trafficSource,
                    y, C = null != (y = Gt(g)) ? y : new $G;
                "boolean" === typeof w ? Lj(C, 8, w) : void 0 !== w && Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "nonPersonalizedAds", Tl(w)));
                "boolean" === typeof u ? Lj(C, 13, u) : void 0 !== u && Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "userOptedOutOfPersonalization", Tl(u)));
                "boolean" === typeof m ? Lj(C, 1, m) : void 0 !== m && Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "restrictDataProcessing", Tl(m)));
                if ("boolean" === typeof r) {
                    m = om();
                    if (r && !_.N(C, 9) && a.yc) {
                        w = a.Ga;
                        u = w.xc;
                        y = xh(a);
                        var D = new WA;
                        D = _.Ah(D, 1, !0);
                        D = _.Ah(D, 2, m);
                        y = _.Ch(y, 11, Dh, D);
                        u.call(w, y)
                    }
                    m ? Lj(C, 9, r) : r && Q(b, PJ())
                } else void 0 !== r && Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "limitedAds", Tl(r)));
                void 0 !== p && (null === p ? C.setTagForUnderAgeOfConsent(2) : !1 === p ? C.setTagForUnderAgeOfConsent(0) : !0 === p ? C.setTagForUnderAgeOfConsent(1) : Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "underAgeOfConsent", Tl(p))));
                void 0 !== n && (null === n ? C.clearTagForChildDirectedTreatment() : !1 === n ? C.setTagForChildDirectedTreatment(0) : !0 === n ? C.setTagForChildDirectedTreatment(1) : Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "childDirectedTreatment", Tl(n))));
                void 0 !== x && (null === x ? _.Gi(C, 10) : (_.H = _.A(Object, "values").call(Object, Bl), _.A(_.H, "includes")).call(_.H, x) ? _.no(C, 10, x) : Q(b, Sl("PubAdsService.setPrivacySettings", Tl(l), "trafficSource", Tl(x))));
                _.wh(g, 25, C);
                return f
            })
        };
    _.T(wm, ZJ);
    var mK = function(a, b) {
        this.getId = L(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = L(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = L(a, 595, function() {
            return b.getName()
        });
        this.toString = L(a, 596, function() {
            return b.toString()
        });
        this.getDomId = L(a, 597, function() {
            return b.getDomId()
        })
    };
    var nK = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        oK = function(a, b) {
            a.advertiserId = b
        },
        pK = function(a, b) {
            a.campaignId = b
        },
        qK = function(a, b) {
            a.yieldGroupIds = b
        },
        rK = function(a, b) {
            a.companyIds = b
        };
    var ei = function(a) {
        this.C = _.B(a)
    };
    _.T(ei, _.F);
    ei.prototype.getWidth = function() {
        return Lr(this, 1)
    };
    ei.prototype.getHeight = function() {
        return Lr(this, 2)
    };
    var Em = function() {
        var a = new ei;
        return Lj(a, 3, !0)
    };
    var ii = function(a) {
        this.C = _.B(a)
    };
    _.T(ii, _.F);
    ii.aa = [2];
    var sK = function(a) {
        this.C = _.B(a)
    };
    _.T(sK, _.F);
    var tK = function(a) {
        this.C = _.B(a)
    };
    _.T(tK, _.F);
    tK.aa = [1];
    var uK = function(a) {
        this.C = _.B(a)
    };
    _.T(uK, _.F);
    uK.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    uK.prototype.getDomId = function() {
        return _.R(this, 2)
    };
    var vK = function(a, b) {
        Zn(a, 2, b)
    };
    uK.prototype.Ma = function() {
        return _.gi(this, ll, 3)
    };
    uK.prototype.getServices = function(a) {
        return ax(this, 4, a)
    };
    var wK = function(a, b) {
        _.ul(a, 5, b)
    };
    uK.prototype.getClickUrl = function() {
        return _.R(this, 7)
    };
    uK.prototype.setClickUrl = function(a) {
        return Zn(this, 7, a)
    };
    uK.prototype.getCategoryExclusions = function(a) {
        return ax(this, 8, a)
    };
    var hl = function(a) {
        return _.gi(a, ll, 9)
    };
    uK.prototype.kc = function() {
        return _.di(this, Ql, 13)
    };
    var Qs = function(a) {
        return _.Nk(a, 15, 0)
    };
    uK.aa = [3, 4, 5, 6, 8, 9, 27];
    var xK = function(a, b) {
        this.width = a;
        this.height = b
    };
    xK.prototype.getWidth = function() {
        return this.width
    };
    xK.prototype.getHeight = function() {
        return this.height
    };
    var yK = new _.v.Set(["unhideWindow"]);
    var Tm = function(a, b, c) {
        var d = this,
            e = eH(Vi(), c.getDomId()),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.yn(c, function() {
            e = new uK;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.listen(Nr, function(n) {
            var p = n.detail;
            n = p.oh;
            p = p.isBackfill;
            n && (f = n, l = p)
        });
        this.set = L(a, 40, function(n, p) {
            ym(n, p, c, e, b);
            return d
        });
        this.get = L(a, 41, function(n) {
            return zm(n, c, e, b)
        });
        this.getAttributeKeys = L(a, 42, function() {
            return Am(e)
        });
        this.addService = L(a, 43, function(n) {
            n = Wk.get(n);
            if (!n) return Q(b, $k("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.H = _.xo(e, 4, 2), _.A(_.H, "includes")).call(_.H, p)) return b.info(QI(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = L(a, 44, function(n) {
            try {
                var p = e;
                if (!Array.isArray(n)) throw new Lm("Size mapping must be an array");
                var r = n.map(Mm);
                _.ul(p, 6, r)
            } catch (w) {
                n = w, Ph(a, 44, n), Iz("Incorrect usage of googletag.Slot defineSizeMapping: " + n.message)
            }
            return d
        });
        this.setClickUrl = L(a, 45, function(n) {
            fl(n, e, c, b);
            return d
        });
        this.setCategoryExclusion = L(a, 46, function(n) {
            var p = e;
            "string" !== typeof n || gl(n) ? Q(b, $k("Slot.setCategoryExclusion", [n]), c) : ((_.H = _.xo(p, 8, 2), _.A(_.H, "includes")).call(_.H, n) || hx(p, 8, n), b.info(RI(n), c));
            return d
        });
        this.clearCategoryExclusions = L(a, 47, function() {
            _.Gi(e, 8);
            b.info(SI(), c);
            return d
        });
        this.getCategoryExclusions = L(a, 48, function() {
            return _.xo(e, 8, 2).slice()
        });
        this.setTargeting = L(a, 49, function(n, p) {
            nl(n, p, c, e, b);
            return d
        });
        this.updateTargetingFromMap = L(a, 649, function(n) {
            ol(n, c, e, b);
            return d
        });
        this.clearTargeting = L(a, 50, function(n) {
            wl(n, c, e, b);
            return d
        });
        this.getTargeting = L(a, 51, function(n) {
            return ql(n, c, e, b)
        });
        this.getTargetingKeys = L(a, 52, function() {
            return rl(e)
        });
        this.setCollapseEmptyDiv = L(a, 53, function(n, p) {
            var r = e;
            p = void 0 === p ? !1 : p;
            p = void 0 === p ? !1 : p;
            "boolean" !== typeof n || "boolean" !== typeof p ? Q(b, $k("Slot.setCollapseEmptyDiv", [n, p]), c) : (r = Lj(r, 10, n), Lj(r, 11, n && p), p && !n && Q(b, TI(c.toString()), c));
            return d
        });
        this.getAdUnitPath = L(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = L(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = L(a, 55, function(n) {
            var p = e;
            "boolean" !== typeof n ? Q(b, $k("Slot.setForceSafeFrame", [String(n)]), c) : Lj(p, 12, n);
            return d
        });
        this.setSafeFrameConfig = L(a, 56, function(n) {
            var p = e,
                r = Ul(b, n);
            r ? _.wh(p, 13, r) : b.error($k("Slot.setSafeFrameConfig", [n]), c);
            return d
        });
        c.listen(tI, function(n) {
            n = n.detail;
            if (Yl(n, 8)) g = null;
            else {
                g = new nK;
                var p = !!Yl(n, 9);
                g.isBackfill = p;
                var r = Zw(n, 15),
                    w = Zw(n, 16);
                r.length && w.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = w[0], p || (g.creativeId = r[0], g.lineItemId = w[0], (p = Zw(n, 22)) && p.length && (g.creativeTemplateId = p[0])));
                Zw(n, 17).length && oK(g, Zw(n, 17)[0]);
                Zw(n, 18).length && pK(g, Zw(n, 18)[0]);
                Zw(n, 19).length && qK(g, Zw(n, 19));
                Zw(n, 20).length && rK(g, Zw(n, 20));
                n = be(n, 45, Pd(n.C) & 34 ? de : ee, 2).map(function(u) {
                    return Fd(u)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = L(a, 355, function() {
            return g
        });
        this.getName = L(a, 170, function() {
            b.error(NJ());
            return c.getAdUnitPath()
        });
        var m = new mK(a, c);
        this.getSlotId = L(a, 579, function() {
            return m
        });
        this.getServices = L(a, 580, function() {
            return _.xo(e, 4, 2).map(function(n) {
                var p = ZG[n];
                if (p) {
                    var r, w, u;
                    n = null != (u = null == (w = (r = Nm())[p]) ? void 0 : w.call(r)) ? u : null
                } else n = null;
                return n
            })
        });
        this.getSizes = L(a, 581, function(n, p) {
            var r, w;
            return null != (w = null == (r = ji(e, n, p)) ? void 0 : r.map(function(u) {
                return _.N(u, 3) ? "fluid" : new xK(u.getWidth(), u.getHeight())
            })) ? w : null
        });
        this.getClickUrl = L(a, 582, function() {
            var n;
            return null != (n = e.getClickUrl()) ? n : ""
        });
        this.getTargetingMap = L(a, 583, function() {
            for (var n = {}, p = _.z(hl(e)), r = p.next(); !r.done; r = p.next()) r = r.value, _.R(r, 1) && (n[_.Gj(r, 1)] = pl(r));
            return n
        });
        this.getOutOfPage = L(a, 584, function(n) {
            return "number" === typeof n ? Qs(e) === n : 0 !== Qs(e)
        });
        this.getCollapseEmptyDiv = L(a, 585, function() {
            return null != Yl(e, 10) ? _.N(e, 10) : null
        });
        this.getDivStartsCollapsed = L(a, 586, function() {
            return null != Yl(e, 11) ? _.N(e, 11) : null
        });
        c.listen(uI, function(n) {
            h = n.detail.Rj
        });
        this.getContentUrl = L(a, 587, function() {
            return h()
        });
        this.getFirstLook = L(a, 588, function() {
            Iz("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.listen(tI, function(n) {
            var p;
            k = null != (p = n.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = L(a, 591, function() {
            return k
        });
        this.getHtml = L(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = L(a, 1022, function(n) {
            var p = e;
            if (Kf(n)) {
                var r = n.componentAuction,
                    w = n.adExpansion;
                if (null != r) {
                    var u = {
                        componentAuction: r
                    };
                    if (_.ka(u)) {
                        if (r = je(p, 26, qd), void 0 !== u.componentAuction) {
                            u = _.z(u.componentAuction);
                            for (var x = u.next(); !x.done; x = u.next()) {
                                var y = x.value;
                                x = y.configKey;
                                y = y.auctionConfig;
                                "string" !== typeof x || gl(x) || (null === y ? r.delete(x) : y && r.set(x, JSON.stringify(y)))
                            }
                        }
                    } else Q(b, $k("googletag.Slot.setConfig", [u]))
                }
                if (_.A(Object, "hasOwn").call(Object, n, "interstitial"))
                    if (5 !== Qs(p)) Q(b, YJ("interstitial"), c);
                    else {
                        u = n.interstitial;
                        b.info(UJ("interstitial", Tl(u)), c);
                        if (Kf(u))
                            for (r = {}, u = _.z(_.A(Object, "entries").call(Object, u)), x = u.next(); !x.done; x = u.next()) switch (y = _.z(x.value), x = y.next().value, y = y.next().value, x) {
                                case "triggers":
                                    r.triggers = y;
                                    break;
                                default:
                                    Q(b, WJ("interstitial", x), c)
                            } else Q(b, XJ("googletag.slot.setConfig", "interstitial", Tl(u)), c), r = null;
                        x = r;
                        r = new tK;
                        u = {};
                        if (x && x.triggers)
                            if (x = x.triggers, Kf(x))
                                for (u.triggers = {}, x = _.z(_.A(Object, "entries").call(Object, x)), y = x.next(); !y.done; y = x.next()) {
                                    var C = _.z(y.value);
                                    y = C.next().value;
                                    C = C.next().value;
                                    var D = y;
                                    y = C;
                                    if (yK.has(D))
                                        if (Pm(y)) switch (D) {
                                            case "unhideWindow":
                                                C = new sK, C = _.no(C, 1, 2), C = Lj(C, 2, y), Mj(r, 1, sK, C), u.triggers.Un = y
                                        } else Q(b, XJ("interstitial.triggers", D, Tl(y)), c);
                                        else Q(b, WJ("interstitial.triggers", D), c)
                                } else Q(b, XJ("interstitial", "triggers", Tl(x)), c);
                        b.info(VJ("interstitial", Tl(u)), c);
                        _.wh(p, 29, r)
                    }
                _.G(Om) ? _.A(Object, "hasOwn").call(Object, n, "adExpansion") && Rm(p, w) : Rm(p, w)
            } else Q(b, $k("googletag.slot.setConfig", [n]), c)
        })
    };
    var Z = function(a, b, c) {
        iG.call(this, b, c);
        this.context = a
    };
    _.T(Z, iG);
    Z.prototype.H = function(a) {
        Ph(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var an = function(a, b, c, d, e) {
        Z.call(this, a, 959);
        this.hb = b;
        this.output = V(this);
        this.j = W(this, b);
        nG(this, c);
        nG(this, d);
        e && nG(this, e)
    };
    _.T(an, Z);
    an.prototype.g = function() {
        this.output.D(this.j.value)
    };
    var $m = function(a, b, c, d, e, f) {
        Z.call(this, a, 1172);
        this.P = b;
        this.K = c;
        this.A = d;
        this.j = lG(this);
        nG(this, e);
        this.o = W(this, f)
    };
    _.T($m, Z);
    $m.prototype.g = function() {
        var a = this,
            b = new UE(this.A);
        _.S(this, b);
        if (SC(b.caller)) {
            var c = this.K.J,
                d = c.status,
                e = function(f) {
                    if (f.internalErrorState) hF(a.o.value, f.gppString);
                    else if (Tf(f.applicableSections)) fF(gF(a.o.value, f.applicableSections.filter(function(k) {
                        return _.A(Number, "isInteger").call(Number, k)
                    })), !1);
                    else {
                        var g = hF(gF(a.o.value, f.applicableSections.filter(function(k) {
                            return _.A(Number, "isInteger").call(Number, k)
                        })), f.gppString);
                        try {
                            var h = YE(f.gppString)
                        } catch (k) {
                            Ph(a.context, 1182, k), h = !1
                        }
                        fF(g, h)
                    }
                    a.j.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.g.push(e);
                    break;
                case 0:
                    zI(c);
                    c.g.push(e);
                    this.P.info(zJ());
                    b.addEventListener(Lh(this.context, 1173, function(f) {
                        if ("ready" === f.pingData.signalStatus || Tf(f.pingData.applicableSections)) c.data = f.pingData, c.status = 2, c.g.forEach(function(g) {
                            g(f.pingData)
                        }), c.oe()
                    }));
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.j.notify()
    };
    var Ym = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.P = b;
        this.K = c;
        this.A = d;
        this.o = e;
        this.j = lG(this);
        nG(this, f);
        this.B = W(this, g)
    };
    _.T(Ym, Z);
    Ym.prototype.g = function() {
        var a = this,
            b = new $C(this.A, {
                timeoutMs: -1,
                Aj: !0
            });
        _.S(this, b);
        if (bD(b)) {
            var c = this.K.H,
                d = c.status,
                e = function(f) {
                    var g = a.B.value,
                        h, k;
                    if (k = !(a.o ? _.N(a.o, 9) : _.G(mB) && om())) {
                        var l = void 0 === l ? !1 : l;
                        k = mE(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !l || "string" !== typeof f.tcString || !f.tcString.length ? !0 : dD(f, "1") : !1
                    }
                    k = Lj(g, 5, k);
                    l = !nE(f, ["3", "4"]);
                    k = Lj(k, 9, l);
                    k = Zn(k, 2, f.tcString);
                    l = null != (h = f.addtlConsent) ? h : "";
                    h = Zn(k, 4, l);
                    _.no(h, 7, f.internalErrorState);
                    null != f.gdprApplies && Lj(g, 3, f.gdprApplies);
                    _.G(gC) && !nE(f, ["2", "7", "9", "10"]) && Lj(g, 8, !0);
                    a.j.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.g.push(e);
                    break;
                case 0:
                    zI(c);
                    c.g.push(e);
                    this.P.info(yJ());
                    b.addEventListener(function(f) {
                        mE(f) ? ("tcunavailable" === f.tcString ? a.P.info(AJ("failed")) : a.P.info(AJ("succeeded")), c.data = f, c.status = 2, c.g.forEach(function(g) {
                            g(f)
                        }), c.oe()) : zI(c)
                    });
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.j.notify()
    };
    var Xm = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.P = b;
        this.A = c;
        this.j = lG(this);
        nG(this, d);
        this.o = W(this, e)
    };
    _.T(Xm, Z);
    Xm.prototype.g = function() {
        var a = this,
            b = new IE(this.A);
        _.S(this, b);
        if (SC(b.caller)) {
            var c = Lh(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && (Zn(a.o.value, 1, d.uspString), eF(a.o.value, Lh(a.context, 1187, function() {
                    var e = d.uspString;
                    var f = e = e.toUpperCase();
                    4 == f.length && (-1 == f.indexOf("-") || "---" === f.substring(1)) && "1" <= f[0] && "9" >= f[0] && iA.hasOwnProperty(f[1]) && iA.hasOwnProperty(f[2]) && iA.hasOwnProperty(f[3]) ? (f = new hA, f = _.Bh(f, 1, parseInt(e[0], 10)), f = _.I(f, 2, iA[e[1]]), f = _.I(f, 3, iA[e[2]]), e = _.I(f, 4, iA[e[3]])) : e = null;
                    return 2 === (null == e ? void 0 : _.Nk(e, 3, 0))
                })()));
                a.j.notify()
            });
            this.P.info(xJ());
            JE(b, c)
        } else this.j.notify()
    };
    var Vm = function(a, b) {
        Z.call(this, a, 958);
        this.j = b;
        this.hb = V(this)
    };
    _.T(Vm, Z);
    Vm.prototype.g = function() {
        var a = new dF,
            b = this.j ? _.N(this.j, 9) : om();
        Lj(a, 5, !b);
        this.hb.D(a)
    };
    var Wm = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.A = b;
        this.o = d;
        this.j = W(this, c)
    };
    _.T(Wm, Z);
    Wm.prototype.g = function() {
        var a = this;
        Rh(this.context, 894, function() {
            return void ej("cmpMet", function(b) {
                kj(b, a.context);
                var c = new $C(a.A);
                _.S(a, c);
                var d = new IE(a.A);
                _.S(a, d);
                lj(b, "fc", Number(a.j.value));
                lj(b, "tcfv1", Number(!!a.A.__cmp));
                lj(b, "tcfv2", Number(bD(c)));
                lj(b, "usp", Number(!!SC(d.caller)));
                lj(b, "ptt", 17)
            }, a.o)
        })
    };
    var zK = function(a, b, c, d) {
        Z.call(this, a, 1103);
        this.j = b;
        this.V = c;
        this.privacyTreatments = d;
        this.output = V(this)
    };
    _.T(zK, Z);
    zK.prototype.g = function() {
        this.output.D(!!Uf(this.V) && !_.N(this.V, 9) && !_.N(this.V, 13) && (!_.G(Zm) || !_.N(this.V, 12)) && (this.j ? _.N(this.j, 9) || _.N(this.j, 8) || _.N(this.j, 1) || _.G(YB) && _.N(this.j, 13) || 1 === _.Nk(this.j, 6, 2) || 1 === mo(this.j, 5) || _.A(this.privacyTreatments, "includes").call(this.privacyTreatments, 1) ? !1 : !0 : !0))
    };
    var en = function(a) {
        this.P = a;
        this.m = this.g = 0
    };
    en.prototype.push = function() {
        for (var a = _.z(_.Wa.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.v.globalThis), this.g++)
            } catch (c) {
                this.m++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.P.error(YI(String(c)))
            }
        }
        this.P.info(ZI(String(this.g), String(this.m)));
        return this.g
    };
    var cn = function(a, b) {
        this.push = L(a, 76, b.push.bind(b))
    };
    var AK = ["Debug", "Info", "Warning", "Error", "Fatal"],
        BK = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.g = c;
            this.timestamp = new Date
        };
    _.q = BK.prototype;
    _.q.getSlot = function() {
        return this.g
    };
    _.q.getLevel = function() {
        return this.level
    };
    _.q.getTimestamp = function() {
        return this.timestamp
    };
    _.q.getMessage = function() {
        return this.message
    };
    _.q.toString = function() {
        return this.timestamp.toTimeString() + ": " + AK[this.level] + ": " + this.message
    };
    var CK = _.tu(["https://console.googletagservices.com/pubconsole/loader.js"]),
        pn = _.ef(CK),
        tn, sn = !1,
        kn = !1,
        mn = !1;
    var es = function(a, b) {
        this.getAllEvents = L(a, 563, function() {
            return kn ? DK(b).slice() : []
        });
        this.getEventsBySlot = L(a, 565, function(c) {
            return kn ? EK(b, c).slice() : []
        });
        this.getEventsByLevel = L(a, 566, function(c) {
            return kn ? FK(b, c).slice() : []
        })
    };
    var GK = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return vn(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            },
            154: function(a) {
                return "Refresh is disabled for " + vn(a[0]) + " " + a[1] + "."
            },
            152: function() {
                return "Attempted to load GPT multiple times."
            },
            155: function() {
                return "Using deprecated googletag.encryptedSignalProviders. Please use googletag.secureSignalProviders instead."
            },
            158: function(a) {
                return "Unrecognized property encountered when calling setConfig: " + a[0] + "." + a[1]
            },
            159: function(a) {
                return "Invalid value encountered when calling setConfig: " + a[0] + "." + a[1] + ": " + a[2]
            },
            160: function(a) {
                return "slot.setConfig key " + a[0] + " is not valid for this slot."
            }
        },
        HK = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            153: function() {
                return "Attempted to load GPT from both standard and limited ads domains."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var IK = function(a) {
            this.context = a;
            this.l = this.g = 0;
            this.v = window;
            this.m = [];
            this.m.length = 1E3
        },
        DK = function(a) {
            return [].concat(_.oh(a.m.slice(a.g)), _.oh(a.m.slice(0, a.g))).filter(function(b) {
                return !!b
            })
        },
        EK = function(a, b) {
            return DK(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        FK = function(a, b) {
            return DK(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    IK.prototype.log = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? !1 : d;
        var e, f, g = new BK(a, b, null != (f = null == (e = c) ? void 0 : e.g) ? f : null);
        this.m[this.g] = g;
        this.g = (this.g + 1) % 1E3;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs();
        e = b.getMessageId();
        var k = GK[e] || HK[e];
        e = void 0;
        if (k) {
            e = k(h);
            if (d) throw new Lm(e);
            d = this.l < _.$e(xB) && f && _.t.console;
            if (this.v === top && d || _.A(_.t.navigator.userAgent, "includes").call(_.t.navigator.userAgent, "Lighthouse")) {
                d = "[GPT] " + e;
                var l, m, n, p;
                2 === a ? null == (m = (l = _.t.console).warn) || m.call(l, d) : null == (p = (n = _.t.console).error) || p.call(n, d);
                this.l++
            }
        }
        a: if (m = e, l = c, l = void 0 === l ? null : l, this.context.Nl) {
            switch (a) {
                case 2:
                    n = 1;
                    break;
                case 3:
                    n = 2;
                    break;
                default:
                    break a
            }
            var r, w, u;
            a = this.context.Ga;
            c = a.Ml;
            p = new ZA;
            p = _.th(p, 1, this.context.pvsid);
            d = _.bg();
            p = _.le(p, 2, d, Pc);
            p = _.uh(p, 3, this.context.Nf);
            p = _.uh(p, 4, this.context.ab);
            p = _.th(p, 5, this.context.wl);
            n = _.I(p, 6, n);
            m = _.uh(n, 7, m);
            n = b.getMessageId();
            m = _.I(m, 8, n);
            b = b.getMessageArgs();
            b = _.Zh(m, 9, b);
            m = qh(null != (u = null == (r = l) ? void 0 : r.getAdUnitPath()) ? u : "");
            r = _.uh(b, 10, m);
            u = null == (w = l) ? void 0 : w.getAdUnitPath();
            w = _.uh(r, 11, u);
            c.call(a, w)
        }
        return g
    };
    IK.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var Q = function(a, b, c) {
        return a.log(2, b, c, !1)
    };
    IK.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var JK = function() {
            var a = {
                    W: Vi().g,
                    Qi: new Date(Date.now()),
                    rh: window.location.href
                },
                b = this;
            a = void 0 === a ? {} : a;
            var c = void 0 === a.W ? Vi().g : a.W,
                d = void 0 === a.Qi ? new Date(Date.now()) : a.Qi,
                e = void 0 === a.rh ? window.location.href : a.rh;
            this.g = "";
            this.v = this.m = null;
            this.J = this.j = !1;
            this.l = function() {
                return !1
            };
            a = {};
            var f = {},
                g = {};
            this.G = (g[3] = (a[72] = function(h, k) {
                var l = b.m;
                k = Number(k);
                h = null !== l ? _.hg("w5uHecUBa2S:" + Number(h) + ":" + l) % k === Math.floor(d.valueOf() / 864E5) % k : void 0;
                return h
            }, a[13] = function() {
                return _.Wa.apply(0, arguments).some(function(h) {
                    return _.A(b.g, "startsWith").call(b.g, h)
                })
            }, a[12] = function() {
                return !!_.N(c, 6)
            }, a[15] = function(h) {
                return b.l(h)
            }, a[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (h) {
                    return !1
                }
            }, a[67] = function() {
                return b.j
            }, a[68] = function() {
                return b.J
            }, a[74] = function() {
                return _.A(_.Wa.apply(0, arguments), "includes").call(_.Wa.apply(0, arguments), String(_.hg(e)))
            }, a), g[4] = (f[14] = function() {
                var h = Number(b.v || void 0);
                isNaN(h) ? h = void 0 : (h = new Date(1E3 * h), h = 1E4 * h.getFullYear() + 100 * (h.getMonth() + 1) + h.getDate());
                return h
            }, f), g[5] = {}, g)
        },
        KK = function(a, b) {
            if (b && !a.m) {
                b = b.split(":");
                a.m = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("ID=")
                }) || null;
                var c;
                a.v = (null == (c = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("T=")
                })) ? void 0 : c.substring(2)) || null
            }
        };
    var qt = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 863);
        this.o = c;
        this.fd = Number(b);
        this.j = W(this, d);
        this.F = W(this, e);
        this.I = W(this, f);
        this.B = W(this, g)
    };
    _.T(qt, Z);
    qt.prototype.g = function() {
        var a = this.I.value,
            b = this.j.value,
            c = this.B.value,
            d = this.F.value,
            e = this.o;
        var f = xn(e);
        var g = b.getBoundingClientRect();
        e = _.tk(e) ? ti(b, e) : {
            x: 0,
            y: 0
        };
        b = e.x;
        e = e.y;
        g = new _.Rz(e, b + g.right, e + g.bottom, b);
        b = new yF;
        b = _.Wo(b, 1, g.top);
        b = _.Wo(b, 3, g.bottom);
        b = _.Wo(b, 2, g.left);
        g = _.Wo(b, 4, g.right);
        b = new zF;
        b = _.Gi(b, 1, _.Sc(this.fd));
        d = Lj(b, 2, !d);
        d = _.wh(d, 3, g);
        c = _.Wo(d, 4, c);
        f = _.Wo(c, 5, f);
        f = {
            type: "asmres",
            payload: Gk(f)
        };
        a.ports[0].postMessage(f)
    };
    var bq = function(a, b, c, d) {
        Z.call(this, a, 1061);
        var e = this;
        this.output = V(this);
        this.output.Ka(new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                h = d(h);
                null !== h && (g(), f(h))
            });
            _.yn(e, g)
        }))
    };
    _.T(bq, Z);
    bq.prototype.g = function() {};
    var Qp = function(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        Z.call(this, a, 1061);
        var e = this;
        this.output = lG(this);
        cG(this.output, new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                d(h) && (g(), f())
            });
            _.yn(e, g)
        }))
    };
    _.T(Qp, Z);
    Qp.prototype.g = function() {};
    var ot = function(a, b, c, d) {
        bq.call(this, a, b, Rp, function(e) {
            e = e.detail;
            var f;
            return "asmreq" === (null == (f = e.data) ? void 0 : f.type) && Lr(xF(e.data.payload), 1) === Number(c) ? e : null
        });
        this.o = d;
        this.j = V(this)
    };
    _.T(ot, bq);
    ot.prototype.g = function() {
        this.j.D(xn(this.o))
    };
    var LK = /(<head(\s+[^>]*)?>)/i,
        Ts = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.output = V(this);
            this.j = W(this, b);
            this.o = Y(this, c);
            this.B = W(this, d);
            this.F = W(this, e)
        };
    _.T(Ts, Z);
    Ts.prototype.g = function() {
        var a;
        0 !== this.j.value.kind || null == (a = this.o.value) || !_.R(a, 1) || this.F.value ? this.output.D(this.j.value) : (a = this.j.value.vb, La("Firefox") || La("FxiOS") || (a = a.replace(LK, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.B.value && (a = a.replace(LK, '$1<meta name="referrer" content="origin">')), this.output.D({
            kind: 0,
            vb: a
        }))
    };
    var MK = function(a, b, c, d) {
        Z.call(this, a, 1124);
        this.Kd = lG(this);
        this.o = W(this, b);
        this.j = W(this, c);
        nG(this, d)
    };
    _.T(MK, Z);
    MK.prototype.g = function() {
        _.Yz(this.j.value, {
            "min-width": "100%",
            visibility: "hidden"
        });
        _.Yz(this.o.value, "min-width", "100%");
        this.Kd.notify()
    };
    var NK = function(a, b, c, d, e) {
        Z.call(this, a, 1125);
        this.o = W(this, b);
        this.j = W(this, c);
        nG(this, d);
        nG(this, e)
    };
    _.T(NK, Z);
    NK.prototype.g = function() {
        var a = this.o.value,
            b = a.contentDocument;
        b && (a.setAttribute("height", String(b.body.offsetHeight)), a.setAttribute("width", String(b.body.offsetWidth)), _.Yz(this.j.value, "visibility", "visible"))
    };
    var rt = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.slotId = b;
        this.Ug = e;
        this.o = f;
        this.B = g;
        this.output = V(this);
        this.j = new Qp(this.context, this.slotId, Is);
        this.I = Y(this, c);
        this.F = Y(this, d);
        this.M = W(this, h)
    };
    _.T(rt, Z);
    rt.prototype.g = function() {
        var a = !this.M.value;
        if (null == this.F.value || "height" !== this.I.value || a) this.j.ua(), this.output.D(!1);
        else {
            a = new Pj;
            _.S(this, a);
            var b = new MK(this.context, this.o, this.B, this.Ug);
            O(a, b);
            O(a, this.j);
            O(a, new NK(this.context, this.o, this.B, this.j.output, b.Kd));
            Yj(a);
            this.output.D(!0)
        }
    };
    var In = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Z.call(this, a, 699);
        this.U = b;
        this.slotId = c;
        this.j = d;
        this.dd = e;
        this.M = r;
        this.I = Y(this, f);
        this.ba = W(this, g);
        this.B = W(this, h);
        this.T = W(this, k);
        this.o = Y(this, l);
        this.ca = W(this, m);
        this.F = W(this, n);
        p && nG(this, p)
    };
    _.T(In, Z);
    In.prototype.g = function() {
        var a = this.ba.value,
            b = this.B.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.I.value) {
            var c, d = null != (c = this.o.value) ? c : 0;
            c = this.T.value;
            var e = this.ca.value,
                f = this.F.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                case 4:
                case 5:
                    var h = this.context;
                    g = this.U;
                    var k = this.slotId,
                        l = this.j,
                        m = this.dd,
                        n, p = a.parentElement ? null == (n = Ni(a.parentElement, window)) ? void 0 : n.width : void 0;
                    n = c.width;
                    var r = c.height,
                        w = 0;
                    var u = 0;
                    var x = li(l);
                    x = _.z(x);
                    for (var y = x.next(); !y.done; y = x.next()) {
                        var C = y.value;
                        Array.isArray(C) && (y = C[0], C = C[1], w < y && (w = y), u < C && (u = C))
                    }
                    u = [w, u];
                    w = u[0] < n;
                    r = u[1] < r;
                    if (w || r) {
                        u = n + "px";
                        x = {
                            "max-height": "none",
                            "max-width": u,
                            padding: "0px",
                            width: u
                        };
                        r && (x.height = "auto");
                        Zi(b, a, x);
                        b = {};
                        if ((_.H = [2, 5], _.A(_.H, "includes")).call(_.H, d) || w && n > Wi(e.width)) b.width = u, b["max-width"] = u;
                        r && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (D in b)
                                if (Object.prototype.hasOwnProperty.call(b, D)) {
                                    var D = !1;
                                    break c
                                }
                            D = !0
                        }
                        D ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.Yi(a, b), b = !0)
                    } else b = !1;
                    b: switch (u = c.width, D = g.defaultView || g.parentWindow || _.t, d) {
                        case 2:
                        case 5:
                            a = $i(a, D, u, e, m);
                            break b;
                        case 1:
                        case 4:
                            if (e = a.parentElement)
                                if (m = Ei(e)) {
                                    y = m.width;
                                    m = Li(k, D.document);
                                    n = Ni(m, D);
                                    r = n.position;
                                    C = Wi(n.width) || 0;
                                    w = Ni(e, D);
                                    x = "rtl" === w.direction ? "Right" : "Left";
                                    m = x.toLowerCase();
                                    D = "absolute" === r ? 0 : Wi(w["padding" + x]);
                                    w = Wi(w["border" + x + "Width"]);
                                    u = Math.max(Math.round((y - Math.max(C, u)) / 2), 0);
                                    y = {};
                                    C = 0;
                                    var E = Pn(n);
                                    E && (C = E[4] * ("Right" === x ? -1 : 1), x = E[3] || 1, 1 !== (E[0] || 1) || 1 !== x) && (E[0] = 1, E[3] = 1, y.transform = "matrix(" + E.join(",") + ")");
                                    x = 0;
                                    switch (r) {
                                        case "fixed":
                                            var J, M = null != (J = Number(Oi(n.getPropertyValue(m)))) ? J : 0,
                                                K;
                                            J = null != (K = e.getBoundingClientRect().left) ? K : 0;
                                            x = M - J;
                                            break;
                                        case "relative":
                                            x = null != (M = Number(Oi(n.getPropertyValue(m)))) ? M : 0;
                                            break;
                                        case "absolute":
                                            y[m] = "0"
                                    }
                                    y["margin-" + m] = u - D - w - x - C + "px";
                                    _.Yi(a, y);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (_.A(gH, "includes").call(gH, d) && bj(h, g, k, l, d, c.width, c.height, p, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, K = this.U, g = this.slotId, k = this.j, p = this.dd, l = a.parentElement ? null == (h = Ni(a.parentElement, window)) ? void 0 : h.width : void 0, h = c.width, J = c.height, M = Wi(e.height) || 0, J >= M || "none" === e.display || "hidden" === e.visibility || !p || -12245933 === p.width || a.getBoundingClientRect().bottom <= p.height ? g = !1 : (p = {
                        height: J + "px"
                    }, Zi(b, a, p), _.Yi(a, p), bj(d, K, g, k, 3, h, J, l, "gpt_slotred", f), g = !0)
            }!g && _.G(fB) && bj(this.context, this.U, this.slotId, this.j, 0, c.width, c.height, void 0, "gpt_pgbrk", f)
        }
        this.M.notify()
    };
    var Dn = function(a, b, c, d, e, f) {
        Z.call(this, a, 1114);
        this.I = b;
        this.ga = c;
        this.B = V(this);
        this.o = V(this);
        this.F = W(this, d);
        this.j = W(this, e);
        this.M = W(this, f)
    };
    _.T(Dn, Z);
    Dn.prototype.g = function() {
        if (this.I) {
            var a = this.I.split(":");
            if (2 !== a.length || "#flexibleAdSlotDebugSize" !== a[0]) OK(this);
            else {
                var b = a[1];
                a = PK(this, b);
                var c;
                (c = /(?:.*)height=(ratio|[0-9]+)(?:;.*|$)/.exec(b)) ? (c = c[1], "ratio" === c ? c = a && this.F.value && this.j.value ? Math.floor(this.j.value / this.F.value * a) : null : (c = Number(c), c = 0 <= c ? c : null)) : c = null;
                b = (b = /(?:.*)ius=(.+,?)+(?:;.*|$)/.exec(b)) ? b[1].split(",") : [];
                a || c ? (this.B.D(new _.Di(null != a ? a : this.F.value, null != c ? c : this.j.value)), this.o.D(b)) : OK(this)
            }
        } else OK(this)
    };
    var PK = function(a, b) {
            b = /(?:.*)width=(parent|viewport|[0-9]+)(?:;.*|$)/.exec(b);
            if (!b) return null;
            b = b[1];
            if ("viewport" === b) return a.ga;
            if ("parent" === b) {
                var c, d, e;
                return (b = null != (e = null == (d = Ei(null == (c = a.M.value) ? void 0 : c.parentElement)) ? void 0 : d.width) ? e : null) ? Math.min(b, a.ga) : null
            }
            a = Number(b);
            return 0 <= a ? a : null
        },
        OK = function(a) {
            a.B.Z();
            a.o.D([])
        };
    var En = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.I = c;
        this.Gc = d;
        this.T = n;
        this.ba = p;
        this.M = r;
        this.da = w;
        this.B = Y(this, e);
        this.oa = Y(this, f);
        this.la = Y(this, g);
        this.ca = Y(this, h);
        this.j = W(this, k);
        this.o = W(this, l);
        this.F = W(this, m)
    };
    _.T(En, Z);
    En.prototype.g = function() {
        var a = QK(this),
            b = this.ca.value,
            c;
        if (c = !this.Gc && a && b) this.j.value.length ? (c = this.adUnitPath.split("/"), c = _.A(this.j.value, "includes").call(this.j.value, c[c.length - 1])) : c = !0;
        if (c) {
            c = this.F.value;
            var d, e, f = null != (e = null == (d = Ei(c.parentElement)) ? void 0 : d.width) ? e : 0;
            d = b.width;
            b = b.height;
            RK(this, !0, d, b, {
                kind: 0,
                vb: '<html><body style="height:' + (b - 2 + "px;width:" + (d - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (d + "x" + b + "</p></body></html>")
            }, d <= f ? 1 : 2, c)
        } else if (a = this.oa.value, b = this.la.value, this.Gc) RK(this, !1, null != a ? a : 0, null != b ? b : 0, this.o.value);
        else {
            if (null == a) throw new Lm("Missing 'width'.");
            if (null == b) throw new Lm("Missing 'height'.");
            RK(this, !1, a, b, this.o.value)
        }
    };
    var QK = function(a) {
            a = li(a.I)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.Di(a[0], a[1]) : null
        },
        RK = function(a, b, c, d, e, f, g) {
            f = void 0 === f ? a.B.value : f;
            a.da.D(b);
            a.ba.D(new _.Di(c, d));
            a.T.D(e);
            a.M.Aa(f);
            g && _.Yz(g, "opacity", .5)
        };
    var Hn = function(a, b, c) {
        Z.call(this, a, 698);
        this.A = b;
        this.output = V(this);
        this.j = W(this, c)
    };
    _.T(Hn, Z);
    Hn.prototype.g = function() {
        this.output.Aa(Ni(this.j.value, this.A))
    };
    var SK = null;
    var TK = function(a, b, c, d, e) {
        Z.call(this, a, 937, _.$e(RB));
        this.gb = b;
        this.j = V(this);
        this.o = V(this);
        this.B = V(this);
        this.Wb = c;
        this.Ub = d;
        this.Cc = e
    };
    _.T(TK, Z);
    TK.prototype.g = function() {
        var a = {},
            b;
        if (null == (b = _.di(this.gb, Px, 2)) ? 0 : _.N(b, 2)) a["*"] = {
            Oe: !0
        };
        b = new _.v.Set;
        for (var c = _.z(_.gi(this.gb, Ox, 1)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = _.z([_.R(d, 2), _.R(d, 1)].filter(function(p) {
                    return !!p
                })), f = e.next(); !f.done; f = e.next()) a[f.value] = {
                Oe: _.N(d, 3)
            };
            d = _.z(be(d, 4, Qc, 2));
            for (e = d.next(); !e.done; e = d.next()) b.add(e.value)
        }
        this.Wb.D(a);
        this.j.D([].concat(_.oh(b)));
        var g, h;
        a = null == (g = _.di(this.gb, Px, 2)) ? void 0 : null == (h = _.di(g, Jx, 1)) ? void 0 : _.gi(h, Ix, 1);
        this.o.Aa((null == a ? 0 : a.length) ? a : null);
        var k;
        this.Ub.D(!(null == (k = _.di(this.gb, Px, 2)) || !_.N(k, 4)));
        var l;
        this.Cc.D(!(null == (l = _.di(this.gb, Px, 2)) || !_.N(l, 5)));
        var m, n;
        g = null == (m = _.di(this.gb, Px, 2)) ? void 0 : null == (n = _.di(m, Jx, 3)) ? void 0 : _.gi(n, Ix, 1);
        this.B.Aa((null == g ? 0 : g.length) ? g : null)
    };
    TK.prototype.G = function(a) {
        this.l(a)
    };
    TK.prototype.l = function() {
        this.Wb.D({});
        this.j.D([]);
        this.o.Z();
        this.Ub.D(!1);
        this.Cc.D(!1);
        this.B.Z()
    };
    var UK = function(a, b, c, d) {
        Z.call(this, a, 980);
        this.Ya = b;
        this.output = new Gn;
        this.j = W(this, c);
        this.o = W(this, d)
    };
    _.T(UK, Z);
    UK.prototype.g = function() {
        (_.H = _.A(Object, "entries").call(Object, this.j.value), _.A(_.H, "find")).call(_.H, function(c) {
            var d = _.z(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.Oe)
        }) && (this.Ya.J = !0);
        $l(25, this.context);
        for (var a = _.z(this.o.value), b = a.next(); !b.done; b = a.next()) ag(b.value);
        this.output.notify()
    };
    var VK = function(a, b, c, d) {
        Z.call(this, a, 931);
        this.j = Y(this, b);
        this.vc = c;
        this.Vb = d
    };
    _.T(VK, Z);
    VK.prototype.g = function() {
        var a = this.j.value,
            b = new _.v.Map;
        this.vc.D(new _.v.Map);
        if (a) {
            var c;
            a = _.z(null != (c = this.j.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = _.gi(d, Hx, 1);
                c = 1 === _.Nk(c[0], 1, 0) ? cx(c[0]) : dx(c[0], bx);
                d = _.Cf(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        this.Vb.D(b)
    };
    VK.prototype.l = function() {
        this.vc.D(new _.v.Map);
        this.Vb.D(new _.v.Map)
    };
    var WK = function(a, b, c) {
        Z.call(this, a, 981);
        this.o = V(this);
        this.B = Y(this, b);
        this.j = c
    };
    _.T(WK, Z);
    WK.prototype.g = function() {
        var a = new _.v.Map,
            b, c = _.z(null != (b = this.B.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = _.gi(b, Hx, 1);
            d = 1 === _.Nk(d[0], 1, 0) ? cx(d[0]) : dx(d[0], bx);
            a.set(d, _.Cf(b, 2))
        }
        this.o.D(a);
        this.j.D(new Ax)
    };
    WK.prototype.l = function() {
        this.o.D(new _.v.Map);
        var a = this.j,
            b = a.D;
        var c = new Ax;
        c = _.no(c, 1, 2);
        b.call(a, c)
    };
    var XK = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.j = e;
        this.requestBidsConfig = f;
        nG(this, b);
        nG(this, c)
    };
    _.T(XK, Z);
    XK.prototype.g = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.j, [this.requestBidsConfig])
    };
    var YK = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.o = b;
        this.j = c;
        this.B = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.output = new Gn
    };
    _.T(YK, Z);
    YK.prototype.g = function() {
        $n(this.pbjs, this.o, this.j, this.B, this.requestBidsConfig);
        this.output.notify()
    };
    YK.prototype.l = function() {
        this.output.notify()
    };
    var ZK = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.j = c;
        this.o = d;
        this.B = e;
        this.requestBidsConfig = f;
        this.output = new Gn
    };
    _.T(ZK, Z);
    ZK.prototype.g = function() {
        var a, b, c = null != (b = null == (a = this.j) ? void 0 : a.get("*")) ? b : _.$e(jB);
        if (c) this.Tb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.z(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.j) ? void 0 : c.get(_.G(qo) ? wg(e) : e)) ? a : null == (b = this.j) ? void 0 : b.get(_.hg(e))) ? g : 0, this.Tb(f)
        }
        this.output.notify()
    };
    ZK.prototype.Tb = function(a) {
        var b;
        null != (b = this.o) && Lj(b, 2, this.B);
        if (a) {
            var c;
            null == (c = this.o) || _.no(c, 1, 1);
            if (!this.B) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.z(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    ZK.prototype.l = function() {
        this.output.notify()
    };
    var $K = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.g = a;
        this.v = b;
        this.l = c;
        this.j = d;
        this.H = e;
        this.G = f;
        this.L = g;
        this.pbjs = h
    };
    _.T($K, _.U);
    $K.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new Pj;
            _.S(this, d);
            var e = new ZK(this.g, this.pbjs, this.H, this.G, this.L, a),
                f = new YK(this.g, this.v, this.l, this.j, this.pbjs, a);
            O(d, e);
            O(d, f);
            O(d, new XK(this.g, f.output, e.output, c, b, a));
            Yj(d)
        }
    };
    var bo = function(a, b) {
        this.push = L(a, 932, function(c) {
            b.push(c)
        })
    };
    var aL = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 951);
        this.A = window;
        this.F = W(this, b);
        this.o = Y(this, d);
        this.B = W(this, e);
        this.M = W(this, f);
        this.j = Y(this, g);
        this.T = Y(this, h);
        this.I = W(this, k);
        nG(this, c);
        this.bf = null != l ? l : V(this);
        this.cf = null != m ? m : V(this)
    };
    _.T(aL, Z);
    aL.prototype.g = function() {
        var a = !!Nm().pbjs_hooks;
        this.cf.D(a);
        this.bf.Aa(a ? null : _.Yg());
        var b, c = null == (b = this.o.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.j.value) ? void 0 : d.size) || _.$e(jB);
        d = this.F.value;
        var e, f = null != (e = Nm().pbjs_hooks) ? e : [];
        e = new $K(this.context, this.o.value, this.B.value, this.M.value, this.j.value, this.T.value, this.I.value, d);
        _.S(this, e);
        f = _.z(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) Nm().pbjs_hooks = co(this.context, e);
        !c && !b || a || ao(d, this.A)
    };
    var bL = function(a, b, c) {
        Z.call(this, a, 966);
        this.A = b;
        this.Pb = c
    };
    _.T(bL, Z);
    bL.prototype.g = function() {
        var a = this,
            b = vg(this.A);
        if (b) this.Pb.D(b);
        else if (b = Object.getOwnPropertyDescriptor(this.A, "_pbjsGlobals"), !b || b.configurable) {
            var c = null;
            Object.defineProperty(this.A, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = vg(a.A)) && a.Pb.D(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    bL.prototype.l = function() {};
    var cL = function(a, b, c, d, e) {
        Z.call(this, a, 1146, _.$e(RB));
        this.Ya = b;
        this.A = d;
        this.j = e;
        this.o = mG(this, c)
    };
    _.T(cL, Z);
    cL.prototype.g = function() {
        var a = this.o.value,
            b = new Pj;
        _.S(this, b);
        var c = new bL(this.context, this.A, this.j.Pb);
        O(b, c);
        if (a) {
            a = new TK(this.context, a, this.j.Wb, this.j.Ub, this.j.Cc);
            O(b, a);
            var d = new UK(this.context, this.Ya, a.Wb, a.j);
            O(b, d);
            var e = new VK(this.context, a.o, this.j.vc, this.j.Vb);
            O(b, e);
            var f = new WK(this.context, a.B, this.j.Af);
            O(b, f);
            c = new aL(this.context, c.Pb, d.output, e.Vb, this.j.Ub, e.vc, f.o, f.j, a.Cc, this.j.bf, this.j.cf);
            O(b, c)
        } else dL(this);
        Yj(b)
    };
    var dL = function(a) {
        a.j.Wb.D({});
        a.j.Vb.D(new _.v.Map);
        a.j.Ub.D(!1);
        a.j.vc.D(new _.v.Map);
        a.j.bf.Z();
        a.j.cf.D(!1);
        a.j.Af.D(new Ax);
        a.j.Cc.D(!1)
    };
    cL.prototype.G = function(a) {
        this.l(a)
    };
    cL.prototype.l = function() {
        dL(this)
    };
    var eL = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        fL = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 920);
            this.P = b;
            this.R = c;
            this.pbjs = f;
            this.B = g;
            this.F = V(this);
            this.o = V(this);
            this.I = [];
            this.j = new _.v.Map;
            this.ba = W(this, d);
            this.T = Y(this, e.Vb);
            this.M = W(this, e.Ub);
            this.da = W(this, e.vc);
            this.ca = Y(this, e.Af)
        };
    _.T(fL, Z);
    fL.prototype.g = function() {
        var a = gL(this, this.pbjs);
        a ? (this.B.Aa(a), this.F.D(this.j), this.o.D(this.I)) : hL(this)
    };
    fL.prototype.G = function(a) {
        this.l(a)
    };
    fL.prototype.l = function(a) {
        this.P.error(EJ(a.message));
        hL(this)
    };
    var hL = function(a) {
            a.B.Z();
            a.F.Z();
            a.o.Z()
        },
        gL = function(a, b) {
            var c = (0, b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.ba.value.map(function(g) {
                    var h = new Fx,
                        k = function(ra) {
                            return ra === g.getDomId() || ra === g.getAdUnitPath()
                        },
                        l, m = null != (l = iL.get(g)) ? l : 0,
                        n;
                    l = null != (n = d.filter(function(ra) {
                        var Aa, ya, Pa;
                        return Number(null == (Aa = ra.args) ? void 0 : Aa.timestamp) > m && (null == (ya = ra.args) ? void 0 : null == (Pa = ya.adUnitCodes) ? void 0 : _.A(Pa, "find").call(Pa, k))
                    })) ? n : [];
                    if (!l.length) return a.I.push(g), [g, h];
                    var p;
                    n = null == (p = l.reduce(function(ra, Aa) {
                        return Number(Aa.args.timestamp) > Number(ra.args.timestamp) ? Aa : ra
                    })) ? void 0 : p.args;
                    if (!n) return [g, h];
                    var r = void 0 === n.bidderRequests ? [] : n.bidderRequests;
                    p = void 0 === n.bidsReceived ? [] : n.bidsReceived;
                    var w = n.auctionId;
                    n = n.timestamp;
                    if (!w || null == n || !r.length) return [g, h];
                    iL.has(g) || _.yn(g, function() {
                        return iL.delete(g)
                    });
                    iL.set(g, n);
                    n = Gx(h);
                    Math.random() < _.$e(iB) && b.version && eL.test(b.version) && Zn(n, 6, b.version);
                    var u;
                    Dx(n, null == (u = a.ca) ? void 0 : u.value);
                    u = Mi(function() {
                        return Do(c, w)
                    });
                    l = hl(a.R[g.getDomId()]);
                    r = _.z(r);
                    for (var x = r.next(), y = {}; !x.done; y = {
                            bidderCode: y.bidderCode,
                            Pg: y.Pg
                        }, x = r.next()) {
                        var C = x.value;
                        y.bidderCode = C.bidderCode;
                        var D = C.bids;
                        x = C.timeout;
                        y.Pg = C.src;
                        C = C.auctionStart;
                        D = _.z(D);
                        for (var E = D.next(), J = {}; !E.done; J = {
                                jd: J.jd
                            }, E = D.next()) {
                            var M = E.value;
                            J.jd = M.bidId;
                            var K = M.transactionId;
                            E = M.adUnitCode;
                            var X = M.getFloor;
                            M = M.mediaTypes;
                            if (J.jd && k(E)) {
                                e = !0;
                                oo(n, g, E);
                                K && (null != _.Gj(n, 4) || Zn(n, 4, K), a.j.has(K) || a.j.set(K, C));
                                null == Mp(n, 8) && _.A(Number, "isFinite").call(Number, x) && _.Wo(n, 8, x);
                                var ba = _.A(p, "find").call(p, function(ra) {
                                    return function(Aa) {
                                        return Aa.requestId === ra.jd
                                    }
                                }(J));
                                K = fo(n, function(ra) {
                                    return function() {
                                        var Aa = io(new jo, ra.bidderCode);
                                        ko(ra.bidderCode, b, Aa);
                                        switch (ra.Pg) {
                                            case "client":
                                                _.no(Aa, 7, 1);
                                                break;
                                            case "s2s":
                                                _.no(Aa, 7, 2)
                                        }
                                        return Aa
                                    }
                                }(y)());
                                ro(n, K, E, a.T.value, a.M.value, a.da.value, X);
                                ba ? (ho(K, 1), "number" === typeof ba.timeToRespond && _.A(Number, "isFinite").call(Number, ba.timeToRespond) && _.Dk(K, 2, Math.round(ba.timeToRespond)), E = eo(ba, l, M), go(K, E)) : (E = u().get(J.jd)) && !E.Uh ? (ho(K, 2), _.A(Number, "isFinite").call(Number, E.latency) && _.Dk(K, 2, Math.round(E.latency))) : (E = ho(K, 3), _.A(Number, "isFinite").call(Number, x) && _.Dk(E, 2, Math.round(x)))
                            }
                        }
                    }
                    var la;
                    (null == (la = b.getConfig) ? 0 : la.call(b).useBidCache) && lo(n, g, w, l, b);
                    return [g, h]
                });
            return e ? new _.v.Map(f) : null
        },
        iL = new _.v.Map;
    var jL = function(a, b, c, d) {
        Z.call(this, a, 1019);
        this.R = c;
        this.pbjs = d;
        this.j = Y(this, b)
    };
    _.T(jL, Z);
    jL.prototype.g = function() {
        kL(this)
    };
    var kL = function(a) {
        if (!(Math.random() >= _.$e(hB))) {
            var b = (a.j.value || []).filter(function(k) {
                return hl(a.R[k.getDomId()]).some(function(l) {
                    return "hb_pb" === _.Gj(l, 1)
                })
            });
            if (b.length) {
                var c, d, e, f, g, h = (null == (c = a.pbjs) ? 0 : null == (d = c.adUnits) ? 0 : d.length) ? [].concat(_.oh(new _.v.Set(null == (e = a.pbjs) ? void 0 : e.adUnits.map(function(k) {
                    return k.code
                })))) : _.A(Object, "keys").call(Object, (null == (f = a.pbjs) ? void 0 : null == (g = f.getAdserverTargeting) ? void 0 : g.call(f)) || {});
                c = new ln("haux");
                lj(c, "ius", b.map(function(k) {
                    return k.getAdUnitPath()
                }).join("~"));
                lj(c, "dids", b.map(function(k) {
                    return k.getDomId()
                }).join("~"));
                lj(c, "paucs", h.join("~"));
                kj(c, a.context);
                nn(c)
            }
        }
    };
    var Io = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1153);
        this.P = b;
        this.R = c;
        this.networkCode = d;
        this.F = e;
        this.fe = f;
        this.j = h;
        this.I = W(this, f.Wb);
        this.o = new bG(f.Pb);
        g && (this.B = Y(this, g))
    };
    _.T(Io, Z);
    Io.prototype.g = function() {
        var a, b = null == (a = this.o) ? void 0 : a.value;
        if (a = lL(this)) null != b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.P.error(DJ()), a = !1) : a = !0 : a = !1;
        if (a) {
            a = new Pj;
            var c = new fL(this.context, this.P, this.R, this.F, this.fe, b, this.j.Og);
            O(a, c);
            O(a, new jL(this.context, c.o, this.R, b));
            Yj(a)
        } else this.j.Og.Z()
    };
    var lL = function(a) {
        var b;
        if (null == (b = a.B) ? 0 : b.value) return !0;
        var c = a.I.value;
        if (!c) return !1;
        var d;
        return !(null == (d = c["*"]) || !d.Oe) || a.networkCode.split(",").some(function(e) {
            var f;
            return !(null == (f = c[e]) || !f.Oe)
        })
    };
    var mL = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.B = d;
        this.af = e;
        this.o = W(this, b);
        this.j = W(this, c)
    };
    _.T(mL, Z);
    mL.prototype.g = function() {
        for (var a = this, b = _.z(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), c = b.next(), d = {}; !c.done; d = {
                pd: d.pd,
                Ue: d.Ue
            }, c = b.next()) d.pd = c.value, d.Ue = function(e) {
            return function(f) {
                if (a.B === f.adId) {
                    var g = new ln("hbm_brt");
                    kj(g, a.context);
                    lj(g, "et", e.pd);
                    lj(g, "sf", a.o.value);
                    lj(g, "qqid", a.j.value);
                    var h, k, l;
                    lj(g, "bc", String(null != (l = null != (k = f.bidderCode) ? k : null == (h = f.bid) ? void 0 : h.bidder) ? l : ""));
                    nn(g)
                }
            }
        }(d), (0, this.af.onEvent)(d.pd, d.Ue), _.yn(this, function(e) {
            return function() {
                return void Rh(a.context, a.id, function() {
                    var f, g;
                    return void(null == (g = (f = a.af).offEvent) ? void 0 : g.call(f, e.pd, e.Ue))
                }, !0)
            }
        }(d))
    };
    mL.prototype.l = function() {};
    var Ko = function(a, b, c, d, e) {
        Z.call(this, a, 1134);
        this.sf = d;
        this.ec = e;
        this.o = Y(this, b);
        this.j = new bG(c)
    };
    _.T(Ko, Z);
    Ko.prototype.g = function() {
        var a;
        if (this.o.value && null != (a = this.j.value) && a.onEvent) {
            a = new Pj;
            var b = new mL(this.context, this.sf, this.ec, this.o.value, this.j.value);
            O(a, b);
            Yj(a)
        }
    };
    var qL = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.K = c;
            this.g = new _.v.Map;
            this.m = new _.v.Map;
            this.timer = _.Ye(Nh);
            iI() && (_.lb(window, "DOMContentLoaded", Lh(a, 334, function() {
                for (var f = _.z(e.g), g = f.next(); !g.done; g = f.next()) {
                    var h = _.z(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    nL(e, g, h) && e.g.delete(g)
                }
            })), b.listen(vI, function(f) {
                f = f.detail;
                var g = f.R;
                return void oL(e, pL(d, f.Ng), Lr(g, 20))
            }), b.listen(wI, function(f) {
                f = f.detail;
                var g = f.R;
                f = pL(d, f.Ng);
                g = Lr(g, 20);
                var h = e.m.get(f);
                null != h ? kI(h, g) : oL(e, f, g)
            }))
        },
        oL = function(a, b, c) {
            nL(a, b, c) ? a.g.delete(b) : (a.g.set(b, c), _.yn(b, function() {
                return a.g.delete(b)
            }))
        },
        nL = function(a, b, c) {
            var d = Li(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new hI({
                A: window,
                timer: a.timer,
                Ib: d,
                lb: function(e) {
                    return void Ph(a.context, 336, e)
                },
                Sl: _.G(AC),
                Rf: _.G(NB)
            });
            if (!d.m) return !1;
            kI(d, c);
            a.m.set(b, d);
            DI(a.K, b, function() {
                return void a.m.delete(b)
            });
            return !0
        };
    var rL = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.A = b;
        this.V = c;
        this.output = lG(this);
        d && (this.j = Y(this, d.Ac));
        nG(this, e)
    };
    _.T(rL, Z);
    rL.prototype.g = function() {
        var a;
        fg(this.A.isSecureContext, this.A, this.A.document) && null != (a = this.j) && a.value && !_.G(lB) && Uf(this.V) && (a = this.j.value, a({
            message: "goog:spam:client_age",
            pvsid: this.context.pvsid
        }));
        this.output.notify()
    };
    var sL = function(a, b, c) {
        Z.call(this, a, 1199);
        this.j = c;
        this.o = Y(this, b)
    };
    _.T(sL, Z);
    sL.prototype.g = function() {
        var a = this.o.value;
        a && (a = eH(this.j, a.getSlotElementId()), Lj(a, 30, !0))
    };
    var tL = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1109);
        this.U = c;
        this.W = d;
        this.j = e;
        this.B = f;
        this.F = g;
        this.o = h;
        this.output = V(this);
        this.I = Y(this, b)
    };
    _.T(tL, Z);
    tL.prototype.g = function() {
        var a = this,
            b = this.I.value;
        b && (this.o.push(function() {
            b.addService(a.j)
        }), Nz(this.U, function() {
            a.F();
            a.B(b);
            _.N(a.W, 4) && a.j.refresh([b])
        }))
    };
    var uL = {},
        Qo = (uL[64] = GJ, uL[134217728] = HJ, uL[32768] = IJ, uL[536870912] = JJ, uL[8] = KJ, uL[512] = LJ, uL[1048576] = MJ, uL[4194304] = OJ, uL);
    var vL = function(a) {
        return "22639388115" === qh(a.getAdUnitPath())
    };
    var wL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1108);
        this.adUnitPath = b;
        this.format = c;
        this.pb = d;
        this.o = e;
        this.P = f;
        this.output = V(this);
        this.j = V(this)
    };
    _.T(wL, Z);
    wL.prototype.g = function() {
        var a = ip(this.context, this.P, this.o, {
            wh: this.format,
            adUnitPath: this.adUnitPath,
            pb: this.pb
        });
        this.j.Aa(a);
        this.output.Aa(a ? a.g : null)
    };
    var xL = function(a, b, c, d) {
        Z.call(this, a, 1111);
        this.j = c;
        this.o = d;
        this.B = Y(this, b)
    };
    _.T(xL, Z);
    xL.prototype.g = function() {
        var a = this.B.value;
        a && (a = eH(this.j, a.getSlotElementId()), Mj(a, 27, Xx, this.o))
    };
    var yL = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Pj.call(this);
        this.context = a;
        this.U = b;
        this.adUnitPath = c;
        this.format = d;
        this.pb = e;
        this.T = f;
        this.I = g;
        this.M = h;
        this.F = k;
        this.W = l;
        this.H = m;
        this.ba = n;
        this.P = p;
        this.ca = r;
        this.L = w;
        a = O(this, new wL(this.context, this.adUnitPath, this.format, this.pb, this.ba, this.P));
        this.L && O(this, new xL(this.context, a.output, this.H, this.L));
        this.ca && O(this, new sL(this.context, a.output, this.H));
        O(this, new tL(this.context, a.output, this.U, this.W, this.T, this.I, this.M, this.F));
        this.g = {
            Sn: a.j
        }
    };
    _.T(yL, Pj);
    var jp = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1198);
        this.U = b;
        this.googletag = c;
        this.W = d;
        this.j = e;
        this.o = f;
        this.P = g;
        this.B = W(this, h)
    };
    _.T(jp, Z);
    jp.prototype.g = function() {
        for (var a = this, b = _.z(this.B.value), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            c = d.getAdUnitPath();
            d = _.Nk(d, 2, 0);
            c && d && (c = new yL(this.context, this.U, c, d, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, this.W, this.j, this.o, this.P, !0), Yj(c), _.S(this, c))
        }
    };
    var Bs = function(a, b) {
        Z.call(this, a, 1110);
        this.A = b;
        this.output = V(this)
    };
    _.T(Bs, Z);
    Bs.prototype.g = function() {
        var a = this.A;
        a = _.G(wC) && void 0 !== a.credentialless && (_.G(xC) || a.crossOriginIsolated);
        this.output.D(a)
    };
    var zL = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.K = b;
        this.O = c;
        this.U = d;
        this.output = lG(this);
        this.j = W(this, e);
        nG(this, f)
    };
    _.T(zL, Z);
    zL.prototype.g = function() {
        var a = this.O,
            b = a.W;
        a = a.R;
        for (var c = _.z(this.j.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.U;
            lp(e, b) && !this.K.mc(d) && mp(d, f, e, b)
        }
        this.output.notify()
    };
    var tp = function(a, b, c) {
        Z.call(this, a, 1208);
        this.j = b;
        this.output = new Gn;
        this.o = Y(this, c)
    };
    _.T(tp, Z);
    tp.prototype.g = function() {
        var a, b = null == (a = this.o.value) ? void 0 : _.di(a, ty, 1);
        if (b) {
            a = this.j;
            var c = new dF;
            c = Lj(c, 5, !0);
            kF(a, "__eoi", b, c)
        }
        this.output.notify()
    };
    var yp = function(a, b, c, d) {
        Z.call(this, a, 896);
        this.Zf = b;
        this.lc = d;
        this.Ic = V(this);
        c && nG(this, c)
    };
    _.T(yp, Z);
    yp.prototype.g = function() {
        this.Ic.D(this.Zf.Hc(".google.cn" === this.lc))
    };
    var AL = function(a, b) {
        Z.call(this, a, 1018);
        this.Ce = lG(this);
        this.j = Y(this, b)
    };
    _.T(AL, Z);
    AL.prototype.g = function() {
        var a, b, c;
        if (null == (a = this.j.value)) a = void 0;
        else {
            var d;
            null == (b = _.di(a, PC, 5)) ? d = void 0 : d = be(b, 1, Qc, 2);
            a = d
        }
        a = _.z(null != (c = a) ? c : []);
        for (c = a.next(); !c.done; c = a.next()) ag(c.value);
        this.Ce.notify()
    };
    var BL = function(a, b) {
        Z.call(this, a, 1070);
        this.j = V(this);
        this.o = Y(this, b)
    };
    _.T(BL, Z);
    BL.prototype.g = function() {
        var a, b = null == (a = this.o.value) ? void 0 : _.di(a, PC, 5);
        if (b) {
            a = [];
            var c = be(b, 2, gd, 2, void 0, void 0, 0);
            c = _.z(c);
            for (var d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new Xx;
                var f = new Vx;
                e = _.Gi(f, 1, Yc(e));
                d = _.wh(d, 2, e);
                null != Mp(b, 3) && (e = new Tx, e = _.no(e, 1, 1), f = _.$w(b, 3), e = _.Dk(e, 2, f), _.wh(d, 3, e));
                a.push(d)
            }
            this.j.D(a)
        } else this.j.D([])
    };
    var CL = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.output = V(this);
        this.o = Y(this, b);
        this.j = Y(this, c);
        this.B = pG(this, [b, d])
    };
    _.T(CL, Z);
    CL.prototype.g = function() {
        if (this.j.value) {
            var a = this.o.value || this.B.value;
            a && DL(this, a) ? this.output.D(a) : this.output.Z()
        } else this.output.Z()
    };
    CL.prototype.G = function(a) {
        this.l(a)
    };
    CL.prototype.l = function() {
        this.output.Z()
    };
    var DL = function(a, b) {
        return _.gi(a.j.value, Rx, 1).some(function(c) {
            return _.R(c, 1) === b
        })
    };
    var EL = function(a, b) {
        Z.call(this, a, 1015);
        this.j = V(this);
        this.o = Y(this, b)
    };
    _.T(EL, Z);
    EL.prototype.g = function() {
        if (this.o.value)
            if (_.gi(this.o.value, Rx, 1).length) {
                var a = _.gi(this.o.value, Rx, 1)[0];
                (_.H = [2, 3], _.A(_.H, "includes")).call(_.H, _.Nk(a, 3, 0)) ? this.j.D(_.R(a, 1)) : this.j.Z()
            } else this.j.Z();
        else this.j.Z()
    };
    EL.prototype.G = function(a) {
        this.l(a)
    };
    EL.prototype.l = function() {
        this.j.Z()
    };
    var FL = function(a, b, c) {
        Z.call(this, a, 1017);
        this.A = c;
        this.output = lG(this);
        this.j = Y(this, b)
    };
    _.T(FL, Z);
    FL.prototype.g = function() {
        var a = this;
        if (this.j.value) {
            var b = pE(this.A, this.j.value, function(c) {
                if (!c) {
                    c = tf(b.g);
                    for (var d = _.z(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.oj(e.value)
                }
                a.output.notify()
            });
            b.start()
        } else this.output.notify()
    };
    FL.prototype.G = function(a) {
        this.l(a)
    };
    FL.prototype.l = function() {
        this.output.notify()
    };
    var GL = function(a, b) {
        Z.call(this, a, 1056);
        this.output = V(this);
        this.j = W(this, b)
    };
    _.T(GL, Z);
    GL.prototype.g = function() {
        var a = qh(this.j.value.getAdUnitPath());
        this.output.D(a)
    };
    GL.prototype.G = function(a) {
        this.l(a)
    };
    GL.prototype.l = function() {
        this.output.Z()
    };
    var HL = function(a, b, c, d) {
        Z.call(this, a, 906, _.$e(SB));
        this.j = lG(this);
        if (b === b.top) {
            var e = new Pj;
            _.S(this, e);
            var f = new EL(a, c);
            O(e, f);
            d = new bq(a, d, vI, function(g) {
                return g.detail.R
            });
            O(e, d);
            d = new GL(a, d.output);
            O(e, d);
            a = new CL(a, f.j, c, d.output);
            O(e, a);
            b = new FL(this.context, a.output, b);
            O(e, b);
            oG(this, b.output);
            Yj(e)
        } else this.j.notify()
    };
    _.T(HL, Z);
    HL.prototype.g = function() {
        this.j.notify()
    };
    HL.prototype.G = function(a) {
        this.l(a)
    };
    HL.prototype.l = function() {
        this.j.notify()
    };
    var gt = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.A = b;
        this.slotId = c;
        nG(this, d);
        this.j = W(this, e)
    };
    _.T(gt, Z);
    gt.prototype.g = function() {
        var a = this;
        this.slotId.listen(Rp, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.j.value,
                        g = new ty;
                    var h = Zn(g, 1, d ? "1" : "0");
                    var k = Zn(_.Dk(h, 2, 2147483647), 3, "/");
                    var l = Zn(k, 4, a.A.location.hostname);
                    var m = new _.iF(a.A);
                    kF(m, "__gpi_opt_out", l, f);
                    if (d || e) lF(m, "__gads", f), lF(m, "__gpi", f)
                }
            } catch (n) {}
        })
    };
    var IL = function(a, b, c) {
        Z.call(this, a, 944);
        this.A = b;
        this.j = new _.iF(this.A);
        this.o = W(this, c)
    };
    _.T(IL, Z);
    IL.prototype.g = function() {
        var a = this.o.value;
        if (jF(this.j, a)) {
            var b = _.am(this.j, "__gpi_opt_out", a);
            if (b) {
                var c = new ty;
                b = Zn(c, 1, b);
                b = Zn(_.Dk(b, 2, 2147483647), 3, "/");
                b = Zn(b, 4, this.A.location.hostname);
                kF(this.j, "__gpi_opt_out", b, a)
            }
        }
    };
    var JL = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.V = b;
        this.xa = c;
        this.j = W(this, d)
    };
    _.T(JL, Z);
    JL.prototype.g = function() {
        if (Uf(this.V)) {
            var a = new _.v.Set;
            var b = _.gi(this.j.value, ty, 14);
            b = _.z(b);
            for (var c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = gx(c, 5)) ? d : 1;
                a.has(e) || (kF(this.xa, 2 === e ? "__gpi" : "__gads", c, this.V), a.add(e))
            }
        }
    };
    var KL = function() {
            this.m = [];
            this.hostpageLibraryTokens = [];
            this.g = {}
        },
        ss = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.g[b]) ? void 0 : _.A(c, "values").call(c)) ? d : [];
            return [].concat(_.oh(a))
        };
    var LL = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Sa = c;
        this.j = W(this, d)
    };
    _.T(LL, Z);
    LL.prototype.g = function() {
        var a = be(this.j.value, 23, Oc, 2);
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = this.Sa;
            if (!_.A(c.m, "includes").call(c.m, b) && (_.H = [1, 2, 3], _.A(_.H, "includes")).call(_.H, b)) {
                var d = nF[b];
                if (d) {
                    var e = b + "_hostpage_library";
                    if (d = _.on(document, d)) d.id = e
                }
                c.m.push(b);
                e = new oF(b);
                c.hostpageLibraryTokens.push(e);
                c = Nm();
                c.hostpageLibraryTokens || (c.hostpageLibraryTokens = {});
                c.hostpageLibraryTokens[e.g] = e.m
            }
            c = void 0;
            e = this.Sa;
            d = this.slotId;
            e.g[b] = null != (c = e.g[b]) ? c : new _.v.Set;
            e.g[b].add(d)
        }
    };
    var Ip = 0;
    var st = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.A = b;
        this.F = Y(this, c);
        this.o = W(this, d);
        this.j = W(this, e);
        this.B = W(this, f)
    };
    _.T(st, Z);
    st.prototype.g = function() {
        var a = this,
            b = this.F.value,
            c, d = null == b ? void 0 : null == (c = _.R(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = _.R(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.o.value;
            c = this.j.value;
            var f = this.B.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                m = Kp(e.id + "_top", d),
                n = Kp(e.id + "_bottom", b);
            _.Yi(n, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(m);
            f.appendChild(n);
            _.Yi(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.Yi(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.Yi(f, {
                position: "relative",
                display: (null == (p = this.A.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            zn(this, 722, this.A, "orientationchange", function() {
                var r;
                (null == (r = a.A.screen.orientation) ? 0 : r.angle) ? _.Yi(f, {
                    display: "none"
                }): _.Yi(f, {
                    display: "block"
                })
            });
            _.yn(this, function() {
                _.kz(m);
                _.kz(n);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var ML = _.tu(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        et = function(a, b, c, d, e) {
            Z.call(this, a, 1007);
            this.B = Y(this, b);
            this.j = W(this, d);
            c && (this.o = W(this, c));
            e && nG(this, e)
        };
    _.T(et, Z);
    et.prototype.g = function() {
        if (Uf(this.j.value)) {
            var a;
            if (null == (a = this.o) || !a.value) {
                var b = this.B.value;
                if (null != b && b.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
                    a = document.createElement("iframe");
                    b = Xa(ML, encodeURIComponent(b.join()));
                    a.removeAttribute("srcdoc");
                    if (b instanceof _.kv) throw new fw("TrustedResourceUrl", 3);
                    var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
                    a.setAttribute("sandbox", "");
                    for (var d = 0; d < c.length; d++) a.sandbox.supports && !a.sandbox.supports(c[d]) || a.sandbox.add(c[d]);
                    b = _.ab(b);
                    void 0 !== b && (a.src = b);
                    a.id = "koelBirdIGRegisterIframe";
                    document.head.appendChild(a)
                }
            }
        }
    };
    var Us = function(a, b) {
        Z.call(this, a, 1176);
        this.o = b;
        this.j = V(this)
    };
    _.T(Us, Z);
    Us.prototype.g = function() {
        var a, b = this.j,
            c = b.Aa,
            d = null != (a = this.o) ? a : new Vs;
        a = null != Mp(d, 2) ? null != Np(d) && 0 !== (0, _.Tn)() ? Mp(d, 2) * Np(d) : Mp(d, 2) : null;
        c.call(b, a)
    };
    var $s = function(a, b, c, d, e, f) {
        f = void 0 === f ? Lp : f;
        Z.call(this, a, 666);
        this.o = f;
        this.output = lG(this);
        nG(this, b);
        e && nG(this, e);
        this.j = W(this, c);
        this.B = Y(this, d)
    };
    _.T($s, Z);
    $s.prototype.g = function() {
        var a = this.B.value,
            b = this.j.value;
        null == a || 0 > a || !Pi(b) ? this.output.notify() : NL(this, a, b)
    };
    var NL = function(a, b, c) {
        var d = a.o(b, Lh(a.context, 291, function(e, f) {
            e = _.z(e);
            for (var g = e.next(); !g.done; g = e.next())
                if (g = g.value, !(0 >= g.intersectionRatio)) {
                    f.unobserve(g.target);
                    a.output.notify();
                    break
                }
        }));
        d ? (d.observe(c), _.yn(a, function() {
            d.disconnect()
        })) : a.output.notify()
    };
    var Zs = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.dd = c;
        this.K = d;
        this.output = lG(this);
        this.o = W(this, e);
        this.j = Y(this, f);
        g && nG(this, g)
    };
    _.T(Zs, Z);
    Zs.prototype.g = function() {
        var a = this,
            b, c = null != (b = this.j.value) ? b : 0;
        if (0 !== (0, _.Tn)() || 0 < c)
            if (b = AF(document), BF(document) && b && (0 < II(this.K, this.slotId) || !OL(this)) && b) {
                var d = zn(this, 324, document, b, function() {
                    BF(document) || (d && d(), a.output.notify())
                });
                if (d) return
            }
        this.output.notify()
    };
    var OL = function(a) {
        try {
            var b = top;
            if (!b) return !0;
            var c = vt(b.document, b).y,
                d = c + a.dd.height,
                e = a.o.value;
            return e.y >= c && e.y <= d
        } catch (f) {
            return !0
        }
    };
    var Ys = function(a, b) {
        Z.call(this, a, 676);
        this.output = V(this);
        this.j = W(this, b)
    };
    _.T(Ys, Z);
    Ys.prototype.g = function() {
        var a = vi(this.j.value);
        this.output.D(a)
    };
    var Op = function(a, b, c, d, e, f) {
        f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        Z.call(this, a, 886);
        this.X = b;
        this.K = c;
        this.o = d;
        this.j = f;
        this.output = lG(this);
        e && nG(this, e)
    };
    _.T(Op, Z);
    Op.prototype.g = function() {
        this.X.some(function(a) {
            return !Pi(Li(a))
        }) ? this.output.notify() : cG(this.output, PL(this, this.o))
    };
    var PL = function(a, b) {
        return new _.v.Promise(function(c) {
            if (a.j) {
                for (var d = new a.j(function(h, k) {
                        h.some(function(l) {
                            return 0 < l.intersectionRatio
                        }) && (k.disconnect(), c())
                    }, {
                        rootMargin: b + "%"
                    }), e = _.z(a.X), f = e.next(), g = {}; !f.done; g = {
                        Ud: g.Ud
                    }, f = e.next()) {
                    f = f.value;
                    g.Ud = Li(f);
                    if (!g.Ud) return;
                    d.observe(g.Ud);
                    DI(a.K, f, function(h) {
                        return function() {
                            return void d.unobserve(h.Ud)
                        }
                    }(g))
                }
                _.yn(a, function() {
                    return void d.disconnect()
                })
            } else c()
        })
    };
    var QL = [{
            name: "Interstitial",
            format: 1,
            Ld: 5
        }, {
            name: "TopAnchor",
            format: 2,
            Ld: 2
        }, {
            name: "BottomAnchor",
            format: 3,
            Ld: 3
        }, {
            name: "LeftSideRail",
            format: 4,
            Ld: 8
        }, {
            name: "RightSideRail",
            format: 5,
            Ld: 9
        }],
        RL = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 789);
            this.U = b;
            this.googletag = c;
            this.o = d;
            this.j = e;
            this.P = f;
            this.B = g;
            this.output = V(this)
        };
    _.T(RL, Z);
    RL.prototype.g = function() {
        var a = this;
        QL.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.B)
        }).forEach(function(b) {
            var c = b.name;
            b = b.Ld;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            c = new yL(a.context, a.U, "/22639388115/example/" + c.toLowerCase(), b, !1, a.googletag.pubads(), function(f) {
                return void a.googletag.display(f)
            }, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, a.googletag.cmd, a.j.g, a.j, a.o, a.P, !1);
            _.S(a, c);
            Yj(c)
        })
    };
    var SL = function(a, b, c) {
        Z.call(this, a, 1163);
        _.G(ht);
        this.j = W(this, b);
        c && nG(this, c)
    };
    _.T(SL, Z);
    SL.prototype.g = function() {
        this.j.value.nj();
        this.j.value.Da()
    };
    var kt = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 682);
        this.K = b;
        this.format = c;
        this.slotId = d;
        this.A = e;
        this.o = V(this);
        this.j = Y(this, f);
        this.B = W(this, g);
        this.M = W(this, h);
        this.F = Y(this, k);
        this.I = W(this, l)
    };
    _.T(kt, Z);
    kt.prototype.g = function() {
        var a = this,
            b;
        if (null != (b = this.j.value) && _.N(b, 12, !1)) {
            b = this.F.value.qk;
            var c = _.np(this.K, this.slotId),
                d = this.M.value,
                e = this.B.value;
            _.Yi(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (TL) TL.lj(e, this.I.value);
            else {
                TL = new b(this.context, this.format, e, this.A, d, this.K, this.slotId);
                b = {};
                d = _.z(_.gi(this.j.value, gy, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[_.Gj(f, 1)] = _.Gj(f, 2);
                TL.mj(b);
                _.G(ht) ? (TL.tm(), this.o.D(TL)) : TL.Da();
                CI(this.K, this.slotId, function() {
                    TL && (TL.ua(), TL = null);
                    c && _.GI(a.K, a.slotId)
                })
            }
            _.yn(this, function() {
                return _.kz(e)
            })
        }
    };
    var TL = null;
    var jt = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1155);
        this.K = b;
        this.format = c;
        this.slotId = d;
        this.A = e;
        this.Xf = f;
        this.o = g;
        this.F = h;
        this.B = k;
        this.I = l;
        this.j = Y(this, f)
    };
    _.T(jt, Z);
    jt.prototype.g = function() {
        var a;
        if (null != (a = this.j.value) && null != Yl(a, 12)) {
            a = new Pj;
            _.S(this, a);
            var b, c = (null == (b = this.j.value) ? 0 : _.N(b, 15)) ? O(a, new Qp(this.context, this.slotId, Rp, function(d) {
                d = d.detail.data;
                try {
                    var e = JSON.parse(d);
                    return "floating" === e.type && "loaded" === e.message
                } catch (f) {}
                return !1
            })).output : void 0;
            b = new kt(this.context, this.K, this.format, this.slotId, this.A, this.Xf, this.o, this.F, this.B, this.I);
            O(a, b);
            b = new SL(this.context, b.o, c);
            O(a, b);
            Yj(a)
        }
    };
    var Xp = function(a, b, c) {
        Z.call(this, a, 1150);
        this.A = b;
        this.output = lG(this);
        nG(this, c)
    };
    _.T(Xp, Z);
    Xp.prototype.g = function() {
        var a = this;
        this.A.location.hash = "goog_game_inter";
        _.yn(this, function() {
            "goog_game_inter" === a.A.location.hash && (a.A.location.hash = "")
        });
        cG(this.output, new _.v.Promise(function(b) {
            return void zn(a, a.id, a.A, "hashchange", function(c) {
                rv(c.oldURL, "#goog_game_inter") && b()
            })
        }))
    };
    var UL = function(a, b) {
            this.serviceName = b;
            this.slot = a.g
        },
        VL = function(a, b) {
            UL.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.T(VL, UL);
    var WL = function() {
        UL.apply(this, arguments)
    };
    _.T(WL, UL);
    var XL = function(a, b, c) {
        UL.call(this, a, b);
        this.inViewPercentage = c
    };
    _.T(XL, UL);
    var YL = function() {
        UL.apply(this, arguments)
    };
    _.T(YL, UL);
    var ZL = function() {
        UL.apply(this, arguments)
    };
    _.T(ZL, UL);
    var $L = function() {
        UL.apply(this, arguments)
    };
    _.T($L, UL);
    var aM = function() {
        UL.apply(this, arguments)
    };
    _.T(aM, UL);
    var bM = function(a, b, c, d) {
        UL.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.T(bM, UL);
    var cM = function(a, b, c) {
        UL.call(this, a, b);
        this.payload = c
    };
    _.T(cM, UL);
    var dM = function() {
        UL.apply(this, arguments)
    };
    _.T(dM, UL);
    var eM = function(a, b, c) {
        UL.call(this, a, b);
        this.makeGameManualInterstitialVisible = c
    };
    _.T(eM, UL);
    var fM = function() {
        UL.apply(this, arguments)
    };
    _.T(fM, UL);
    var Yp = function(a, b, c, d, e, f) {
        Z.call(this, a, 1151);
        this.slotId = b;
        this.ra = c;
        nG(this, d);
        a = [e];
        f && a.push(f);
        f = new dG(a, !0);
        gG(this.v, f)
    };
    _.T(Yp, Z);
    Yp.prototype.g = function() {
        Mr(this.ra, "gameManualInterstitialSlotClosed", 1148, new fM(this.slotId, "publisher_ads"))
    };
    var Vp = function(a, b, c, d) {
        Z.call(this, a, 1149);
        this.slotId = b;
        this.ra = c;
        this.output = lG(this);
        nG(this, d)
    };
    _.T(Vp, Z);
    Vp.prototype.g = function() {
        var a = new _.pg,
            b = a.promise;
        Mr(this.ra, "gameManualInterstitialSlotReady", 1147, new eM(this.slotId, "publisher_ads", a.resolve));
        0 < _.$e(PB) ? cG(this.output, b.then(function() {
            return Oz(_.$e(PB))
        })) : cG(this.output, b)
    };
    var Up = function(a, b, c) {
        c = void 0 === c ? gM : c;
        Z.call(this, a, 1158);
        this.j = c;
        this.o = 1E3 * _.$e(Tp);
        this.output = lG(this);
        nG(this, b)
    };
    _.T(Up, Z);
    Up.prototype.g = function() {
        var a = this;
        this.j.Ze++ ? cG(this.output, Oz(this.o * (this.j.Ze - 2) + (this.o - (Date.now() - this.j.ig))).then(function() {
            a.j.ig = Date.now();
            a.j.Ze--
        })) : (this.j.ig = Date.now(), Oz(this.o).then(function() {
            return void a.j.Ze--
        }), this.output.notify())
    };
    var gM = {
        Ze: 0,
        ig: Date.now()
    };
    var hM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        iM = {
            width: "100%",
            height: "100%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        Wp = function(a, b, c, d, e) {
            Z.call(this, a, 1150);
            this.A = b;
            this.j = W(this, c);
            this.B = W(this, d);
            nG(this, e);
            this.o = new _.zG(this.A)
        };
    _.T(Wp, Z);
    Wp.prototype.g = function() {
        var a = 0 === (0, _.Tn)() ? "rgba(1,1,1,0.5)" : "white";
        _.Yi(this.j.value, _.A(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.Tn)() ? iM : hM));
        _.Yi(this.B.value, _.A(Object, "assign").call(Object, {
            "background-color": a,
            opacity: "1",
            position: "fixed",
            margin: "0",
            padding: "0",
            "z-index": "2147483647",
            display: "block"
        }, hM));
        _.yn(this, _.MG(this.A.document, this.A));
        a = {};
        nz(this.j.value).postMessage(JSON.stringify((a.googMsgType = "sth", a.msg_type = "i-view", a)), "*");
        if (this.A === this.A.top) {
            var b = _.BG(this.o, 2147483646);
            _.FG(b);
            _.yn(this, function() {
                return void _.GG(b)
            })
        }
    };
    var jM = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.M = c;
        this.o = d;
        this.j = V(this);
        this.B = W(this, e);
        this.T = W(this, f);
        this.F = Y(this, g);
        this.I = Y(this, h)
    };
    _.T(jM, Z);
    jM.prototype.g = function() {
        var a = this,
            b = this.T.value,
            c = this.B.value,
            d = this.I.value.Jk,
            e = new _.XG(this.context),
            f = null != fi(this.o, 14) ? 60 * Lr(this.o, 14) : 604800;
        b = new d(this.context, window, c, b, e, this.M, kM(this), new _.v.Set(be(this.o, 15, Oc, 2)), vL(this.slotId), function() {
            return void a.ua()
        }, f, this.F.value);
        b.I();
        _.S(this, b);
        this.j.D(b)
    };
    var kM = function(a) {
        var b = {};
        a = _.gi(a.o, gy, 13);
        a = _.z(a);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[_.Gj(c, 1)] = _.Gj(c, 2);
        return b
    };
    var lM = function(a, b, c, d) {
        Z.call(this, a, 1210);
        this.action = b;
        this.j = Y(this, c);
        nG(this, d)
    };
    _.T(lM, Z);
    lM.prototype.g = function() {
        var a;
        null != (a = this.j.value) && a.Pa() && this.action()
    };
    var mM = function() {
        this.Vj = 1E3
    };
    mM.prototype.send = function(a, b) {
        a.Ki(b)
    };
    var nM = function(a, b, c) {
        Z.call(this, a, 1121);
        this.U = b;
        this.output = lG(this);
        this.B = !1;
        this.F = W(this, c)
    };
    _.T(nM, Z);
    nM.prototype.g = function() {
        var a = this;
        if (this.o = aq(Lh(this.context, this.id, function(b) {
                b = _.z(b);
                for (var c = b.next(); !c.done; c = b.next()) c = 100 * c.value.intersectionRatio, _.A(Number, "isFinite").call(Number, c) && 50 <= c ? a.j || (a.B = !0, BF(a.U) || oM(a)) : (a.B = !1, pM(a))
            }))) _.yn(this, function() {
            var b;
            null == (b = a.o) || b.disconnect();
            pM(a)
        }), this.o.observe(this.F.value), this.I = zn(this, this.id, this.U, "visibilitychange", function() {
            BF(a.U) ? pM(a) : a.B && !a.j && oM(a)
        })
    };
    var oM = function(a) {
            a.j = setTimeout(function() {
                a.j = void 0;
                if (!BF(a.U)) {
                    a.output.notify();
                    var b;
                    null == (b = a.o) || b.disconnect();
                    var c;
                    null == (c = a.I) || c.call(a)
                }
            }, 1E3)
        },
        pM = function(a) {
            clearTimeout(a.j);
            a.j = void 0
        };
    var lt = function(a, b, c, d, e, f, g, h, k, l, m) {
        m = void 0 === m ? function() {
            return _.Zg()
        } : m;
        Z.call(this, a, 1141);
        this.slotId = b;
        this.I = c;
        this.U = e;
        this.j = f;
        this.M = g;
        this.rb = h;
        this.F = k;
        this.B = l;
        this.Xc = m;
        this.output = V(this);
        this.o = Y(this, d)
    };
    _.T(lt, Z);
    lt.prototype.g = function() {
        var a = this;
        if (this.o.value) {
            var b = new Pj;
            _.S(this, b);
            var c = O(b, new jM(this.context, this.slotId, this.I, this.o.value, this.j, this.M, this.rb, this.F));
            _.yn(c, function() {
                return void a.ua()
            });
            this.output.Ka(c.j.promise.then(function() {
                return !0
            }));
            if (_.G(KB) || _.$e(LB)) {
                var d = O(b, new nM(this.context, this.U, this.j));
                _.$e(LB) && O(b, new lM(this.context, function() {
                    $p(a.context, {
                        Vc: _.$e(LB),
                        payload: function() {
                            var e = new XA,
                                f = a.Xc();
                            null !== f && _.Wo(e, 1, f);
                            return YA(e)
                        }
                    })
                }, c.j, d.output));
                _.G(KB) && O(b, new lM(this.context, function() {
                    $p(a.context, {
                        Vc: 1,
                        payload: function() {
                            var e = new XA,
                                f = a.Xc();
                            null !== f && _.Wo(e, 1, f);
                            Lj(e, 2, !0);
                            return YA(e)
                        }
                    });
                    a.B()
                }, c.j, d.output))
            }
            Yj(b)
        } else this.output.D(!1)
    };
    var qM = function(a) {
        this.module = a
    };
    qM.prototype.toString = function() {
        return String(this.module)
    };
    _.rM = new qM(2);
    _.sM = new qM(5);
    _.tM = new qM(6);
    var dt = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.B = b;
        this.format = c;
        this.output = V(this);
        this.j = Y(this, d);
        this.o = Y(this, e);
        f && nG(this, f)
    };
    _.T(dt, Z);
    dt.prototype.g = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.j.value) || !_.N(a, 12, !1));
        a = 5 === this.format && this.o.value;
        b || a ? this.output.Ka(this.B.load(_.rM)) : this.output.Z()
    };
    var uM = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.O = b;
        this.j = c;
        this.output = lG(this);
        this.o = W(this, d);
        nG(this, e)
    };
    _.T(uM, Z);
    uM.prototype.g = function() {
        for (var a = _.z(this.o.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            b = null == (c = this.O.R[b.value.getDomId()]) ? void 0 : Qs(c);
            if (2 === b || 3 === b || 5 === b) {
                this.j.load(_.rM);
                return
            }
        }
        this.output.notify()
    };
    var vM = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.ra = c;
        nG(this, d);
        pG(this, [e, f])
    };
    _.T(vM, Z);
    vM.prototype.g = function() {
        Mr(this.ra, "rewardedSlotClosed", 703, new dM(this.slotId, "publisher_ads"))
    };
    var wM = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.ra = c;
        nG(this, d);
        this.j = Y(this, e)
    };
    _.T(wM, Z);
    wM.prototype.g = function() {
        var a, b = null == (a = this.j.value) ? void 0 : a.payload;
        Mr(this.ra, "rewardedSlotGranted", 702, new cM(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var xM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        yM = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.A = b;
            this.F = f;
            this.output = lG(this);
            this.o = W(this, c);
            this.B = W(this, d);
            nG(this, e);
            this.j = new _.zG(this.A)
        };
    _.T(yM, Z);
    yM.prototype.g = function() {
        var a = this;
        if (!this.F.yb) {
            var b = 0 === (0, _.Tn)() ? "rgba(1,1,1,0.5)" : "white";
            _.Yi(this.B.value, _.A(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, xM));
            _.yn(this, _.MG(this.A.document, this.A));
            nz(this.o.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.A === this.A.top) {
                this.A.location.hash = "goog_rewarded";
                var c = _.BG(this.j, 2147483646);
                _.FG(c);
                _.yn(this, function() {
                    _.GG(c);
                    "goog_rewarded" === a.A.location.hash && (a.A.location.hash = "")
                })
            }
            this.output.notify()
        }
    };
    var zM = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.A = b;
        this.j = W(this, c);
        nG(this, d)
    };
    _.T(zM, Z);
    zM.prototype.g = function() {
        if (this.A === this.A.top) var a = nz(this.j.value),
            b = zn(this, 503, this.A, "hashchange", function(c) {
                rv(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var AM = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.ra = c;
        this.output = lG(this);
        this.j = W(this, d)
    };
    _.T(AM, Z);
    AM.prototype.g = function() {
        var a = this.j.value,
            b = new _.pg,
            c = b.promise,
            d;
        Mr(this.ra, "rewardedSlotReady", 701, new bM(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        cG(this.output, c)
    };
    var BM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        CM = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        DM = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.B = V(this);
            this.o = lG(this);
            this.F = W(this, c);
            this.j = pG(this, [d, e])
        };
    _.T(DM, Z);
    DM.prototype.g = function() {
        if ("ha_before_make_visible" === this.j.value.message) this.o.notify();
        else {
            var a = _.G(OB) ? BM : CM;
            _.Yi(this.F.value, _.A(Object, "assign").call(Object, {
                position: "absolute"
            }, 0 === (0, _.Tn)() ? a : BM));
            this.B.D(this.j.value)
        }
    };
    var mt = function(a, b, c, d, e, f) {
        Pj.call(this);
        var g = cq(b, "granted", a);
        O(this, g);
        var h = cq(b, "prefetched", a);
        O(this, h);
        var k = cq(b, "closed", a);
        O(this, k);
        var l = cq(b, "ha_before_make_visible", a);
        O(this, l);
        var m = new DM(a, b, e, h.output, l.output);
        O(this, m);
        h = new AM(a, b, c, m.B);
        O(this, h);
        f = new yM(a, d, e, f, h.output, m.o);
        O(this, f);
        O(this, new zM(a, d, e, f.output));
        O(this, new wM(a, b, c, h.output, g.output));
        O(this, new vM(a, b, c, h.output, k.output, l.output))
    };
    _.T(mt, Pj);
    var Es = function(a, b) {
        Z.call(this, a, 1031);
        this.A = b
    };
    _.T(Es, Z);
    Es.prototype.g = function() {
        this.A === this.A.top && Qk(this.A)
    };
    var Cs = function(a, b, c) {
        c = void 0 === c ? tg : c;
        Z.call(this, a, 1063);
        this.A = b;
        this.o = c;
        this.j = V(this)
    };
    _.T(Cs, Z);
    Cs.prototype.g = function() {
        var a = this;
        if (_.G(DB) && ug(this.A)) {
            var b = null,
                c = 0,
                d = Lh(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.nb(function(l) {
                        switch (l.g) {
                            case 1:
                                return f = a.o(a.A), g = "0", l.l = 2, l.yield(f, 4);
                            case 4:
                                g = null != (h = l.m) ? h : "0";
                                1E4 < g.length && (Ph(a.context, a.id, new Lm("ML:" + g.length)), g = "0");
                                l.g = 3;
                                l.l = 0;
                                break;
                            case 2:
                                k = pb(l), Ph(a.context, a.id, k);
                            case 3:
                                b = g, c = _.Yg(a.A) + 3E5, l.g = 0
                        }
                    })
                });
            var e = (_.H = d(), _.A(_.H, "finally")).call(_.H, function() {
                e = void 0
            });
            this.j.D(function() {
                var f, g;
                return _.nb(function(h) {
                    if (1 == h.g) {
                        f = _.Yg(a.A) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.g = 2;
                            return
                        }
                        e || (e = (_.H = d(), _.A(_.H, "finally")).call(_.H, function() {
                            e = void 0
                        }));
                        return h.yield(e, 2)
                    }
                    return h.return(b)
                })
            })
        } else this.j.D(function() {
            return _.v.Promise.resolve("")
        })
    };
    Cs.prototype.l = function() {
        this.j.D(function() {
            return _.v.Promise.resolve("")
        })
    };
    var EM = function(a, b) {
        Z.call(this, a, 1091);
        this.output = V(this);
        b && (this.j = Y(this, b))
    };
    _.T(EM, Z);
    EM.prototype.g = function() {
        var a;
        null != (a = this.j) && a.value ? this.output.Ka(this.j.value()) : this.output.D("")
    };
    EM.prototype.l = function() {
        this.output.D("")
    };
    var qq = new _.v.Set(["disablePersonalization"]);
    var tq = function(a, b, c) {
        Z.call(this, a, 1122);
        this.U = b;
        this.j = c;
        lG(this, c)
    };
    _.T(tq, Z);
    tq.prototype.g = function() {
        var a = this,
            b = Hh(this.context);
        cG(this.j, new _.v.Promise(function(c) {
            return void DF(function() {
                c();
                b()
            }, a.U)
        }))
    };
    var Fs = function(a, b, c) {
        Z.call(this, a, 1107);
        this.A = b;
        this.j = c;
        V(this, c)
    };
    _.T(Fs, Z);
    Fs.prototype.g = function() {
        var a = dg(this.A.isSecureContext, this.A.navigator, this.A.document),
            b = eg(this.A.isSecureContext, this.A.document),
            c = fg(this.A.isSecureContext, this.A, this.A.document),
            d = !(!this.A.isSecureContext || !cg("attribution-reporting", this.A.document)),
            e = 0;
        a && (e |= 1);
        b && (e |= 4);
        c && (e |= 8);
        d && (e |= 2);
        this.j.Aa(0 === e ? null : e)
    };
    Fs.prototype.l = function() {
        this.j.Z()
    };
    var FM = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1118, _.$e(WB));
        this.B = b;
        this.F = d;
        this.R = e;
        V(this, d);
        c && (this.I = Y(this, c));
        f && (this.o = W(this, f));
        g && (this.j = mG(this, g))
    };
    _.T(FM, Z);
    FM.prototype.g = function() {
        var a = new QF;
        a = _.me(a, 1, _.Sc(this.B), 0);
        if (this.j)
            if (this.j.value) {
                var b = _.uh(a, 3, this.j.value.label);
                _.I(b, 4, this.j.value.status)
            } else this.j.yb() || _.I(a, 4, 5);
        if (this.B & 1) {
            var c, d;
            b = GM(this, null != (d = null == (c = this.I) ? void 0 : c.value) ? d : null);
            _.wh(a, 2, b)
        }
        this.F.D(a)
    };
    var GM = function(a, b) {
            switch (_.$e(Gs)) {
                case 1:
                    var c = 1;
                    break;
                case 2:
                    c = 2;
                    break;
                case 3:
                    c = 3;
                    break;
                default:
                    c = 0
            }
            var d = PF(new OF, c);
            null == b || b.forEach(function(g, h) {
                var k = ke(d, 2, NF);
                var l = k.set,
                    m = new NF;
                g = _.le(m, 1, g, Rc);
                l.call(k, h, g)
            });
            var e;
            if ((null == (e = a.o) ? 0 : e.value) && a.R) {
                var f;
                b = _.z(null == (f = a.o) ? void 0 : f.value);
                for (f = b.next(); !f.done; f = b.next()) f = f.value, (c = HM(a, a.R[f.getDomId()])) && ke(d, 3, LF).set(f.getAdUnitPath(), c)
            }
            return d
        },
        HM = function(a, b) {
            a = Sm(a.context, b);
            if (0 !== a.length) return MF(new LF, a.map(function(c) {
                return c.seller
            }))
        };
    var vq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1165);
        this.F = c;
        this.ef = d;
        this.R = e;
        this.B = f;
        this.o = g;
        this.j = Y(this, b.wi)
    };
    _.T(vq, Z);
    vq.prototype.g = function() {
        if (this.j.value) {
            var a = new Pj,
                b = new FM(this.context, this.j.value, this.F, this.ef.Dg, this.R, this.B, this.o);
            O(a, b);
            Yj(a)
        } else this.ef.Dg.Z()
    };
    var IM = function(a, b, c) {
        Z.call(this, a, 1206);
        this.o = b;
        this.j = V(this);
        this.V = W(this, c)
    };
    _.T(IM, Z);
    IM.prototype.g = function() {
        var a = this;
        this.o.cookieDeprecationLabel ? Uf(this.V.value) ? this.j.Ka(this.o.cookieDeprecationLabel.getValue().then(function(b) {
            return {
                status: 1,
                label: b
            }
        }).catch(function(b) {
            a.H(b);
            return {
                status: 2
            }
        })) : this.j.D({
            status: 4
        }) : this.j.D({
            status: 3
        })
    };
    var JM = function(a, b) {
        Z.call(this, a, 1213, _.$e(WB));
        this.j = V(this);
        b && (this.o = mG(this, b))
    };
    _.T(JM, Z);
    JM.prototype.g = function() {
        var a, b, c;
        (null == (c = null == (a = this.o) ? void 0 : null == (b = a.value) ? void 0 : b.label) ? 0 : c.match(af(VB))) ? this.j.D(!0): this.j.D(!1)
    };
    var KM = function(a, b) {
        Z.call(this, a, 1212, _.$e(WB));
        this.j = V(this);
        this.o = V(this);
        b && (this.B = mG(this, b))
    };
    _.T(KM, Z);
    KM.prototype.g = function() {
        var a, b, c = null == (a = this.B) ? void 0 : null == (b = a.value) ? void 0 : b.label;
        c ? (this.o.D(!0), c.match(af(VB)) ? this.j.D(!0) : this.j.D(!1)) : (this.j.D(!1), this.o.D(!1))
    };
    var LM = function(a, b, c) {
        Z.call(this, a, 873);
        this.A = b;
        this.j = W(this, c)
    };
    _.T(LM, Z);
    LM.prototype.g = function() {
        var a = this.context,
            b = this.j.value,
            c = this.A;
        !Nm()._pubconsole_disable_ && (b = Yf("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || hn(a, c))
    };
    var MM = function() {
        this.resources = {}
    };
    var Rq = "3rd party ad content";
    var NM = function(a, b, c) {
        _.U.call(this);
        this.context = a;
        this.ib = b;
        this.l = c;
        a = c.slotId;
        b = c.size;
        this.g = "height" === c.rk ? "fluid" : [b.width, b.height];
        this.yd = Si(a);
        this.zd = Rq
    };
    _.T(NM, _.U);
    NM.prototype.render = function() {
        var a = this.ib,
            b = this.l,
            c = b.slotId,
            d = b.O.R,
            e = b.size,
            f = b.Tf,
            g = b.isBackfill,
            h = b.ae;
        Bg(b.Oi, _.hz(b.U), null != f ? f : "", !1);
        Kr(_.Ye(Nh), "5", Lr(d[c.getDomId()], 20));
        Mr(c, Nr, 801, {
            oh: 0 === a.kind ? a.vb : "",
            isBackfill: g
        });
        a = this.j();
        h && a && a.setAttribute("data-google-container-id", h);
        Mr(c, Or, 825, {
            size: e,
            isEmpty: !1
        });
        return a
    };
    NM.prototype.loaded = function(a) {
        var b = this.l,
            c = b.slotId,
            d = b.ra;
        b = b.O.R;
        Mr(c, Is, 844);
        a && a.setAttribute("data-load-complete", !0);
        Mr(d, "slotOnload", 710, new YL(c, "publisher_ads"));
        Kr(_.Ye(Nh), "6", Lr(b[c.getDomId()], 20))
    };
    var OM = function(a) {
        a = a.ib;
        a = 0 === a.kind ? a.vb : "";
        var b = "";
        b = void 0 === b ? "" : b;
        if (a) {
            var c = a.toLowerCase();
            a = -1 < c.indexOf("<!doctype") || -1 < c.indexOf("<html") || _.G(Uy) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>"
        }
        return a
    };
    NM.prototype.m = function() {
        _.U.prototype.m.call(this);
        this.l.Oi.removeAttribute("data-google-query-id")
    };
    NM.prototype.G = function(a) {
        var b = this,
            c = PM(this, function() {
                return void b.loaded(c.g)
            }, a);
        _.yn(this, function() {
            100 != c.status && (c.hg() && (DH(c.l), c.o = 0), window.clearTimeout(c.sa), c.sa = -1, c.H = 3, c.m && (c.m.ua(), c.m = null), _.Ef(window, "resize", c.B), _.Ef(window, "scroll", c.B), c.j && c.g && c.j == _.lz(c.g) && c.j.removeChild(c.g), c.g = null, c.j = null, c.status = 100)
        });
        return c
    };
    var PM = function(a, b, c) {
        var d = a.l,
            e = d.Hi,
            f = d.isBackfill,
            g = d.ae,
            h = d.Ae,
            k = d.zf,
            l = d.Sa,
            m = Array.isArray(a.g) ? new _.Di(Number(a.g[0]), Number(a.g[1])) : 1;
        return new LH({
            Bg: d.ih,
            yd: a.yd,
            zd: a.zd,
            content: OM(a),
            size: m,
            li: b,
            Ii: null != e ? e : void 0,
            permissions: {
                ye: null != Yl(c, 1) ? !!_.N(c, 1) : !f,
                ze: null != Yl(c, 2) ? !!_.N(c, 2) : !1
            },
            Bd: !!Nm().fifWin,
            Hl: eK ? eK : eK = Ll(),
            Gj: Pl(),
            hostpageLibraryTokens: l.hostpageLibraryTokens,
            lb: function(n, p) {
                return void Ph(a.context, n, p)
            },
            uniqueId: g,
            Gi: fH(),
            Ae: null != h ? h : void 0,
            mb: void 0,
            zf: null != k ? k : void 0
        })
    };
    var QM = function() {
        NM.apply(this, arguments)
    };
    _.T(QM, NM);
    QM.prototype.j = function() {
        var a = this.l,
            b = a.O,
            c = b.W;
        a = b.R[a.slotId.getDomId()];
        b = new Ql;
        c = Zl([b, c.kc(), null == a ? void 0 : a.kc()]);
        return NM.prototype.G.call(this, c).g
    };
    QM.prototype.v = function() {
        return !1
    };
    var Ws = function(a, b, c, d, e, f) {
        Z.call(this, a, 669);
        this.W = b;
        this.R = c;
        this.output = V(this);
        this.o = Y(this, d);
        this.j = W(this, e);
        f && (this.B = W(this, f))
    };
    _.T(Ws, Z);
    Ws.prototype.g = function() {
        var a;
        if (null == (a = this.B) ? 0 : a.value) this.output.D(!0);
        else {
            var b;
            a = !(null == (b = this.o.value) || !_.R(b, 1)) && (_.N(this.R, 12) || Yl(this.W, 13)) || this.j.value;
            this.output.D(!!a)
        }
    };
    var RM = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.j = b;
        this.A = c;
        this.output = lG(this);
        nG(this, d)
    };
    _.T(RM, Z);
    RM.prototype.g = function() {
        var a = this.j,
            b = this.A,
            c = fH();
        c = {
            version: eK ? eK : eK = Ll(),
            mf: c
        };
        c = SH.Sk(c);
        var d = yH(b);
        c = d ? _.ff(c, new _.v.Map([
            ["n", String(d)]
        ])) : c;
        d = bf(Nl);
        for (var e = new _.v.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
        c = _.ff(c, e);
        var g;
        a.resources[c.toString()] || (null == (g = Nm()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.rf("IFRAME"), a.src = _.jb(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)));
        this.output.notify()
    };
    var SM = function(a, b, c) {
        Z.call(this, a, 1135);
        this.o = b;
        this.B = c;
        this.j = V(this)
    };
    _.T(SM, Z);
    SM.prototype.g = function() {
        for (var a = new Mx, b = new _.v.Map, c = new _.v.Set, d = _.z(this.o), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (null != _.Gj(f, 1)) {
                e = new _.v.Set;
                b.set(_.R(f, 1).toString(), e);
                f = _.z(_.gi(f, Kx, 2));
                for (var g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    var h = _.R(g, 1);
                    e.add(h);
                    c.has(h) || Mj(a, 2, Kx, g);
                    c.add(h)
                }
            }
        }
        this.B.D(b);
        this.j.D(a)
    };
    var TM = function(a, b, c) {
        Z.call(this, a, 1051);
        this.o = b;
        this.j = Y(this, c)
    };
    _.T(TM, Z);
    TM.prototype.g = function() {
        var a = this;
        this.j.value && kk(this.j.value, function(b, c) {
            Ph(a.context, b, c);
            var d, e;
            null == (d = a.o) || null == (e = d.error) || e.call(d, c)
        })
    };
    var UM = function(a, b) {
        Z.call(this, a, 1040);
        this.j = V(this);
        this.o = Y(this, b)
    };
    _.T(UM, Z);
    UM.prototype.g = function() {
        var a = this.o.value;
        a ? (a = _.gi(a, Kx, 2), this.j.D(a.map(function(b) {
            var c = dx(b, Lx);
            b = _.R(b, 1);
            c = c && (_.A(c, "startsWith").call(c, location.protocol) || _.A(c, "startsWith").call(c, "data:") && 80 >= c.length) ? df(xj(c)) : void 0;
            return {
                pe: b,
                url: c
            }
        }))) : this.j.D([])
    };
    var VM = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.B = b;
        this.j = d;
        this.rb = e;
        c && (this.F = Y(this, c));
        e && (this.o = Y(this, e))
    };
    _.T(VM, Z);
    VM.prototype.g = function() {
        var a = this,
            b, c, d = null != (c = this.B) ? c : null == (b = this.F) ? void 0 : b.value,
            e, f;
        b = null != (f = this.j) ? f : null == (e = this.o) ? void 0 : e.value;
        if (null != d && d.length && b)
            for (d = _.z(d), e = d.next(); !e.done; e = d.next()) f = e.value, e = f.pe, (f = f.url) && _.S(this, ok(e, f, b, this.rb, function(g, h) {
                Ph(a.context, g, h);
                var k, l;
                null == (l = (k = console).error) || l.call(k, h)
            }))
    };
    var WM = function(a, b, c) {
        Z.call(this, a, 1045);
        this.j = b;
        this.rb = c
    };
    _.T(WM, Z);
    WM.prototype.g = function() {
        var a = new Pj;
        _.S(this, a);
        var b = new UM(this.context, this.j);
        O(a, b);
        b = new VM(this.context, void 0, b.j, void 0, this.rb);
        O(a, b);
        Yj(a)
    };
    var Os = function(a, b, c, d) {
        Z.call(this, a, 706);
        this.A = b;
        this.output = null != d ? d : V(this);
        this.j = W(this, c)
    };
    _.T(Os, Z);
    Os.prototype.g = function() {
        this.output.Aa(Vf(this.j.value, this.A))
    };
    var XM = function(a, b, c, d) {
        Z.call(this, a, 1154);
        this.hb = c;
        this.j = d;
        this.o = Y(this, b)
    };
    _.T(XM, Z);
    XM.prototype.g = function() {
        if (this.o.value) {
            var a = new Pj;
            _.S(this, a);
            var b = new Os(this.context, window, this.hb, this.j.rb);
            O(a, b);
            b = new SM(this.context, this.o.value, this.j.ug);
            O(a, b);
            O(a, new WM(this.context, b.j, this.j.rb));
            b = new TM(this.context, console, this.j.rb);
            O(a, b);
            Yj(a)
        } else this.j.ug.Z(), this.j.rb.Z()
    };
    var YM = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.A = b;
        this.V = c;
        this.j = d;
        this.lc = e;
        this.o = Y(this, f)
    };
    _.T(YM, Z);
    YM.prototype.g = function() {
        var a, b = null == (a = this.o.value) ? void 0 : a.sj;
        b && b(this.j, this.V, this.A, this.lc, this.context.Ga)
    };
    var ZM = function(a, b) {
        Z.call(this, a, 1095);
        this.j = b;
        this.output = V(this)
    };
    _.T(ZM, Z);
    ZM.prototype.g = function() {
        this.output.Ka(this.j.load(_.sM))
    };
    var $M = function(a, b, c, d, e) {
        Z.call(this, a, 1090);
        this.j = b;
        this.lc = c;
        this.o = W(this, d);
        this.B = Y(this, e)
    };
    _.T($M, Z);
    $M.prototype.g = function() {
        var a = this.B.value,
            b;
        if (a && null != (b = _.di(a, _.ay, 1)) && _.gi(b, _.$x, 15).length) {
            b = new Pj;
            _.S(this, b);
            var c = new ZM(this.context, this.j);
            O(b, c);
            a = new YM(this.context, window, this.o.value, a, this.lc, c.output);
            O(b, a);
            Yj(b)
        }
    };
    var Wq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1205);
        this.A = b;
        this.I = c;
        this.F = W(this, d);
        this.o = W(this, e);
        this.j = W(this, f);
        this.B = W(this, g)
    };
    _.T(Wq, Z);
    Wq.prototype.g = function() {
        var a = this.F.value;
        a = new a.Tl(this.o.value, this.A, this.j.value, this.I, this.B.value, new _.XG(this.context), new a.pk(this.A));
        _.S(this, a);
        _.S(this, a.I)
    };
    var Vq = function(a, b) {
        Z.call(this, a, 1204);
        this.j = b;
        this.output = V(this)
    };
    _.T(Vq, Z);
    Vq.prototype.g = function() {
        this.output.Ka(this.j.load(_.tM))
    };
    var fs = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = Lh(a, 88, function(f, g) {
            var h;
            if (h = Dm(f)) h = g, h = Cm(h) || Array.isArray(h) && h.every(Cm);
            if (h) {
                if (_.G(fC)) {
                    var k = Zq(g);
                    h = k.size;
                    k.Hg && (g = Zk([f, g]), g = g.substring(1, g.length - 1), Q(b, new Yk(151, ["SizeMappingBuilder.addSize", g])), g = h)
                }
                d.push([f, g])
            } else e.push([f, g]), Q(b, $k("SizeMappingBuilder.addSize", [f, g]));
            return c
        });
        this.build = Lh(a, 89, function() {
            if (e.length) return Q(b, $I(Tl(e))), null;
            sa(d);
            return d
        })
    };
    var aN = function(a, b, c, d, e, f) {
        f = void 0 === f ? qk : f;
        Z.call(this, a, 939);
        this.o = b;
        this.A = c;
        this.V = d;
        this.j = f;
        this.output = lG(this);
        nG(this, e)
    };
    _.T(aN, Z);
    aN.prototype.g = function() {
        var a = this.j,
            b = this.A,
            c = new Eq;
        var d = new Dq;
        d = _.uh(d, 1, String(this.o));
        c = _.wh(c, 5, d);
        c = _.I(c, 4, 1);
        c = _.I(c, 2, 2);
        c = _.uh(c, 3, this.context.wb || this.context.ab);
        c = _.Ah(c, 6, Uf(this.V));
        a.call(this, b, c);
        this.output.notify()
    };
    var bt = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.A = b;
        this.output = lG(this);
        this.j = Y(this, c);
        this.o = W(this, d);
        e && nG(this, e)
    };
    _.T(bt, Z);
    bt.prototype.g = function() {
        var a = this.j.value;
        if (a && !this.o.value) {
            var b = Pz(this.A);
            mI(new lI(b, a)) || this.H(new Lm("Cannot create top window frame"))
        }
        this.output.notify()
    };
    var bN = function(a, b) {
        Z.call(this, a, 820);
        this.A = b;
        this.output = V(this)
    };
    _.T(bN, Z);
    bN.prototype.g = function() {
        var a = this;
        this.output.Ka(uk(this.A).then(function(b) {
            var c = b.te,
                d = b.status;
            ej("gpt_etu", function(e) {
                kj(e, a.context);
                lj(e, "rsn", d)
            }, c ? void 0 : 0);
            return null != c ? c : ""
        }))
    };
    var cN = function(a, b, c, d) {
        Z.call(this, a, 979);
        this.A = b;
        this.j = Y(this, d);
        this.output = c
    };
    _.T(cN, Z);
    cN.prototype.g = function() {
        var a = this;
        if (_.G(kC)) this.output.Z();
        else {
            var b;
            yk(this.A, null != (b = this.j.value) ? b : !1).then(function(c) {
                a.output.D(c)
            })
        }
    };
    cN.prototype.l = function() {
        this.output.Z()
    };
    var dN = function(a, b, c, d) {
        Z.call(this, a, 1156);
        this.A = b;
        this.qe = c;
        this.j = {
            Ac: new Cn
        };
        this.o = W(this, d)
    };
    _.T(dN, Z);
    dN.prototype.g = function() {
        if (Uf(this.o.value)) {
            var a = new Pj;
            _.S(this, a);
            var b = new cN(this.context, this.A, this.j.Ac, this.qe);
            O(a, b);
            Yj(a)
        } else this.j.Ac.Z()
    };
    var eN = function(a, b, c) {
        Z.call(this, a, 1123);
        this.j = b;
        this.o = c;
        V(this, b);
        V(this, c)
    };
    _.T(eN, Z);
    eN.prototype.g = function() {
        _.G(iC) ? (this.j.D(!1), this.o.Z()) : (this.j.D(!0), this.o.D(10))
    };
    var fN = function(a, b, c, d, e) {
        Z.call(this, a, 978);
        this.A = b;
        this.B = c;
        this.j = e;
        V(this, e);
        this.o = Y(this, d.Ac)
    };
    _.T(fN, Z);
    fN.prototype.g = function() {
        if (_.G(jC)) this.j.Z();
        else if (this.o.value) {
            var a = Hk(this.o.value, this.A, new _.XG(this.context), this.B);
            this.j.Ka(a)
        } else this.j.Z()
    };
    fN.prototype.l = function() {
        this.j.Z()
    };
    var dr = function(a, b, c, d, e, f) {
        Z.call(this, a, 1164);
        this.o = b;
        this.qf = c;
        this.j = e;
        this.B = W(this, d);
        f && (this.F = W(this, f))
    };
    _.T(dr, Z);
    dr.prototype.g = function() {
        var a = eg(window.isSecureContext, window.document),
            b;
        _.G(lC) && !a || (null == (b = this.F) ? 0 : b.value) ? (this.j.Zc.Z(), this.j.Xd.D(!1), this.j.Yd.Z()) : this.B.value ? (a = new Pj, _.S(this, a), O(a, new fN(this.context, window, this.o, this.qf, this.j.Zc)), b = new eN(this.context, this.j.Xd, this.j.Yd), O(a, b), Yj(a)) : (this.j.Zc.D(5), this.j.Xd.D(!1), this.j.Yd.D(5))
    };
    var gN = function(a, b, c) {
        Z.call(this, a, 1101);
        this.A = b;
        this.j = c
    };
    _.T(gN, Z);
    gN.prototype.g = function() {
        if (!_.G(jC)) {
            var a = this.j,
                b = vk(this.A);
            b.setTopicsCalled ? _.v.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var fr = function(a, b, c, d) {
        Z.call(this, a, 1180);
        this.A = b;
        this.o = Y(this, d);
        this.j = Y(this, c.Ac)
    };
    _.T(fr, Z);
    fr.prototype.g = function() {
        if (this.o.value && this.j.value) {
            var a = new Pj;
            _.S(this, a);
            O(a, new gN(this.context, this.A, this.j.value));
            Yj(a)
        }
    };
    var or = function(a) {
        this.C = _.B(a)
    };
    _.T(or, _.F);
    var kr = function(a, b) {
        return _.me(a, 2, null == b ? b : hd(b), "0")
    };
    var hN = function(a) {
        this.C = _.B(a)
    };
    _.T(hN, _.F);
    var nr = Te(hN);
    hN.aa = [1];
    var iN = function(a, b, c, d) {
        Z.call(this, a, 1186);
        this.K = b;
        this.A = c;
        this.output = V(this);
        this.V = W(this, d)
    };
    _.T(iN, Z);
    iN.prototype.g = function() {
        if (!dg(this.A.isSecureContext, this.A.navigator, this.A.document) || _.G(Qr)) this.output.Z();
        else {
            var a = this.K.Be;
            if (null !== a) this.output.D(a);
            else {
                var b = _.am(new _.iF(this.A), "__gpi", this.V.value);
                a = this.output;
                var c = a.D;
                b = _.hg(b || String(this.context.pvsid)) % 63001;
                this.K.Be = b;
                c.call(a, b)
            }
        }
    };
    var jN = function(a, b, c) {
        Z.call(this, a, 1171);
        this.j = c;
        V(this, c);
        this.Gg = W(this, b)
    };
    _.T(jN, Z);
    jN.prototype.g = function() {
        this.j.D(0 === this.Gg.value.kind)
    };
    var kN = function(a, b, c) {
        Z.call(this, a, 1160);
        this.j = c;
        V(this, c);
        this.o = W(this, b)
    };
    _.T(kN, Z);
    kN.prototype.g = function() {
        if (this.o.value.requestId) {
            var a = this.o.value.request,
                b = this.context.Ga,
                c = a.byteLength,
                d = void 0 === c ? 1 : c;
            c = SA("JanWw");
            var e = new PA;
            d = Ek(e, 4, QA, _.Fc(d));
            c = _.wh(c, 3, d);
            b.Lg(c);
            32768 < a.byteLength ? this.j.D({
                kind: 1,
                reason: 3
            }) : (a = Bb(a, 3), a.length ? this.j.D({
                kind: 0,
                signal: a,
                requestId: this.o.value.requestId
            }) : this.j.D({
                kind: 1,
                reason: 5
            }))
        } else this.j.D({
            kind: 1,
            reason: this.o.value
        })
    };
    kN.prototype.l = function() {
        this.j.D({
            kind: 1,
            reason: 4
        })
    };
    var lN = function(a, b) {
        Z.call(this, a, 1159);
        this.output = V(this);
        this.j = b
    };
    _.T(lN, Z);
    lN.prototype.g = function() {
        var a = this;
        this.output.Ka(this.j.getInterestGroupAdAuctionData({
            seller: "https://securepubads.g.doubleclick.net"
        }).catch(function(b) {
            a.H(b);
            return 4
        }))
    };
    lN.prototype.l = function() {
        this.output.D(4)
    };
    var sr = function(a, b, c, d, e, f) {
        Z.call(this, a, 1177);
        this.B = b;
        this.j = e;
        this.o = f;
        V(this, e);
        V(this, f);
        this.F = W(this, c);
        d && (this.I = W(this, d))
    };
    _.T(sr, Z);
    sr.prototype.g = function() {
        if (this.F.value) {
            var a;
            if (null == (a = this.I) ? 0 : a.value) this.j.D({
                kind: 1,
                reason: 6
            }), this.o.D(!1);
            else {
                a = new Pj;
                _.S(this, a);
                var b = new lN(this.context, this.B);
                O(a, b);
                b = new kN(this.context, b.output, this.j);
                O(a, b);
                b = new jN(this.context, this.j, this.o);
                O(a, b);
                Yj(a)
            }
        } else this.j.D({
            kind: 1,
            reason: 2
        }), this.o.D(!1)
    };
    var mN = function(a, b, c, d) {
        Z.call(this, a, 881);
        this.Ba = b;
        this.pa = c;
        this.j = d;
        this.output = V(this)
    };
    _.T(mN, Z);
    mN.prototype.g = function() {
        if (4 === _.$e(Gs)) {
            var a = _.di(this.pa, Cy, 23);
            if (a) {
                var b;
                if (0 !== (null == (b = this.j) ? void 0 : b.kind)) throw new TypeError("Received remote auction config despite " + (this.j ? "invalid" : "absent") + " remarketing input.");
                this.output.D({
                    seller: "https://securepubads.g.doubleclick.net",
                    interestGroupBuyers: _.xo(this.pa, 3, 2),
                    requestId: this.j.requestId,
                    serverResponse: Kk(Lk(a, 1)),
                    resolveToConfig: !_.N(this.pa, 14)
                })
            } else this.output.Z()
        } else {
            b = this.output;
            a = b.D;
            var c = this.pa,
                d = Sm(this.context, this.Ba),
                e = _.G(nC),
                f = _.G(uC),
                g = void 0 === e ? !1 : e;
            e = void 0 === f ? !1 : f;
            f = !_.N(c, 14) && !0;
            for (var h = {}, k = _.z(_.gi(c, Ay, 7)), l = k.next(); !l.done; l = k.next()) l = l.value, h[_.R(l, 1)] = JSON.parse(_.R(l, 2));
            if (k = _.di(c, zy, 6)) h["https://googleads.g.doubleclick.net"] = k.toJSON(), h["https://td.doubleclick.net"] = k.toJSON();
            l = {};
            k = _.z(_.gi(c, By, 11));
            for (var m = k.next(); !m.done; m = k.next()) m = m.value, l[_.R(m, 1)] = _.$w(m, 2);
            m = {};
            0 !== _.$w(c, 21) && (m["*"] = _.$w(c, 21));
            var n = {};
            Lr(c, 18) && (n["https://googleads.g.doubleclick.net"] = Lr(c, 18), n["https://td.doubleclick.net"] = Lr(c, 18));
            k = _.z(ke(c, 24, Gy));
            for (var p = k.next(); !p.done; p = k.next()) {
                var r = p.value;
                Lr(r[1], 4) && (p = r[0], r = Lr(r[1], 4), n[p] = r)
            }
            k = _.R(c, 1).split("/td/")[0];
            var w;
            p = null == (w = _.di(c, Ey, 5)) ? void 0 : _.Sd(w);
            var u;
            null != p && null != (u = _.di(p, Dy, 5)) && _.Gi(u, 2);
            w = _.A(Object, "assign").call(Object, {}, {
                seller: k,
                decisionLogicUrl: _.R(c, 1),
                trustedScoringSignalsUrl: _.R(c, 2),
                interestGroupBuyers: _.xo(c, 3, 2),
                sellerExperimentGroupId: Lr(c, 17),
                auctionSignals: JSON.parse(_.R(c, 4) || "{}"),
                sellerSignals: (null == p ? void 0 : p.toJSON()) || [],
                sellerTimeout: _.$w(c, 15) || 50,
                perBuyerExperimentGroupIds: n,
                perBuyerSignals: h,
                perBuyerTimeouts: l,
                perBuyerCumulativeTimeouts: m
            }, f ? {
                resolveToConfig: f
            } : {});
            if (null == c ? 0 : _.N(us(c, Ey, 5), 25)) w.sellerCurrency = "USD", w.perBuyerCurrencies = _.A(Object, "fromEntries").call(Object, je(c, 22, qd));
            _.R(c, 28) ? w.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (u = _.R(c, 19), w.directFromSellerSignals = "" !== u ? k + u : void 0);
            if (g) {
                var x;
                g = null == (x = _.di(c, Ey, 5)) ? void 0 : _.Sd(x)
            } else {
                g = new Ey;
                if (Mn(us(c, Ey, 5), Dy, 5)) {
                    x = g;
                    u = new Dy;
                    h = us(us(c, Ey, 5), Dy, 5);
                    var y = void 0 === y ? "0" : y;
                    y = qe(gd(mo(h, 2)), y);
                    y = _.me(u, 2, Yc(y), "0");
                    _.wh(x, 5, y)
                }
                us(c, Ey, 5).getEscapedQemQueryId() && (y = us(c, Ey, 5).getEscapedQemQueryId(), _.uh(g, 2, y))
            }
            if (e)
                if (_.N(c, 30)) {
                    if (null == d || !d.length) throw Error("top_td_without_component_auction");
                } else d = [w].concat(_.oh(null != d ? d : []));
            else d = [w].concat(_.oh(null != d ? d : []));
            var C;
            e = _.A(Object, "assign").call(Object, {}, {
                seller: k,
                decisionLogicUrl: _.R(c, 1),
                sellerExperimentGroupId: Lr(c, 17),
                sellerSignals: (null == (C = g) ? void 0 : C.toJSON()) || [],
                sellerTimeout: _.$w(c, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {},
                perBuyerCumulativeTimeouts: {},
                componentAuctions: d
            }, f ? {
                resolveToConfig: f
            } : {});
            _.R(c, 28) ? e.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (C = _.R(c, 19), e.directFromSellerSignals = "" !== C ? k + C : void 0);
            a.call(b, e)
        }
    };
    mN.prototype.l = function() {
        this.output.Z()
    };
    var nN = function(a, b, c, d) {
        Z.call(this, a, 1105);
        this.adUnitPath = b;
        this.pa = c;
        this.j = d
    };
    _.T(nN, Z);
    nN.prototype.g = function() {
        var a = _.xo(this.pa, 3, 2),
            b = hr(this.adUnitPath);
        if (_.N(this.pa, 20)) {
            if (_.G(sC)) {
                var c;
                var d = (null == (c = _.di(this.pa, Fy, 29)) ? void 0 : Lr(c, 2)) || 864E5
            } else d = 864E5;
            a = wr(a, Date.now() + d);
            c = (d = this.j.getItem(b)) ? _.gi(nr(d), or, 1) : [];
            var e;
            d = new hN;
            a = lr(c, a);
            a = _.ul(d, 1, a);
            d = !(null == (e = _.di(this.pa, Fy, 29)) || !_.N(e, 3));
            e = Lj(a, 2, d);
            this.j.setItem(b, Gk(e))
        } else _.G(qC) && this.j.removeItem(b)
    };
    var oN = function(a, b, c, d) {
        Z.call(this, a, 1174);
        var e = this;
        this.U = b;
        this.directFromSellerSignals = c;
        this.j = _.ev(function() {
            var f = (_.H = [].concat(_.oh(e.U.head.querySelectorAll("script[type=webbundle]"))), _.A(_.H, "find")).call(_.H, function(h) {
                var k;
                return null == (k = h.textContent) ? void 0 : k.match(e.directFromSellerSignals)
            });
            if (null != f && f.textContent) {
                var g = JSON.parse(f.textContent);
                g.resources = g.resources.filter(function(h) {
                    return !h.match(e.directFromSellerSignals)
                });
                f.remove();
                g.resources.length && (f = e.U.createElement("script"), f.type = "webbundle", ib(f, jf(g)), e.U.head.appendChild(f))
            }
        });
        nG(this, d);
        _.yn(this, function() {
            return setTimeout(function() {
                return void e.j()
            }, 5E3)
        })
    };
    _.T(oN, Z);
    oN.prototype.g = function() {
        this.j()
    };
    var pN = function(a, b, c) {
        Z.call(this, a, 1175);
        this.output = lG(this);
        nG(this, b);
        nG(this, c)
    };
    _.T(pN, Z);
    pN.prototype.g = function() {
        cG(this.output, Oz(5E3))
    };
    Lf({
        google_signals: Lf({
            buyer_reporting_id: Pf
        })
    });
    var zr = navigator,
        Ar = /(\$\{GDPR})/gi,
        Br = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        Cr = /(\$\{ADDTL_CONSENT})/gi,
        Dr = /(\$\{AD_WIDTH})/gi,
        Er = /(\$\{AD_HEIGHT})/gi,
        Fr = /(\$\{RENDER_DATA})/gi;
    var qN = function() {
            var a = this;
            this.promise = new _.v.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        rN = function() {
            this.auctionSignals = new qN;
            this.topLevelSellerSignals = new qN;
            this.g = new qN;
            this.perBuyerSignals = new qN;
            this.perBuyerTimeouts = new qN;
            this.perBuyerCumulativeTimeouts = new qN;
            this.directFromSellerSignals = new qN;
            this.directFromSellerSignalsHeaderAdSlot = new qN;
            this.perBuyerCurrencies = new qN;
            this.resolveToConfig = new qN
        },
        sN = function(a, b, c) {
            this.g = a;
            this.Jf = b;
            this.zb = c
        };
    var tN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u) {
        Z.call(this, a, 1201);
        this.ca = b;
        this.V = c;
        this.pa = d;
        this.da = e;
        this.T = k;
        this.F = l;
        this.I = m;
        this.M = n;
        this.B = p;
        this.j = r;
        this.la = lG(this);
        this.o = V(this);
        this.Da = Y(this, f);
        this.Ia = W(this, g);
        this.oa = W(this, h);
        this.ba = W(this, u);
        W(this, w);
        V(this, p);
        V(this, n.Cb);
        V(this, n.ya);
        V(this, n.La);
        V(this, this.j)
    };
    _.T(tN, Z);
    tN.prototype.g = function() {
        var a = Math.round(performance.now() - this.Ia.value),
            b = this.oa.value,
            c = this.Da.value,
            d = _.di(this.pa, Ey, 5),
            e = _.N(d, 10),
            f = _.N(d, 9),
            g = "string" === typeof c || "function" === typeof FencedFrameConfig && c instanceof FencedFrameConfig,
            h = 3 !== c && 2 !== c && 1 !== c;
        this.j.D(g && !f);
        h && Ir(this.context, g, b, a, d);
        var k, l;
        h = null != (l = null == (k = this.ba.value.componentAuctions) ? void 0 : k.length) ? l : 0;
        Hr(this.context, c, a, b, !!this.da, d, h, g);
        if (g)
            if (e) this.ca.deprecatedURNToURL(c, !0), this.B.D(!0), this.o.Z();
            else if (f) {
            _.N(d, 17) ? xr(0, 0, d) : this.ca.deprecatedURNToURL(c, !0);
            var m;
            yr(this.M, this.j, this.F, this.I, this.T, null == (m = this.pa) ? void 0 : _.R(m, 25));
            this.B.D(!0);
            this.o.Z()
        } else {
            this.o.D(c);
            this.B.D(!0);
            if (_.G(pC)) {
                b = this.ba.value;
                d = this.pa;
                var n;
                a = 1 === (null == (n = b.componentAuctions) ? void 0 : n.length) && rr(b.componentAuctions[0].seller) && b.componentAuctions[0].interestGroupBuyers.every(qr) && Mn(d, yy, 26) ? Aw(Gk(us(d, yy, 26)), 3) : ""
            } else a = void 0;
            n = a;
            cG(this.la, Gr(c, _.A(Object, "assign").call(Object, {}, {
                gdprApplies: null != Yl(this.V, 3) ? _.N(this.V, 3) ? "1" : "0" : null,
                Ak: _.Gj(this.V, 2),
                uj: _.Gj(this.V, 4),
                rj: this.pa.getWidth().toString(),
                pj: this.pa.getHeight().toString()
            }, n ? {
                Cl: n
            } : {})))
        } else {
            xr(a, 2 === c ? b : 0, d);
            if (!e) {
                var p;
                yr(this.M, this.j, this.F, this.I, this.T, null == (p = this.pa) ? void 0 : _.R(p, 25))
            }
            this.B.D(!0);
            this.o.Z()
        }
    };
    tN.prototype.l = function() {
        var a, b = null == (a = this.pa) ? void 0 : _.di(a, Ey, 5);
        a = this.da;
        var c = this.M,
            d = this.j,
            e = this.F,
            f = this.I,
            g = this.T;
        b && xr(0, 0, b);
        null == a || a.zb.abort();
        yr(c, d, e, f, g)
    };
    var uN = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 1200);
        this.K = b;
        this.oa = c;
        this.o = d;
        this.pa = e;
        this.T = g;
        this.F = h;
        this.I = k;
        this.M = m;
        this.ba = n;
        this.B = kG(this);
        this.la = V(this);
        this.da = V(this);
        this.ca = V(this);
        this.j = Y(this, f);
        W(this, l);
        V(this, m.Cb);
        V(this, m.ya);
        V(this, m.La);
        V(this, n)
    };
    _.T(uN, Z);
    uN.prototype.g = function() {
        if (this.j.value) {
            var a = us(this.pa, Ey, 5);
            Jr(this.context, a);
            this.la.D(performance.now());
            var b = _.$w(this.pa, 8) || 1E3;
            this.da.D(b);
            var c = _.$w(a, 14) || -1,
                d = _.$w(a, 13) || -1;
            d = 0 < d && this.K.v >= d;
            if (0 < c && this.K.l >= c || d) this.B.D(1);
            else if (++this.K.l, ++this.K.v, this.j.value.signal = AbortSignal.timeout(b), _.N(a, 15)) --this.K.l, this.B.Ka(new _.v.Promise(function(e) {
                setTimeout(function() {
                    e(1)
                }, 0)
            }));
            else {
                if (this.o && this.j.value.serverResponse) throw new TypeError("Attempted to provide a RemoteAuctionConfig in parallelized auction.");
                a = this.o ? vN(this.j.value, b, this.o) : wN(this, this.j.value);
                --this.K.l;
                this.B.Ka(a)
            }
        } else null == (a = this.o) || a.zb.abort(), yr(this.M, this.ba, this.F, this.I, this.T), this.ca.D(!1)
    };
    var wN = function(a, b) {
            var c, d;
            return null == (d = (c = a.oa).runAdAuction) ? void 0 : d.call(c, b).catch(function(e) {
                return e instanceof DOMException && "TimeoutError" === e.name ? 2 : 3
            })
        },
        vN = function(a, b, c) {
            vr(a, c);
            setTimeout(function() {
                c.zb.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, b);
            return c.g
        };
    uN.prototype.l = function() {
        var a, b = null == (a = this.pa) ? void 0 : _.di(a, Ey, 5);
        a = this.o;
        var c = this.M,
            d = this.ba,
            e = this.F,
            f = this.I,
            g = this.T;
        b && xr(0, 0, b);
        null == a || a.zb.abort();
        yr(c, d, e, f, g)
    };
    var xN = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1202);
        this.pa = b;
        this.B = c;
        this.j = d;
        this.o = Y(this, f);
        this.F = W(this, e);
        nG(this, g);
        V(this, d.Cb);
        V(this, d.ya);
        V(this, d.La)
    };
    _.T(xN, Z);
    xN.prototype.g = function() {
        this.o.value && (_.G(rC) && ni(this.B) || (this.F.value.style.display = ""), this.j.ya.D({
            kind: 2,
            Wd: this.o.value
        }), this.j.La.D(new _.Di(this.pa.getWidth(), this.pa.getHeight())), this.j.Cb.D(!1))
    };
    var yN = function(a, b, c) {
        Z.call(this, a, 1054);
        this.j = b;
        this.output = lG(this);
        this.o = W(this, c)
    };
    _.T(yN, Z);
    yN.prototype.g = function() {
        this.o.value || this.j();
        this.output.notify()
    };
    var zN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.O = c;
        this.K = d;
        this.j = V(this);
        this.o = W(this, e);
        this.B = W(this, f)
    };
    _.T(zN, Z);
    zN.prototype.g = function() {
        this.B.value ? (Pr(this.slotId, this.K, this.O, this.o.value), this.j.D(!1)) : this.j.D(!0)
    };
    var AN = function(a, b, c, d) {
        Z.call(this, a, 1055);
        this.j = d;
        nG(this, c);
        this.o = W(this, b);
        lG(this, this.j)
    };
    _.T(AN, Z);
    AN.prototype.g = function() {
        this.o.value && this.j.notify()
    };
    var Rr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
        Z.call(this, a, 1179);
        this.slotId = b;
        this.R = d;
        this.K = e;
        this.V = f;
        this.o = g;
        this.M = l;
        this.B = m;
        this.O = n;
        this.ba = p;
        this.ec = r;
        this.j = u;
        this.da = x;
        this.ca = Y(this, w);
        this.F = W(this, h);
        this.I = W(this, k);
        this.T = Y(this, c)
    };
    _.T(Rr, Z);
    Rr.prototype.g = function() {
        var a = new Pj;
        _.S(this, a);
        var b = this.ca.value,
            c = V(this);
        if (b) {
            var d = us(b, Ey, 5),
                e = _.N(d, 10);
            if (b.getWidth() && b.getHeight())
                if (e)
                    if (yr({
                            Cb: c,
                            ya: this.j.ya,
                            La: this.j.La
                        }, this.j.Jc, this.F.value, this.I.value, this.o), _.N(d, 17)) {
                        xr(0, 0, d);
                        var f;
                        null == (f = this.B) || f.zb.abort()
                    } else BN(this, a, b);
            else c = BN(this, a, b);
            else {
                yr({
                    Cb: c,
                    ya: this.j.ya,
                    La: this.j.La
                }, this.j.Jc, this.F.value, this.I.value, this.o);
                xr(0, 0, d);
                var g;
                null == (g = this.B) || g.zb.abort()
            }
        } else yr({
            Cb: c,
            ya: this.j.ya,
            La: this.j.La
        }, this.j.Jc, this.F.value, this.I.value, this.o), null == (d = this.B) || d.zb.abort();
        b = new zN(this.context, this.slotId, this.O, this.K, this.ec, c);
        O(a, b);
        c = new yN(this.context, this.ba, c);
        O(a, c);
        c = new AN(this.context, b.j, c.output, this.j.Rd);
        O(a, c);
        Yj(a)
    };
    var BN = function(a, b, c) {
        if (2 === _.$e(Gs) && a.T.value && _.N(c, 20) && 0 !== _.xo(c, 3, 2).length) {
            var d = new nN(a.context, a.slotId.getAdUnitPath(), c, a.T.value);
            O(b, d)
        }
        var e = new mN(a.context, a.R, c, a.da);
        O(b, e);
        var f = navigator,
            g = {
                ya: a.j.ya,
                La: a.j.La,
                Cb: new Cn
            };
        d = g.Cb;
        var h = new uN(a.context, a.K, f, a.B, c, e.output, a.o, a.F.value, a.I.value, a.M, g, a.j.Jc);
        O(b, h);
        var k = h.ca;
        e = new tN(a.context, f, a.V, c, a.B, h.B, h.la, h.da, a.o, a.F.value, a.I.value, g, k, a.j.Jc, a.M, e.output);
        O(b, e);
        g = new xN(a.context, c, Qs(a.R), g, a.M, e.o, e.la);
        O(b, g);
        g = new Qp(a.context, a.slotId, Or);
        O(b, g);
        k = new pN(a.context, k, g.output);
        O(b, k);
        c = _.R(c, 19);
        (null == c ? 0 : c.length) && O(b, new oN(a.context, window.document, c, k.output));
        return d
    };
    var CN = function() {
        NM.apply(this, arguments)
    };
    _.T(CN, NM);
    var DN = function(a, b) {
            var c = _.rf(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.yd;
            c.name = a.yd;
            c.title = a.zd;
            Array.isArray(a.g) ? null != a.g[0] && null != a.g[1] && (c.width = String(a.g[0]), c.height = String(a.g[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        EN = function(a, b) {
            "string" !== typeof a.g && (b.width = String(a.g[0]), b.height = String(a.g[1]));
            var c = Lh(a.context, 774, function() {
                a.loaded(b);
                _.Ef(b, "load", c)
            });
            _.lb(b, "load", c);
            _.yn(a, function() {
                return _.Ef(b, "load", c)
            });
            a.l.ih.appendChild(b)
        };
    var FN = function() {
        CN.apply(this, arguments)
    };
    _.T(FN, CN);
    FN.prototype.j = function() {
        var a = DN(this, !this.l.km);
        if ("string" === typeof this.ib.Wd) {
            var b = this.ib.Wd;
            /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = df(b), a.src = _.jb(b).toString())
        } else a.config = this.ib.Wd;
        EN(this, a);
        return a
    };
    FN.prototype.v = function() {
        return !1
    };
    var GN = navigator,
        HN = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 1089);
            this.Nb = b;
            this.X = c;
            this.R = d;
            this.Ec = f;
            this.j = g;
            V(this, g);
            e && (this.o = Y(this, e))
        };
    _.T(HN, Z);
    HN.prototype.g = function() {
        var a = {};
        if (1 === this.Nb)
            for (var b = _.z(this.X), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = this.R[d.getDomId()];
                a[d.getId()] = IN(this, c, void 0, this.Ec)
            } else if (2 === this.Nb) {
                b = null == (d = this.o) ? void 0 : d.value;
                if (!b) {
                    this.j.Z();
                    return
                }
                d = _.z(this.X);
                for (c = d.next(); !c.done; c = d.next()) {
                    c = c.value;
                    var e = b.get(c.getId()),
                        f = void 0;
                    null != (f = e) && f.length && (f = this.R[c.getDomId()], a[c.getId()] = IN(this, f, e, this.Ec))
                }
            }
        this.j.D(a)
    };
    var IN = function(a, b, c, d) {
        var e = new rN,
            f = new AbortController;
        a = ur({
            Jf: e,
            zb: f,
            hh: Sm(a.context, b),
            interestGroupBuyers: c,
            Ec: d
        });
        a = GN.runAdAuction(a).catch(function(g) {
            return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
        });
        return new sN(a, e, f)
    };
    var JN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1106);
        this.V = b;
        this.o = c;
        this.X = d;
        this.Ec = e;
        this.B = f;
        this.j = V(this);
        V(this, f)
    };
    _.T(JN, Z);
    JN.prototype.g = function() {
        for (var a = pr(this.o, this.V, this.Ec), b = new _.v.Map, c = Ur(a), d = new _.v.Map, e = _.z(this.X), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            f = g.getAdUnitPath();
            var h = a.get(hr(f)),
                k = void 0,
                l = void 0,
                m = void 0,
                n = null != (m = null != (l = c) ? l : null == (k = h) ? void 0 : _.gi(k, or, 1).map(function(p) {
                    return _.R(p, 1)
                })) ? m : [];
            b.set(g.getId(), n);
            if (!d.has(f)) {
                g = [];
                n = _.z(n.sort());
                for (h = n.next(); !h.done; h = n.next()) g.push(_.hg(h.value));
                d.set(f, g)
            }
        }
        this.j.D(b);
        this.B.D(d)
    };
    var Vr = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 1170);
        this.Nb = b;
        this.R = c;
        this.V = d;
        this.o = e;
        this.j = {
            Ag: V(this)
        };
        2 === b && this.o && (this.j.eg = V(this));
        this.I = W(this, f);
        this.F = W(this, g);
        h && (this.B = Y(this, h));
        k && (this.M = W(this, k))
    };
    _.T(Vr, Z);
    Vr.prototype.g = function() {
        var a = this.I.value,
            b;
        if (!this.F.value || !a.length || (null == (b = this.M) ? 0 : b.value)) {
            this.j.Ag.Z();
            var c;
            null == (c = this.j.eg) || c.Z()
        } else {
            b = new Pj;
            _.S(this, b);
            if (2 === this.Nb && this.o) {
                var d, e;
                var f = new JN(this.context, this.V, this.o, a, null != (e = null == (d = this.B) ? void 0 : d.value) ? e : void 0, this.j.eg);
                O(b, f);
                f = f.j
            }
            var g, h;
            a = new HN(this.context, this.Nb, a, this.R, f, null != (h = null == (g = this.B) ? void 0 : g.value) ? h : void 0, this.j.Ag);
            O(b, a);
            Yj(b)
        }
    };
    var KN = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1166);
        this.kd = b;
        this.U = c;
        this.F = d;
        this.j = kG(this);
        this.o = V(this);
        this.B = V(this);
        this.M = W(this, e);
        this.T = W(this, f);
        nG(this, g);
        this.I = W(this, h)
    };
    _.T(KN, Z);
    KN.prototype.g = function() {
        var a = this,
            b = this.M.value;
        if (b) {
            var c = rb(this.T.value, {
                    uuid: this.kd
                }),
                d = this.U.createElement("script");
            b = {
                source: b,
                credentials: this.I.value ? "include" : "omit",
                resources: [c.toString()]
            };
            d.setAttribute("type", "webbundle");
            ib(d, jf(b));
            this.U.head.appendChild(d);
            this.o.D(d);
            this.B.D(b);
            this.j.Ka(LN(c).catch(function(e) {
                e instanceof $E ? a.F(e) : (a.H(e), a.l(e));
                return null
            }))
        } else this.j.Z(), this.o.Z(), this.B.Z()
    };
    var LN = function(a) {
        var b, c;
        return _.nb(function(d) {
            if (1 == d.g) return d.yield(fetch(a.toString()).catch(function() {
                throw new $E("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.g) return b = d.m, d.yield(b.text(), 3);
            c = d.m;
            return d.return(My(c))
        })
    };
    var MN = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 1167);
        this.U = b;
        this.V = c;
        this.F = d;
        this.j = e;
        this.B = f;
        this.o = W(this, g);
        this.M = Y(this, h);
        this.T = Y(this, k);
        this.ba = Y(this, l);
        m && (this.I = Y(this, m))
    };
    _.T(MN, Z);
    MN.prototype.g = function() {
        var a = this.M.value,
            b = this.T.value,
            c = this.ba.value;
        if (a)
            if (b && c) {
                var d = _.xo(a, 1, 2),
                    e = _.xo(a, 2, 2);
                a = _.xo(a, 3, 2);
                if (d.length !== e.length) this.j(new ZE("Received " + d.length + " ad URLs but " + e.length + " metadatas"));
                else {
                    c.resources = [].concat(_.oh(d.filter(function(f) {
                        return f
                    })), _.oh(a.map(function(f) {
                        return "https://securepubads.g.doubleclick.net" + f
                    })));
                    c.resources.length ? (a = _.rf("SCRIPT"), a.setAttribute("type", "webbundle"), ib(a, jf(c)), this.U.head.removeChild(b), this.U.head.appendChild(a)) : this.U.head.removeChild(b);
                    for (b = 0; b < d.length; b++) c = void 0, this.F(b, e[b], {
                        kind: 1,
                        url: d[b]
                    }, this.o.value, this.V, null == (c = this.I) ? void 0 : c.value, void 0);
                    this.B(d.length - 1, this.o.value, this.V)
                }
            } else this.j(Error("Lost bundle script"))
    };
    var NN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Pj.call(this);
        e = new KN(a, f, h, c, m, n, p, r);
        O(this, e);
        O(this, new MN(a, h, g, b, c, d, k, e.j, e.o, e.B, l));
        this.g = {
            output: e.j
        }
    };
    _.T(NN, Pj);
    var ps = new _.v.Set,
        ON = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.t.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new Lm("Reached Limit for addEventListener");
        }, 3E5),
        PN = function(a, b, c) {
            _.U.call(this);
            this.context = a;
            this.P = b;
            this.l = c;
            this.g = [];
            this.enabled = !1;
            this.H = 0;
            this.j = new _.v.Map;
            ps.add(this);
            this.P.info(aJ(this.getName()))
        };
    _.T(PN, _.U);
    var rs = function(a) {
        a.enabled || (a.enabled = !0, $l(6, a.context), a.L())
    };
    PN.prototype.slotAdded = function(a, b) {
        this.g.push(a);
        var c = new ZL(a, this.getName());
        Mr(this.l, "slotAdded", 818, c);
        this.P.info(bJ(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        hx(b, 4, a)
    };
    PN.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return ha(b.g, c)
        })
    };
    PN.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.H >= _.$e(uB) && 0 < _.$e(uB)) return ON(), !1;
        if (!c.IntersectionObserver && (_.H = ["impressionViewable", "slotVisibilityChanged"], _.A(_.H, "includes")).call(_.H, a)) return Q(this.P, QJ()), !1;
        var e;
        if (null == (e = this.j.get(a)) ? 0 : e.has(b)) return !1;
        this.j.has(a) || this.j.set(a, new _.v.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.P.error(qJ(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        this.j.get(a).set(b, c);
        this.l.listen(a, c);
        this.H++;
        return !0
    };
    PN.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.j.get(a)) ? void 0 : c.get(b);
        if (!d || !qI(this.l, a, d)) return !1;
        this.H--;
        return this.j.get(a).delete(b)
    };
    var Zr = function(a) {
        for (var b = _.z(ps), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var cs = function(a, b, c, d) {
        PN.call(this, a, b, d);
        this.v = c;
        this.ads = new _.v.Map;
        this.wc = !1
    };
    _.T(cs, PN);
    cs.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.wc = a)
    };
    var bK = function(a, b) {
            var c;
            return a.v.enabled && !(null == (c = a.ads.get(b)) || !c.ml)
        },
        cK = function(a, b, c, d) {
            b = new VL(b, a.getName());
            null != c && null != d && (b.size = [c, d]);
            Mr(a.l, "slotRenderEnded", 67, b)
        };
    cs.prototype.getName = function() {
        return "companion_ads"
    };
    cs.prototype.slotAdded = function(a, b) {
        var c = this;
        a.listen(tI, function(d) {
            Yl(d.detail, 11) && (QN(c, a).ml = !0)
        });
        PN.prototype.slotAdded.call(this, a, b)
    };
    cs.prototype.L = function() {};
    var QN = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.yn(b, function() {
                return a.ads.delete(b)
            }));
            return c
        },
        $J = function(a, b) {
            var c = Vi().g,
                d = Vi().m;
            if (a.v.enabled) {
                var e = {
                    Qb: 3
                };
                a.G && (e.bd = a.G);
                a.o && (e.cd = a.o);
                b = null != b ? b : a.g;
                c = Hi(c, d);
                d = e.bd;
                var f = e.cd;
                d && "number" !== typeof d || f && "number" !== typeof f || a.v.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.P.error(hJ(b[0].getDomId()))
        },
        aK = function(a, b) {
            return a.g.filter(function(c) {
                return _.A(b, "includes").call(b, c.toString())
            })
        };
    var ds = function(a, b, c) {
        PN.call(this, a, b, c)
    };
    _.T(ds, PN);
    ds.prototype.getName = function() {
        return "content"
    };
    ds.prototype.L = function() {};
    var iu = function(a, b) {
        var c = {};
        this.configuration = (c[576944485] = new mM, c);
        this.Ja = a;
        this.g = b
    };
    iu.prototype.log = function(a, b, c) {
        var d, e = null != (d = c.Vc) ? d : this.configuration[a].Vj;
        1 / e < this.g || (b = b(_.A(Object, "assign").call(Object, {}, {
            Vc: e
        }, c)), this.configuration[a].send(this.Ja, b))
    };
    var RN = _.tu(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        SN = _.tu(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        TN = _.tu(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        UN = _.tu(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        VN = new _.v.Map([
            [2, {
                sg: "page_level_ads"
            }],
            [5, {
                sg: "shoppit"
            }],
            [6, {
                sg: "side_rails"
            }]
        ]),
        WN = function(a) {
            var b = void 0 === b ? VN : b;
            this.context = a;
            this.g = b;
            this.m = new _.v.Map;
            this.loaded = new _.v.Set
        },
        YN;
    WN.prototype.load = function(a) {
        var b = _.XN(this, a),
            c, d = (null != (c = this.g.get(a.module)) ? c : {}).sg;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            d = (c = _.qi(172)) && "pagead2.googlesyndication.com" === rz((c.src || "").match(_.qz)[3] || null) ? this.context.wb ? _.ef(TN, this.context.wb, d) : _.ef(UN, d, this.context.ab) : this.context.wb ? _.ef(RN, this.context.wb, d) : _.ef(SN, d, this.context.ab);
            c = {};
            var e = _.$e($B);
            e && (c.cb = e);
            d = _.A(Object, "keys").call(Object, c).length ? _.nv(d, c) : d;
            YN(this, a);
            _.on(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.XN = function(a, b) {
        b = b.module;
        a.m.has(b) || a.m.set(b, new _.pg);
        return a.m.get(b)
    };
    YN = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = Lh(a.context, 340, function(e) {
            if (a.g.has(c) && "function" === typeof e) {
                var f = a.g.get(c);
                f = (void 0 === f.Xj ? [] : f.Xj).map(function(g) {
                    return _.XN(a, g).promise
                });
                _.v.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Nm(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var ZN = function(a, b) {
        Z.call(this, a, 980);
        this.output = new Gn;
        this.j = [];
        this.o = W(this, b)
    };
    _.T(ZN, Z);
    ZN.prototype.g = function() {
        for (var a = _.z((_.H = [this.o.value, this.j.map(function(c) {
                return c.value
            })], _.A(_.H, "flat")).call(_.H)), b = a.next(); !b.done; b = a.next()) ag(b.value);
        this.output.notify()
    };
    var $N = function(a, b) {
        Z.call(this, a, 892, _.$e(TB));
        this.j = V(this);
        this.B = V(this);
        this.o = V(this);
        this.od = V(this);
        this.Qd = V(this);
        this.F = V(this);
        this.vf = V(this);
        this.I = mG(this, b);
        _.G(oB) && (this.nd = V(this))
    };
    _.T($N, Z);
    $N.prototype.g = function() {
        var a = this.I.value;
        if (!a) throw Error("config timeout");
        this.j.Aa(_.di(a, Qx, 3));
        this.B.Aa(_.di(a, Sx, 2));
        var b = this.o,
            c = b.D;
        var d = be(a, 4, Qc, 2);
        c.call(b, d);
        b = this.od;
        c = b.Aa;
        d = _.gi(a, Mx, 6);
        c.call(b, d);
        b = this.Qd;
        c = b.Aa;
        d = _.gi(a, cy, 5);
        c.call(b, d);
        this.F.Aa(_.di(a, by, 7));
        var e;
        b = this.vf;
        c = b.D;
        d = _.v.Set;
        var f;
        null == (e = _.di(a, Nx, 1)) ? f = void 0 : f = _.xo(e, 6, 2);
        c.call(b, new d(f || []));
        var g;
        null == (g = this.nd) || g.Aa(_.di(a, ey, 8))
    };
    $N.prototype.G = function(a) {
        this.l(a)
    };
    $N.prototype.l = function(a) {
        this.j.fb(a);
        this.B.fb(a);
        this.o.D([]);
        this.od.D([]);
        this.Qd.D([]);
        this.F.Z();
        var b;
        null == (b = this.nd) || b.Z()
    };
    var aO = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.j = V(this);
        this.error = void 0;
        var d = V(this);
        this.o = W(this, d);
        b(function(e, f) {
            if (f) c.error = f, d.D([]);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.D(g)
                }
            } catch (h) {} finally {
                d.yb || (c.error = Error("malformed response"), d.D([]))
            }
        })
    };
    _.T(aO, Z);
    aO.prototype.g = function() {
        if (this.error) throw this.error;
        this.j.D(te(fy, this.o.value))
    };
    var bO = function(a, b) {
        Z.call(this, a, 1081);
        this.Kb = V(this);
        this.j = Y(this, b)
    };
    _.T(bO, Z);
    bO.prototype.g = function() {
        this.j.value ? this.Kb.D(this.j.value) : this.Kb.Z()
    };
    var cO = new _.v.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        dO = function(a, b, c, d, e, f, g, h, k) {
            Z.call(this, a, 1079);
            this.U = b;
            this.googletag = c;
            this.W = d;
            this.F = e;
            this.j = f;
            this.P = g;
            this.o = h;
            this.B = k;
            V(this)
        };
    _.T(dO, Z);
    dO.prototype.g = function() {
        var a = this,
            b = this.o.getAdUnitPath(),
            c = cO.get(_.Nk(this.o, 2, 0));
        if (b && c) {
            var d, e = null != (d = this.W) ? d : this.j.g;
            b = new yL(this.context, this.U, b, c, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, e, this.j, this.F, this.P, !1, this.B);
            _.S(this, b);
            Yj(b)
        }
    };
    var tt = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.W = c;
        this.F = d;
        this.o = e;
        this.P = f;
        this.B = V(this);
        this.j = new bO(this.context, this.B);
        this.Kb = this.j.Kb;
        _.S(this, this.j);
        this.I = W(this, g)
    };
    _.T(tt, Z);
    tt.prototype.g = function() {
        if (_.G(ZB)) {
            for (var a = [], b = _.z(this.I.value), c = b.next(); !c.done; c = b.next()) switch (c = c.value, Jk(c, dy)) {
                case 5:
                    a.push(c);
                    break;
                case 8:
                    var d = c
            }
            this.B.Aa(null == d ? void 0 : _.di(d, Xx, 4));
            d = new Pj;
            _.S(this, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) b = b.value, c = void 0, O(d, new dO(this.context, document, this.googletag, null != (c = this.W) ? c : this.o.g, this.F, this.o, this.P, _.di(b, Zx, Mk(b, dy, 5)), _.di(b, Xx, 4)));
            O(d, this.j);
            Yj(d)
        } else this.Kb.Z()
    };
    var eO = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.context = a;
        this.v = b;
        this.l = c;
        this.P = d;
        this.K = e;
        this.g = f;
        this.Ya = g;
        this.j = h
    };
    _.T(eO, _.U);
    var fO = function(a, b, c, d) {
        var e = new Pj;
        _.S(a, e);
        var f = a.context;
        var g = a.g;
        var h = new Pj;
        g = new aO(f, g);
        O(h, g);
        var k = new $N(f, g.j);
        O(h, k);
        Yj(h);
        var l = k.j;
        var m = k.B;
        var n = k.o;
        f = k.od;
        var p = k.Qd;
        var r = k.F;
        g = k.vf;
        k = k.nd;
        _.S(a, h);
        var w;
        h = new RL(a.context, document, Nm(), a.v, a.l, a.P, null != (w = window.location.hash) ? w : "");
        O(e, h);
        w = new tt(a.context, Nm(), null, a.v, a.l, a.P, p);
        O(e, w);
        h = new ZN(a.context, n);
        O(e, h);
        b = new HL(a.context, window, m, b);
        O(e, b);
        n = a.context;
        p = a.Ya;
        m = {
            Pb: new Cn,
            Wb: new Cn,
            Vb: new Cn,
            Ub: new Cn,
            Cc: new Cn,
            vc: new Cn,
            bf: new Cn,
            cf: new Cn,
            Af: new Cn
        };
        var u = new Pj;
        O(u, new cL(n, p, l, window, m));
        Yj(u);
        _.S(a, u);
        l = Ap(a.context, a.g, b.j);
        p = l.Ic;
        u = l.Fh;
        _.S(e, l.Fa);
        l = new AL(a.context, u);
        O(e, l);
        n = new BL(a.context, u);
        O(e, n);
        u = bn(a.context, a.P, a.K, window, p, u);
        p = u.hb;
        _.S(a, u.Fa);
        if (_.G(UB)) {
            u = new IM(a.context, window.navigator, p);
            var x = u.j;
            O(e, u)
        }
        u = void 0;
        if (_.G(mC)) {
            var y = new iN(a.context, a.K, window, p);
            u = y.output;
            O(e, y)
        }
        y = a.context;
        if (_.G(sB) || om()) y = void 0;
        else {
            var C = {
                    ug: new Cn,
                    rb: new Cn
                },
                D = new Pj;
            O(D, new XM(y, f, p, C));
            Yj(D);
            y = {
                hf: C,
                Fa: D
            }
        }
        if (y) {
            var E = y.hf;
            _.S(a, y.Fa)
        }
        y = a.context;
        d = d.qe;
        C = window;
        D = !eg(C.isSecureContext, C.document);
        fg(C.isSecureContext, C, C.document) || !D ? (D = new Pj, d = new dN(y, C, d, p), O(D, d), Yj(D), d = d.j) : d = void 0;
        C = a.context;
        D = a.j;
        y = new Pj;
        c = new $M(C, D, c, p, r);
        O(y, c);
        Yj(y);
        _.S(a, y);
        Yj(e);
        return {
            fe: m,
            hf: E,
            al: b.j,
            Pj: h.output,
            Kb: w.Kb,
            od: f,
            Ce: l.Ce,
            xk: n.j,
            vf: g,
            qf: d,
            Eh: u,
            Sj: x,
            nd: k
        }
    };
    var hu = function(a) {
        sG.call(this, function(b, c) {
            Ph(a, b, c);
            var d;
            null == (d = console) || d.error(c)
        })
    };
    _.T(hu, sG);
    var gO = function() {
        CN.apply(this, arguments)
    };
    _.T(gO, CN);
    gO.prototype.j = function() {
        var a = this,
            b = this.l,
            c = b.Hi;
        b = b.Ae;
        var d = DN(this);
        if (null == c ? 0 : c.length)
            if (_.jw) {
                c = _.z(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.oh(c));
        b && (d.allow = b);
        EN(this, d);
        Rh(this.context, 653, function() {
            var f;
            if (f = zj(a.ib.vb)) {
                var g = f.toString().toLowerCase();
                f = -1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") || _.G(BC) ? f : zj("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>")
            }
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            (La("Firefox") || La("FxiOS")) && g.open("text/html", "replace");
            g.write(_.Uv(f));
            var l, m, n;
            if (rv(null != (n = null == (l = d.contentWindow) ? void 0 : null == (m = l.location) ? void 0 : m.href) ? n : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    gO.prototype.v = function() {
        return !0
    };
    var ft = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.K = c;
        this.O = d;
        this.ra = e;
        this.Sa = f;
        this.A = g;
        this.j = V(this);
        this.B = V(this);
        this.o = lG(this);
        this.I = W(this, h);
        this.Ia = W(this, k);
        nG(this, l);
        this.da = W(this, m);
        this.F = W(this, n);
        this.ca = W(this, p);
        nG(this, C);
        this.M = W(this, r);
        this.T = Y(this, w);
        this.Pa = Y(this, u);
        this.ba = W(this, x);
        this.Va = Y(this, y);
        nG(this, D);
        this.Da = W(this, E);
        nG(this, J);
        X && nG(this, X);
        this.la = Y(this, M);
        K && (this.oa = Y(this, K))
    };
    _.T(ft, Z);
    ft.prototype.g = function() {
        var a = this.I.value;
        if (0 === a.kind && null == a.vb) throw new ZE("invalid html");
        var b, c;
        a: {
            var d = this.context,
                e = {
                    U: document,
                    slotId: this.slotId,
                    K: this.K,
                    O: this.O,
                    ra: this.ra,
                    size: this.ca.value,
                    Oi: this.da.value,
                    ih: this.F.value,
                    Tf: this.M.value,
                    rk: this.T.value,
                    Hi: this.Pa.value,
                    isBackfill: this.ba.value,
                    ae: this.Va.value,
                    Ae: this.Da.value,
                    km: null == (b = this.la.value) ? void 0 : _.N(b, 14),
                    zf: null == (c = this.oa) ? void 0 : c.value,
                    Sa: this.Sa
                };b = this.Ia.value;c = a.kind;
            switch (c) {
                case 0:
                    a = new(b ? QM : gO)(d, a, e);
                    break a;
                case 2:
                    a = new FN(d, a, e);
                    break a;
                default:
                    _.eb(c)
            }
            a = void 0
        }
        _.S(this, a);
        d = a.render();
        hO(this, this.A, d);
        this.A.top && this.A.top !== this.A && _.tk(this.A.top) && hO(this, this.A.top, d);
        this.o.notify();
        this.j.D(d);
        this.B.D(a.v())
    };
    var hO = function(a, b, c) {
        zn(a, a.id, b, "message", function(d) {
            c.contentWindow === d.source && Mr(a.slotId, Rp, 824, d)
        })
    };
    var Ps = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.ma = c;
        this.output = V(this);
        this.j = Y(this, d);
        this.o = Y(this, e)
    };
    _.T(Ps, Z);
    Ps.prototype.g = function() {
        var a = this.o.value;
        if (null == a) this.output.Z();
        else {
            var b = Math.round(.3 * this.ma),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.j.value) || !_.N(c, 12, !1) || 0 >= b || a <= b ? this.output.D(a) : this.output.D(b)
        }
    };
    var Xs = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.W = c;
        this.o = d;
        this.U = f;
        this.K = g;
        this.output = V(this);
        this.M = 2 === e || 3 === e;
        this.j = W(this, h);
        this.I = W(this, k);
        this.F = Y(this, l);
        this.B = Y(this, m);
        n && nG(this, n)
    };
    _.T(Xs, Z);
    Xs.prototype.g = function() {
        var a = No(this.W, this.o),
            b = Ki(this.slotId, this.U) || Kn(this.j.value, Ti(this.slotId), a);
        this.I.value && !a && (b.style.display = "inline-block");
        this.M ? CI(this.K, this.slotId, function() {
            return void _.kz(b)
        }) : _.yn(this, function() {
            return void _.kz(b)
        });
        a = iO(this);
        0 < a && (b.style.paddingTop = a + "px");
        this.output.D(b)
    };
    var iO = function(a) {
        var b = a.j.value,
            c, d = null == (c = a.F.value) ? void 0 : c.height;
        if (b && !a.B.value && d) {
            var e;
            c = (null != (e = Mo(a.o, 23)) ? e : _.N(a.W, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Ns = function(a, b) {
        Z.call(this, a, 859);
        this.A = b;
        this.output = V(this)
    };
    _.T(Ns, Z);
    Ns.prototype.g = function() {
        this.output.D(!_.tk(this.A.top))
    };
    var ct = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.U = c;
        this.output = V(this)
    };
    _.T(ct, Z);
    ct.prototype.g = function() {
        var a = [],
            b = this.U;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.H = c.features(), _.A(_.H, "includes")).call(_.H, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.G(gB) || a.push("autoplay");
        a.length ? this.output.D(a.join(";")) : this.output.D("")
    };
    var Ks = function(a, b, c, d) {
        Z.call(this, a, 1207);
        this.ra = c;
        this.slotId = d;
        nG(this, b)
    };
    _.T(Ks, Z);
    Ks.prototype.g = function() {
        Mr(this.ra, "impressionViewable", 715, new WL(this.slotId, "publisher_ads"))
    };
    var Js = function(a, b, c, d) {
        nM.call(this, a, b, c);
        nG(this, d)
    };
    _.T(Js, nM);
    var nt = function(a, b, c, d, e, f) {
        f = void 0 === f ? Ms : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.U = d;
        this.ra = e;
        this.B = f;
        this.j = this.o = -1;
        this.I = _.fv(function() {
            Mr(g.ra, "slotVisibilityChanged", 716, new XL(g.slotId, "publisher_ads", g.j))
        }, 200);
        this.F = W(this, c);
        var h = new Gn;
        rI(this.slotId).then(function() {
            return void h.notify()
        });
        nG(this, h)
    };
    _.T(nt, Z);
    nt.prototype.g = function() {
        var a = this,
            b = this.B(Lh(this.context, this.id, function(c) {
                c = _.z(c);
                for (var d = c.next(); !d.done; d = c.next()) a.o = 100 * d.value.intersectionRatio, _.A(Number, "isFinite").call(Number, a.o) && jO(a)
            }));
        b && (b.observe(this.F.value), zn(this, this.id, this.U, "visibilitychange", function() {
            jO(a)
        }), _.yn(this, function() {
            b.disconnect()
        }))
    };
    var jO = function(a) {
        var b = Math.floor(BF(a.U) ? 0 : a.o);
        if (0 > b || 100 < b || b === a.j ? 0 : -1 !== a.j || 0 !== b) a.j = b, a.I()
    };
    var at = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.W = b;
        this.o = c;
        this.output = V(this);
        this.j = W(this, d);
        this.B = W(this, e);
        this.F = Y(this, f)
    };
    _.T(at, Z);
    at.prototype.g = function() {
        var a = this.j.value.kind;
        switch (a) {
            case 0:
                if (this.j.value.vb)
                    if (this.B.value) {
                        a = this.F.value;
                        var b = new Ql;
                        a = Lj(b, 3, a);
                        _.N(Zl([a, this.W.kc(), this.o.kc()]), 3) ? this.output.D(QH) : this.output.Z()
                    } else this.output.Z();
                else this.output.Z();
                break;
            case 2:
                this.output.Z();
                break;
            default:
                _.eb(a)
        }
    };
    var kO = function(a, b, c, d, e, f) {
        Z.call(this, a, 1119);
        this.slotId = b;
        this.o = c;
        this.documentElement = d;
        this.K = e;
        this.j = f;
        this.output = jG(this)
    };
    _.T(kO, Z);
    kO.prototype.g = function() {
        var a = _.rf("INS");
        a.id = this.o;
        ni(this.j) && _.Yi(a, {
            display: "none"
        });
        this.documentElement.appendChild(a);
        var b = function() {
            return void _.kz(a)
        };
        (_.H = [2, 3], _.A(_.H, "includes")).call(_.H, this.j) ? CI(this.K, this.slotId, b) : _.yn(this, b);
        this.output.D(a)
    };
    var lO = function(a, b, c, d, e) {
        Z.call(this, a, 1120);
        this.F = b;
        this.o = c;
        this.Gc = d;
        this.j = e;
        this.output = jG(this);
        a = this.j;
        if (!_.ka(a) || !_.ka(a) || 1 !== a.nodeType || a.namespaceURI && "http://www.w3.org/1999/xhtml" !== a.namespaceURI) this.B = W(this, this.j)
    };
    _.T(lO, Z);
    lO.prototype.g = function() {
        var a, b, c = null != (b = null == (a = this.B) ? void 0 : a.value) ? b : this.j;
        if (!(_.H = [2, 3], _.A(_.H, "includes")).call(_.H, this.o)) {
            a = _.z(_.A(Array, "from").call(Array, c.childNodes));
            for (b = a.next(); !b.done; b = a.next()) b = b.value, 1 === b.nodeType && b.id !== this.F && _.kz(b);
            this.Gc || (c.style.display = "")
        }
        this.output.D(c)
    };
    var Rs = function(a, b, c, d, e, f, g, h, k) {
        Pj.call(this);
        c ? (a = new lO(a, e, g, k, c), O(this, a), a = a.output) : 0 !== g && 1 !== g ? (a = new kO(a, b, d, f, h, g), O(this, a), a = a.output) : (b = new bq(a, b, sI, function(l) {
            return l.detail
        }), O(this, b), a = new lO(a, e, g, k, b.output), O(this, a), a = a.output);
        this.g = {
            output: a
        }
    };
    _.T(Rs, Pj);
    var mO = function(a, b) {
            var c = Vi();
            this.context = a;
            this.K = b;
            this.g = c
        },
        nO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x) {
            var y = document,
                C = window;
            e || f || KI(a.K, d);
            var D = ut(a.context, b, a.g, c, d, e, f, g, h, k, l, y, m, n, p, r, w, function() {
                KI(a.K, d);
                JI(a.K, d, D)
            }, u, x);
            f || JI(a.K, d, D);
            _.yn(d, function() {
                KI(a.K, d)
            });
            C.top !== C && C.addEventListener("pagehide", function(E) {
                E.persisted || KI(a.K, d)
            });
            Yj(D)
        };
    var oO = function(a, b, c, d) {
        Z.call(this, a, 884);
        this.xa = b;
        this.Ya = c;
        this.o = V(this);
        this.j = W(this, d)
    };
    _.T(oO, Z);
    oO.prototype.g = function() {
        KK(this.Ya, _.am(this.xa, "__gads", this.j.value));
        cm(20, this.context, this.xa, this.j.value);
        cm(2, this.context, this.xa, this.j.value);
        this.o.D(_.bg())
    };
    var wt = 0,
        pO = new _.ui(-9, -9);
    var zt = new _.v.Set([function(a, b) {
        var c = a.ia.O.W;
        b.set("pvsid", {
            value: a.ha.context.pvsid
        }).set("correlator", {
            value: ir(c, 26)
        })
    }, function(a, b) {
        a = a.cj;
        var c = a.kd;
        "wbn" === a.Xe && b.set("wbsu", {
            value: c
        })
    }, function(a, b) {
        var c = a.ia.O.W,
            d = a.om;
        a = d.cd;
        d = d.bd;
        var e = _.N(c, 21);
        b = b.set("hxva", {
            value: e ? 1 : null
        }).set("cmsid", {
            value: e ? _.Gj(c, 23) : null
        }).set("vid", {
            value: e ? _.Gj(c, 22) : null
        }).set("pod", {
            value: d
        }).set("ppos", {
            value: a
        });
        a = b.set;
        c = Yw(c, 29);
        a.call(b, "scor", {
            value: null == c ? void 0 : c
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.X,
            e = c.O.R;
        c = a.zl;
        var f = c.Dk,
            g = c.yk;
        b.set("eid", {
            value: a.ha.Wf
        }).set("debug_experiment_id", {
            value: bF().split(",")
        }).set("expflags", {
            value: _.qi(253) ? af(yB) || null : null
        }).set("pied", {
            value: function() {
                var h = new wG,
                    k = !1,
                    l = !1;
                f && (k = !0, Mj(h, 1, Xx, f));
                var m = d.map(function(p) {
                    var r = new uG,
                        w, u;
                    null == (w = e[p.getDomId()]) ? u = void 0 : u = _.gi(w, Xx, 27);
                    p = u;
                    if (null == p || !p.length) return r;
                    l = k = !0;
                    p = _.z(p);
                    for (w = p.next(); !w.done; w = p.next()) Mj(r, 1, Xx, w.value);
                    return r
                });
                l && _.ul(h, 2, m);
                m = _.z(null != g ? g : []);
                for (var n = m.next(); !n.done; n = m.next()) Mj(h, 1, Xx, n.value), k = !0;
                return k ? Bb(h.g(), 3) : null
            }()
        })
    }, function(a, b) {
        var c = a.ha,
            d = c.context;
        c = c.eb;
        b.set("output", {
            value: a.cj.Xe
        }).set("gdfp_req", {
            value: 1
        }).set("vrg", {
            value: d.tc ? String(d.tc) : d.ab
        }).set("ptt", {
            value: 17
        }).set("impl", {
            value: c ? "fifs" : "fif"
        })
    }, function(a, b) {
        var c = a.ha.V;
        a = Gt(a.ia.O.W) || new $G;
        var d = _.Nk(a, 6, 2);
        b = b.set("rdp", {
            value: _.N(a, 1) ? "1" : null
        }).set("ltd", {
            value: _.N(a, 9) ? "1" : null
        }).set("gdpr_consent", {
            value: fx(c, 2)
        }).set("gdpr", {
            value: null != Yl(c, 3) ? _.N(c, 3) ? "1" : "0" : null,
            options: {
                Ea: !0
            }
        }).set("addtl_consent", {
            value: fx(c, 4)
        }).set("tcfe", {
            value: gx(c, 7)
        }).set("us_privacy", {
            value: fx(c, 1)
        }).set("npa", {
            value: _.N(c, 6) || _.N(a, 8) ? 1 : null
        }).set("puo", {
            value: _.G(YB) && _.N(a, 13) ? 1 : null
        }).set("tfua", {
            value: 2 !== d ? d : null,
            options: {
                Ea: !0
            }
        }).set("tfcd", {
            value: null != mo(a, 5) ? _.Nk(a, 5, 0) : null,
            options: {
                Ea: !0
            }
        }).set("trt", {
            value: null != mo(a, 10) ? _.Nk(a, 10, 0) : null,
            options: {
                Ea: !0
            }
        }).set("tad", {
            value: null != Yl(c, 8) ? _.N(c, 8) ? "1" : "0" : null,
            options: {
                Ea: !0
            }
        }).set("gpp", {
            value: fx(c, 11)
        });
        a = b.set;
        c = Zw(c, 10);
        a.call(b, "gpp_sid", {
            value: c.join(",") || void 0
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.O,
            e = c.X,
            f = c.gg,
            g = a.ha.A;
        a = {
            za: "~"
        };
        var h = e.map(function(l) {
                return d.R[l.getDomId()]
            }),
            k = [];
        c = e.map(function(l) {
            return l.getAdUnitPath().replace(/,/g, ":").split("/").map(function(m) {
                if (!m) return "";
                var n = _.A(k, "findIndex").call(k, function(p) {
                    return p === m
                });
                return 0 <= n ? n : k.push(m) - 1
            }).join("/")
        });
        b.set("iu_parts", {
            value: k
        }).set("enc_prev_ius", {
            value: c
        }).set("prev_iu_szs", {
            value: h.map(function(l) {
                return mi(l)
            })
        }).set("fluid", {
            value: function() {
                var l = !1,
                    m = h.map(function(n) {
                        n = (_.H = li(n), _.A(_.H, "includes")).call(_.H, "fluid");
                        l || (l = n);
                        return n ? "height" : "0"
                    });
                return l ? m : null
            }()
        }).set("ifi", {
            value: function() {
                var l = mj(g);
                if (!f) {
                    l += 1;
                    var m = g,
                        n = e.length;
                    n = void 0 === n ? 1 : n;
                    m = Wz(kf(m)) || m;
                    m.google_unique_id = (m.google_unique_id || 0) + n
                }
                return l
            }()
        }).set("didk", {
            value: _.G(cC) ? Ho(e, function(l) {
                return _.hg(l.getDomId())
            }, a) : null,
            options: _.A(Object, "assign").call(Object, {}, a, {
                Lb: !0
            })
        })
    }, function(a, b) {
        var c = a.ia;
        a = c.X;
        c = c.O;
        var d = c.W,
            e = c.R;
        b.set("sfv", {
            value: eK ? eK : eK = Ll()
        }).set("fsfs", {
            value: Ho(a, function(f) {
                f = e[f.getDomId()];
                var g;
                return Number(null != (g = null == f ? void 0 : Mo(f, 12)) ? g : Yl(d, 13))
            }, {
                qd: 0
            }),
            options: {
                za: ",",
                ld: 0,
                Lb: !0
            }
        }).set("fsbs", {
            value: Ho(a, function(f) {
                f = e[f.getDomId()].kc();
                var g = d.kc(),
                    h;
                return (null != (h = null == f ? void 0 : Mo(f, 3)) ? h : null == g ? 0 : _.N(g, 3)) ? 1 : 0
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Lb: !0
            }
        })
    }, function(a, b) {
        var c = a.ha.K;
        a = a.ia;
        var d = a.gg;
        b.set("rcs", {
            value: Ho(a.X, function(e) {
                if (!d) {
                    var f = c.g.get(e);
                    f && f.Di++
                }
                return II(c, e)
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Lb: !0
            }
        })
    }, function(a, b) {
        var c = a.ia;
        a = a.ha.eb;
        c = c.O.R[c.X[0].getDomId()];
        b.set("click", {
            value: !a && c.getClickUrl() ? _.Gj(c, 7) : null
        })
    }, function(a, b, c) {
        var d = a.ia,
            e = d.X,
            f = d.O.R;
        a = a.ha;
        var g = a.V,
            h = a.A;
        c = void 0 === c ? function(n, p) {
            return Vf(n, p)
        } : c;
        a = e.map(function(n) {
            return f[n.getDomId()]
        });
        var k, l, m;
        b.set("ists", {
            value: Eo(a, function(n) {
                var p;
                if (p = 0 !== Qs(n)) n = Qs(n), p = !(8 === n || 9 === n);
                return p
            }) || null
        }).set("fas", {
            value: Ho(a, function(n) {
                return cp(Qs(n))
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Lb: !0
            }
        }).set("itsi", {
            value: e.some(function(n) {
                var p;
                return !vL(n) && 5 === (null == (p = f[n.getDomId()]) ? void 0 : Qs(p))
            }) ? function() {
                var n = c(g, h);
                if (!n) return 1;
                var p;
                n = Math.max.apply(Math, _.oh(null != (p = _.ap(n, 604800)) ? p : []));
                return isFinite(n) ? Math.floor(Math.max((Date.now() - n) / 6E4, 1)) : null
            }() : null
        }).set("fsapi", {
            value: Eo(a, function(n) {
                return 5 === Qs(n) && _.G(_.HB)
            }) || null
        }).set("ifs", {
            value: null != (m = null == (k = (_.H = _.A(Object, "values").call(Object, f), _.A(_.H, "find")).call(_.H, function(n) {
                return Mn(n, tK, 29)
            })) ? void 0 : null == (l = _.di(k, tK, 29)) ? void 0 : Gk(l)) ? m : null
        })
    }, function(a, b) {
        a = a.ia;
        var c = a.O.R;
        a = a.X.map(function(d) {
            return c[d.getDomId()]
        });
        b.set("rbvs", {
            value: Eo(a, function(d) {
                return 4 === Qs(d)
            }) || null
        })
    }, function(a, b) {
        var c = a.ia,
            d = a.ha;
        a = d.isSecureContext;
        d = d.A;
        var e = b.set;
        var f = c.X;
        var g = c.O;
        c = c.Qb;
        var h = g.W,
            k = g.R,
            l = new fj;
        l.set(0, 1 !== c);
        k = k[f[0].getDomId()];
        l.set(1, !!_.N(k, 17));
        l.set(2, Hp(f, g));
        l.set(3, _.N(h, 27) || !1);
        l.set(4, 3 === c);
        f = hj(l);
        e.call(b, "eri", {
            value: f
        }).set("gct", {
            value: Cp("google_preview", d)
        }).set("sc", {
            value: a ? 1 : 0,
            options: {
                Ea: !0
            }
        })
    }, function(a, b) {
        var c = a.ha,
            d = c.A,
            e = c.V;
        c = c.xa;
        var f = Ep(a.ia.O.W.Ma()),
            g = _.am(c, "__gads", e);
        a = "1" === _.am(c, "__gpi_opt_out", e) ? "1" : null;
        b = b.set("cookie", {
            value: g,
            options: {
                Ea: !0
            }
        }).set("cookie_enabled", {
            value: !g && jF(c, e) ? "1" : null
        });
        g = d.document;
        var h = g.domain;
        d = b.set.call(b, "cdm", {
            value: (f || si(d)) === g.URL ? "" : h
        });
        f = d.set;
        e = (e = _.am(c, "__gpi", e)) && !_.A(e, "includes").call(e, "&") ? e : null;
        f.call(d, "gpic", {
            value: e
        }).set("pdopt", {
            value: a
        })
    }, function(a, b) {
        a = a.ha.A;
        b.set("arp", {
            value: Bn(a) ? 1 : null
        }).set("abxe", {
            value: _.tk(a.top) || Dz(a.IntersectionObserver) ? 1 : null
        })
    }, function(a, b) {
        var c = a.ha.A;
        a = Ep(a.ia.O.W.Ma());
        b.set("dt", {
            value: (new Date).getTime()
        });
        if (!a) {
            try {
                var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
            } catch (e) {
                d = null
            }
            b.set("lmt", {
                value: d
            })
        }
    }, function(a, b) {
        var c = a.ia,
            d = c.O;
        c = c.X;
        var e = a.ha;
        a = e.A;
        var f = e.eb;
        e = ki(!0, a);
        for (var g = d.W, h = a.document, k = d.R, l = [], m = [], n = _.z(c), p = n.next(); !p.done; p = n.next()) {
            p = p.value;
            var r = k[p.getDomId()];
            p = Ri(p, r, h, No(g, r));
            r = void 0;
            var w = f ? null != (r = p) ? r : pO : p;
            w && (l.push(Math.round(w.x)), m.push(Math.round(w.y)))
        }
        e && (d.dd = e);
        f = ri(a) ? null : ki(!1, a);
        try {
            var u = a.top;
            var x = vt(u.document, u)
        } catch (y) {
            x = new _.ui(-12245933, -12245933)
        }
        b.set("adxs", {
            value: l,
            options: {
                Ea: !0
            }
        }).set("adys", {
            value: m,
            options: {
                Ea: !0
            }
        }).set("biw", {
            value: e ? e.width : null
        }).set("bih", {
            value: e ? e.height : null
        }).set("isw", {
            value: e ? null == f ? void 0 : f.width : null
        }).set("ish", {
            value: e ? null == f ? void 0 : f.height : null
        }).set("scr_x", {
            value: Math.round(x.x),
            options: {
                Ea: !0
            }
        }).set("scr_y", {
            value: Math.round(x.y),
            options: {
                Ea: !0
            }
        }).set("btvi", {
            value: xt(c, a, d),
            options: {
                Ea: !0,
                za: "|"
            }
        })
    }, function(a, b) {
        var c = a.ha.K;
        b.set("ucis", {
            value: a.ia.X.map(function(d) {
                d = c.g.get(d);
                null != d.ae || (d.ae = window === window.top ? (++c.L).toString(36) : Xy());
                return d.ae
            }),
            options: {
                za: "|"
            }
        }).set("oid", {
            value: 2
        })
    }, function(a, b) {
        a = a.ia;
        var c = a.X,
            d = a.O,
            e = d.R;
        a = new _.v.Map;
        d = _.z(d.W.Ma());
        for (var f = d.next(); !f.done; f = d.next()) {
            var g = f.value;
            a.set(_.R(g, 1), [pl(g)[0]])
        }
        for (d = 0; d < c.length; d++)
            if (g = e[c[d].getDomId()])
                for (g = _.z(g.Ma()), f = g.next(); !f.done; f = g.next()) {
                    var h = f.value;
                    f = _.R(h, 1);
                    var k = a.get(f) || [];
                    h = pl(h)[0];
                    1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                    a.set(f, k)
                }
        c = [];
        e = _.z(_.A(a, "keys").call(a));
        for (d = e.next(); !d.done; d = e.next()) g = d.value, d = El()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
            return encodeURIComponent(l || "")
        }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
            value: g[0]
        }));
        c.length && b.set("sps", {
            value: c,
            options: {
                za: "|"
            }
        })
    }, function(a, b) {
        a = a.ha.A;
        var c, d, e, f, g, h, k;
        var l = a;
        l = void 0 === l ? Ny : l;
        try {
            var m = l.history.length
        } catch (D) {
            m = 0
        }
        b = b.set("u_his", {
            value: m
        }).set("u_h", {
            value: null == (c = a.screen) ? void 0 : c.height
        }).set("u_w", {
            value: null == (d = a.screen) ? void 0 : d.width
        }).set("u_ah", {
            value: null == (e = a.screen) ? void 0 : e.availHeight
        }).set("u_aw", {
            value: null == (f = a.screen) ? void 0 : f.availWidth
        }).set("u_cd", {
            value: null == (g = a.screen) ? void 0 : g.colorDepth
        });
        c = b.set;
        d = a;
        d = void 0 === d ? _.t : d;
        d = d.devicePixelRatio;
        c = c.call(b, "u_sd", {
            value: "number" === typeof d ? +d.toFixed(3) : null
        }).set("u_tz", {
            value: -(new Date).getTimezoneOffset()
        }).set("dmc", {
            value: null != (k = null == (h = a.navigator) ? void 0 : h.deviceMemory) ? k : null
        });
        h = c.set;
        k = a;
        k = void 0 === k ? _.t : k;
        d = new fj;
        "SVGElement" in k && "createElementNS" in k.document && d.set(0);
        e = Cz();
        e["allow-top-navigation-by-user-activation"] && d.set(1);
        e["allow-popups-to-escape-sandbox"] && d.set(2);
        k.crypto && k.crypto.subtle && d.set(3);
        "TextDecoder" in k && "TextEncoder" in k && d.set(4);
        k = hj(d);
        h = h.call(c, "bc", {
            value: k
        });
        k = h.set;
        a: {
            try {
                var n, p, r = null == (n = a.performance) ? void 0 : null == (p = n.getEntriesByType("navigation")) ? void 0 : p[0];
                if (null == r ? 0 : r.type) {
                    var w;
                    var u = null != (w = uF.get(r.type)) ? w : null;
                    break a
                }
            } catch (D) {}
            var x, y, C;u = null != (C = vF.get(null == (x = a.performance) ? void 0 : null == (y = x.navigation) ? void 0 : y.type)) ? C : null
        }
        u = k.call(h, "nvt", {
            value: u
        });
        n = u.set;
        p = _.$e(kB);
        p = 0 === p ? null : Qz(a, 2 === p);
        u = n.call(u, "bz", {
            value: p
        });
        n = u.set;
        _.G(eC) ? a = Na() && Ok(a) ? a.document.documentElement.lang : void 0 : a = null;
        n.call(u, "tl", {
            value: a
        })
    }, function(a, b) {
        (a = _.qi(251)) && b.set("uach", {
            value: Aw(a, 3)
        })
    }, function(a, b) {
        a = a.ha;
        if (!a.Db) {
            var c;
            if (a = null == (c = a.A.navigator) ? void 0 : c.userActivation) {
                c = 0;
                if (null == a ? 0 : a.hasBeenActive) c |= 1;
                if (null == a ? 0 : a.isActive) c |= 2
            } else c = void 0;
            c && b.set("uas", {
                value: c
            })
        }
    }, function(a, b) {
        var c = a.ha,
            d = c.A,
            e = c.K;
        c = c.eb;
        a = a.ia;
        var f = a.X;
        a = a.O;
        var g = a.W,
            h = a.R;
        a = Dp("google_preview", d);
        var k = d.document,
            l = a ? Fp(k.URL) : k.URL;
        k = a ? Fp(k.referrer) : k.referrer;
        a = !1;
        if (c) c = Ep(g.Ma());
        else {
            var m;
            c = null != (m = Ep(h[f[0].getDomId()].Ma())) ? m : Ep(g.Ma())
        }
        if (null != c) {
            var n = l;
            ri(d) || (k = "", a = !0)
        } else c = l;
        m = Gp(d);
        b.set("nhd", {
            value: m || null
        }).set("url", {
            value: c
        }).set("loc", {
            value: null !== n && n !== c ? n : null
        }).set("ref", {
            value: k
        });
        if (m) {
            n = b.set;
            var p, r;
            m = _.tk(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
            var w;
            p = null == (w = d.location) ? void 0 : w.ancestorOrigins;
            d = Sk(d) || "";
            w = (null == p ? void 0 : p[p.length - 1]) || "";
            d = (d = m || d || w) ? a ? rz(d.match(_.qz)[3] || null) : d : null;
            n.call(b, "top", {
                value: d
            }).set("etu", {
                value: e.te
            })
        }
    }, function(a, b) {
        a = a.ha.context.pvsid;
        b.set("rumc", {
            value: _.G(AC) || _.Ye(Nh).g ? a : null
        }).set("rume", {
            value: _.G(zC) ? 1 : null
        })
    }, function(a, b) {
        b.set("vis", {
            value: _.sq(a.ha.A.document)
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.X;
        c = c.O;
        a = a.ha.A;
        var e = On(d, c.R, c.W),
            f = Rn(d, e, a);
        c = f.el;
        f = f.Ul;
        var g = Un(d, e, a),
            h = g.tk;
        g = g.dl;
        null != SK || (SK = Uk(a));
        var k = !1;
        d = d.map(function(m) {
            var n;
            m = null != (n = e.get(m)) ? n : 0;
            if (0 === m) return null;
            k = !0;
            return 2 === m ? "1" : "0"
        });
        var l;
        b.set("aee", {
            value: k ? d : null,
            options: {
                za: "|"
            }
        }).set("psz", {
            value: c,
            options: {
                za: "|"
            }
        }).set("msz", {
            value: f,
            options: {
                za: "|"
            }
        }).set("fws", {
            value: h,
            options: {
                Ea: !0
            }
        }).set("ohw", {
            value: g,
            options: {
                Ea: !0
            }
        }).set("ea", {
            value: SK ? null : "0",
            options: {
                Ea: !0
            }
        }).set("efat", {
            value: "#flexibleAdSlotTest" === (null == (l = a.location) ? void 0 : l.hash) ? "1" : null
        })
    }, function(a, b) {
        b.set("psts", {
            value: HI(a.ha.K, a.ia.X)
        })
    }, function(a, b) {
        var c = a.ha;
        a = c.V;
        c = c.A;
        var d;
        var e = c.document.domain,
            f = null != (d = Uf(a) && Wf(c) ? c.document.cookie : null) ? d : "",
            g = c.history.length,
            h = c.screen,
            k = c.document.referrer;
        if (kf()) var l = window.gaGlobal || {};
        else {
            var m = Math.round((new Date).getTime() / 1E3),
                n = c.google_analytics_domain_name;
            e = "undefined" == typeof n ? CE("auto", e) : CE(n, e);
            var p = -1 < f.indexOf("__utma=" + e + "."),
                r = -1 < f.indexOf("__utmb=" + e);
            (d = (Wz() || window).gaGlobal) || (d = {}, (Wz() || window).gaGlobal = d);
            var w = !1;
            if (p) {
                var u = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                r ? d.sid = u[3] : d.sid || (d.sid = m + "");
                d.vid = u[0] + "." + u[1];
                d.from_cookie = !0
            } else {
                d.sid || (d.sid = m + "");
                if (!d.vid) {
                    w = !0;
                    r = Math.round(2147483647 * Math.random());
                    p = AE.appName;
                    var x = AE.version,
                        y = AE.language ? AE.language : AE.browserLanguage,
                        C = AE.platform,
                        D = AE.userAgent;
                    try {
                        u = AE.javaEnabled()
                    } catch (E) {
                        u = !1
                    }
                    u = [p, x, y, C, D, u ? 1 : 0].join("");
                    h ? u += h.width + "x" + h.height + h.colorDepth : _.t.java && _.t.java.awt && (h = _.t.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), u += h.screen.width + "x" + h.screen.height);
                    u = u + f + (k || "");
                    for (k = u.length; 0 < g;) u += g-- ^ k++;
                    d.vid = (r ^ BE(u) & 2147483647) + "." + m
                }
                d.from_cookie || (d.from_cookie = !1)
            }
            if (!d.cid) {
                b: for (m = 999, n && (n = 0 == n.indexOf(".") ? n.substr(1) : n, m = n.split(".").length), n = 999, f = f.split(";"), u = 0; u < f.length; u++)
                    if (k = DE.exec(f[u]) || EE.exec(f[u]) || FE.exec(f[u])) {
                        h = k[1] || 0;
                        if (h == m) {
                            l = k[2];
                            break b
                        }
                        h < n && (n = h, l = k[2])
                    }w && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
            }
            d.dh = e;
            d.hid || (d.hid = Math.round(2147483647 * Math.random()));
            l = d
        }
        e = l.sid;
        d = l.hid;
        w = l.from_cookie;
        f = l.cid;
        w && !Uf(a) || b.set("ga_vid", {
            value: l.vid
        }).set("ga_sid", {
            value: e
        }).set("ga_hid", {
            value: d
        }).set("ga_fc", {
            value: w
        }).set("ga_cid", {
            value: f
        }).set("ga_wpids", {
            value: c.google_analytics_uacct
        })
    }, function(a, b) {
        var c = a.ha.A,
            d = a.jm;
        a = d.Gg;
        var e = d.Be;
        d = d.Rl;
        if (!_.G(CC) && !d) {
            dg(c.isSecureContext, c.navigator, c.document) && b.set("td", {
                value: 1
            });
            if (a) switch (a.kind) {
                case 0:
                    b.set("eig", {
                        value: a.signal
                    });
                    break;
                case 1:
                    b.set("eigir", {
                        value: a.reason,
                        options: {
                            Ea: !0
                        }
                    });
                    break;
                default:
                    _.eb(a)
            }
            void 0 !== e && b.set("egid", {
                value: e,
                options: {
                    Ea: !0
                }
            })
        }
    }, function(a, b) {
        var c = a.ha.A,
            d = a.Zl;
        a = d.cm;
        d = d.am;
        eg(c.isSecureContext, c.document) && (b.set("topics", {
            value: a instanceof Uint8Array ? Bb(a, 3) : a
        }), !a || a instanceof Uint8Array || b.set("tps", {
            value: a
        }), d && b.set("htps", {
            value: d
        }))
    }, function(a, b) {
        var c = a.ha,
            d = c.A,
            e = c.V,
            f = a.ia.X;
        c = a.Jl;
        a = c.af;
        var g = c.ik,
            h = c.Yk;
        if (!_.G(tB)) {
            c = b.set;
            d = Vf(e, d);
            f = qh(f[0].getAdUnitPath());
            e = new ry;
            g = null != g ? g : [];
            if (f && a && g && "function" === typeof a.getUserIdsAsEidBySource) {
                if ("function" === typeof a.getUserIdsAsEids) try {
                    for (var k = _.z(a.getUserIdsAsEids()), l = k.next(); !l.done; l = k.next()) {
                        var m = l.value;
                        "string" === typeof m.source && Cj(52, m.source)
                    }
                } catch (w) {
                    var n;
                    Cj(45, "", null == (n = w) ? void 0 : n.message)
                }
                k = _.z(g);
                for (l = k.next(); !l.done; l = k.next())
                    if (l = l.value, String(_.R(l, 1)) === f)
                        for (l = _.z(_.gi(l, Kx, 2)), m = l.next(); !m.done; m = l.next())
                            if (m = m.value, _.N(m, Mk(m, Lx, 3)) && (m = _.R(m, 1), !Hj(e, m))) {
                                n = null;
                                try {
                                    var p = g = void 0,
                                        r = void 0;
                                    n = null == (g = a.getUserIdsAsEidBySource(m)) ? void 0 : null == (p = g.uids) ? void 0 : null == (r = p[0]) ? void 0 : r.id
                                } catch (w) {
                                    g = void 0, Cj(45, m, null == (g = w) ? void 0 : g.message)
                                }
                                n && (300 < n.length ? (g = {}, Cj(12, m, null, (g.sl = String(n.length), g.fp = "1", g))) : (g = my(m), g = Zn(g, 2, n), g = Lj(g, 11, !0), Mj(e, 2, Fj, g), g = {}, Cj(19, m, null, (g.fp = "1", g.hs = n ? "1" : "0", g))))
                            }
            }
            Nj(e, d, f, h);
            _.gi(e, Fj, 2).length ? (Cj(50, ""), a = Bb(e.g(), 3)) : a = null;
            c.call(b, "a3p", {
                value: a
            })
        }
    }, function(a, b) {
        var c = a.gb.ge,
            d = a.ia.X;
        a = {
            za: "~"
        };
        var e = function() {
            return c ? d.map(function(f) {
                return c.get(f)
            }) : []
        }();
        b.set("cbidsp", {
            value: Ho(e, function(f) {
                return Bb(f.g(), 3)
            }, a),
            options: _.A(Object, "assign").call(Object, {}, a, {
                Lb: !0
            })
        })
    }, function(a, b) {
        a = a.ia.O.W;
        if (Mn(a.He(), vs, 1)) {
            a = us(a.He(), vs, 1);
            b = b.set("cmrv", {
                value: 1
            }).set("cmrq", {
                value: _.R(a, 1)
            }).set("cmrc", {
                value: _.xo(a, 2, 2),
                options: {
                    za: ">"
                }
            });
            var c = b.set;
            var d = _.xo(a, 3, 2);
            c.call(b, "cmrids", {
                value: d,
                options: {
                    za: "!"
                }
            }).set("cmrf", {
                value: _.R(a, 4)
            })
        }
    }, function(a, b) {
        var c = [];
        a = _.z(_.gi(us(a.ia.O.W.He(), xs, 2), jq, 1));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.xo(d, 2, 2).length && c.push(_.Nk(d, 1, 0) + 2 + "=" + _.xo(d, 2, 2).join("|"));
        b.set("pps", {
            value: c,
            options: {
                za: "~"
            }
        })
    }, function(a, b) {
        b.set("scar", {
            value: a.il.Ck
        })
    }, function(a, b) {
        a = a.ha.A;
        a = !(!a.isSecureContext || !cg("attribution-reporting", a.document));
        !_.G(yC) && a && b.set("nt", {
            value: 1
        })
    }, function(a, b) {
        if (a = a.ul.tl) a = Aw(Gk(a), 3), b.set("psd", {
            value: a
        })
    }, function(a, b) {
        a = _.ah(a.ha.A);
        var c = Ip;
        0 < a && c >= a && b.set("dlt", {
            value: a
        }).set("idt", {
            value: c - a
        })
    }, function(a, b) {
        a = a.ia.O.W;
        b.set("ppid", {
            value: null != _.Gj(a, 16) ? _.R(a, 16) : null,
            options: {
                Ea: !0
            }
        })
    }, function(a, b) {
        var c = b.set;
        (a = _.Gj(a.ia.O.W, 8)) ? (50 < a.length && (a = a.substring(0, 50)), a = "a " + Aw('role:1 producer:12 loc:"' + a + '"')) : a = "";
        c.call(b, "uule", {
            value: a
        })
    }, function(a, b) {
        a = a.ia;
        var c = a.O.W;
        b.set("prev_scp", {
            value: ar(a.X, a.O),
            options: {
                Lb: !0,
                za: "|"
            }
        }).set("cust_params", {
            value: cr(c),
            options: {
                za: "&"
            }
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.O;
        a = a.ha;
        var e = a.K,
            f = a.eb;
        b.set("adks", {
            value: c.X.map(function(g) {
                if (f) {
                    var h = d.R[g.getDomId()];
                    h = wn(h);
                    if (g = e.g.get(g)) g.fd = h;
                    return h
                }
                h = d.W;
                var k = d.R[g.getDomId()],
                    l;
                if (!(l = pt(e, g))) {
                    h = wn(k, _.N(h, 6) || _.N(k, 17) ? null : Li(g));
                    if (g = e.g.get(g)) g.fd = h;
                    l = h
                }
                return l
            })
        })
    }, function(a, b) {
        var c = b.set;
        a = a.ha.A;
        var d = Pz(a);
        var e = Tk(a, a.google_ad_width, a.google_ad_height);
        var f = d.location.href;
        if (d === d.top) f = !0;
        else {
            var g = !1,
                h = d.document;
            h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
            (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1);
            f = g
        }
        g = a.top == a ? 0 : _.tk(a.top) ? 1 : 2;
        d = 4;
        e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
        f && (d |= 16);
        e = "" + d;
        if (a != a.top)
            for (; a && a != a.top && _.tk(a) && !a.sf_ && !a.$sf && !a.inGptIF && !a.inDapIF; a = a.parent);
        c.call(b, "frm", {
            value: e || null
        })
    }, function(a, b) {
        var c = b.set;
        a = us(a.ia.O.W, zs, 36);
        a = be(a, 1, Oc, 2);
        c.call(b, "ppt", {
            value: a,
            options: {
                za: "~"
            }
        })
    }, function(a, b) {
        a = a.ha.A;
        try {
            var c, d, e = null == (c = a.external) ? void 0 : null == (d = c.getHostEnvironmentValue) ? void 0 : d.call(c, "os-mode");
            if (e) {
                var f = Number(JSON.parse(e)["os-mode"]);
                0 > f || b.set("wsm", {
                    value: f + 1
                })
            }
        } catch (g) {}
    }, function(a, b) {
        var c = a.ia;
        a = c.O.R;
        var d = [],
            e = !1;
        c = _.z(c.X);
        for (var f = c.next(); !f.done; f = c.next()) {
            var g = void 0;
            (null == (g = a[f.value.getDomId()]) ? 0 : _.N(g, 30)) ? (d.push("1"), e = !0) : d.push("")
        }
        b.set("is_cau", {
            value: e ? d : null
        })
    }, function(a, b) {
        var c = a.ia,
            d = c.O.R;
        a = a.ha.A;
        var e = [],
            f = !1;
        c = _.z(c.X);
        for (var g = c.next(); !g.done; g = c.next()) g = Qs(d[g.value.getDomId()]), (_.H = [8, 9], _.A(_.H, "includes")).call(_.H, g) ? (f = 9 === g ? "right" : "left", e.push(_.mh(a).sideRailPlasParam.get(f)), f = !0) : e.push("");
        f && b.set("plas", {
            value: e,
            options: {
                za: "|"
            }
        })
    }, function(a, b) {
        var c = a.ha,
            d = c.A;
        c = c.V;
        var e = a.ia,
            f = e.O.W;
        e = e.networkCode;
        a = a.fk.gk;
        if (_.G(nB)) {
            a = a ? !je(a, 1, pd).get(e) : _.G(oB);
            var g;
            f = !(null == (g = Gt(f)) || !_.N(g, 9));
            d = new NE(d, {
                yl: a,
                xl: f
            });
            d = _.N(c, 8) || (d.options.xl || !Uf(c)) && d.options.yl ? void 0 : (new Xf(d.g.document)).get("__eoi") || "";
            d && b.set("eo_id_str", {
                value: d
            })
        }
    }]);
    var qO = function(a, b, c) {
        Z.call(this, a, 798);
        this.output = V(this);
        this.j = Y(this, b);
        this.o = W(this, c)
    };
    _.T(qO, Z);
    qO.prototype.g = function() {
        var a = this,
            b = new _.v.Map;
        if (this.j.value) {
            var c = this.j.value,
                d = c.ha.eb,
                e = c.gb.ge;
            c = _.z(c.ia.X);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? rO(this, f, h) : function() {
                    return a.o.value
                })
            }
        }
        this.output.D(b)
    };
    var rO = function(a, b, c) {
        return Mi(function() {
            var d = _.A(Object, "assign").call(Object, {}, a.j.value);
            d.ia.gg = !0;
            d.ia.X = [b];
            c && (d.gb.ge = new _.v.Map, d.gb.ge.set(b, c));
            return Bp(Ft(d)).url
        })
    };
    var sO = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.o = b;
        this.eb = c;
        this.O = d;
        this.P = e;
        this.A = f;
        this.V = g;
        this.j = V(this)
    };
    _.T(sO, Z);
    sO.prototype.g = function() {
        var a = this,
            b = this.o;
        !this.eb && 1 < this.o.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.J) return !1;
            var d = a.O.R[c.getDomId()],
                e;
            if (e = !(gp(Qs(d)) && (_.H = bf(QB), _.A(_.H, "includes")).call(_.H, String(Qs(d))))) e = a.P, Hg(a.A) && 4 === Qs(d) ? (Q(e, uJ("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            if (e) {
                e = a.P;
                var f = a.A,
                    g = a.V;
                d = Qs(d);
                5 !== d ? c = !1 : (f = bp(f, !vL(c), g), (f &= -134217729) && Ro(e, f, d, c.getAdUnitPath()), c = !!f);
                e = !c
            }
            return e
        });
        30 < b.length && (Q(this.P, tJ("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        this.j.D(b)
    };
    var tO = function(a, b, c) {
        Z.call(this, a, 919);
        this.j = b;
        this.V = c;
        this.output = V(this)
    };
    _.T(tO, Z);
    tO.prototype.g = function() {
        var a, b = !(null == (a = this.j) ? 0 : _.N(a, 9)) && !!Uf(this.V);
        this.output.D(b)
    };
    var uO = function(a, b, c, d, e, f) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.B = f;
        this.output = lG(this);
        this.o = W(this, c);
        e && (this.j = W(this, e));
        nG(this, d)
    };
    _.T(uO, Z);
    var vO = function(a) {
        return a.j ? a.B.split(",").some(function(b) {
            var c;
            return null == (c = a.j) ? void 0 : c.value.has(b)
        }) : !1
    };
    uO.prototype.g = function() {
        var a = this.context,
            b = this.requestId,
            c = this.o.value.length,
            d = vO(this);
        if (a.yc) {
            var e = a.Ga,
                f = e.xc;
            a = xh(a);
            var g = new TA;
            b = _.th(g, 2, b);
            c = _.Bh(b, 1, c);
            d = _.Ah(c, 3, d);
            d = _.Ch(a, 7, Dh, d);
            f.call(e, d)
        }
        this.output.notify()
    };
    var wO = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.ra = b;
        this.O = c;
        this.output = lG(this);
        this.j = W(this, d)
    };
    _.T(wO, Z);
    wO.prototype.g = function() {
        for (var a = _.z(this.j.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.z(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = fi(this.O.R[b.getDomId()], 20);
            Mr(b, uI, 808, {
                Rj: c,
                Gl: d
            });
            Mr(this.ra, "slotRequested", 705, new $L(b, "publisher_ads"))
        }
        this.output.notify()
    };
    var xO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X, ba, la, ra, Aa, ya, Pa, Fa, Cb, bb, yb) {
        Z.call(this, a, 785, _.$e(dC));
        this.eb = b;
        this.K = c;
        this.xa = d;
        this.O = e;
        this.Xe = f;
        this.Qb = g;
        this.networkCode = h;
        this.cd = k;
        this.bd = l;
        this.Wf = m;
        this.kd = n;
        this.timer = p;
        this.V = r;
        this.isSecureContext = w;
        this.Db = u;
        this.A = x;
        this.j = V(this);
        this.o = V(this);
        this.T = V(this);
        nG(this, K);
        this.Ia = mG(this, y);
        this.F = mG(this, C);
        this.I = W(this, D);
        J && (this.B = _.G(hC) ? new bG(J.Zc) : mG(this, J.Zc), J.Yd && (this.ic = Y(this, J.Yd)));
        M && (this.M = _.G(hC) ? new bG(M.Ac) : mG(this, M.Ac));
        nG(this, K);
        X && (this.Va = W(this, X));
        ba && (this.ba = new bG(ba));
        la && (this.Pa = Y(this, la));
        ra && (this.la = W(this, ra));
        Aa && nG(this, Aa);
        ya && (this.Da = W(this, ya));
        E && (this.ca = Y(this, E));
        Pa && (this.Yb = Y(this, Pa.Dg));
        Fa && (this.jc = W(this, Fa));
        Cb && (this.oa = Y(this, Cb));
        bb && (this.da = Y(this, bb));
        yb && (this.bc = W(this, yb))
    };
    _.T(xO, Z);
    xO.prototype.g = function() {
        if (this.I.value.length) {
            var a = null;
            if (this.B) {
                var b = this.B.value;
                a = b ? b : this.M && !this.M.yb() ? 9 : this.B.yb() ? null : 1
            }
            this.F.value && (this.K.te = this.F.value);
            var c, d, e, f, g, h, k, l, m, n, p, r, w, u;
            b = {
                ha: {
                    A: this.A,
                    context: this.context,
                    K: this.K,
                    xa: this.xa,
                    V: this.V,
                    eb: this.eb,
                    Wf: this.Wf,
                    isSecureContext: this.isSecureContext,
                    Db: this.Db
                },
                ia: {
                    networkCode: this.networkCode,
                    X: this.I.value,
                    O: this.O,
                    Qb: this.Qb,
                    gg: !1
                },
                om: {
                    cd: this.cd,
                    bd: this.bd
                },
                il: {
                    Ck: null != (w = this.Ia.value) ? w : "0"
                },
                cj: {
                    Xe: this.Xe,
                    kd: this.kd
                },
                gb: {
                    ge: null == (c = this.ca) ? void 0 : c.value
                },
                Zl: {
                    cm: a,
                    am: null == (d = this.ic) ? void 0 : d.value
                },
                Jl: {
                    Yk: null != (u = null == (e = this.Va) ? void 0 : e.value) ? u : void 0,
                    af: null == (f = this.ba) ? void 0 : f.value,
                    ik: null == (g = this.la) ? void 0 : g.value
                },
                zl: {
                    Dk: null == (h = this.Pa) ? void 0 : h.value,
                    yk: null == (k = this.Da) ? void 0 : k.value
                },
                ul: {
                    tl: null == (l = this.Yb) ? void 0 : l.value
                },
                jm: {
                    Gg: null == (m = this.jc) ? void 0 : m.value,
                    Be: null == (n = this.oa) ? void 0 : n.value,
                    Rl: null == (p = this.bc) ? void 0 : p.value
                },
                fk: {
                    gk: null == (r = this.da) ? void 0 : r.value
                }
            };
            this.o.D(b);
            c = Bp(Ft(b));
            d = c.url;
            WG(this.timer, (9).toString(), 9, c.eh);
            this.j.D(d);
            this.T.D(At(b) ? cv("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : cv("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}"))
        } else this.j.D(""), this.o.Z()
    };
    var yO = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.j = b;
        this.U = c;
        this.O = d;
        this.A = e;
        this.output = lG(this);
        f && nG(this, f)
    };
    _.T(yO, Z);
    yO.prototype.g = function() {
        for (var a = _.z(this.j), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = Li(b, this.U);
            if (!Ki(b, this.U) && c) {
                a: {
                    var d = c;
                    var e = this.O.R[b.getDomId()],
                        f = 0,
                        g = 0;e = _.z(li(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.z(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), Ln(Ni(d, this.A)) || !d.parentElement || Ln(Ni(d.parentElement, this.A))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.O;f = g.W;g = g.R[b.getDomId()];Kn(c, Ti(b), No(f, g), d)
            }
        }
        this.output.notify()
    };
    var zO = function(a, b, c, d, e, f, g) {
            this.j = a;
            this.H = b;
            this.J = c;
            this.X = d;
            this.V = e;
            this.L = f;
            this.G = g;
            this.v = "";
            this.l = -1;
            this.g = 1;
            this.m = ""
        },
        BO = function(a, b) {
            if (b)
                if (1 !== a.g && 2 !== a.g) AO(a, new ZE("state err: (" + ([a.g, a.m.length].join() + ")")));
                else {
                    a.m && (b = a.m + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.g) f.v = c, ++f.l, f.g = 2;
                        else {
                            try {
                                f.j(f.l, f.v, {
                                    kind: 0,
                                    vb: Lz(c)
                                }, f.X, f.V, f.L, f.G), f.v = ""
                            } catch (g) {}
                            f.g = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.m = b.substr(c)
                }
        },
        AO = function(a, b) {
            a.g = 4;
            try {
                a.H(b)
            } catch (c) {}
        },
        CO = function(a) {
            1 !== a.g || a.m ? AO(a, new ZE("state err (" + ([a.g, a.m.length].join() + ")"))) : (a.g = 3, a.J(a.l, a.X, a.V))
        };
    var DO = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 788);
        this.T = b;
        this.M = c;
        this.I = d;
        this.V = e;
        this.K = f;
        this.O = g;
        this.output = lG(this);
        this.F = 0;
        this.B = !1;
        this.j = null != p ? p : new XMLHttpRequest;
        this.o = W(this, h);
        k && (this.ca = Y(this, k));
        this.da = W(this, l);
        nG(this, m);
        this.ba = W(this, n)
    };
    _.T(DO, Z);
    DO.prototype.g = function() {
        var a = this,
            b = this.da.value;
        if (b) {
            var c, d = new zO(this.T, this.M, this.I, this.o.value, this.V, null == (c = this.ca) ? void 0 : c.value);
            this.j.open("GET", b);
            this.j.withCredentials = this.ba.value;
            this.j.onreadystatechange = function() {
                EO(a, d, !1)
            };
            this.j.onload = function() {
                EO(a, d, !0)
            };
            this.j.onerror = function() {
                AO(d, new $E("XHR error"));
                FO(a)
            };
            this.j.send()
        }
        this.output.notify()
    };
    var EO = function(a, b, c) {
            try {
                if (3 === a.j.readyState || 4 === a.j.readyState)
                    if (300 <= a.j.status) a.B || (AO(b, new $E("xhr_err-" + a.j.status)), a.B = !0, _.G(wB) && FO(a));
                    else {
                        var d = a.j.responseText.substr(a.F);
                        d && BO(b, d);
                        a.F = a.j.responseText.length;
                        c && 4 === a.j.readyState && CO(b)
                    }
            } catch (e) {
                AO(b, e)
            }
        },
        FO = function(a) {
            _.G(vB) && a.o.value.forEach(function(b) {
                Pr(b, a.K, a.O, "")
            })
        };
    var GO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 1078);
        this.F = b;
        this.B = c;
        this.o = d;
        this.V = e;
        this.K = f;
        this.O = g;
        this.output = lG(this);
        this.j = W(this, h);
        k && (this.M = Y(this, k));
        l && (this.T = W(this, l));
        this.ba = W(this, m);
        nG(this, n);
        this.I = W(this, p);
        if (null == r ? 0 : r.Xd) this.da = Y(this, r.Xd);
        w && (this.ca = W(this, w))
    };
    _.T(GO, Z);
    GO.prototype.g = function() {
        var a = this,
            b = this.ba.value;
        if (b) {
            var c, d, e = new zO(this.F, this.B, this.o, this.j.value, this.V, null == (c = this.M) ? void 0 : c.value, null == (d = this.T) ? void 0 : d.value);
            c = this.I.value ? "include" : "omit";
            var f;
            d = null == (f = this.da) ? void 0 : f.value;
            var g;
            f = null == (g = this.ca) ? void 0 : g.value;
            g = _.A(Object, "assign").call(Object, {}, {
                credentials: c
            }, d ? {
                browsingTopics: d
            } : {}, f ? {
                adAuctionHeaders: f
            } : {});
            fetch(b, g).then(function(h) {
                HO(a, h, e)
            }).catch(function(h) {
                IO(h, e);
                JO(a)
            })
        }
        this.output.notify()
    };
    var HO = function(a, b, c) {
            if (300 <= b.status) AO(c, new $E("fetch_status-" + b.status)), _.G(wB) && JO(a);
            else {
                var d, e = null == (d = b.body) ? void 0 : d.pipeThrough(new TextDecoderStream).getReader();
                e ? e.read().then(function(f) {
                    KO(a, f, e, c)
                }).catch(function(f) {
                    IO(f, c)
                }) : AO(c, new $E("failed_reader"))
            }
        },
        KO = function(a, b, c, d) {
            var e = b.value;
            b.done ? CO(d) : (BO(d, e), c.read().then(function(f) {
                KO(a, f, c, d)
            }).catch(function(f) {
                IO(f, d)
            }))
        },
        IO = function(a, b) {
            AO(b, new $E("fetch error: " + (a instanceof Error ? a.message : void 0)))
        },
        JO = function(a) {
            _.G(vB) && a.j.value.forEach(function(b) {
                Pr(b, a.K, a.O, "")
            })
        };
    var LO = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.O = b;
        this.timer = c;
        this.output = lG(this);
        this.j = W(this, e);
        nG(this, d)
    };
    _.T(LO, Z);
    LO.prototype.g = function() {
        var a = this.j.value;
        a.length && Kr(this.timer, "3", Lr(this.O.R[a[0].getDomId()], 20));
        this.output.notify()
    };
    var NO = function(a, b, c) {
        Z.call(this, a, 804);
        this.ib = c;
        this.output = jG(this);
        this.o = [];
        this.Oc = {
            Fk: MO(this, function(d) {
                return ex(d, 6)
            }),
            pm: MO(this, function(d) {
                return ex(d, 7)
            }),
            Lk: MO(this, function(d) {
                return !!Yl(d, 8)
            }),
            sk: MO(this, function(d) {
                return fx(d, 10)
            }),
            ec: MO(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            vj: MO(this, function(d) {
                return _.di(d, uy, 43)
            }),
            Kk: MO(this, function(d) {
                return !!Yl(d, 9)
            }),
            sf: MO(this, function(d) {
                return !!Yl(d, 12)
            }),
            zk: MO(this, function(d) {
                return _.di(d, iy, Mk(d, Jy, 48))
            }),
            Xf: MO(this, function(d) {
                return _.di(d, hy, Mk(d, Jy, 39))
            }),
            he: MO(this, function(d) {
                return gx(d, 36)
            }),
            lm: MO(this, function(d) {
                return !!Yl(d, 13)
            }),
            Ug: MO(this, function(d) {
                return fx(d, 49)
            }),
            Ik: MO(this, function(d) {
                return _.di(d, xy, 51)
            }),
            ek: MO(this, function(d) {
                return fx(d, 61)
            }),
            ya: V(this),
            Ti: MO(this, function(d) {
                return _.di(d, Hy, 58)
            }),
            qm: MO(this, function(d) {
                var e, f;
                return null != (f = null == (e = _.di(d, sy, 56)) ? void 0 : fx(e, 1)) ? f : null
            }),
            Qd: MO(this, function(d) {
                return _.gi(d, cy, 62)
            }),
            Nj: MO(this, function(d) {
                return _.gi(d, vy, 67)
            }),
            Tk: MO(this, function(d) {
                return be(d, 63, gd, 2, void 0, void 0, 0)
            }),
            Ij: MO(this, function(d) {
                return !!Yl(d, 64)
            }),
            hk: MO(this, function(d) {
                return Uo(d, wy, 68)
            })
        };
        this.j = W(this, b)
    };
    _.T(NO, Z);
    var MO = function(a, b) {
        var c = V(a);
        a.o.push({
            output: c,
            lk: b
        });
        return c
    };
    NO.prototype.g = function() {
        for (var a = _.z(this.o), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.lk,
                d = void 0;
            b.output.Aa(null != (d = c(this.j.value)) ? d : null)
        }
        0 === this.ib.kind ? this.Oc.ya.D(this.ib) : this.Oc.ya.D({
            kind: 0,
            vb: _.Gj(this.j.value, 4) || ""
        });
        this.output.D(this.Oc)
    };
    var OO = function(a, b, c, d, e) {
        Z.call(this, a, 803);
        this.j = b;
        this.slotId = c;
        this.xa = d;
        this.V = e;
        this.output = V(this)
    };
    _.T(OO, Z);
    OO.prototype.g = function() {
        var a = JSON.parse(this.j),
            b = An(a, dv);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.j);
        a = te(Iy, a);
        b = be(a, 27, Qc, 2);
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next()) c = c.value, _.Ye($f).g(c);
        cm(4, this.context, this.xa, this.V);
        Mr(this.slotId, tI, 800, a);
        this.output.D(a)
    };
    var PO = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.K = c;
        this.j = W(this, d)
    };
    _.T(PO, Z);
    PO.prototype.g = function() {
        var a = this;
        Yl(this.j.value, 11) && (_.FI(this.K, this.slotId), CI(this.K, this.slotId, function() {
            _.GI(a.K, a.slotId)
        }))
    };
    var QO = function(a, b, c, d) {
        Pj.call(this);
        this.context = a;
        this.slotId = b;
        a = d.K;
        var e = d.V;
        b = d.Sa;
        var f = d.xa;
        d = d.ib;
        c = new OO(this.context, c, this.slotId, f, e);
        O(this, c);
        e = new JL(this.context, e, f, c.output);
        O(this, e);
        b = new LL(this.context, this.slotId, b, c.output);
        O(this, b);
        a = new PO(this.context, this.slotId, a, c.output);
        O(this, a);
        a = new NO(this.context, c.output, d);
        O(this, a);
        d = a.Oc;
        this.g = {
            Gc: d.Lk,
            Tf: d.ec,
            pa: d.Ti,
            Oc: a.output
        }
    };
    _.T(QO, Pj);
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var RO = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        SO = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = RO[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var TO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K, X) {
        Z.call(this, a, 973);
        this.oa = b;
        this.P = c;
        this.I = d;
        this.ba = e;
        this.O = f;
        this.K = g;
        this.xa = h;
        this.da = k;
        this.M = l;
        this.F = m;
        this.Sd = n;
        this.la = p;
        this.networkCode = r;
        this.isSecureContext = w;
        this.Db = u;
        this.Sa = x;
        this.A = y;
        this.U = C;
        this.j = M;
        this.T = K;
        this.Da = X;
        this.B = [];
        this.o = Y(this, D);
        this.ca = W(this, E);
        this.Ia = W(this, J);
        this.j && nG(this, this.j.Pj)
    };
    _.T(TO, Z);
    TO.prototype.g = function() {
        var a = this,
            b = new Pj;
        _.S(this, b);
        var c = this.ca.value,
            d = Gt(this.O.W);
        this.o.value && this.Da.D(this.o.value);
        var e = uq(this.context, this.U);
        e && _.S(b, e.Fa);
        var f = Pp(this.context, _.di(this.O.W, Vs, 5), this.K, this.I, null == e ? void 0 : e.ql.Kd);
        e = f.jg;
        (f = f.Uk) && _.S(b, f);
        f = new yO(this.context, this.I, this.U, this.O, this.A, e);
        O(b, f);
        var g = !!_.N(this.O.W, 6);
        e = new sO(this.context, this.I, g, this.O, this.P, this.A, c);
        O(b, e);
        var h, k = new zK(this.context, d, c, (null == (h = _.di(this.O.W, zs, 36)) ? void 0 : be(h, 1, Oc, 2)) || []);
        O(b, k);
        h = this.T;
        var l = h.jl,
            m = h.vl,
            n = h.dm,
            p, r = null != (p = this.j) ? p : {},
            w = r.fe;
        h = r.hf;
        var u = r.Kb,
            x = r.od,
            y = r.Ce,
            C = r.xk;
        p = r.vf;
        var D = r.Eh,
            E = r.Sj;
        r = r.nd;
        if (_.G(XB)) {
            var J = new JM(this.context, E);
            var M = new KM(this.context, E);
            O(b, J);
            O(b, M);
            var K = J.j;
            J = M.j;
            M = M.o
        }
        if (D = Wr(this.context, n, this.O.R, c, this.o.value, e.j, k.output, D, J)) {
            var X = D.gm;
            D = D.fm;
            var ba = X.Ag;
            X = X.eg;
            _.S(b, D)
        }
        if (M = tr(this.context, n, this.A.navigator, k.output, M)) {
            var la = M.Ui;
            M = M.hm;
            var ra = la.Bi;
            la = la.Nh;
            M && _.S(b, M)
        }
        _.G(oC) && (la = V(this), la.D(n.Sg));
        D = new bN(this.context, this.A);
        O(b, D);
        n = (null != w ? w : {}).Pb;
        var Aa;
        M = null == (Aa = this.j) ? void 0 : Aa.qf;
        Aa = new EM(this.context, l.kl);
        O(b, Aa);
        if (l = Jo(this.context, this.P, this.O.R, this.networkCode, e.j, w, u)) {
            var ya = l.zj;
            _.S(this, l.Fa)
        }
        if (X = wq(this.context, m, X, _.G(tC) ? this.O.R : void 0, _.G(tC) ? e.j : void 0, E)) {
            var Pa = X.ef;
            _.S(this, X.Fa)
        }
        if (K = er(this.context, this.o.value, M, k.output, K)) {
            var Fa = K.bm;
            _.S(this, K.Fa);
            this.B.push(Fa.Zc.promise)
        }
        K = window.isSecureContext && _.G(vC) ? "wbn" : "ldjh";
        var Cb = ++this.K.G;
        X = "wbn" === K ? SO().toLowerCase() : void 0;
        k = this.Sd;
        var bb, yb;
        ya = new xO(this.context, g, this.K, this.xa, this.O, K, k.Qb, this.networkCode, k.cd, k.bd, this.Ia.value, X, _.Ye(Nh), c, this.isSecureContext, this.Db, this.A, Aa.output, D.output, e.j, null == (bb = ya) ? void 0 : bb.Og, Fa, M, f.output, null == h ? void 0 : h.ug, n, u, x, y, C, Pa, ra, null == (yb = this.j) ? void 0 : yb.Eh, r, J);
        O(b, ya);
        Pa = new LO(this.context, this.O, _.Ye(Nh), ya.j, e.j);
        O(b, Pa);
        d = new tO(this.context, d, c);
        O(b, d);
        bb = Lh(this.context, 646, function(cc, Jc, mc, Zc, $c, ce, dc) {
            It(function() {
                return void UO(a, $c, cc, Jc, mc, Zc, ce, dc)
            }, cc, a.A)
        });
        yb = Lh(this.context, 647, function(cc, Jc, mc) {
            It(function() {
                return void VO(a, Cb, mc, Jc, cc)
            }, -1, a.A)
        });
        "ldjh" === K ? (J = WO(this, 289, "strm_err"), _.G(zB) && window.fetch && window.TextDecoderStream || _.G(BB) && Dz(window.fetch) && Dz(window.TextDecoderStream) || _.G(AB) && Na() && Dz(window.fetch) && Dz(window.TextDecoderStream) ? (ba = new GO(this.context, bb, J, yb, c, this.K, this.O, e.j, ba, ra, ya.j, Pa.output, d.output, Fa, la), O(b, ba), ba = ba.output) : (ba = new DO(this.context, bb, J, yb, c, this.K, this.O, e.j, ba, ya.j, Pa.output, d.output), O(b, ba), ba = ba.output)) : (ra = new NN(this.context, bb, WO(this, 1042, "Unknown web bundle error."), yb, K, X, c, this.U, e.j, ba, ya.j, ya.T, Pa.output, d.output), Ss(b, ra), ba = new Gn, cG(ba, Yj(ra).then(function() {})));
        ra = new uO(this.context, Cb, e.j, ba, p, this.networkCode);
        O(b, ra);
        Fa = new qO(this.context, ya.o, ya.j);
        O(b, Fa);
        Fa = new wO(this.context, this.F.ra, this.O, Fa.output);
        O(b, Fa);
        Fa = new RM(this.context, this.da, this.A, Fa.output);
        O(b, Fa);
        Fa = new uM(this.context, this.O, this.M, e.j, Fa.output);
        O(b, Fa);
        e = new zL(this.context, this.K, this.O, this.U, e.j, Fa.output);
        O(b, e);
        Fa = new aN(this.context, _.Wh(this.A), this.A, c, ba);
        O(b, Fa);
        1 === Cb && (c = new rL(this.context, this.A, c, M, ba), O(b, c), this.B.push(c.output.promise));
        this.B.push(ra.output.promise, e.output.promise, Fa.output.promise);
        Yj(b)
    };
    var UO = function(a, b, c, d, e, f, g, h) {
            var k, l, m;
            return _.nb(function(n) {
                k = f[c];
                if (!k) return Ph(a.context, 646, Error("missing slot")), n.return();
                0 === c && (l = Lr(a.O.R[k.getDomId()], 20), Kr(_.Ye(Nh), "4", l));
                return n.yield(XO(a, k, d, e, b, null == (m = g) ? void 0 : m[k.getId()], h), 0)
            })
        },
        VO = function(a, b, c, d, e) {
            var f, g, h;
            return _.nb(function(k) {
                if (1 == k.g) {
                    var l = a.context,
                        m = e + 1,
                        n = d.length;
                    if (l.yc) {
                        var p = l.Ga,
                            r = p.xc;
                        l = xh(l);
                        var w = new UA;
                        w = _.th(w, 3, b);
                        m = _.Bh(w, 1, m);
                        n = _.Bh(m, 2, n);
                        n = _.Ch(l, 8, Dh, n);
                        r.call(p, n)
                    }
                    f = e + 1
                }
                if (3 != k.g) {
                    if (!(f < d.length)) return k.yield(YO(a), 0);
                    if (!d[f]) {
                        k.g = 3;
                        return
                    }
                    p = new Iy;
                    p = Lj(p, 8, !0);
                    g = Gk(p);
                    h = '{"empty":' + g + "}";
                    return k.yield(UO(a, c, f, h, {
                        kind: 0,
                        vb: ""
                    }, d), 3)
                }++f;
                k.g = 2
            })
        },
        XO = function(a, b, c, d, e, f, g) {
            var h, k, l, m, n, p, r, w, u, x;
            return _.nb(function(y) {
                if (1 == y.g) return h = {
                    V: e,
                    Sa: a.Sa,
                    K: a.K,
                    xa: a.xa,
                    ib: d
                }, k = new QO(a.context, b, c, h), y.yield(Yj(k), 2);
                l = y.m;
                m = l.Gc;
                n = l.Tf;
                p = l.pa;
                r = l.Oc;
                Lo(a.context, null == (w = a.j) ? void 0 : w.fe, r.qm, r.sf, r.ec);
                _.G(nB) && up(a.context, a.xa, r.hk);
                if (b.J) return y.return();
                (u = !!p) && ej("gpt_td_init", function(C) {
                    kj(C, a.context);
                    lj(C, "noFill", m ? "1" : "0");
                    lj(C, "publisher_tag", "gpt");
                    var D = _.di(p, Ey, 5);
                    D && (lj(C, "winner_qid", D.getEscapedQemQueryId()), lj(C, "xfpQid", _.R(D, 6)))
                }, 1);
                (x = Dp("google_norender")) || m && !u ? Pr(b, a.K, a.O, n) : nO(a.la, a.oa, a.P, b, m || x, u, a.K, a.O, a.Sa, r, e, f, g, a.F.ra, a.M, a.j, a.T);
                k.ua();
                y.g = 0
            })
        },
        WO = function(a, b, c) {
            return Lh(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                Ph(a.context, b, d);
                YO(a)
            })
        },
        YO = function(a) {
            return _.nb(function(b) {
                if (1 == b.g) {
                    var c = a.K,
                        d = a.ba,
                        e = c.m.get(d) - 1;
                    0 === e ? c.m.delete(d) : c.m.set(d, e);
                    return e ? b.return() : b.yield(_.v.Promise.all(a.B), 2)
                }
                Mr(a.F.Ih, xI, 965, a.ba);
                b.g = 0
            })
        };
    var ZO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C, D, E, J, M, K) {
        Z.call(this, a, 885);
        this.ca = b;
        this.P = c;
        this.O = d;
        this.K = e;
        this.xa = f;
        this.Sd = g;
        this.T = h;
        this.F = k;
        this.j = l;
        this.B = m;
        this.ba = n;
        this.isSecureContext = p;
        this.Ya = r;
        this.M = w;
        this.Db = u;
        this.Sa = x;
        this.A = y;
        this.U = C;
        this.o = J;
        this.I = M;
        this.da = K;
        this.la = W(this, D);
        nG(this, E)
    };
    _.T(ZO, Z);
    ZO.prototype.g = function() {
        var a = this.la.value;
        if (a.length) {
            var b = this.K,
                c = this.j,
                d = a.length;
            b.m.has(c);
            b.m.set(c, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0;
                b = c.networkCode;
                d = c.X;
                c = new Pj;
                _.S(this, c);
                var f = Ap(this.context, this.M, null == (e = this.o) ? void 0 : e.al);
                e = f.Ic;
                var g = f.Fh;
                _.S(c, f.Fa);
                e = bn(this.context, this.P, this.K, this.A, e, g, Gt(this.O.W));
                f = e.hb;
                _.S(c, e.Fa);
                e = new LM(this.context, this.A, f);
                O(c, e);
                e = new IL(this.context, this.A, f);
                O(c, e);
                e = new Os(this.context, this.A, f);
                O(c, e);
                g = new oO(this.context, this.xa, this.Ya, f);
                O(c, g);
                b = new TO(this.context, this.ca, this.P, d, this.j, this.O, this.K, this.xa, this.T, this.F, this.B, this.Sd, this.ba, b, this.isSecureContext, this.Db, this.Sa, this.A, this.U, e.output, f, g.o, this.o, this.I, this.da);
                O(c, b);
                Yj(c)
            }
        } else Mr(this.B.Ih, xI, 965, this.j)
    };
    var $O = new _.v.Map,
        aP = function(a, b, c, d) {
            d = void 0 === d ? $O : d;
            Z.call(this, a, 834);
            this.P = b;
            this.X = c;
            this.j = d;
            this.o = V(this);
            this.o.Ka(_.v.Promise.all(this.X.map(this.B, this)).then(function(e) {
                return e.filter(function(f) {
                    return null != f && !f.J
                })
            }))
        };
    _.T(aP, Z);
    aP.prototype.g = function() {};
    aP.prototype.B = function(a) {
        var b = this,
            c, d;
        return _.nb(function(e) {
            if (1 == e.g) {
                if (a.J) return e.return();
                b.j.has(a) || (b.j.set(a, Kt(a)), _.yn(a, function() {
                    return void b.j.delete(a)
                }));
                c = b.j.get(a);
                return e.yield(c(), 2)
            }
            d = e.m;
            if (b.J) return e.return();
            if (d) return e.return(a);
            Q(b.P, CJ(a.getAdUnitPath()));
            return e.return()
        })
    };
    var bP = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, x, y, C) {
        _.U.call(this);
        var D = this;
        this.context = a;
        this.B = b;
        this.P = c;
        this.K = d;
        this.xa = e;
        this.ra = f;
        this.L = g;
        this.j = h;
        this.o = k;
        this.isSecureContext = l;
        this.Ya = m;
        this.H = n;
        this.Db = p;
        this.Sa = r;
        this.U = w;
        this.A = u;
        this.v = x;
        this.G = y;
        this.F = C;
        this.g = new _.v.Map;
        this.l = new pI(a);
        _.S(this, this.l);
        this.l.listen(xI, function(E) {
            E = E.detail;
            var J = D.g.get(E);
            J && (D.g.delete(E), J.ua())
        })
    };
    _.T(bP, _.U);
    var cP = function(a, b, c, d) {
        var e = ++a.K.j;
        a.g.has(e);
        var f = new Pj;
        a.g.set(e, f);
        b = new aP(a.context, a.P, b);
        O(f, b);
        var g = tG(f, 845, Ot, {
            X: b.o
        }, {
            R: d.R
        }, {
            Ni: void 0,
            Xi: void 0
        });
        b = g.Xi;
        g = tG(f, 847, Mt, {
            X: g.Ni
        }, {
            K: a.K,
            eb: !!_.N(d.W, 6),
            Pk: Dp("google_nofetch")
        }, {
            Od: void 0
        }).Od;
        b = tG(f, 864, pp, {
            X: b
        }, {
            K: a.K,
            O: d,
            U: document
        }, {}).finished;
        a = new ZO(a.context, a.B, a.P, d, a.K, a.xa, c, a.L, a.j, e, {
            Ih: a.l,
            ra: a.ra
        }, a.o, a.isSecureContext, a.Ya, a.H, a.Db, a.Sa, a.A, a.U, g, b, a.v, a.G, a.F);
        O(f, a);
        Yj(f)
    };
    var dP = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        PN.call(this, a, c, h);
        this.context = a;
        this.K = d;
        this.v = new _.v.Set;
        this.G = {};
        this.o = new mO(a, d);
        this.B = new bP(a, b, c, d, new _.iF(window), this.l, m, e, this.o, f, g, k, l, n, document, window, p, r, w);
        _.S(this, this.B)
    };
    _.T(dP, PN);
    dP.prototype.getName = function() {
        return "publisher_ads"
    };
    dP.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.ka(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        rs(this);
        var h = tm(c, this.context, this.P, a, b, f),
            k = h.slotId;
        h = h.Ba;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            bs(this, null != (l = g) ? l : k.getDomId(), c)
        } else Q(this.P, $k("PubAdsService.display", [a, b, d]))
    };
    var bs = function(a, b, c) {
        var d = eP(b, c);
        c = d.slotId;
        var e = d.ak;
        d = d.bk;
        if (c) {
            if (b = Vi(), (d = eH(b, c.getDomId())) && !_.N(d, 19))
                if (e && b.l.set(c, e), (e = Li(c)) || (e = Qs(d), e = 0 !== e && 1 !== e), e) {
                    if (Lj(d, 19, !0), e = Hi(b.g, b.m), a.enabled) {
                        rs(a);
                        a.enabled && EI(a.K, c);
                        a.P.info(dJ());
                        b = e.W;
                        d = e.R;
                        var f = _.N(b, 6);
                        if (f || !a.K.mc(c)) f && (f = Li(c)) && Mr(c, sI, 778, f), _.N(b, 4) && (d = d[c.getDomId()], lp(d, b) && !a.K.mc(c) && mp(c, document, d, b)), dK(a, e, c)
                    }
                } else Q(a.P, UI(String(_.Gj(d, 1)), String(_.Gj(d, 2))), c)
        } else d ? a.P.error(VI(d)) : a.P.error($k("googletag.display", [String(b)]))
    };
    dP.prototype.slotAdded = function(a, b) {
        var c = this;
        _.N(b, 17) || this.enabled && EI(this.K, a);
        Mr(this.l, vI, 724, {
            Ng: a.getDomId(),
            R: b
        });
        a.listen(Or, function(d) {
            var e = d.detail;
            d = e.size;
            var f = new VL(a, "publisher_ads");
            e.isEmpty && (f.isEmpty = !0);
            e = a.g.getResponseInformation();
            d && e && (f.size = [d.width, d.height], f.sourceAgnosticCreativeId = e.sourceAgnosticCreativeId, f.sourceAgnosticLineItemId = e.sourceAgnosticLineItemId, f.isBackfill = e.isBackfill, f.creativeId = e.creativeId, f.lineItemId = e.lineItemId, f.creativeTemplateId = e.creativeTemplateId, f.advertiserId = e.advertiserId, f.campaignId = e.campaignId, f.yieldGroupIds = e.yieldGroupIds, f.companyIds = e.companyIds);
            Mr(c.l, "slotRenderEnded", 708, f)
        });
        a.listen(tI, function() {
            Mr(c.l, "slotResponseReceived", 709, new aM(a, c.getName()))
        });
        4 === Qs(b) && fP(this, "rewardedSlotClosed", a, b);
        7 === Qs(b) && fP(this, "gameManualInterstitialSlotClosed", a, b);
        PN.prototype.slotAdded.call(this, a, b)
    };
    var fP = function(a, b, c, d) {
            _.yn(c, a.l.listen(b, function(e) {
                c.g === e.detail.slot && (e = {}, gP(a, [c], Vi().g, (e[c.getDomId()] = d, e), a.K))
            }))
        },
        dK = function(a, b, c) {
            var d = hP(a, b, c);
            iP(a, d, b, {
                Qb: 1
            });
            b = c.getAdUnitPath();
            if (c = a.G[b]) {
                c = _.z(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, iP(a, d.X, d.O, d.Sd);
                delete a.G[b]
            }
        },
        hP = function(a, b, c) {
            var d = b.W;
            b = b.R;
            if (_.N(d, 4)) return [];
            var e;
            return !_.N(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : _.N(e, 17)) ? (a.v.add(c), _.yn(c, function() {
                return void a.v.delete(c)
            }), [c]) : a.g.filter(function(f) {
                if (a.v.has(f)) return !1;
                a.v.add(f);
                _.yn(f, function() {
                    return void a.v.delete(f)
                });
                return !0
            })
        },
        iP = function(a, b, c, d) {
            a.P.info(kJ());
            if (jP(a, b, d, c) && 1 !== d.Qb)
                for (b = _.z(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), Mr(a.l, wI, 725, {
                    Ng: d,
                    R: c.R[d]
                })
        },
        jP = function(a, b, c, d) {
            b = b.filter(function(e) {
                var f = d.R[e.getDomId()],
                    g = _.np(a.K, e);
                !1 === g && Q(a.P, TJ(String(Qs(f)), e.getAdUnitPath()));
                if (!g) return !1;
                (_.H = [5, 4, 7], _.A(_.H, "includes")).call(_.H, Qs(f)) && _.FI(a.K, e);
                return !0
            });
            if (!b.length) return null;
            cP(a.B, b, c, d);
            return b
        };
    dP.prototype.refresh = function(a, b, c) {
        c = void 0 === c ? {
            Qb: 2
        } : c;
        b = kP(this, b);
        if (!b.length) return !1;
        lP(this, a, b, c);
        return !0
    };
    var kP = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.J) return !0;
                Q(a.P, nJ(String(d)));
                return !1
            })
        },
        lP = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.enabled) {
                var h = _.z(c);
                e = h.next();
                for (f = {}; !e.done; f = {
                        Vd: f.Vd
                    }, e = h.next()) f.Vd = e.value, a.v.add(f.Vd), _.yn(f.Vd, function(k) {
                    return function() {
                        return void a.v.delete(k.Vd)
                    }
                }(f));
                iP(a, c, b, d)
            } else c.length && _.N(b.W, 6) ? (Q(a.P, jJ(g), e), e = e.getAdUnitPath(), f = null != (h = a.G[e]) ? h : [], f.push({
                X: c,
                O: b,
                Sd: d
            }), a.G[e] = f) : Q(a.P, hJ(g), e)
        };
    dP.prototype.L = function() {
        var a = Vi().g;
        if (_.N(a, 6))
            for (var b = _.z(this.g), c = b.next(); !c.done; c = b.next()) this.enabled && EI(this.K, c.value);
        iK(this, a);
        a = Nm();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    dP.prototype.destroySlots = function(a) {
        a = PN.prototype.destroySlots.call(this, a);
        if (a.length && this.enabled) {
            var b = Vi();
            mP(this, a, b.g, b.m)
        }
        return a
    };
    var kK = function(a, b, c, d) {
            if (!a.enabled) return Q(a.P, iJ(), d[0]), !1;
            var e = kP(a, d);
            if (!e.length) return Q(a.P, $k("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.P.info(lJ());
            mP(a, e, b, c);
            return !0
        },
        mP = function(a, b, c, d) {
            for (var e = _.z(b), f = e.next(); !f.done; f = e.next()) BI(a.K, f.value);
            gP(a, b, c, d, a.K)
        };
    dP.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.Ye($f).g(a)
    };
    var gP = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.z(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                KI(a.o.K, g);
                var h = d[g.getDomId()];
                lp(h, c) && mp(g, f.document, h, c);
                op(e, g)
            }
        },
        jK = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) Q(a.P, $k("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = Lj(d, 21, !0);
                b = Zn(e, 22, b);
                Zn(b, 23, c);
                iK(a, d)
            }
        },
        lK = function(a, b) {
            if (!a.enabled) return null;
            var c, d;
            return {
                vid: null != (c = _.R(b, 22)) ? c : "",
                cmsid: null != (d = _.R(b, 23)) ? d : ""
            }
        },
        iK = function(a, b) {
            _.N(b, 21) && a.enabled && (a = Mz(), _.Gi(b, 29, null == a ? a : hd(a)))
        },
        eP = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = pL(b, c);
            else if (_.ka(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = pL(b, c)
            } else b = (_.H = [].concat(_.oh(b.X)), _.A(_.H, "find")).call(_.H, function(e) {
                return e.g === a
            });
            return {
                slotId: b,
                ak: d,
                bk: c
            }
        };
    var Yt = _.tu(["https://pagead2.googlesyndication.com/pagead/js/rum_debug.js"]),
        Zt = _.tu(["https://pagead2.googlesyndication.com/pagead/js/rum.js"]);
    var nP = uu(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        oP = _.ev(function() {
            Iz("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        qP = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.A(String, "raw").call(String, nP) : d;
            this.K = a;
            this.m = d;
            this.g = new _.v.Map;
            this.X = new _.v.Set;
            b.l = function(e) {
                return pP(c, e)
            }
        };
    qP.prototype.defineSlot = function(a, b, c, d, e) {
        a = tm(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.g;
        a.we || b.error($k("googletag.defineSlot", [c, d, e]));
        return null
    };
    var tm = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            Ib: f,
            pi: void 0 === g ? !1 : g
        }) : {}
    };
    qP.prototype.add = function(a, b, c, d, e, f) {
        var g = this,
            h = e.Ib,
            k = void 0 === e.format ? 0 : e.format,
            l = void 0 === e.pi ? !1 : e.pi;
        e = void 0 === e.pb ? !1 : e.pb;
        f = void 0 === f ? _.t : f;
        try {
            var m = new RegExp(this.m, "u");
            if (m.test("/1") && !m.test(c)) return b.error(XI(c)), {
                we: !0
            }
        } catch (p) {}
        m = _.G(CB) && 3 === k && 0 === fp(2, f, !0);
        if (!m && (f = fp(k, f, e), null !== f && Xo(a, f, cp(k)), f)) return Ro(b, f, k, c), {};
        l && oP();
        k = this.g.get(c) || Number(l);
        b = rP(this, a, b, c, k, d, h || "gpt_unit_" + c + "_" + k);
        a = b.Ba;
        var n = b.slotId;
        b = b.we;
        if (!n) return {
            we: b
        };
        this.g.set(c, k + 1);
        this.X.add(n);
        _.yn(n, function() {
            return void g.X.delete(n)
        });
        NG(c);
        return {
            slotId: n,
            Ba: a,
            wj: m
        }
    };
    var pL = function(a, b) {
            a = _.z(a.X);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        $r = function(a) {
            a = _.z(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.ua()
        },
        rP = function(a, b, c, d, e, f, g) {
            var h = pL(a, g);
            if (h) return c.error(WI(g, d, h.getAdUnitPath())), {
                we: !0
            };
            var k = new uK;
            vK(Zn(k, 1, d), g);
            wK(k, Im(f));
            dH(k);
            var l = new If(b, d, e, g);
            fK(l, Um(b, c, l));
            _.yn(l, function() {
                var m = Vi(),
                    n = l.getDomId();
                delete m.m[n];
                m.l.delete(l);
                m = l.getAdUnitPath();
                m = qh(m);
                var p;
                n = (null != (p = bi.get(m)) ? p : 0) - 1;
                0 >= n ? bi.delete(m) : bi.set(m, n);
                c.info(sJ(l.toString()), l);
                (p = Vk.get(l)) && Wk.delete(p);
                Vk.delete(l)
            });
            c.info(LI(l.toString()), l);
            l.listen(uI, function(m) {
                m = m.detail.Gl;
                c.info(MI(l.getAdUnitPath()), l);
                WG(_.Ye(Nh), "7", 9, II(a.K, l), 0, m)
            });
            l.listen(tI, function(m) {
                var n = m.detail;
                c.info(NI(l.getAdUnitPath()), l);
                var p;
                m = _.Ye(Nh);
                var r = Lr(k, 20);
                n = null != (p = n.getEscapedQemQueryId()) ? p : "";
                m.g && (_.t.google_timing_params = _.t.google_timing_params || {}, _.t.google_timing_params["qqid." + r] = n)
            });
            l.listen(Nr, function() {
                return void c.info(OI(l.getAdUnitPath()), l)
            });
            l.listen(Or, function() {
                return void c.info(PI(l.getAdUnitPath()), l)
            });
            return {
                Ba: k,
                slotId: l
            }
        },
        pP = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.oh(a.X)).some(function(d) {
                return c.test(qh(d.getAdUnitPath()))
            })
        };
    (function(a, b) {
        var c = null != a ? a : {
            pvsid: _.Wh(window),
            ab: "1",
            wb: "m202312060101",
            Ga: new gu(3, "m202312060101", 0),
            Mg: !0,
            Sf: 1
        };
        try {
            wc(function(ya) {
                Ph(c, 1190, ya)
            });
            var d = Nm();
            Qe(!_.Ye(oi).g);
            _.A(Object, "assign").call(Object, pi, d._vars_);
            d._vars_ = pi;
            if (d.evalScripts) d.evalScripts();
            else {
                FH();
                try {
                    og()
                } catch (ya) {
                    Ph(c, 408, ya)
                }
                Jp();
                var e = new JK;
                try {
                    kg(e.G), $l(13, c), $l(3, c)
                } catch (ya) {
                    Ph(c, 408, ya)
                }
                var f = eu(c, e),
                    g = null != a ? a : ju(f, c),
                    h = null != b ? b : new IK(g);
                Eh(g);
                Kh(g);
                ej("gpt_fifwin", function(ya) {
                    kj(ya, g)
                }, d.fifWin ? .01 : 0);
                var k = new AI,
                    l = new qP(k, e),
                    m = new WN(g),
                    n = _.qi(260),
                    p = new eO(g, l, Vi(), h, k, n, e, m),
                    r = xz(),
                    w = Hs(g),
                    u = new pI(g),
                    x = new pI(g),
                    y = new pI(g),
                    C = _.qi(150),
                    D;
                n && (D = fO(p, u, C, w));
                var E = _.qi(221),
                    J = new MM,
                    M = new KL,
                    K, X, ba, la = null != (ba = null == (K = D) ? void 0 : null == (X = K.hf) ? void 0 : X.rb) ? ba : new Cn,
                    ra = new dP(g, l, h, k, m, r, e, u, n, E, J, M, D, w, la);
                _.G(AC) && new qL(g, u, k, l);
                var Aa = Vi().g;
                As(g, h, ra, Aa, l, x, y, e, M, la);
                fn(g, d, h);
                window.setTimeout(function() {
                    for (var ya = window.document.scripts, Pa = 0, Fa = 0, Cb = 0; Cb < ya.length; Cb++) ya[Cb].src.match("securepubads.g.doubleclick.net/tag/js/gpt.js") ? Pa++ : ya[Cb].src.match("www.googletagservices.com/tag/js/gpt.js") && Fa++;
                    1 < Pa && 0 === Fa || 1 < Fa && 0 === Pa ? Q(h, RJ()) : 0 < Fa && 0 < Pa && h.error(SJ())
                }, 1E3);
                Xr();
                if (_.G(AC) || _.Ye(Nh).g) Wt(), $t();
                Qq(g, h);
                jn(g)
            }
        } catch (ya) {
            Ph(c, 106, ya)
        }
    })();
    _.sP = _.t.requestAnimationFrame || _.t.webkitRequestAnimationFrame;
    _.tP = !!_.sP && !/'iPhone'/.test(_.t.navigator.userAgent);
    _.uP = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.v = a;
        this.g = b;
        this.l = c;
        this.T = null;
        _.yn(this, function() {
            return d.T = null
        })
    };
    _.T(_.uP, _.U);
}).call(this, {});