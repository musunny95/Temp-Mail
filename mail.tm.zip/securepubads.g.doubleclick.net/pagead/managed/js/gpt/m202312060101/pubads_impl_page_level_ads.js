window.googletag && typeof googletag._gpt_js_load_2_ == 'function' && googletag._gpt_js_load_2_(function(_, _m) {
    var wP = function(a) {
            if (!vP.test(a)) return null;
            a = Number(a);
            return isNaN(a) ? null : a
        },
        xP = function(a, b) {
            return a && a.source ? a.source === b || a.source.parent === b : !1
        },
        yP = function(a) {
            a = _.Fg(a);
            return .05 > Math.abs(a - 1)
        },
        AP = function(a) {
            var b = {
                bottom: "auto",
                clear: "none",
                display: "inline",
                "float": "none",
                height: "auto",
                left: "auto",
                margin: 0,
                "margin-bottom": 0,
                "margin-left": 0,
                "margin-right": "0",
                "margin-top": 0,
                "max-height": "none",
                "max-width": "none",
                opacity: 1,
                overflow: "visible",
                padding: 0,
                "padding-bottom": 0,
                "padding-left": 0,
                "padding-right": 0,
                "padding-top": 0,
                position: "static",
                right: "auto",
                top: "auto",
                "vertical-align": "baseline",
                visibility: "visible",
                width: "auto",
                "z-index": "auto"
            };
            _.hv(_.A(Object, "keys").call(Object, b), function(c) {
                var d = a.style[_.Zy(c)];
                ("undefined" !== typeof d ? d : a.style[_.Xz(a, c)]) || _.Yz(a, c, b[c])
            });
            zP(a)
        },
        CP = function(a, b, c, d) {
            return BP(a, "fullscreen", d.va(952, function(e, f) {
                if (f.source === b) {
                    if (!("eventType" in e)) throw Error("bad message " + JSON.stringify(e));
                    delete e.googMsgType;
                    c(e)
                }
            }))
        },
        EP = function(a, b, c, d, e) {
            a = new DP(1, a, b, c, d, e);
            a.na();
            return a
        },
        FP = function(a) {
            var b;
            null == (b = a.l) || b.setAttribute("data-vignette-loaded", "true")
        },
        GP = function(a) {
            var b = a.ownerDocument,
                c = b.createElementNS("http://www.w3.org/2000/svg", "line");
            c.setAttribute("x1", "22");
            c.setAttribute("y1", "18");
            c.setAttribute("x2", "28");
            c.setAttribute("y2", "12");
            a.appendChild(c);
            b = b.createElementNS("http://www.w3.org/2000/svg", "line");
            b.setAttribute("x1", "28");
            b.setAttribute("y1", "12");
            b.setAttribute("x2", "34");
            b.setAttribute("y2", "18");
            a.appendChild(b)
        },
        HP = function(a) {
            var b = a.ownerDocument,
                c = b.createElementNS("http://www.w3.org/2000/svg", "line");
            c.setAttribute("x1", "22");
            c.setAttribute("y1", "12");
            c.setAttribute("x2", "28");
            c.setAttribute("y2", "18");
            a.appendChild(c);
            b = b.createElementNS("http://www.w3.org/2000/svg", "line");
            b.setAttribute("x1", "28");
            b.setAttribute("y1", "18");
            b.setAttribute("x2", "34");
            b.setAttribute("y2", "12");
            a.appendChild(b)
        },
        IP = function(a, b, c) {
            null !== b && null !== wP(a.getAttribute("width")) && a.setAttribute("width", String(b));
            null !== c && null !== wP(a.getAttribute("height")) && a.setAttribute("height", String(c));
            null !== b && (a.style.width = _.AH(b));
            null !== c && (a.style.height = _.AH(c))
        },
        JP = function(a, b) {
            a = b ? 100 * _.Kg(a) : 100;
            return {
                width: a + "vw",
                height: a + "vh"
            }
        },
        KP = function(a, b, c, d) {
            if (!a.T) {
                a.T = [];
                for (var e = a.v.parentElement; e;) {
                    a.T.push(e);
                    if (a.l === e) break;
                    e = e.parentNode && 1 === e.parentNode.nodeType ? e.parentNode : null
                }
            }
            e = a.T.slice();
            !c && a.l === e[e.length - 1] && e.pop();
            var f;
            if (d)
                for (c = e.length - 1; 0 <= c; --c)(f = e[c]) && b.call(a, f, c, e);
            else
                for (c = 0; c < e.length; ++c)(f = e[c]) && b.call(a, f, c, e)
        },
        LP = {
            capture: !0
        },
        MP = function(a, b) {
            return new _.ui(a.x - b.x, a.y - b.y)
        },
        NP = function(a) {
            var b = a.document,
                c = 0;
            if (b) {
                c = b.body;
                var d = b.documentElement;
                if (!d || !c) return 0;
                a = _.fz(a).height;
                if (_.ez(b) && d.scrollHeight) c = d.scrollHeight != a ? d.scrollHeight : d.offsetHeight;
                else {
                    b = d.scrollHeight;
                    var e = d.offsetHeight;
                    d.clientHeight != e && (b = c.scrollHeight, e = c.offsetHeight);
                    c = b > a ? b > e ? b : e : b < e ? b : e
                }
            }
            return c
        },
        vP = /^(-?[0-9.]{1,30})$/,
        OP = function(a, b) {
            for (a = [a]; a.length;) {
                var c = a.shift();
                !1 !== b(c) && (c = _.bh(c.children || c.childNodes || [], function(d) {
                    return 1 === d.nodeType
                }), c.length && a.unshift.apply(a, _.oh(c)))
            }
        },
        PP = function(a) {
            var b = {};
            if (a) {
                var c = /\s*:\s*/;
                _.hv((a || "").split(/\s*;\s*/), function(d) {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        QP = function(a, b) {
            if ("length" in a.style) {
                a = a.style;
                for (var c = a.length, d = 0; d < c; d++) {
                    var e = a[d];
                    b(a[e], e, a)
                }
            } else a = PP(a.style.cssText), _.Rl(a, b)
        },
        zP = function(a, b) {
            b = void 0 === b ? function() {
                return !0
            } : b;
            var c = /!\s*important/i;
            QP(a, function(d, e) {
                !c.test(d) && b(e, d) ? a.style.setProperty(e, d, "important") : c.test(d) && !b(e, d) && a.style.setProperty(e, d, "")
            })
        },
        RP = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        SP = /.*domain\.test$/,
        TP = /\.prod\.google\.com(:\d+)?$/,
        UP = function(a) {
            a.preventDefault ? a.preventDefault() : a.returnValue = !1
        },
        VP = function(a) {
            if (1 == a.nodeType) return _.dA(a);
            a = a.changedTouches ? a.changedTouches[0] : a;
            return new _.ui(a.clientX, a.clientY)
        },
        WP = function(a, b) {
            if (b instanceof _.Di) {
                var c = b.height;
                b = b.width
            } else throw Error("missing height argument");
            a.style.width = _.eA(b, !0);
            a.style.height = _.eA(c, !0)
        },
        XP = function(a, b) {
            var c = a.currentStyle ? a.currentStyle[b] : null;
            if (c)
                if (/^\d+px?$/.test(c)) a = parseInt(c, 10);
                else {
                    b = a.style.left;
                    var d = a.runtimeStyle.left;
                    a.runtimeStyle.left = a.currentStyle.left;
                    a.style.left = c;
                    c = a.style.pixelLeft;
                    a.style.left = b;
                    a.runtimeStyle.left = d;
                    a = +c
                }
            else a = 0;
            return a
        },
        YP = function(a, b) {
            if (_.jw) {
                var c = XP(a, b + "Left"),
                    d = XP(a, b + "Right"),
                    e = XP(a, b + "Top");
                a = XP(a, b + "Bottom");
                return new _.Rz(e, d, a, c)
            }
            c = _.$z(a, b + "Left");
            d = _.$z(a, b + "Right");
            e = _.$z(a, b + "Top");
            a = _.$z(a, b + "Bottom");
            return new _.Rz(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
        },
        BP = function(a, b, c, d) {
            d = void 0 === d ? null : d;
            var e = function(g) {
                try {
                    var h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            _.lb(a, "message", e);
            var f = !1;
            return function() {
                var g = !1;
                f || (f = !0, g = _.Ef(a, "message", e));
                return g
            }
        },
        ZP = function(a, b, c, d, e) {
            if (!(0 >= e) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (var f = 0; f < a.length; ++f) 1 < e && ZP(a[f], b, c, d, --e)
        },
        $P = function(a) {
            var b = 812 === a.screen.height && 375 === a.screen.width || 812 === a.screen.width && 375 === a.screen.height || 414 === a.screen.width && 896 === a.screen.height || 896 === a.screen.width && 414 === a.screen.height;
            return null != (a.navigator && a.navigator.userAgent && a.navigator.userAgent.match(/iPhone OS 1[1-9]|[2-9]\d/)) && b
        },
        dQ = function(a, b) {
            _.U.call(this);
            this.A = a;
            this.j = this.v = this.g = !1;
            if (_.Zg(a) && b.length)
                for (a = _.z(b), b = a.next(); !b.done; b = a.next()) switch (b.value) {
                    case 0:
                        aQ(this);
                        break;
                    case 1:
                        bQ(this);
                        break;
                    case 2:
                        cQ(this)
                } else this.ua()
        };
    _.T(dQ, _.U);
    dQ.prototype.na = function() {
        this.J || this.l(_.Zg(this.A))
    };
    var aQ = function(a) {
            var b = function(d) {
                    d.isTrusted && (a.v = !0, a.l(d.timeStamp))
                },
                c = function(d) {
                    d.isTrusted && (a.v = !1, a.l(d.timeStamp))
                };
            _.lb(a.A, "focus", b);
            _.lb(a.A, "blur", c);
            _.yn(a, function() {
                return void a.A.removeEventListener("focus", b)
            });
            _.yn(a, function() {
                return void a.A.removeEventListener("blur", c)
            });
            a.v = a.A.document.hasFocus()
        },
        bQ = function(a) {
            var b = function(c) {
                c.isTrusted && (a.g = 1 === _.sq(a.A.document) ? !0 : !1, a.l(c.timeStamp))
            };
            _.lb(a.A.document, "visibilitychange", b);
            _.yn(a, function() {
                return void a.A.document.removeEventListener("visibilitychange", b)
            });
            a.g = 1 === _.sq(a.A.document)
        },
        cQ = function(a) {
            var b = a.A.document.body.getBoundingClientRect().top + 10,
                c = function(d) {
                    d.isTrusted && (a.j = d.clientY < b ? !0 : !1, a.l(d.timeStamp))
                };
            _.lb(a.A.document.body, "mouseleave", c);
            _.lb(a.A.document.body, "mouseenter", c);
            _.yn(a, function() {
                return void a.A.document.body.removeEventListener("mouseleave", c)
            });
            _.yn(a, function() {
                return void a.A.document.body.removeEventListener("mouseenter", c)
            });
            a.j = !1
        },
        eQ = function() {
            dQ.apply(this, arguments);
            this.L = new _.pg;
            this.H = this.L.promise
        };
    _.T(eQ, dQ);
    var fQ = function(a) {
        eQ.call(this, a, [0, 1, 2]);
        this.G = 0;
        this.na()
    };
    _.T(fQ, eQ);
    fQ.prototype.l = function(a) {
        var b = this;
        switch (this.G) {
            case 0:
                this.v && !this.j && (this.G = 1);
                break;
            case 1:
                if (!this.v && this.g && this.j) {
                    this.G = 2;
                    var c = setTimeout(function() {
                        b.l(a)
                    }, 200);
                    _.yn(this, function() {
                        return void clearTimeout(c)
                    })
                }
                break;
            case 2:
                !this.v && this.g && this.j ? (this.L.resolve(a), this.ua()) : this.G = 1
        }
    };
    var gQ = function(a) {
        eQ.call(this, a, [1]);
        this.na()
    };
    _.T(gQ, eQ);
    gQ.prototype.l = function(a) {
        null != this.G || (this.G = 0);
        switch (this.G) {
            case 0:
                this.g && (this.G = 1);
                break;
            case 1:
                this.g || (this.G = 2, this.B = a);
                break;
            case 2:
                this.g && (this.o = a - this.B, this.L.resolve(a), this.ua())
        }
    };
    var hQ = function(a, b, c) {
        _.U.call(this);
        var d = this;
        c.promise.then(function() {
            return void d.ua()
        });
        b = _.z(b);
        for (var e = b.next(), f = {}; !e.done; f = {
                Gb: f.Gb
            }, e = b.next()) switch (f.Gb = e.value, f.Gb) {
            case 2:
                e = new gQ(a);
                _.S(this, e);
                e.H.then(function(g) {
                    return function() {
                        return void c.resolve(g.Gb)
                    }
                }(f));
                break;
            case 3:
                0 === (0, _.Tn)() && (e = new fQ(a), _.S(this, e), e.H.then(function(g) {
                    return function() {
                        return void c.resolve(g.Gb)
                    }
                }(f)))
        }
    };
    _.T(hQ, _.U);
    var iQ = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1,
            NOSCRIPT: 1
        },
        jQ = {
            IMG: " ",
            BR: "\n"
        },
        kQ = function(a, b, c, d) {
            if (!(a.nodeName in iQ))
                if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
                else if (a.nodeName in jQ) d && "IMG" == a.nodeName && a.hasAttribute("alt") && b.push(" " + a.getAttribute("alt")), b.push(jQ[a.nodeName]);
            else
                for (a = a.firstChild; a;) kQ(a, b, c, d), a = a.nextSibling
        },
        lQ = / \xAD /g,
        mQ = /\xAD/g,
        nQ = /\u200B/g,
        oQ = / +/g,
        pQ = /^\s*/,
        qQ = function(a) {
            var b = new _.v.Set;
            a.forEach(function(c) {
                switch (c) {
                    case 1:
                        b.add(1);
                        break;
                    case 2:
                        b.add(2);
                        break;
                    case 3:
                        b.add(3)
                }
            });
            return b
        },
        rQ = function(a, b) {
            var c = this;
            this.l = a;
            this.g = !1;
            this.v = b;
            this.m = this.v.va(264, function(d) {
                c.g && (_.tP || (d = Date.now()), c.l(d), _.tP ? _.sP.call(_.t, c.m) : _.t.setTimeout(c.m, 17))
            })
        };
    rQ.prototype.start = function() {
        this.g || (this.g = !0, _.tP ? _.sP.call(_.t, this.m) : this.m(0))
    };
    var sQ = function(a, b, c, d) {
        this.g = a;
        this.G = b;
        this.B = c;
        this.progress = 0;
        this.m = null;
        this.j = !1;
        this.v = [];
        this.J = null;
        this.l = new rQ((0, _.Wu)(this.sa, this), d)
    };
    sQ.prototype.sa = function(a) {
        if (this.j) this.l.g = !1;
        else {
            null === this.m && (this.m = a);
            this.progress = (a - this.m) / this.B;
            1 <= this.progress && (this.progress = 1);
            a = this.J ? this.J(this.progress) : this.progress;
            this.v = [];
            for (var b = 0; b < this.g.length; b++) this.v.push((this.G[b] - this.g[b]) * a + this.g[b]);
            this.o();
            1 == this.progress && (this.l.g = !1, this.H())
        }
    };
    sQ.prototype.H = function() {};
    sQ.prototype.o = function() {};
    sQ.prototype.reset = function(a, b, c) {
        this.m = null;
        this.g = a;
        this.G = b;
        this.B = c;
        this.progress = 0
    };
    var tQ = function(a) {
            return a * a * a
        },
        uQ = function(a) {
            a = 1 - a;
            return 1 - a * a * a
        },
        vQ = function(a, b, c, d, e, f, g, h) {
            sQ.call(this, [b], [c], d, f);
            this.F = a;
            this.I = e;
            this.L = g ? g : null;
            this.J = h || null
        };
    _.T(vQ, sQ);
    vQ.prototype.o = function() {
        var a = {};
        a[this.I] = _.AH(this.v[0]);
        _.Yz(this.F, a)
    };
    vQ.prototype.H = function() {
        this.L && this.L()
    };
    var DP = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.slotType = a;
        this.H = b;
        this.qh = c;
        this.G = d;
        this.Ja = e;
        this.pf = f;
        this.g = 1;
        this.qem = null;
        this.j = new _.pg;
        this.l = new _.pg;
        this.v = new _.pg
    };
    _.T(DP, _.U);
    var wQ = function(a) {
            return _.nb(function(b) {
                return b.return(a.j.promise)
            })
        },
        xQ = function(a) {
            return _.nb(function(b) {
                return b.return(a.l.promise)
            })
        },
        yQ = function(a) {
            return _.nb(function(b) {
                return b.return(a.v.promise)
            })
        };
    DP.prototype.na = function() {
        var a = this,
            b = CP(this.H, this.qh, function(c) {
                if ("adError" === c.eventType) a.v.resolve(), a.g = 0;
                else if ("adReady" === c.eventType && 1 === a.g) a.qem = c.qem, c.slotType !== a.slotType && (zQ(a, {
                    cur_st: a.g,
                    evt: c.eventType,
                    adp_tp: c.slotType
                }), a.g = 0), a.j.resolve(), a.g = 2;
                else if ("adClosed" === c.eventType && 2 === a.g) a.l.resolve(c.result), a.g = 3;
                else if ("adClosed" !== c.eventType || 3 !== a.g) zQ(a, {
                    cur_st: a.g,
                    evt: c.eventType
                }), a.g = 0
            }, this.G);
        _.yn(this, b)
    };
    var zQ = function(a, b) {
        var c = .25;
        c = void 0 === c ? .01 : c;
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = c;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.pf.Xl;
        b.version = a.pf.version;
        _.Xg(a.Ja, "fullscreen_tag", b, !1, c)
    };
    var CQ = function(a) {
            var b = AQ(_.hz(_.bz(a))) || [];
            return !!_.fh(a, function(c) {
                if (!_.ka(c) || 1 != c.nodeType) return !1;
                var d = c.matches || c.webkitMatchesSelector || c.mozMatchesSelector || c.msMatchesSelector || c.oMatchesSelector;
                return !d || 0 <= _.fa(b, c) || _.dh(_.uz(BQ), function(e) {
                    return d.call(c, e)
                })
            }, !1, 20)
        },
        AQ = function(a) {
            var b = _.ku(a);
            return b ? _.bh(_.iv(b.pubads().getSlots(), function(c) {
                return a.document.getElementById(c.getSlotElementId())
            }), function(c) {
                return null != c
            }) : null
        },
        BQ = {
            vm: "ins.adsbygoogle-ablated-ad-slot",
            xm: "body ins.adsbygoogle",
            wm: "iframe[id^=aswift_],iframe[id^=google_ads_frame]",
            Jm: ".google-auto-placed",
            Km: "ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]",
            Lm: "iframe[id^=google_ads_iframe]",
            Qm: "div[id^=div-gpt-ad]",
            jn: "ins.adsbygoogle[data-ad-format=autorelaxed]",
            kn: "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]",
            Pm: "div.googlepublisherpluginad",
            An: "html > ins.adsbygoogle"
        };
    var DQ = function() {};
    DQ.prototype.log = function() {};
    var EQ = ["mousemove", "mousedown", "scroll", "keydown"],
        GQ = function(a) {
            _.U.call(this);
            var b = this;
            this.A = a;
            this.g = [];
            this.l = _.ev(function() {
                FQ(b)
            })
        };
    _.T(GQ, _.U);
    GQ.prototype.listen = function(a) {
        this.l();
        this.g.push(a)
    };
    var FQ = function(a) {
        for (var b = null, c = null, d = function(l) {
                if (b && 3E4 < l.timeStamp - b)
                    for (var m = {
                            Xc: l.timeStamp,
                            Hk: l.timeStamp - b,
                            nm: c
                        }, n = _.z(a.g), p = n.next(); !p.done; p = n.next()) {
                        p = p.value;
                        try {
                            p(m)
                        } catch (r) {}
                    }
                b = l.timeStamp
            }, e = _.z(EQ), f = e.next(); !f.done; f = e.next()) a.A.addEventListener(f.value, d);
        var g = null,
            h, k;
        (null == (h = a.A.navigator) ? 0 : h.userActivation) && (null == (k = a.A.performance) ? 0 : k.now) && (g = a.A.setInterval(function() {
            a.A.navigator.userActivation.isActive && (c = a.A.performance.now())
        }, 1E3));
        _.yn(a, function() {
            for (var l = _.z(EQ), m = l.next(); !m.done; m = l.next()) a.A.removeEventListener(m.value, d);
            g && a.A.clearInterval(g)
        })
    };
    var IQ = function(a) {
        _.U.call(this);
        var b = this;
        this.A = a;
        this.g = [];
        this.l = _.ev(function() {
            HQ(b)
        })
    };
    _.T(IQ, _.U);
    IQ.prototype.listen = function(a) {
        this.l();
        this.g.push(a)
    };
    var HQ = function(a) {
        var b = null,
            c = function(e) {
                e.isTrusted && (b = e.timeStamp)
            },
            d = function(e) {
                var f = e.timeStamp;
                if (e.isTrusted) {
                    e = _.A(Object, "assign").call(Object, {}, {
                        Xc: f
                    }, b ? {
                        Yl: f - b
                    } : null);
                    f = _.z(a.g);
                    for (var g = f.next(); !g.done; g = f.next()) {
                        g = g.value;
                        try {
                            g(e)
                        } catch (h) {}
                    }
                }
            };
        a.A.addEventListener("focus", d);
        a.A.addEventListener("blur", c);
        _.yn(a, function() {
            a.A.removeEventListener("focus", d);
            a.A.removeEventListener("blur", c)
        })
    };
    var JQ = function(a, b, c, d, e, f) {
        _.U.call(this);
        var g = this;
        this.Ja = c;
        this.l = d;
        this.j = e;
        this.v = Math.floor(2147483647 * _.gg());
        this.g = function(h, k, l) {
            l = void 0 === l ? {} : l;
            h = _.A(Object, "assign").call(Object, {
                etc: g.v,
                e: h,
                t: Math.round(k),
                qqid: g.l,
                ptt: g.j
            }, l);
            _.Xg(g.Ja, "eit", h, !0, 1)
        };
        this.g(1, b);
        b = _.z(f);
        d = b.next();
        for (c = {}; !d.done; c = {
                qc: c.qc,
                Zd: c.Zd
            }, d = b.next()) switch (c.qc = d.value, c.qc) {
            case 101:
                d = new fQ(a);
                d.H.then(function(h) {
                    return function(k) {
                        return void g.g(h.qc, k)
                    }
                }(c));
                _.S(this, d);
                break;
            case 102:
                c.Zd = new gQ(a);
                c.Zd.H.then(function(h) {
                    return function(k) {
                        return void g.g(h.qc, k, {
                            tbd: Math.round(h.Zd.o || -1)
                        })
                    }
                }(c));
                _.S(this, c.Zd);
                break;
            case 103:
                d = new IQ(a);
                d.listen(function(h) {
                    return function(k) {
                        var l;
                        g.g(h.qc, k.Xc, {
                            tsb: null != (l = k.Yl) ? l : -1
                        })
                    }
                }(c));
                _.S(this, d);
                break;
            case 104:
                d = new GQ(a), d.listen(function(h) {
                    return function(k) {
                        var l;
                        g.g(h.qc, k.Xc, {
                            it: k.Hk,
                            ualta: null != (l = k.nm) ? l : -1
                        })
                    }
                }(c)), _.S(this, d)
        }
    };
    _.T(JQ, _.U);
    var LQ = function(a) {
            this.g = null;
            this.l = a.match(_.qz)[3] || "";
            this.v = KQ(a);
            this.m = !1
        },
        MQ = function(a, b) {
            b ? a.g = new RegExp("\\b(" + b.join("|").toLowerCase() + ")\\b", "ig") : a.g = null
        },
        PQ = function(a, b, c) {
            if (_.dh(["data-google-vignette", "data-google-interstitial"], function(f) {
                    return "false" === b.getAttribute(f) || b.closest && !!b.closest("[" + f + '="false"]')
                })) return !1;
            var d = b.href,
                e = d && (d.match(_.qz)[3] || null);
            if (!NQ(a, b, d, e, c)) return !1;
            a.m = !!e && OQ(a, e);
            return a.m || !c && !CQ(b) && /^https?:\/\//i.test(d) && !/((facebook|whatsapp|youtube|google)\.com)|\/ads?\//i.test(d)
        },
        NQ = function(a, b, c, d, e) {
            if (!c) return !1;
            switch (b.target) {
                case "_top":
                case "_parent":
                    break;
                case "":
                case "_self":
                    if (e) return !1;
                    break;
                default:
                    return !1
            }
            return !d || OQ(a, d) && KQ(c) == a.v ? !1 : !0
        },
        OQ = function(a, b) {
            return b.replace(QQ, "") == a.l.replace(QQ, "")
        },
        KQ = function(a) {
            a = a.match(_.qz);
            var b = a[6];
            return (a[5] || "") + (b ? "?" + b : "") || "/"
        },
        QQ = /^(www\.|m\.|mobile\.)*/i;
    var TQ = function(a, b, c, d, e) {
        e = void 0 === e ? {} : e;
        _.U.call(this);
        var f = this;
        this.v = a;
        this.ba = b;
        this.j = c;
        this.Ja = d;
        this.Ha = {};
        this.vd = this.j.va(168, function(g, h) {
            return void RQ(f, g, h)
        });
        this.Cd = this.j.va(169, function(g, h) {
            _.Xg(f.Ja, "ras::xsf", {
                c: h.data.substring(0, 500),
                u: f.v.location.href.substring(0, 500)
            }, !0, .1);
            return !0
        });
        this.M = [];
        SQ(this, this.Ha, e);
        this.M.push(BP(this.v, "sth", this.vd, this.Cd))
    };
    _.T(TQ, _.U);
    var RQ = function(a, b, c) {
        try {
            if (!a.Ca(c.origin) || !xP(c, a.ba.contentWindow)) return
        } catch (f) {
            return
        }
        var d = b.msg_type,
            e;
        "string" === typeof d && (e = a.Ha[d]) && a.j.Fb(168, function() {
            e.call(a, b, c)
        })
    };
    TQ.prototype.Ca = function(a) {
        return _.Hz[a] || RP.test(a) || SP.test(a) || TP.test(a)
    };
    TQ.prototype.m = function() {
        for (var a = _.z(this.M), b = a.next(); !b.done; b = a.next()) b = b.value, b();
        this.M.length = 0;
        _.U.prototype.m.call(this)
    };
    var XQ = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        TQ.call(this, a, b, c, e, {
            fullscreenApi: h.Yi
        });
        var p = this;
        this.L = d;
        this.la = f;
        this.B = h;
        this.kg = l;
        this.Ia = _.Yg();
        this.Va = "true" === g["i-fvs"];
        this.xd = g.qid;
        this.o = null != n ? n : new LQ(a.location.href);
        this.Yb = "true" === g.iobs && "IntersectionObserver" in this.v;
        var r, w;
        MQ(this.o, null != (w = null == (r = g.stop_word) ? void 0 : r.split(";")) ? w : null);
        this.G = this.B.Yi ? EP(a, b.contentWindow, c, e, this.B.pf) : null;
        this.H = {
            Oh: !1
        };
        this.l = {};
        this.wa = {
            tag: 0
        };
        this.g = {
            Qn: !0,
            qj: !1,
            re: !1,
            bg: !0
        };
        UQ(this);
        VQ(this);
        k.size && (b = new _.pg, b.promise.then(function(y) {
            p.g.Fd || p.J || WQ(p, y)
        }), this.oa = new hQ(a, k, b), _.S(this, this.oa));
        var u;
        if (null == (u = h.Bh) ? 0 : u.length)
            if (k = _.Zg(a)) {
                var x = new JQ(a, k, e, this.xd, 17, h.Bh);
                _.S(this, x);
                this.jc = function(y) {
                    x.g(2, y - _.ah(a))
                }
            }
    };
    _.T(XQ, TQ);
    var UQ = function(a) {
            a.G && (wQ(a.G).then(function() {
                FP(a.L);
                a.I()
            }), xQ(a.G).then(function() {
                return void YQ(a)
            }), yQ(a.G).then(function() {
                return void a.F()
            }))
        },
        SQ = function(a, b, c) {
            b["i-blur"] = function() {
                a.g.re = !0;
                a.g.Fg && (a.g.bg = !0)
            };
            b["i-no"] = function(d) {
                a.wa = {
                    tag: 1,
                    Tn: d.i_tslv ? d.i_tslv : void 0
                }
            };
            c.fullscreenApi || (b["i-adframe-load"] = function() {
                FP(a.L);
                a.I()
            }, b["i-dismiss"] = function() {
                YQ(a)
            }, b.i_iif = function() {
                a.F()
            })
        };
    XQ.prototype.I = function() {
        this.H.ai || (this.H.ai = _.Yg())
    };
    var YQ = function(a) {
        a.g.re ? ZQ(a) ? a.v.history.back() : $Q(a) : (_.t.setTimeout(function() {
            $Q(a)
        }, 1E3), a.g.tg && (a.g.Fg && (a.g.bg = !1), aR(a, a.g.tg)))
    };
    XQ.prototype.F = function() {
        this.H.Oh = !0
    };
    var bR = function(a) {
            ZQ(a) || (a.v.location.hash = "google_vignette");
            a.g.Fg = a.j.va(526, function() {
                a.g.bg && (ZQ(a) ? aR(a, a.l.Wa.href) : $Q(a))
            });
            _.t.setTimeout(_.Xu(_.lb, a.v, "hashchange", a.g.Fg), 0)
        },
        cR = function(a, b) {
            var c = _.Yg(),
                d = !_.mh(a.v).wasReactiveAdVisible[9];
            if (b) {
                var e = a.o;
                if (b && e.g) {
                    var f = [];
                    kQ(b, f, !0, !0);
                    b = f.join("");
                    b = b.replace(lQ, " ").replace(mQ, "");
                    b = b.replace(nQ, "");
                    b = b.replace(oQ, " ");
                    " " != b && (b = b.replace(pQ, ""));
                    if (b) {
                        e = b.match(e.g);
                        b = [];
                        for (f = 0; e && f < e.length; f++) {
                            var g = e[f].toLowerCase();
                            0 <= _.fa(b, g) || b.push(g)
                        }
                        e = b
                    } else e = []
                } else e = []
            } else e = [];
            b = a.B.Gk || yP(a.v);
            if (!(c = 864E5 <= c - a.Ia)) {
                a: switch (a.wa.tag) {
                    case 0:
                        c = !0;
                        break a;
                    case 1:
                        c = !1;
                        break a;
                    default:
                        c = !1
                }
                c = !c
            }
            return c || a.H.Oh || ZQ(a) || !a.H.ai || !a.Va && !d || e.length || !b || a.la.width < a.la.height !== _.Cg(a.v) ? !1 : !0
        },
        eR = function(a, b) {
            a.g.Tc = dR(a, b, "prerender");
            a.g.Sc = dR(a, b, "prefetch");
            a.v.document.body.appendChild(a.g.Tc);
            a.v.document.body.appendChild(a.g.Sc)
        },
        dR = function(a, b, c) {
            a = _.rf("LINK", a.v.document);
            a.setAttribute("rel", c);
            a.setAttribute("href", b);
            return a
        },
        fR = function(a, b) {
            for (b = b.target; b;) {
                if ("nodeName" in b && "A" === b.nodeName) {
                    if (PQ(a.o, b, b.ownerDocument !== a.v.document)) return b;
                    break
                }
                b = "parentElement" in b ? b.parentElement : null
            }
            return null
        };
    XQ.prototype.m = function() {
        TQ.prototype.m.call(this);
        ZQ(this) && aR(this, this.l.Wa.href);
        this.l.xb && (_.Ef(this.v.document, "click", this.l.xb), this.l.xb = void 0)
    };
    var $Q = function(a) {
            a.g.Fd && (a.g.qj = !0, a.l.xb && (_.Ef(a.v.document, "click", a.l.xb), a.l.xb = void 0), a.g.Tc && a.g.Tc.parentNode && (a.g.Tc.parentNode.removeChild(a.g.Tc), a.g.Tc = void 0), a.g.Sc && a.g.Sc.parentNode && (a.g.Sc.parentNode.removeChild(a.g.Sc), a.g.Sc = void 0), gR(a.L, !1))
        },
        VQ = function(a) {
            if (!a.l.xb) {
                a.l.xb = a.j.va(527, function(e) {
                    hR(a, e)
                });
                if (null !== a.l.xb) {
                    var b = a.l.xb;
                    _.lb(a.v.document, "click", function(e) {
                        b(e)
                    }, LP)
                }
                for (var c = a.v.frames, d = 0; d < c.length; d++) try {
                    _.lb(c[d].document, "click", a.l.xb, LP)
                } catch (e) {}
            }
        },
        aR = function(a, b) {
            a = a.v.location;
            b = _.Va(b);
            b = _.ab(b);
            void 0 !== b && a.replace(b)
        },
        WQ = function(a, b) {
            if (cR(a)) {
                b = 1 === b;
                if (a.B.Zj) {
                    var c;
                    (c = a.g).re || (c.re = !b)
                }
                if (a.Da()) {
                    a.g.Fd = Date.now();
                    _.mh(a.v).wasReactiveAdVisible[8] = !0;
                    b && a.l.Wa && (a.g.tg = a.l.Wa.href);
                    iR(a);
                    a.l.Wa && eR(a, a.l.Wa.href);
                    bR(a);
                    _.lb(a.v, "pagehide", a.j.va(528, function() {
                        $Q(a)
                    }));
                    if (b) {
                        var d;
                        null == (d = a.jc) || d.call(a, a.g.Fd)
                    }
                    gR(a.L, !0);
                    var e;
                    null == (e = a.oa) || e.ua()
                } else b && a.l.Wa && aR(a, a.l.Wa.href)
            }
        };
    XQ.prototype.bc = function(a) {
        this.g.Fd || this.J || !this.l.Wa || (a.preventDefaultTriggered ? this.l.Wa = void 0 : PQ(this.o, this.l.Wa, this.l.Wa.ownerDocument !== this.v.document) && cR(this, this.l.Wa) && WQ(this, 1))
    };
    XQ.prototype.Da = function() {
        return !0
    };
    var hR = function(a, b) {
            if (b && !(b.defaultPrevented || a.g.Fd || a.g.tg || a.J || a.l.Wa)) {
                var c = fR(a, b);
                c && cR(a, c) && (a.l.Wa = c, UP(b), b.preventDefault = function() {
                    return b && (b.preventDefaultTriggered = !0)
                }, _.t.setTimeout((0, _.Wu)(a.bc, a, b), 0))
            }
        },
        ZQ = function(a) {
            return -1 !== a.v.location.hash.indexOf("google_vignette")
        },
        iR = function(a) {
            if (!a.Yb)
                if (a.G) _.t.IntersectionObserver || a.G.qh.postMessage(JSON.stringify({
                    eventType: "visible",
                    googMsgType: "fullscreen"
                }), "*");
                else {
                    var b = {};
                    b = (b.msg_type = "i-view", b);
                    var c;
                    (null == (c = a.ba) ? void 0 : c.contentWindow).postMessage(JSON.stringify(b), "*")
                }
        };
    var kR = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.g = a;
        this.l = b;
        this.v = c;
        _.lb(this.g, this.l, this.v, LP);
        _.yn(this, function() {
            return void jR(d)
        })
    };
    _.T(kR, _.U);
    var jR = function(a) {
            a.g && _.Ef(a.g, a.l, a.v, LP)
        },
        lR = function(a) {
            this.l = a;
            this.reset()
        };
    lR.prototype.add = function(a) {
        var b = Date.now();
        this.g.push({
            time: b,
            coords: a
        });
        for (a = this.m; a < this.g.length; ++a)
            if (b - this.g[a].time >= this.l) delete this.g[a];
            else break;
        this.m = a;
        a >= this.g.length && this.reset()
    };
    lR.prototype.reset = function() {
        this.g = [];
        this.m = 0
    };
    var nR = function(a, b, c, d) {
        _.U.call(this);
        var e = this;
        this.j = a;
        this.target = b;
        this.handle = c || b;
        this.oa = d || 100;
        this.L = this.H = this.T = !1;
        this.G = this.g = this.l = this.v = this.F = this.o = this.I = this.B = null;
        this.Pa = new kR(this.handle, "mousedown", function(f) {
            0 == f.button && mR(e, f)
        });
        _.S(this, this.Pa);
        this.Va = new kR(this.handle, "touchstart", function(f) {
            return mR(e, f)
        });
        _.S(this, this.Va);
        this.Ia = new kR(this.handle, "click", function(f) {
            e.T ? (e.onClick(), e.T = !1) : f.stopPropagation()
        });
        _.S(this, this.Ia)
    };
    _.T(nR, _.U);
    var oR = function(a) {
        a = a.touches && a.touches[0] || a;
        return new _.ui(a.clientX, a.clientY)
    };
    nR.prototype.ba = function() {
        if (this.v && this.l && this.g) {
            var a = this.v,
                b = MP(this.g, this.l);
            var c = new _.ui(a.x + b.x, a.y + b.y);
            a = this.target;
            c instanceof _.ui ? (b = c.x, c = c.y) : (b = c, c = void 0);
            a.style.left = _.eA(b, !1);
            a.style.top = _.eA(c, !1)
        }
    };
    nR.prototype.ca = function() {};
    nR.prototype.onClick = function() {};
    nR.prototype.M = function() {
        var a = this.target,
            b = _.lz(a);
        var c = VP(a);
        b = VP(b);
        c = new _.ui(c.x - b.x, c.y - b.y);
        a = YP(a, "margin");
        return MP(c, new _.ui(a.left, a.top))
    };
    var mR = function(a, b) {
        a.H && pR(a);
        a.H = !0;
        a.v = a.M();
        a.l = oR(b);
        a.g = a.l;
        a.G = new lR(a.oa);
        a.G.add(a.l);
        a.B = new kR(a.j, "mousemove", (0, _.Wu)(a.Ha, a));
        _.S(a, a.B);
        a.I = new kR(a.j, "touchmove", (0, _.Wu)(a.Ha, a));
        _.S(a, a.I);
        a.o = new kR(a.j, "mouseup", (0, _.Wu)(a.la, a));
        _.S(a, a.o);
        a.F = new kR(a.j, "touchend", (0, _.Wu)(a.la, a));
        _.S(a, a.F)
    };
    nR.prototype.Ha = function(a) {
        if (this.H)
            if (a.preventDefault(), this.g = oR(a), this.G.add(this.g), this.L) this.ba();
            else {
                var b = this.l,
                    c = this.g;
                a = b.x - c.x;
                b = b.y - c.y;
                10 <= Math.sqrt(a * a + b * b) && (this.ba(), this.L = !0)
            }
    };
    nR.prototype.la = function(a) {
        this.L ? (a.preventDefault(), this.g = oR(a), this.ca()) : this.T = !0;
        pR(this)
    };
    var pR = function(a) {
        a.H = !1;
        a.L = !1;
        a.v = null;
        a.l = null;
        a.g = null;
        a.G = null;
        a.B && jR(a.B);
        a.I && jR(a.I);
        a.o && jR(a.o);
        a.F && jR(a.F)
    };
    var sR = function(a, b, c, d, e, f, g, h, k, l, m) {
        _.U.call(this);
        var n = this;
        this.config = a;
        this.ka = b;
        this.T = c;
        this.H = d;
        this.la = f || function() {};
        this.da = g || function() {};
        this.o = h;
        this.Ja = k;
        this.Ca = l;
        this.Ha = m;
        _.yn(this, function() {
            return qR(n, !0)
        });
        this.L = _.rf("INS", b.document);
        _.yn(this, function() {
            return n.L = null
        });
        this.l = null;
        HTMLElement.prototype.attachShadow && !this.o.Fb(1013, function() {
            n.l = _.rf("DIV", b.document);
            n.l.className = "grippy-host";
            n.l.attachShadow({
                mode: "closed"
            }).appendChild(n.L);
            _.yn(n, function() {
                return n.l = null
            });
            return !0
        }) && (this.l = null);
        this.F = this.j = this.G = !1;
        this.B = 0;
        this.g = e;
        this.M = !1;
        this.v = this.ba = null;
        this.ma = b.innerHeight;
        this.ca = "true" === this.config.scroll_detached;
        this.I = "true" === this.config.dismissable;
        this.Pa = "true" === this.config.draggable || "top" != this.g;
        this.Da = this.config.expId || "";
        this.oa = this.config.qemId || "";
        a = parseInt(this.config.z_index_override, 10);
        this.wa = isNaN(a) ? null : a;
        this.Ia = new _.zG(b);
        !this.I && _.t.navigator.userAgent.match(/iPhone OS 7/) && b.setInterval(function() {
            var p = n.ka.innerHeight;
            if (2 > Math.abs(p - 460) || 2 > Math.abs(p - 529)) p < n.ma && 2 > Math.abs(_.Mg(n.ka) - n.B - 68) && (n.M = !0, n.j && n.show()), n.ma = p
        }, 300);
        rR(this, this.L)
    };
    _.T(sR, _.U);
    var rR = function(a, b) {
            AP(b);
            _.Yi(b, {
                "background-color": "#FAFAFA",
                display: "block",
                position: "relative",
                "z-index": 1,
                height: _.AH(5),
                "box-shadow": "top" == a.g ? "rgba(0, 0, 0, 0.2) 0px 1px 5px -1px, rgba(0, 0, 0, 0.1) 0px -1px 2px -1px" : "rgba(0, 0, 0, 0.2) 0px -1px 5px -1px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px"
            });
            if ("top" == a.g) {
                var c = {
                        position: "absolute",
                        top: _.AH(a.H.height),
                        width: "100%"
                    },
                    d;
                _.Yi(null != (d = a.l) ? d : b, c)
            }
            var e = _.rf("SPAN", a.ka.document);
            e.appendChild(tR(a));
            var f = function(g) {
                g.target === e && (g.preventDefault && g.preventDefault(), g.stopImmediatePropagation && g.stopImmediatePropagation(), g.stopPropagation && g.stopPropagation())
            };
            _.lb(e, "click", f);
            _.yn(a, function() {
                return _.Ef(e, "click", f)
            });
            uR(a, e);
            b.className = "ee";
            b.appendChild(e)
        },
        uR = function(a, b) {
            var c = {};
            a = (c.display = "block", c.width = "80px", c.height = "45px", c[a.g] = "0", c.left = "0%", c.marginLeft = "0px", c["pointer-events"] = "none", c);
            c = b.getElementsByTagName("svg")[0];
            _.Yi(b, a);
            zP(c)
        },
        vR = function(a) {
            var b;
            return null != (b = a.l) ? b : a.L
        },
        tR = function(a) {
            switch (a.g) {
                case "top":
                    var b = "dropShadowBottom";
                    var c = "M0,4 L0,22 A6,6 0 0,0 6,28 L50,28 A6,6 0 0,0 56,22 L56,10 A6,6 0 0,1 61,4 Z";
                    var d = "0";
                    var e = "up";
                    var f = GP;
                    break;
                case "bottom":
                    b = "dropShadowTop", c = "M0,26 L0,6 A6,6 0 0,1 6,1 L50,1 A6,6 0 0,1 56,6 L56,20 A6,6 0 0,0 62,26 Z", d = "25", e = "down", f = HP
            }
            var g = a.ka.document,
                h = g.createElementNS("http://www.w3.org/2000/svg", "svg");
            h.style.setProperty("margin", "0 0 0 0px", "important");
            h.style.setProperty("position", "absolute", "important");
            h.style.setProperty(a.g, "0", "important");
            h.style.setProperty("left", "0%", "important");
            h.style.setProperty("display", "block", "important");
            h.style.setProperty("width", "80px", "important");
            h.style.setProperty("height", "30px", "important");
            h.style.setProperty("transform", "none", "important");
            h.style.setProperty("pointer-events", "initial", "important");
            a = g.createElementNS("http://www.w3.org/2000/svg", "defs");
            var k = g.createElementNS("http://www.w3.org/2000/svg", "filter");
            k.setAttribute("id", b);
            k.setAttribute("filterUnits", "userSpaceOnUse");
            k.setAttribute("color-interpolation-filters", "sRGB");
            var l = g.createElementNS("http://www.w3.org/2000/svg", "feComponentTransfer");
            l.setAttribute("in", "SourceAlpha");
            l.setAttribute("result", "TransferredAlpha");
            var m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncR");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            l.appendChild(m);
            m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncG");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            l.appendChild(m);
            m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncB");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            l.appendChild(m);
            k.appendChild(l);
            l = g.createElementNS("http://www.w3.org/2000/svg", "feGaussianBlur");
            l.setAttribute("in", "TransferredAlpha");
            l.setAttribute("stdDeviation", "2");
            k.appendChild(l);
            l = g.createElementNS("http://www.w3.org/2000/svg", "feOffset");
            l.setAttribute("dx", "0");
            l.setAttribute("dy", "0");
            l.setAttribute("result", "offsetblur");
            k.appendChild(l);
            l = g.createElementNS("http://www.w3.org/2000/svg", "feMerge");
            l.appendChild(g.createElementNS("http://www.w3.org/2000/svg", "feMergeNode"));
            m = g.createElementNS("http://www.w3.org/2000/svg", "feMergeNode");
            m.setAttribute("in", "SourceGraphic");
            l.appendChild(m);
            k.appendChild(l);
            a.appendChild(k);
            h.appendChild(a);
            a = g.createElementNS("http://www.w3.org/2000/svg", "path");
            a.setAttribute("d", c);
            a.setAttribute("stroke", "#FAFAFA");
            a.setAttribute("stroke-width", "1");
            a.setAttribute("fill", "#FAFAFA");
            a.style.setProperty("filter", "url(#" + b + ")");
            h.appendChild(a);
            b = g.createElementNS("http://www.w3.org/2000/svg", "rect");
            b.setAttribute("x", "0");
            b.setAttribute("y", d);
            b.setAttribute("width", "80");
            b.setAttribute("height", "5");
            b.style.setProperty("fill", "#FAFAFA");
            h.appendChild(b);
            d = g.createElementNS("http://www.w3.org/2000/svg", "g");
            d.setAttribute("class", e);
            d.setAttribute("stroke", "#616161");
            d.setAttribute("stroke-width", "2px");
            d.setAttribute("stroke-linecap", "square");
            f(d);
            h.appendChild(d);
            return h
        },
        wR = function(a, b) {
            for (var c = a.L.getElementsByTagName("svg")[0].getElementsByTagName("g")[0], d; d = c.firstChild;) c.removeChild(d);
            switch (a.g) {
                case "top":
                    (b ? HP : GP)(c);
                    break;
                case "bottom":
                    (b ? GP : HP)(c)
            }
        },
        xR = function(a, b, c, d) {
            b = {
                i: b,
                dc: a.j ? "1" : "0",
                fdc: c ? "1" : "0",
                ds: a.I ? "1" : "0",
                expId: a.Da,
                sc: a.ca ? "1" : "0",
                off: d,
                vw: _.Dg(a.ka),
                req: a.T.src,
                tp: a.g,
                h: a.H.height,
                w: a.H.width,
                qemId: a.oa
            };
            _.Xg(a.Ja, "flgr", b, !0, 1)
        };
    sR.prototype.onClick = function(a) {
        a.preventDefault();
        this.G || (this.M = !0, this.j ? this.show() : qR(this, this.I), xR(this, "c", !this.j, 0))
    };
    sR.prototype.show = function() {
        var a = this;
        if (!this.G) {
            var b = parseInt(this.v.style[this.g], 10);
            if (b) {
                this.G = !0;
                var c = -b / .1;
                "bottom" == this.g && $P(this.ka) && this.o.Fb(404, function() {
                    return yR(a, "0px", c, "ease-out")
                });
                wR(this, !1);
                b = new vQ(this.v, b, 0, c, this.g, this.o, function() {
                    a.G = !1;
                    a.j = !1;
                    a.F = !1;
                    zR(a);
                    a.v.setAttribute("data-anchor-status", "displayed");
                    a.v.setAttribute("data-anchor-shown", !0);
                    wR(a, !1)
                }, uQ);
                this.Ha();
                b.j = !1;
                b.l.start()
            } else this.F = this.j = !1
        }
    };
    var qR = function(a, b) {
            if (!a.G && a.v) {
                var c = parseInt(a.v.style[a.g], 10),
                    d = -a.H.height - (b ? 30 : 0),
                    e = (c - d) / .1;
                "bottom" == a.g && $P(a.ka) && a.o.Fb(405, function() {
                    return yR(a, "21px", e, "ease-in")
                });
                b || wR(a, !0);
                c === d ? (a.j = !b, a.F = b) : (a.G = !0, c = new vQ(a.v, c, d, e, a.g, a.o, function() {
                    a.G = !1;
                    a.j = !b;
                    (a.F = b) || wR(a, !0);
                    b && a.la();
                    a.v.setAttribute("data-anchor-status", "dismissed")
                }, tQ), a.Ca(), c.j = !1, c.l.start())
            }
        },
        CR = function(a, b) {
            if ("bottom" !== a.g && "top" !== a.g) throw Error("unsupported reactive type");
            var c = function(f) {
                    return a.onClick(f)
                },
                d = a.L;
            _.lb(d, "click", c);
            _.yn(a, function() {
                return _.Ef(d, "click", c)
            });
            a.l && (_.lb(a.l, "click", c), _.yn(a, function() {
                return a.l && _.Ef(a.l, "click", c)
            }));
            _.Yz(b, {
                opacity: 1
            });
            var e = a.ka.document;
            e && (a.v = b, a.Pa && (a.ba = new("top" == a.g ? AR : BR)(a, e, a.H.height, b, a.L), _.S(a, a.ba)), e = {
                position: "fixed",
                left: _.AH(0)
            }, e[a.g] = _.AH(-a.H.height - 30), _.Yz(b, e), _.Yi(b, {
                overflow: "visible",
                background: "#FAFAFA"
            }), _.DG(a.Ia, function(f) {
                var g = null == a.wa ? 2147483647 : a.wa;
                _.Yz(b, {
                    zIndex: null == f ? g : Math.min(f, g)
                })
            }), a.show())
        },
        yR = function(a, b, c, d) {
            _.Yz(a.T, {
                transition: c / 1E3 + "s",
                "transition-timing-function": d,
                "margin-top": b
            })
        },
        zR = function(a) {
            a.da();
            a.da = function() {}
        },
        DR = function(a, b, c, d, e) {
            nR.call(this, b, d, e);
            this.Da = a;
            this.Ca = c
        };
    _.T(DR, nR);
    DR.prototype.ca = function() {
        var a = this.Da;
        if (!a.G) {
            var b = parseInt(a.v.style[a.g], 10);
            b >= -(a.H.height / 2) ? (a.show(), xR(a, "d", !1, b)) : (qR(a, a.I), xR(a, "d", !0, b))
        }
    };
    DR.prototype.ba = function() {
        if (null !== this.v && null !== this.l && null !== this.g) {
            var a = this.wa(this.v.y, MP(this.g, this.l).y);
            0 < a && (a = 0);
            a < -this.Ca && (a = -this.Ca);
            var b = {};
            b[this.da()] = _.AH(a);
            _.Yz(this.target, b)
        }
    };
    var AR = function(a, b, c, d, e) {
        DR.call(this, a, b, c, d, e)
    };
    _.T(AR, DR);
    AR.prototype.M = function() {
        return new _.ui(0, parseInt(this.target.style.top, 10))
    };
    AR.prototype.wa = function(a, b) {
        return b - a
    };
    AR.prototype.da = function() {
        return "top"
    };
    var BR = function(a, b, c, d, e) {
        DR.call(this, a, b, c, d, e)
    };
    _.T(BR, DR);
    BR.prototype.M = function() {
        return new _.ui(0, parseInt(this.target.style.bottom, 10))
    };
    BR.prototype.wa = function(a, b) {
        return a - b
    };
    BR.prototype.da = function() {
        return "bottom"
    };
    var KR = function(a, b, c, d, e, f, g) {
        g = void 0 === g ? !1 : g;
        _.uP.call(this, a, b, f);
        var h = this;
        this.H = d;
        this.Ja = e;
        this.B = this.ic = this.bc = 0;
        this.Va = this.aj = !1;
        this.j = null;
        this.ba = this.la = !1;
        this.I = null;
        this.Ca = YP(b.document.body, "padding");
        this.o = YP(b.document.body, "padding");
        this.M = 0;
        this.ji = this.F = !1;
        this.wa = !0;
        this.G = c;
        this.L = ER(this);
        this.ca = null;
        this.xd = this.Cd = this.oa = this.Pa = this.Ia = this.bi = this.bj = this.fj = !1;
        this.kj = _.fz(b || window).height / 2;
        this.hj = _.fz(b || window).height;
        this.Xh = NP(b);
        this.Wh = this.da = this.jc = !1;
        this.Ha = g;
        FR(this);
        this.ki = this.H.va(266, function() {
            GR(h)
        });
        this.ni = this.H.va(267, function() {
            GR(h)
        });
        this.xi = this.H.va(268, function() {
            if (h.F && h.l && h.j) {
                var k = h.j;
                k.B = _.Mg(k.ka)
            }
            k = _.Mg(h.g);
            var l = k - h.bc;
            HR(h, l);
            h.oa && (0 < l && (h.B += l), h.jc = h.Xh - k <= h.hj, h.bc = k);
            GR(h)
        });
        this.yi = this.H.va(269, function() {
            IR(h)
        });
        this.Fi = this.H.va(270, function(k) {
            JR(h, k)
        });
        this.Pi = this.H.va(271, function(k) {
            if (k && k.touches) {
                h.I = "touchmove";
                h.M = k.touches.length;
                h.ba = !0;
                GR(h);
                if (!h.aj && k.touches && 0 != k.touches.length && k.touches[0]) {
                    k = k.touches[0].pageY;
                    var l = k - h.ic;
                    h.ic = k;
                    k = l
                } else k = 0;
                0 < k && (h.B += k);
                HR(h, k)
            }
        });
        this.Vi = this.H.va(272, function(k) {
            k && k.touches && k.touches[0] && (h.I = "touchstart", h.M = k.touches.length, h.ba = !1, GR(h), h.ic = k.touches[0].pageY, k = (k = k.target) && "top" == h.G && h.la && h.j && vR(h.j) && 1 === k.nodeType ? _.mz(vR(h.j), k) : !1, h.aj = k)
        });
        this.vd = this.H.va(273, function() {
            h.Ia || (h.Ia = !0, _.Ef(h.v, "load", h.vd), h.Pa && !h.ji || GR(h))
        });
        _.lb(a, "load", this.vd);
        _.yn(this, function() {
            return _.Ef(a, "load", h.vd)
        })
    };
    _.T(KR, _.uP);
    var MR = function(a) {
            var b = a.g;
            _.lb(b, "orientationchange", a.ki);
            _.lb(b, "resize", a.ni);
            _.lb(b, "scroll", a.xi);
            _.lb(b, "touchcancel", a.yi);
            _.lb(b, "touchend", a.Fi);
            _.lb(b, "touchmove", a.Pi);
            _.lb(b, "touchstart", a.Vi);
            _.yn(a, function() {
                return LR(a)
            })
        },
        LR = function(a) {
            var b = a.g;
            _.Ef(b, "orientationchange", a.ki);
            _.Ef(b, "resize", a.ni);
            _.Ef(b, "scroll", a.xi);
            _.Ef(b, "touchcancel", a.yi);
            _.Ef(b, "touchend", a.Fi);
            _.Ef(b, "touchmove", a.Pi);
            _.Ef(b, "touchstart", a.Vi)
        };
    KR.prototype.mj = function(a) {
        var b = this.l;
        if (b && !this.j) {
            for (var c in NR) !NR.hasOwnProperty(c) || c in a || (a[c] = NR[c]);
            this.fj = "true" === a.use_manual_view || "top" === this.G || !!_.mh(this.g).wasReactiveAdConfigReceived[2];
            this.bj = "true" === a.use_important;
            if (c = a.af_l) this.Pa = "true" === c;
            this.Wh = (this.oa = "true" === a.wait_for_scroll || "top" == this.G) && ("true" === a.tsec || "top" == this.G);
            OR(this, a);
            this.j = PR(this, a);
            this.ca = QR(this);
            this.jc = this.hj >= this.Xh;
            a = this.l;
            c = this.j && vR(this.j);
            a && c && ("top" == this.G ? a.appendChild(c) : a.insertBefore(c, a.firstChild));
            MR(this);
            this.la = !0;
            b.setAttribute("data-anchor-status", "ready-to-display")
        }
    };
    var QR = function(a) {
            var b = a.L.height + 5;
            "bottom" == a.G && $P(a.g) && (b += 20);
            return new _.Di(a.L.width, b)
        },
        OR = function(a, b) {
            var c = parseInt(b.ht, 10),
                d = 0 < c ? c : null;
            b = parseInt(b.wd, 10);
            var e = 0 < b ? b : null;
            null != d && (a.L.height = d);
            null != e && (a.L.width = e);
            KP(a, function(f) {
                IP(f, e, d)
            }, !1, !0);
            IP(a.v, e, d)
        },
        PR = function(a, b) {
            b = new sR(b, a.g, a.v, a.L, a.G, function() {
                if (!a.Va) {
                    a.Va = !0;
                    LR(a);
                    var c = a.l;
                    _.kz(c);
                    RR(a, a.Ca, !0, !0);
                    c && (c.style.display = "none")
                }
            }, function() {
                return void SR(a)
            }, a.H, a.Ja, function() {
                a.da || (a.da = !0, HR(a, null));
                _.FI(a.K, a.slotId)
            }, function() {
                a.da && (a.da = !1, HR(a, null));
                a.jj && _.GI(a.K, a.slotId)
            });
            _.S(a, b);
            return b
        },
        FR = function(a) {
            if (a.wa) {
                var b = a.l;
                b && (b.style.display = "none");
                RR(a, a.Ca, !0, !0);
                a.wa = !1
            }
        };
    KR.prototype.Da = function() {
        this.ji = !0;
        if (!this.F && TR(this) && (this.Ia || !this.Pa)) {
            var a = this.l;
            a && (UR(this), KP(this, function(b) {
                AP(b)
            }, !0), CR(this.j, a), VR(this), this.F = !0, (a = this.v.contentWindow) && ZP(a, "ig", {
                rr: "vis-aa"
            }, "*", 2))
        }
    };
    var VR = function(a) {
            var b = a.l;
            if (b) {
                var c = a.j,
                    d = c.ka,
                    e = _.Mg(d);
                if (!(10 > Math.abs(e - c.B))) {
                    var f = 10 > e;
                    d = e + 10 + _.Jg(d) > _.Lg(d);
                    f = f || d;
                    c.ca || c.M || c.G || (c.j || f ? c.j && f && c.show() : qR(c, !1));
                    c.B = e
                }
                a.wa || (WR(a), c = YP(a.g.document.body, "padding"), "bottom" == a.G && (c.bottom += a.ca.height + 25), RR(a, c), b.style.display = "block", a.wa = !0)
            }
        },
        UR = function(a) {
            var b = a.l;
            if (b && a.v.parentElement) {
                WP(b, a.ca);
                var c = a.g.innerWidth;
                _.Ig(a.g).scrollWidth > c ? b.style.width = c : b.style.width = (a.Ha ? 100 * _.Kg(a.g) : 100) + "%";
                YR(a)
            }
        },
        YR = function(a) {
            KP(a, function(c) {
                WP(c, a.L);
                c.style.width = (a.Ha ? 100 * _.Kg(a.g) : 100) + "%"
            }, !1, !0);
            a.v.style.display = "block";
            a.v.style.margin = "0 auto";
            if (a.bj) {
                var b = a.l;
                OP(b, function(c) {
                    zP(c, function(d) {
                        return c === b && /display|bottom/i.test(d) ? !1 : !0
                    });
                    if ("svg" === c.nodeName) return !1
                })
            }
        },
        WR = function(a) {
            if ("bottom" !== a.G && "top" !== a.G) throw Error("Unexpected position: " + a.G);
        },
        ER = function(a) {
            WR(a);
            var b = a.g.innerWidth;
            a = _.Bi(_.fA, a.v).height || +a.v.height || 0;
            return new _.Di(b, a)
        },
        IR = function(a) {
            a.I = "touchcancel";
            _.t.setTimeout(a.H.va(274, function() {
                "touchcancel" === a.I && (a.M = 0, a.ba = !1, GR(a))
            }), 1E3)
        },
        JR = function(a, b) {
            if (b && b.touches) {
                a.I = "touchend";
                var c = b.touches.length;
                2 > c ? _.t.setTimeout(a.H.va(256, function() {
                    "touchend" === a.I && (a.M = c, a.ba = !1, GR(a))
                }), 1E3) : (a.M = c, GR(a));
                !a.F || a.Ha || yP(a.g) || qR(a.j, !0)
            }
        },
        HR = function(a, b) {
            var c = a.wa ? ZR(a, a.da) : a.Ca.top;
            if ("top" === a.G && a.g.document.body && a.la && a.j && a.F && a.o.top !== c && 0 !== b) {
                var d = _.Sz(a.o);
                null === b ? (d.top = c, RR(a, d)) : (0 < b && a.o.top > c && (d.top = Math.max(c, a.o.top - b), RR(a, d, !1)), 0 > b && a.o.top < c && (d.top = Math.min(c, a.o.top - b), RR(a, d, !1)))
            }
        },
        RR = function(a, b, c, d) {
            var e = a.o.top - b.top,
                f = _.Mg(a.g);
            f < e && (void 0 === d || !d) || (d = a.g.document.body, d.style.paddingTop = _.AH(b.top), d.style.paddingRight = _.AH(b.right), d.style.paddingBottom = _.AH(b.bottom), d.style.paddingLeft = _.AH(b.left), a.o = b, (void 0 === c || c) && a.g.scrollTo(0, f - e))
        },
        GR = function(a) {
            !a.la || a.Va || 2 <= a.M && a.ba || !TR(a) ? FR(a) : (a.Da(), VR(a))
        };
    KR.prototype.Yb = function() {
        return _.Cg(this.g)
    };
    KR.prototype.tm = function() {
        this.Cd = !0;
        var a;
        null == (a = this.l) || a.removeAttribute("data-anchor-status")
    };
    KR.prototype.nj = function() {
        this.xd = !0;
        var a = this.l;
        this.Cd && this.xd && (null == a || a.setAttribute("data-anchor-status", "ready-to-display"))
    };
    var TR = function(a) {
            if (!a.Yb() || a.Cd && !a.xd) return !1;
            var b = a.g;
            if (!a.F && a.oa) switch (a.Wh && (a.B += Math.max(_.Mg(a.g) - a.bc, 0)), a.G) {
                case "bottom":
                    return a.B >= a.kj || a.jc;
                case "top":
                    return a.B > ZR(a)
            }
            return a.Ha || yP(b)
        },
        ZR = function(a, b) {
            return (void 0 === b ? 0 : b) ? a.Ca.top + 30 : a.Ca.top + 30 + a.ca.height - 5
        },
        SR = function(a) {
            a.fj && !a.bi && (a.bi = !0, a.H.Fb(257, function() {
                var b = {
                        msg_type: "manual-send-view"
                    },
                    c = a.v.contentWindow;
                c && c.postMessage(a.g.JSON.stringify(b), "*")
            }))
        };
    KR.prototype.lj = function(a, b) {
        this.v = a;
        if (b && (this.L.height !== b.height || this.L.width !== b.width)) {
            a = b.height - this.L.height;
            var c = {};
            OR(this, (c.ht = b.height, c.wd = b.width, c));
            this.ca = QR(this);
            UR(this);
            HR(this, a);
            var d;
            if (null != (d = this.j) && "top" == d.g) {
                var e;
                _.Yi(null != (e = d.l) ? e : d.L, {
                    top: _.AH(d.H.height)
                })
            }
        }
        YR(this)
    };
    var NR = {
        ui: "gr",
        gvar: "ar",
        scroll_detached: "true",
        dismissable: "false"
    };
    var $R = function() {
            this.g = null
        },
        aS = function(a, b, c) {
            a.g = _.ap(b, c);
            return !!a.g && _.$o(a.g)
        };
    var bS = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        _.uP.call(this, a, b, c);
        this.j = null;
        this.G = b.document;
        this.B = d;
        this.H = _.BG(new _.zG(b), 2147483646);
        this.o = e;
        this.L = b
    };
    _.T(bS, _.uP);
    var fS = function(a) {
            gR(a, !1);
            var b = a.l;
            if (b) {
                var c = JP(a.L, a.o);
                KP(a, function(d) {
                    _.Yi(d, c);
                    AP(d)
                }, !0);
                a.v.setAttribute("width", "");
                a.v.setAttribute("height", "");
                _.Yz(a.v, c);
                _.Yz(a.v, cS);
                _.Yz(b, dS);
                _.Yz(b, {
                    background: "transparent"
                });
                _.Yi(b, {
                    display: "none",
                    position: "fixed"
                });
                AP(b);
                AP(a.v);
                eS(a, b)
            }
        },
        eS = function(a, b) {
            !_.G(_.Ty) || 1 >= _.Kg(a.L) || (_.Yz(b, {
                overflow: "scroll",
                "max-width": "100vw"
            }), zP(b))
        },
        gR = function(a, b) {
            var c = a.l;
            c && (b ? (_.FG(a.H), _.Yi(c, {
                display: "block"
            }), a.G.body && !a.j && (a.j = _.MG(a.G, a.g, a.B)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.G.body.setAttribute("aria-hidden", "true")) : (_.GG(a.H), _.Yi(c, {
                display: "none"
            }), a.j && (a.j(), a.j = null), a.G.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
        },
        dS = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        cS = {
            left: "0",
            position: "absolute",
            top: "0"
        };
    var gS = function(a, b, c, d, e, f, g) {
        KR.call(this, c, d, 2 === b ? "top" : "bottom", new _.XG(a), new _.KF, e, _.G(_.ep));
        this.K = f;
        this.slotId = g;
        this.jj = !!_.np(this.K, this.slotId);
        2 === b && _.FI(this.K, this.slotId)
    };
    _.T(gS, KR);
    gS.prototype.Yb = function() {
        return 0 === (0, _.Tn)() || KR.prototype.Yb.call(this)
    };
    var hS = function(a, b, c) {
        bS.call(this, b, a, c, _.$e(_.JB), _.G(_.Yo));
        fS(this)
    };
    _.T(hS, bS);
    var iS = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        var p = [];
        _.G(_.FB) && 0 === (0, _.Tn)() && p.push(101);
        _.G(_.GB) && p.push(102);
        h = _.G(_.IB) ? qQ(h) : new _.v.Set(_.G(_.MB) ? [2] : []);
        XQ.call(this, b, c, e, new hS(b, c, d), new _.KF, f, g, {
            Yi: _.G(_.HB),
            Bh: p,
            Zj: !0,
            pf: {
                Xl: 3,
                version: "m202312060101"
            },
            Gk: _.G(_.Yo)
        }, h, new DQ, a);
        this.ca = k;
        this.ic = l;
        this.da = m;
        this.T = n;
        _.S(this, this.L)
    };
    _.T(iS, XQ);
    iS.prototype.Da = function() {
        var a;
        if (!(a = this.ca)) {
            var b = _.Ye($R),
                c = this.T;
            try {
                if (c && aS(b, c, this.da)) {
                    b.g.push(Date.now());
                    var d = JSON.stringify(b.g);
                    c.setItem("__lsv__", d);
                    a = c.getItem("__lsv__") == d
                } else a = !1
            } catch (e) {
                a = !1
            }
        }
        return a
    };
    iS.prototype.Ca = function() {
        return !0
    };
    iS.prototype.F = function() {
        XQ.prototype.F.call(this);
        this.ic()
    };
    iS.prototype.Pa = function() {
        return this.ca || aS(_.Ye($R), this.T, this.da)
    };
    var jS = {
        qk: gS,
        Jk: iS
    };
    _.XN(_m, _.rM).resolve(jS);
})