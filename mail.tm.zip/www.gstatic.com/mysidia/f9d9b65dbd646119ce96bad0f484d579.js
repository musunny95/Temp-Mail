(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var m = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = m, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    };

    function ba(a) {
        a = a.o;
        const b = encodeURIComponent;
        let c = "";
        a.platform && (c += "&uap=" + b(a.platform));
        a.platformVersion && (c += "&uapv=" + b(a.platformVersion));
        a.uaFullVersion && (c += "&uafv=" + b(a.uaFullVersion));
        a.architecture && (c += "&uaa=" + b(a.architecture));
        a.model && (c += "&uam=" + b(a.model));
        a.bitness && (c += "&uab=" + b(a.bitness));
        a.fullVersionList && (c += "&uafvl=" + b(a.fullVersionList.map(d => b(d.brand) + ";" + b(d.version)).join("|")));
        "undefined" !== typeof a.wow64 && (c += "&uaw=" + Number(a.wow64));
        return c
    }

    function ca(a, b) {
        return a.g ? a.l.slice(0, a.g.index) + b + a.l.slice(a.g.index) : a.l + b
    }

    function da(a) {
        let b = "&act=1&ri=1";
        a.h && a.o && (b += ba(a));
        return ca(a, b)
    }

    function ea(a, b) {
        return a.h && a.i || a.m ? 1 == b ? a.h ? a.i : ca(a, "&dct=1") : 2 == b ? ca(a, "&ri=2") : ca(a, "&ri=16") : a.l
    }
    var fa = class {
        constructor({
            url: a,
            X: b
        }) {
            this.l = a;
            this.o = b;
            b = /[?&]dsh=1(&|$)/.test(a);
            this.h = !b && /[?&]ae=1(&|$)/.test(a);
            this.m = !b && /[?&]ae=2(&|$)/.test(a);
            if ((this.g = /[?&]adurl=([^&]*)/.exec(a)) && this.g[1]) {
                let c;
                try {
                    c = decodeURIComponent(this.g[1])
                } catch (d) {
                    c = null
                }
                this.i = c
            }
        }
    };

    function ha(a, b) {
        a: {
            const c = a.length,
                d = "string" === typeof a ? a.split("") : a;
            for (let e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    };

    function ia(a) {
        let b = 0;
        for (const c in a) b++
    };
    var r = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };
    r.prototype.h = !0;
    var ka;
    try {
        new URL("s://g"), ka = !0
    } catch (a) {
        ka = !1
    }
    var la = ka,
        ma = {},
        na = new r("about:invalid#zClosurez", ma);
    var oa = aa(610401301, !1),
        pa = aa(572417392, !0);
    var qa;
    const ra = m.navigator;
    qa = ra ? ra.userAgentData || null : null;

    function sa(a) {
        return oa ? qa ? qa.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function t(a) {
        var b;
        a: {
            if (b = m.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function u() {
        return oa ? !!qa && 0 < qa.brands.length : !1
    }

    function ta() {
        return u() ? sa("Chromium") : (t("Chrome") || t("CriOS")) && !(u() ? 0 : t("Edge")) || t("Silk")
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    class ua {
        constructor(a) {
            this.ga = a
        }
    }

    function v(a) {
        return new ua(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const va = new ua(a => /^[^:]*([/?#]|$)/.test(a));
    var wa = v("http"),
        xa = v("https"),
        ya = v("ftp"),
        za = v("mailto"),
        Aa = v("intent"),
        Ba = v("market"),
        Ca = v("itms"),
        Da = v("itms-appss");
    const Ea = [v("data"), wa, xa, za, ya, va];

    function Fa(a, b = Ea) {
        if (a instanceof r) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof ua && d.ga(a)) return new r(a, ma)
        }
    }

    function Ga(a, b = Ea) {
        return Fa(a, b) || na
    };

    function Ha() {
        return t("iPhone") && !t("iPod") && !t("iPad")
    };

    function Ia(a) {
        Ia[" "](a);
        return a
    }
    Ia[" "] = function() {};
    var Ka = Ha(),
        La = t("iPad");
    var Ma = Ha() || t("iPod"),
        Na = t("iPad");
    !t("Android") || ta();
    ta();
    t("Safari") && (ta() || (u() ? 0 : t("Coast")) || (u() ? 0 : t("Opera")) || (u() ? 0 : t("Edge")) || (u() ? sa("Microsoft Edge") : t("Edg/")) || u() && sa("Opera"));
    var Oa = {},
        Pa = null;
    var Qa = !pa;
    let Ra = !pa;

    function w(a) {
        return Array.prototype.slice.call(a)
    };
    var x = Symbol(),
        Sa = Symbol();

    function Ta(a) {
        const b = a[x] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = w(a)), a[x] = b | 1)
    }

    function z(a, b, c) {
        return c ? a | b : a & ~b
    }

    function Ua() {
        var a = [];
        a[x] |= 1;
        return a
    }

    function D(a) {
        a[x] |= 34;
        return a
    }

    function Va(a, b) {
        b[x] = (a | 0) & -14591
    }

    function Wa(a, b) {
        b[x] = (a | 34) & -14557
    }

    function Xa(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var Ya = {},
        Za = {};

    function $a(a) {
        return !(!a || "object" !== typeof a || a.ia !== Za)
    }

    function ab(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let bb, cb = !pa;

    function db(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[x] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[x] = d | 1;
        return !0
    }
    var E;
    const eb = [];
    eb[x] = 55;
    E = Object.freeze(eb);

    function fb(a) {
        if (a & 2) throw Error();
    }
    class gb {
        constructor(a, b, c) {
            this.i = 0;
            this.g = a;
            this.h = b;
            this.l = c
        }
        next() {
            if (this.i < this.g.length) {
                const a = this.g[this.i++];
                return {
                    done: !1,
                    value: this.h ? this.h.call(this.l, a) : a
                }
            }
            return {
                done: !0,
                value: void 0
            }
        }[Symbol.iterator]() {
            return new gb(this.g, this.h, this.l)
        }
    }
    var ib = {};
    class jb {}
    class kb {}
    Object.freeze(new jb);
    Object.freeze(new kb);

    function lb(a) {
        a = Error(a);
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = "warning";
        return a
    };

    function nb(a) {
        if (!Number.isFinite(a)) throw lb("enum");
        return a | 0
    }

    function ob(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function G(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function pb(a, b, c, d) {
        if (null != a && "object" === typeof a && a.C === Ya) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? (a = b[Sa]) ? b = a : (a = new b, D(a.j), b = b[Sa] = a) : b = new b : b = void 0, b;
        let e = c = a[x] | 0;
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[x] = e);
        return new b(a)
    }

    function qb(a, b, c) {
        if (b) {
            if ("string" !== typeof a) throw Error();
            return a
        }
        let d;
        return null != (d = G(a)) ? d : c ? "" : void 0
    };
    let rb;
    const sb = (() => class extends Map {
        constructor() {
            super()
        }
    })();

    function tb(a) {
        return a
    }

    function ub(a) {
        if (a.u & 2) throw Error("Cannot mutate an immutable Map");
    }
    var H = class extends sb {
        constructor(a, b, c = tb, d = tb) {
            super();
            let e = a[x] | 0;
            e |= 64;
            this.u = a[x] = e;
            this.B = b;
            this.s = c || tb;
            this.J = this.B ? yb : d || tb;
            for (let f = 0; f < a.length; f++) {
                const h = a[f],
                    g = c(h[0], !1, !0);
                let k = h[1];
                b ? void 0 === k && (k = null) : k = d(h[1], !1, !0, void 0, void 0, e);
                super.set(g, k)
            }
        }
        W(a = zb) {
            return this.G(a)
        }
        G(a = zb) {
            const b = [],
                c = super.entries();
            for (var d; !(d = c.next()).done;) d = d.value, d[0] = a(d[0]), d[1] = a(d[1]), b.push(d);
            return b
        }
        clear() {
            ub(this);
            super.clear()
        }
        delete(a) {
            ub(this);
            return super.delete(this.s(a, !0, !1))
        }
        entries() {
            var a = this.U();
            return new gb(a, Ab, this)
        }
        keys() {
            return this.ha()
        }
        values() {
            var a = this.U();
            return new gb(a, H.prototype.get, this)
        }
        forEach(a, b) {
            super.forEach((c, d) => {
                a.call(b, this.get(d), d, this)
            })
        }
        set(a, b) {
            ub(this);
            a = this.s(a, !0, !1);
            return null == a ? this : null == b ? (super.delete(a), this) : super.set(a, this.J(b, !0, !0, this.B, !1, this.u))
        }
        has(a) {
            return super.has(this.s(a, !1, !1))
        }
        get(a) {
            a = this.s(a, !1, !1);
            const b = super.get(a);
            if (void 0 !== b) {
                var c = this.B;
                return c ? (c = this.J(b, !1, !0, c, this.fa, this.u),
                    c !== b && super.set(a, c), c) : b
            }
        }
        U() {
            return Array.from(super.keys())
        }
        ha() {
            return super.keys()
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    H.prototype.toJSON = void 0;
    H.prototype.ia = Za;

    function yb(a, b, c, d, e, f) {
        a = pb(a, d, c, f);
        e && (a = Bb(a));
        return a
    }

    function zb(a) {
        return a
    }

    function Ab(a) {
        return [a, this.get(a)]
    };

    function Cb(a, b) {
        return Db(b)
    }

    function Db(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return cb || !db(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                    if (a instanceof H) return a = a.W(), Qa || 0 !== a.length ? a : void 0
                }
        }
        return a
    };

    function Eb(a, b, c) {
        a = w(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) b[f] = c(e[f])
        }
        return a
    }

    function Fb(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[x] | 0) & 1 ? void 0 : f && (a[x] | 0) & 2 ? a : Gb(a, b, c, void 0 !== d, e, f);
            else if (ab(a)) {
                const h = {};
                for (let g in a) h[g] = Fb(a[g], b, c, d, e, f);
                a = h
            } else a = b(a, d);
            return a
        }
    }

    function Gb(a, b, c, d, e, f) {
        const h = d || c ? a[x] | 0 : 0;
        d = d ? !!(h & 32) : void 0;
        a = w(a);
        for (let g = 0; g < a.length; g++) a[g] = Fb(a[g], b, c, d, e, f);
        c && c(h, a);
        return a
    }

    function Hb(a) {
        return Fb(a, Ib, void 0, void 0, !1, !1)
    }

    function Ib(a) {
        return a.C === Ya ? a.toJSON() : a instanceof H ? a.W(Hb) : Db(a)
    };

    function Jb(a, b, c = Wa) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[x] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[x] = (d | 34) & -12293, a) : Gb(a, Jb, d & 4 ? Wa : c, !0, !1, !0)
            }
            a.C === Ya ? (c = a.j, d = c[x], a = d & 2 ? a : Kb(a, c, d, !0)) : a instanceof H && (c = D(a.G(Jb)), a = new H(c, a.B, a.s, a.J));
            return a
        }
    }

    function Lb(a) {
        const b = a.j;
        return Kb(a, b, b[x], !1)
    }

    function Kb(a, b, c, d) {
        a = a.constructor;
        rb = b = Mb(b, c, d);
        b = new a(b);
        rb = void 0;
        return b
    }

    function Mb(a, b, c) {
        const d = c || b & 2 ? Wa : Va,
            e = !!(b & 32);
        a = Eb(a, b, f => Jb(f, e, d));
        a[x] = a[x] | 32 | (c ? 2 : 0);
        return a
    }

    function Bb(a) {
        const b = a.j,
            c = b[x];
        return c & 2 ? Kb(a, b, c, !1) : a
    };

    function I(a, b) {
        a = a.j;
        return Nb(a, a[x], b)
    }

    function Nb(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= Xa(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function Ob(a, b, c) {
        const d = a.j;
        let e = d[x];
        fb(e);
        J(d, e, b, c);
        return a
    }

    function J(a, b, c, d, e) {
        var f = Xa(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && (a[x] = e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function Pb(a, b, c, d, e) {
        var f = b & 2;
        let h = Nb(a, b, c, e);
        Array.isArray(h) || (h = E);
        const g = !(d & 2);
        d = !(d & 1);
        const k = !!(b & 32);
        let l = h[x] | 0;
        0 !== l || !k || f || g ? l & 1 || (l |= 1, h[x] = l) : (l |= 33, h[x] = l);
        f ? (a = !1, l & 2 || (D(h), a = !!(4 & l)), (d || a) && Object.freeze(h)) : (f = !!(2 & l) || !!(2048 & l), d && f ? (h = w(h), d = 1, k && !g && (d |= 32), h[x] = d, J(a, b, c, h, e)) : g && l & 32 && !f && (h[x] &= -33));
        return h
    }
    let Qb;

    function Rb() {
        let a;
        return null != (a = Qb) ? a : Qb = new H(D([]), void 0, void 0, void 0, ib)
    }

    function Sb(a, b, c, d, e, f) {
        const h = b & 2;
        a: {
            var g = c,
                k = b & 2;c = !1;
            if (null == g) {
                if (k) {
                    a = Rb();
                    break a
                }
                g = []
            } else if (g.constructor === H) {
                if (0 == (g.u & 2) || k) {
                    a = g;
                    break a
                }
                g = g.G()
            } else Array.isArray(g) ? c = !!((g[x] | 0) & 2) : g = [];
            if (k) {
                if (!g.length) {
                    a = Rb();
                    break a
                }
                c || (c = !0, D(g))
            } else if (c) {
                c = !1;
                k = w(g);
                for (g = 0; g < k.length; g++) {
                    const l = k[g] = w(k[g]);
                    Array.isArray(l[1]) && (l[1] = D(l[1]))
                }
                g = k
            }
            c || ((g[x] | 0) & 64 ? g[x] &= -33 : 32 & b && (g[x] |= 32));f = new H(g, e, qb, f);J(a, b, d, f, !1);a = f
        }
        if (null == a) return a;
        !h && e && (a.fa = !0);
        return a
    }

    function Tb(a, b) {
        a = a.j;
        const c = a[x];
        return Sb(a, c, Nb(a, c, b), b, void 0, qb)
    }

    function K(a, b, c) {
        a = a.j;
        let d = a[x];
        const e = Nb(a, d, c, !1);
        b = pb(e, b, !1, d);
        b !== e && null != b && J(a, d, c, b, !1);
        return b
    }

    function M(a, b, c) {
        b = K(a, b, c);
        if (null == b) return b;
        a = a.j;
        let d = a[x];
        if (!(d & 2)) {
            const e = Bb(b);
            e !== b && (b = e, J(a, d, c, b, !1))
        }
        return b
    }

    function Ub(a, b, c) {
        a = z(a, 2, !!(2 & b));
        a = z(a, 32, !!(32 & b) && c);
        return a = z(a, 2048, !1)
    }

    function Vb(a, b) {
        a = a.j;
        let c = a[x];
        const d = 2 & c ? 1 : 2;
        let e = Pb(a, c, b, 1);
        c = a[x];
        var f = e[x] | 0;
        let h = f,
            g = !!(2 & f);
        var k = !!(4 & f),
            l = g && k;
        if (!(4 & f)) {
            if (k || Object.isFrozen(e)) e = w(e), h = 0, f = Ub(f, c, !1), g = !!(2 & f), c = J(a, c, b, e);
            let n = k = 0;
            for (; k < e.length; k++) {
                const p = G(e[k]);
                null != p && (e[n++] = p)
            }
            n < k && (e.length = n);
            f = z(f, 4096, !1);
            f = z(f, 8192, !1);
            f = z(f, 20, !0)
        }
        l || ((l = 1 === d) && (f = z(f, 2, !0)), f !== h && (e[x] = f), (l || g) && Object.freeze(e));
        2 === d && g && (e = w(e), f = Ub(f, c, !1), e[x] = f, J(a, c, b, e));
        return e
    }

    function Wb(a, b) {
        a = I(a, b);
        return null == a ? a : Number.isFinite(a) ? a | 0 : void 0
    }

    function N(a, b) {
        return null != a ? a : b
    }

    function P(a, b, c = !1) {
        a = I(a, b);
        return N(null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0, c)
    }

    function Q(a, b) {
        return N(G(I(a, b)), "")
    }

    function R(a, b, c = 0) {
        return N(Wb(a, b), c)
    }

    function Xb(a, b, c) {
        if (null != c && "boolean" !== typeof c) throw a = typeof c, Error(`Expected boolean but got ${"object"!=a?a:c?Array.isArray(c)?"array":a:"null"}: ${c}`);
        return Ob(a, b, c)
    }

    function Yb(a, b, c) {
        if (null != c) {
            if ("number" !== typeof c) throw lb("int32");
            if (!Number.isFinite(c)) throw lb("int32");
            c |= 0
        }
        Ob(a, b, c)
    }

    function S(a, b, c) {
        if (null != c && "string" !== typeof c) throw Error();
        return Ob(a, b, c)
    }

    function Zb(a, b, c) {
        Ob(a, b, null == c ? c : nb(c))
    };

    function $b(a) {
        bb = !0;
        try {
            return JSON.stringify(a.toJSON(), Cb)
        } finally {
            bb = !1
        }
    }
    var T = class {
        constructor(a) {
            a: {
                null == a && (a = rb);rb = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[x] | 0;
                    if (b & 64) break a;
                    b |= 64;
                    var c = a.length;
                    if (c && (--c, ab(a[c]))) {
                        b |= 256;
                        c -= +!!(b & 512) - 1;
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[x] = b
            }
            this.j = a
        }
        toJSON() {
            if (bb) var a = ac(this, this.j, !1);
            else a = Gb(this.j, Ib, void 0, void 0, !1, !1), a = ac(this, a, !0);
            return a
        }
    };
    T.prototype.C = Ya;
    T.prototype.toString = function() {
        return ac(this, this.j, !1).toString()
    };

    function ac(a, b, c) {
        const d = a.constructor.A;
        var e = (c ? a.j : b)[x],
            f = Xa(e),
            h = !1;
        if (d && cb) {
            if (!c) {
                b = w(b);
                var g;
                if (b.length && ab(g = b[b.length - 1]))
                    for (h = 0; h < d.length; h++)
                        if (d[h] >= f) {
                            Object.assign(b[b.length - 1] = {}, g);
                            break
                        }
                h = !0
            }
            f = b;
            c = !c;
            g = a.j[x];
            a = Xa(g);
            g = +!!(g & 512) - 1;
            var k;
            for (let F = 0; F < d.length; F++) {
                var l = d[F];
                if (l < a) {
                    l += g;
                    var n = f[l];
                    null == n ? f[l] = c ? E : Ua() : c && n !== E && Ta(n)
                } else {
                    if (!k) {
                        var p = void 0;
                        f.length && ab(p = f[f.length - 1]) ? k = p : f.push(k = {})
                    }
                    n = k[l];
                    null == k[l] ? k[l] = c ? E : Ua() : c && n !== E && Ta(n)
                }
            }
        }
        k = b.length;
        if (!k) return b;
        let q, B;
        if (ab(p = b[k - 1])) {
            a: {
                var A = p;f = {};c = !1;
                for (var C in A) {
                    a = A[C];
                    if (Array.isArray(a)) {
                        g = a;
                        if (!Ra && db(a, d, +C) || !Qa && $a(a) && 0 === a.size) a = null;
                        a != g && (c = !0)
                    }
                    null != a ? f[C] = a : c = !0
                }
                if (c) {
                    for (let F in f) {
                        A = f;
                        break a
                    }
                    A = null
                }
            }
            A != p && (q = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            C = k - 1;
            p = b[C];
            if (!(null == p || !Ra && db(p, d, C - e) || !Qa && $a(p) && 0 === p.size)) break;
            B = !0
        }
        if (!q && !B) return b;
        var L;
        h ? L = b : L = Array.prototype.slice.call(b, 0, k);
        b = L;
        h && (b.length = k);
        A && b.push(A);
        return b
    };
    var bc = class extends T {
        constructor() {
            super()
        }
    };
    var cc = class extends T {};
    var dc = class extends T {};
    var ec = class extends T {
        v() {
            return Q(this, 3)
        }
        V(a) {
            Xb(this, 5, a)
        }
    };
    var U = class extends T {
        v() {
            return Q(this, 1)
        }
        V(a) {
            Xb(this, 2, a)
        }
    };
    var fc = class extends T {};

    function gc(a) {
        a = a.j;
        var b = a[x],
            c = !!(2 & b),
            d = c ? 1 : 2;
        const e = 1 === d;
        d = 2 === d;
        var f = !!(2 & b) && d;
        let h = Pb(a, b, 7, 3);
        b = a[x];
        var g = h[x] | 0,
            k = !!(2 & g);
        const l = !!(4 & g),
            n = !!(32 & g);
        let p = k && l || !!(2048 & g);
        if (!l) {
            var q = h,
                B = b;
            const A = !!(2 & g);
            A && (B = z(B, 2, !0));
            let C = !A,
                L = !0,
                F = 0,
                Y = 0;
            for (; F < q.length; F++) {
                const Z = pb(q[F], ec, !1, B);
                if (Z instanceof ec) {
                    if (!A) {
                        const y = !!((Z.j[x] | 0) & 2);
                        C && (C = !y);
                        L && (L = y)
                    }
                    q[Y++] = Z
                }
            }
            Y < F && (q.length = Y);
            g = z(g, 4, !0);
            g = z(g, 16, L);
            g = z(g, 8, C);
            q[x] = g;
            k && !f && (Object.freeze(h), p = !0)
        }
        f = g;
        k = !!(8 & g) || e && !h.length;
        if (!c && !k) {
            p && (h = w(h), p = !1, f = 0, g = Ub(g, b, !1), b = J(a, b, 7, h));
            c = h;
            k = g;
            for (q = 0; q < c.length; q++) g = c[q], B = Bb(g), g !== B && (c[q] = B);
            k = z(k, 8, !0);
            g = k = z(k, 16, !c.length)
        }
        p || (e ? g = z(g, !h.length || 16 & g && (!l || n) ? 2 : 2048, !0) : g = z(g, 32, !1), g !== f && (h[x] = g), e && (Object.freeze(h), p = !0));
        d && p && (h = w(h), g = Ub(g, b, !1), h[x] = g, J(a, b, 7, h));
        return h
    }
    var hc = class extends T {};
    hc.A = [6, 7];

    function ic(a) {
        a = a.j;
        const b = a[x];
        return Sb(a, b, Nb(a, b, 1), 1, hc)
    }
    var jc = class extends T {};
    jc.A = [17];
    var kc = class extends T {};
    var lc = class extends T {
        constructor() {
            super()
        }
    };

    function mc(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var nc = {
            capture: !0
        },
        oc = {
            passive: !0
        },
        pc = mc(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                m.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function qc(a) {
        return a ? a.passive && pc() ? a : a.capture || !1 : !1
    }

    function rc(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, qc(d))
    };

    function sc(a, b) {
        if (!(b instanceof r || b instanceof r)) {
            b = "object" == typeof b && b.h ? b.g.toString() : String(b);
            b: {
                var c = b;
                if (la) {
                    try {
                        var d = new URL(c)
                    } catch (e) {
                        c = "https:";
                        break b
                    }
                    c = d.protocol
                } else c: {
                    d = document.createElement("a");
                    try {
                        d.href = c
                    } catch (e) {
                        c = void 0;
                        break c
                    }
                    c = d.protocol;c = ":" === c || "" === c ? "https:" : c
                }
            }
            "javascript:" === c && (b = "about:invalid#zClosurez");
            b = new r(b, ma)
        }
        a.href = b instanceof r && b.constructor === r ? b.g : "type_error:SafeUrl"
    };
    var tc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function uc(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) uc(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    }

    function vc(a, b, c, d) {
        for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (38 == f || 63 == f)
                if (f = a.charCodeAt(b + e), !f || 61 == f || 38 == f || 35 == f) return b;
            b += e + 1
        }
        return -1
    }
    var wc = /#|$/;

    function xc(a, b) {
        var c = a.search(wc),
            d = vc(a, 0, b, c);
        if (0 > d) return null;
        var e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    }
    var yc = /[?&]($|#)/;

    function zc(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    var Ac = a => {
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    let Bc = [];
    const Cc = () => {
        const a = Bc;
        Bc = [];
        for (const b of a) try {
            b()
        } catch (c) {}
    };
    var Dc = a => {
            Bc.push(a);
            1 == Bc.length && (window.Promise ? Promise.resolve().then(Cc) : window.setImmediate ? setImmediate(Cc) : setTimeout(Cc, 0))
        },
        Ec = a => {
            var b = V;
            "complete" === b.readyState || "interactive" === b.readyState ? Dc(a) : b.addEventListener("DOMContentLoaded", a)
        },
        Fc = a => {
            var b = window;
            "complete" === b.document.readyState ? Dc(a) : b.addEventListener("load", a)
        };

    function Gc(a = document) {
        return a.createElement("img")
    };

    function Hc(a, b, c = null, d = !1) {
        Jc(a, b, c, d)
    }

    function Jc(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = Gc(a.document);
        if (c || d) {
            const f = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const g = Array.prototype.indexOf.call(h, e, void 0);
                    0 <= g && Array.prototype.splice.call(h, g, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, qc());
                e.removeEventListener && e.removeEventListener("error", f, qc())
            };
            rc(e, "load", f);
            rc(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function Kc(a, b) {
        var c;
        if (c = a.navigator) c = a.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
        c && a.navigator.sendBeacon ? a.navigator.sendBeacon(b) : Hc(a, b, void 0, !1)
    };
    let Lc = 0;

    function Mc(a) {
        return (a = Nc(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function Nc(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[${"data-jc"}="${a}"]`)
    }

    function Oc(a) {
        if (!(.01 < Math.random())) {
            const b = Nc(a, document.currentScript);
            a = `https://${b&&"true"===b.getAttribute("data-jc-rcd")?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${a}&version=${Mc(a)}&sample=${.01}`;
            Kc(window, a)
        }
    };
    var V = document,
        Pc = window;
    const Qc = [wa, xa, za, ya, va, Ba, Ca, Aa, Da];

    function Rc(a, b) {
        if (a instanceof r) return a;
        const c = Ga(a, Qc);
        c === na && b(a);
        return c
    }
    var Sc = a => {
        var b = `${"http:"===Pc.location.protocol?"http:":"https:"}//${"pagead2.googlesyndication.com"}/pagead/gen_204`;
        return c => {
            c = {
                id: "unsafeurl",
                ctx: a,
                url: c
            };
            var d = [];
            for (e in c) uc(e, c[e], d);
            var e = d.join("&");
            if (e) {
                c = b.indexOf("#");
                0 > c && (c = b.length);
                d = b.indexOf("?");
                if (0 > d || d > c) {
                    d = c;
                    var f = ""
                } else f = b.substring(d + 1, c);
                c = [b.slice(0, d), f, b.slice(c)];
                d = c[1];
                c[1] = e ? d ? d + "&" + e : e : d;
                e = c[0] + (c[1] ? "?" + c[1] : "") + c[2]
            } else e = b;
            navigator.sendBeacon && navigator.sendBeacon(e, "")
        }
    };
    var Tc = a => {
        var b = V;
        try {
            return b.querySelectorAll("*[" + a + "]")
        } catch (c) {
            return []
        }
    };
    class Uc {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const Vc = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Wc = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        Xc = class {
            constructor(a, b) {
                this.url = a;
                this.T = !!b;
                this.depth = null
            }
        };
    let Yc = null;

    function Zc() {
        const a = m.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function $c() {
        const a = m.performance;
        return a && a.now ? a.now() : null
    };
    var ad = class {
        constructor(a, b) {
            var c = $c() || Zc();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const W = m.performance,
        bd = !!(W && W.mark && W.measure && W.clearMarks),
        cd = mc(() => {
            var a;
            if (a = bd) {
                var b;
                if (null === Yc) {
                    Yc = "";
                    try {
                        a = "";
                        try {
                            a = m.top.location.hash
                        } catch (c) {
                            a = m.location.hash
                        }
                        a && (Yc = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Yc;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        });

    function dd(a) {
        a && W && cd() && (W.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), W.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }
    class ed {
        constructor() {
            var a = window;
            this.h = [];
            this.i = a || m;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.h = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = cd() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new ad(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            W && cd() && W.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = ($c() || Zc()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                W && cd() && W.mark(b);
                !this.g ||
                    2048 < this.h.length || this.h.push(a)
            }
        }
    };

    function fd(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function gd(a, b, c, d, e) {
        const f = [];
        zc(a, function(h, g) {
            (h = hd(h, b, c, d, e)) && f.push(g + "=" + h)
        });
        return f.join(b)
    }

    function hd(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let h = 0; h < a.length; h++) f.push(hd(a[h], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(gd(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function id(a) {
        let b = 1;
        for (const c in a.h) b = c.length > b ? c.length : b;
        return 3997 - b - a.i.length - 1
    }

    function jd(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = id(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, h) {
            return f - h
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const h = a.g[f],
                g = a.h[h];
            for (let k = 0; k < g.length; k++) {
                if (!d) {
                    b = null == b ? h : b;
                    break
                }
                let l = gd(g[k], a.i, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.i;
                        break
                    }
                    b = null == b ? h : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class kd {
        constructor() {
            this.i = "&";
            this.h = {};
            this.l = 0;
            this.g = []
        }
    };

    function ld(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }

    function md(a, b, c) {
        let d, e;
        try {
            a.g && a.g.g ? (e = a.g.start(b.toString(), 3), d = c(), a.g.end(e)) : d = c()
        } catch (f) {
            c = !0;
            try {
                dd(e), c = a.m(b, new Uc(f, {
                    message: ld(f)
                }), void 0, void 0)
            } catch (h) {
                a.l(217, h)
            }
            if (c) {
                let h, g;
                null == (h = window.console) || null == (g = h.error) || g.call(h, f)
            } else throw f;
        }
        return d
    }

    function nd(a, b) {
        var c = od;
        return (...d) => md(c, a, () => b.apply(void 0, d))
    }
    var rd = class {
        constructor(a = null) {
            this.pinger = pd;
            this.g = a;
            this.h = null;
            this.i = !1;
            this.m = this.l
        }
        l(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const y = new kd;
                y.g.push(1);
                y.h[1] = fd("context", a);
                b.error && b.meta && b.id || (b = new Uc(b, {
                    message: ld(b)
                }));
                if (b.msg) {
                    var h = b.msg.substring(0, 512);
                    y.g.push(2);
                    y.h[2] = fd("msg", h)
                }
                const Ja = b.meta || {};
                if (this.h) try {
                    this.h(Ja)
                } catch (O) {}
                if (d) try {
                    d(Ja)
                } catch (O) {}
                b = [Ja];
                y.g.push(3);
                y.h[3] = b;
                d = m;
                b = [];
                let vb;
                h = null;
                do {
                    var g = d;
                    try {
                        var k;
                        if (k = !!g && null != g.location.href) b: {
                            try {
                                Ia(g.foo);
                                k = !0;
                                break b
                            } catch (O) {}
                            k = !1
                        }
                        var l = k
                    } catch (O) {
                        l = !1
                    }
                    l ? (vb = g.location.href, h = g.document && g.document.referrer || null) : (vb = h, h = null);
                    b.push(new Xc(vb || ""));
                    try {
                        d = g.parent
                    } catch (O) {
                        d = null
                    }
                } while (d && g != d);
                for (let O = 0, Ic = b.length - 1; O <= Ic; ++O) b[O].depth = Ic - O;
                g = m;
                if (g.location && g.location.ancestorOrigins && g.location.ancestorOrigins.length == b.length - 1)
                    for (l = 1; l < b.length; ++l) {
                        var n = b[l];
                        n.url || (n.url = g.location.ancestorOrigins[l - 1] || "", n.T = !0)
                    }
                var p = b;
                let wb = new Xc(m.location.href, !1);
                g = null;
                const xb = p.length -
                    1;
                for (n = xb; 0 <= n; --n) {
                    var q = p[n];
                    !g && Vc.test(q.url) && (g = q);
                    if (q.url && !q.T) {
                        wb = q;
                        break
                    }
                }
                q = null;
                const Pd = p.length && p[xb].url;
                0 != wb.depth && Pd && (q = p[xb]);
                f = new Wc(wb, q);
                if (f.h) {
                    var B = f.h.url || "";
                    y.g.push(4);
                    y.h[4] = fd("top", B)
                }
                var A = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    var C = f.g.url.match(tc),
                        L = C[1],
                        F = C[3],
                        Y = C[4];
                    p = "";
                    L && (p += L + ":");
                    F && (p += "//", p += F, Y && (p += ":" + Y));
                    var Z = p
                } else Z = "";
                A = [A, {
                    url: Z
                }];
                y.g.push(5);
                y.h[5] = A;
                qd(this.pinger, e, y, this.i, c)
            } catch (y) {
                try {
                    qd(this.pinger, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: ld(y),
                        url: f && f.g.url
                    }, this.i, c)
                } catch (Ja) {}
            }
            return !0
        }
    };
    class sd {};

    function qd(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof kd ? f = c : (f = new kd, zc(c, (g, k) => {
                var l = f;
                const n = l.l++;
                g = fd(k, g);
                l.g.push(n);
                l.h[n] = g
            }));
            const h = jd(f, "/pagead/gen_204?id=" + b + "&");
            h && Hc(m, h)
        } catch (f) {}
    }

    function td() {
        var a = pd,
            b = window.google_srt;
        0 <= b && 1 >= b && (a.g = b)
    }
    class ud {
        constructor() {
            this.g = Math.random()
        }
    };
    let pd, od;
    const X = new ed;
    var vd = () => {
        window.google_measure_js_timing || (X.g = !1, X.h != X.i.google_js_reporting_queue && (cd() && Array.prototype.forEach.call(X.h, dd, void 0), X.h.length = 0))
    };
    (a => {
        pd = null != a ? a : new ud;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        td();
        od = new rd(X);
        od.h = b => {
            const c = Lc;
            0 !== c && (b.jc = String(c), b.shv = Mc(c))
        };
        od.i = !0;
        "complete" == window.document.readyState ? vd() : X.g && rc(window, "load", () => {
            vd()
        })
    })();
    var wd = (a, b) => nd(a, b),
        xd = a => {
            var b = sd;
            var c = "S";
            b.S && b.hasOwnProperty(c) || (c = new b, b.S = c);
            b = [];
            !a.eid && b.length && (a.eid = b.toString());
            qd(pd, "gdn-asoch", a, !0)
        };

    function yd(a = window) {
        return a
    };
    ia({
        ua: 0,
        ta: 1,
        qa: 2,
        la: 3,
        ra: 4,
        ma: 5,
        sa: 6,
        oa: 7,
        pa: 8,
        ka: 9,
        na: 10,
        va: 11
    });
    ia({
        xa: 0,
        ya: 1,
        wa: 2
    });

    function zd(a) {
        var b = new Ad;
        const c = b.j,
            d = c[x] | 0;
        fb(b.j[x]);
        b = Pb(c, d, 1, 2, !1);
        if (Array.isArray(a))
            for (var e = 0; e < a.length; e++) b.push(nb(a[e]));
        else
            for (e of a) b.push(nb(e))
    }
    var Ad = class extends T {
        constructor() {
            super()
        }
    };
    Ad.A = [1];
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    zd([1, 8, 10, 11, 12, 2, 3, 4, 5]);
    zd([1, 6, 7, 8, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14]);
    zd([1, 6, 7, 8, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14]);
    new Ad;
    var Bd = (a, b) => {
            b = Q(a, 2) || b;
            if (!b) return "";
            if (P(a, 13)) return b;
            const c = /[?&]adurl=([^&]+)/.exec(b);
            if (!c) return b;
            const d = [b.slice(0, c.index + 1)];
            Tb(a, 4).forEach((e, f) => {
                d.push(encodeURIComponent(f) + "=" + encodeURIComponent(e) + "&")
            });
            d.push(b.slice(c.index + 1));
            return d.join("")
        },
        Cd = (a, b = []) => {
            b = 0 < b.length ? b : Tc("data-asoch-targets");
            a = ic(a);
            const c = [];
            for (let g = 0; g < b.length; ++g) {
                var d = b[g].getAttribute("data-asoch-targets"),
                    e = d.split(","),
                    f = !0;
                for (let k of e)
                    if (!a.has(k)) {
                        f = !1;
                        break
                    }
                if (f) {
                    f = a.get(e[0]);
                    for (d = 1; d < e.length; ++d) {
                        var h = a.get(e[d]);
                        f = Lb(f).toJSON();
                        h = h.toJSON();
                        const k = Math.max(f.length, h.length);
                        for (let l = 0; l < k; ++l) null == f[l] && (f[l] = h[l]);
                        f = new hc(f)
                    }
                    e = Tb(f, 4);
                    null != Wb(f, 5) && e.set("nb", R(f, 5, 0).toString());
                    c.push({
                        element: b[g],
                        data: f
                    })
                } else xd({
                    type: 1,
                    data: d
                })
            }
            return c
        },
        Fd = (a, b, c, d) => {
            c = Bd(b, c);
            if (0 !== c.length) {
                if ("2" === xc(c, "ase") && 1087 !== d) {
                    const f = 609 === d;
                    var e;
                    const h = !(null == (e = V.featurePolicy) || !e.allowedFeatures().includes("attribution-reporting"));
                    e = f ? 4 : h ? 6 : 5;
                    let g = "";
                    f || h &&
                        !Dd(c) ? (c = Ed(c, "nis", e.toString()), a.setAttribute("attributionsrc", g)) : h && Dd(c) && (g = Ed(da(new fa({
                            url: c
                        })), "nis", e.toString()), a.setAttribute("attributionsrc", g))
                }
                sc(a, Rc(c, Sc(d)));
                a.target || (a.target = null != G(I(b, 11)) ? Q(b, 11) : "_top")
            }
        },
        Gd = a => {
            for (const b of a)
                if (a = b.data, "A" == b.element.tagName && !P(a, 1)) {
                    const c = b.element;
                    Fd(c, a, c.href, 609)
                }
        },
        Hd = (a, b, c) => {
            b = encodeURIComponent(b);
            const d = encodeURIComponent(c);
            c = new RegExp("[?&]" + b + "=([^&]+)");
            const e = c.exec(a);
            b = b + "=" + d;
            return e ? a.replace(c, e[0].charAt(0) +
                b) : a.replace("?", "?" + b + "&")
        },
        Dd = a => !/[?&]dsh=1(&|$)/.test(a) && /[?&]ae=1(&|$)/.test(a),
        Id = a => {
            const b = m.oneAfmaInstance;
            if (b)
                for (const c of a)
                    if ((a = c.data) && void 0 !== K(a, fc, 8)) {
                        const d = Q(M(a, fc, 8), 4);
                        if (d) {
                            b.fetchAppStoreOverlay(d, void 0, Q(M(a, fc, 8), 6));
                            break
                        }
                    }
        },
        Jd = (a, b = 500) => {
            const c = [],
                d = [];
            for (var e of a)(a = e.data) && void 0 !== K(a, U, 12) && (d.push(M(a, U, 12)), c.push(M(a, U, 12).v()));
            e = (f, h) => {
                if (h)
                    for (const g of d) h[g.v()] && g.V(!0)
            };
            a = m.oneAfmaInstance;
            for (const f of c) {
                let h;
                null == (h = a) || h.canOpenAndroidApp(f,
                    e, () => {}, b)
            }
        },
        Ld = (a, b, c, d, e) => {
            if (!b || void 0 === K(b, fc, 8)) return !1;
            const f = M(b, fc, 8);
            let h = Q(f, 2);
            Tb(b, 10).forEach((l, n) => {
                h = Hd(h, n, l)
            });
            Kd(b) && P(b, 15) && !/[?&]label=/.test(c) && (c = Ed(c, "label", "deep_link_fallback"));
            const g = l => d.openStoreOverlay(l, void 0, Q(f, 6)),
                k = l => Kc(Pc, l);
            return d.redirectForStoreU2({
                clickUrl: c,
                trackingUrl: Q(f, 3),
                finalUrl: h,
                pingFunc: P(b, 13) ? d.httpTrack : e ? k : d.click,
                openFunc: (null == a ? 0 : P(a, 1)) ? g : d.openIntentOrNativeApp,
                isExternalClickUrl: P(b, 13)
            })
        },
        Nd = (a, b, c, d, e, f, h, g = !1, k = !1) => {
            const l =
                P(e, 15),
                n = Dd(f);
            if (a && b && (!l || !n) && (f = g ? Md(f) : Md(f, h.click), k && (null == e ? 0 : P(e, 21, !1)))) return;
            f && f.startsWith("intent:") ? h.openIntentOrNativeApp(f) : c ? d ? h.openBrowser(f) : h.openChromeCustomTab(f) : h.openSystemBrowser(f, {
                useFirstPackage: !0,
                useRunningProcess: !0
            })
        },
        Md = (a, b = null) => {
            if (null !== b) {
                const c = new fa({
                    url: a
                });
                if (c.h && c.i || c.m) return b(da(c)), ea(c, 1)
            } else return {
                X: b
            } = {}, b = new fa({
                url: a,
                X: b
            }), b.h && b.i || b.m ? navigator.sendBeacon ? navigator.sendBeacon(da(b), "") ? ea(b, 1) : ea(b, 2) : ea(b, 0) : a;
            return a
        },
        Od =
        (a, b = !0) => {
            b && Pc.fetch ? Pc.fetch(a, {
                method: "GET",
                keepalive: !0,
                mode: "no-cors"
            }).then(c => {
                c.ok || Hc(Pc, a)
            }) : Hc(Pc, a)
        },
        Ed = (a, b, c) => {
            b = encodeURIComponent(String(b));
            c = encodeURIComponent(String(c));
            return a.replace("?", "?" + b + "=" + c + "&")
        },
        Kd = a => {
            for (const b of gc(a))
                if (3 === R(b, 1, 0) && Q(b, 2)) return !0;
            return !1
        };
    var Qd = (a, b) => a && (a = a.match(b + "=([^&]+)")) && 2 == a.length ? a[1] : "";
    var Rd = class extends T {
        constructor() {
            super()
        }
    };

    function Sd(a, b) {
        return S(a, 2, b)
    }

    function Td(a, b) {
        return S(a, 3, b)
    }

    function Ud(a, b) {
        return S(a, 4, b)
    }

    function Vd(a, b) {
        return S(a, 5, b)
    }

    function Wd(a, b) {
        return S(a, 9, b)
    }

    function Xd(a, b) {
        {
            const n = a.j;
            let p = n[x];
            fb(p);
            if (null == b) J(n, p, 10);
            else {
                var c = b[x] | 0,
                    d = c,
                    e = !!(2 & c) || !!(2048 & c),
                    f = e || Object.isFrozen(b),
                    h;
                if (h = !f) h = !1;
                var g = !0,
                    k = !0;
                for (let q = 0; q < b.length; q++) {
                    var l = b[q];
                    e || (l = !!((l.j[x] | 0) & 2), g && (g = !l), k && (k = l))
                }
                e || (c = z(c, 5, !0), c = z(c, 8, g), c = z(c, 16, k));
                if (h || f && c !== d) b = w(b), d = 0, c = Ub(c, p, !0);
                c !== d && (b[x] = c);
                J(n, p, 10, b)
            }
        }
        return a
    }

    function Yd(a, b) {
        return Xb(a, 11, b)
    }

    function Zd(a, b) {
        return S(a, 1, b)
    }

    function $d(a, b) {
        return Xb(a, 7, b)
    }
    var ae = class extends T {
        constructor() {
            super()
        }
    };
    ae.A = [10, 6];
    const be = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ce(a) {
        let b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function de(a) {
        let b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function ee() {
        var a = window;
        if (!de(a)) return null;
        const b = ce(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(be).then(c => {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function fe(a) {
        let b;
        return Yd(Xd(Vd(Sd(Zd(Ud($d(Wd(Td(new ae, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(c => {
            var d = new Rd;
            d = S(d, 1, c.brand);
            return S(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function ge() {
        let a, b;
        return null != (b = null == (a = ee()) ? void 0 : a.then(c => fe(c))) ? b : null
    };

    function he(a) {
        for (const b of a)
            if ("A" == b.element.tagName) {
                a = b.element;
                const c = b.data;
                null == G(I(c, 2)) && S(c, 2, a.href)
            }
    }

    function ie(a, b) {
        return ha(a, c => c.element === b)
    }

    function je(a) {
        Ec(wd(556, () => {
            new ke(a || {})
        }))
    }

    function le(a, b) {
        if (!b.defaultPrevented || a.F === b) {
            for (var c, d, e = b.target;
                (!c || !d) && e;) {
                d || "A" != e.tagName || (d = e);
                var f = e.hasAttribute("data-asoch-targets"),
                    h = e.hasAttribute("data-asoch-fixed-value");
                if (!c)
                    if (h) c = new hc(JSON.parse(e.getAttribute("data-asoch-fixed-value")) || []);
                    else if ("A" == e.tagName || f)
                    if (f = f && "true" === e.getAttribute("data-asoch-is-dynamic") ? Cd(a.h, [e]) : a.g, f = ie(f, e)) c = f.data;
                e = e.parentElement
            }
            e = c && !P(c, 1);
            if (a.I && a.l && b.defaultPrevented) me(a, b, d, e ? c : a.l);
            else {
                if (e) {
                    if (!a.I && b.defaultPrevented) {
                        me(a,
                            b, d, c);
                        return
                    }
                    f = c;
                    for (var g of Vb(f, 6)) Od(g)
                }
                a.K && e && P(c, 21, !1) && (Ac(b), (g = c) && Q(g, 2) && (f = Hd(Q(g, 2), "ae", "1"), S(g, 2, f)));
                if (d && e) {
                    c = e ? c : null;
                    (g = ie(a.g, d)) ? g = g.data: (g = new hc, S(g, 2, d.href), S(g, 11, d.target || "_top"), a.g.push({
                        element: d,
                        data: g
                    }));
                    Fd(d, c || g, Q(g, 2), 557);
                    ne(a, b, d, c);
                    for (var k of Vb(a.h, 17)) g = V.body, e = {}, "function" === typeof window.CustomEvent ? f = new CustomEvent(k, e) : (f = document.createEvent("CustomEvent"), f.initCustomEvent(k, !!e.bubbles, !!e.cancelable, e.detail)), g.dispatchEvent(f);
                    if (null ==
                        c ? 0 : null != G(I(c, 19))) {
                        k = new bc;
                        g = R(c, 5, 0);
                        Zb(k, 1, g);
                        g = Qd(d.href, "nx");
                        "" != g && Yb(k, 2, +g);
                        g = Qd(d.href, "ny");
                        "" != g && Yb(k, 3, +g);
                        g = Qd(d.href, "bg");
                        "" != g && S(k, 4, g);
                        g = Qd(d.href, "nm");
                        "" != g && Yb(k, 5, +g);
                        g = Qd(d.href, "mb");
                        "" != g && Yb(k, 6, +g);
                        g = d.href;
                        e = g.search(wc);
                        f = 0;
                        for (var l = []; 0 <= (h = vc(g, f, "bg", e));) l.push(g.substring(f, h)), f = Math.min(g.indexOf("&", h) + 1 || e, e);
                        l.push(g.slice(f));
                        g = l.join("").replace(yc, "$1");
                        sc(d, Rc(g, Sc(1211)));
                        f = Q(c, 19);
                        g = null != ob(I(c, 20)) ? N(ob(I(c, 20)), 0) : null;
                        h = $b(k);
                        k = a.o;
                        e = yd(m);
                        l =
                            new lc;
                        f = S(l, 1, f);
                        f = S(f, 4, h);
                        f = S(f, 10, Date.now().toString());
                        null !== g && Yb(f, 2, g);
                        null !== k && S(f, 3, k);
                        Zb(f, 9, 4);
                        var n;
                        null == e || null == (n = e.fence) || n.reportEvent({
                            eventType: "click",
                            eventData: JSON.stringify(f),
                            destination: ["buyer"]
                        });
                        var p;
                        null == e || null == (p = e.fence) || p.reportEvent({
                            eventType: "click",
                            destination: ["component-seller"]
                        });
                        Zb(f, 9, 5);
                        let q;
                        null == e || null == (q = e.fence) || q.setReportEventDataForAutomaticBeacons({
                            eventType: "reserved.top_navigation",
                            eventData: JSON.stringify(f),
                            destination: ["buyer"],
                            once: !0
                        });
                        Zb(f, 9, 7);
                        let B;
                        null == e || null == (B = e.fence) || B.setReportEventDataForAutomaticBeacons({
                            eventType: "reserved.top_navigation_start",
                            eventData: JSON.stringify(f),
                            destination: ["buyer"],
                            once: !0
                        })
                    }
                    P(a.h, 16) || a.M ? oe(a, b, d, c) : (n = "", (p = m.oneAfmaInstance) && (n = p.appendClickSignals(d.href)), pe(a, b, d, c, n))
                }
            }
        }
    }

    function me(a, b, c, d) {
        if (a.F === b && a.H) {
            const f = new dc(a.H),
                h = Q(d, 9);
            var e = "";
            switch (R(f, 4, 1)) {
                case 2:
                    if (N(ob(I(f, 2)), 0)) e = "blocked_fast_click";
                    else if (Q(f, 1) || Q(f, 7)) e = "blocked_border_click";
                    break;
                case 3:
                    e = V;
                    e = e.getElementById ? e.getElementById("common_15click_anchor") : null;
                    const g = window;
                    if ("function" === typeof g.copfcChm && e) {
                        d = Lb(d);
                        Zb(d, 5, 12);
                        Tb(d, 4).set("nb", (12).toString());
                        const k = ie(a.g, e);
                        k ? k.data = d : a.g.push({
                            element: e,
                            data: d
                        });
                        !a.R && c && (ne(a, b, c, d), S(d, 2, c.href));
                        g.copfcChm(b, Bd(d, e.href), null,
                            void 0 !== K(f, cc, 10) ? $b(M(f, cc, 10)) : null);
                        a.R && ne(a, b, e, d)
                    }
                    e = "onepointfiveclick_first_click"
            }
            h && e && Od(h + "&label=" + e, !1);
            Oc(a.N)
        }
    }

    function ne(a, b, c, d) {
        if (!P(d, 13)) {
            var e = c.href;
            var f = /[?&]adurl=([^&]+)/.exec(e);
            e = f ? [e.slice(0, f.index), e.slice(f.index)] : [e, ""];
            for (sc(c, Rc(e[0], Sc(557))); !c.id;)
                if (f = "asoch-id-" + (Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)), !V.getElementById(f)) {
                    c.id = f;
                    break
                }
            f = c.id;
            "function" === typeof window.xy && window.xy(b, c, V.body);
            "function" === typeof window.mb && window.mb(c);
            "function" === typeof window.bgz && window.bgz(f);
            "function" ===
            typeof window.ja && window.ja(f, d ? R(d, 5, 0) : 0);
            "function" === typeof window.vti && window.vti(c);
            a.i && "function" === typeof window.ss && (a.P ? window.ss(f, 1, a.i) : window.ss(a.i, 1));
            0 < e.length && (a = 0 < a.o.length && (null == d || null == G(I(d, 19))) ? c.href + "&uach=" + encodeURIComponent(a.o) + e[1] : c.href + e[1], sc(c, Rc(a, Sc(557))))
        }
    }
    async function oe(a, b, c, d) {
        let e = "";
        var f = m.oneAfmaInstance;
        if (f && (b.preventDefault(), e = await f.appendClickSignalsAsync(c.href) || "", a.M)) {
            if (a.aa) return;
            if (f = await f.getNativeClickMeta()) {
                if (f.customClickGestureEligible) return;
                e = Ed(e, "nas", f.encodedNas)
            }
        }
        pe(a, b, c, d, e)
    }

    function pe(a, b, c, d, e) {
        const f = P(a.h, 2),
            h = f && 300 < Date.now() - a.O,
            g = m.oneAfmaInstance;
        g ? (Ac(b), (() => {
            let k = P(d, 13) ? e : g.logScionEventAndAddParam(e);
            if (!a.D && d && void 0 !== K(d, U, 12)) {
                var l = M(d, U, 12).v();
                if (0 < gc(d).length)
                    for (const n of gc(d));
                P(M(d, U, 12), 2) ? (g.click(k), g.openAndroidApp(l), l = !0) : l = !1
            } else l = !1;
            l || Ld(a.m, d, k, g, a.ba) || Nd(f, h, a.da, a.D, d, k, g, a.ca, a.K)
        })()) : (b = window, a.Z && b.pawsig && "function" === typeof b.pawsig.clk ? b.pawsig.clk(c) : h && (b = null != c.getAttribute("attributionsrc") && "6" === xc(c.getAttribute("attributionsrc"),
            "nis") ? Md(c.href, () => {}) : Md(c.href), b !== c.href && sc(c, Rc(b, Sc(599)))));
        h && (a.O = Date.now());
        Oc(a.N)
    }
    var ke = class {
        constructor(a) {
            this.D = Ma || Ka || Na || La;
            var b = Tc("data-asoch-meta");
            if (1 !== b.length) xd({
                type: 2,
                data: b.length
            });
            else {
                this.N = 70;
                this.h = new jc(JSON.parse(b[0].getAttribute("data-asoch-meta")) || []);
                this.L = a["extra-meta"] ? new jc(JSON.parse(a["extra-meta"])) : null;
                this.M = "true" === a["is-fsn"];
                this.aa = "true" === a["is-tap-disabled-for-fsn"];
                this.m = a["ios-store-overlay-config"] ? new kc(JSON.parse(a["ios-store-overlay-config"])) : null;
                this.da = "true" === a["use-cct-over-browser"];
                this.ba = "true" === a["send-ac-click-ping-by-js"];
                this.R = "true" === a["correct-redirect-url-for-och-15-click"];
                this.ca = "true" === a["send-click-ping-by-js-in-och"];
                this.Y = "true" === a["middle-clicks-in-och"];
                this.I = "true" === a["default-msg-in-och"];
                this.Z = "true" === a["enable-paw"];
                this.K = "true" === a["allow-redirection-muted-in-och"];
                this.o = "";
                b = ge();
                null != b && b.then(d => {
                    var e = $b(d);
                    d = [];
                    for (var f = 0, h = 0; h < e.length; h++) {
                        var g = e.charCodeAt(h);
                        255 < g && (d[f++] = g & 255, g >>= 8);
                        d[f++] = g
                    }
                    e = 3;
                    void 0 === e && (e = 0);
                    if (!Pa)
                        for (Pa = {}, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                            h = ["+/=", "+/", "-_=", "-_.", "-_"], g = 0; 5 > g; g++) {
                            var k = f.concat(h[g].split(""));
                            Oa[g] = k;
                            for (var l = 0; l < k.length; l++) {
                                var n = k[l];
                                void 0 === Pa[n] && (Pa[n] = l)
                            }
                        }
                    e = Oa[e];
                    f = Array(Math.floor(d.length / 3));
                    h = e[64] || "";
                    for (g = k = 0; k < d.length - 2; k += 3) {
                        var p = d[k],
                            q = d[k + 1];
                        n = d[k + 2];
                        l = e[p >> 2];
                        p = e[(p & 3) << 4 | q >> 4];
                        q = e[(q & 15) << 2 | n >> 6];
                        n = e[n & 63];
                        f[g++] = l + p + q + n
                    }
                    l = 0;
                    n = h;
                    switch (d.length - k) {
                        case 2:
                            l = d[k + 1], n = e[(l & 15) << 2] || h;
                        case 1:
                            d = d[k], f[g] = e[d >> 2] + e[(d & 3) << 4 | l >> 4] + n + h
                    }
                    this.o = f.join("")
                });
                this.g = Cd(this.h);
                this.I && (this.l = null,
                    ic(this.h).forEach(d => {
                        null == this.l && null != G(I(d, 2)) && null != G(I(d, 9)) && (this.l = d)
                    }));
                this.ea = Number(a["deeplink-and-android-app-validation-timeout"]) || 500;
                this.O = -Infinity;
                this.i = Q(this.h, 5) || "";
                this.P = P(this.h, 11);
                this.L && (this.P = P(this.L, 11));
                this.H = this.F = null;
                P(this.h, 3) || (Gd(this.g), Xb(this.h, 3, !0));
                he(this.g);
                a = m.oneAfmaInstance;
                !this.D && a && Jd(this.g, this.ea);
                var c;
                if (a && (null == (c = this.m) ? 0 : P(c, 2))) switch (c = () => {
                    const d = N(ob(I(this.m, 4)), 0);
                    0 < d ? m.setTimeout(() => {
                        Id(this.g)
                    }, d) : Id(this.g)
                }, R(this.m,
                    3, 0)) {
                    case 1:
                        a.runOnOnShowEvent(c);
                        break;
                    case 2:
                        Fc(c);
                        break;
                    default:
                        Id(this.g)
                }
                rc(V, "click", wd(557, d => {
                    le(this, d)
                }), nc);
                this.Y && rc(V, "auxclick", wd(557, d => {
                    1 === d.button && le(this, d)
                }), nc);
                this.i && "function" === typeof window.ss && rc(V.body, "mouseover", wd(626, () => {
                    window.ss(this.i, 0)
                }), oc);
                "function" === typeof window.ivti && window.ivti(V.body);
                c = window;
                c.googqscp && "function" === typeof c.googqscp.registerCallback && c.googqscp.registerCallback((d, e) => {
                    this.F = d;
                    this.H = e
                })
            }
        }
    };
    var qe = wd(555, a => je(a));
    Lc = 70;
    const re = Nc(70, document.currentScript);
    if (null == re) throw Error("JSC not found 70");
    const se = {},
        te = re.attributes;
    for (let a = te.length - 1; 0 <= a; a--) {
        const b = te[a].name;
        0 === b.indexOf("data-jcp-") && (se[b.substring(9)] = te[a].value)
    }
    qe(se);
}).call(this);