/* Copyright (c) 2008-2023, Quantcast Corp. https://www.quantcast.com/legal/license */ ! function() {
    "use strict";
    var e = "qcSes";

    function t() {
        var e = r();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
            var n = (e + 16 * Math.random()) % 16 | 0;
            return e = Math.floor(e / 16), ("x" === t ? n : 3 & n | 8).toString(16)
        }))
    }
    var n = function() {
        try {
            if (!window.sessionStorage) return t()
        } catch (e) {
            return t()
        }
        var n;
        try {
            if (n = window.sessionStorage.getItem(e)) return n
        } catch (e) {
            return t()
        }
        n = t();
        try {
            window.sessionStorage.setItem(e, n)
        } catch (e) {}
        return n
    }();

    function r() {
        return (new Date).getTime()
    }

    function o() {
        return new Date
    }

    function i(e) {
        var t = new Date(2e3, e, 1, 0, 0, 0, 0),
            n = t.toUTCString(),
            r = new Date(n.substring(0, n.lastIndexOf(" ") - 1));
        return t.getTime() - r.getTime()
    }

    function a() {
        return Math.round(2147483647 * Math.random())
    }
    /qcdbgc=1$/.test(window.location.toString());

    function c(e, t) {
        "undefined" != typeof console && console.log.apply(console, [e + " " + o().toString()].concat([].slice.call(t)))
    }
    var u = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        c("ERROR", e)
    };

    function s(e, t, o) {
        o = o || {};
        var i = {
            url: window.location.href,
            version: "b70d35e8-20231208114759",
            time: r(),
            browser: navigator.userAgent,
            sessionId: n
        };
        t && "string" == typeof t && (i.label = t), e && (e.message && "string" == typeof e.message ? i.msg = e.message : "string" == typeof e && (i.msg = e), e.stack && "string" == typeof e.stack && (i.stack = e.stack)), o.pcode && "string" == typeof o.pcode && (i.pcode = o.pcode);
        var a = new XMLHttpRequest;
        a.open("POST", "https://pixel.quantcount.com/tag/error", !0), a.send(JSON.stringify(i))
    }
    var f = "_dlt=",
        p = function(e, t) {
            if (void 0 === e) throw new Error("window many not be undefined");
            if (void 0 === t) throw new Error("top may not be undefined");
            t = t ? t.self : null, this.depth = 0;
            var n = e.self;
            for (this.top = n; n !== t;) {
                n = n.parent.self;
                try {
                    n.location.href && (this.url = n.location.href, this.top = n)
                } catch (e) {}
                this.depth++
            }
            this.locate = function(n) {
                for (var r = e;;) {
                    try {
                        if (n in r.frames) return r
                    } catch (e) {}
                    if (r === t) break;
                    r = r.parent.self
                }
            }
        },
        l = !1,
        d = [];

    function v() {
        for (l = !0; d.length > 0;) {
            var e = d.shift();
            e && e()
        }
    }

    function g(e) {
        l ? e() : d.push(e)
    }
    document.readyState in {
        complete: !0,
        interactive: !0
    } && (l = !0), document.addEventListener ? (document.addEventListener("DOMContentLoaded", v, !1), window.addEventListener("load", v, !1)) : document.attachEvent && window.attachEvent && (document.attachEvent("onreadystatechange", v), window.attachEvent("onload", v));
    var h = function(e, t) {
        var n = null,
            r = [];
        g((function() {
            n = t.head || t.getElementsByTagName("head")[0]
        }));
        var o = function(e) {
            var t = new Image;
            return t.src = e, t
        };
        return {
            image: function(e) {
                return new Promise((function(t, n) {
                    var i = o(e);
                    r.push(i), i.onload = function() {
                        t(i), r.shift(), delete i.onload, delete i.onerror
                    }, i.onerror = n
                }))
            },
            beacon: function(t) {
                var n = e.navigator;
                n && n.sendBeacon ? n.sendBeacon(t) : o(t)
            },
            script: function(e) {
                return new Promise((function(r, o) {
                    g((function() {
                        var i = function(e, n, r) {
                            var o = t.createElement("script");
                            o.type = "text/javascript", o.src = e;
                            var i = function() {
                                n(o), o.onreadystatechange = null, o.onload = null, o.onerror = null
                            };
                            return o.onload = i, o.onreadystatechange = function() {
                                o.readyState in {
                                    loaded: 1,
                                    complete: 1
                                } && i()
                            }, o.onerror = r, o
                        }(e, r, o);
                        n && (n.firstChild ? n.insertBefore(i, n.firstChild) : n.appendChild(i))
                    }))
                }))
            }
        }
    };

    function m(e, t, n) {
        e.addEventListener ? e.addEventListener(t, n) : "function" == typeof jQuery ? jQuery(e).on(t, n) : e.attachEvent && e.attachEvent("on" + t, n)
    }
    var y, w, _ = function(e, t, n, o, i, a, c, u) {
            var s, f = function(e) {
                var t = e.source[0];
                return "p" + e.consent[0] + ("a" == t ? "e" : "i")
            };
            s = "object" == typeof o && "function" == typeof o.callApi ? function(e, t, n, r) {
                var a = o.callApi(t, r, u, i, n);
                return e.cm = f(a), Promise.resolve(!0)
            } : function(o, a, c, s) {
                return e.depth > 0 && (m(t, "message", (function(e) {
                    var t = e.data;
                    if ("string" == typeof t && t.indexOf("PrivacyManagerAPI") > 0) try {
                        t = JSON.parse(t)
                    } catch (e) {
                        return
                    } else if (void 0 !== t.PrivacyManagerAPI) {
                        var n = t.PrivacyManagerAPI;
                        o.cm = f(n)
                    }
                })), n.postMessage(JSON.stringify({
                    PrivacyManagerAPI: {
                        timestamp: r(),
                        action: a,
                        self: s,
                        domain: u,
                        authority: i,
                        type: c
                    }
                }), "*")), Promise.resolve(!0)
            }, this.consent = function(e) {
                return s(e, "getConsent", a, c)
            }, this.parameters = {}
        },
        q = "__uspapiLocator",
        b = function(e, t) {
            var n;
            if ("function" == typeof t.__uspapi) {
                var o = t.__uspapi;
                n = function() {
                    return new Promise((function(e, t) {
                        o("getUSPData", 1, (function(n) {
                            n && "string" == typeof n.uspString ? e(n) : t(n)
                        }))
                    })).catch((function(e) {
                        return u("uspapi: unsuccessful", e), s(e, "uspapi: unsuccessful"), !0
                    }))
                }
            } else {
                e.locate(q);
                var i = {};
                m(t, "message", (function(e) {
                    var t = e.data;
                    if (null != t) {
                        if ("string" == typeof t && "{" == t[0]) try {
                            t = JSON.parse(t)
                        } catch (e) {
                            return
                        }
                        if (Object.prototype.hasOwnProperty.call(t, "__uspapiReturn")) {
                            var n = t.__uspapiReturn,
                                r = n.callId,
                                o = i[r];
                            if (void 0 === o) return;
                            n.success ? o[0](n.returnValue) : o[1](n.returnValue)
                        }
                    }
                })), n = function() {
                    var t = e.locate(q);
                    if (!t) return Promise.resolve(void 0);
                    var n = r();
                    return new Promise((function(e, r) {
                        i[n] = [e, r], t.postMessage({
                            __uspapiCall: {
                                command: "getUSPData",
                                version: 1,
                                callId: n
                            }
                        }, "*")
                    }))
                }
            }
            this.consent = function(e) {
                return n().then((function(t) {
                    if (t && "string" == typeof t.uspString) {
                        var n = t.uspString;
                        return e.us_privacy = n, "Y" != n[2]
                    }
                    return !0
                }))
            }
        },
        x = function(e) {
            var t, n = {},
                r = function(r) {
                    return void 0 === t && (t = Promise.all(e.map((function(e) {
                        return e.consent(n)
                    }))).then((function(e) {
                        return e.reduce((function(e, t) {
                            return e && t
                        }), !0)
                    }))), t.then((function(e) {
                        if (e) return r()
                    }))
                };
            this.consent = r, this.wrap = function(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return r((function() {
                        return e.apply(t, n)
                    }))
                }
            }, this.parameters = n
        };
    ! function(e) {
        e.getTCData = "getTCData", e.ping = "ping", e.addEventListener = "addEventListener", e.removeEventListener = "removeEventListener"
    }(y || (y = {})),
    function(e) {
        e.getInAppTCData = "getInAppTCData", e.getVendorList = "getVendorList"
    }(w || (w = {}));
    var S = "tcf2",
        P = [1, 3, 7, 8, 9, 10],
        I = [1, 3],
        O = [1, 3],
        E = "__tcfapiReturn";

    function C(e, t) {
        var n = t.gdprApplies,
            r = t.purpose,
            o = t.vendor,
            i = o && o.consents && o.consents[11],
            a = o && o.legitimateInterests && o.legitimateInterests[11],
            c = t.publisher ? t.publisher.restrictions : {};
        return !n || e.map((function(e) {
            var t = !!r.consents && r.consents[e],
                n = !!r.legitimateInterests && r.legitimateInterests[e],
                o = c && c[e] ? c[e][11] : null;
            return !(0 === o || (!i || !t || 2 === o || -1 == I.indexOf(e) && 1 !== o) && (1 === o || !a || !n || -1 != O.indexOf(e) || -1 != I.indexOf(e) && 2 !== o))
        })).reduce((function(e, t) {
            return e && t
        }), !0)
    }
    var j = function(e, t) {
        var n;
        this.consent = function(o) {
            var i, a;
            return void 0 === n && ("function" == typeof t.__tcfapi ? (a = t.__tcfapi, i = new Promise((function(e, t) {
                a(y.addEventListener, 2, (function(n, r) {
                    if (r) {
                        var o = n.eventStatus;
                        n.gdprApplies && "useractioncomplete" !== o && "tcloaded" !== o || e(n)
                    } else t(n)
                }))
            }))) : i = function() {
                var n = {},
                    o = {};
                m(t, "message", (function(e) {
                    var t = e.data;
                    if (void 0 === t) return u(S + ": Recieved undefined message"), void s("Recieved undefined message", S);
                    if ("string" == typeof t && "{" == t[0]) try {
                        t = JSON.parse(t)
                    } catch (e) {
                        return
                    }
                    if (Object.prototype.hasOwnProperty.call(t, E)) {
                        var r = t[E],
                            i = r.callId,
                            a = n[i];
                        if (void 0 === a) return;
                        var c = r.returnValue;
                        r.success ? "addEventListener" === o[i] && c.gdprApplies && "useractioncomplete" !== c.eventStatus && "tcloaded" !== c.eventStatus || a[0](c) : a[1](c)
                    }
                }));
                var i = e.locate("__tcfapiLocator");
                if (!i) return Promise.resolve({
                    gdprApplies: !1
                });
                var a = r();
                return new Promise((function(e, t) {
                    var r;
                    n[a] = [e, t], o[a] = y.addEventListener;
                    var c = ((r = {}).__tcfapiCall = {
                        command: y.addEventListener,
                        version: 2,
                        callId: a
                    }, r);
                    i.postMessage(JSON.stringify(c), "*")
                }))
            }(), n = i.then((function(e) {
                var t = !1;
                return "boolean" == typeof e.gdprApplies ? t = e.gdprApplies : "string" == typeof e.gdprApplies && (t = "false" != e.gdprApplies), t ? (o.gdpr = 1, o.gdpr_consent = e.tcString) : o.gdpr = o.gdpr || 0, C(P, e)
            })).catch((function(e) {
                return u(S + ": unsuccessful", e), s(e, S + ": unsuccessful"), o.gdpr = o.gdpr || 0, !0
            }))), n
        }
    };
    j.resolveConsent = C;
    var A = j,
        R = "__gppReturn",
        D = "addEventListener",
        L = function() {
            function e(e, t) {
                this.consentPromise = null, this.windows = e, this.win = t
            }
            return e.prototype.consent = function(e) {
                return this.consentPromise ? this.consentPromise : (t = "function" == typeof this.win.__gpp ? this.addEventListenerViaAPI(this.win.__gpp, e) : this.addEventListenerViaEvent(e), this.consentPromise = t, t);
                var t
            }, e.prototype.cmpReady = function(e) {
                return "signalStatus" === e.eventName && "ready" === e.data || "listenerRegistered" === e.eventName && !0 === e.data && "ready" === e.pingData.signalStatus
            }, e.prototype.addEventListenerViaAPI = function(e, t) {
                var n = this;
                return new Promise((function(r) {
                    e("addEventListener", (function(e, o) {
                        if (n.cmpReady(e)) {
                            var i = e.pingData.gppString;
                            t.gpp = i, t.gpp_sid = e.pingData.applicableSections.join(","), r(!0)
                        }
                    }))
                }))
            }, e.prototype.addEventListenerViaEvent = function(e) {
                var t = this,
                    n = this.windows.locate("__gppLocator");
                if (!n) return Promise.resolve(!0);
                var o = {},
                    i = {},
                    a = r();
                return m(window, "message", (function(n) {
                    var r = n.data;
                    if (void 0 === r) return u("gpp: Recieved undefined message"), void s("Recieved undefined message", "gpp");
                    if ("string" == typeof r && "{" == r[0]) try {
                        r = JSON.parse(r)
                    } catch (e) {
                        return
                    }
                    if (Object.prototype.hasOwnProperty.call(r, R)) {
                        var a = r[R],
                            c = a.callId,
                            f = o[c];
                        if (void 0 === f) return;
                        var p = a.returnValue;
                        if (a.success) {
                            if (i[c] !== D) return;
                            if (!t.cmpReady(p)) return;
                            var l = p.pingData.gppString;
                            e.gpp = l, e.gpp_sid = p.pingData.applicableSections.join(","), f[0](!0)
                        } else f[1]()
                    }
                })), new Promise((function(e, t) {
                    var r;
                    o[a] = [e, t], i[a] = D;
                    var c = ((r = {}).__gppCall = {
                        command: D,
                        callId: a
                    }, r);
                    n.postMessage(JSON.stringify(c), "*")
                }))
            }, e
        }();

    function T(e, t) {
        return t >>> e | t << 32 - e
    }

    function M(e) {
        return T(2, e) ^ T(13, e) ^ T(22, e)
    }

    function N(e) {
        return T(6, e) ^ T(11, e) ^ T(25, e)
    }

    function k(e) {
        return T(7, e) ^ T(18, e) ^ e >>> 3
    }

    function U(e, t, n) {
        return e & t ^ ~e & n
    }

    function z(e, t, n) {
        return e & t ^ e & n ^ t & n
    }
    var V = function(e, t) {
        var n;
        for (n = 0; n < t.length; n++) e ^= t.charCodeAt(n), e += (e << 1) + (e << 4) + (e << 7) + (e << 8) + (e << 24);
        return e
    };

    function J(e) {
        for (var t = unescape(encodeURIComponent(e)), n = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298], r = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], o = (t += String.fromCharCode(128)).length / 4 + 2, i = Math.ceil(o / 16), a = new Array(i), c = 0; c < i; c++) {
            a[c] = new Array(16);
            for (var u = 0; u < 16; u++) a[c][u] = t.charCodeAt(64 * c + 4 * u + 0) << 24 | t.charCodeAt(64 * c + 4 * u + 1) << 16 | t.charCodeAt(64 * c + 4 * u + 2) << 8 | t.charCodeAt(64 * c + 4 * u + 3) << 0
        }
        var s, f = 8 * (t.length - 1) / Math.pow(2, 32),
            p = 8 * (t.length - 1) >>> 0;
        for (a[i - 1][14] = Math.floor(f), a[i - 1][15] = p, c = 0; c < i; c++) {
            for (var l = new Array(64), d = 0; d < 16; d++) l[d] = a[c][d];
            for (d = 16; d < 64; d++) l[d] = (T(17, s = l[d - 2]) ^ T(19, s) ^ s >>> 10) + l[d - 7] + k(l[d - 15]) + l[d - 16] >>> 0;
            var v = r[0],
                g = r[1],
                h = r[2],
                m = r[3],
                y = r[4],
                w = r[5],
                _ = r[6],
                q = r[7];
            for (d = 0; d < 64; d++) {
                var b = q + N(y) + U(y, w, _) + n[d] + l[d],
                    x = M(v) + z(v, g, h);
                q = _, _ = w, w = y, y = m + b >>> 0, m = h, h = g, g = v, v = b + x >>> 0
            }
            r[0] = r[0] + v >>> 0, r[1] = r[1] + g >>> 0, r[2] = r[2] + h >>> 0, r[3] = r[3] + m >>> 0, r[4] = r[4] + y >>> 0, r[5] = r[5] + w >>> 0, r[6] = r[6] + _ >>> 0, r[7] = r[7] + q >>> 0
        }
        var S = [];
        for (q = 0; q < r.length; q++) S[q] = ("00000000" + r[q].toString(16)).slice(-8);
        return S.join("")
    }
    var B = function(e) {
            var t = typeof e;
            return "string" == t && e.length > 0 || "number" == t || "boolean" == t
        },
        F = 338688e5,
        Q = "__qca",
        H = ["4dcfa7079941", "127fdf7967f31", "588ab9292a3f", "32f92b0727e5", "22f9aa38dfd3", "a4abfe8f3e04", "18b66bc1325c", "958e70ea2f28", "bdbf0cb4bbb", "65118a0d557", "40a1d9db1864", "18ae3d985046", "3b26460f55d"],
        $ = function(e, t) {
            var n, r, o, i = null;
            return e ? (r = (n = e.indexOf(t + "=")) + t.length + 1, n > -1 && ((o = e.indexOf(";", r)) < 0 && (o = e.length), i = e.substring(r, o)), i) : i
        };

    function G(e, t, c) {
        var l, d, v, g, m, y, w, q, S, P, I, O, E, C, j, R, D, T, M, N, k, U, z, G, X, Y, Z, K, W, ee, te, ne, re, oe, ie, ae, ce, ue, se, fe, pe = "quantserve.com",
            le = function(e) {
                for (var t = e.domain || "", n = new Date(0).toUTCString(), o = new Date(r() + 864e5).toUTCString(), i = t.split("."), a = "", c = 2; c <= i.length; c++) {
                    a = i.slice(-c).join(".");
                    var u = f + "1; path=/; domain=" + a + "; expires=" + o;
                    if (e.cookie = u, /_dlt=1\b/.test(e.cookie)) return e.cookie = f + "; path=/; domain=" + a + "; expires=" + n, a
                }
                return e.cookie = f + "; path=/; domain=" + a + "; expires=" + n, t
            }(t),
            de = new p(e, e.top),
            ve = new h(e, t),
            ge = function() {
                var e;
                if (!(null === (e = null === navigator || void 0 === navigator ? void 0 : navigator.userAgentData) || void 0 === e ? void 0 : e.getHighEntropyValues)) return Promise.resolve("");
                try {
                    return navigator.userAgentData.getHighEntropyValues(["model"]).then((function(e) {
                        return encodeURIComponent(e.model)
                    })).catch((function() {
                        return ""
                    }))
                } catch (e) {
                    return Promise.resolve("")
                }
            }(),
            he = new x([new _(de, e, e.top, e.PrivacyManagerAPI, "truste.com", "advertising", pe, le), new b(de, e), new A(de, e), new L(de, e)]),
            me = function(e, t, n) {
                var r = 0,
                    i = $(t.cookie, Q) || function(e, t) {
                        var n = null;
                        try {
                            n = e.localStorage.getItem(t)
                        } catch (e) {}
                        if (!n) return null;
                        var r = JSON.parse(n);
                        if (o().getTime() > r.expiry) {
                            try {
                                e.localStorage.removeItem(t)
                            } catch (e) {}
                            return null
                        }
                        return r.value
                    }(e, Q),
                    c = function(e) {
                        for (var t, n, r, o = (n = V(2166136261, t = e), r = V(3386659096, t), Math.round(Math.abs(n * r) / 65536).toString(16)), i = 0; i < H.length; i++)
                            if (H[i] === o) return !0;
                        return !1
                    }(n);
                return i || (r = 1, i = "P0-" + a() + "-" + o().getTime()), {
                    SD: H,
                    persistIdentifier: function() {
                        1 !== r || c || (t.cookie = [Q, "=", i, "; expires=", new Date(o().getTime() + F).toUTCString(), "; path=/; domain=", n].join(""), function(e, t, n, r) {
                            var i = {
                                value: n,
                                expiry: o().getTime() + r
                            };
                            try {
                                e.localStorage.setItem(t, JSON.stringify(i))
                            } catch (e) {}
                        }(e, Q, i, F))
                    },
                    removeIdentifier: function() {
                        t.cookie = Q + "=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
                        try {
                            e.localStorage.removeItem(Q)
                        } catch (e) {}
                    },
                    getFirstPartyIDString: function(e) {
                        return c || 1 === e ? ";fpan=u;fpa=" : ";fpan=" + r + ";fpa=" + i
                    },
                    getExternalIDString: function(e) {
                        if (c || 1 === e) return "";
                        var n = $(t.cookie, "_pubcid") || $(t.cookie, "_sharedID"),
                            r = $(t.cookie, "_pubcid_optout");
                        return !$(t.cookie, "_pbjs_id_optout") && "1" !== r && n ? ";pbc=" + n : ";pbc="
                    }
                }
            }(e, t, le),
            ye = ["a", "ce", "cm", "dst", "enc", "fpa", "fpan", "je", "ns", "ogl", "rf", "tzo", "sr", "ses"],
            we = "rule",
            _e = "webpage",
            qe = "ad",
            be = "load",
            xe = "engagement",
            Se = !1,
            Pe = !1,
            Ie = 0,
            Oe = [],
            Ee = [],
            Ce = [],
            je = [],
            Ae = {},
            Re = 0,
            De = null,
            Le = {},
            Te = {},
            Me = [].slice;
        fe = t.createElement("script"), l = "async" in fe ? 1 : fe.readyState ? 2 : 3, fe = null;
        var Ne = function(e) {
            try {
                return {
                    init: g,
                    clean: ke,
                    hash: J,
                    push: m,
                    rules: G,
                    require: function() {
                        s("deprecated api.require fn called", "api", {
                            pcode: je[0]
                        })
                    },
                    hasRules: Y,
                    defaults: ee,
                    __qc: function() {
                        return !0
                    }
                }[e].apply(null, Me.call(arguments, 1))
            } catch (e) {
                return u(e), s(e, "api", {
                    pcode: je[0]
                }), !1
            }
        };
        Ne.evts = 0, Ne.v = 2, Ne.SD = me.SD, Ne.qpixelsent = [], z = function(e) {
            var t, n = e && e.length || 0;
            for (t = 0; t < n; t++)
                if (!e[t]) return !1;
            return !0
        }, W = function(t) {
            (t = t || e._qacct) && (R(je, t) || je.push(t))
        }, R = function(e, t) {
            var n, r = e.length;
            for (n = 0; n < r; n++)
                if (e[n] === t) return !0;
            return !1
        }, M = function(e) {
            return {}.toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase()
        }, N = function(e) {
            var t, n, r;
            if ("array" === (n = M(e))) return e.slice(0);
            if ("object" === n) {
                for (r in t = {}, e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return t
            }
            return "string" === n ? "" + e : e
        }, m = function(e, t) {
            y(e, t)
        }, Y = function(e) {
            return R(Ce, e)
        }, ee = function(e, t) {
            var n;
            e && ((n = Le[e]) && (t = C(t, n)), t && t.qacct && delete t.qacct, Le[e] = t)
        }, te = function(t) {
            var n, r, o, i, a, c;
            if (v(t))
                for (i in a = t) {
                    if ("string" == typeof a[i]) {
                        n = t.event || be, r = t.media || _e, n !== we && n !== be || r !== _e && r !== qe ? y(t) : (c = t.qacct || e._qacct, t.qacct = c, o = (o = Te[c]) ? C(o, t) : t, Te[c] = o), W(t.qacct);
                        break
                    }
                    "object" == typeof a[i] && null != a[i] && te(a[i])
                }
        }, C = function(e, t) {
            var n = {};
            return n.qacct = e.qacct || t.qacct, e.event === be || t.event === be ? n.event = be : e.event && t.event ? n.event = e.event || t.event : n.event = null, n.media = null, e.media === _e || t.media === _e ? n.media = _e : e.media === qe || t.media === qe ? n.media = qe : n.media = e.media || t.media, j(n, e, t), j(n, t, e), n.event || delete n.event, n.media || delete n.media, n
        }, j = function(e, t, n) {
            var r, o, i, a, c, u;
            for (r in t) Object.prototype.hasOwnProperty.call(t, r) && !Object.prototype.hasOwnProperty.call(e, r) && (o = t[r], a = "", u = !!(i = n[r]) && "string" == typeof i, (c = !!o && "string" == typeof o) && (a = o), c && u && (a += ","), u && (a += i), e[r] = a)
        }, ne = function() {
            var e, t, n = [];
            if (!(Re > 0)) {
                for (e in T(), Te) Object.prototype.hasOwnProperty.call(Te, e) && Te[e] && (t = Te[e], n.push(t), delete Te[e]);
                if (1 == n.length && y(n[0]), n.length > 1)
                    for (e = 0; e < n.length; e++) y(n[e])
            }
        }, re = function() {
            var e, t, n, r = [];
            for (n = je.slice(0), e = 0; e < n.length; e++) t = n[e], Y(t) || r.push(t);
            if (0 === r.length) ne();
            else
                for (e = 0; e < r.length; e++) t = r[e], Ce.push(t), O(t)
        }, E = function(n, r, o, i) {
            var a;
            n = e.location.protocol + "//" + n;
            var c = (De = t.scripts && t.scripts[0] || null) && De.parentNode || t.head || t;
            if (a = t.createElement("script"), 1 === l) a.src = n, a.async = !0, a.onload = r, o && (a.onerror = function(e) {
                a.onerror = null, o(e)
            }), c.insertBefore(a, De);
            else if (2 === l) {
                var u = !1;
                a.onload = a.onreadystatechange = function() {
                    u || "loaded" != a.readyState && "complete" != a.readyState || (u = !0, a.onreadystatechange = null, r())
                }, a.src = n, c.insertBefore(a, De)
            } else i && i()
        }, O = function(e) {
            Re++, E("rules.quantcount.com/rules-" + e + ".js", (function() {
                Ae[e] = 2 === l ? 2 : 0, oe()
            }), (function(t) {
                Ae[e] = 1, s(t, "ruleFetch", {
                    pcode: e
                }), oe()
            }), (function() {
                Ae[e] = 4, oe()
            }))
        }, oe = function() {
            Re -= Re > 0 ? 1 : 0, ne()
        }, G = function() {
            var e, t, n, r = !0,
                o = !1;
            if (arguments.length) {
                for (n = function(e) {
                        r ? te(e) : y(e, !0), o = !0
                    }, e = 0; e < arguments.length; e++)(t = Me.call(arguments[e], 0)).splice(1, 0, n), X.apply(null, t);
                r = !1, Se && ne()
            }
            return o
        }, X = function(e, t) {
            var n, r, o, i, a, c, u, s = [],
                f = [],
                p = t || y;
            if ((r = Me.call(arguments, 2)) && r.length) {
                for (o = r[0] || z, i = r[1], n = (a = r[2]).length, c = 0; c < n; c++) s.push(!1), f.push(null);
                u = {
                    p: e,
                    f: s,
                    r: o,
                    c: a,
                    a: i,
                    v: f
                }, Y(e) || Ce.push(e), Ee.push(u), Z(u, p)
            } else Ce.push(e), Ae[e] = 6
        }, Z = function(e, t) {
            var n, r = e && e.c ? e.c.length : 0;
            for (n = 0; n < r; n++) ! function(n) {
                var r, o;
                try {
                    r = e.c[n][0], (o = e.c[n].slice(1)).splice(0, 0, (function(r) {
                        e.f[n] = !0, e.v[n] = r, K(e, t)
                    })), r.apply(null, o)
                } catch (r) {
                    s(r, "processRule", {
                        pcode: e.p
                    }), e.f[n] = !0, e.v[n] = !1, K(e, t)
                }
            }(n)
        }, K = function(e, t) {
            var n, r, o, i, a, c, u, f = e.a,
                p = e.f,
                l = e.v,
                d = e.r || z;
            if ((n = z(p)) && (n = n && d(l)), n)
                for (a = 0; a < f.length; a++) try {
                    for (u in r = f[a][0], o = (o = f[a].length > 1 ? f[a].slice(1) : []).concat(e.v), i = r.apply(null, o), c = {
                            qacct: e.p,
                            event: we
                        }, i) Object.prototype.hasOwnProperty.call(i, u) && "qacct" !== u && (c[u] = i[u]);
                    t(c)
                } catch (t) {
                    s(t, "evalRule", {
                        pcode: e.p
                    });
                    continue
                }
        }, d = function(e) {
            return e.replace(/\./g, "%2E").replace(/,/g, "%2C")
        }, v = function(e) {
            return void 0 !== e && null != e
        }, U = function(e) {
            var t, n;
            if (e && "object" === M(e))
                for (n = 0; n < ye.length; n++) t = ye[n], Object.prototype.hasOwnProperty.call(e, t) && e[t] && delete e[t]
        }, P = function(t, n, r) {
            var o, i, a;
            return n && "string" == typeof n.qacct ? o = n.qacct : "string" == typeof e._qacct && (o = e._qacct), o && 0 !== o.length ? (n = k(o, n), delete Te[o], a = Le[o], i = Ae[o], v(i) || (i = 3), se(n, a, r, o) ? null : function(e, t, n, r, o) {
                var i, a = {},
                    c = null,
                    u = /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    s = /^[A-Fa-f0-9]{64}$/,
                    f = 2;
                for (i in t) Object.prototype.hasOwnProperty.call(t, i) && B(t[i]) && ("uid" !== i && "uh" !== i ? "qacct" !== i && (a[i + e] = encodeURIComponent(t[i])) : (t[i].match(s) ? (f = 1, c = t[i].toLowerCase()) : (t[i].match(u) && (f = 0, t[i] = t[i].toLowerCase()), "" !== t[i] && (c = J(t[i]))), delete t[i]));
                for (i in n) Object.prototype.hasOwnProperty.call(n, i) && B(n[i]) && !a[i + e] && (a[i + e] = encodeURIComponent(n[i]));
                return a["rf" + e] = "" + o, "string" == typeof c && (t.uh = c, a["uh" + e] = encodeURIComponent(c)), a["uht" + e] = "" + f, a["a" + e] = r, a
            }(t, n, a, o, i)) : null
        }, S = function(e) {
            var t, n = [],
                r = [],
                o = [];
            for (t in e) e[t] && Object.prototype.hasOwnProperty.call(e, t) && ("uh" === t || "uht" === t ? r.push(";" + t + "=" + e[t]) : n.push(t + "=" + e[t]));
            return o.push(n.join(";")), o.push(r.join("")), o
        }, I = function() {
            var e, n, r, o, i, a = t.getElementsByTagName("meta"),
                c = "";
            for (e = 0; e < a.length; e++) {
                if (i = a[e], c.length >= 1e3) return encodeURIComponent(c);
                v(i) && v(i.attributes) && v(i.attributes.property) && v(i.attributes.property.value) && v(i.content) && (n = i.attributes.property.value, r = i.content, n.length > 3 && "og:" === n.substring(0, 3) && (c.length > 0 && (c += ","), o = r.length > 80 ? 80 : r.length, c += d(n.substring(3, n.length)) + "." + d(r.substring(0, o))))
            }
            return encodeURIComponent(c)
        }, y = function(r, u) {
            var s, f, p, l, d, g, h, m, y, w, _, b = a(),
                x = "",
                O = "",
                E = "",
                j = "",
                A = "1",
                R = [];
            if (Ie = 0, v(Ne.qpixelsent) || (Ne.qpixelsent = []), v(r)) {
                if ("object" === (w = M(r))) p = P("", r, u);
                else if ("array" === w)
                    for (d = 0; d < r.length; d++) _ = P("." + (d + 1), r[d], u), p = 0 === d ? _ : C(p, _)
            } else "string" == typeof _qacct && (p = P("", null, u));
            if (p) {
                s = c.cookieEnabled ? "1" : "0", v(e._qmeta) && (x = ";m=" + encodeURIComponent(e._qmeta), e._qmeta = null), g = o(), h = i(0) !== i(6) ? 1 : 0, m = me.getFirstPartyIDString(Ie), y = me.getExternalIDString(Ie), e.location && e.location.href && (O = encodeURIComponent(e.location.href)), t && t.referrer && (j = encodeURIComponent(t.referrer)), e.self === e.top && (A = "0"), p.url ? E = O : p.url = O, p.ref || (p.ref = j || ""), f = I(), l = S(p);
                var D = ue(p.event),
                    L = p.event === xe ? "/engagement" : "/pixel";
                R.push(L + D + "r=" + b + ";" + l[0]), R.push(l[1]), R.push(m + y), R.push(";ns=" + A + ";ce=" + s + ";qjs=1;qv=b70d35e8-20231208114759"), R.push((p.ref ? "" : ";ref=") + ";d=" + le + ";dst=" + h + ";et=" + g.getTime() + ";tzo=" + g.getTimezoneOffset() + (E ? ";ourl=" + E : "") + x + ";ogl=" + f + ";ses=" + n), Oe.push({
                    pixel: R,
                    pCode: p.a
                }), q()
            }
        }, ue = function(e) {
            return e === xe ? "?" : ";"
        }, w = function(t) {
            var n = t.pixel,
                r = {};
            he.consent((function() {
                return !0
            })).then((function(e) {
                e || me.removeIdentifier(), r.target = e ? pe : "quantcount.com"
            })).then((function() {
                return ge
            })).then((function(t) {
                var o, i = r.target,
                    a = he.parameters,
                    c = [navigator && "Apple Computer, Inc." === navigator.vendor ? "https://prreqcroab.icu" : "https://pixel." + i, n[0], i === pe ? [n[1], n[2]].join("") : ";uh=u;uht=u", n[3], ";cm=", a.cm, 1 === a.gdpr ? ";gdpr=1;gdpr_consent=" + a.gdpr_consent : ";gdpr=0", a.us_privacy ? ";us_privacy=" + a.us_privacy : "", a.gpp ? ";gpp=" + a.gpp : "", a.gpp_sid ? ";gpp_sid=" + a.gpp_sid : "", n[4], ";mdl=" + t].join("");
                return "function" != typeof CustomEvent ? (o = document.createEvent("CustomEvent")).initCustomEvent("q_pixel_fire", !1, !1, {
                    url: c
                }) : o = new CustomEvent("q_pixel_fire", {
                    detail: {
                        url: c
                    }
                }), e.dispatchEvent(o), ve.image(c).catch((function() {
                    return null
                })).then((function(e) {
                    e && "number" == typeof e.width && 3 === e.width ? me.removeIdentifier() : i === pe && me.persistIdentifier()
                }))
            })).catch((function(e) {
                s(e, "fire")
            }))
        }, q = function() {
            for (; Oe.length;) w(Oe.shift())
        }, ie = function() {
            var e, t = arguments;
            for (D([].slice.call(t)), e = 0; e < t.length; e++) y(t[e]);
            je.length ? re() : ne()
        }, D = function(t) {
            var n, r = M(t);
            if ("array" === r)
                for (n = 0; n < t.length; n++) D(t[n]);
            else "object" === r && W(t.qacct || e._qacct)
        }, T = function() {
            var t;
            if (Pe || e._qevents.length || e.ezt.length || "undefined" == typeof _qacct || (y({
                    qacct: e._qacct
                }), Pe = !0), !Ne.evts) {
                for (t in e._qevents) e._qevents[t] !== e._qevents.push && Object.prototype.hasOwnProperty.call(e._qevents, t) && y(e._qevents[t]);
                for (t in e.ezt) e.ezt[t] !== e.ezt.push && Object.prototype.hasOwnProperty.call(e.ezt, t) && y(e.ezt[t]);
                e._qevents = {
                    push: ie
                }, e.ezt.push = function() {
                    var t, n = arguments;
                    if (v(e.queueManager))
                        for (t = 0; t < n.length; t++) e.queueManager.push(n[t]);
                    else ie.apply(this, arguments)
                }, Ne.evts = 1
            }
        }, ce = function(t) {
            var n;
            t && (n = N(t), D(t), e._qevents.push(n), t = null)
        }, ae = function(e) {
            e.push = function() {
                return D([].slice.call(arguments)), re(), [].push.apply(e, arguments)
            }
        }, se = function(e, t, n, r) {
            t = t || {};
            var o = (e ? e.media : t.media) || _e,
                i = (e ? e.event : t.event) || be;
            if (o === qe && (Ie = 1), o === _e && i === be) {
                for (var a = 0; a < Ne.qpixelsent.length; a++)
                    if (Ne.qpixelsent[a] === r && !n) return !0;
                Ne.qpixelsent.push(r)
            }
            return !1
        }, k = function(e, t) {
            var n = Te[e];
            return t ? n && (t = C(t, n)) : t = n, U(t), t
        }, g = function() {
            try {
                v(e._qevents) || (e._qevents = []), v(e.ezt) || (e.ezt = []), ce(e._qoptions), ce(e.qcdata), ce(e.smarttagdata), Ne.evts || (ae(e._qevents), ae(e.ezt)), D(e.ezt), D(e._qevents), D({
                    qacct: e._qacct
                }), e._qoptions = null, je.length ? re() : ne(), Se = !0
            } catch (e) {
                return s(e, "init"), e
            }
        };
        var ke = function() {
            e._qevents = null, e.ezt = null, e.quantserve = null
        };
        return e.quantserve = e.quantserve || g, Ne.quantserve = g, Ne
    }
    void 0 !== window.Promise && (void 0 === window.__qc && (window.__qc = new function(e, t, n) {
        try {
            return new G(e, t, n)
        } catch (e) {
            return s(e, "construct"), e
        }
    }(window, window.document, window.navigator)), window.__qc("init")), window.__qc
}();
//# sourceMappingURL=quant.min.js.map