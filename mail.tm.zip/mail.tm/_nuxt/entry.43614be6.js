function io(e, t) {
    const n = Object.create(null),
        r = e.split(",");
    for (let a = 0; a < r.length; a++) n[r[a]] = !0;
    return t ? a => !!n[a.toLowerCase()] : a => !!n[a]
}
const Oe = {},
    mr = [],
    Pt = () => {},
    Cy = () => !1,
    ja = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
    Hl = e => e.startsWith("onUpdate:"),
    Ge = Object.assign,
    Kl = (e, t) => {
        const n = e.indexOf(t);
        n > -1 && e.splice(n, 1)
    },
    Ay = Object.prototype.hasOwnProperty,
    ye = (e, t) => Ay.call(e, t),
    ie = Array.isArray,
    gr = e => $a(e) === "[object Map]",
    fp = e => $a(e) === "[object Set]",
    Ly = e => $a(e) === "[object RegExp]",
    se = e => typeof e == "function",
    xe = e => typeof e == "string",
    Dr = e => typeof e == "symbol",
    Te = e => e !== null && typeof e == "object",
    Ul = e => (Te(e) || se(e)) && se(e.then) && se(e.catch),
    dp = Object.prototype.toString,
    $a = e => dp.call(e),
    Sy = e => $a(e).slice(8, -1),
    pp = e => $a(e) === "[object Object]",
    Jl = e => xe(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
    ia = io(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    oo = e => {
        const t = Object.create(null);
        return n => t[n] || (t[n] = e(n))
    },
    Ty = /-(\w)/g,
    Ut = oo(e => e.replace(Ty, (t, n) => n ? n.toUpperCase() : "")),
    ky = /\B([A-Z])/g,
    ar = oo(e => e.replace(ky, "-$1").toLowerCase()),
    so = oo(e => e.charAt(0).toUpperCase() + e.slice(1)),
    Ko = oo(e => e ? `on${so(e)}` : ""),
    Zn = (e, t) => !Object.is(e, t),
    oa = (e, t) => {
        for (let n = 0; n < e.length; n++) e[n](t)
    },
    Ii = (e, t, n) => {
        Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            value: n
        })
    },
    Ry = e => {
        const t = parseFloat(e);
        return isNaN(t) ? e : t
    },
    hp = e => {
        const t = xe(e) ? Number(e) : NaN;
        return isNaN(t) ? e : t
    };
let lu;
const Es = () => lu || (lu = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

function er(e) {
    if (ie(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) {
            const r = e[n],
                a = xe(r) ? xy(r) : er(r);
            if (a)
                for (const i in a) t[i] = a[i]
        }
        return t
    } else if (xe(e) || Te(e)) return e
}
const Oy = /;(?![^(]*\))/g,
    My = /:([^]+)/,
    Py = /\/\*[^]*?\*\//g;

function xy(e) {
    const t = {};
    return e.replace(Py, "").split(Oy).forEach(n => {
        if (n) {
            const r = n.split(My);
            r.length > 1 && (t[r[0].trim()] = r[1].trim())
        }
    }), t
}

function Le(e) {
    let t = "";
    if (xe(e)) t = e;
    else if (ie(e))
        for (let n = 0; n < e.length; n++) {
            const r = Le(e[n]);
            r && (t += r + " ")
        } else if (Te(e))
            for (const n in e) e[n] && (t += n + " ");
    return t.trim()
}

function Gl(e) {
    if (!e) return null;
    let {
        class: t,
        style: n
    } = e;
    return t && !xe(t) && (e.class = Le(t)), n && (e.style = er(n)), e
}
const Iy = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot",
    Dy = io(Iy),
    Ny = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
    Fy = io(Ny);

function mp(e) {
    return !!e || e === ""
}
const qn = e => xe(e) ? e : e == null ? "" : ie(e) || Te(e) && (e.toString === dp || !se(e.toString)) ? JSON.stringify(e, gp, 2) : String(e),
    gp = (e, t) => t && t.__v_isRef ? gp(e, t.value) : gr(t) ? {
        [`Map(${t.size})`]: [...t.entries()].reduce((n, [r, a], i) => (n[Uo(r, i) + " =>"] = a, n), {})
    } : fp(t) ? {
        [`Set(${t.size})`]: [...t.values()].map(n => Uo(n))
    } : Dr(t) ? Uo(t) : Te(t) && !ie(t) && !pp(t) ? String(t) : t,
    Uo = (e, t = "") => {
        var n;
        return Dr(e) ? `Symbol(${(n=e.description)!=null?n:t})` : e
    };
let mt;
class yp {
    constructor(t = !1) {
        this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = mt, !t && mt && (this.index = (mt.scopes || (mt.scopes = [])).push(this) - 1)
    }
    get active() {
        return this._active
    }
    run(t) {
        if (this._active) {
            const n = mt;
            try {
                return mt = this, t()
            } finally {
                mt = n
            }
        }
    }
    on() {
        mt = this
    }
    off() {
        mt = this.parent
    }
    stop(t) {
        if (this._active) {
            let n, r;
            for (n = 0, r = this.effects.length; n < r; n++) this.effects[n].stop();
            for (n = 0, r = this.cleanups.length; n < r; n++) this.cleanups[n]();
            if (this.scopes)
                for (n = 0, r = this.scopes.length; n < r; n++) this.scopes[n].stop(!0);
            if (!this.detached && this.parent && !t) {
                const a = this.parent.scopes.pop();
                a && a !== this && (this.parent.scopes[this.index] = a, a.index = this.index)
            }
            this.parent = void 0, this._active = !1
        }
    }
}

function Va(e) {
    return new yp(e)
}

function By(e, t = mt) {
    t && t.active && t.effects.push(e)
}

function Nr() {
    return mt
}

function lo(e) {
    mt && mt.cleanups.push(e)
}
const Wl = e => {
        const t = new Set(e);
        return t.w = 0, t.n = 0, t
    },
    bp = e => (e.w & Ln) > 0,
    vp = e => (e.n & Ln) > 0,
    jy = ({
        deps: e
    }) => {
        if (e.length)
            for (let t = 0; t < e.length; t++) e[t].w |= Ln
    },
    $y = e => {
        const {
            deps: t
        } = e;
        if (t.length) {
            let n = 0;
            for (let r = 0; r < t.length; r++) {
                const a = t[r];
                bp(a) && !vp(a) ? a.delete(e) : t[n++] = a, a.w &= ~Ln, a.n &= ~Ln
            }
            t.length = n
        }
    },
    Di = new WeakMap;
let ta = 0,
    Ln = 1;
const Cs = 30;
let Rt;
const Yn = Symbol(""),
    As = Symbol("");
class zl {
    constructor(t, n = null, r) {
        this.fn = t, this.scheduler = n, this.active = !0, this.deps = [], this.parent = void 0, By(this, r)
    }
    run() {
        if (!this.active) return this.fn();
        let t = Rt,
            n = _n;
        for (; t;) {
            if (t === this) return;
            t = t.parent
        }
        try {
            return this.parent = Rt, Rt = this, _n = !0, Ln = 1 << ++ta, ta <= Cs ? jy(this) : cu(this), this.fn()
        } finally {
            ta <= Cs && $y(this), Ln = 1 << --ta, Rt = this.parent, _n = n, this.parent = void 0, this.deferStop && this.stop()
        }
    }
    stop() {
        Rt === this ? this.deferStop = !0 : this.active && (cu(this), this.onStop && this.onStop(), this.active = !1)
    }
}

function cu(e) {
    const {
        deps: t
    } = e;
    if (t.length) {
        for (let n = 0; n < t.length; n++) t[n].delete(e);
        t.length = 0
    }
}
let _n = !0;
const _p = [];

function Fr() {
    _p.push(_n), _n = !1
}

function Br() {
    const e = _p.pop();
    _n = e === void 0 ? !0 : e
}

function dt(e, t, n) {
    if (_n && Rt) {
        let r = Di.get(e);
        r || Di.set(e, r = new Map);
        let a = r.get(n);
        a || r.set(n, a = Wl()), wp(a)
    }
}

function wp(e, t) {
    let n = !1;
    ta <= Cs ? vp(e) || (e.n |= Ln, n = !bp(e)) : n = !e.has(Rt), n && (e.add(Rt), Rt.deps.push(e))
}

function Zt(e, t, n, r, a, i) {
    const o = Di.get(e);
    if (!o) return;
    let s = [];
    if (t === "clear") s = [...o.values()];
    else if (n === "length" && ie(e)) {
        const l = Number(r);
        o.forEach((c, u) => {
            (u === "length" || !Dr(u) && u >= l) && s.push(c)
        })
    } else switch (n !== void 0 && s.push(o.get(n)), t) {
        case "add":
            ie(e) ? Jl(n) && s.push(o.get("length")) : (s.push(o.get(Yn)), gr(e) && s.push(o.get(As)));
            break;
        case "delete":
            ie(e) || (s.push(o.get(Yn)), gr(e) && s.push(o.get(As)));
            break;
        case "set":
            gr(e) && s.push(o.get(Yn));
            break
    }
    if (s.length === 1) s[0] && Ls(s[0]);
    else {
        const l = [];
        for (const c of s) c && l.push(...c);
        Ls(Wl(l))
    }
}

function Ls(e, t) {
    const n = ie(e) ? e : [...e];
    for (const r of n) r.computed && uu(r);
    for (const r of n) r.computed || uu(r)
}

function uu(e, t) {
    (e !== Rt || e.allowRecurse) && (e.scheduler ? e.scheduler() : e.run())
}

function Vy(e, t) {
    var n;
    return (n = Di.get(e)) == null ? void 0 : n.get(t)
}
const Hy = io("__proto__,__v_isRef,__isVue"),
    Ep = new Set(Object.getOwnPropertyNames(Symbol).filter(e => e !== "arguments" && e !== "caller").map(e => Symbol[e]).filter(Dr)),
    fu = Ky();

function Ky() {
    const e = {};
    return ["includes", "indexOf", "lastIndexOf"].forEach(t => {
        e[t] = function(...n) {
            const r = he(this);
            for (let i = 0, o = this.length; i < o; i++) dt(r, "get", i + "");
            const a = r[t](...n);
            return a === -1 || a === !1 ? r[t](...n.map(he)) : a
        }
    }), ["push", "pop", "shift", "unshift", "splice"].forEach(t => {
        e[t] = function(...n) {
            Fr();
            const r = he(this)[t].apply(this, n);
            return Br(), r
        }
    }), e
}

function Uy(e) {
    const t = he(this);
    return dt(t, "has", e), t.hasOwnProperty(e)
}
class Cp {
    constructor(t = !1, n = !1) {
        this._isReadonly = t, this._shallow = n
    }
    get(t, n, r) {
        const a = this._isReadonly,
            i = this._shallow;
        if (n === "__v_isReactive") return !a;
        if (n === "__v_isReadonly") return a;
        if (n === "__v_isShallow") return i;
        if (n === "__v_raw") return r === (a ? i ? rb : Tp : i ? Sp : Lp).get(t) || Object.getPrototypeOf(t) === Object.getPrototypeOf(r) ? t : void 0;
        const o = ie(t);
        if (!a) {
            if (o && ye(fu, n)) return Reflect.get(fu, n, r);
            if (n === "hasOwnProperty") return Uy
        }
        const s = Reflect.get(t, n, r);
        return (Dr(n) ? Ep.has(n) : Hy(n)) || (a || dt(t, "get", n), i) ? s : _e(s) ? o && Jl(n) ? s : s.value : Te(s) ? a ? Ka(s) : tt(s) : s
    }
}
class Ap extends Cp {
    constructor(t = !1) {
        super(!1, t)
    }
    set(t, n, r, a) {
        let i = t[n];
        if (tr(i) && _e(i) && !_e(r)) return !1;
        if (!this._shallow && (!Ni(r) && !tr(r) && (i = he(i), r = he(r)), !ie(t) && _e(i) && !_e(r))) return i.value = r, !0;
        const o = ie(t) && Jl(n) ? Number(n) < t.length : ye(t, n),
            s = Reflect.set(t, n, r, a);
        return t === he(a) && (o ? Zn(r, i) && Zt(t, "set", n, r) : Zt(t, "add", n, r)), s
    }
    deleteProperty(t, n) {
        const r = ye(t, n);
        t[n];
        const a = Reflect.deleteProperty(t, n);
        return a && r && Zt(t, "delete", n, void 0), a
    }
    has(t, n) {
        const r = Reflect.has(t, n);
        return (!Dr(n) || !Ep.has(n)) && dt(t, "has", n), r
    }
    ownKeys(t) {
        return dt(t, "iterate", ie(t) ? "length" : Yn), Reflect.ownKeys(t)
    }
}
class Jy extends Cp {
    constructor(t = !1) {
        super(!0, t)
    }
    set(t, n) {
        return !0
    }
    deleteProperty(t, n) {
        return !0
    }
}
const Gy = new Ap,
    Wy = new Jy,
    zy = new Ap(!0),
    ql = e => e,
    co = e => Reflect.getPrototypeOf(e);

function ri(e, t, n = !1, r = !1) {
    e = e.__v_raw;
    const a = he(e),
        i = he(t);
    n || (Zn(t, i) && dt(a, "get", t), dt(a, "get", i));
    const {
        has: o
    } = co(a), s = r ? ql : n ? Ql : _a;
    if (o.call(a, t)) return s(e.get(t));
    if (o.call(a, i)) return s(e.get(i));
    e !== a && e.get(t)
}

function ai(e, t = !1) {
    const n = this.__v_raw,
        r = he(n),
        a = he(e);
    return t || (Zn(e, a) && dt(r, "has", e), dt(r, "has", a)), e === a ? n.has(e) : n.has(e) || n.has(a)
}

function ii(e, t = !1) {
    return e = e.__v_raw, !t && dt(he(e), "iterate", Yn), Reflect.get(e, "size", e)
}

function du(e) {
    e = he(e);
    const t = he(this);
    return co(t).has.call(t, e) || (t.add(e), Zt(t, "add", e, e)), this
}

function pu(e, t) {
    t = he(t);
    const n = he(this),
        {
            has: r,
            get: a
        } = co(n);
    let i = r.call(n, e);
    i || (e = he(e), i = r.call(n, e));
    const o = a.call(n, e);
    return n.set(e, t), i ? Zn(t, o) && Zt(n, "set", e, t) : Zt(n, "add", e, t), this
}

function hu(e) {
    const t = he(this),
        {
            has: n,
            get: r
        } = co(t);
    let a = n.call(t, e);
    a || (e = he(e), a = n.call(t, e)), r && r.call(t, e);
    const i = t.delete(e);
    return a && Zt(t, "delete", e, void 0), i
}

function mu() {
    const e = he(this),
        t = e.size !== 0,
        n = e.clear();
    return t && Zt(e, "clear", void 0, void 0), n
}

function oi(e, t) {
    return function(r, a) {
        const i = this,
            o = i.__v_raw,
            s = he(o),
            l = t ? ql : e ? Ql : _a;
        return !e && dt(s, "iterate", Yn), o.forEach((c, u) => r.call(a, l(c), l(u), i))
    }
}

function si(e, t, n) {
    return function(...r) {
        const a = this.__v_raw,
            i = he(a),
            o = gr(i),
            s = e === "entries" || e === Symbol.iterator && o,
            l = e === "keys" && o,
            c = a[e](...r),
            u = n ? ql : t ? Ql : _a;
        return !t && dt(i, "iterate", l ? As : Yn), {
            next() {
                const {
                    value: f,
                    done: d
                } = c.next();
                return d ? {
                    value: f,
                    done: d
                } : {
                    value: s ? [u(f[0]), u(f[1])] : u(f),
                    done: d
                }
            },
            [Symbol.iterator]() {
                return this
            }
        }
    }
}

function an(e) {
    return function(...t) {
        return e === "delete" ? !1 : e === "clear" ? void 0 : this
    }
}

function qy() {
    const e = {
            get(i) {
                return ri(this, i)
            },
            get size() {
                return ii(this)
            },
            has: ai,
            add: du,
            set: pu,
            delete: hu,
            clear: mu,
            forEach: oi(!1, !1)
        },
        t = {
            get(i) {
                return ri(this, i, !1, !0)
            },
            get size() {
                return ii(this)
            },
            has: ai,
            add: du,
            set: pu,
            delete: hu,
            clear: mu,
            forEach: oi(!1, !0)
        },
        n = {
            get(i) {
                return ri(this, i, !0)
            },
            get size() {
                return ii(this, !0)
            },
            has(i) {
                return ai.call(this, i, !0)
            },
            add: an("add"),
            set: an("set"),
            delete: an("delete"),
            clear: an("clear"),
            forEach: oi(!0, !1)
        },
        r = {
            get(i) {
                return ri(this, i, !0, !0)
            },
            get size() {
                return ii(this, !0)
            },
            has(i) {
                return ai.call(this, i, !0)
            },
            add: an("add"),
            set: an("set"),
            delete: an("delete"),
            clear: an("clear"),
            forEach: oi(!0, !0)
        };
    return ["keys", "values", "entries", Symbol.iterator].forEach(i => {
        e[i] = si(i, !1, !1), n[i] = si(i, !0, !1), t[i] = si(i, !1, !0), r[i] = si(i, !0, !0)
    }), [e, n, t, r]
}
const [Yy, Xy, Qy, Zy] = qy();

function Yl(e, t) {
    const n = t ? e ? Zy : Qy : e ? Xy : Yy;
    return (r, a, i) => a === "__v_isReactive" ? !e : a === "__v_isReadonly" ? e : a === "__v_raw" ? r : Reflect.get(ye(n, a) && a in r ? n : r, a, i)
}
const eb = {
        get: Yl(!1, !1)
    },
    tb = {
        get: Yl(!1, !0)
    },
    nb = {
        get: Yl(!0, !1)
    },
    Lp = new WeakMap,
    Sp = new WeakMap,
    Tp = new WeakMap,
    rb = new WeakMap;

function ab(e) {
    switch (e) {
        case "Object":
        case "Array":
            return 1;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2;
        default:
            return 0
    }
}

function ib(e) {
    return e.__v_skip || !Object.isExtensible(e) ? 0 : ab(Sy(e))
}

function tt(e) {
    return tr(e) ? e : Xl(e, !1, Gy, eb, Lp)
}

function Ha(e) {
    return Xl(e, !1, zy, tb, Sp)
}

function Ka(e) {
    return Xl(e, !0, Wy, nb, Tp)
}

function Xl(e, t, n, r, a) {
    if (!Te(e) || e.__v_raw && !(t && e.__v_isReactive)) return e;
    const i = a.get(e);
    if (i) return i;
    const o = ib(e);
    if (o === 0) return e;
    const s = new Proxy(e, o === 2 ? r : n);
    return a.set(e, s), s
}

function en(e) {
    return tr(e) ? en(e.__v_raw) : !!(e && e.__v_isReactive)
}

function tr(e) {
    return !!(e && e.__v_isReadonly)
}

function Ni(e) {
    return !!(e && e.__v_isShallow)
}

function kp(e) {
    return en(e) || tr(e)
}

function he(e) {
    const t = e && e.__v_raw;
    return t ? he(t) : e
}

function uo(e) {
    return Ii(e, "__v_skip", !0), e
}
const _a = e => Te(e) ? tt(e) : e,
    Ql = e => Te(e) ? Ka(e) : e;

function Zl(e) {
    _n && Rt && (e = he(e), wp(e.dep || (e.dep = Wl())))
}

function ec(e, t) {
    e = he(e);
    const n = e.dep;
    n && Ls(n)
}

function _e(e) {
    return !!(e && e.__v_isRef === !0)
}

function Q(e) {
    return Rp(e, !1)
}

function Er(e) {
    return Rp(e, !0)
}

function Rp(e, t) {
    return _e(e) ? e : new ob(e, t)
}
class ob {
    constructor(t, n) {
        this.__v_isShallow = n, this.dep = void 0, this.__v_isRef = !0, this._rawValue = n ? t : he(t), this._value = n ? t : _a(t)
    }
    get value() {
        return Zl(this), this._value
    }
    set value(t) {
        const n = this.__v_isShallow || Ni(t) || tr(t);
        t = n ? t : he(t), Zn(t, this._rawValue) && (this._rawValue = t, this._value = n ? t : _a(t), ec(this))
    }
}

function pe(e) {
    return _e(e) ? e.value : e
}

function Jo(e) {
    return se(e) ? e() : pe(e)
}
const sb = {
    get: (e, t, n) => pe(Reflect.get(e, t, n)),
    set: (e, t, n, r) => {
        const a = e[t];
        return _e(a) && !_e(n) ? (a.value = n, !0) : Reflect.set(e, t, n, r)
    }
};

function Op(e) {
    return en(e) ? e : new Proxy(e, sb)
}
class lb {
    constructor(t) {
        this.dep = void 0, this.__v_isRef = !0;
        const {
            get: n,
            set: r
        } = t(() => Zl(this), () => ec(this));
        this._get = n, this._set = r
    }
    get value() {
        return this._get()
    }
    set value(t) {
        this._set(t)
    }
}

function cb(e) {
    return new lb(e)
}

function ub(e) {
    const t = ie(e) ? new Array(e.length) : {};
    for (const n in e) t[n] = Mp(e, n);
    return t
}
class fb {
    constructor(t, n, r) {
        this._object = t, this._key = n, this._defaultValue = r, this.__v_isRef = !0
    }
    get value() {
        const t = this._object[this._key];
        return t === void 0 ? this._defaultValue : t
    }
    set value(t) {
        this._object[this._key] = t
    }
    get dep() {
        return Vy(he(this._object), this._key)
    }
}
class db {
    constructor(t) {
        this._getter = t, this.__v_isRef = !0, this.__v_isReadonly = !0
    }
    get value() {
        return this._getter()
    }
}

function ir(e, t, n) {
    return _e(e) ? e : se(e) ? new db(e) : Te(e) && arguments.length > 1 ? Mp(e, t, n) : Q(e)
}

function Mp(e, t, n) {
    const r = e[t];
    return _e(r) ? r : new fb(e, t, n)
}
class pb {
    constructor(t, n, r, a) {
        this._setter = n, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this._dirty = !0, this.effect = new zl(t, () => {
            this._dirty || (this._dirty = !0, ec(this))
        }), this.effect.computed = this, this.effect.active = this._cacheable = !a, this.__v_isReadonly = r
    }
    get value() {
        const t = he(this);
        return Zl(t), (t._dirty || !t._cacheable) && (t._dirty = !1, t._value = t.effect.run()), t._value
    }
    set value(t) {
        this._setter(t)
    }
}

function hb(e, t, n = !1) {
    let r, a;
    const i = se(e);
    return i ? (r = e, a = Pt) : (r = e.get, a = e.set), new pb(r, a, i || !a, n)
}

function wn(e, t, n, r) {
    let a;
    try {
        a = r ? e(...r) : e()
    } catch (i) {
        jr(i, t, n)
    }
    return a
}

function Ct(e, t, n, r) {
    if (se(e)) {
        const i = wn(e, t, n, r);
        return i && Ul(i) && i.catch(o => {
            jr(o, t, n)
        }), i
    }
    const a = [];
    for (let i = 0; i < e.length; i++) a.push(Ct(e[i], t, n, r));
    return a
}

function jr(e, t, n, r = !0) {
    const a = t ? t.vnode : null;
    if (t) {
        let i = t.parent;
        const o = t.proxy,
            s = n;
        for (; i;) {
            const c = i.ec;
            if (c) {
                for (let u = 0; u < c.length; u++)
                    if (c[u](e, o, s) === !1) return
            }
            i = i.parent
        }
        const l = t.appContext.config.errorHandler;
        if (l) {
            wn(l, null, 10, [e, o, s]);
            return
        }
    }
    mb(e, n, a, r)
}

function mb(e, t, n, r = !0) {
    console.error(e)
}
let wa = !1,
    Ss = !1;
const et = [];
let Vt = 0;
const yr = [];
let Yt = null,
    Kn = 0;
const Pp = Promise.resolve();
let tc = null;

function St(e) {
    const t = tc || Pp;
    return e ? t.then(this ? e.bind(this) : e) : t
}

function gb(e) {
    let t = Vt + 1,
        n = et.length;
    for (; t < n;) {
        const r = t + n >>> 1,
            a = et[r],
            i = Ea(a);
        i < e || i === e && a.pre ? t = r + 1 : n = r
    }
    return t
}

function fo(e) {
    (!et.length || !et.includes(e, wa && e.allowRecurse ? Vt + 1 : Vt)) && (e.id == null ? et.push(e) : et.splice(gb(e.id), 0, e), xp())
}

function xp() {
    !wa && !Ss && (Ss = !0, tc = Pp.then(Ip))
}

function yb(e) {
    const t = et.indexOf(e);
    t > Vt && et.splice(t, 1)
}

function Ts(e) {
    ie(e) ? yr.push(...e) : (!Yt || !Yt.includes(e, e.allowRecurse ? Kn + 1 : Kn)) && yr.push(e), xp()
}

function gu(e, t, n = wa ? Vt + 1 : 0) {
    for (; n < et.length; n++) {
        const r = et[n];
        if (r && r.pre) {
            if (e && r.id !== e.uid) continue;
            et.splice(n, 1), n--, r()
        }
    }
}

function Fi(e) {
    if (yr.length) {
        const t = [...new Set(yr)];
        if (yr.length = 0, Yt) {
            Yt.push(...t);
            return
        }
        for (Yt = t, Yt.sort((n, r) => Ea(n) - Ea(r)), Kn = 0; Kn < Yt.length; Kn++) Yt[Kn]();
        Yt = null, Kn = 0
    }
}
const Ea = e => e.id == null ? 1 / 0 : e.id,
    bb = (e, t) => {
        const n = Ea(e) - Ea(t);
        if (n === 0) {
            if (e.pre && !t.pre) return -1;
            if (t.pre && !e.pre) return 1
        }
        return n
    };

function Ip(e) {
    Ss = !1, wa = !0, et.sort(bb);
    const t = Pt;
    try {
        for (Vt = 0; Vt < et.length; Vt++) {
            const n = et[Vt];
            n && n.active !== !1 && wn(n, null, 14)
        }
    } finally {
        Vt = 0, et.length = 0, Fi(), wa = !1, tc = null, (et.length || yr.length) && Ip()
    }
}

function vb(e, t, ...n) {
    if (e.isUnmounted) return;
    const r = e.vnode.props || Oe;
    let a = n;
    const i = t.startsWith("update:"),
        o = i && t.slice(7);
    if (o && o in r) {
        const u = `${o==="modelValue"?"model":o}Modifiers`,
            {
                number: f,
                trim: d
            } = r[u] || Oe;
        d && (a = n.map(p => xe(p) ? p.trim() : p)), f && (a = n.map(Ry))
    }
    let s, l = r[s = Ko(t)] || r[s = Ko(Ut(t))];
    !l && i && (l = r[s = Ko(ar(t))]), l && Ct(l, e, 6, a);
    const c = r[s + "Once"];
    if (c) {
        if (!e.emitted) e.emitted = {};
        else if (e.emitted[s]) return;
        e.emitted[s] = !0, Ct(c, e, 6, a)
    }
}

function Dp(e, t, n = !1) {
    const r = t.emitsCache,
        a = r.get(e);
    if (a !== void 0) return a;
    const i = e.emits;
    let o = {},
        s = !1;
    if (!se(e)) {
        const l = c => {
            const u = Dp(c, t, !0);
            u && (s = !0, Ge(o, u))
        };
        !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l)
    }
    return !i && !s ? (Te(e) && r.set(e, null), null) : (ie(i) ? i.forEach(l => o[l] = null) : Ge(o, i), Te(e) && r.set(e, o), o)
}

function po(e, t) {
    return !e || !ja(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ye(e, t[0].toLowerCase() + t.slice(1)) || ye(e, ar(t)) || ye(e, t))
}
let qe = null,
    ho = null;

function Bi(e) {
    const t = qe;
    return qe = e, ho = e && e.type.__scopeId || null, t
}

function gP(e) {
    ho = e
}

function yP() {
    ho = null
}

function Sn(e, t = qe, n) {
    if (!t || e._n) return e;
    const r = (...a) => {
        r._d && Ou(-1);
        const i = Bi(t);
        let o;
        try {
            o = e(...a)
        } finally {
            Bi(i), r._d && Ou(1)
        }
        return o
    };
    return r._n = !0, r._c = !0, r._d = !0, r
}

function Go(e) {
    const {
        type: t,
        vnode: n,
        proxy: r,
        withProxy: a,
        props: i,
        propsOptions: [o],
        slots: s,
        attrs: l,
        emit: c,
        render: u,
        renderCache: f,
        data: d,
        setupState: p,
        ctx: v,
        inheritAttrs: E
    } = e;
    let w, h;
    const b = Bi(e);
    try {
        if (n.shapeFlag & 4) {
            const y = a || r,
                C = y;
            w = vt(u.call(C, y, f, i, p, d, v)), h = l
        } else {
            const y = t;
            w = vt(y.length > 1 ? y(i, {
                attrs: l,
                slots: s,
                emit: c
            }) : y(i, null)), h = t.props ? l : wb(l)
        }
    } catch (y) {
        ca.length = 0, jr(y, e, 1), w = Ae(ot)
    }
    let m = w;
    if (h && E !== !1) {
        const y = Object.keys(h),
            {
                shapeFlag: C
            } = m;
        y.length && C & 7 && (o && y.some(Hl) && (h = Eb(h, o)), m = tn(m, h))
    }
    return n.dirs && (m = tn(m), m.dirs = m.dirs ? m.dirs.concat(n.dirs) : n.dirs), n.transition && (m.transition = n.transition), w = m, Bi(b), w
}

function _b(e) {
    let t;
    for (let n = 0; n < e.length; n++) {
        const r = e[n];
        if (Ar(r)) {
            if (r.type !== ot || r.children === "v-if") {
                if (t) return;
                t = r
            }
        } else return
    }
    return t
}
const wb = e => {
        let t;
        for (const n in e)(n === "class" || n === "style" || ja(n)) && ((t || (t = {}))[n] = e[n]);
        return t
    },
    Eb = (e, t) => {
        const n = {};
        for (const r in e)(!Hl(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
        return n
    };

function Cb(e, t, n) {
    const {
        props: r,
        children: a,
        component: i
    } = e, {
        props: o,
        children: s,
        patchFlag: l
    } = t, c = i.emitsOptions;
    if (t.dirs || t.transition) return !0;
    if (n && l >= 0) {
        if (l & 1024) return !0;
        if (l & 16) return r ? yu(r, o, c) : !!o;
        if (l & 8) {
            const u = t.dynamicProps;
            for (let f = 0; f < u.length; f++) {
                const d = u[f];
                if (o[d] !== r[d] && !po(c, d)) return !0
            }
        }
    } else return (a || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? o ? yu(r, o, c) : !0 : !!o;
    return !1
}

function yu(e, t, n) {
    const r = Object.keys(t);
    if (r.length !== Object.keys(e).length) return !0;
    for (let a = 0; a < r.length; a++) {
        const i = r[a];
        if (t[i] !== e[i] && !po(n, i)) return !0
    }
    return !1
}

function nc({
    vnode: e,
    parent: t
}, n) {
    for (; t && t.subTree === e;)(e = t.vnode).el = n, t = t.parent
}
const rc = "components",
    Ab = "directives";

function Np(e, t) {
    return ic(rc, e, !0, t) || e
}
const Fp = Symbol.for("v-ndc");

function ac(e) {
    return xe(e) ? ic(rc, e, !1) || e : e || Fp
}

function bP(e) {
    return ic(Ab, e)
}

function ic(e, t, n = !0, r = !1) {
    const a = qe || Ve;
    if (a) {
        const i = a.type;
        if (e === rc) {
            const s = Ds(i, !1);
            if (s && (s === t || s === Ut(t) || s === so(Ut(t)))) return i
        }
        const o = bu(a[e] || i[e], t) || bu(a.appContext[e], t);
        return !o && r ? i : o
    }
}

function bu(e, t) {
    return e && (e[t] || e[Ut(t)] || e[so(Ut(t))])
}
const Bp = e => e.__isSuspense,
    Lb = {
        name: "Suspense",
        __isSuspense: !0,
        process(e, t, n, r, a, i, o, s, l, c) {
            e == null ? Sb(t, n, r, a, i, o, s, l, c) : Tb(e, t, n, r, a, o, s, l, c)
        },
        hydrate: kb,
        create: sc,
        normalize: Rb
    },
    oc = Lb;

function Ca(e, t) {
    const n = e.props && e.props[t];
    se(n) && n()
}

function Sb(e, t, n, r, a, i, o, s, l) {
    const {
        p: c,
        o: {
            createElement: u
        }
    } = l, f = u("div"), d = e.suspense = sc(e, a, r, t, f, n, i, o, s, l);
    c(null, d.pendingBranch = e.ssContent, f, null, r, d, i, o), d.deps > 0 ? (Ca(e, "onPending"), Ca(e, "onFallback"), c(null, e.ssFallback, t, n, r, null, i, o), br(d, e.ssFallback)) : d.resolve(!1, !0)
}

function Tb(e, t, n, r, a, i, o, s, {
    p: l,
    um: c,
    o: {
        createElement: u
    }
}) {
    const f = t.suspense = e.suspense;
    f.vnode = t, t.el = e.el;
    const d = t.ssContent,
        p = t.ssFallback,
        {
            activeBranch: v,
            pendingBranch: E,
            isInFallback: w,
            isHydrating: h
        } = f;
    if (E) f.pendingBranch = d, Ot(d, E) ? (l(E, d, f.hiddenContainer, null, a, f, i, o, s), f.deps <= 0 ? f.resolve() : w && (l(v, p, n, r, a, null, i, o, s), br(f, p))) : (f.pendingId++, h ? (f.isHydrating = !1, f.activeBranch = E) : c(E, a, f), f.deps = 0, f.effects.length = 0, f.hiddenContainer = u("div"), w ? (l(null, d, f.hiddenContainer, null, a, f, i, o, s), f.deps <= 0 ? f.resolve() : (l(v, p, n, r, a, null, i, o, s), br(f, p))) : v && Ot(d, v) ? (l(v, d, n, r, a, f, i, o, s), f.resolve(!0)) : (l(null, d, f.hiddenContainer, null, a, f, i, o, s), f.deps <= 0 && f.resolve()));
    else if (v && Ot(d, v)) l(v, d, n, r, a, f, i, o, s), br(f, d);
    else if (Ca(t, "onPending"), f.pendingBranch = d, f.pendingId++, l(null, d, f.hiddenContainer, null, a, f, i, o, s), f.deps <= 0) f.resolve();
    else {
        const {
            timeout: b,
            pendingId: m
        } = f;
        b > 0 ? setTimeout(() => {
            f.pendingId === m && f.fallback(p)
        }, b) : b === 0 && f.fallback(p)
    }
}

function sc(e, t, n, r, a, i, o, s, l, c, u = !1) {
    const {
        p: f,
        m: d,
        um: p,
        n: v,
        o: {
            parentNode: E,
            remove: w
        }
    } = c;
    let h;
    const b = Ob(e);
    b && t != null && t.pendingBranch && (h = t.pendingId, t.deps++);
    const m = e.props ? hp(e.props.timeout) : void 0,
        y = {
            vnode: e,
            parent: t,
            parentComponent: n,
            isSVG: o,
            container: r,
            hiddenContainer: a,
            anchor: i,
            deps: 0,
            pendingId: 0,
            timeout: typeof m == "number" ? m : -1,
            activeBranch: null,
            pendingBranch: null,
            isInFallback: !0,
            isHydrating: u,
            isUnmounted: !1,
            effects: [],
            resolve(C = !1, S = !1) {
                const {
                    vnode: A,
                    activeBranch: R,
                    pendingBranch: O,
                    pendingId: N,
                    effects: x,
                    parentComponent: M,
                    container: K
                } = y;
                let ne = !1;
                if (y.isHydrating) y.isHydrating = !1;
                else if (!C) {
                    ne = R && O.transition && O.transition.mode === "out-in", ne && (R.transition.afterLeave = () => {
                        N === y.pendingId && (d(O, K, v(R), 0), Ts(x))
                    });
                    let {
                        anchor: ae
                    } = y;
                    R && (ae = v(R), p(R, M, y, !0)), ne || d(O, K, ae, 0)
                }
                br(y, O), y.pendingBranch = null, y.isInFallback = !1;
                let te = y.parent,
                    J = !1;
                for (; te;) {
                    if (te.pendingBranch) {
                        te.effects.push(...x), J = !0;
                        break
                    }
                    te = te.parent
                }!J && !ne && Ts(x), y.effects = [], b && t && t.pendingBranch && h === t.pendingId && (t.deps--, t.deps === 0 && !S && t.resolve()), Ca(A, "onResolve")
            },
            fallback(C) {
                if (!y.pendingBranch) return;
                const {
                    vnode: S,
                    activeBranch: A,
                    parentComponent: R,
                    container: O,
                    isSVG: N
                } = y;
                Ca(S, "onFallback");
                const x = v(A),
                    M = () => {
                        y.isInFallback && (f(null, C, O, x, R, null, N, s, l), br(y, C))
                    },
                    K = C.transition && C.transition.mode === "out-in";
                K && (A.transition.afterLeave = M), y.isInFallback = !0, p(A, R, null, !0), K || M()
            },
            move(C, S, A) {
                y.activeBranch && d(y.activeBranch, C, S, A), y.container = C
            },
            next() {
                return y.activeBranch && v(y.activeBranch)
            },
            registerDep(C, S) {
                const A = !!y.pendingBranch;
                A && y.deps++;
                const R = C.vnode.el;
                C.asyncDep.catch(O => {
                    jr(O, C, 0)
                }).then(O => {
                    if (C.isUnmounted || y.isUnmounted || y.pendingId !== C.suspenseId) return;
                    C.asyncResolved = !0;
                    const {
                        vnode: N
                    } = C;
                    Is(C, O, !1), R && (N.el = R);
                    const x = !R && C.subTree.el;
                    S(C, N, E(R || C.subTree.el), R ? null : v(C.subTree), y, o, l), x && w(x), nc(C, N.el), A && --y.deps === 0 && y.resolve()
                })
            },
            unmount(C, S) {
                y.isUnmounted = !0, y.activeBranch && p(y.activeBranch, n, C, S), y.pendingBranch && p(y.pendingBranch, n, C, S)
            }
        };
    return y
}

function kb(e, t, n, r, a, i, o, s, l) {
    const c = t.suspense = sc(t, r, n, e.parentNode, document.createElement("div"), null, a, i, o, s, !0),
        u = l(e, c.pendingBranch = t.ssContent, n, c, i, o);
    return c.deps === 0 && c.resolve(!1, !0), u
}

function Rb(e) {
    const {
        shapeFlag: t,
        children: n
    } = e, r = t & 32;
    e.ssContent = vu(r ? n.default : n), e.ssFallback = r ? vu(n.fallback) : Ae(ot)
}

function vu(e) {
    let t;
    if (se(e)) {
        const n = Cr && e._c;
        n && (e._d = !1, le()), e = e(), n && (e._d = !0, t = wt, oh())
    }
    return ie(e) && (e = _b(e)), e = vt(e), t && !e.dynamicChildren && (e.dynamicChildren = t.filter(n => n !== e)), e
}

function jp(e, t) {
    t && t.pendingBranch ? ie(e) ? t.effects.push(...e) : t.effects.push(e) : Ts(e)
}

function br(e, t) {
    e.activeBranch = t;
    const {
        vnode: n,
        parentComponent: r
    } = e, a = n.el = t.el;
    r && r.subTree === n && (r.vnode.el = a, nc(r, a))
}

function Ob(e) {
    var t;
    return ((t = e.props) == null ? void 0 : t.suspensible) != null && e.props.suspensible !== !1
}

function lc(e, t) {
    return mo(e, null, t)
}

function Mb(e, t) {
    return mo(e, null, {
        flush: "post"
    })
}
const li = {};

function we(e, t, n) {
    return mo(e, t, n)
}

function mo(e, t, {
    immediate: n,
    deep: r,
    flush: a,
    onTrack: i,
    onTrigger: o
} = Oe) {
    var s;
    const l = Nr() === ((s = Ve) == null ? void 0 : s.scope) ? Ve : null;
    let c, u = !1,
        f = !1;
    if (_e(e) ? (c = () => e.value, u = Ni(e)) : en(e) ? (c = () => e, r = !0) : ie(e) ? (f = !0, u = e.some(y => en(y) || Ni(y)), c = () => e.map(y => {
            if (_e(y)) return y.value;
            if (en(y)) return Jn(y);
            if (se(y)) return wn(y, l, 2)
        })) : se(e) ? t ? c = () => wn(e, l, 2) : c = () => {
            if (!(l && l.isUnmounted)) return d && d(), Ct(e, l, 3, [p])
        } : c = Pt, t && r) {
        const y = c;
        c = () => Jn(y())
    }
    let d, p = y => {
            d = b.onStop = () => {
                wn(y, l, 4), d = b.onStop = void 0
            }
        },
        v;
    if (Lr)
        if (p = Pt, t ? n && Ct(t, l, 3, [c(), f ? [] : void 0, p]) : c(), a === "sync") {
            const y = Av();
            v = y.__watcherHandles || (y.__watcherHandles = [])
        } else return Pt;
    let E = f ? new Array(e.length).fill(li) : li;
    const w = () => {
        if (b.active)
            if (t) {
                const y = b.run();
                (r || u || (f ? y.some((C, S) => Zn(C, E[S])) : Zn(y, E))) && (d && d(), Ct(t, l, 3, [y, E === li ? void 0 : f && E[0] === li ? [] : E, p]), E = y)
            } else b.run()
    };
    w.allowRecurse = !!t;
    let h;
    a === "sync" ? h = w : a === "post" ? h = () => Xe(w, l && l.suspense) : (w.pre = !0, l && (w.id = l.uid), h = () => fo(w));
    const b = new zl(c, h);
    t ? n ? w() : E = b.run() : a === "post" ? Xe(b.run.bind(b), l && l.suspense) : b.run();
    const m = () => {
        b.stop(), l && l.scope && Kl(l.scope.effects, b)
    };
    return v && v.push(m), m
}

function Pb(e, t, n) {
    const r = this.proxy,
        a = xe(e) ? e.includes(".") ? $p(r, e) : () => r[e] : e.bind(r, r);
    let i;
    se(t) ? i = t : (i = t.handler, n = t);
    const o = Ve;
    Tn(this);
    const s = mo(a, i.bind(r), n);
    return o ? Tn(o) : En(), s
}

function $p(e, t) {
    const n = t.split(".");
    return () => {
        let r = e;
        for (let a = 0; a < n.length && r; a++) r = r[n[a]];
        return r
    }
}

function Jn(e, t) {
    if (!Te(e) || e.__v_skip || (t = t || new Set, t.has(e))) return e;
    if (t.add(e), _e(e)) Jn(e.value, t);
    else if (ie(e))
        for (let n = 0; n < e.length; n++) Jn(e[n], t);
    else if (fp(e) || gr(e)) e.forEach(n => {
        Jn(n, t)
    });
    else if (pp(e))
        for (const n in e) Jn(e[n], t);
    return e
}

function vP(e, t) {
    const n = qe;
    if (n === null) return e;
    const r = vo(n) || n.proxy,
        a = e.dirs || (e.dirs = []);
    for (let i = 0; i < t.length; i++) {
        let [o, s, l, c = Oe] = t[i];
        o && (se(o) && (o = {
            mounted: o,
            updated: o
        }), o.deep && Jn(s), a.push({
            dir: o,
            instance: r,
            value: s,
            oldValue: void 0,
            arg: l,
            modifiers: c
        }))
    }
    return e
}

function $t(e, t, n, r) {
    const a = e.dirs,
        i = t && t.dirs;
    for (let o = 0; o < a.length; o++) {
        const s = a[o];
        i && (s.oldValue = i[o].value);
        let l = s.dir[r];
        l && (Fr(), Ct(l, n, 8, [e.el, s, e, t]), Br())
    }
}
const hn = Symbol("_leaveCb"),
    ci = Symbol("_enterCb");

function xb() {
    const e = {
        isMounted: !1,
        isLeaving: !1,
        isUnmounting: !1,
        leavingVNodes: new Map
    };
    return Jt(() => {
        e.isMounted = !0
    }), Ja(() => {
        e.isUnmounting = !0
    }), e
}
const bt = [Function, Array],
    Vp = {
        mode: String,
        appear: Boolean,
        persisted: Boolean,
        onBeforeEnter: bt,
        onEnter: bt,
        onAfterEnter: bt,
        onEnterCancelled: bt,
        onBeforeLeave: bt,
        onLeave: bt,
        onAfterLeave: bt,
        onLeaveCancelled: bt,
        onBeforeAppear: bt,
        onAppear: bt,
        onAfterAppear: bt,
        onAppearCancelled: bt
    },
    Ib = {
        name: "BaseTransition",
        props: Vp,
        setup(e, {
            slots: t
        }) {
            const n = yt(),
                r = xb();
            let a;
            return () => {
                const i = t.default && Kp(t.default(), !0);
                if (!i || !i.length) return;
                let o = i[0];
                if (i.length > 1) {
                    for (const E of i)
                        if (E.type !== ot) {
                            o = E;
                            break
                        }
                }
                const s = he(e),
                    {
                        mode: l
                    } = s;
                if (r.isLeaving) return Wo(o);
                const c = _u(o);
                if (!c) return Wo(o);
                const u = ks(c, s, r, n);
                ji(c, u);
                const f = n.subTree,
                    d = f && _u(f);
                let p = !1;
                const {
                    getTransitionKey: v
                } = c.type;
                if (v) {
                    const E = v();
                    a === void 0 ? a = E : E !== a && (a = E, p = !0)
                }
                if (d && d.type !== ot && (!Ot(c, d) || p)) {
                    const E = ks(d, s, r, n);
                    if (ji(d, E), l === "out-in") return r.isLeaving = !0, E.afterLeave = () => {
                        r.isLeaving = !1, n.update.active !== !1 && n.update()
                    }, Wo(o);
                    l === "in-out" && c.type !== ot && (E.delayLeave = (w, h, b) => {
                        const m = Hp(r, d);
                        m[String(d.key)] = d, w[hn] = () => {
                            h(), w[hn] = void 0, delete u.delayedLeave
                        }, u.delayedLeave = b
                    })
                }
                return o
            }
        }
    },
    Db = Ib;

function Hp(e, t) {
    const {
        leavingVNodes: n
    } = e;
    let r = n.get(t.type);
    return r || (r = Object.create(null), n.set(t.type, r)), r
}

function ks(e, t, n, r) {
    const {
        appear: a,
        mode: i,
        persisted: o = !1,
        onBeforeEnter: s,
        onEnter: l,
        onAfterEnter: c,
        onEnterCancelled: u,
        onBeforeLeave: f,
        onLeave: d,
        onAfterLeave: p,
        onLeaveCancelled: v,
        onBeforeAppear: E,
        onAppear: w,
        onAfterAppear: h,
        onAppearCancelled: b
    } = t, m = String(e.key), y = Hp(n, e), C = (R, O) => {
        R && Ct(R, r, 9, O)
    }, S = (R, O) => {
        const N = O[1];
        C(R, O), ie(R) ? R.every(x => x.length <= 1) && N() : R.length <= 1 && N()
    }, A = {
        mode: i,
        persisted: o,
        beforeEnter(R) {
            let O = s;
            if (!n.isMounted)
                if (a) O = E || s;
                else return;
            R[hn] && R[hn](!0);
            const N = y[m];
            N && Ot(e, N) && N.el[hn] && N.el[hn](), C(O, [R])
        },
        enter(R) {
            let O = l,
                N = c,
                x = u;
            if (!n.isMounted)
                if (a) O = w || l, N = h || c, x = b || u;
                else return;
            let M = !1;
            const K = R[ci] = ne => {
                M || (M = !0, ne ? C(x, [R]) : C(N, [R]), A.delayedLeave && A.delayedLeave(), R[ci] = void 0)
            };
            O ? S(O, [R, K]) : K()
        },
        leave(R, O) {
            const N = String(e.key);
            if (R[ci] && R[ci](!0), n.isUnmounting) return O();
            C(f, [R]);
            let x = !1;
            const M = R[hn] = K => {
                x || (x = !0, O(), K ? C(v, [R]) : C(p, [R]), R[hn] = void 0, y[N] === e && delete y[N])
            };
            y[N] = e, d ? S(d, [R, M]) : M()
        },
        clone(R) {
            return ks(R, t, n, r)
        }
    };
    return A
}

function Wo(e) {
    if (Ua(e)) return e = tn(e), e.children = null, e
}

function _u(e) {
    return Ua(e) ? e.children ? e.children[0] : void 0 : e
}

function ji(e, t) {
    e.shapeFlag & 6 && e.component ? ji(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function Kp(e, t = !1, n) {
    let r = [],
        a = 0;
    for (let i = 0; i < e.length; i++) {
        let o = e[i];
        const s = n == null ? o.key : String(n) + String(o.key != null ? o.key : i);
        o.type === Fe ? (o.patchFlag & 128 && a++, r = r.concat(Kp(o.children, t, s))) : (t || o.type !== ot) && r.push(s != null ? tn(o, {
            key: s
        }) : o)
    }
    if (a > 1)
        for (let i = 0; i < r.length; i++) r[i].patchFlag = -2;
    return r
} /*! #__NO_SIDE_EFFECTS__ */
function Ne(e, t) {
    return se(e) ? (() => Ge({
        name: e.name
    }, t, {
        setup: e
    }))() : e
}
const Xn = e => !!e.type.__asyncLoader; /*! #__NO_SIDE_EFFECTS__ */
function $i(e) {
    se(e) && (e = {
        loader: e
    });
    const {
        loader: t,
        loadingComponent: n,
        errorComponent: r,
        delay: a = 200,
        timeout: i,
        suspensible: o = !0,
        onError: s
    } = e;
    let l = null,
        c, u = 0;
    const f = () => (u++, l = null, d()),
        d = () => {
            let p;
            return l || (p = l = t().catch(v => {
                if (v = v instanceof Error ? v : new Error(String(v)), s) return new Promise((E, w) => {
                    s(v, () => E(f()), () => w(v), u + 1)
                });
                throw v
            }).then(v => p !== l && l ? l : (v && (v.__esModule || v[Symbol.toStringTag] === "Module") && (v = v.default), c = v, v)))
        };
    return Ne({
        name: "AsyncComponentWrapper",
        __asyncLoader: d,
        get __asyncResolved() {
            return c
        },
        setup() {
            const p = Ve;
            if (c) return () => zo(c, p);
            const v = b => {
                l = null, jr(b, p, 13, !r)
            };
            if (o && p.suspense || Lr) return d().then(b => () => zo(b, p)).catch(b => (v(b), () => r ? Ae(r, {
                error: b
            }) : null));
            const E = Q(!1),
                w = Q(),
                h = Q(!!a);
            return a && setTimeout(() => {
                h.value = !1
            }, a), i != null && setTimeout(() => {
                if (!E.value && !w.value) {
                    const b = new Error(`Async component timed out after ${i}ms.`);
                    v(b), w.value = b
                }
            }, i), d().then(() => {
                E.value = !0, p.parent && Ua(p.parent.vnode) && fo(p.parent.update)
            }).catch(b => {
                v(b), w.value = b
            }), () => {
                if (E.value && c) return zo(c, p);
                if (w.value && r) return Ae(r, {
                    error: w.value
                });
                if (n && !h.value) return Ae(n)
            }
        }
    })
}

function zo(e, t) {
    const {
        ref: n,
        props: r,
        children: a,
        ce: i
    } = t.vnode, o = Ae(e, r, a);
    return o.ref = n, o.ce = i, delete t.vnode.ce, o
}
const Ua = e => e.type.__isKeepAlive,
    Nb = {
        name: "KeepAlive",
        __isKeepAlive: !0,
        props: {
            include: [String, RegExp, Array],
            exclude: [String, RegExp, Array],
            max: [String, Number]
        },
        setup(e, {
            slots: t
        }) {
            const n = yt(),
                r = n.ctx;
            if (!r.renderer) return () => {
                const b = t.default && t.default();
                return b && b.length === 1 ? b[0] : b
            };
            const a = new Map,
                i = new Set;
            let o = null;
            const s = n.suspense,
                {
                    renderer: {
                        p: l,
                        m: c,
                        um: u,
                        o: {
                            createElement: f
                        }
                    }
                } = r,
                d = f("div");
            r.activate = (b, m, y, C, S) => {
                const A = b.component;
                c(b, m, y, 0, s), l(A.vnode, b, m, y, A, s, C, b.slotScopeIds, S), Xe(() => {
                    A.isDeactivated = !1, A.a && oa(A.a);
                    const R = b.props && b.props.onVnodeMounted;
                    R && ct(R, A.parent, b)
                }, s)
            }, r.deactivate = b => {
                const m = b.component;
                c(b, d, null, 1, s), Xe(() => {
                    m.da && oa(m.da);
                    const y = b.props && b.props.onVnodeUnmounted;
                    y && ct(y, m.parent, b), m.isDeactivated = !0
                }, s)
            };

            function p(b) {
                qo(b), u(b, n, s, !0)
            }

            function v(b) {
                a.forEach((m, y) => {
                    const C = Ds(m.type);
                    C && (!b || !b(C)) && E(y)
                })
            }

            function E(b) {
                const m = a.get(b);
                !o || !Ot(m, o) ? p(m) : o && qo(o), a.delete(b), i.delete(b)
            }
            we(() => [e.include, e.exclude], ([b, m]) => {
                b && v(y => na(b, y)), m && v(y => !na(m, y))
            }, {
                flush: "post",
                deep: !0
            });
            let w = null;
            const h = () => {
                w != null && a.set(w, Yo(n.subTree))
            };
            return Jt(h), cc(h), Ja(() => {
                a.forEach(b => {
                    const {
                        subTree: m,
                        suspense: y
                    } = n, C = Yo(m);
                    if (b.type === C.type && b.key === C.key) {
                        qo(C);
                        const S = C.component.da;
                        S && Xe(S, y);
                        return
                    }
                    p(b)
                })
            }), () => {
                if (w = null, !t.default) return null;
                const b = t.default(),
                    m = b[0];
                if (b.length > 1) return o = null, b;
                if (!Ar(m) || !(m.shapeFlag & 4) && !(m.shapeFlag & 128)) return o = null, m;
                let y = Yo(m);
                const C = y.type,
                    S = Ds(Xn(y) ? y.type.__asyncResolved || {} : C),
                    {
                        include: A,
                        exclude: R,
                        max: O
                    } = e;
                if (A && (!S || !na(A, S)) || R && S && na(R, S)) return o = y, m;
                const N = y.key == null ? C : y.key,
                    x = a.get(N);
                return y.el && (y = tn(y), m.shapeFlag & 128 && (m.ssContent = y)), w = N, x ? (y.el = x.el, y.component = x.component, y.transition && ji(y, y.transition), y.shapeFlag |= 512, i.delete(N), i.add(N)) : (i.add(N), O && i.size > parseInt(O, 10) && E(i.values().next().value)), y.shapeFlag |= 256, o = y, Bp(m.type) ? m : y
            }
        }
    },
    Fb = Nb;

function na(e, t) {
    return ie(e) ? e.some(n => na(n, t)) : xe(e) ? e.split(",").includes(t) : Ly(e) ? e.test(t) : !1
}

function Up(e, t) {
    Gp(e, "a", t)
}

function Jp(e, t) {
    Gp(e, "da", t)
}

function Gp(e, t, n = Ve) {
    const r = e.__wdc || (e.__wdc = () => {
        let a = n;
        for (; a;) {
            if (a.isDeactivated) return;
            a = a.parent
        }
        return e()
    });
    if (go(t, r, n), n) {
        let a = n.parent;
        for (; a && a.parent;) Ua(a.parent.vnode) && Bb(r, t, n, a), a = a.parent
    }
}

function Bb(e, t, n, r) {
    const a = go(t, e, r, !0);
    Rn(() => {
        Kl(r[t], a)
    }, n)
}

function qo(e) {
    e.shapeFlag &= -257, e.shapeFlag &= -513
}

function Yo(e) {
    return e.shapeFlag & 128 ? e.ssContent : e
}

function go(e, t, n = Ve, r = !1) {
    if (n) {
        const a = n[e] || (n[e] = []),
            i = t.__weh || (t.__weh = (...o) => {
                if (n.isUnmounted) return;
                Fr(), Tn(n);
                const s = Ct(t, n, e, o);
                return En(), Br(), s
            });
        return r ? a.unshift(i) : a.push(i), i
    }
}
const nn = e => (t, n = Ve) => (!Lr || e === "sp") && go(e, (...r) => t(...r), n),
    jb = nn("bm"),
    Jt = nn("m"),
    $b = nn("bu"),
    cc = nn("u"),
    Ja = nn("bum"),
    Rn = nn("um"),
    Vb = nn("sp"),
    Hb = nn("rtg"),
    Kb = nn("rtc");

function Wp(e, t = Ve) {
    go("ec", e, t)
}

function Vi(e, t, n, r) {
    let a;
    const i = n && n[r];
    if (ie(e) || xe(e)) {
        a = new Array(e.length);
        for (let o = 0, s = e.length; o < s; o++) a[o] = t(e[o], o, void 0, i && i[o])
    } else if (typeof e == "number") {
        a = new Array(e);
        for (let o = 0; o < e; o++) a[o] = t(o + 1, o, void 0, i && i[o])
    } else if (Te(e))
        if (e[Symbol.iterator]) a = Array.from(e, (o, s) => t(o, s, void 0, i && i[s]));
        else {
            const o = Object.keys(e);
            a = new Array(o.length);
            for (let s = 0, l = o.length; s < l; s++) {
                const c = o[s];
                a[s] = t(e[c], c, s, i && i[s])
            }
        }
    else a = [];
    return n && (n[r] = a), a
}

function Ub(e, t) {
    for (let n = 0; n < t.length; n++) {
        const r = t[n];
        if (ie(r))
            for (let a = 0; a < r.length; a++) e[r[a].name] = r[a].fn;
        else r && (e[r.name] = r.key ? (...a) => {
            const i = r.fn(...a);
            return i && (i.key = r.key), i
        } : r.fn)
    }
    return e
}

function Kt(e, t, n = {}, r, a) {
    if (qe.isCE || qe.parent && Xn(qe.parent) && qe.parent.isCE) return t !== "default" && (n.name = t), Ae("slot", n, r && r());
    let i = e[t];
    i && i._c && (i._d = !1), le();
    const o = i && zp(i(n)),
        s = Pe(Fe, {
            key: n.key || o && o.key || `_${t}`
        }, o || (r ? r() : []), o && e._ === 1 ? 64 : -2);
    return !a && s.scopeId && (s.slotScopeIds = [s.scopeId + "-s"]), i && i._c && (i._d = !0), s
}

function zp(e) {
    return e.some(t => Ar(t) ? !(t.type === ot || t.type === Fe && !zp(t.children)) : !0) ? e : null
}
const Rs = e => e ? ch(e) ? vo(e) || e.proxy : Rs(e.parent) : null,
    sa = Ge(Object.create(null), {
        $: e => e,
        $el: e => e.vnode.el,
        $data: e => e.data,
        $props: e => e.props,
        $attrs: e => e.attrs,
        $slots: e => e.slots,
        $refs: e => e.refs,
        $parent: e => Rs(e.parent),
        $root: e => Rs(e.root),
        $emit: e => e.emit,
        $options: e => uc(e),
        $forceUpdate: e => e.f || (e.f = () => fo(e.update)),
        $nextTick: e => e.n || (e.n = St.bind(e.proxy)),
        $watch: e => Pb.bind(e)
    }),
    Xo = (e, t) => e !== Oe && !e.__isScriptSetup && ye(e, t),
    Jb = {
        get({
            _: e
        }, t) {
            const {
                ctx: n,
                setupState: r,
                data: a,
                props: i,
                accessCache: o,
                type: s,
                appContext: l
            } = e;
            let c;
            if (t[0] !== "$") {
                const p = o[t];
                if (p !== void 0) switch (p) {
                    case 1:
                        return r[t];
                    case 2:
                        return a[t];
                    case 4:
                        return n[t];
                    case 3:
                        return i[t]
                } else {
                    if (Xo(r, t)) return o[t] = 1, r[t];
                    if (a !== Oe && ye(a, t)) return o[t] = 2, a[t];
                    if ((c = e.propsOptions[0]) && ye(c, t)) return o[t] = 3, i[t];
                    if (n !== Oe && ye(n, t)) return o[t] = 4, n[t];
                    Os && (o[t] = 0)
                }
            }
            const u = sa[t];
            let f, d;
            if (u) return t === "$attrs" && dt(e, "get", t), u(e);
            if ((f = s.__cssModules) && (f = f[t])) return f;
            if (n !== Oe && ye(n, t)) return o[t] = 4, n[t];
            if (d = l.config.globalProperties, ye(d, t)) return d[t]
        },
        set({
            _: e
        }, t, n) {
            const {
                data: r,
                setupState: a,
                ctx: i
            } = e;
            return Xo(a, t) ? (a[t] = n, !0) : r !== Oe && ye(r, t) ? (r[t] = n, !0) : ye(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (i[t] = n, !0)
        },
        has({
            _: {
                data: e,
                setupState: t,
                accessCache: n,
                ctx: r,
                appContext: a,
                propsOptions: i
            }
        }, o) {
            let s;
            return !!n[o] || e !== Oe && ye(e, o) || Xo(t, o) || (s = i[0]) && ye(s, o) || ye(r, o) || ye(sa, o) || ye(a.config.globalProperties, o)
        },
        defineProperty(e, t, n) {
            return n.get != null ? e._.accessCache[t] = 0 : ye(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
        }
    };

function Gb() {
    return qp().slots
}

function Wb() {
    return qp().attrs
}

function qp() {
    const e = yt();
    return e.setupContext || (e.setupContext = fh(e))
}

function wu(e) {
    return ie(e) ? e.reduce((t, n) => (t[n] = null, t), {}) : e
}

function zb(e) {
    const t = yt();
    let n = e();
    return En(), Ul(n) && (n = n.catch(r => {
        throw Tn(t), r
    })), [n, () => Tn(t)]
}
let Os = !0;

function qb(e) {
    const t = uc(e),
        n = e.proxy,
        r = e.ctx;
    Os = !1, t.beforeCreate && Eu(t.beforeCreate, e, "bc");
    const {
        data: a,
        computed: i,
        methods: o,
        watch: s,
        provide: l,
        inject: c,
        created: u,
        beforeMount: f,
        mounted: d,
        beforeUpdate: p,
        updated: v,
        activated: E,
        deactivated: w,
        beforeDestroy: h,
        beforeUnmount: b,
        destroyed: m,
        unmounted: y,
        render: C,
        renderTracked: S,
        renderTriggered: A,
        errorCaptured: R,
        serverPrefetch: O,
        expose: N,
        inheritAttrs: x,
        components: M,
        directives: K,
        filters: ne
    } = t;
    if (c && Yb(c, r, null), o)
        for (const ae in o) {
            const X = o[ae];
            se(X) && (r[ae] = X.bind(n))
        }
    if (a) {
        const ae = a.call(n, n);
        Te(ae) && (e.data = tt(ae))
    }
    if (Os = !0, i)
        for (const ae in i) {
            const X = i[ae],
                Ce = se(X) ? X.bind(n, n) : se(X.get) ? X.get.bind(n, n) : Pt,
                Ze = !se(X) && se(X.set) ? X.set.bind(n) : Pt,
                je = W({
                    get: Ce,
                    set: Ze
                });
            Object.defineProperty(r, ae, {
                enumerable: !0,
                configurable: !0,
                get: () => je.value,
                set: Ie => je.value = Ie
            })
        }
    if (s)
        for (const ae in s) Yp(s[ae], r, n, ae);
    if (l) {
        const ae = se(l) ? l.call(n) : l;
        Reflect.ownKeys(ae).forEach(X => {
            Qn(X, ae[X])
        })
    }
    u && Eu(u, e, "c");

    function J(ae, X) {
        ie(X) ? X.forEach(Ce => ae(Ce.bind(n))) : X && ae(X.bind(n))
    }
    if (J(jb, f), J(Jt, d), J($b, p), J(cc, v), J(Up, E), J(Jp, w), J(Wp, R), J(Kb, S), J(Hb, A), J(Ja, b), J(Rn, y), J(Vb, O), ie(N))
        if (N.length) {
            const ae = e.exposed || (e.exposed = {});
            N.forEach(X => {
                Object.defineProperty(ae, X, {
                    get: () => n[X],
                    set: Ce => n[X] = Ce
                })
            })
        } else e.exposed || (e.exposed = {});
    C && e.render === Pt && (e.render = C), x != null && (e.inheritAttrs = x), M && (e.components = M), K && (e.directives = K)
}

function Yb(e, t, n = Pt) {
    ie(e) && (e = Ms(e));
    for (const r in e) {
        const a = e[r];
        let i;
        Te(a) ? "default" in a ? i = Je(a.from || r, a.default, !0) : i = Je(a.from || r) : i = Je(a), _e(i) ? Object.defineProperty(t, r, {
            enumerable: !0,
            configurable: !0,
            get: () => i.value,
            set: o => i.value = o
        }) : t[r] = i
    }
}

function Eu(e, t, n) {
    Ct(ie(e) ? e.map(r => r.bind(t.proxy)) : e.bind(t.proxy), t, n)
}

function Yp(e, t, n, r) {
    const a = r.includes(".") ? $p(n, r) : () => n[r];
    if (xe(e)) {
        const i = t[e];
        se(i) && we(a, i)
    } else if (se(e)) we(a, e.bind(n));
    else if (Te(e))
        if (ie(e)) e.forEach(i => Yp(i, t, n, r));
        else {
            const i = se(e.handler) ? e.handler.bind(n) : t[e.handler];
            se(i) && we(a, i, e)
        }
}

function uc(e) {
    const t = e.type,
        {
            mixins: n,
            extends: r
        } = t,
        {
            mixins: a,
            optionsCache: i,
            config: {
                optionMergeStrategies: o
            }
        } = e.appContext,
        s = i.get(t);
    let l;
    return s ? l = s : !a.length && !n && !r ? l = t : (l = {}, a.length && a.forEach(c => Hi(l, c, o, !0)), Hi(l, t, o)), Te(t) && i.set(t, l), l
}

function Hi(e, t, n, r = !1) {
    const {
        mixins: a,
        extends: i
    } = t;
    i && Hi(e, i, n, !0), a && a.forEach(o => Hi(e, o, n, !0));
    for (const o in t)
        if (!(r && o === "expose")) {
            const s = Xb[o] || n && n[o];
            e[o] = s ? s(e[o], t[o]) : t[o]
        }
    return e
}
const Xb = {
    data: Cu,
    props: Au,
    emits: Au,
    methods: ra,
    computed: ra,
    beforeCreate: nt,
    created: nt,
    beforeMount: nt,
    mounted: nt,
    beforeUpdate: nt,
    updated: nt,
    beforeDestroy: nt,
    beforeUnmount: nt,
    destroyed: nt,
    unmounted: nt,
    activated: nt,
    deactivated: nt,
    errorCaptured: nt,
    serverPrefetch: nt,
    components: ra,
    directives: ra,
    watch: Zb,
    provide: Cu,
    inject: Qb
};

function Cu(e, t) {
    return t ? e ? function() {
        return Ge(se(e) ? e.call(this, this) : e, se(t) ? t.call(this, this) : t)
    } : t : e
}

function Qb(e, t) {
    return ra(Ms(e), Ms(t))
}

function Ms(e) {
    if (ie(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
        return t
    }
    return e
}

function nt(e, t) {
    return e ? [...new Set([].concat(e, t))] : t
}

function ra(e, t) {
    return e ? Ge(Object.create(null), e, t) : t
}

function Au(e, t) {
    return e ? ie(e) && ie(t) ? [...new Set([...e, ...t])] : Ge(Object.create(null), wu(e), wu(t ? ? {})) : t
}

function Zb(e, t) {
    if (!e) return t;
    if (!t) return e;
    const n = Ge(Object.create(null), e);
    for (const r in t) n[r] = nt(e[r], t[r]);
    return n
}

function Xp() {
    return {
        app: null,
        config: {
            isNativeTag: Cy,
            performance: !1,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: Object.create(null),
        optionsCache: new WeakMap,
        propsCache: new WeakMap,
        emitsCache: new WeakMap
    }
}
let ev = 0;

function tv(e, t) {
    return function(r, a = null) {
        se(r) || (r = Ge({}, r)), a != null && !Te(a) && (a = null);
        const i = Xp(),
            o = new WeakSet;
        let s = !1;
        const l = i.app = {
            _uid: ev++,
            _component: r,
            _props: a,
            _container: null,
            _context: i,
            _instance: null,
            version: dh,
            get config() {
                return i.config
            },
            set config(c) {},
            use(c, ...u) {
                return o.has(c) || (c && se(c.install) ? (o.add(c), c.install(l, ...u)) : se(c) && (o.add(c), c(l, ...u))), l
            },
            mixin(c) {
                return i.mixins.includes(c) || i.mixins.push(c), l
            },
            component(c, u) {
                return u ? (i.components[c] = u, l) : i.components[c]
            },
            directive(c, u) {
                return u ? (i.directives[c] = u, l) : i.directives[c]
            },
            mount(c, u, f) {
                if (!s) {
                    const d = Ae(r, a);
                    return d.appContext = i, u && t ? t(d, c) : e(d, c, f), s = !0, l._container = c, c.__vue_app__ = l, vo(d.component) || d.component.proxy
                }
            },
            unmount() {
                s && (e(null, l._container), delete l._container.__vue_app__)
            },
            provide(c, u) {
                return i.provides[c] = u, l
            },
            runWithContext(c) {
                Aa = l;
                try {
                    return c()
                } finally {
                    Aa = null
                }
            }
        };
        return l
    }
}
let Aa = null;

function Qn(e, t) {
    if (Ve) {
        let n = Ve.provides;
        const r = Ve.parent && Ve.parent.provides;
        r === n && (n = Ve.provides = Object.create(r)), n[e] = t
    }
}

function Je(e, t, n = !1) {
    const r = Ve || qe;
    if (r || Aa) {
        const a = r ? r.parent == null ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : Aa._context.provides;
        if (a && e in a) return a[e];
        if (arguments.length > 1) return n && se(t) ? t.call(r && r.proxy) : t
    }
}

function fc() {
    return !!(Ve || qe || Aa)
}

function nv(e, t, n, r = !1) {
    const a = {},
        i = {};
    Ii(i, yo, 1), e.propsDefaults = Object.create(null), Qp(e, t, a, i);
    for (const o in e.propsOptions[0]) o in a || (a[o] = void 0);
    n ? e.props = r ? a : Ha(a) : e.type.props ? e.props = a : e.props = i, e.attrs = i
}

function rv(e, t, n, r) {
    const {
        props: a,
        attrs: i,
        vnode: {
            patchFlag: o
        }
    } = e, s = he(a), [l] = e.propsOptions;
    let c = !1;
    if ((r || o > 0) && !(o & 16)) {
        if (o & 8) {
            const u = e.vnode.dynamicProps;
            for (let f = 0; f < u.length; f++) {
                let d = u[f];
                if (po(e.emitsOptions, d)) continue;
                const p = t[d];
                if (l)
                    if (ye(i, d)) p !== i[d] && (i[d] = p, c = !0);
                    else {
                        const v = Ut(d);
                        a[v] = Ps(l, s, v, p, e, !1)
                    }
                else p !== i[d] && (i[d] = p, c = !0)
            }
        }
    } else {
        Qp(e, t, a, i) && (c = !0);
        let u;
        for (const f in s)(!t || !ye(t, f) && ((u = ar(f)) === f || !ye(t, u))) && (l ? n && (n[f] !== void 0 || n[u] !== void 0) && (a[f] = Ps(l, s, f, void 0, e, !0)) : delete a[f]);
        if (i !== s)
            for (const f in i)(!t || !ye(t, f)) && (delete i[f], c = !0)
    }
    c && Zt(e, "set", "$attrs")
}

function Qp(e, t, n, r) {
    const [a, i] = e.propsOptions;
    let o = !1,
        s;
    if (t)
        for (let l in t) {
            if (ia(l)) continue;
            const c = t[l];
            let u;
            a && ye(a, u = Ut(l)) ? !i || !i.includes(u) ? n[u] = c : (s || (s = {}))[u] = c : po(e.emitsOptions, l) || (!(l in r) || c !== r[l]) && (r[l] = c, o = !0)
        }
    if (i) {
        const l = he(n),
            c = s || Oe;
        for (let u = 0; u < i.length; u++) {
            const f = i[u];
            n[f] = Ps(a, l, f, c[f], e, !ye(c, f))
        }
    }
    return o
}

function Ps(e, t, n, r, a, i) {
    const o = e[n];
    if (o != null) {
        const s = ye(o, "default");
        if (s && r === void 0) {
            const l = o.default;
            if (o.type !== Function && !o.skipFactory && se(l)) {
                const {
                    propsDefaults: c
                } = a;
                n in c ? r = c[n] : (Tn(a), r = c[n] = l.call(null, t), En())
            } else r = l
        }
        o[0] && (i && !s ? r = !1 : o[1] && (r === "" || r === ar(n)) && (r = !0))
    }
    return r
}

function Zp(e, t, n = !1) {
    const r = t.propsCache,
        a = r.get(e);
    if (a) return a;
    const i = e.props,
        o = {},
        s = [];
    let l = !1;
    if (!se(e)) {
        const u = f => {
            l = !0;
            const [d, p] = Zp(f, t, !0);
            Ge(o, d), p && s.push(...p)
        };
        !n && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u)
    }
    if (!i && !l) return Te(e) && r.set(e, mr), mr;
    if (ie(i))
        for (let u = 0; u < i.length; u++) {
            const f = Ut(i[u]);
            Lu(f) && (o[f] = Oe)
        } else if (i)
            for (const u in i) {
                const f = Ut(u);
                if (Lu(f)) {
                    const d = i[u],
                        p = o[f] = ie(d) || se(d) ? {
                            type: d
                        } : Ge({}, d);
                    if (p) {
                        const v = ku(Boolean, p.type),
                            E = ku(String, p.type);
                        p[0] = v > -1, p[1] = E < 0 || v < E, (v > -1 || ye(p, "default")) && s.push(f)
                    }
                }
            }
    const c = [o, s];
    return Te(e) && r.set(e, c), c
}

function Lu(e) {
    return e[0] !== "$"
}

function Su(e) {
    const t = e && e.toString().match(/^\s*(function|class) (\w+)/);
    return t ? t[2] : e === null ? "null" : ""
}

function Tu(e, t) {
    return Su(e) === Su(t)
}

function ku(e, t) {
    return ie(t) ? t.findIndex(n => Tu(n, e)) : se(t) && Tu(t, e) ? 0 : -1
}
const eh = e => e[0] === "_" || e === "$stable",
    dc = e => ie(e) ? e.map(vt) : [vt(e)],
    av = (e, t, n) => {
        if (t._n) return t;
        const r = Sn((...a) => dc(t(...a)), n);
        return r._c = !1, r
    },
    th = (e, t, n) => {
        const r = e._ctx;
        for (const a in e) {
            if (eh(a)) continue;
            const i = e[a];
            if (se(i)) t[a] = av(a, i, r);
            else if (i != null) {
                const o = dc(i);
                t[a] = () => o
            }
        }
    },
    nh = (e, t) => {
        const n = dc(t);
        e.slots.default = () => n
    },
    iv = (e, t) => {
        if (e.vnode.shapeFlag & 32) {
            const n = t._;
            n ? (e.slots = he(t), Ii(t, "_", n)) : th(t, e.slots = {})
        } else e.slots = {}, t && nh(e, t);
        Ii(e.slots, yo, 1)
    },
    ov = (e, t, n) => {
        const {
            vnode: r,
            slots: a
        } = e;
        let i = !0,
            o = Oe;
        if (r.shapeFlag & 32) {
            const s = t._;
            s ? n && s === 1 ? i = !1 : (Ge(a, t), !n && s === 1 && delete a._) : (i = !t.$stable, th(t, a)), o = t
        } else t && (nh(e, t), o = {
            default: 1
        });
        if (i)
            for (const s in a) !eh(s) && o[s] == null && delete a[s]
    };

function Ki(e, t, n, r, a = !1) {
    if (ie(e)) {
        e.forEach((d, p) => Ki(d, t && (ie(t) ? t[p] : t), n, r, a));
        return
    }
    if (Xn(r) && !a) return;
    const i = r.shapeFlag & 4 ? vo(r.component) || r.component.proxy : r.el,
        o = a ? null : i,
        {
            i: s,
            r: l
        } = e,
        c = t && t.r,
        u = s.refs === Oe ? s.refs = {} : s.refs,
        f = s.setupState;
    if (c != null && c !== l && (xe(c) ? (u[c] = null, ye(f, c) && (f[c] = null)) : _e(c) && (c.value = null)), se(l)) wn(l, s, 12, [o, u]);
    else {
        const d = xe(l),
            p = _e(l);
        if (d || p) {
            const v = () => {
                if (e.f) {
                    const E = d ? ye(f, l) ? f[l] : u[l] : l.value;
                    a ? ie(E) && Kl(E, i) : ie(E) ? E.includes(i) || E.push(i) : d ? (u[l] = [i], ye(f, l) && (f[l] = u[l])) : (l.value = [i], e.k && (u[e.k] = l.value))
                } else d ? (u[l] = o, ye(f, l) && (f[l] = o)) : p && (l.value = o, e.k && (u[e.k] = o))
            };
            o ? (v.id = -1, Xe(v, n)) : v()
        }
    }
}
let on = !1;
const ui = e => /svg/.test(e.namespaceURI) && e.tagName !== "foreignObject",
    fi = e => e.nodeType === 8;

function sv(e) {
    const {
        mt: t,
        p: n,
        o: {
            patchProp: r,
            createText: a,
            nextSibling: i,
            parentNode: o,
            remove: s,
            insert: l,
            createComment: c
        }
    } = e, u = (m, y) => {
        if (!y.hasChildNodes()) {
            n(null, m, y), Fi(), y._vnode = m;
            return
        }
        on = !1, f(y.firstChild, m, null, null, null), Fi(), y._vnode = m, on && console.error("Hydration completed but contains mismatches.")
    }, f = (m, y, C, S, A, R = !1) => {
        const O = fi(m) && m.data === "[",
            N = () => E(m, y, C, S, A, O),
            {
                type: x,
                ref: M,
                shapeFlag: K,
                patchFlag: ne
            } = y;
        let te = m.nodeType;
        y.el = m, ne === -2 && (R = !1, y.dynamicChildren = null);
        let J = null;
        switch (x) {
            case nr:
                te !== 3 ? y.children === "" ? (l(y.el = a(""), o(m), m), J = m) : J = N() : (m.data !== y.children && (on = !0, m.data = y.children), J = i(m));
                break;
            case ot:
                b(m) ? (J = i(m), h(y.el = m.content.firstChild, m, C)) : te !== 8 || O ? J = N() : J = i(m);
                break;
            case vr:
                if (O && (m = i(m), te = m.nodeType), te === 1 || te === 3) {
                    J = m;
                    const ae = !y.children.length;
                    for (let X = 0; X < y.staticCount; X++) ae && (y.children += J.nodeType === 1 ? J.outerHTML : J.data), X === y.staticCount - 1 && (y.anchor = J), J = i(J);
                    return O ? i(J) : J
                } else N();
                break;
            case Fe:
                O ? J = v(m, y, C, S, A, R) : J = N();
                break;
            default:
                if (K & 1)(te !== 1 || y.type.toLowerCase() !== m.tagName.toLowerCase()) && !b(m) ? J = N() : J = d(m, y, C, S, A, R);
                else if (K & 6) {
                    y.slotScopeIds = A;
                    const ae = o(m);
                    if (O ? J = w(m) : fi(m) && m.data === "teleport start" ? J = w(m, m.data, "teleport end") : J = i(m), t(y, ae, null, C, S, ui(ae), R), Xn(y)) {
                        let X;
                        O ? (X = Ae(Fe), X.anchor = J ? J.previousSibling : ae.lastChild) : X = m.nodeType === 3 ? La("") : Ae("div"), X.el = m, y.component.subTree = X
                    }
                } else K & 64 ? te !== 8 ? J = N() : J = y.type.hydrate(m, y, C, S, A, R, e, p) : K & 128 && (J = y.type.hydrate(m, y, C, S, ui(o(m)), A, R, e, f))
        }
        return M != null && Ki(M, null, S, y), J
    }, d = (m, y, C, S, A, R) => {
        R = R || !!y.dynamicChildren;
        const {
            type: O,
            props: N,
            patchFlag: x,
            shapeFlag: M,
            dirs: K,
            transition: ne
        } = y, te = O === "input" || O === "option";
        if (te || x !== -1) {
            if (K && $t(y, null, C, "created"), N)
                if (te || !R || x & 48)
                    for (const X in N)(te && (X.endsWith("value") || X === "indeterminate") || ja(X) && !ia(X) || X[0] === ".") && r(m, X, null, N[X], !1, void 0, C);
                else N.onClick && r(m, "onClick", null, N.onClick, !1, void 0, C);
            let J;
            (J = N && N.onVnodeBeforeMount) && ct(J, C, y);
            let ae = !1;
            if (b(m)) {
                ae = ah(S, ne) && C && C.vnode.props && C.vnode.props.appear;
                const X = m.content.firstChild;
                ae && ne.beforeEnter(X), h(X, m, C), y.el = m = X
            }
            if (K && $t(y, null, C, "beforeMount"), ((J = N && N.onVnodeMounted) || K || ae) && jp(() => {
                    J && ct(J, C, y), ae && ne.enter(m), K && $t(y, null, C, "mounted")
                }, S), M & 16 && !(N && (N.innerHTML || N.textContent))) {
                let X = p(m.firstChild, y, m, C, S, A, R);
                for (; X;) {
                    on = !0;
                    const Ce = X;
                    X = X.nextSibling, s(Ce)
                }
            } else M & 8 && m.textContent !== y.children && (on = !0, m.textContent = y.children)
        }
        return m.nextSibling
    }, p = (m, y, C, S, A, R, O) => {
        O = O || !!y.dynamicChildren;
        const N = y.children,
            x = N.length;
        for (let M = 0; M < x; M++) {
            const K = O ? N[M] : N[M] = vt(N[M]);
            if (m) m = f(m, K, S, A, R, O);
            else {
                if (K.type === nr && !K.children) continue;
                on = !0, n(null, K, C, null, S, A, ui(C), R)
            }
        }
        return m
    }, v = (m, y, C, S, A, R) => {
        const {
            slotScopeIds: O
        } = y;
        O && (A = A ? A.concat(O) : O);
        const N = o(m),
            x = p(i(m), y, N, C, S, A, R);
        return x && fi(x) && x.data === "]" ? i(y.anchor = x) : (on = !0, l(y.anchor = c("]"), N, x), x)
    }, E = (m, y, C, S, A, R) => {
        if (on = !0, y.el = null, R) {
            const x = w(m);
            for (;;) {
                const M = i(m);
                if (M && M !== x) s(M);
                else break
            }
        }
        const O = i(m),
            N = o(m);
        return s(m), n(null, y, N, O, C, S, ui(N), A), O
    }, w = (m, y = "[", C = "]") => {
        let S = 0;
        for (; m;)
            if (m = i(m), m && fi(m) && (m.data === y && S++, m.data === C)) {
                if (S === 0) return i(m);
                S--
            }
        return m
    }, h = (m, y, C) => {
        const S = y.parentNode;
        S && S.replaceChild(m, y);
        let A = C;
        for (; A;) A.vnode.el === y && (A.vnode.el = A.subTree.el = m), A = A.parent
    }, b = m => m.nodeType === 1 && m.tagName.toLowerCase() === "template";
    return [u, f]
}
const Xe = jp;

function lv(e) {
    return rh(e)
}

function cv(e) {
    return rh(e, sv)
}

function rh(e, t) {
    const n = Es();
    n.__VUE__ = !0;
    const {
        insert: r,
        remove: a,
        patchProp: i,
        createElement: o,
        createText: s,
        createComment: l,
        setText: c,
        setElementText: u,
        parentNode: f,
        nextSibling: d,
        setScopeId: p = Pt,
        insertStaticContent: v
    } = e, E = (L, g, _, T = null, P = null, F = null, $ = !1, H = null, U = !!g.dynamicChildren) => {
        if (L === g) return;
        L && !Ot(L, g) && (T = j(L), Ie(L, P, F, !0), L = null), g.patchFlag === -2 && (U = !1, g.dynamicChildren = null);
        const {
            type: V,
            ref: re,
            shapeFlag: z
        } = g;
        switch (V) {
            case nr:
                w(L, g, _, T);
                break;
            case ot:
                h(L, g, _, T);
                break;
            case vr:
                L == null && b(g, _, T, $);
                break;
            case Fe:
                M(L, g, _, T, P, F, $, H, U);
                break;
            default:
                z & 1 ? C(L, g, _, T, P, F, $, H, U) : z & 6 ? K(L, g, _, T, P, F, $, H, U) : (z & 64 || z & 128) && V.process(L, g, _, T, P, F, $, H, U, G)
        }
        re != null && P && Ki(re, L && L.ref, F, g || L, !g)
    }, w = (L, g, _, T) => {
        if (L == null) r(g.el = s(g.children), _, T);
        else {
            const P = g.el = L.el;
            g.children !== L.children && c(P, g.children)
        }
    }, h = (L, g, _, T) => {
        L == null ? r(g.el = l(g.children || ""), _, T) : g.el = L.el
    }, b = (L, g, _, T) => {
        [L.el, L.anchor] = v(L.children, g, _, T, L.el, L.anchor)
    }, m = ({
        el: L,
        anchor: g
    }, _, T) => {
        let P;
        for (; L && L !== g;) P = d(L), r(L, _, T), L = P;
        r(g, _, T)
    }, y = ({
        el: L,
        anchor: g
    }) => {
        let _;
        for (; L && L !== g;) _ = d(L), a(L), L = _;
        a(g)
    }, C = (L, g, _, T, P, F, $, H, U) => {
        $ = $ || g.type === "svg", L == null ? S(g, _, T, P, F, $, H, U) : O(L, g, P, F, $, H, U)
    }, S = (L, g, _, T, P, F, $, H) => {
        let U, V;
        const {
            type: re,
            props: z,
            shapeFlag: I,
            transition: B,
            dirs: Z
        } = L;
        if (U = L.el = o(L.type, F, z && z.is, z), I & 8 ? u(U, L.children) : I & 16 && R(L.children, U, null, T, P, F && re !== "foreignObject", $, H), Z && $t(L, null, T, "created"), A(U, L, L.scopeId, $, T), z) {
            for (const fe in z) fe !== "value" && !ia(fe) && i(U, fe, null, z[fe], F, L.children, T, P, $e);
            "value" in z && i(U, "value", null, z.value), (V = z.onVnodeBeforeMount) && ct(V, T, L)
        }
        Z && $t(L, null, T, "beforeMount");
        const oe = ah(P, B);
        oe && B.beforeEnter(U), r(U, g, _), ((V = z && z.onVnodeMounted) || oe || Z) && Xe(() => {
            V && ct(V, T, L), oe && B.enter(U), Z && $t(L, null, T, "mounted")
        }, P)
    }, A = (L, g, _, T, P) => {
        if (_ && p(L, _), T)
            for (let F = 0; F < T.length; F++) p(L, T[F]);
        if (P) {
            let F = P.subTree;
            if (g === F) {
                const $ = P.vnode;
                A(L, $, $.scopeId, $.slotScopeIds, P.parent)
            }
        }
    }, R = (L, g, _, T, P, F, $, H, U = 0) => {
        for (let V = U; V < L.length; V++) {
            const re = L[V] = H ? mn(L[V]) : vt(L[V]);
            E(null, re, g, _, T, P, F, $, H)
        }
    }, O = (L, g, _, T, P, F, $) => {
        const H = g.el = L.el;
        let {
            patchFlag: U,
            dynamicChildren: V,
            dirs: re
        } = g;
        U |= L.patchFlag & 16;
        const z = L.props || Oe,
            I = g.props || Oe;
        let B;
        _ && In(_, !1), (B = I.onVnodeBeforeUpdate) && ct(B, _, g, L), re && $t(g, L, _, "beforeUpdate"), _ && In(_, !0);
        const Z = P && g.type !== "foreignObject";
        if (V ? N(L.dynamicChildren, V, H, _, T, Z, F) : $ || X(L, g, H, null, _, T, Z, F, !1), U > 0) {
            if (U & 16) x(H, g, z, I, _, T, P);
            else if (U & 2 && z.class !== I.class && i(H, "class", null, I.class, P), U & 4 && i(H, "style", z.style, I.style, P), U & 8) {
                const oe = g.dynamicProps;
                for (let fe = 0; fe < oe.length; fe++) {
                    const ke = oe[fe],
                        We = z[ke],
                        rn = I[ke];
                    (rn !== We || ke === "value") && i(H, ke, We, rn, P, L.children, _, T, $e)
                }
            }
            U & 1 && L.children !== g.children && u(H, g.children)
        } else !$ && V == null && x(H, g, z, I, _, T, P);
        ((B = I.onVnodeUpdated) || re) && Xe(() => {
            B && ct(B, _, g, L), re && $t(g, L, _, "updated")
        }, T)
    }, N = (L, g, _, T, P, F, $) => {
        for (let H = 0; H < g.length; H++) {
            const U = L[H],
                V = g[H],
                re = U.el && (U.type === Fe || !Ot(U, V) || U.shapeFlag & 70) ? f(U.el) : _;
            E(U, V, re, null, T, P, F, $, !0)
        }
    }, x = (L, g, _, T, P, F, $) => {
        if (_ !== T) {
            if (_ !== Oe)
                for (const H in _) !ia(H) && !(H in T) && i(L, H, _[H], null, $, g.children, P, F, $e);
            for (const H in T) {
                if (ia(H)) continue;
                const U = T[H],
                    V = _[H];
                U !== V && H !== "value" && i(L, H, V, U, $, g.children, P, F, $e)
            }
            "value" in T && i(L, "value", _.value, T.value)
        }
    }, M = (L, g, _, T, P, F, $, H, U) => {
        const V = g.el = L ? L.el : s(""),
            re = g.anchor = L ? L.anchor : s("");
        let {
            patchFlag: z,
            dynamicChildren: I,
            slotScopeIds: B
        } = g;
        B && (H = H ? H.concat(B) : B), L == null ? (r(V, _, T), r(re, _, T), R(g.children, _, re, P, F, $, H, U)) : z > 0 && z & 64 && I && L.dynamicChildren ? (N(L.dynamicChildren, I, _, P, F, $, H), (g.key != null || P && g === P.subTree) && pc(L, g, !0)) : X(L, g, _, re, P, F, $, H, U)
    }, K = (L, g, _, T, P, F, $, H, U) => {
        g.slotScopeIds = H, L == null ? g.shapeFlag & 512 ? P.ctx.activate(g, _, T, $, U) : ne(g, _, T, P, F, $, U) : te(L, g, U)
    }, ne = (L, g, _, T, P, F, $) => {
        const H = L.component = bv(L, T, P);
        if (Ua(L) && (H.ctx.renderer = G), vv(H), H.asyncDep) {
            if (P && P.registerDep(H, J), !L.el) {
                const U = H.subTree = Ae(ot);
                h(null, U, g, _)
            }
            return
        }
        J(H, L, g, _, P, F, $)
    }, te = (L, g, _) => {
        const T = g.component = L.component;
        if (Cb(L, g, _))
            if (T.asyncDep && !T.asyncResolved) {
                ae(T, g, _);
                return
            } else T.next = g, yb(T.update), T.update();
        else g.el = L.el, T.vnode = g
    }, J = (L, g, _, T, P, F, $) => {
        const H = () => {
                if (L.isMounted) {
                    let {
                        next: re,
                        bu: z,
                        u: I,
                        parent: B,
                        vnode: Z
                    } = L, oe = re, fe;
                    In(L, !1), re ? (re.el = Z.el, ae(L, re, $)) : re = Z, z && oa(z), (fe = re.props && re.props.onVnodeBeforeUpdate) && ct(fe, B, re, Z), In(L, !0);
                    const ke = Go(L),
                        We = L.subTree;
                    L.subTree = ke, E(We, ke, f(We.el), j(We), L, P, F), re.el = ke.el, oe === null && nc(L, ke.el), I && Xe(I, P), (fe = re.props && re.props.onVnodeUpdated) && Xe(() => ct(fe, B, re, Z), P)
                } else {
                    let re;
                    const {
                        el: z,
                        props: I
                    } = g, {
                        bm: B,
                        m: Z,
                        parent: oe
                    } = L, fe = Xn(g);
                    if (In(L, !1), B && oa(B), !fe && (re = I && I.onVnodeBeforeMount) && ct(re, oe, g), In(L, !0), z && ue) {
                        const ke = () => {
                            L.subTree = Go(L), ue(z, L.subTree, L, P, null)
                        };
                        fe ? g.type.__asyncLoader().then(() => !L.isUnmounted && ke()) : ke()
                    } else {
                        const ke = L.subTree = Go(L);
                        E(null, ke, _, T, L, P, F), g.el = ke.el
                    }
                    if (Z && Xe(Z, P), !fe && (re = I && I.onVnodeMounted)) {
                        const ke = g;
                        Xe(() => ct(re, oe, ke), P)
                    }(g.shapeFlag & 256 || oe && Xn(oe.vnode) && oe.vnode.shapeFlag & 256) && L.a && Xe(L.a, P), L.isMounted = !0, g = _ = T = null
                }
            },
            U = L.effect = new zl(H, () => fo(V), L.scope),
            V = L.update = () => U.run();
        V.id = L.uid, In(L, !0), V()
    }, ae = (L, g, _) => {
        g.component = L;
        const T = L.vnode.props;
        L.vnode = g, L.next = null, rv(L, g.props, T, _), ov(L, g.children, _), Fr(), gu(L), Br()
    }, X = (L, g, _, T, P, F, $, H, U = !1) => {
        const V = L && L.children,
            re = L ? L.shapeFlag : 0,
            z = g.children,
            {
                patchFlag: I,
                shapeFlag: B
            } = g;
        if (I > 0) {
            if (I & 128) {
                Ze(V, z, _, T, P, F, $, H, U);
                return
            } else if (I & 256) {
                Ce(V, z, _, T, P, F, $, H, U);
                return
            }
        }
        B & 8 ? (re & 16 && $e(V, P, F), z !== V && u(_, z)) : re & 16 ? B & 16 ? Ze(V, z, _, T, P, F, $, H, U) : $e(V, P, F, !0) : (re & 8 && u(_, ""), B & 16 && R(z, _, T, P, F, $, H, U))
    }, Ce = (L, g, _, T, P, F, $, H, U) => {
        L = L || mr, g = g || mr;
        const V = L.length,
            re = g.length,
            z = Math.min(V, re);
        let I;
        for (I = 0; I < z; I++) {
            const B = g[I] = U ? mn(g[I]) : vt(g[I]);
            E(L[I], B, _, null, P, F, $, H, U)
        }
        V > re ? $e(L, P, F, !0, !1, z) : R(g, _, T, P, F, $, H, U, z)
    }, Ze = (L, g, _, T, P, F, $, H, U) => {
        let V = 0;
        const re = g.length;
        let z = L.length - 1,
            I = re - 1;
        for (; V <= z && V <= I;) {
            const B = L[V],
                Z = g[V] = U ? mn(g[V]) : vt(g[V]);
            if (Ot(B, Z)) E(B, Z, _, null, P, F, $, H, U);
            else break;
            V++
        }
        for (; V <= z && V <= I;) {
            const B = L[z],
                Z = g[I] = U ? mn(g[I]) : vt(g[I]);
            if (Ot(B, Z)) E(B, Z, _, null, P, F, $, H, U);
            else break;
            z--, I--
        }
        if (V > z) {
            if (V <= I) {
                const B = I + 1,
                    Z = B < re ? g[B].el : T;
                for (; V <= I;) E(null, g[V] = U ? mn(g[V]) : vt(g[V]), _, Z, P, F, $, H, U), V++
            }
        } else if (V > I)
            for (; V <= z;) Ie(L[V], P, F, !0), V++;
        else {
            const B = V,
                Z = V,
                oe = new Map;
            for (V = Z; V <= I; V++) {
                const ht = g[V] = U ? mn(g[V]) : vt(g[V]);
                ht.key != null && oe.set(ht.key, V)
            }
            let fe, ke = 0;
            const We = I - Z + 1;
            let rn = !1,
                Ho = 0;
            const Gr = new Array(We);
            for (V = 0; V < We; V++) Gr[V] = 0;
            for (V = B; V <= z; V++) {
                const ht = L[V];
                if (ke >= We) {
                    Ie(ht, P, F, !0);
                    continue
                }
                let Ft;
                if (ht.key != null) Ft = oe.get(ht.key);
                else
                    for (fe = Z; fe <= I; fe++)
                        if (Gr[fe - Z] === 0 && Ot(ht, g[fe])) {
                            Ft = fe;
                            break
                        }
                Ft === void 0 ? Ie(ht, P, F, !0) : (Gr[Ft - Z] = V + 1, Ft >= Ho ? Ho = Ft : rn = !0, E(ht, g[Ft], _, null, P, F, $, H, U), ke++)
            }
            const ou = rn ? uv(Gr) : mr;
            for (fe = ou.length - 1, V = We - 1; V >= 0; V--) {
                const ht = Z + V,
                    Ft = g[ht],
                    su = ht + 1 < re ? g[ht + 1].el : T;
                Gr[V] === 0 ? E(null, Ft, _, su, P, F, $, H, U) : rn && (fe < 0 || V !== ou[fe] ? je(Ft, _, su, 2) : fe--)
            }
        }
    }, je = (L, g, _, T, P = null) => {
        const {
            el: F,
            type: $,
            transition: H,
            children: U,
            shapeFlag: V
        } = L;
        if (V & 6) {
            je(L.component.subTree, g, _, T);
            return
        }
        if (V & 128) {
            L.suspense.move(g, _, T);
            return
        }
        if (V & 64) {
            $.move(L, g, _, G);
            return
        }
        if ($ === Fe) {
            r(F, g, _);
            for (let z = 0; z < U.length; z++) je(U[z], g, _, T);
            r(L.anchor, g, _);
            return
        }
        if ($ === vr) {
            m(L, g, _);
            return
        }
        if (T !== 2 && V & 1 && H)
            if (T === 0) H.beforeEnter(F), r(F, g, _), Xe(() => H.enter(F), P);
            else {
                const {
                    leave: z,
                    delayLeave: I,
                    afterLeave: B
                } = H, Z = () => r(F, g, _), oe = () => {
                    z(F, () => {
                        Z(), B && B()
                    })
                };
                I ? I(F, Z, oe) : oe()
            }
        else r(F, g, _)
    }, Ie = (L, g, _, T = !1, P = !1) => {
        const {
            type: F,
            props: $,
            ref: H,
            children: U,
            dynamicChildren: V,
            shapeFlag: re,
            patchFlag: z,
            dirs: I
        } = L;
        if (H != null && Ki(H, null, _, L, !0), re & 256) {
            g.ctx.deactivate(L);
            return
        }
        const B = re & 1 && I,
            Z = !Xn(L);
        let oe;
        if (Z && (oe = $ && $.onVnodeBeforeUnmount) && ct(oe, g, L), re & 6) xn(L.component, _, T);
        else {
            if (re & 128) {
                L.suspense.unmount(_, T);
                return
            }
            B && $t(L, null, g, "beforeUnmount"), re & 64 ? L.type.remove(L, g, _, P, G, T) : V && (F !== Fe || z > 0 && z & 64) ? $e(V, g, _, !1, !0) : (F === Fe && z & 384 || !P && re & 16) && $e(U, g, _), T && Me(L)
        }(Z && (oe = $ && $.onVnodeUnmounted) || B) && Xe(() => {
            oe && ct(oe, g, L), B && $t(L, null, g, "unmounted")
        }, _)
    }, Me = L => {
        const {
            type: g,
            el: _,
            anchor: T,
            transition: P
        } = L;
        if (g === Fe) {
            Tt(_, T);
            return
        }
        if (g === vr) {
            y(L);
            return
        }
        const F = () => {
            a(_), P && !P.persisted && P.afterLeave && P.afterLeave()
        };
        if (L.shapeFlag & 1 && P && !P.persisted) {
            const {
                leave: $,
                delayLeave: H
            } = P, U = () => $(_, F);
            H ? H(L.el, F, U) : U()
        } else F()
    }, Tt = (L, g) => {
        let _;
        for (; L !== g;) _ = d(L), a(L), L = _;
        a(g)
    }, xn = (L, g, _) => {
        const {
            bum: T,
            scope: P,
            update: F,
            subTree: $,
            um: H
        } = L;
        T && oa(T), P.stop(), F && (F.active = !1, Ie($, L, g, _)), H && Xe(H, g), Xe(() => {
            L.isUnmounted = !0
        }, g), g && g.pendingBranch && !g.isUnmounted && L.asyncDep && !L.asyncResolved && L.suspenseId === g.pendingId && (g.deps--, g.deps === 0 && g.resolve())
    }, $e = (L, g, _, T = !1, P = !1, F = 0) => {
        for (let $ = F; $ < L.length; $++) Ie(L[$], g, _, T, P)
    }, j = L => L.shapeFlag & 6 ? j(L.component.subTree) : L.shapeFlag & 128 ? L.suspense.next() : d(L.anchor || L.el), q = (L, g, _) => {
        L == null ? g._vnode && Ie(g._vnode, null, null, !0) : E(g._vnode || null, L, g, null, null, null, _), gu(), Fi(), g._vnode = L
    }, G = {
        p: E,
        um: Ie,
        m: je,
        r: Me,
        mt: ne,
        mc: R,
        pc: X,
        pbc: N,
        n: j,
        o: e
    };
    let ee, ue;
    return t && ([ee, ue] = t(G)), {
        render: q,
        hydrate: ee,
        createApp: tv(q, ee)
    }
}

function In({
    effect: e,
    update: t
}, n) {
    e.allowRecurse = t.allowRecurse = n
}

function ah(e, t) {
    return (!e || e && !e.pendingBranch) && t && !t.persisted
}

function pc(e, t, n = !1) {
    const r = e.children,
        a = t.children;
    if (ie(r) && ie(a))
        for (let i = 0; i < r.length; i++) {
            const o = r[i];
            let s = a[i];
            s.shapeFlag & 1 && !s.dynamicChildren && ((s.patchFlag <= 0 || s.patchFlag === 32) && (s = a[i] = mn(a[i]), s.el = o.el), n || pc(o, s)), s.type === nr && (s.el = o.el)
        }
}

function uv(e) {
    const t = e.slice(),
        n = [0];
    let r, a, i, o, s;
    const l = e.length;
    for (r = 0; r < l; r++) {
        const c = e[r];
        if (c !== 0) {
            if (a = n[n.length - 1], e[a] < c) {
                t[r] = a, n.push(r);
                continue
            }
            for (i = 0, o = n.length - 1; i < o;) s = i + o >> 1, e[n[s]] < c ? i = s + 1 : o = s;
            c < e[n[i]] && (i > 0 && (t[r] = n[i - 1]), n[i] = r)
        }
    }
    for (i = n.length, o = n[i - 1]; i-- > 0;) n[i] = o, o = t[o];
    return n
}
const fv = e => e.__isTeleport,
    la = e => e && (e.disabled || e.disabled === ""),
    Ru = e => typeof SVGElement < "u" && e instanceof SVGElement,
    xs = (e, t) => {
        const n = e && e.to;
        return xe(n) ? t ? t(n) : null : n
    },
    dv = {
        name: "Teleport",
        __isTeleport: !0,
        process(e, t, n, r, a, i, o, s, l, c) {
            const {
                mc: u,
                pc: f,
                pbc: d,
                o: {
                    insert: p,
                    querySelector: v,
                    createText: E,
                    createComment: w
                }
            } = c, h = la(t.props);
            let {
                shapeFlag: b,
                children: m,
                dynamicChildren: y
            } = t;
            if (e == null) {
                const C = t.el = E(""),
                    S = t.anchor = E("");
                p(C, n, r), p(S, n, r);
                const A = t.target = xs(t.props, v),
                    R = t.targetAnchor = E("");
                A && (p(R, A), o = o || Ru(A));
                const O = (N, x) => {
                    b & 16 && u(m, N, x, a, i, o, s, l)
                };
                h ? O(n, S) : A && O(A, R)
            } else {
                t.el = e.el;
                const C = t.anchor = e.anchor,
                    S = t.target = e.target,
                    A = t.targetAnchor = e.targetAnchor,
                    R = la(e.props),
                    O = R ? n : S,
                    N = R ? C : A;
                if (o = o || Ru(S), y ? (d(e.dynamicChildren, y, O, a, i, o, s), pc(e, t, !0)) : l || f(e, t, O, N, a, i, o, s, !1), h) R ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : di(t, n, C, c, 1);
                else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                    const x = t.target = xs(t.props, v);
                    x && di(t, x, null, c, 0)
                } else R && di(t, S, A, c, 1)
            }
            ih(t)
        },
        remove(e, t, n, r, {
            um: a,
            o: {
                remove: i
            }
        }, o) {
            const {
                shapeFlag: s,
                children: l,
                anchor: c,
                targetAnchor: u,
                target: f,
                props: d
            } = e;
            if (f && i(u), o && i(c), s & 16) {
                const p = o || !la(d);
                for (let v = 0; v < l.length; v++) {
                    const E = l[v];
                    a(E, t, n, p, !!E.dynamicChildren)
                }
            }
        },
        move: di,
        hydrate: pv
    };

function di(e, t, n, {
    o: {
        insert: r
    },
    m: a
}, i = 2) {
    i === 0 && r(e.targetAnchor, t, n);
    const {
        el: o,
        anchor: s,
        shapeFlag: l,
        children: c,
        props: u
    } = e, f = i === 2;
    if (f && r(o, t, n), (!f || la(u)) && l & 16)
        for (let d = 0; d < c.length; d++) a(c[d], t, n, 2);
    f && r(s, t, n)
}

function pv(e, t, n, r, a, i, {
    o: {
        nextSibling: o,
        parentNode: s,
        querySelector: l
    }
}, c) {
    const u = t.target = xs(t.props, l);
    if (u) {
        const f = u._lpa || u.firstChild;
        if (t.shapeFlag & 16)
            if (la(t.props)) t.anchor = c(o(e), t, s(e), n, r, a, i), t.targetAnchor = f;
            else {
                t.anchor = o(e);
                let d = f;
                for (; d;)
                    if (d = o(d), d && d.nodeType === 8 && d.data === "teleport anchor") {
                        t.targetAnchor = d, u._lpa = t.targetAnchor && o(t.targetAnchor);
                        break
                    }
                c(f, t, u, n, r, a, i)
            }
        ih(t)
    }
    return t.anchor && o(t.anchor)
}
const hv = dv;

function ih(e) {
    const t = e.ctx;
    if (t && t.ut) {
        let n = e.children[0].el;
        for (; n && n !== e.targetAnchor;) n.nodeType === 1 && n.setAttribute("data-v-owner", t.uid), n = n.nextSibling;
        t.ut()
    }
}
const Fe = Symbol.for("v-fgt"),
    nr = Symbol.for("v-txt"),
    ot = Symbol.for("v-cmt"),
    vr = Symbol.for("v-stc"),
    ca = [];
let wt = null;

function le(e = !1) {
    ca.push(wt = e ? null : [])
}

function oh() {
    ca.pop(), wt = ca[ca.length - 1] || null
}
let Cr = 1;

function Ou(e) {
    Cr += e
}

function sh(e) {
    return e.dynamicChildren = Cr > 0 ? wt || mr : null, oh(), Cr > 0 && wt && wt.push(e), e
}

function Ke(e, t, n, r, a, i) {
    return sh(Xt(e, t, n, r, a, i, !0))
}

function Pe(e, t, n, r, a) {
    return sh(Ae(e, t, n, r, a, !0))
}

function Ar(e) {
    return e ? e.__v_isVNode === !0 : !1
}

function Ot(e, t) {
    return e.type === t.type && e.key === t.key
}
const yo = "__vInternal",
    lh = ({
        key: e
    }) => e ? ? null,
    Li = ({
        ref: e,
        ref_key: t,
        ref_for: n
    }) => (typeof e == "number" && (e = "" + e), e != null ? xe(e) || _e(e) || se(e) ? {
        i: qe,
        r: e,
        k: t,
        f: !!n
    } : e : null);

function Xt(e, t = null, n = null, r = 0, a = null, i = e === Fe ? 0 : 1, o = !1, s = !1) {
    const l = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e,
        props: t,
        key: t && lh(t),
        ref: t && Li(t),
        scopeId: ho,
        slotScopeIds: null,
        children: n,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag: i,
        patchFlag: r,
        dynamicProps: a,
        dynamicChildren: null,
        appContext: null,
        ctx: qe
    };
    return s ? (hc(l, n), i & 128 && e.normalize(l)) : n && (l.shapeFlag |= xe(n) ? 8 : 16), Cr > 0 && !o && wt && (l.patchFlag > 0 || i & 6) && l.patchFlag !== 32 && wt.push(l), l
}
const Ae = mv;

function mv(e, t = null, n = null, r = 0, a = null, i = !1) {
    if ((!e || e === Fp) && (e = ot), Ar(e)) {
        const s = tn(e, t, !0);
        return n && hc(s, n), Cr > 0 && !i && wt && (s.shapeFlag & 6 ? wt[wt.indexOf(e)] = s : wt.push(s)), s.patchFlag |= -2, s
    }
    if (Ev(e) && (e = e.__vccOpts), t) {
        t = bo(t);
        let {
            class: s,
            style: l
        } = t;
        s && !xe(s) && (t.class = Le(s)), Te(l) && (kp(l) && !ie(l) && (l = Ge({}, l)), t.style = er(l))
    }
    const o = xe(e) ? 1 : Bp(e) ? 128 : fv(e) ? 64 : Te(e) ? 4 : se(e) ? 2 : 0;
    return Xt(e, t, n, r, a, o, i, !0)
}

function bo(e) {
    return e ? kp(e) || yo in e ? Ge({}, e) : e : null
}

function tn(e, t, n = !1) {
    const {
        props: r,
        ref: a,
        patchFlag: i,
        children: o
    } = e, s = t ? it(r || {}, t) : r;
    return {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e.type,
        props: s,
        key: s && lh(s),
        ref: t && t.ref ? n && a ? ie(a) ? a.concat(Li(t)) : [a, Li(t)] : Li(t) : a,
        scopeId: e.scopeId,
        slotScopeIds: e.slotScopeIds,
        children: o,
        target: e.target,
        targetAnchor: e.targetAnchor,
        staticCount: e.staticCount,
        shapeFlag: e.shapeFlag,
        patchFlag: t && e.type !== Fe ? i === -1 ? 16 : i | 16 : i,
        dynamicProps: e.dynamicProps,
        dynamicChildren: e.dynamicChildren,
        appContext: e.appContext,
        dirs: e.dirs,
        transition: e.transition,
        component: e.component,
        suspense: e.suspense,
        ssContent: e.ssContent && tn(e.ssContent),
        ssFallback: e.ssFallback && tn(e.ssFallback),
        el: e.el,
        anchor: e.anchor,
        ctx: e.ctx,
        ce: e.ce
    }
}

function La(e = " ", t = 0) {
    return Ae(nr, null, e, t)
}

function _P(e, t) {
    const n = Ae(vr, null, e);
    return n.staticCount = t, n
}

function ft(e = "", t = !1) {
    return t ? (le(), Pe(ot, null, e)) : Ae(ot, null, e)
}

function vt(e) {
    return e == null || typeof e == "boolean" ? Ae(ot) : ie(e) ? Ae(Fe, null, e.slice()) : typeof e == "object" ? mn(e) : Ae(nr, null, String(e))
}

function mn(e) {
    return e.el === null && e.patchFlag !== -1 || e.memo ? e : tn(e)
}

function hc(e, t) {
    let n = 0;
    const {
        shapeFlag: r
    } = e;
    if (t == null) t = null;
    else if (ie(t)) n = 16;
    else if (typeof t == "object")
        if (r & 65) {
            const a = t.default;
            a && (a._c && (a._d = !1), hc(e, a()), a._c && (a._d = !0));
            return
        } else {
            n = 32;
            const a = t._;
            !a && !(yo in t) ? t._ctx = qe : a === 3 && qe && (qe.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
        }
    else se(t) ? (t = {
        default: t,
        _ctx: qe
    }, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [La(t)]) : n = 8);
    e.children = t, e.shapeFlag |= n
}

function it(...e) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
        const r = e[n];
        for (const a in r)
            if (a === "class") t.class !== r.class && (t.class = Le([t.class, r.class]));
            else if (a === "style") t.style = er([t.style, r.style]);
        else if (ja(a)) {
            const i = t[a],
                o = r[a];
            o && i !== o && !(ie(i) && i.includes(o)) && (t[a] = i ? [].concat(i, o) : o)
        } else a !== "" && (t[a] = r[a])
    }
    return t
}

function ct(e, t, n, r = null) {
    Ct(e, t, 7, [n, r])
}
const gv = Xp();
let yv = 0;

function bv(e, t, n) {
    const r = e.type,
        a = (t ? t.appContext : e.appContext) || gv,
        i = {
            uid: yv++,
            vnode: e,
            type: r,
            parent: t,
            appContext: a,
            root: null,
            next: null,
            subTree: null,
            effect: null,
            update: null,
            scope: new yp(!0),
            render: null,
            proxy: null,
            exposed: null,
            exposeProxy: null,
            withProxy: null,
            provides: t ? t.provides : Object.create(a.provides),
            accessCache: null,
            renderCache: [],
            components: null,
            directives: null,
            propsOptions: Zp(r, a),
            emitsOptions: Dp(r, a),
            emit: null,
            emitted: null,
            propsDefaults: Oe,
            inheritAttrs: r.inheritAttrs,
            ctx: Oe,
            data: Oe,
            props: Oe,
            attrs: Oe,
            slots: Oe,
            refs: Oe,
            setupState: Oe,
            setupContext: null,
            attrsProxy: null,
            slotsProxy: null,
            suspense: n,
            suspenseId: n ? n.pendingId : 0,
            asyncDep: null,
            asyncResolved: !1,
            isMounted: !1,
            isUnmounted: !1,
            isDeactivated: !1,
            bc: null,
            c: null,
            bm: null,
            m: null,
            bu: null,
            u: null,
            um: null,
            bum: null,
            da: null,
            a: null,
            rtg: null,
            rtc: null,
            ec: null,
            sp: null
        };
    return i.ctx = {
        _: i
    }, i.root = t ? t.root : i, i.emit = vb.bind(null, i), e.ce && e.ce(i), i
}
let Ve = null;
const yt = () => Ve || qe;
let mc, ur, Mu = "__VUE_INSTANCE_SETTERS__";
(ur = Es()[Mu]) || (ur = Es()[Mu] = []), ur.push(e => Ve = e), mc = e => {
    ur.length > 1 ? ur.forEach(t => t(e)) : ur[0](e)
};
const Tn = e => {
        mc(e), e.scope.on()
    },
    En = () => {
        Ve && Ve.scope.off(), mc(null)
    };

function ch(e) {
    return e.vnode.shapeFlag & 4
}
let Lr = !1;

function vv(e, t = !1) {
    Lr = t;
    const {
        props: n,
        children: r
    } = e.vnode, a = ch(e);
    nv(e, n, a, t), iv(e, r);
    const i = a ? _v(e, t) : void 0;
    return Lr = !1, i
}

function _v(e, t) {
    const n = e.type;
    e.accessCache = Object.create(null), e.proxy = uo(new Proxy(e.ctx, Jb));
    const {
        setup: r
    } = n;
    if (r) {
        const a = e.setupContext = r.length > 1 ? fh(e) : null;
        Tn(e), Fr();
        const i = wn(r, e, 0, [e.props, a]);
        if (Br(), En(), Ul(i)) {
            if (i.then(En, En), t) return i.then(o => {
                Is(e, o, t)
            }).catch(o => {
                jr(o, e, 0)
            });
            e.asyncDep = i
        } else Is(e, i, t)
    } else uh(e, t)
}

function Is(e, t, n) {
    se(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : Te(t) && (e.setupState = Op(t)), uh(e, n)
}
let Pu;

function uh(e, t, n) {
    const r = e.type;
    if (!e.render) {
        if (!t && Pu && !r.render) {
            const a = r.template || uc(e).template;
            if (a) {
                const {
                    isCustomElement: i,
                    compilerOptions: o
                } = e.appContext.config, {
                    delimiters: s,
                    compilerOptions: l
                } = r, c = Ge(Ge({
                    isCustomElement: i,
                    delimiters: s
                }, o), l);
                r.render = Pu(a, c)
            }
        }
        e.render = r.render || Pt
    } {
        Tn(e), Fr();
        try {
            qb(e)
        } finally {
            Br(), En()
        }
    }
}

function wv(e) {
    return e.attrsProxy || (e.attrsProxy = new Proxy(e.attrs, {
        get(t, n) {
            return dt(e, "get", "$attrs"), t[n]
        }
    }))
}

function fh(e) {
    const t = n => {
        e.exposed = n || {}
    };
    return {
        get attrs() {
            return wv(e)
        },
        slots: e.slots,
        emit: e.emit,
        expose: t
    }
}

function vo(e) {
    if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(Op(uo(e.exposed)), {
        get(t, n) {
            if (n in t) return t[n];
            if (n in sa) return sa[n](e)
        },
        has(t, n) {
            return n in t || n in sa
        }
    }))
}

function Ds(e, t = !0) {
    return se(e) ? e.displayName || e.name : e.name || t && e.__name
}

function Ev(e) {
    return se(e) && "__vccOpts" in e
}
const W = (e, t) => hb(e, t, Lr);

function Be(e, t, n) {
    const r = arguments.length;
    return r === 2 ? Te(t) && !ie(t) ? Ar(t) ? Ae(e, null, [t]) : Ae(e, t) : Ae(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && Ar(n) && (n = [n]), Ae(e, t, n))
}
const Cv = Symbol.for("v-scx"),
    Av = () => Je(Cv),
    dh = "3.3.11",
    Lv = "http://www.w3.org/2000/svg",
    Un = typeof document < "u" ? document : null,
    xu = Un && Un.createElement("template"),
    Sv = {
        insert: (e, t, n) => {
            t.insertBefore(e, n || null)
        },
        remove: e => {
            const t = e.parentNode;
            t && t.removeChild(e)
        },
        createElement: (e, t, n, r) => {
            const a = t ? Un.createElementNS(Lv, e) : Un.createElement(e, n ? {
                is: n
            } : void 0);
            return e === "select" && r && r.multiple != null && a.setAttribute("multiple", r.multiple), a
        },
        createText: e => Un.createTextNode(e),
        createComment: e => Un.createComment(e),
        setText: (e, t) => {
            e.nodeValue = t
        },
        setElementText: (e, t) => {
            e.textContent = t
        },
        parentNode: e => e.parentNode,
        nextSibling: e => e.nextSibling,
        querySelector: e => Un.querySelector(e),
        setScopeId(e, t) {
            e.setAttribute(t, "")
        },
        insertStaticContent(e, t, n, r, a, i) {
            const o = n ? n.previousSibling : t.lastChild;
            if (a && (a === i || a.nextSibling))
                for (; t.insertBefore(a.cloneNode(!0), n), !(a === i || !(a = a.nextSibling)););
            else {
                xu.innerHTML = r ? `<svg>${e}</svg>` : e;
                const s = xu.content;
                if (r) {
                    const l = s.firstChild;
                    for (; l.firstChild;) s.appendChild(l.firstChild);
                    s.removeChild(l)
                }
                t.insertBefore(s, n)
            }
            return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
        }
    },
    sn = "transition",
    Wr = "animation",
    Sa = Symbol("_vtc"),
    Ga = (e, {
        slots: t
    }) => Be(Db, Tv(e), t);
Ga.displayName = "Transition";
const ph = {
    name: String,
    type: String,
    css: {
        type: Boolean,
        default: !0
    },
    duration: [String, Number, Object],
    enterFromClass: String,
    enterActiveClass: String,
    enterToClass: String,
    appearFromClass: String,
    appearActiveClass: String,
    appearToClass: String,
    leaveFromClass: String,
    leaveActiveClass: String,
    leaveToClass: String
};
Ga.props = Ge({}, Vp, ph);
const Dn = (e, t = []) => {
        ie(e) ? e.forEach(n => n(...t)) : e && e(...t)
    },
    Iu = e => e ? ie(e) ? e.some(t => t.length > 1) : e.length > 1 : !1;

function Tv(e) {
    const t = {};
    for (const M in e) M in ph || (t[M] = e[M]);
    if (e.css === !1) return t;
    const {
        name: n = "v",
        type: r,
        duration: a,
        enterFromClass: i = `${n}-enter-from`,
        enterActiveClass: o = `${n}-enter-active`,
        enterToClass: s = `${n}-enter-to`,
        appearFromClass: l = i,
        appearActiveClass: c = o,
        appearToClass: u = s,
        leaveFromClass: f = `${n}-leave-from`,
        leaveActiveClass: d = `${n}-leave-active`,
        leaveToClass: p = `${n}-leave-to`
    } = e, v = kv(a), E = v && v[0], w = v && v[1], {
        onBeforeEnter: h,
        onEnter: b,
        onEnterCancelled: m,
        onLeave: y,
        onLeaveCancelled: C,
        onBeforeAppear: S = h,
        onAppear: A = b,
        onAppearCancelled: R = m
    } = t, O = (M, K, ne) => {
        Nn(M, K ? u : s), Nn(M, K ? c : o), ne && ne()
    }, N = (M, K) => {
        M._isLeaving = !1, Nn(M, f), Nn(M, p), Nn(M, d), K && K()
    }, x = M => (K, ne) => {
        const te = M ? A : b,
            J = () => O(K, M, ne);
        Dn(te, [K, J]), Du(() => {
            Nn(K, M ? l : i), ln(K, M ? u : s), Iu(te) || Nu(K, r, E, J)
        })
    };
    return Ge(t, {
        onBeforeEnter(M) {
            Dn(h, [M]), ln(M, i), ln(M, o)
        },
        onBeforeAppear(M) {
            Dn(S, [M]), ln(M, l), ln(M, c)
        },
        onEnter: x(!1),
        onAppear: x(!0),
        onLeave(M, K) {
            M._isLeaving = !0;
            const ne = () => N(M, K);
            ln(M, f), Mv(), ln(M, d), Du(() => {
                M._isLeaving && (Nn(M, f), ln(M, p), Iu(y) || Nu(M, r, w, ne))
            }), Dn(y, [M, ne])
        },
        onEnterCancelled(M) {
            O(M, !1), Dn(m, [M])
        },
        onAppearCancelled(M) {
            O(M, !0), Dn(R, [M])
        },
        onLeaveCancelled(M) {
            N(M), Dn(C, [M])
        }
    })
}

function kv(e) {
    if (e == null) return null;
    if (Te(e)) return [Qo(e.enter), Qo(e.leave)]; {
        const t = Qo(e);
        return [t, t]
    }
}

function Qo(e) {
    return hp(e)
}

function ln(e, t) {
    t.split(/\s+/).forEach(n => n && e.classList.add(n)), (e[Sa] || (e[Sa] = new Set)).add(t)
}

function Nn(e, t) {
    t.split(/\s+/).forEach(r => r && e.classList.remove(r));
    const n = e[Sa];
    n && (n.delete(t), n.size || (e[Sa] = void 0))
}

function Du(e) {
    requestAnimationFrame(() => {
        requestAnimationFrame(e)
    })
}
let Rv = 0;

function Nu(e, t, n, r) {
    const a = e._endId = ++Rv,
        i = () => {
            a === e._endId && r()
        };
    if (n) return setTimeout(i, n);
    const {
        type: o,
        timeout: s,
        propCount: l
    } = Ov(e, t);
    if (!o) return r();
    const c = o + "end";
    let u = 0;
    const f = () => {
            e.removeEventListener(c, d), i()
        },
        d = p => {
            p.target === e && ++u >= l && f()
        };
    setTimeout(() => {
        u < l && f()
    }, s + 1), e.addEventListener(c, d)
}

function Ov(e, t) {
    const n = window.getComputedStyle(e),
        r = v => (n[v] || "").split(", "),
        a = r(`${sn}Delay`),
        i = r(`${sn}Duration`),
        o = Fu(a, i),
        s = r(`${Wr}Delay`),
        l = r(`${Wr}Duration`),
        c = Fu(s, l);
    let u = null,
        f = 0,
        d = 0;
    t === sn ? o > 0 && (u = sn, f = o, d = i.length) : t === Wr ? c > 0 && (u = Wr, f = c, d = l.length) : (f = Math.max(o, c), u = f > 0 ? o > c ? sn : Wr : null, d = u ? u === sn ? i.length : l.length : 0);
    const p = u === sn && /\b(transform|all)(,|$)/.test(r(`${sn}Property`).toString());
    return {
        type: u,
        timeout: f,
        propCount: d,
        hasTransform: p
    }
}

function Fu(e, t) {
    for (; e.length < t.length;) e = e.concat(e);
    return Math.max(...t.map((n, r) => Bu(n) + Bu(e[r])))
}

function Bu(e) {
    return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3
}

function Mv() {
    return document.body.offsetHeight
}

function Pv(e, t, n) {
    const r = e[Sa];
    r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
}
const xv = Symbol("_vod");

function Iv(e, t, n) {
    const r = e.style,
        a = xe(n);
    if (n && !a) {
        if (t && !xe(t))
            for (const i in t) n[i] == null && Ns(r, i, "");
        for (const i in n) Ns(r, i, n[i])
    } else {
        const i = r.display;
        a ? t !== n && (r.cssText = n) : t && e.removeAttribute("style"), xv in e && (r.display = i)
    }
}
const ju = /\s*!important$/;

function Ns(e, t, n) {
    if (ie(n)) n.forEach(r => Ns(e, t, r));
    else if (n == null && (n = ""), t.startsWith("--")) e.setProperty(t, n);
    else {
        const r = Dv(e, t);
        ju.test(n) ? e.setProperty(ar(r), n.replace(ju, ""), "important") : e[r] = n
    }
}
const $u = ["Webkit", "Moz", "ms"],
    Zo = {};

function Dv(e, t) {
    const n = Zo[t];
    if (n) return n;
    let r = Ut(t);
    if (r !== "filter" && r in e) return Zo[t] = r;
    r = so(r);
    for (let a = 0; a < $u.length; a++) {
        const i = $u[a] + r;
        if (i in e) return Zo[t] = i
    }
    return t
}
const Vu = "http://www.w3.org/1999/xlink";

function Nv(e, t, n, r, a) {
    if (r && t.startsWith("xlink:")) n == null ? e.removeAttributeNS(Vu, t.slice(6, t.length)) : e.setAttributeNS(Vu, t, n);
    else {
        const i = Fy(t);
        n == null || i && !mp(n) ? e.removeAttribute(t) : e.setAttribute(t, i ? "" : n)
    }
}

function Fv(e, t, n, r, a, i, o) {
    if (t === "innerHTML" || t === "textContent") {
        r && o(r, a, i), e[t] = n ? ? "";
        return
    }
    const s = e.tagName;
    if (t === "value" && s !== "PROGRESS" && !s.includes("-")) {
        e._value = n;
        const c = s === "OPTION" ? e.getAttribute("value") : e.value,
            u = n ? ? "";
        c !== u && (e.value = u), n == null && e.removeAttribute(t);
        return
    }
    let l = !1;
    if (n === "" || n == null) {
        const c = typeof e[t];
        c === "boolean" ? n = mp(n) : n == null && c === "string" ? (n = "", l = !0) : c === "number" && (n = 0, l = !0)
    }
    try {
        e[t] = n
    } catch {}
    l && e.removeAttribute(t)
}

function Bv(e, t, n, r) {
    e.addEventListener(t, n, r)
}

function jv(e, t, n, r) {
    e.removeEventListener(t, n, r)
}
const Hu = Symbol("_vei");

function $v(e, t, n, r, a = null) {
    const i = e[Hu] || (e[Hu] = {}),
        o = i[t];
    if (r && o) o.value = r;
    else {
        const [s, l] = Vv(t);
        if (r) {
            const c = i[t] = Uv(r, a);
            Bv(e, s, c, l)
        } else o && (jv(e, s, o, l), i[t] = void 0)
    }
}
const Ku = /(?:Once|Passive|Capture)$/;

function Vv(e) {
    let t;
    if (Ku.test(e)) {
        t = {};
        let r;
        for (; r = e.match(Ku);) e = e.slice(0, e.length - r[0].length), t[r[0].toLowerCase()] = !0
    }
    return [e[2] === ":" ? e.slice(3) : ar(e.slice(2)), t]
}
let es = 0;
const Hv = Promise.resolve(),
    Kv = () => es || (Hv.then(() => es = 0), es = Date.now());

function Uv(e, t) {
    const n = r => {
        if (!r._vts) r._vts = Date.now();
        else if (r._vts <= n.attached) return;
        Ct(Jv(r, n.value), t, 5, [r])
    };
    return n.value = e, n.attached = Kv(), n
}

function Jv(e, t) {
    if (ie(t)) {
        const n = e.stopImmediatePropagation;
        return e.stopImmediatePropagation = () => {
            n.call(e), e._stopped = !0
        }, t.map(r => a => !a._stopped && r && r(a))
    } else return t
}
const Uu = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123,
    Gv = (e, t, n, r, a = !1, i, o, s, l) => {
        t === "class" ? Pv(e, r, a) : t === "style" ? Iv(e, n, r) : ja(t) ? Hl(t) || $v(e, t, n, r, o) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Wv(e, t, r, a)) ? Fv(e, t, r, i, o, s, l) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), Nv(e, t, r, a))
    };

function Wv(e, t, n, r) {
    if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Uu(t) && se(n));
    if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
    if (t === "width" || t === "height") {
        const a = e.tagName;
        if (a === "IMG" || a === "VIDEO" || a === "CANVAS" || a === "SOURCE") return !1
    }
    return Uu(t) && xe(n) ? !1 : t in e
}

function wP(e) {
    const t = yt();
    if (!t) return;
    const n = t.ut = (a = e(t.proxy)) => {
            Array.from(document.querySelectorAll(`[data-v-owner="${t.uid}"]`)).forEach(i => Bs(i, a))
        },
        r = () => {
            const a = e(t.proxy);
            Fs(t.subTree, a), n(a)
        };
    Mb(r), Jt(() => {
        const a = new MutationObserver(r);
        a.observe(t.subTree.el.parentNode, {
            childList: !0
        }), Rn(() => a.disconnect())
    })
}

function Fs(e, t) {
    if (e.shapeFlag & 128) {
        const n = e.suspense;
        e = n.activeBranch, n.pendingBranch && !n.isHydrating && n.effects.push(() => {
            Fs(n.activeBranch, t)
        })
    }
    for (; e.component;) e = e.component.subTree;
    if (e.shapeFlag & 1 && e.el) Bs(e.el, t);
    else if (e.type === Fe) e.children.forEach(n => Fs(n, t));
    else if (e.type === vr) {
        let {
            el: n,
            anchor: r
        } = e;
        for (; n && (Bs(n, t), n !== r);) n = n.nextSibling
    }
}

function Bs(e, t) {
    if (e.nodeType === 1) {
        const n = e.style;
        for (const r in t) n.setProperty(`--${r}`, t[r])
    }
}
const zv = ["ctrl", "shift", "alt", "meta"],
    qv = {
        stop: e => e.stopPropagation(),
        prevent: e => e.preventDefault(),
        self: e => e.target !== e.currentTarget,
        ctrl: e => !e.ctrlKey,
        shift: e => !e.shiftKey,
        alt: e => !e.altKey,
        meta: e => !e.metaKey,
        left: e => "button" in e && e.button !== 0,
        middle: e => "button" in e && e.button !== 1,
        right: e => "button" in e && e.button !== 2,
        exact: (e, t) => zv.some(n => e[`${n}Key`] && !t.includes(n))
    },
    ts = (e, t) => e._withMods || (e._withMods = (n, ...r) => {
        for (let a = 0; a < t.length; a++) {
            const i = qv[t[a]];
            if (i && i(n, t)) return
        }
        return e(n, ...r)
    }),
    Yv = {
        esc: "escape",
        space: " ",
        up: "arrow-up",
        left: "arrow-left",
        right: "arrow-right",
        down: "arrow-down",
        delete: "backspace"
    },
    EP = (e, t) => e._withKeys || (e._withKeys = n => {
        if (!("key" in n)) return;
        const r = ar(n.key);
        if (t.some(a => a === r || Yv[a] === r)) return e(n)
    }),
    hh = Ge({
        patchProp: Gv
    }, Sv);
let ua, Ju = !1;

function Xv() {
    return ua || (ua = lv(hh))
}

function Qv() {
    return ua = Ju ? ua : cv(hh), Ju = !0, ua
}
const Zv = (...e) => {
        const t = Xv().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = r => {
            const a = mh(r);
            if (!a) return;
            const i = t._component;
            !se(i) && !i.render && !i.template && (i.template = a.innerHTML), a.innerHTML = "";
            const o = n(a, !1, a instanceof SVGElement);
            return a instanceof Element && (a.removeAttribute("v-cloak"), a.setAttribute("data-v-app", "")), o
        }, t
    },
    e0 = (...e) => {
        const t = Qv().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = r => {
            const a = mh(r);
            if (a) return n(a, !0, a instanceof SVGElement)
        }, t
    };

function mh(e) {
    return xe(e) ? document.querySelector(e) : e
}
const t0 = /#/g,
    n0 = /&/g,
    r0 = /=/g,
    gc = /\+/g,
    a0 = /%5e/gi,
    i0 = /%60/gi,
    o0 = /%7c/gi,
    s0 = /%20/gi;

function l0(e) {
    return encodeURI("" + e).replace(o0, "|")
}

function js(e) {
    return l0(typeof e == "string" ? e : JSON.stringify(e)).replace(gc, "%2B").replace(s0, "+").replace(t0, "%23").replace(n0, "%26").replace(i0, "`").replace(a0, "^")
}

function ns(e) {
    return js(e).replace(r0, "%3D")
}

function Ui(e = "") {
    try {
        return decodeURIComponent("" + e)
    } catch {
        return "" + e
    }
}

function c0(e) {
    return Ui(e.replace(gc, " "))
}

function u0(e) {
    return Ui(e.replace(gc, " "))
}

function gh(e = "") {
    const t = {};
    e[0] === "?" && (e = e.slice(1));
    for (const n of e.split("&")) {
        const r = n.match(/([^=]+)=?(.*)/) || [];
        if (r.length < 2) continue;
        const a = c0(r[1]);
        if (a === "__proto__" || a === "constructor") continue;
        const i = u0(r[2] || "");
        t[a] === void 0 ? t[a] = i : Array.isArray(t[a]) ? t[a].push(i) : t[a] = [t[a], i]
    }
    return t
}

function f0(e, t) {
    return (typeof t == "number" || typeof t == "boolean") && (t = String(t)), t ? Array.isArray(t) ? t.map(n => `${ns(e)}=${js(n)}`).join("&") : `${ns(e)}=${js(t)}` : ns(e)
}

function d0(e) {
    return Object.keys(e).filter(t => e[t] !== void 0).map(t => f0(t, e[t])).filter(Boolean).join("&")
}
const p0 = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/,
    h0 = /^[\s\w\0+.-]{2,}:([/\\]{2})?/,
    m0 = /^([/\\]\s*){2,}[^/\\]/;

function or(e, t = {}) {
    return typeof t == "boolean" && (t = {
        acceptRelative: t
    }), t.strict ? p0.test(e) : h0.test(e) || (t.acceptRelative ? m0.test(e) : !1)
}
const g0 = /^[\s\0]*(blob|data|javascript|vbscript):$/i;

function y0(e) {
    return !!e && g0.test(e)
}
const b0 = /\/$|\/\?|\/#/;

function $s(e = "", t) {
    return t ? b0.test(e) : e.endsWith("/")
}

function yc(e = "", t) {
    if (!t) return ($s(e) ? e.slice(0, -1) : e) || "/";
    if (!$s(e, !0)) return e || "/";
    let n = e,
        r = "";
    const a = e.indexOf("#");
    a >= 0 && (n = e.slice(0, a), r = e.slice(a));
    const [i, ...o] = n.split("?");
    return (i.slice(0, -1) || "/") + (o.length > 0 ? `?${o.join("?")}` : "") + r
}

function Ji(e = "", t) {
    if (!t) return e.endsWith("/") ? e : e + "/";
    if ($s(e, !0)) return e || "/";
    let n = e,
        r = "";
    const a = e.indexOf("#");
    if (a >= 0 && (n = e.slice(0, a), r = e.slice(a), !n)) return r;
    const [i, ...o] = n.split("?");
    return i + "/" + (o.length > 0 ? `?${o.join("?")}` : "") + r
}

function v0(e = "") {
    return e.startsWith("/")
}

function Gu(e = "") {
    return v0(e) ? e : "/" + e
}

function _0(e, t) {
    if (bh(t) || or(e)) return e;
    const n = yc(t);
    return e.startsWith(n) ? e : $r(n, e)
}

function Wu(e, t) {
    if (bh(t)) return e;
    const n = yc(t);
    if (!e.startsWith(n)) return e;
    const r = e.slice(n.length);
    return r[0] === "/" ? r : "/" + r
}

function yh(e, t) {
    const n = _o(e),
        r = { ...gh(n.search),
            ...t
        };
    return n.search = d0(r), C0(n)
}

function bh(e) {
    return !e || e === "/"
}

function w0(e) {
    return e && e !== "/"
}
const E0 = /^\.?\//;

function $r(e, ...t) {
    let n = e || "";
    for (const r of t.filter(a => w0(a)))
        if (n) {
            const a = r.replace(E0, "");
            n = Ji(n) + a
        } else n = r;
    return n
}

function Vs(e, t, n = {}) {
    return n.trailingSlash || (e = Ji(e), t = Ji(t)), n.leadingSlash || (e = Gu(e), t = Gu(t)), n.encoding || (e = Ui(e), t = Ui(t)), e === t
}

function _o(e = "", t) {
    const n = e.match(/^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i);
    if (n) {
        const [, f, d = ""] = n;
        return {
            protocol: f.toLowerCase(),
            pathname: d,
            href: f + d,
            auth: "",
            host: "",
            search: "",
            hash: ""
        }
    }
    if (!or(e, {
            acceptRelative: !0
        })) return t ? _o(t + e) : zu(e);
    const [, r = "", a, i = ""] = e.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [], [, o = "", s = ""] = i.match(/([^#/?]*)(.*)?/) || [], {
        pathname: l,
        search: c,
        hash: u
    } = zu(s.replace(/\/(?=[A-Za-z]:)/, ""));
    return {
        protocol: r.toLowerCase(),
        auth: a ? a.slice(0, Math.max(0, a.length - 1)) : "",
        host: o,
        pathname: l,
        search: c,
        hash: u
    }
}

function zu(e = "") {
    const [t = "", n = "", r = ""] = (e.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
    return {
        pathname: t,
        search: n,
        hash: r
    }
}

function C0(e) {
    const t = e.pathname || "",
        n = e.search ? (e.search.startsWith("?") ? "" : "?") + e.search : "",
        r = e.hash || "",
        a = e.auth ? e.auth + "@" : "",
        i = e.host || "";
    return (e.protocol ? e.protocol + "//" : "") + a + i + t + n + r
}
const A0 = () => {
        var e;
        return ((e = window == null ? void 0 : window.__NUXT__) == null ? void 0 : e.config) || {}
    },
    Gi = A0().app,
    L0 = () => Gi.baseURL,
    S0 = () => Gi.buildAssetsDir,
    bc = (...e) => $r(vh(), S0(), ...e),
    vh = (...e) => {
        const t = Gi.cdnURL || Gi.baseURL;
        return e.length ? $r(t, ...e) : t
    };
globalThis.__buildAssetsURL = bc, globalThis.__publicAssetsURL = vh;
const T0 = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/,
    k0 = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/,
    R0 = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;

function O0(e, t) {
    if (e === "__proto__" || e === "constructor" && t && typeof t == "object" && "prototype" in t) {
        M0(e);
        return
    }
    return t
}

function M0(e) {
    console.warn(`[destr] Dropping "${e}" key to prevent prototype pollution.`)
}

function Ta(e, t = {}) {
    if (typeof e != "string") return e;
    const n = e.trim();
    if (e[0] === '"' && e.at(-1) === '"' && !e.includes("\\")) return n.slice(1, -1);
    if (n.length <= 9) {
        const r = n.toLowerCase();
        if (r === "true") return !0;
        if (r === "false") return !1;
        if (r === "undefined") return;
        if (r === "null") return null;
        if (r === "nan") return Number.NaN;
        if (r === "infinity") return Number.POSITIVE_INFINITY;
        if (r === "-infinity") return Number.NEGATIVE_INFINITY
    }
    if (!R0.test(e)) {
        if (t.strict) throw new SyntaxError("[destr] Invalid JSON");
        return e
    }
    try {
        if (T0.test(e) || k0.test(e)) {
            if (t.strict) throw new Error("[destr] Possible prototype pollution");
            return JSON.parse(e, O0)
        }
        return JSON.parse(e)
    } catch (r) {
        if (t.strict) throw r;
        return e
    }
}
class P0 extends Error {
    constructor(t, n) {
        super(t, n), this.name = "FetchError", n != null && n.cause && !this.cause && (this.cause = n.cause)
    }
}

function x0(e) {
    var l, c, u, f, d;
    const t = ((l = e.error) == null ? void 0 : l.message) || ((c = e.error) == null ? void 0 : c.toString()) || "",
        n = ((u = e.request) == null ? void 0 : u.method) || ((f = e.options) == null ? void 0 : f.method) || "GET",
        r = ((d = e.request) == null ? void 0 : d.url) || String(e.request) || "/",
        a = `[${n}] ${JSON.stringify(r)}`,
        i = e.response ? `${e.response.status} ${e.response.statusText}` : "<no response>",
        o = `${a}: ${i}${t?` ${t}`:""}`,
        s = new P0(o, e.error ? {
            cause: e.error
        } : void 0);
    for (const p of ["request", "options", "response"]) Object.defineProperty(s, p, {
        get() {
            return e[p]
        }
    });
    for (const [p, v] of [
            ["data", "_data"],
            ["status", "status"],
            ["statusCode", "status"],
            ["statusText", "statusText"],
            ["statusMessage", "statusText"]
        ]) Object.defineProperty(s, p, {
        get() {
            return e.response && e.response[v]
        }
    });
    return s
}
const I0 = new Set(Object.freeze(["PATCH", "POST", "PUT", "DELETE"]));

function qu(e = "GET") {
    return I0.has(e.toUpperCase())
}

function D0(e) {
    if (e === void 0) return !1;
    const t = typeof e;
    return t === "string" || t === "number" || t === "boolean" || t === null ? !0 : t !== "object" ? !1 : Array.isArray(e) ? !0 : e.buffer ? !1 : e.constructor && e.constructor.name === "Object" || typeof e.toJSON == "function"
}
const N0 = new Set(["image/svg", "application/xml", "application/xhtml", "application/html"]),
    F0 = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;

function B0(e = "") {
    if (!e) return "json";
    const t = e.split(";").shift() || "";
    return F0.test(t) ? "json" : N0.has(t) || t.startsWith("text/") ? "text" : "blob"
}

function j0(e, t, n = globalThis.Headers) {
    const r = { ...t,
        ...e
    };
    if (t != null && t.params && (e != null && e.params) && (r.params = { ...t == null ? void 0 : t.params,
            ...e == null ? void 0 : e.params
        }), t != null && t.query && (e != null && e.query) && (r.query = { ...t == null ? void 0 : t.query,
            ...e == null ? void 0 : e.query
        }), t != null && t.headers && (e != null && e.headers)) {
        r.headers = new n((t == null ? void 0 : t.headers) || {});
        for (const [a, i] of new n((e == null ? void 0 : e.headers) || {})) r.headers.set(a, i)
    }
    return r
}
const $0 = new Set([408, 409, 425, 429, 500, 502, 503, 504]),
    V0 = new Set([101, 204, 205, 304]);

function _h(e = {}) {
    const {
        fetch: t = globalThis.fetch,
        Headers: n = globalThis.Headers,
        AbortController: r = globalThis.AbortController
    } = e;
    async function a(s) {
        const l = s.error && s.error.name === "AbortError" && !s.options.timeout || !1;
        if (s.options.retry !== !1 && !l) {
            let u;
            typeof s.options.retry == "number" ? u = s.options.retry : u = qu(s.options.method) ? 0 : 1;
            const f = s.response && s.response.status || 500;
            if (u > 0 && (Array.isArray(s.options.retryStatusCodes) ? s.options.retryStatusCodes.includes(f) : $0.has(f))) {
                const d = s.options.retryDelay || 0;
                return d > 0 && await new Promise(p => setTimeout(p, d)), i(s.request, { ...s.options,
                    retry: u - 1,
                    timeout: s.options.timeout
                })
            }
        }
        const c = x0(s);
        throw Error.captureStackTrace && Error.captureStackTrace(c, i), c
    }
    const i = async function(l, c = {}) {
            var d;
            const u = {
                request: l,
                options: j0(c, e.defaults, n),
                response: void 0,
                error: void 0
            };
            if (u.options.method = (d = u.options.method) == null ? void 0 : d.toUpperCase(), u.options.onRequest && await u.options.onRequest(u), typeof u.request == "string" && (u.options.baseURL && (u.request = _0(u.request, u.options.baseURL)), (u.options.query || u.options.params) && (u.request = yh(u.request, { ...u.options.params,
                    ...u.options.query
                }))), u.options.body && qu(u.options.method) && (D0(u.options.body) ? (u.options.body = typeof u.options.body == "string" ? u.options.body : JSON.stringify(u.options.body), u.options.headers = new n(u.options.headers || {}), u.options.headers.has("content-type") || u.options.headers.set("content-type", "application/json"), u.options.headers.has("accept") || u.options.headers.set("accept", "application/json")) : ("pipeTo" in u.options.body && typeof u.options.body.pipeTo == "function" || typeof u.options.body.pipe == "function") && ("duplex" in u.options || (u.options.duplex = "half"))), !u.options.signal && u.options.timeout) {
                const p = new r;
                setTimeout(() => p.abort(), u.options.timeout), u.options.signal = p.signal
            }
            try {
                u.response = await t(u.request, u.options)
            } catch (p) {
                return u.error = p, u.options.onRequestError && await u.options.onRequestError(u), await a(u)
            }
            if (u.response.body && !V0.has(u.response.status) && u.options.method !== "HEAD") {
                const p = (u.options.parseResponse ? "json" : u.options.responseType) || B0(u.response.headers.get("content-type") || "");
                switch (p) {
                    case "json":
                        {
                            const v = await u.response.text(),
                                E = u.options.parseResponse || Ta;u.response._data = E(v);
                            break
                        }
                    case "stream":
                        {
                            u.response._data = u.response.body;
                            break
                        }
                    default:
                        u.response._data = await u.response[p]()
                }
            }
            return u.options.onResponse && await u.options.onResponse(u), !u.options.ignoreResponseError && u.response.status >= 400 && u.response.status < 600 ? (u.options.onResponseError && await u.options.onResponseError(u), await a(u)) : u.response
        },
        o = async function(l, c) {
            return (await i(l, c))._data
        };
    return o.raw = i, o.native = (...s) => t(...s), o.create = (s = {}) => _h({ ...e,
        defaults: { ...e.defaults,
            ...s
        }
    }), o
}
const vc = function() {
        if (typeof globalThis < "u") return globalThis;
        if (typeof self < "u") return self;
        if (typeof window < "u") return window;
        if (typeof global < "u") return global;
        throw new Error("unable to locate global object")
    }(),
    H0 = vc.fetch || (() => Promise.reject(new Error("[ofetch] global.fetch is not supported!"))),
    K0 = vc.Headers,
    U0 = vc.AbortController,
    J0 = _h({
        fetch: H0,
        Headers: K0,
        AbortController: U0
    }),
    G0 = J0;
globalThis.$fetch || (globalThis.$fetch = G0.create({
    baseURL: L0()
}));

function Hs(e, t = {}, n) {
    for (const r in e) {
        const a = e[r],
            i = n ? `${n}:${r}` : r;
        typeof a == "object" && a !== null ? Hs(a, t, i) : typeof a == "function" && (t[i] = a)
    }
    return t
}
const W0 = {
        run: e => e()
    },
    z0 = () => W0,
    wh = typeof console.createTask < "u" ? console.createTask : z0;

function q0(e, t) {
    const n = t.shift(),
        r = wh(n);
    return e.reduce((a, i) => a.then(() => r.run(() => i(...t))), Promise.resolve())
}

function Y0(e, t) {
    const n = t.shift(),
        r = wh(n);
    return Promise.all(e.map(a => r.run(() => a(...t))))
}

function rs(e, t) {
    for (const n of [...e]) n(t)
}
class X0 {
    constructor() {
        this._hooks = {}, this._before = void 0, this._after = void 0, this._deprecatedMessages = void 0, this._deprecatedHooks = {}, this.hook = this.hook.bind(this), this.callHook = this.callHook.bind(this), this.callHookWith = this.callHookWith.bind(this)
    }
    hook(t, n, r = {}) {
        if (!t || typeof n != "function") return () => {};
        const a = t;
        let i;
        for (; this._deprecatedHooks[t];) i = this._deprecatedHooks[t], t = i.to;
        if (i && !r.allowDeprecated) {
            let o = i.message;
            o || (o = `${a} hook has been deprecated` + (i.to ? `, please use ${i.to}` : "")), this._deprecatedMessages || (this._deprecatedMessages = new Set), this._deprecatedMessages.has(o) || (console.warn(o), this._deprecatedMessages.add(o))
        }
        if (!n.name) try {
            Object.defineProperty(n, "name", {
                get: () => "_" + t.replace(/\W+/g, "_") + "_hook_cb",
                configurable: !0
            })
        } catch {}
        return this._hooks[t] = this._hooks[t] || [], this._hooks[t].push(n), () => {
            n && (this.removeHook(t, n), n = void 0)
        }
    }
    hookOnce(t, n) {
        let r, a = (...i) => (typeof r == "function" && r(), r = void 0, a = void 0, n(...i));
        return r = this.hook(t, a), r
    }
    removeHook(t, n) {
        if (this._hooks[t]) {
            const r = this._hooks[t].indexOf(n);
            r !== -1 && this._hooks[t].splice(r, 1), this._hooks[t].length === 0 && delete this._hooks[t]
        }
    }
    deprecateHook(t, n) {
        this._deprecatedHooks[t] = typeof n == "string" ? {
            to: n
        } : n;
        const r = this._hooks[t] || [];
        delete this._hooks[t];
        for (const a of r) this.hook(t, a)
    }
    deprecateHooks(t) {
        Object.assign(this._deprecatedHooks, t);
        for (const n in t) this.deprecateHook(n, t[n])
    }
    addHooks(t) {
        const n = Hs(t),
            r = Object.keys(n).map(a => this.hook(a, n[a]));
        return () => {
            for (const a of r.splice(0, r.length)) a()
        }
    }
    removeHooks(t) {
        const n = Hs(t);
        for (const r in n) this.removeHook(r, n[r])
    }
    removeAllHooks() {
        for (const t in this._hooks) delete this._hooks[t]
    }
    callHook(t, ...n) {
        return n.unshift(t), this.callHookWith(q0, t, ...n)
    }
    callHookParallel(t, ...n) {
        return n.unshift(t), this.callHookWith(Y0, t, ...n)
    }
    callHookWith(t, n, ...r) {
        const a = this._before || this._after ? {
            name: n,
            args: r,
            context: {}
        } : void 0;
        this._before && rs(this._before, a);
        const i = t(n in this._hooks ? [...this._hooks[n]] : [], r);
        return i instanceof Promise ? i.finally(() => {
            this._after && a && rs(this._after, a)
        }) : (this._after && a && rs(this._after, a), i)
    }
    beforeEach(t) {
        return this._before = this._before || [], this._before.push(t), () => {
            if (this._before !== void 0) {
                const n = this._before.indexOf(t);
                n !== -1 && this._before.splice(n, 1)
            }
        }
    }
    afterEach(t) {
        return this._after = this._after || [], this._after.push(t), () => {
            if (this._after !== void 0) {
                const n = this._after.indexOf(t);
                n !== -1 && this._after.splice(n, 1)
            }
        }
    }
}

function Eh() {
    return new X0
}

function Q0(e = {}) {
    let t, n = !1;
    const r = o => {
        if (t && t !== o) throw new Error("Context conflict")
    };
    let a;
    if (e.asyncContext) {
        const o = e.AsyncLocalStorage || globalThis.AsyncLocalStorage;
        o ? a = new o : console.warn("[unctx] `AsyncLocalStorage` is not provided.")
    }
    const i = () => {
        if (a && t === void 0) {
            const o = a.getStore();
            if (o !== void 0) return o
        }
        return t
    };
    return {
        use: () => {
            const o = i();
            if (o === void 0) throw new Error("Context is not available");
            return o
        },
        tryUse: () => i(),
        set: (o, s) => {
            s || r(o), t = o, n = !0
        },
        unset: () => {
            t = void 0, n = !1
        },
        call: (o, s) => {
            r(o), t = o;
            try {
                return a ? a.run(o, s) : s()
            } finally {
                n || (t = void 0)
            }
        },
        async callAsync(o, s) {
            t = o;
            const l = () => {
                    t = o
                },
                c = () => t === o ? l : void 0;
            Ks.add(c);
            try {
                const u = a ? a.run(o, s) : s();
                return n || (t = void 0), await u
            } finally {
                Ks.delete(c)
            }
        }
    }
}

function Z0(e = {}) {
    const t = {};
    return {
        get(n, r = {}) {
            return t[n] || (t[n] = Q0({ ...e,
                ...r
            })), t[n], t[n]
        }
    }
}
const Wi = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof global < "u" ? global : typeof window < "u" ? window : {},
    Yu = "__unctx__",
    e_ = Wi[Yu] || (Wi[Yu] = Z0()),
    t_ = (e, t = {}) => e_.get(e, t),
    Xu = "__unctx_async_handlers__",
    Ks = Wi[Xu] || (Wi[Xu] = new Set);

function Cn(e) {
    const t = [];
    for (const a of Ks) {
        const i = a();
        i && t.push(i)
    }
    const n = () => {
        for (const a of t) a()
    };
    let r = e();
    return r && typeof r == "object" && "catch" in r && (r = r.catch(a => {
        throw n(), a
    })), [r, n]
}
const Ch = t_("nuxt-app", {
        asyncContext: !1
    }),
    n_ = "__nuxt_plugin";

function r_(e) {
    let t = 0;
    const n = {
        _scope: Va(),
        provide: void 0,
        globalName: "nuxt",
        versions: {
            get nuxt() {
                return "3.8.2"
            },
            get vue() {
                return n.vueApp.version
            }
        },
        payload: tt({
            data: {},
            state: {},
            _errors: {},
            ...window.__NUXT__ ? ? {}
        }),
        static: {
            data: {}
        },
        runWithContext: a => n._scope.run(() => o_(n, a)),
        isHydrating: !0,
        deferHydration() {
            if (!n.isHydrating) return () => {};
            t++;
            let a = !1;
            return () => {
                if (!a && (a = !0, t--, t === 0)) return n.isHydrating = !1, n.callHook("app:suspense:resolve")
            }
        },
        _asyncDataPromises: {},
        _asyncData: {},
        _payloadRevivers: {},
        ...e
    };
    n.hooks = Eh(), n.hook = n.hooks.hook, n.callHook = n.hooks.callHook, n.provide = (a, i) => {
        const o = "$" + a;
        pi(n, o, i), pi(n.vueApp.config.globalProperties, o, i)
    }, pi(n.vueApp, "$nuxt", n), pi(n.vueApp.config.globalProperties, "$nuxt", n); {
        window.addEventListener("nuxt.preloadError", i => {
            n.callHook("app:chunkError", {
                error: i.payload
            })
        }), window.useNuxtApp = window.useNuxtApp || ge;
        const a = n.hook("app:error", (...i) => {
            console.error("[nuxt] error caught during app initialization", ...i)
        });
        n.hook("app:mounted", a)
    }
    const r = tt(n.payload.config);
    return n.provide("config", r), n
}
async function a_(e, t) {
    if (t.hooks && e.hooks.addHooks(t.hooks), typeof t == "function") {
        const {
            provide: n
        } = await e.runWithContext(() => t(e)) || {};
        if (n && typeof n == "object")
            for (const r in n) e.provide(r, n[r])
    }
}
async function i_(e, t) {
    const n = [],
        r = [];
    for (const a of t) {
        const i = a_(e, a);
        a.parallel ? n.push(i.catch(o => r.push(o))) : await i
    }
    if (await Promise.all(n), r.length) throw r[0]
} /*! @__NO_SIDE_EFFECTS__ */
function Qe(e) {
    return typeof e == "function" ? e : (delete e.name, Object.assign(e.setup || (() => {}), e, {
        [n_]: !0
    }))
}

function o_(e, t, n) {
    const r = () => n ? t(...n) : t();
    return Ch.set(e), e.vueApp.runWithContext(r)
} /*! @__NO_SIDE_EFFECTS__ */
function ge() {
    var t;
    let e;
    if (fc() && (e = (t = yt()) == null ? void 0 : t.appContext.app.$nuxt), e = e || Ch.tryUse(), !e) throw new Error("[nuxt] instance unavailable");
    return e
} /*! @__NO_SIDE_EFFECTS__ */
function Nt() {
    return ge().$config
}

function pi(e, t, n) {
    Object.defineProperty(e, t, {
        get: () => n
    })
}
const s_ = "modulepreload",
    l_ = function(e, t) {
        return e[0] === "." ? new URL(e, t).href : e
    },
    Qu = {},
    c_ = function(t, n, r) {
        if (!n || n.length === 0) return t();
        const a = document.getElementsByTagName("link");
        return Promise.all(n.map(i => {
            if (i = l_(i, r), i in Qu) return;
            Qu[i] = !0;
            const o = i.endsWith(".css"),
                s = o ? '[rel="stylesheet"]' : "";
            if (!!r)
                for (let u = a.length - 1; u >= 0; u--) {
                    const f = a[u];
                    if (f.href === i && (!o || f.rel === "stylesheet")) return
                } else if (document.querySelector(`link[href="${i}"]${s}`)) return;
            const c = document.createElement("link");
            if (c.rel = o ? "stylesheet" : s_, o || (c.as = "script", c.crossOrigin = ""), c.href = i, document.head.appendChild(c), o) return new Promise((u, f) => {
                c.addEventListener("load", u), c.addEventListener("error", () => f(new Error(`Unable to preload CSS for ${i}`)))
            })
        })).then(() => t()).catch(i => {
            const o = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (o.payload = i, window.dispatchEvent(o), !o.defaultPrevented) throw i
        })
    },
    D = (...e) => c_(...e).catch(t => {
        const n = new Event("nuxt.preloadError");
        throw n.payload = t, window.dispatchEvent(n), t
    }),
    u_ = -1,
    f_ = -2,
    d_ = -3,
    p_ = -4,
    h_ = -5,
    m_ = -6;

function g_(e, t) {
    return y_(JSON.parse(e), t)
}

function y_(e, t) {
    if (typeof e == "number") return a(e, !0);
    if (!Array.isArray(e) || e.length === 0) throw new Error("Invalid input");
    const n = e,
        r = Array(n.length);

    function a(i, o = !1) {
        if (i === u_) return;
        if (i === d_) return NaN;
        if (i === p_) return 1 / 0;
        if (i === h_) return -1 / 0;
        if (i === m_) return -0;
        if (o) throw new Error("Invalid input");
        if (i in r) return r[i];
        const s = n[i];
        if (!s || typeof s != "object") r[i] = s;
        else if (Array.isArray(s))
            if (typeof s[0] == "string") {
                const l = s[0],
                    c = t == null ? void 0 : t[l];
                if (c) return r[i] = c(a(s[1]));
                switch (l) {
                    case "Date":
                        r[i] = new Date(s[1]);
                        break;
                    case "Set":
                        const u = new Set;
                        r[i] = u;
                        for (let p = 1; p < s.length; p += 1) u.add(a(s[p]));
                        break;
                    case "Map":
                        const f = new Map;
                        r[i] = f;
                        for (let p = 1; p < s.length; p += 2) f.set(a(s[p]), a(s[p + 1]));
                        break;
                    case "RegExp":
                        r[i] = new RegExp(s[1], s[2]);
                        break;
                    case "Object":
                        r[i] = Object(s[1]);
                        break;
                    case "BigInt":
                        r[i] = BigInt(s[1]);
                        break;
                    case "null":
                        const d = Object.create(null);
                        r[i] = d;
                        for (let p = 1; p < s.length; p += 2) d[s[p]] = a(s[p + 1]);
                        break;
                    default:
                        throw new Error(`Unknown type ${l}`)
                }
            } else {
                const l = new Array(s.length);
                r[i] = l;
                for (let c = 0; c < s.length; c += 1) {
                    const u = s[c];
                    u !== f_ && (l[c] = a(u))
                }
            }
        else {
            const l = {};
            r[i] = l;
            for (const c in s) {
                const u = s[c];
                l[c] = a(u)
            }
        }
        return r[i]
    }
    return a(0)
}

function b_(e) {
    return Array.isArray(e) ? e : [e]
}
const v_ = ["title", "titleTemplate", "script", "style", "noscript"],
    Si = ["base", "meta", "link", "style", "script", "noscript"],
    __ = ["title", "titleTemplate", "templateParams", "base", "htmlAttrs", "bodyAttrs", "meta", "link", "style", "script", "noscript"],
    w_ = ["base", "title", "titleTemplate", "bodyAttrs", "htmlAttrs", "templateParams"],
    Ah = ["tagPosition", "tagPriority", "tagDuplicateStrategy", "children", "innerHTML", "textContent", "processTemplateParams"],
    E_ = typeof window < "u";

function _c(e) {
    let t = 9;
    for (let n = 0; n < e.length;) t = Math.imul(t ^ e.charCodeAt(n++), 9 ** 9);
    return ((t ^ t >>> 9) + 65536).toString(16).substring(1, 8).toLowerCase()
}

function Zu(e) {
    return e._h || _c(e._d ? e._d : `${e.tag}:${e.textContent||e.innerHTML||""}:${Object.entries(e.props).map(([t,n])=>`${t}:${String(n)}`).join(",")}`)
}

function Lh(e, t) {
    const {
        props: n,
        tag: r
    } = e;
    if (w_.includes(r)) return r;
    if (r === "link" && n.rel === "canonical") return "canonical";
    if (n.charset) return "charset";
    const a = ["id"];
    r === "meta" && a.push("name", "property", "http-equiv");
    for (const i of a)
        if (typeof n[i] < "u") {
            const o = String(n[i]);
            return t && !t(o) ? !1 : `${r}:${i}:${o}`
        }
    return !1
}

function ef(e, t) {
    return e == null ? t || null : typeof e == "function" ? e(t) : e
}
async function C_(e, t, n) {
    const r = {
        tag: e,
        props: await Sh(typeof t == "object" && typeof t != "function" && !(t instanceof Promise) ? { ...t
        } : {
            [
                ["script", "noscript", "style"].includes(e) ? "innerHTML" : "textContent"
            ]: t
        }, ["templateParams", "titleTemplate"].includes(e))
    };
    return Ah.forEach(a => {
        const i = typeof r.props[a] < "u" ? r.props[a] : n[a];
        typeof i < "u" && ((!["innerHTML", "textContent", "children"].includes(a) || v_.includes(r.tag)) && (r[a === "children" ? "innerHTML" : a] = i), delete r.props[a])
    }), r.props.body && (r.tagPosition = "bodyClose", delete r.props.body), r.tag === "script" && typeof r.innerHTML == "object" && (r.innerHTML = JSON.stringify(r.innerHTML), r.props.type = r.props.type || "application/json"), Array.isArray(r.props.content) ? r.props.content.map(a => ({ ...r,
        props: { ...r.props,
            content: a
        }
    })) : r
}

function A_(e) {
    return typeof e == "object" && !Array.isArray(e) && (e = Object.keys(e).filter(t => e[t])), (Array.isArray(e) ? e.join(" ") : e).split(" ").filter(t => t.trim()).filter(Boolean).join(" ")
}
async function Sh(e, t) {
    for (const n of Object.keys(e)) {
        if (n === "class") {
            e[n] = A_(e[n]);
            continue
        }
        if (e[n] instanceof Promise && (e[n] = await e[n]), !t && !Ah.includes(n)) {
            const r = String(e[n]),
                a = n.startsWith("data-");
            r === "true" || r === "" ? e[n] = a ? "true" : !0 : e[n] || (a && r === "false" ? e[n] = "false" : delete e[n])
        }
    }
    return e
}
const L_ = 10;
async function S_(e) {
    const t = [];
    return Object.entries(e.resolvedInput).filter(([n, r]) => typeof r < "u" && __.includes(n)).forEach(([n, r]) => {
        const a = b_(r);
        t.push(...a.map(i => C_(n, i, e)).flat())
    }), (await Promise.all(t)).flat().filter(Boolean).map((n, r) => (n._e = e._i, e.mode && (n._m = e.mode), n._p = (e._i << L_) + r, n))
}
const tf = {
        base: -10,
        title: 10
    },
    nf = {
        critical: -80,
        high: -10,
        low: 20
    };

function zi(e) {
    let t = 100;
    const n = e.tagPriority;
    return typeof n == "number" ? n : (e.tag === "meta" ? (e.props["http-equiv"] === "content-security-policy" && (t = -30), e.props.charset && (t = -20), e.props.name === "viewport" && (t = -15)) : e.tag === "link" && e.props.rel === "preconnect" ? t = 20 : e.tag in tf && (t = tf[e.tag]), typeof n == "string" && n in nf ? t + nf[n] : t)
}
const T_ = [{
        prefix: "before:",
        offset: -1
    }, {
        prefix: "after:",
        offset: 1
    }],
    Th = ["onload", "onerror", "onabort", "onprogress", "onloadstart"],
    cn = "%separator";

function Ti(e, t, n) {
    if (typeof e != "string" || !e.includes("%")) return e;

    function r(o) {
        let s;
        return ["s", "pageTitle"].includes(o) ? s = t.pageTitle : o.includes(".") ? s = o.split(".").reduce((l, c) => l && l[c] || void 0, t) : s = t[o], typeof s < "u" ? (s || "").replace(/"/g, '\\"') : !1
    }
    let a = e;
    try {
        a = decodeURI(e)
    } catch {}
    return (a.match(/%(\w+\.+\w+)|%(\w+)/g) || []).sort().reverse().forEach(o => {
        const s = r(o.slice(1));
        typeof s == "string" && (e = e.replace(new RegExp(`\\${o}(\\W|$)`, "g"), (l, c) => `${s}${c}`).trim())
    }), e.includes(cn) && (e.endsWith(cn) && (e = e.slice(0, -cn.length).trim()), e.startsWith(cn) && (e = e.slice(cn.length).trim()), e = e.replace(new RegExp(`\\${cn}\\s*\\${cn}`, "g"), cn), e = Ti(e, {
        separator: n
    }, n)), e
}
async function k_(e) {
    const t = {
        tag: e.tagName.toLowerCase(),
        props: await Sh(e.getAttributeNames().reduce((n, r) => ({ ...n,
            [r]: e.getAttribute(r)
        }), {})),
        innerHTML: e.innerHTML
    };
    return t._d = Lh(t), t
}
async function kh(e, t = {}) {
    var u;
    const n = t.document || e.resolvedOptions.document;
    if (!n) return;
    const r = {
        shouldRender: e.dirty,
        tags: []
    };
    if (await e.hooks.callHook("dom:beforeRender", r), !r.shouldRender) return;
    const a = (await e.resolveTags()).map(f => ({
        tag: f,
        id: Si.includes(f.tag) ? Zu(f) : f.tag,
        shouldRender: !0
    }));
    let i = e._dom;
    if (!i) {
        i = {
            elMap: {
                htmlAttrs: n.documentElement,
                bodyAttrs: n.body
            }
        };
        for (const f of ["body", "head"]) {
            const d = (u = n == null ? void 0 : n[f]) == null ? void 0 : u.children;
            for (const p of [...d].filter(v => Si.includes(v.tagName.toLowerCase()))) i.elMap[p.getAttribute("data-hid") || Zu(await k_(p))] = p
        }
    }
    i.pendingSideEffects = { ...i.sideEffects || {}
    }, i.sideEffects = {};

    function o(f, d, p) {
        const v = `${f}:${d}`;
        i.sideEffects[v] = p, delete i.pendingSideEffects[v]
    }

    function s({
        id: f,
        $el: d,
        tag: p
    }) {
        const v = p.tag.endsWith("Attrs");
        i.elMap[f] = d, v || (["textContent", "innerHTML"].forEach(E => {
            p[E] && p[E] !== d[E] && (d[E] = p[E])
        }), o(f, "el", () => {
            i.elMap[f].remove(), delete i.elMap[f]
        })), Object.entries(p.props).forEach(([E, w]) => {
            const h = `attr:${E}`;
            if (E === "class")
                for (const b of (w || "").split(" ").filter(Boolean)) v && o(f, `${h}:${b}`, () => d.classList.remove(b)), !d.classList.contains(b) && d.classList.add(b);
            else d.getAttribute(E) !== w && d.setAttribute(E, w === !0 ? "" : String(w)), v && o(f, h, () => d.removeAttribute(E))
        })
    }
    const l = [],
        c = {
            bodyClose: void 0,
            bodyOpen: void 0,
            head: void 0
        };
    for (const f of a) {
        const {
            tag: d,
            shouldRender: p,
            id: v
        } = f;
        if (p) {
            if (d.tag === "title") {
                n.title = d.textContent;
                continue
            }
            f.$el = f.$el || i.elMap[v], f.$el ? s(f) : Si.includes(d.tag) && l.push(f)
        }
    }
    for (const f of l) {
        const d = f.tag.tagPosition || "head";
        f.$el = n.createElement(f.tag.tag), s(f), c[d] = c[d] || n.createDocumentFragment(), c[d].appendChild(f.$el)
    }
    for (const f of a) await e.hooks.callHook("dom:renderTag", f, n, o);
    c.head && n.head.appendChild(c.head), c.bodyOpen && n.body.insertBefore(c.bodyOpen, n.body.firstChild), c.bodyClose && n.body.appendChild(c.bodyClose), Object.values(i.pendingSideEffects).forEach(f => f()), e._dom = i, e.dirty = !1, await e.hooks.callHook("dom:rendered", {
        renders: a
    })
}
async function R_(e, t = {}) {
    const n = t.delayFn || (r => setTimeout(r, 10));
    return e._domUpdatePromise = e._domUpdatePromise || new Promise(r => n(async () => {
        await kh(e, t), delete e._domUpdatePromise, r()
    }))
}

function O_(e) {
    return t => {
        var r, a;
        const n = ((a = (r = t.resolvedOptions.document) == null ? void 0 : r.head.querySelector('script[id="unhead:payload"]')) == null ? void 0 : a.innerHTML) || !1;
        return n && t.push(JSON.parse(n)), {
            mode: "client",
            hooks: {
                "entries:updated": function(i) {
                    R_(i, e)
                }
            }
        }
    }
}
const M_ = ["templateParams", "htmlAttrs", "bodyAttrs"],
    P_ = {
        hooks: {
            "tag:normalise": function({
                tag: e
            }) {
                ["hid", "vmid", "key"].forEach(r => {
                    e.props[r] && (e.key = e.props[r], delete e.props[r])
                });
                const n = Lh(e) || (e.key ? `${e.tag}:${e.key}` : !1);
                n && (e._d = n)
            },
            "tags:resolve": function(e) {
                const t = {};
                e.tags.forEach(r => {
                    const a = (r.key ? `${r.tag}:${r.key}` : r._d) || r._p,
                        i = t[a];
                    if (i) {
                        let s = r == null ? void 0 : r.tagDuplicateStrategy;
                        if (!s && M_.includes(r.tag) && (s = "merge"), s === "merge") {
                            const l = i.props;
                            ["class", "style"].forEach(c => {
                                l[c] && (r.props[c] ? (c === "style" && !l[c].endsWith(";") && (l[c] += ";"), r.props[c] = `${l[c]} ${r.props[c]}`) : r.props[c] = l[c])
                            }), t[a].props = { ...l,
                                ...r.props
                            };
                            return
                        } else if (r._e === i._e) {
                            i._duped = i._duped || [], r._d = `${i._d}:${i._duped.length+1}`, i._duped.push(r);
                            return
                        } else if (zi(r) > zi(i)) return
                    }
                    const o = Object.keys(r.props).length + (r.innerHTML ? 1 : 0) + (r.textContent ? 1 : 0);
                    if (Si.includes(r.tag) && o === 0) {
                        delete t[a];
                        return
                    }
                    t[a] = r
                });
                const n = [];
                Object.values(t).forEach(r => {
                    const a = r._duped;
                    delete r._duped, n.push(r), a && n.push(...a)
                }), e.tags = n, e.tags = e.tags.filter(r => !(r.tag === "meta" && (r.props.name || r.props.property) && !r.props.content))
            }
        }
    },
    x_ = {
        mode: "server",
        hooks: {
            "tags:resolve": function(e) {
                const t = {};
                e.tags.filter(n => ["titleTemplate", "templateParams", "title"].includes(n.tag) && n._m === "server").forEach(n => {
                    t[n.tag] = n.tag.startsWith("title") ? n.textContent : n.props
                }), Object.keys(t).length && e.tags.push({
                    tag: "script",
                    innerHTML: JSON.stringify(t),
                    props: {
                        id: "unhead:payload",
                        type: "application/json"
                    }
                })
            }
        }
    },
    I_ = ["script", "link", "bodyAttrs"];

function D_(e) {
    const t = {},
        n = {};
    return Object.entries(e.props).forEach(([r, a]) => {
        r.startsWith("on") && typeof a == "function" ? (Th.includes(r) && (t[r] = `this.dataset.${r} = true`), n[r] = a) : t[r] = a
    }), {
        props: t,
        eventHandlers: n
    }
}
const N_ = e => ({
        hooks: {
            "tags:resolve": function(t) {
                for (const n of t.tags)
                    if (I_.includes(n.tag)) {
                        const {
                            props: r,
                            eventHandlers: a
                        } = D_(n);
                        n.props = r, Object.keys(a).length && ((n.props.src || n.props.href) && (n.key = n.key || _c(n.props.src || n.props.href)), n._eventHandlers = a)
                    }
            },
            "dom:renderTag": function(t, n, r) {
                if (!t.tag._eventHandlers) return;
                const a = t.tag.tag === "bodyAttrs" ? n.defaultView : t.$el;
                Object.entries(t.tag._eventHandlers).forEach(([i, o]) => {
                    const s = `${t.tag._d||t.tag._p}:${i}`,
                        l = i.slice(2).toLowerCase(),
                        c = `data-h-${l}`;
                    if (r(t.id, s, () => {}), t.$el.hasAttribute(c)) return;
                    t.$el.setAttribute(c, "");
                    let u;
                    const f = d => {
                        o(d), u == null || u.disconnect()
                    };
                    i in t.$el.dataset ? f(new Event(i.replace("on", ""))) : Th.includes(i) && typeof MutationObserver < "u" ? (u = new MutationObserver(d => {
                        d.some(v => v.attributeName === `data-${i}`) && (f(new Event(i.replace("on", ""))), u == null || u.disconnect())
                    }), u.observe(t.$el, {
                        attributes: !0
                    })) : a.addEventListener(l, f), r(t.id, s, () => {
                        u == null || u.disconnect(), a.removeEventListener(l, f), t.$el.removeAttribute(c)
                    })
                })
            }
        }
    }),
    F_ = ["link", "style", "script", "noscript"],
    B_ = {
        hooks: {
            "tag:normalise": ({
                tag: e
            }) => {
                e.key && F_.includes(e.tag) && (e.props["data-hid"] = e._h = _c(e.key))
            }
        }
    },
    j_ = {
        hooks: {
            "tags:resolve": e => {
                const t = n => {
                    var r;
                    return (r = e.tags.find(a => a._d === n)) == null ? void 0 : r._p
                };
                for (const {
                        prefix: n,
                        offset: r
                    } of T_)
                    for (const a of e.tags.filter(i => typeof i.tagPriority == "string" && i.tagPriority.startsWith(n))) {
                        const i = t(a.tagPriority.replace(n, ""));
                        typeof i < "u" && (a._p = i + r)
                    }
                e.tags.sort((n, r) => n._p - r._p).sort((n, r) => zi(n) - zi(r))
            }
        }
    },
    $_ = {
        meta: "content",
        link: "href",
        htmlAttrs: "lang"
    },
    V_ = e => ({
        hooks: {
            "tags:resolve": t => {
                var s;
                const {
                    tags: n
                } = t, r = (s = n.find(l => l.tag === "title")) == null ? void 0 : s.textContent, a = n.findIndex(l => l.tag === "templateParams"), i = a !== -1 ? n[a].props : {}, o = i.separator || "|";
                delete i.separator, i.pageTitle = Ti(i.pageTitle || r || "", i, o);
                for (const l of n.filter(c => c.processTemplateParams !== !1)) {
                    const c = $_[l.tag];
                    c && typeof l.props[c] == "string" ? l.props[c] = Ti(l.props[c], i, o) : (l.processTemplateParams === !0 || ["titleTemplate", "title"].includes(l.tag)) && ["innerHTML", "textContent"].forEach(u => {
                        typeof l[u] == "string" && (l[u] = Ti(l[u], i, o))
                    })
                }
                e._templateParams = i, e._separator = o, t.tags = n.filter(l => l.tag !== "templateParams")
            }
        }
    }),
    H_ = {
        hooks: {
            "tags:resolve": e => {
                const {
                    tags: t
                } = e;
                let n = t.findIndex(a => a.tag === "titleTemplate");
                const r = t.findIndex(a => a.tag === "title");
                if (r !== -1 && n !== -1) {
                    const a = ef(t[n].textContent, t[r].textContent);
                    a !== null ? t[r].textContent = a || t[r].textContent : delete t[r]
                } else if (n !== -1) {
                    const a = ef(t[n].textContent);
                    a !== null && (t[n].textContent = a, t[n].tag = "title", n = -1)
                }
                n !== -1 && delete t[n], e.tags = t.filter(Boolean)
            }
        }
    },
    K_ = {
        hooks: {
            "tags:afterResolve": function(e) {
                for (const t of e.tags) typeof t.innerHTML == "string" && (t.innerHTML && ["application/ld+json", "application/json"].includes(t.props.type) ? t.innerHTML = t.innerHTML.replace(/</g, "\\u003C") : t.innerHTML = t.innerHTML.replace(new RegExp(`</${t.tag}`, "g"), `<\\/${t.tag}`))
            }
        }
    };
let Rh;

function U_(e = {}) {
    const t = J_(e);
    return t.use(O_()), Rh = t
}

function rf(e, t) {
    return !e || e === "server" && t || e === "client" && !t
}

function J_(e = {}) {
    const t = Eh();
    t.addHooks(e.hooks || {}), e.document = e.document || (E_ ? document : void 0);
    const n = !e.document,
        r = () => {
            s.dirty = !0, t.callHook("entries:updated", s)
        };
    let a = 0,
        i = [];
    const o = [],
        s = {
            plugins: o,
            dirty: !1,
            resolvedOptions: e,
            hooks: t,
            headEntries() {
                return i
            },
            use(l) {
                const c = typeof l == "function" ? l(s) : l;
                (!c.key || !o.some(u => u.key === c.key)) && (o.push(c), rf(c.mode, n) && t.addHooks(c.hooks || {}))
            },
            push(l, c) {
                c == null || delete c.head;
                const u = {
                    _i: a++,
                    input: l,
                    ...c
                };
                return rf(u.mode, n) && (i.push(u), r()), {
                    dispose() {
                        i = i.filter(f => f._i !== u._i), t.callHook("entries:updated", s), r()
                    },
                    patch(f) {
                        i = i.map(d => (d._i === u._i && (d.input = u.input = f), d)), r()
                    }
                }
            },
            async resolveTags() {
                const l = {
                    tags: [],
                    entries: [...i]
                };
                await t.callHook("entries:resolve", l);
                for (const c of l.entries) {
                    const u = c.resolvedInput || c.input;
                    if (c.resolvedInput = await (c.transform ? c.transform(u) : u), c.resolvedInput)
                        for (const f of await S_(c)) {
                            const d = {
                                tag: f,
                                entry: c,
                                resolvedOptions: s.resolvedOptions
                            };
                            await t.callHook("tag:normalise", d), l.tags.push(d.tag)
                        }
                }
                return await t.callHook("tags:beforeResolve", l), await t.callHook("tags:resolve", l), await t.callHook("tags:afterResolve", l), l.tags
            },
            ssr: n
        };
    return [P_, x_, N_, B_, j_, V_, H_, K_, ...(e == null ? void 0 : e.plugins) || []].forEach(l => s.use(l)), s.hooks.callHook("init", s), s
}

function G_() {
    return Rh
}
const W_ = dh.startsWith("3");

function z_(e) {
    return typeof e == "function" ? e() : pe(e)
}

function qi(e, t = "") {
    if (e instanceof Promise) return e;
    const n = z_(e);
    return !e || !n ? n : Array.isArray(n) ? n.map(r => qi(r, t)) : typeof n == "object" ? Object.fromEntries(Object.entries(n).map(([r, a]) => r === "titleTemplate" || r.startsWith("on") ? [r, pe(a)] : [r, qi(a, r)])) : n
}
const q_ = {
        hooks: {
            "entries:resolve": function(e) {
                for (const t of e.entries) t.resolvedInput = qi(t.input)
            }
        }
    },
    Oh = "usehead";

function Y_(e) {
    return {
        install(n) {
            W_ && (n.config.globalProperties.$unhead = e, n.config.globalProperties.$head = e, n.provide(Oh, e))
        }
    }.install
}

function X_(e = {}) {
    e.domDelayFn = e.domDelayFn || (n => St(() => setTimeout(() => n(), 0)));
    const t = U_(e);
    return t.use(q_), t.install = Y_(t), t
}
const Us = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    Js = "__unhead_injection_handler__";

function Q_(e) {
    Us[Js] = e
}

function Z_() {
    if (Js in Us) return Us[Js]();
    const e = Je(Oh);
    return e || G_()
}

function wo(e, t = {}) {
    const n = t.head || Z_();
    if (n) return n.ssr ? n.push(e, t) : ew(n, e, t)
}

function ew(e, t, n = {}) {
    const r = Q(!1),
        a = Q({});
    lc(() => {
        a.value = r.value ? {} : qi(t)
    });
    const i = e.push(a.value, n);
    return we(a, s => {
        i.patch(s)
    }), yt() && (Ja(() => {
        i.dispose()
    }), Jp(() => {
        r.value = !0
    }), Up(() => {
        r.value = !1
    })), i
}
const hi = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;

function tw(e, t) {
    if (typeof e != "string") throw new TypeError("argument str must be a string");
    const n = {},
        a = (t || {}).decode || aw;
    let i = 0;
    for (; i < e.length;) {
        const o = e.indexOf("=", i);
        if (o === -1) break;
        let s = e.indexOf(";", i);
        if (s === -1) s = e.length;
        else if (s < o) {
            i = e.lastIndexOf(";", o - 1) + 1;
            continue
        }
        const l = e.slice(i, o).trim();
        if (n[l] === void 0) {
            let c = e.slice(o + 1, s).trim();
            c.codePointAt(0) === 34 && (c = c.slice(1, -1)), n[l] = rw(c, a)
        }
        i = s + 1
    }
    return n
}

function af(e, t, n) {
    const r = n || {},
        a = r.encode || iw;
    if (typeof a != "function") throw new TypeError("option encode is invalid");
    if (!hi.test(e)) throw new TypeError("argument name is invalid");
    const i = a(t);
    if (i && !hi.test(i)) throw new TypeError("argument val is invalid");
    let o = e + "=" + i;
    if (r.maxAge !== void 0 && r.maxAge !== null) {
        const s = r.maxAge - 0;
        if (Number.isNaN(s) || !Number.isFinite(s)) throw new TypeError("option maxAge is invalid");
        o += "; Max-Age=" + Math.floor(s)
    }
    if (r.domain) {
        if (!hi.test(r.domain)) throw new TypeError("option domain is invalid");
        o += "; Domain=" + r.domain
    }
    if (r.path) {
        if (!hi.test(r.path)) throw new TypeError("option path is invalid");
        o += "; Path=" + r.path
    }
    if (r.expires) {
        if (!nw(r.expires) || Number.isNaN(r.expires.valueOf())) throw new TypeError("option expires is invalid");
        o += "; Expires=" + r.expires.toUTCString()
    }
    if (r.httpOnly && (o += "; HttpOnly"), r.secure && (o += "; Secure"), r.priority) switch (typeof r.priority == "string" ? r.priority.toLowerCase() : r.priority) {
        case "low":
            o += "; Priority=Low";
            break;
        case "medium":
            o += "; Priority=Medium";
            break;
        case "high":
            o += "; Priority=High";
            break;
        default:
            throw new TypeError("option priority is invalid")
    }
    if (r.sameSite) switch (typeof r.sameSite == "string" ? r.sameSite.toLowerCase() : r.sameSite) {
        case !0:
            o += "; SameSite=Strict";
            break;
        case "lax":
            o += "; SameSite=Lax";
            break;
        case "strict":
            o += "; SameSite=Strict";
            break;
        case "none":
            o += "; SameSite=None";
            break;
        default:
            throw new TypeError("option sameSite is invalid")
    }
    return o
}

function nw(e) {
    return Object.prototype.toString.call(e) === "[object Date]" || e instanceof Date
}

function rw(e, t) {
    try {
        return t(e)
    } catch {
        return e
    }
}

function aw(e) {
    return e.includes("%") ? decodeURIComponent(e) : e
}

function iw(e) {
    return encodeURIComponent(e)
}

function ow(e) {
    return {
        ctx: {
            table: e
        },
        matchAll: t => Ph(t, e)
    }
}

function Mh(e) {
    const t = {};
    for (const n in e) t[n] = n === "dynamic" ? new Map(Object.entries(e[n]).map(([r, a]) => [r, Mh(a)])) : new Map(Object.entries(e[n]));
    return t
}

function sw(e) {
    return ow(Mh(e))
}

function Ph(e, t) {
    const n = [];
    for (const [a, i] of of (t.wildcard)) e.startsWith(a) && n.push(i);
    for (const [a, i] of of (t.dynamic))
        if (e.startsWith(a + "/")) {
            const o = "/" + e.slice(a.length).split("/").splice(2).join("/");
            n.push(...Ph(o, i))
        }
    const r = t.static.get(e);
    return r && n.push(r), n.filter(Boolean)
}

function of (e) {
    return [...e.entries()].sort((t, n) => t[0].length - n[0].length)
}

function Gs(e, t, n = ".", r) {
    if (!as(t)) return Gs(e, {}, n, r);
    const a = Object.assign({}, t);
    for (const i in e) {
        if (i === "__proto__" || i === "constructor") continue;
        const o = e[i];
        o != null && (r && r(a, i, o, n) || (Array.isArray(o) && Array.isArray(a[i]) ? a[i] = [...o, ...a[i]] : as(o) && as(a[i]) ? a[i] = Gs(o, a[i], (n ? `${n}.` : "") + i.toString(), r) : a[i] = o))
    }
    return a
}

function as(e) {
    if (e === null || typeof e != "object") return !1;
    const t = Object.getPrototypeOf(e);
    return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
}

function wc(e) {
    return (...t) => t.reduce((n, r) => Gs(n, r, "", e), {})
}
const Eo = wc(),
    lw = wc((e, t, n) => {
        if (e[t] !== void 0 && typeof n == "function") return e[t] = n(e[t]), !0
    });

function cw(e, t) {
    try {
        return t in e
    } catch {
        return !1
    }
}
var uw = Object.defineProperty,
    fw = (e, t, n) => t in e ? uw(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    Hn = (e, t, n) => (fw(e, typeof t != "symbol" ? t + "" : t, n), n);
class Ws extends Error {
    constructor(t, n = {}) {
        super(t, n), Hn(this, "statusCode", 500), Hn(this, "fatal", !1), Hn(this, "unhandled", !1), Hn(this, "statusMessage"), Hn(this, "data"), Hn(this, "cause"), n.cause && !this.cause && (this.cause = n.cause)
    }
    toJSON() {
        const t = {
            message: this.message,
            statusCode: qs(this.statusCode, 500)
        };
        return this.statusMessage && (t.statusMessage = xh(this.statusMessage)), this.data !== void 0 && (t.data = this.data), t
    }
}
Hn(Ws, "__h3_error__", !0);

function zs(e) {
    if (typeof e == "string") return new Ws(e);
    if (dw(e)) return e;
    const t = new Ws(e.message ? ? e.statusMessage ? ? "", {
        cause: e.cause || e
    });
    if (cw(e, "stack")) try {
        Object.defineProperty(t, "stack", {
            get() {
                return e.stack
            }
        })
    } catch {
        try {
            t.stack = e.stack
        } catch {}
    }
    if (e.data && (t.data = e.data), e.statusCode ? t.statusCode = qs(e.statusCode, t.statusCode) : e.status && (t.statusCode = qs(e.status, t.statusCode)), e.statusMessage ? t.statusMessage = e.statusMessage : e.statusText && (t.statusMessage = e.statusText), t.statusMessage) {
        const n = t.statusMessage;
        xh(t.statusMessage) !== n && console.warn("[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default.")
    }
    return e.fatal !== void 0 && (t.fatal = e.fatal), e.unhandled !== void 0 && (t.unhandled = e.unhandled), t
}

function dw(e) {
    var t;
    return ((t = e == null ? void 0 : e.constructor) == null ? void 0 : t.__h3_error__) === !0
}
const pw = /[^\u0009\u0020-\u007E]/g;

function xh(e = "") {
    return e.replace(pw, "")
}

function qs(e, t = 200) {
    return !e || (typeof e == "string" && (e = Number.parseInt(e, 10)), e < 100 || e > 999) ? t : e
}
const Ih = Symbol("layout-meta"),
    Vr = Symbol("route"),
    Co = () => ir(ge().payload, "error"),
    yn = e => {
        const t = Ec(e);
        try {
            const n = ge(),
                r = Co();
            n.hooks.callHook("app:error", t), r.value = r.value || t
        } catch {
            throw t
        }
        return t
    },
    hw = async (e = {}) => {
        const t = ge(),
            n = Co();
        t.callHook("app:error:cleared", e), e.redirect && await pt().replace(e.redirect), n.value = null
    },
    mw = e => !!(e && typeof e == "object" && "__nuxt_error" in e),
    Ec = e => {
        const t = zs(e);
        return t.__nuxt_error = !0, t
    },
    pt = () => {
        var e;
        return (e = ge()) == null ? void 0 : e.$router
    },
    Hr = () => fc() ? Je(Vr, ge()._route) : ge()._route; /*! @__NO_SIDE_EFFECTS__ */
const gw = (e, t, n = {}) => {
        const r = ge(),
            a = n.global || typeof e != "string",
            i = typeof e != "string" ? e : t;
        if (!i) {
            console.warn("[nuxt] No route middleware passed to `addRouteMiddleware`.", e);
            return
        }
        a ? r._middleware.global.push(i) : r._middleware.named[e] = i
    },
    yw = () => {
        try {
            if (ge()._processingMiddleware) return !0
        } catch {
            return !0
        }
        return !1
    },
    Dh = (e, t) => {
        e || (e = "/");
        const n = typeof e == "string" ? e : yh(e.path || "/", e.query || {}) + (e.hash || "");
        if (t != null && t.open) {
            {
                const {
                    target: s = "_blank",
                    windowFeatures: l = {}
                } = t.open, c = Object.entries(l).filter(([u, f]) => f !== void 0).map(([u, f]) => `${u.toLowerCase()}=${f}`).join(", ");
                open(n, s, c)
            }
            return Promise.resolve()
        }
        const r = (t == null ? void 0 : t.external) || or(n, {
            acceptRelative: !0
        });
        if (r) {
            if (!(t != null && t.external)) throw new Error("Navigating to an external URL is not allowed by default. Use `navigateTo(url, { external: true })`.");
            const s = _o(n).protocol;
            if (s && y0(s)) throw new Error(`Cannot navigate to a URL with '${s}' protocol.`)
        }
        const a = yw();
        if (!r && a) return e;
        const i = pt(),
            o = ge();
        return r ? (o._scope.stop(), t != null && t.replace ? location.replace(n) : location.href = n, a ? o.isHydrating ? new Promise(() => {}) : !1 : Promise.resolve()) : t != null && t.replace ? i.replace(e) : i.push(e)
    },
    bw = {
        ui: {
            primary: "indigo",
            gray: "cool",
            modal: {
                overlay: {
                    background: "bg-gray-500/75 dark:bg-gray-900/75"
                }
            },
            notifications: {
                position: "top-0 bottom-auto z-50"
            }
        }
    },
    vw = {
        nuxt: {
            buildId: "8c2473c5-2989-4d49-b5a3-c8fc14ca9e69"
        },
        ui: {
            primary: "green",
            gray: "cool",
            colors: ["red", "orange", "amber", "yellow", "lime", "green", "emerald", "teal", "cyan", "sky", "blue", "indigo", "violet", "purple", "fuchsia", "pink", "rose", "primary"],
            strategy: "merge"
        }
    },
    At = lw(bw, vw);

function Wa() {
    const e = ge();
    return e._appConfig || (e._appConfig = tt(At)), e._appConfig
}
const _w = !1,
    Ys = !1,
    ww = !1,
    Ew = {
        componentName: "NuxtLink"
    },
    Cw = "#__nuxt";
let ki, Nh;

function Aw() {
    var t;
    const e = (t = Wa().nuxt) == null ? void 0 : t.buildId;
    return ki = $fetch(bc(`builds/meta/${e}.json`)), ki.then(n => {
        Nh = sw(n.matcher)
    }), ki
}

function Fh() {
    return ki || Aw()
}
async function Lw(e) {
    return await Fh(), Eo({}, ...Nh.matchAll(e).reverse())
}
async function Sw(e) {
    return null
}
let mi = null;
async function Tw() {
    if (mi) return mi;
    const e = document.getElementById("__NUXT_DATA__");
    if (!e) return {};
    const t = kw(e.textContent || ""),
        n = e.dataset.src ? await Sw(e.dataset.src) : void 0;
    return mi = { ...t,
        ...n,
        ...window.__NUXT__
    }, mi
}

function kw(e) {
    return g_(e, ge()._payloadRevivers)
}

function Rw(e, t) {
    ge()._payloadRevivers[e] = t
}
const sf = {
        NuxtError: e => Ec(e),
        EmptyShallowRef: e => Er(e === "_" ? void 0 : e === "0n" ? BigInt(0) : Ta(e)),
        EmptyRef: e => Q(e === "_" ? void 0 : e === "0n" ? BigInt(0) : Ta(e)),
        ShallowRef: e => Er(e),
        ShallowReactive: e => Ha(e),
        Ref: e => Q(e),
        Reactive: e => tt(e)
    },
    Ow = Qe({
        name: "nuxt:revive-payload:client",
        order: -30,
        async setup(e) {
            let t, n;
            for (const r in sf) Rw(r, sf[r]);
            Object.assign(e.payload, ([t, n] = Cn(() => e.runWithContext(Tw)), t = await t, n(), t)), window.__NUXT__ = e.payload
        }
    }),
    Mw = [],
    Pw = Qe({
        name: "nuxt:head",
        enforce: "pre",
        setup(e) {
            const t = X_({
                plugins: Mw
            });
            Q_(() => ge().vueApp._context.provides.usehead), e.vueApp.use(t); {
                let n = !0;
                const r = async () => {
                    n = !1, await kh(t)
                };
                t.hooks.hook("dom:beforeRender", a => {
                    a.shouldRender = !n
                }), e.hooks.hook("page:start", () => {
                    n = !0
                }), e.hooks.hook("page:finish", () => {
                    e.isHydrating || r()
                }), e.hooks.hook("app:error", r), e.hooks.hook("app:suspense:resolve", r)
            }
        }
    });
/*!
 * vue-router v4.2.5
 * (c) 2023 Eduardo San Martin Morote
 * @license MIT
 */
const pr = typeof window < "u";

function xw(e) {
    return e.__esModule || e[Symbol.toStringTag] === "Module"
}
const Ee = Object.assign;

function is(e, t) {
    const n = {};
    for (const r in t) {
        const a = t[r];
        n[r] = xt(a) ? a.map(e) : e(a)
    }
    return n
}
const fa = () => {},
    xt = Array.isArray,
    Iw = /\/$/,
    Dw = e => e.replace(Iw, "");

function os(e, t, n = "/") {
    let r, a = {},
        i = "",
        o = "";
    const s = t.indexOf("#");
    let l = t.indexOf("?");
    return s < l && s >= 0 && (l = -1), l > -1 && (r = t.slice(0, l), i = t.slice(l + 1, s > -1 ? s : t.length), a = e(i)), s > -1 && (r = r || t.slice(0, s), o = t.slice(s, t.length)), r = jw(r ? ? t, n), {
        fullPath: r + (i && "?") + i + o,
        path: r,
        query: a,
        hash: o
    }
}

function Nw(e, t) {
    const n = t.query ? e(t.query) : "";
    return t.path + (n && "?") + n + (t.hash || "")
}

function lf(e, t) {
    return !t || !e.toLowerCase().startsWith(t.toLowerCase()) ? e : e.slice(t.length) || "/"
}

function Fw(e, t, n) {
    const r = t.matched.length - 1,
        a = n.matched.length - 1;
    return r > -1 && r === a && Sr(t.matched[r], n.matched[a]) && Bh(t.params, n.params) && e(t.query) === e(n.query) && t.hash === n.hash
}

function Sr(e, t) {
    return (e.aliasOf || e) === (t.aliasOf || t)
}

function Bh(e, t) {
    if (Object.keys(e).length !== Object.keys(t).length) return !1;
    for (const n in e)
        if (!Bw(e[n], t[n])) return !1;
    return !0
}

function Bw(e, t) {
    return xt(e) ? cf(e, t) : xt(t) ? cf(t, e) : e === t
}

function cf(e, t) {
    return xt(t) ? e.length === t.length && e.every((n, r) => n === t[r]) : e.length === 1 && e[0] === t
}

function jw(e, t) {
    if (e.startsWith("/")) return e;
    if (!e) return t;
    const n = t.split("/"),
        r = e.split("/"),
        a = r[r.length - 1];
    (a === ".." || a === ".") && r.push("");
    let i = n.length - 1,
        o, s;
    for (o = 0; o < r.length; o++)
        if (s = r[o], s !== ".")
            if (s === "..") i > 1 && i--;
            else break;
    return n.slice(0, i).join("/") + "/" + r.slice(o - (o === r.length ? 1 : 0)).join("/")
}
var ka;
(function(e) {
    e.pop = "pop", e.push = "push"
})(ka || (ka = {}));
var da;
(function(e) {
    e.back = "back", e.forward = "forward", e.unknown = ""
})(da || (da = {}));

function $w(e) {
    if (!e)
        if (pr) {
            const t = document.querySelector("base");
            e = t && t.getAttribute("href") || "/", e = e.replace(/^\w+:\/\/[^\/]+/, "")
        } else e = "/";
    return e[0] !== "/" && e[0] !== "#" && (e = "/" + e), Dw(e)
}
const Vw = /^[^#]+#/;

function Hw(e, t) {
    return e.replace(Vw, "#") + t
}

function Kw(e, t) {
    const n = document.documentElement.getBoundingClientRect(),
        r = e.getBoundingClientRect();
    return {
        behavior: t.behavior,
        left: r.left - n.left - (t.left || 0),
        top: r.top - n.top - (t.top || 0)
    }
}
const Ao = () => ({
    left: window.pageXOffset,
    top: window.pageYOffset
});

function Uw(e) {
    let t;
    if ("el" in e) {
        const n = e.el,
            r = typeof n == "string" && n.startsWith("#"),
            a = typeof n == "string" ? r ? document.getElementById(n.slice(1)) : document.querySelector(n) : n;
        if (!a) return;
        t = Kw(a, e)
    } else t = e;
    "scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(t.left != null ? t.left : window.pageXOffset, t.top != null ? t.top : window.pageYOffset)
}

function uf(e, t) {
    return (history.state ? history.state.position - t : -1) + e
}
const Xs = new Map;

function Jw(e, t) {
    Xs.set(e, t)
}

function Gw(e) {
    const t = Xs.get(e);
    return Xs.delete(e), t
}
let Ww = () => location.protocol + "//" + location.host;

function jh(e, t) {
    const {
        pathname: n,
        search: r,
        hash: a
    } = t, i = e.indexOf("#");
    if (i > -1) {
        let s = a.includes(e.slice(i)) ? e.slice(i).length : 1,
            l = a.slice(s);
        return l[0] !== "/" && (l = "/" + l), lf(l, "")
    }
    return lf(n, e) + r + a
}

function zw(e, t, n, r) {
    let a = [],
        i = [],
        o = null;
    const s = ({
        state: d
    }) => {
        const p = jh(e, location),
            v = n.value,
            E = t.value;
        let w = 0;
        if (d) {
            if (n.value = p, t.value = d, o && o === v) {
                o = null;
                return
            }
            w = E ? d.position - E.position : 0
        } else r(p);
        a.forEach(h => {
            h(n.value, v, {
                delta: w,
                type: ka.pop,
                direction: w ? w > 0 ? da.forward : da.back : da.unknown
            })
        })
    };

    function l() {
        o = n.value
    }

    function c(d) {
        a.push(d);
        const p = () => {
            const v = a.indexOf(d);
            v > -1 && a.splice(v, 1)
        };
        return i.push(p), p
    }

    function u() {
        const {
            history: d
        } = window;
        d.state && d.replaceState(Ee({}, d.state, {
            scroll: Ao()
        }), "")
    }

    function f() {
        for (const d of i) d();
        i = [], window.removeEventListener("popstate", s), window.removeEventListener("beforeunload", u)
    }
    return window.addEventListener("popstate", s), window.addEventListener("beforeunload", u, {
        passive: !0
    }), {
        pauseListeners: l,
        listen: c,
        destroy: f
    }
}

function ff(e, t, n, r = !1, a = !1) {
    return {
        back: e,
        current: t,
        forward: n,
        replaced: r,
        position: window.history.length,
        scroll: a ? Ao() : null
    }
}

function qw(e) {
    const {
        history: t,
        location: n
    } = window, r = {
        value: jh(e, n)
    }, a = {
        value: t.state
    };
    a.value || i(r.value, {
        back: null,
        current: r.value,
        forward: null,
        position: t.length - 1,
        replaced: !0,
        scroll: null
    }, !0);

    function i(l, c, u) {
        const f = e.indexOf("#"),
            d = f > -1 ? (n.host && document.querySelector("base") ? e : e.slice(f)) + l : Ww() + e + l;
        try {
            t[u ? "replaceState" : "pushState"](c, "", d), a.value = c
        } catch (p) {
            console.error(p), n[u ? "replace" : "assign"](d)
        }
    }

    function o(l, c) {
        const u = Ee({}, t.state, ff(a.value.back, l, a.value.forward, !0), c, {
            position: a.value.position
        });
        i(l, u, !0), r.value = l
    }

    function s(l, c) {
        const u = Ee({}, a.value, t.state, {
            forward: l,
            scroll: Ao()
        });
        i(u.current, u, !0);
        const f = Ee({}, ff(r.value, l, null), {
            position: u.position + 1
        }, c);
        i(l, f, !1), r.value = l
    }
    return {
        location: r,
        state: a,
        push: s,
        replace: o
    }
}

function $h(e) {
    e = $w(e);
    const t = qw(e),
        n = zw(e, t.state, t.location, t.replace);

    function r(i, o = !0) {
        o || n.pauseListeners(), history.go(i)
    }
    const a = Ee({
        location: "",
        base: e,
        go: r,
        createHref: Hw.bind(null, e)
    }, t, n);
    return Object.defineProperty(a, "location", {
        enumerable: !0,
        get: () => t.location.value
    }), Object.defineProperty(a, "state", {
        enumerable: !0,
        get: () => t.state.value
    }), a
}

function Yw(e) {
    return e = location.host ? e || location.pathname + location.search : "", e.includes("#") || (e += "#"), $h(e)
}

function Xw(e) {
    return typeof e == "string" || e && typeof e == "object"
}

function Vh(e) {
    return typeof e == "string" || typeof e == "symbol"
}
const jt = {
        path: "/",
        name: void 0,
        params: {},
        query: {},
        hash: "",
        fullPath: "/",
        matched: [],
        meta: {},
        redirectedFrom: void 0
    },
    Hh = Symbol("");
var df;
(function(e) {
    e[e.aborted = 4] = "aborted", e[e.cancelled = 8] = "cancelled", e[e.duplicated = 16] = "duplicated"
})(df || (df = {}));

function Tr(e, t) {
    return Ee(new Error, {
        type: e,
        [Hh]: !0
    }, t)
}

function Gt(e, t) {
    return e instanceof Error && Hh in e && (t == null || !!(e.type & t))
}
const pf = "[^/]+?",
    Qw = {
        sensitive: !1,
        strict: !1,
        start: !0,
        end: !0
    },
    Zw = /[.+*?^${}()[\]/\\]/g;

function eE(e, t) {
    const n = Ee({}, Qw, t),
        r = [];
    let a = n.start ? "^" : "";
    const i = [];
    for (const c of e) {
        const u = c.length ? [] : [90];
        n.strict && !c.length && (a += "/");
        for (let f = 0; f < c.length; f++) {
            const d = c[f];
            let p = 40 + (n.sensitive ? .25 : 0);
            if (d.type === 0) f || (a += "/"), a += d.value.replace(Zw, "\\$&"), p += 40;
            else if (d.type === 1) {
                const {
                    value: v,
                    repeatable: E,
                    optional: w,
                    regexp: h
                } = d;
                i.push({
                    name: v,
                    repeatable: E,
                    optional: w
                });
                const b = h || pf;
                if (b !== pf) {
                    p += 10;
                    try {
                        new RegExp(`(${b})`)
                    } catch (y) {
                        throw new Error(`Invalid custom RegExp for param "${v}" (${b}): ` + y.message)
                    }
                }
                let m = E ? `((?:${b})(?:/(?:${b}))*)` : `(${b})`;
                f || (m = w && c.length < 2 ? `(?:/${m})` : "/" + m), w && (m += "?"), a += m, p += 20, w && (p += -8), E && (p += -20), b === ".*" && (p += -50)
            }
            u.push(p)
        }
        r.push(u)
    }
    if (n.strict && n.end) {
        const c = r.length - 1;
        r[c][r[c].length - 1] += .7000000000000001
    }
    n.strict || (a += "/?"), n.end ? a += "$" : n.strict && (a += "(?:/|$)");
    const o = new RegExp(a, n.sensitive ? "" : "i");

    function s(c) {
        const u = c.match(o),
            f = {};
        if (!u) return null;
        for (let d = 1; d < u.length; d++) {
            const p = u[d] || "",
                v = i[d - 1];
            f[v.name] = p && v.repeatable ? p.split("/") : p
        }
        return f
    }

    function l(c) {
        let u = "",
            f = !1;
        for (const d of e) {
            (!f || !u.endsWith("/")) && (u += "/"), f = !1;
            for (const p of d)
                if (p.type === 0) u += p.value;
                else if (p.type === 1) {
                const {
                    value: v,
                    repeatable: E,
                    optional: w
                } = p, h = v in c ? c[v] : "";
                if (xt(h) && !E) throw new Error(`Provided param "${v}" is an array but it is not repeatable (* or + modifiers)`);
                const b = xt(h) ? h.join("/") : h;
                if (!b)
                    if (w) d.length < 2 && (u.endsWith("/") ? u = u.slice(0, -1) : f = !0);
                    else throw new Error(`Missing required param "${v}"`);
                u += b
            }
        }
        return u || "/"
    }
    return {
        re: o,
        score: r,
        keys: i,
        parse: s,
        stringify: l
    }
}

function tE(e, t) {
    let n = 0;
    for (; n < e.length && n < t.length;) {
        const r = t[n] - e[n];
        if (r) return r;
        n++
    }
    return e.length < t.length ? e.length === 1 && e[0] === 40 + 40 ? -1 : 1 : e.length > t.length ? t.length === 1 && t[0] === 40 + 40 ? 1 : -1 : 0
}

function nE(e, t) {
    let n = 0;
    const r = e.score,
        a = t.score;
    for (; n < r.length && n < a.length;) {
        const i = tE(r[n], a[n]);
        if (i) return i;
        n++
    }
    if (Math.abs(a.length - r.length) === 1) {
        if (hf(r)) return 1;
        if (hf(a)) return -1
    }
    return a.length - r.length
}

function hf(e) {
    const t = e[e.length - 1];
    return e.length > 0 && t[t.length - 1] < 0
}
const rE = {
        type: 0,
        value: ""
    },
    aE = /[a-zA-Z0-9_]/;

function iE(e) {
    if (!e) return [
        []
    ];
    if (e === "/") return [
        [rE]
    ];
    if (!e.startsWith("/")) throw new Error(`Invalid path "${e}"`);

    function t(p) {
        throw new Error(`ERR (${n})/"${c}": ${p}`)
    }
    let n = 0,
        r = n;
    const a = [];
    let i;

    function o() {
        i && a.push(i), i = []
    }
    let s = 0,
        l, c = "",
        u = "";

    function f() {
        c && (n === 0 ? i.push({
            type: 0,
            value: c
        }) : n === 1 || n === 2 || n === 3 ? (i.length > 1 && (l === "*" || l === "+") && t(`A repeatable param (${c}) must be alone in its segment. eg: '/:ids+.`), i.push({
            type: 1,
            value: c,
            regexp: u,
            repeatable: l === "*" || l === "+",
            optional: l === "*" || l === "?"
        })) : t("Invalid state to consume buffer"), c = "")
    }

    function d() {
        c += l
    }
    for (; s < e.length;) {
        if (l = e[s++], l === "\\" && n !== 2) {
            r = n, n = 4;
            continue
        }
        switch (n) {
            case 0:
                l === "/" ? (c && f(), o()) : l === ":" ? (f(), n = 1) : d();
                break;
            case 4:
                d(), n = r;
                break;
            case 1:
                l === "(" ? n = 2 : aE.test(l) ? d() : (f(), n = 0, l !== "*" && l !== "?" && l !== "+" && s--);
                break;
            case 2:
                l === ")" ? u[u.length - 1] == "\\" ? u = u.slice(0, -1) + l : n = 3 : u += l;
                break;
            case 3:
                f(), n = 0, l !== "*" && l !== "?" && l !== "+" && s--, u = "";
                break;
            default:
                t("Unknown state");
                break
        }
    }
    return n === 2 && t(`Unfinished custom RegExp for param "${c}"`), f(), o(), a
}

function oE(e, t, n) {
    const r = eE(iE(e.path), n),
        a = Ee(r, {
            record: e,
            parent: t,
            children: [],
            alias: []
        });
    return t && !a.record.aliasOf == !t.record.aliasOf && t.children.push(a), a
}

function sE(e, t) {
    const n = [],
        r = new Map;
    t = yf({
        strict: !1,
        end: !0,
        sensitive: !1
    }, t);

    function a(u) {
        return r.get(u)
    }

    function i(u, f, d) {
        const p = !d,
            v = lE(u);
        v.aliasOf = d && d.record;
        const E = yf(t, u),
            w = [v];
        if ("alias" in u) {
            const m = typeof u.alias == "string" ? [u.alias] : u.alias;
            for (const y of m) w.push(Ee({}, v, {
                components: d ? d.record.components : v.components,
                path: y,
                aliasOf: d ? d.record : v
            }))
        }
        let h, b;
        for (const m of w) {
            const {
                path: y
            } = m;
            if (f && y[0] !== "/") {
                const C = f.record.path,
                    S = C[C.length - 1] === "/" ? "" : "/";
                m.path = f.record.path + (y && S + y)
            }
            if (h = oE(m, f, E), d ? d.alias.push(h) : (b = b || h, b !== h && b.alias.push(h), p && u.name && !gf(h) && o(u.name)), v.children) {
                const C = v.children;
                for (let S = 0; S < C.length; S++) i(C[S], h, d && d.children[S])
            }
            d = d || h, (h.record.components && Object.keys(h.record.components).length || h.record.name || h.record.redirect) && l(h)
        }
        return b ? () => {
            o(b)
        } : fa
    }

    function o(u) {
        if (Vh(u)) {
            const f = r.get(u);
            f && (r.delete(u), n.splice(n.indexOf(f), 1), f.children.forEach(o), f.alias.forEach(o))
        } else {
            const f = n.indexOf(u);
            f > -1 && (n.splice(f, 1), u.record.name && r.delete(u.record.name), u.children.forEach(o), u.alias.forEach(o))
        }
    }

    function s() {
        return n
    }

    function l(u) {
        let f = 0;
        for (; f < n.length && nE(u, n[f]) >= 0 && (u.record.path !== n[f].record.path || !Kh(u, n[f]));) f++;
        n.splice(f, 0, u), u.record.name && !gf(u) && r.set(u.record.name, u)
    }

    function c(u, f) {
        let d, p = {},
            v, E;
        if ("name" in u && u.name) {
            if (d = r.get(u.name), !d) throw Tr(1, {
                location: u
            });
            E = d.record.name, p = Ee(mf(f.params, d.keys.filter(b => !b.optional).map(b => b.name)), u.params && mf(u.params, d.keys.map(b => b.name))), v = d.stringify(p)
        } else if ("path" in u) v = u.path, d = n.find(b => b.re.test(v)), d && (p = d.parse(v), E = d.record.name);
        else {
            if (d = f.name ? r.get(f.name) : n.find(b => b.re.test(f.path)), !d) throw Tr(1, {
                location: u,
                currentLocation: f
            });
            E = d.record.name, p = Ee({}, f.params, u.params), v = d.stringify(p)
        }
        const w = [];
        let h = d;
        for (; h;) w.unshift(h.record), h = h.parent;
        return {
            name: E,
            path: v,
            params: p,
            matched: w,
            meta: uE(w)
        }
    }
    return e.forEach(u => i(u)), {
        addRoute: i,
        resolve: c,
        removeRoute: o,
        getRoutes: s,
        getRecordMatcher: a
    }
}

function mf(e, t) {
    const n = {};
    for (const r of t) r in e && (n[r] = e[r]);
    return n
}

function lE(e) {
    return {
        path: e.path,
        redirect: e.redirect,
        name: e.name,
        meta: e.meta || {},
        aliasOf: void 0,
        beforeEnter: e.beforeEnter,
        props: cE(e),
        children: e.children || [],
        instances: {},
        leaveGuards: new Set,
        updateGuards: new Set,
        enterCallbacks: {},
        components: "components" in e ? e.components || null : e.component && {
            default: e.component
        }
    }
}

function cE(e) {
    const t = {},
        n = e.props || !1;
    if ("component" in e) t.default = n;
    else
        for (const r in e.components) t[r] = typeof n == "object" ? n[r] : n;
    return t
}

function gf(e) {
    for (; e;) {
        if (e.record.aliasOf) return !0;
        e = e.parent
    }
    return !1
}

function uE(e) {
    return e.reduce((t, n) => Ee(t, n.meta), {})
}

function yf(e, t) {
    const n = {};
    for (const r in e) n[r] = r in t ? t[r] : e[r];
    return n
}

function Kh(e, t) {
    return t.children.some(n => n === e || Kh(e, n))
}
const Uh = /#/g,
    fE = /&/g,
    dE = /\//g,
    pE = /=/g,
    hE = /\?/g,
    Jh = /\+/g,
    mE = /%5B/g,
    gE = /%5D/g,
    Gh = /%5E/g,
    yE = /%60/g,
    Wh = /%7B/g,
    bE = /%7C/g,
    zh = /%7D/g,
    vE = /%20/g;

function Cc(e) {
    return encodeURI("" + e).replace(bE, "|").replace(mE, "[").replace(gE, "]")
}

function _E(e) {
    return Cc(e).replace(Wh, "{").replace(zh, "}").replace(Gh, "^")
}

function Qs(e) {
    return Cc(e).replace(Jh, "%2B").replace(vE, "+").replace(Uh, "%23").replace(fE, "%26").replace(yE, "`").replace(Wh, "{").replace(zh, "}").replace(Gh, "^")
}

function wE(e) {
    return Qs(e).replace(pE, "%3D")
}

function EE(e) {
    return Cc(e).replace(Uh, "%23").replace(hE, "%3F")
}

function CE(e) {
    return e == null ? "" : EE(e).replace(dE, "%2F")
}

function Yi(e) {
    try {
        return decodeURIComponent("" + e)
    } catch {}
    return "" + e
}

function AE(e) {
    const t = {};
    if (e === "" || e === "?") return t;
    const r = (e[0] === "?" ? e.slice(1) : e).split("&");
    for (let a = 0; a < r.length; ++a) {
        const i = r[a].replace(Jh, " "),
            o = i.indexOf("="),
            s = Yi(o < 0 ? i : i.slice(0, o)),
            l = o < 0 ? null : Yi(i.slice(o + 1));
        if (s in t) {
            let c = t[s];
            xt(c) || (c = t[s] = [c]), c.push(l)
        } else t[s] = l
    }
    return t
}

function bf(e) {
    let t = "";
    for (let n in e) {
        const r = e[n];
        if (n = wE(n), r == null) {
            r !== void 0 && (t += (t.length ? "&" : "") + n);
            continue
        }(xt(r) ? r.map(i => i && Qs(i)) : [r && Qs(r)]).forEach(i => {
            i !== void 0 && (t += (t.length ? "&" : "") + n, i != null && (t += "=" + i))
        })
    }
    return t
}

function LE(e) {
    const t = {};
    for (const n in e) {
        const r = e[n];
        r !== void 0 && (t[n] = xt(r) ? r.map(a => a == null ? null : "" + a) : r == null ? r : "" + r)
    }
    return t
}
const SE = Symbol(""),
    vf = Symbol(""),
    Lo = Symbol(""),
    Ac = Symbol(""),
    Zs = Symbol("");

function zr() {
    let e = [];

    function t(r) {
        return e.push(r), () => {
            const a = e.indexOf(r);
            a > -1 && e.splice(a, 1)
        }
    }

    function n() {
        e = []
    }
    return {
        add: t,
        list: () => e.slice(),
        reset: n
    }
}

function gn(e, t, n, r, a) {
    const i = r && (r.enterCallbacks[a] = r.enterCallbacks[a] || []);
    return () => new Promise((o, s) => {
        const l = f => {
                f === !1 ? s(Tr(4, {
                    from: n,
                    to: t
                })) : f instanceof Error ? s(f) : Xw(f) ? s(Tr(2, {
                    from: t,
                    to: f
                })) : (i && r.enterCallbacks[a] === i && typeof f == "function" && i.push(f), o())
            },
            c = e.call(r && r.instances[a], t, n, l);
        let u = Promise.resolve(c);
        e.length < 3 && (u = u.then(l)), u.catch(f => s(f))
    })
}

function ss(e, t, n, r) {
    const a = [];
    for (const i of e)
        for (const o in i.components) {
            let s = i.components[o];
            if (!(t !== "beforeRouteEnter" && !i.instances[o]))
                if (TE(s)) {
                    const c = (s.__vccOpts || s)[t];
                    c && a.push(gn(c, n, r, i, o))
                } else {
                    let l = s();
                    a.push(() => l.then(c => {
                        if (!c) return Promise.reject(new Error(`Couldn't resolve component "${o}" at "${i.path}"`));
                        const u = xw(c) ? c.default : c;
                        i.components[o] = u;
                        const d = (u.__vccOpts || u)[t];
                        return d && gn(d, n, r, i, o)()
                    }))
                }
        }
    return a
}

function TE(e) {
    return typeof e == "object" || "displayName" in e || "props" in e || "__vccOpts" in e
}

function _f(e) {
    const t = Je(Lo),
        n = Je(Ac),
        r = W(() => t.resolve(pe(e.to))),
        a = W(() => {
            const {
                matched: l
            } = r.value, {
                length: c
            } = l, u = l[c - 1], f = n.matched;
            if (!u || !f.length) return -1;
            const d = f.findIndex(Sr.bind(null, u));
            if (d > -1) return d;
            const p = wf(l[c - 2]);
            return c > 1 && wf(u) === p && f[f.length - 1].path !== p ? f.findIndex(Sr.bind(null, l[c - 2])) : d
        }),
        i = W(() => a.value > -1 && ME(n.params, r.value.params)),
        o = W(() => a.value > -1 && a.value === n.matched.length - 1 && Bh(n.params, r.value.params));

    function s(l = {}) {
        return OE(l) ? t[pe(e.replace) ? "replace" : "push"](pe(e.to)).catch(fa) : Promise.resolve()
    }
    return {
        route: r,
        href: W(() => r.value.href),
        isActive: i,
        isExactActive: o,
        navigate: s
    }
}
const kE = Ne({
        name: "RouterLink",
        compatConfig: {
            MODE: 3
        },
        props: {
            to: {
                type: [String, Object],
                required: !0
            },
            replace: Boolean,
            activeClass: String,
            exactActiveClass: String,
            custom: Boolean,
            ariaCurrentValue: {
                type: String,
                default: "page"
            }
        },
        useLink: _f,
        setup(e, {
            slots: t
        }) {
            const n = tt(_f(e)),
                {
                    options: r
                } = Je(Lo),
                a = W(() => ({
                    [Ef(e.activeClass, r.linkActiveClass, "router-link-active")]: n.isActive,
                    [Ef(e.exactActiveClass, r.linkExactActiveClass, "router-link-exact-active")]: n.isExactActive
                }));
            return () => {
                const i = t.default && t.default(n);
                return e.custom ? i : Be("a", {
                    "aria-current": n.isExactActive ? e.ariaCurrentValue : null,
                    href: n.href,
                    onClick: n.navigate,
                    class: a.value
                }, i)
            }
        }
    }),
    RE = kE;

function OE(e) {
    if (!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && !(e.button !== void 0 && e.button !== 0)) {
        if (e.currentTarget && e.currentTarget.getAttribute) {
            const t = e.currentTarget.getAttribute("target");
            if (/\b_blank\b/i.test(t)) return
        }
        return e.preventDefault && e.preventDefault(), !0
    }
}

function ME(e, t) {
    for (const n in t) {
        const r = t[n],
            a = e[n];
        if (typeof r == "string") {
            if (r !== a) return !1
        } else if (!xt(a) || a.length !== r.length || r.some((i, o) => i !== a[o])) return !1
    }
    return !0
}

function wf(e) {
    return e ? e.aliasOf ? e.aliasOf.path : e.path : ""
}
const Ef = (e, t, n) => e ? ? t ? ? n,
    PE = Ne({
        name: "RouterView",
        inheritAttrs: !1,
        props: {
            name: {
                type: String,
                default: "default"
            },
            route: Object
        },
        compatConfig: {
            MODE: 3
        },
        setup(e, {
            attrs: t,
            slots: n
        }) {
            const r = Je(Zs),
                a = W(() => e.route || r.value),
                i = Je(vf, 0),
                o = W(() => {
                    let c = pe(i);
                    const {
                        matched: u
                    } = a.value;
                    let f;
                    for (;
                        (f = u[c]) && !f.components;) c++;
                    return c
                }),
                s = W(() => a.value.matched[o.value]);
            Qn(vf, W(() => o.value + 1)), Qn(SE, s), Qn(Zs, a);
            const l = Q();
            return we(() => [l.value, s.value, e.name], ([c, u, f], [d, p, v]) => {
                u && (u.instances[f] = c, p && p !== u && c && c === d && (u.leaveGuards.size || (u.leaveGuards = p.leaveGuards), u.updateGuards.size || (u.updateGuards = p.updateGuards))), c && u && (!p || !Sr(u, p) || !d) && (u.enterCallbacks[f] || []).forEach(E => E(c))
            }, {
                flush: "post"
            }), () => {
                const c = a.value,
                    u = e.name,
                    f = s.value,
                    d = f && f.components[u];
                if (!d) return Cf(n.default, {
                    Component: d,
                    route: c
                });
                const p = f.props[u],
                    v = p ? p === !0 ? c.params : typeof p == "function" ? p(c) : p : null,
                    w = Be(d, Ee({}, v, t, {
                        onVnodeUnmounted: h => {
                            h.component.isUnmounted && (f.instances[u] = null)
                        },
                        ref: l
                    }));
                return Cf(n.default, {
                    Component: w,
                    route: c
                }) || w
            }
        }
    });

function Cf(e, t) {
    if (!e) return null;
    const n = e(t);
    return n.length === 1 ? n[0] : n
}
const qh = PE;

function xE(e) {
    const t = sE(e.routes, e),
        n = e.parseQuery || AE,
        r = e.stringifyQuery || bf,
        a = e.history,
        i = zr(),
        o = zr(),
        s = zr(),
        l = Er(jt);
    let c = jt;
    pr && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
    const u = is.bind(null, j => "" + j),
        f = is.bind(null, CE),
        d = is.bind(null, Yi);

    function p(j, q) {
        let G, ee;
        return Vh(j) ? (G = t.getRecordMatcher(j), ee = q) : ee = j, t.addRoute(ee, G)
    }

    function v(j) {
        const q = t.getRecordMatcher(j);
        q && t.removeRoute(q)
    }

    function E() {
        return t.getRoutes().map(j => j.record)
    }

    function w(j) {
        return !!t.getRecordMatcher(j)
    }

    function h(j, q) {
        if (q = Ee({}, q || l.value), typeof j == "string") {
            const _ = os(n, j, q.path),
                T = t.resolve({
                    path: _.path
                }, q),
                P = a.createHref(_.fullPath);
            return Ee(_, T, {
                params: d(T.params),
                hash: Yi(_.hash),
                redirectedFrom: void 0,
                href: P
            })
        }
        let G;
        if ("path" in j) G = Ee({}, j, {
            path: os(n, j.path, q.path).path
        });
        else {
            const _ = Ee({}, j.params);
            for (const T in _) _[T] == null && delete _[T];
            G = Ee({}, j, {
                params: f(_)
            }), q.params = f(q.params)
        }
        const ee = t.resolve(G, q),
            ue = j.hash || "";
        ee.params = u(d(ee.params));
        const L = Nw(r, Ee({}, j, {
                hash: _E(ue),
                path: ee.path
            })),
            g = a.createHref(L);
        return Ee({
            fullPath: L,
            hash: ue,
            query: r === bf ? LE(j.query) : j.query || {}
        }, ee, {
            redirectedFrom: void 0,
            href: g
        })
    }

    function b(j) {
        return typeof j == "string" ? os(n, j, l.value.path) : Ee({}, j)
    }

    function m(j, q) {
        if (c !== j) return Tr(8, {
            from: q,
            to: j
        })
    }

    function y(j) {
        return A(j)
    }

    function C(j) {
        return y(Ee(b(j), {
            replace: !0
        }))
    }

    function S(j) {
        const q = j.matched[j.matched.length - 1];
        if (q && q.redirect) {
            const {
                redirect: G
            } = q;
            let ee = typeof G == "function" ? G(j) : G;
            return typeof ee == "string" && (ee = ee.includes("?") || ee.includes("#") ? ee = b(ee) : {
                path: ee
            }, ee.params = {}), Ee({
                query: j.query,
                hash: j.hash,
                params: "path" in ee ? {} : j.params
            }, ee)
        }
    }

    function A(j, q) {
        const G = c = h(j),
            ee = l.value,
            ue = j.state,
            L = j.force,
            g = j.replace === !0,
            _ = S(G);
        if (_) return A(Ee(b(_), {
            state: typeof _ == "object" ? Ee({}, ue, _.state) : ue,
            force: L,
            replace: g
        }), q || G);
        const T = G;
        T.redirectedFrom = q;
        let P;
        return !L && Fw(r, ee, G) && (P = Tr(16, {
            to: T,
            from: ee
        }), je(ee, ee, !0, !1)), (P ? Promise.resolve(P) : N(T, ee)).catch(F => Gt(F) ? Gt(F, 2) ? F : Ze(F) : X(F, T, ee)).then(F => {
            if (F) {
                if (Gt(F, 2)) return A(Ee({
                    replace: g
                }, b(F.to), {
                    state: typeof F.to == "object" ? Ee({}, ue, F.to.state) : ue,
                    force: L
                }), q || T)
            } else F = M(T, ee, !0, g, ue);
            return x(T, ee, F), F
        })
    }

    function R(j, q) {
        const G = m(j, q);
        return G ? Promise.reject(G) : Promise.resolve()
    }

    function O(j) {
        const q = Tt.values().next().value;
        return q && typeof q.runWithContext == "function" ? q.runWithContext(j) : j()
    }

    function N(j, q) {
        let G;
        const [ee, ue, L] = IE(j, q);
        G = ss(ee.reverse(), "beforeRouteLeave", j, q);
        for (const _ of ee) _.leaveGuards.forEach(T => {
            G.push(gn(T, j, q))
        });
        const g = R.bind(null, j, q);
        return G.push(g), $e(G).then(() => {
            G = [];
            for (const _ of i.list()) G.push(gn(_, j, q));
            return G.push(g), $e(G)
        }).then(() => {
            G = ss(ue, "beforeRouteUpdate", j, q);
            for (const _ of ue) _.updateGuards.forEach(T => {
                G.push(gn(T, j, q))
            });
            return G.push(g), $e(G)
        }).then(() => {
            G = [];
            for (const _ of L)
                if (_.beforeEnter)
                    if (xt(_.beforeEnter))
                        for (const T of _.beforeEnter) G.push(gn(T, j, q));
                    else G.push(gn(_.beforeEnter, j, q));
            return G.push(g), $e(G)
        }).then(() => (j.matched.forEach(_ => _.enterCallbacks = {}), G = ss(L, "beforeRouteEnter", j, q), G.push(g), $e(G))).then(() => {
            G = [];
            for (const _ of o.list()) G.push(gn(_, j, q));
            return G.push(g), $e(G)
        }).catch(_ => Gt(_, 8) ? _ : Promise.reject(_))
    }

    function x(j, q, G) {
        s.list().forEach(ee => O(() => ee(j, q, G)))
    }

    function M(j, q, G, ee, ue) {
        const L = m(j, q);
        if (L) return L;
        const g = q === jt,
            _ = pr ? history.state : {};
        G && (ee || g ? a.replace(j.fullPath, Ee({
            scroll: g && _ && _.scroll
        }, ue)) : a.push(j.fullPath, ue)), l.value = j, je(j, q, G, g), Ze()
    }
    let K;

    function ne() {
        K || (K = a.listen((j, q, G) => {
            if (!xn.listening) return;
            const ee = h(j),
                ue = S(ee);
            if (ue) {
                A(Ee(ue, {
                    replace: !0
                }), ee).catch(fa);
                return
            }
            c = ee;
            const L = l.value;
            pr && Jw(uf(L.fullPath, G.delta), Ao()), N(ee, L).catch(g => Gt(g, 12) ? g : Gt(g, 2) ? (A(g.to, ee).then(_ => {
                Gt(_, 20) && !G.delta && G.type === ka.pop && a.go(-1, !1)
            }).catch(fa), Promise.reject()) : (G.delta && a.go(-G.delta, !1), X(g, ee, L))).then(g => {
                g = g || M(ee, L, !1), g && (G.delta && !Gt(g, 8) ? a.go(-G.delta, !1) : G.type === ka.pop && Gt(g, 20) && a.go(-1, !1)), x(ee, L, g)
            }).catch(fa)
        }))
    }
    let te = zr(),
        J = zr(),
        ae;

    function X(j, q, G) {
        Ze(j);
        const ee = J.list();
        return ee.length ? ee.forEach(ue => ue(j, q, G)) : console.error(j), Promise.reject(j)
    }

    function Ce() {
        return ae && l.value !== jt ? Promise.resolve() : new Promise((j, q) => {
            te.add([j, q])
        })
    }

    function Ze(j) {
        return ae || (ae = !j, ne(), te.list().forEach(([q, G]) => j ? G(j) : q()), te.reset()), j
    }

    function je(j, q, G, ee) {
        const {
            scrollBehavior: ue
        } = e;
        if (!pr || !ue) return Promise.resolve();
        const L = !G && Gw(uf(j.fullPath, 0)) || (ee || !G) && history.state && history.state.scroll || null;
        return St().then(() => ue(j, q, L)).then(g => g && Uw(g)).catch(g => X(g, j, q))
    }
    const Ie = j => a.go(j);
    let Me;
    const Tt = new Set,
        xn = {
            currentRoute: l,
            listening: !0,
            addRoute: p,
            removeRoute: v,
            hasRoute: w,
            getRoutes: E,
            resolve: h,
            options: e,
            push: y,
            replace: C,
            go: Ie,
            back: () => Ie(-1),
            forward: () => Ie(1),
            beforeEach: i.add,
            beforeResolve: o.add,
            afterEach: s.add,
            onError: J.add,
            isReady: Ce,
            install(j) {
                const q = this;
                j.component("RouterLink", RE), j.component("RouterView", qh), j.config.globalProperties.$router = q, Object.defineProperty(j.config.globalProperties, "$route", {
                    enumerable: !0,
                    get: () => pe(l)
                }), pr && !Me && l.value === jt && (Me = !0, y(a.location).catch(ue => {}));
                const G = {};
                for (const ue in jt) Object.defineProperty(G, ue, {
                    get: () => l.value[ue],
                    enumerable: !0
                });
                j.provide(Lo, q), j.provide(Ac, Ha(G)), j.provide(Zs, l);
                const ee = j.unmount;
                Tt.add(j), j.unmount = function() {
                    Tt.delete(j), Tt.size < 1 && (c = jt, K && K(), K = null, l.value = jt, Me = !1, ae = !1), ee()
                }
            }
        };

    function $e(j) {
        return j.reduce((q, G) => q.then(() => O(G)), Promise.resolve())
    }
    return xn
}

function IE(e, t) {
    const n = [],
        r = [],
        a = [],
        i = Math.max(t.matched.length, e.matched.length);
    for (let o = 0; o < i; o++) {
        const s = t.matched[o];
        s && (e.matched.find(c => Sr(c, s)) ? r.push(s) : n.push(s));
        const l = e.matched[o];
        l && (t.matched.find(c => Sr(c, l)) || a.push(l))
    }
    return [n, r, a]
}

function Lc() {
    return Je(Lo)
}

function So() {
    return Je(Ac)
}
const k = {
        layout: "error"
    },
    Af = [{
        name: (k == null ? void 0 : k.name) ? ? "all___en",
        path: (k == null ? void 0 : k.path) ? ? "/en/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___de",
        path: (k == null ? void 0 : k.path) ? ? "/de/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___es",
        path: (k == null ? void 0 : k.path) ? ? "/es/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___fr",
        path: (k == null ? void 0 : k.path) ? ? "/fr/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___it",
        path: (k == null ? void 0 : k.path) ? ? "/it/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___pl",
        path: (k == null ? void 0 : k.path) ? ? "/pl/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___pt",
        path: (k == null ? void 0 : k.path) ? ? "/pt/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___ru",
        path: (k == null ? void 0 : k.path) ? ? "/ru/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___tr",
        path: (k == null ? void 0 : k.path) ? ? "/tr/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___uk",
        path: (k == null ? void 0 : k.path) ? ? "/uk/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___vi",
        path: (k == null ? void 0 : k.path) ? ? "/vi/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___ar",
        path: (k == null ? void 0 : k.path) ? ? "/ar/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___th",
        path: (k == null ? void 0 : k.path) ? ? "/th/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___ko",
        path: (k == null ? void 0 : k.path) ? ? "/ko/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___zh",
        path: (k == null ? void 0 : k.path) ? ? "/zh/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: (k == null ? void 0 : k.name) ? ? "all___ja",
        path: (k == null ? void 0 : k.path) ? ? "/ja/:all(.*)*/",
        meta: k || {},
        alias: (k == null ? void 0 : k.alias) || [],
        redirect: (k == null ? void 0 : k.redirect) || void 0,
        component: () => D(() =>
            import ("./_...all_.8a9b27e5.js"), [],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___en",
        path: "/en/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___de",
        path: "/de/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___es",
        path: "/es/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___fr",
        path: "/fr/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___it",
        path: "/it/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___pl",
        path: "/pl/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___pt",
        path: "/pt/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___ru",
        path: "/ru/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___tr",
        path: "/tr/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___uk",
        path: "/uk/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___vi",
        path: "/vi/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___ar",
        path: "/ar/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___th",
        path: "/th/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___ko",
        path: "/ko/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___zh",
        path: "/zh/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "contact___ja",
        path: "/ja/contact/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.e7cd235d.js"), ["./index.e7cd235d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___en",
        path: "/en/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___de",
        path: "/de/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___es",
        path: "/es/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___fr",
        path: "/fr/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___it",
        path: "/it/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___pl",
        path: "/pl/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___pt",
        path: "/pt/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___ru",
        path: "/ru/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___tr",
        path: "/tr/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___uk",
        path: "/uk/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___vi",
        path: "/vi/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___ar",
        path: "/ar/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___th",
        path: "/th/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___ko",
        path: "/ko/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___zh",
        path: "/zh/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "faq___ja",
        path: "/ja/faq/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d5498dd1.js"), ["./index.d5498dd1.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___en",
        path: "/en/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___de",
        path: "/de/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___es",
        path: "/es/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___fr",
        path: "/fr/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___it",
        path: "/it/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___pl",
        path: "/pl/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___pt",
        path: "/pt/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___ru",
        path: "/ru/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___tr",
        path: "/tr/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___uk",
        path: "/uk/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___vi",
        path: "/vi/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___ar",
        path: "/ar/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___th",
        path: "/th/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___ko",
        path: "/ko/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___zh",
        path: "/zh/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "feedback___ja",
        path: "/ja/feedback/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.2979365a.js"), ["./index.2979365a.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./index.008dc6b4.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___en",
        path: "/en/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___de",
        path: "/de/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___es",
        path: "/es/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___fr",
        path: "/fr/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___it",
        path: "/it/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___pl",
        path: "/pl/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___pt",
        path: "/pt/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___ru",
        path: "/ru/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___tr",
        path: "/tr/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___uk",
        path: "/uk/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___vi",
        path: "/vi/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___ar",
        path: "/ar/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___th",
        path: "/th/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___ko",
        path: "/ko/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___zh",
        path: "/zh/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "index___ja",
        path: "/ja/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.8b5d3f63.js"), ["./index.8b5d3f63.js", "./client-only.be8c7cca.js", "./index.1bdff377.css"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___en",
        path: "/en/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___de",
        path: "/de/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___es",
        path: "/es/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___fr",
        path: "/fr/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___it",
        path: "/it/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___pl",
        path: "/pl/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___pt",
        path: "/pt/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___ru",
        path: "/ru/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___tr",
        path: "/tr/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___uk",
        path: "/uk/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___vi",
        path: "/vi/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___ar",
        path: "/ar/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___th",
        path: "/th/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___ko",
        path: "/ko/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___zh",
        path: "/zh/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "privacy___ja",
        path: "/ja/privacy/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./index.d7d98898.js"), ["./index.d7d98898.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___en",
        path: "/en/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___de",
        path: "/de/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___es",
        path: "/es/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___fr",
        path: "/fr/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___it",
        path: "/it/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___pl",
        path: "/pl/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___pt",
        path: "/pt/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___ru",
        path: "/ru/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___tr",
        path: "/tr/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___uk",
        path: "/uk/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___vi",
        path: "/vi/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___ar",
        path: "/ar/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___th",
        path: "/th/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___ko",
        path: "/ko/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___zh",
        path: "/zh/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "source-id___ja",
        path: "/ja/source/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.aee15b9d.js"), ["./_id_.aee15b9d.js", "./Back.6f380bb5.js", "./Title.b270e0d6.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___en",
        path: "/en/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___de",
        path: "/de/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___es",
        path: "/es/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___fr",
        path: "/fr/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___it",
        path: "/it/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___pl",
        path: "/pl/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___pt",
        path: "/pt/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___ru",
        path: "/ru/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___tr",
        path: "/tr/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___uk",
        path: "/uk/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___vi",
        path: "/vi/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___ar",
        path: "/ar/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___th",
        path: "/th/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___ko",
        path: "/ko/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___zh",
        path: "/zh/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }, {
        name: "view-id___ja",
        path: "/ja/view/:id()/",
        meta: {},
        alias: [],
        redirect: void 0,
        component: () => D(() =>
            import ("./_id_.c0bba723.js"), ["./_id_.c0bba723.js", "./Back.6f380bb5.js", "./Tooltip.06538c8d.js", "./client-only.be8c7cca.js"],
            import.meta.url).then(e => e.default || e)
    }],
    Yh = (e, t, n) => (t = t === !0 ? {} : t, {
        default: () => {
            var r;
            return t ? Be(e, t, n) : (r = n.default) == null ? void 0 : r.call(n)
        }
    });

function Lf(e) {
    const t = (e == null ? void 0 : e.meta.key) ? ? e.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, n => {
        var r;
        return ((r = e.params[n.slice(1)]) == null ? void 0 : r.toString()) || ""
    });
    return typeof t == "function" ? t(e) : t
}

function DE(e, t) {
    return e === t ? !1 : Lf(e) !== Lf(t) ? !0 : !e.matched.every((r, a) => {
        var i, o;
        return r.components && r.components.default === ((o = (i = t.matched[a]) == null ? void 0 : i.components) == null ? void 0 : o.default)
    })
}
const NE = {
    scrollBehavior(e, t, n) {
        var c;
        const r = ge(),
            a = ((c = pt().options) == null ? void 0 : c.scrollBehaviorType) ? ? "auto";
        let i = n || void 0;
        const o = typeof e.meta.scrollToTop == "function" ? e.meta.scrollToTop(e, t) : e.meta.scrollToTop;
        if (!i && t && e && o !== !1 && DE(e, t) && (i = {
                left: 0,
                top: 0
            }), e.path === t.path) {
            if (t.hash && !e.hash) return {
                left: 0,
                top: 0
            };
            if (e.hash) return {
                el: e.hash,
                top: Sf(e.hash),
                behavior: a
            }
        }
        const s = u => !!(u.meta.pageTransition ? ? Ys),
            l = s(t) && s(e) ? "page:transition:finish" : "page:finish";
        return new Promise(u => {
            r.hooks.hookOnce(l, async () => {
                await St(), e.hash && (i = {
                    el: e.hash,
                    top: Sf(e.hash),
                    behavior: a
                }), u(i)
            })
        })
    }
};

function Sf(e) {
    try {
        const t = document.querySelector(e);
        if (t) return parseFloat(getComputedStyle(t).scrollMarginTop)
    } catch {}
    return 0
}
const FE = {
        hashMode: !1,
        scrollBehaviorType: "auto"
    },
    st = { ...FE,
        ...NE
    },
    BE = async e => {
        var l;
        let t, n;
        if (!((l = e.meta) != null && l.validate)) return;
        const r = ge(),
            a = pt();
        if (([t, n] = Cn(() => Promise.resolve(e.meta.validate(e))), t = await t, n(), t) === !0) return;
        const o = Ec({
                statusCode: 404,
                statusMessage: `Page Not Found: ${e.fullPath}`
            }),
            s = a.beforeResolve(c => {
                if (s(), c === e) {
                    const u = a.afterEach(async () => {
                        u(), await r.runWithContext(() => yn(o)), window.history.pushState({}, "", e.fullPath)
                    });
                    return !1
                }
            })
    },
    jE = async e => {
        let t, n;
        const r = ([t, n] = Cn(() => Lw(e.path)), t = await t, n(), t);
        if (r.redirect) return r.redirect
    },
    $E = [BE, jE],
    pa = {};

function VE(e, t, n) {
    const {
        pathname: r,
        search: a,
        hash: i
    } = t, o = e.indexOf("#");
    if (o > -1) {
        const c = i.includes(e.slice(o)) ? e.slice(o).length : 1;
        let u = i.slice(c);
        return u[0] !== "/" && (u = "/" + u), Wu(u, "")
    }
    const s = Wu(r, e),
        l = !n || Vs(s, n, {
            trailingSlash: !0
        }) ? s : n;
    return l + (l.includes("?") ? "" : a) + i
}
const HE = Qe({
        name: "nuxt:router",
        enforce: "pre",
        async setup(e) {
            var E, w;
            let t, n, r = Nt().app.baseURL;
            st.hashMode && !r.includes("#") && (r += "#");
            const a = ((E = st.history) == null ? void 0 : E.call(st, r)) ? ? (st.hashMode ? Yw(r) : $h(r)),
                i = ((w = st.routes) == null ? void 0 : w.call(st, Af)) ? ? Af;
            let o;
            const s = VE(r, window.location, e.payload.path),
                l = xE({ ...st,
                    scrollBehavior: (h, b, m) => {
                        var y;
                        if (b === jt) {
                            o = m;
                            return
                        }
                        return l.options.scrollBehavior = st.scrollBehavior, (y = st.scrollBehavior) == null ? void 0 : y.call(st, h, jt, o || m)
                    },
                    history: a,
                    routes: i
                });
            e.vueApp.use(l);
            const c = Er(l.currentRoute.value);
            l.afterEach((h, b) => {
                c.value = b
            }), Object.defineProperty(e.vueApp.config.globalProperties, "previousRoute", {
                get: () => c.value
            });
            const u = Er(l.resolve(s)),
                f = () => {
                    u.value = l.currentRoute.value
                };
            e.hook("page:finish", f), l.afterEach((h, b) => {
                var m, y, C, S;
                ((y = (m = h.matched[0]) == null ? void 0 : m.components) == null ? void 0 : y.default) === ((S = (C = b.matched[0]) == null ? void 0 : C.components) == null ? void 0 : S.default) && f()
            });
            const d = {};
            for (const h in u.value) Object.defineProperty(d, h, {
                get: () => u.value[h]
            });
            e._route = Ha(d), e._middleware = e._middleware || {
                global: [],
                named: {}
            };
            const p = Co();
            try {
                [t, n] = Cn(() => l.isReady()), await t, n()
            } catch (h) {
                [t, n] = Cn(() => e.runWithContext(() => yn(h))), await t, n()
            }
            const v = e.payload.state._layout;
            return l.beforeEach(async (h, b) => {
                var m;
                h.meta = tt(h.meta), e.isHydrating && v && !tr(h.meta.layout) && (h.meta.layout = v), e._processingMiddleware = !0; {
                    const y = new Set([...$E, ...e._middleware.global]);
                    for (const C of h.matched) {
                        const S = C.meta.middleware;
                        if (S)
                            if (Array.isArray(S))
                                for (const A of S) y.add(A);
                            else y.add(S)
                    }
                    for (const C of y) {
                        const S = typeof C == "string" ? e._middleware.named[C] || await ((m = pa[C]) == null ? void 0 : m.call(pa).then(R => R.default || R)) : C;
                        if (!S) throw new Error(`Unknown route middleware: '${C}'.`);
                        const A = await e.runWithContext(() => S(h, b));
                        if (!e.payload.serverRendered && e.isHydrating && (A === !1 || A instanceof Error)) {
                            const R = A || zs({
                                statusCode: 404,
                                statusMessage: `Page Not Found: ${s}`
                            });
                            return await e.runWithContext(() => yn(R)), !1
                        }
                        if (A !== !0 && (A || A === !1)) return A
                    }
                }
            }), l.onError(() => {
                delete e._processingMiddleware
            }), l.afterEach(async (h, b, m) => {
                delete e._processingMiddleware, !e.isHydrating && p.value && await e.runWithContext(hw), h.matched.length === 0 && await e.runWithContext(() => yn(zs({
                    statusCode: 404,
                    fatal: !1,
                    statusMessage: `Page not found: ${h.fullPath}`
                })))
            }), e.hooks.hookOnce("app:created", async () => {
                try {
                    await l.replace({ ...l.resolve(s),
                        name: void 0,
                        force: !0
                    }), l.options.scrollBehavior = st.scrollBehavior
                } catch (h) {
                    await e.runWithContext(() => yn(h))
                }
            }), {
                provide: {
                    router: l
                }
            }
        }
    }),
    KE = !1,
    UE = !0;
/*!
 * pinia v2.1.7
 * (c) 2023 Eduardo San Martin Morote
 * @license MIT
 */
let Xh;
const za = e => Xh = e,
    Qh = Symbol();

function el(e) {
    return e && typeof e == "object" && Object.prototype.toString.call(e) === "[object Object]" && typeof e.toJSON != "function"
}
var ha;
(function(e) {
    e.direct = "direct", e.patchObject = "patch object", e.patchFunction = "patch function"
})(ha || (ha = {}));

function JE() {
    const e = Va(!0),
        t = e.run(() => Q({}));
    let n = [],
        r = [];
    const a = uo({
        install(i) {
            za(a), a._a = i, i.provide(Qh, a), i.config.globalProperties.$pinia = a, r.forEach(o => n.push(o)), r = []
        },
        use(i) {
            return !this._a && !KE ? r.push(i) : n.push(i), this
        },
        _p: n,
        _a: null,
        _e: e,
        _s: new Map,
        state: t
    });
    return a
}
const Zh = () => {};

function Tf(e, t, n, r = Zh) {
    e.push(t);
    const a = () => {
        const i = e.indexOf(t);
        i > -1 && (e.splice(i, 1), r())
    };
    return !n && Nr() && lo(a), a
}

function fr(e, ...t) {
    e.slice().forEach(n => {
        n(...t)
    })
}
const GE = e => e();

function tl(e, t) {
    e instanceof Map && t instanceof Map && t.forEach((n, r) => e.set(r, n)), e instanceof Set && t instanceof Set && t.forEach(e.add, e);
    for (const n in t) {
        if (!t.hasOwnProperty(n)) continue;
        const r = t[n],
            a = e[n];
        el(a) && el(r) && e.hasOwnProperty(n) && !_e(r) && !en(r) ? e[n] = tl(a, r) : e[n] = r
    }
    return e
}
const WE = Symbol();

function zE(e) {
    return !el(e) || !e.hasOwnProperty(WE)
}
const {
    assign: pn
} = Object;

function qE(e) {
    return !!(_e(e) && e.effect)
}

function YE(e, t, n, r) {
    const {
        state: a,
        actions: i,
        getters: o
    } = t, s = n.state.value[e];
    let l;

    function c() {
        s || (n.state.value[e] = a ? a() : {});
        const u = ub(n.state.value[e]);
        return pn(u, i, Object.keys(o || {}).reduce((f, d) => (f[d] = uo(W(() => {
            za(n);
            const p = n._s.get(e);
            return o[d].call(p, p)
        })), f), {}))
    }
    return l = em(e, c, t, n, r, !0), l
}

function em(e, t, n = {}, r, a, i) {
    let o;
    const s = pn({
            actions: {}
        }, n),
        l = {
            deep: !0
        };
    let c, u, f = [],
        d = [],
        p;
    const v = r.state.value[e];
    !i && !v && (r.state.value[e] = {}), Q({});
    let E;

    function w(R) {
        let O;
        c = u = !1, typeof R == "function" ? (R(r.state.value[e]), O = {
            type: ha.patchFunction,
            storeId: e,
            events: p
        }) : (tl(r.state.value[e], R), O = {
            type: ha.patchObject,
            payload: R,
            storeId: e,
            events: p
        });
        const N = E = Symbol();
        St().then(() => {
            E === N && (c = !0)
        }), u = !0, fr(f, O, r.state.value[e])
    }
    const h = i ? function() {
        const {
            state: O
        } = n, N = O ? O() : {};
        this.$patch(x => {
            pn(x, N)
        })
    } : Zh;

    function b() {
        o.stop(), f = [], d = [], r._s.delete(e)
    }

    function m(R, O) {
        return function() {
            za(r);
            const N = Array.from(arguments),
                x = [],
                M = [];

            function K(J) {
                x.push(J)
            }

            function ne(J) {
                M.push(J)
            }
            fr(d, {
                args: N,
                name: R,
                store: C,
                after: K,
                onError: ne
            });
            let te;
            try {
                te = O.apply(this && this.$id === e ? this : C, N)
            } catch (J) {
                throw fr(M, J), J
            }
            return te instanceof Promise ? te.then(J => (fr(x, J), J)).catch(J => (fr(M, J), Promise.reject(J))) : (fr(x, te), te)
        }
    }
    const y = {
            _p: r,
            $id: e,
            $onAction: Tf.bind(null, d),
            $patch: w,
            $reset: h,
            $subscribe(R, O = {}) {
                const N = Tf(f, R, O.detached, () => x()),
                    x = o.run(() => we(() => r.state.value[e], M => {
                        (O.flush === "sync" ? u : c) && R({
                            storeId: e,
                            type: ha.direct,
                            events: p
                        }, M)
                    }, pn({}, l, O)));
                return N
            },
            $dispose: b
        },
        C = tt(y);
    r._s.set(e, C);
    const A = (r._a && r._a.runWithContext || GE)(() => r._e.run(() => (o = Va()).run(t)));
    for (const R in A) {
        const O = A[R];
        if (_e(O) && !qE(O) || en(O)) i || (v && zE(O) && (_e(O) ? O.value = v[R] : tl(O, v[R])), r.state.value[e][R] = O);
        else if (typeof O == "function") {
            const N = m(R, O);
            A[R] = N, s.actions[R] = O
        }
    }
    return pn(C, A), pn(he(C), A), Object.defineProperty(C, "$state", {
        get: () => r.state.value[e],
        set: R => {
            w(O => {
                pn(O, R)
            })
        }
    }), r._p.forEach(R => {
        pn(C, o.run(() => R({
            store: C,
            app: r._a,
            pinia: r,
            options: s
        })))
    }), v && i && n.hydrate && n.hydrate(C.$state, v), c = !0, u = !0, C
}

function To(e, t, n) {
    let r, a;
    const i = typeof t == "function";
    typeof e == "string" ? (r = e, a = i ? n : t) : (a = e, r = e.id);

    function o(s, l) {
        const c = fc();
        return s = s || (c ? Je(Qh, null) : null), s && za(s), s = Xh, s._s.has(r) || (i ? em(r, t, a, s) : YE(r, a, s)), s._s.get(r)
    }
    return o.$id = r, o
}

function CP(e) {
    {
        e = he(e);
        const t = {};
        for (const n in e) {
            const r = e[n];
            (_e(r) || en(r)) && (t[n] = ir(e, n))
        }
        return t
    }
}
const nl = globalThis.requestIdleCallback || (e => {
        const t = Date.now(),
            n = {
                didTimeout: !1,
                timeRemaining: () => Math.max(0, 50 - (Date.now() - t))
            };
        return setTimeout(() => {
            e(n)
        }, 1)
    }),
    XE = globalThis.cancelIdleCallback || (e => {
        clearTimeout(e)
    }),
    tm = e => {
        const t = ge();
        t.isHydrating ? t.hooks.hookOnce("app:suspense:resolve", () => {
            nl(e)
        }) : nl(e)
    },
    QE = "$s";

function qa(...e) {
    const t = typeof e[e.length - 1] == "string" ? e.pop() : void 0;
    typeof e[0] != "string" && e.unshift(t);
    const [n, r] = e;
    if (!n || typeof n != "string") throw new TypeError("[nuxt] [useState] key must be a string: " + n);
    if (r !== void 0 && typeof r != "function") throw new Error("[nuxt] [useState] init must be a function: " + r);
    const a = QE + n,
        i = ge(),
        o = ir(i.payload.state, a);
    if (o.value === void 0 && r) {
        const s = r();
        if (_e(s)) return i.payload.state[a] = s, s;
        o.value = s
    }
    return o
}
const kf = Object.freeze({
    ignoreUnknown: !1,
    respectType: !1,
    respectFunctionNames: !1,
    respectFunctionProperties: !1,
    unorderedObjects: !0,
    unorderedArrays: !1,
    unorderedSets: !1,
    excludeKeys: void 0,
    excludeValues: void 0,
    replacer: void 0
});

function Rf(e, t) {
    t ? t = { ...kf,
        ...t
    } : t = kf;
    const n = nm(t);
    return n.dispatch(e), n.toString()
}
const ZE = Object.freeze(["prototype", "__proto__", "constructor"]);

function nm(e) {
    let t = "",
        n = new Map;
    const r = a => {
        t += a
    };
    return {
        toString() {
            return t
        },
        getContext() {
            return n
        },
        dispatch(a) {
            return e.replacer && (a = e.replacer(a)), this[a === null ? "null" : typeof a](a)
        },
        object(a) {
            if (a && typeof a.toJSON == "function") return this.object(a.toJSON());
            const i = Object.prototype.toString.call(a);
            let o = "";
            const s = i.length;
            s < 10 ? o = "unknown:[" + i + "]" : o = i.slice(8, s - 1), o = o.toLowerCase();
            let l = null;
            if ((l = n.get(a)) === void 0) n.set(a, n.size);
            else return this.dispatch("[CIRCULAR:" + l + "]");
            if (typeof Buffer < "u" && Buffer.isBuffer && Buffer.isBuffer(a)) return r("buffer:"), r(a.toString("utf8"));
            if (o !== "object" && o !== "function" && o !== "asyncfunction") this[o] ? this[o](a) : e.ignoreUnknown || this.unkown(a, o);
            else {
                let c = Object.keys(a);
                e.unorderedObjects && (c = c.sort());
                let u = [];
                e.respectType !== !1 && !Of(a) && (u = ZE), e.excludeKeys && (c = c.filter(d => !e.excludeKeys(d)), u = u.filter(d => !e.excludeKeys(d))), r("object:" + (c.length + u.length) + ":");
                const f = d => {
                    this.dispatch(d), r(":"), e.excludeValues || this.dispatch(a[d]), r(",")
                };
                for (const d of c) f(d);
                for (const d of u) f(d)
            }
        },
        array(a, i) {
            if (i = i === void 0 ? e.unorderedArrays !== !1 : i, r("array:" + a.length + ":"), !i || a.length <= 1) {
                for (const l of a) this.dispatch(l);
                return
            }
            const o = new Map,
                s = a.map(l => {
                    const c = nm(e);
                    c.dispatch(l);
                    for (const [u, f] of c.getContext()) o.set(u, f);
                    return c.toString()
                });
            return n = o, s.sort(), this.array(s, !1)
        },
        date(a) {
            return r("date:" + a.toJSON())
        },
        symbol(a) {
            return r("symbol:" + a.toString())
        },
        unkown(a, i) {
            if (r(i), !!a && (r(":"), a && typeof a.entries == "function")) return this.array(Array.from(a.entries()), !0)
        },
        error(a) {
            return r("error:" + a.toString())
        },
        boolean(a) {
            return r("bool:" + a)
        },
        string(a) {
            r("string:" + a.length + ":"), r(a)
        },
        function(a) {
            r("fn:"), Of(a) ? this.dispatch("[native]") : this.dispatch(a.toString()), e.respectFunctionNames !== !1 && this.dispatch("function-name:" + String(a.name)), e.respectFunctionProperties && this.object(a)
        },
        number(a) {
            return r("number:" + a)
        },
        xml(a) {
            return r("xml:" + a.toString())
        },
        null() {
            return r("Null")
        },
        undefined() {
            return r("Undefined")
        },
        regexp(a) {
            return r("regex:" + a.toString())
        },
        uint8array(a) {
            return r("uint8array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        uint8clampedarray(a) {
            return r("uint8clampedarray:"), this.dispatch(Array.prototype.slice.call(a))
        },
        int8array(a) {
            return r("int8array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        uint16array(a) {
            return r("uint16array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        int16array(a) {
            return r("int16array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        uint32array(a) {
            return r("uint32array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        int32array(a) {
            return r("int32array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        float32array(a) {
            return r("float32array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        float64array(a) {
            return r("float64array:"), this.dispatch(Array.prototype.slice.call(a))
        },
        arraybuffer(a) {
            return r("arraybuffer:"), this.dispatch(new Uint8Array(a))
        },
        url(a) {
            return r("url:" + a.toString())
        },
        map(a) {
            r("map:");
            const i = [...a];
            return this.array(i, e.unorderedSets !== !1)
        },
        set(a) {
            r("set:");
            const i = [...a];
            return this.array(i, e.unorderedSets !== !1)
        },
        file(a) {
            return r("file:"), this.dispatch([a.name, a.size, a.type, a.lastModfied])
        },
        blob() {
            if (e.ignoreUnknown) return r("[blob]");
            throw new Error(`Hashing Blob objects is currently not supported
Use "options.replacer" or "options.ignoreUnknown"
`)
        },
        domwindow() {
            return r("domwindow")
        },
        bigint(a) {
            return r("bigint:" + a.toString())
        },
        process() {
            return r("process")
        },
        timer() {
            return r("timer")
        },
        pipe() {
            return r("pipe")
        },
        tcp() {
            return r("tcp")
        },
        udp() {
            return r("udp")
        },
        tty() {
            return r("tty")
        },
        statwatcher() {
            return r("statwatcher")
        },
        securecontext() {
            return r("securecontext")
        },
        connection() {
            return r("connection")
        },
        zlib() {
            return r("zlib")
        },
        context() {
            return r("context")
        },
        nodescript() {
            return r("nodescript")
        },
        httpparser() {
            return r("httpparser")
        },
        dataview() {
            return r("dataview")
        },
        signal() {
            return r("signal")
        },
        fsevent() {
            return r("fsevent")
        },
        tlswrap() {
            return r("tlswrap")
        }
    }
}
const rm = "[native code] }",
    eC = rm.length;

function Of(e) {
    return typeof e != "function" ? !1 : Function.prototype.toString.call(e).slice(-eC) === rm
}

function tC(e, t, n = {}) {
    return e === t || Rf(e, n) === Rf(t, n)
}
const nC = {
    path: "/",
    watch: !0,
    decode: e => Ta(decodeURIComponent(e)),
    encode: e => encodeURIComponent(typeof e == "string" ? e : JSON.stringify(e))
};

function am(e, t) {
    var l;
    const n = { ...nC,
            ...t
        },
        r = rC(n) || {};
    let a;
    n.maxAge !== void 0 ? a = n.maxAge * 1e3 : n.expires && (a = n.expires.getTime() - Date.now());
    const i = a !== void 0 && a <= 0,
        o = i ? void 0 : r[e] ? ? ((l = n.default) == null ? void 0 : l.call(n)),
        s = a && !i ? oC(o, a) : Q(o); {
        const c = typeof BroadcastChannel > "u" ? null : new BroadcastChannel(`nuxt:cookies:${e}`),
            u = () => {
                iC(e, s.value, n), c == null || c.postMessage(n.encode(s.value))
            };
        let f = !1;
        Nr() && lo(() => {
            f = !0, u(), c == null || c.close()
        }), c && (c.onmessage = d => {
            f = !0, s.value = n.decode(d.data), St(() => {
                f = !1
            })
        }), n.watch ? we(s, () => {
            f || u()
        }, {
            deep: n.watch !== "shallow"
        }) : u()
    }
    return s
}

function rC(e = {}) {
    return tw(document.cookie, e)
}

function aC(e, t, n = {}) {
    return t == null ? af(e, t, { ...n,
        maxAge: -1
    }) : af(e, t, n)
}

function iC(e, t, n = {}) {
    document.cookie = aC(e, t, n)
}
const Mf = 2147483647;

function oC(e, t) {
    let n, r = 0;
    return Nr() && lo(() => {
        clearTimeout(n)
    }), cb((a, i) => {
        function o() {
            clearTimeout(n);
            const s = t - r,
                l = s < Mf ? s : Mf;
            n = setTimeout(() => {
                if (r += l, r < t) return o();
                e = void 0, i()
            }, l)
        }
        return {
            get() {
                return a(), e
            },
            set(s) {
                o(), e = s, i()
            }
        }
    })
}
async function im(e, t = pt()) {
    const {
        path: n,
        matched: r
    } = t.resolve(e);
    if (!r.length || (t._routePreloaded || (t._routePreloaded = new Set), t._routePreloaded.has(n))) return;
    const a = t._preloadPromises = t._preloadPromises || [];
    if (a.length > 4) return Promise.all(a).then(() => im(e, t));
    t._routePreloaded.add(n);
    const i = r.map(o => {
        var s;
        return (s = o.components) == null ? void 0 : s.default
    }).filter(o => typeof o == "function");
    for (const o of i) {
        const s = Promise.resolve(o()).catch(() => {}).finally(() => a.splice(a.indexOf(s)));
        a.push(s)
    }
    await Promise.all(a)
}

function sC(e = {}) {
    const t = e.path || window.location.pathname;
    let n = {};
    try {
        n = Ta(sessionStorage.getItem("nuxt:reload") || "{}")
    } catch {}
    if (e.force || (n == null ? void 0 : n.path) !== t || (n == null ? void 0 : n.expires) < Date.now()) {
        try {
            sessionStorage.setItem("nuxt:reload", JSON.stringify({
                path: t,
                expires: Date.now() + (e.ttl ? ? 1e4)
            }))
        } catch {}
        if (e.persistState) try {
            sessionStorage.setItem("nuxt:reload:state", JSON.stringify({
                state: ge().payload.state
            }))
        } catch {}
        window.location.pathname !== t ? window.location.href = t : window.location.reload()
    }
}
const lC = (...e) => e.find(t => t !== void 0),
    cC = "noopener noreferrer"; /*! @__NO_SIDE_EFFECTS__ */
function uC(e) {
    const t = e.componentName || "NuxtLink",
        n = (r, a) => {
            if (!r || e.trailingSlash !== "append" && e.trailingSlash !== "remove") return r;
            const i = e.trailingSlash === "append" ? Ji : yc;
            if (typeof r == "string") return i(r, !0);
            const o = "path" in r ? r.path : a(r).path;
            return { ...r,
                name: void 0,
                path: i(o, !0)
            }
        };
    return Ne({
        name: t,
        props: {
            to: {
                type: [String, Object],
                default: void 0,
                required: !1
            },
            href: {
                type: [String, Object],
                default: void 0,
                required: !1
            },
            target: {
                type: String,
                default: void 0,
                required: !1
            },
            rel: {
                type: String,
                default: void 0,
                required: !1
            },
            noRel: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            prefetch: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            noPrefetch: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            activeClass: {
                type: String,
                default: void 0,
                required: !1
            },
            exactActiveClass: {
                type: String,
                default: void 0,
                required: !1
            },
            prefetchedClass: {
                type: String,
                default: void 0,
                required: !1
            },
            replace: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            ariaCurrentValue: {
                type: String,
                default: void 0,
                required: !1
            },
            external: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            custom: {
                type: Boolean,
                default: void 0,
                required: !1
            }
        },
        setup(r, {
            slots: a
        }) {
            const i = pt(),
                o = Nt(),
                s = W(() => {
                    const p = r.to || r.href || "";
                    return n(p, i.resolve)
                }),
                l = W(() => typeof s.value == "string" && or(s.value, {
                    acceptRelative: !0
                })),
                c = W(() => r.external || r.target && r.target !== "_self" ? !0 : typeof s.value == "object" ? !1 : s.value === "" || l.value),
                u = Q(!1),
                f = Q(null),
                d = p => {
                    var v;
                    f.value = r.custom ? (v = p == null ? void 0 : p.$el) == null ? void 0 : v.nextElementSibling : p == null ? void 0 : p.$el
                };
            if (r.prefetch !== !1 && r.noPrefetch !== !0 && r.target !== "_blank" && !dC()) {
                const v = ge();
                let E, w = null;
                Jt(() => {
                    const h = fC();
                    tm(() => {
                        E = nl(() => {
                            var b;
                            (b = f == null ? void 0 : f.value) != null && b.tagName && (w = h.observe(f.value, async () => {
                                w == null || w(), w = null;
                                const m = typeof s.value == "string" ? s.value : i.resolve(s.value).fullPath;
                                await Promise.all([v.hooks.callHook("link:prefetch", m).catch(() => {}), !c.value && im(s.value, i).catch(() => {})]), u.value = !0
                            }))
                        })
                    })
                }), Ja(() => {
                    E && XE(E), w == null || w(), w = null
                })
            }
            return () => {
                var h, b;
                if (!c.value) {
                    const m = {
                        ref: d,
                        to: s.value,
                        activeClass: r.activeClass || e.activeClass,
                        exactActiveClass: r.exactActiveClass || e.exactActiveClass,
                        replace: r.replace,
                        ariaCurrentValue: r.ariaCurrentValue,
                        custom: r.custom
                    };
                    return r.custom || (u.value && (m.class = r.prefetchedClass || e.prefetchedClass), m.rel = r.rel), Be(Np("RouterLink"), m, a.default)
                }
                const p = typeof s.value == "object" ? ((h = i.resolve(s.value)) == null ? void 0 : h.href) ? ? null : s.value && !r.external && !l.value ? n($r(o.app.baseURL, s.value), i.resolve) : s.value || null,
                    v = r.target || null,
                    E = r.noRel ? null : lC(r.rel, e.externalRelAttribute, p ? cC : "") || null,
                    w = () => Dh(p, {
                        replace: r.replace
                    });
                return r.custom ? a.default ? a.default({
                    href: p,
                    navigate: w,
                    get route() {
                        if (!p) return;
                        const m = _o(p);
                        return {
                            path: m.pathname,
                            fullPath: m.pathname,
                            get query() {
                                return gh(m.search)
                            },
                            hash: m.hash,
                            params: {},
                            name: void 0,
                            matched: [],
                            redirectedFrom: void 0,
                            meta: {},
                            href: p
                        }
                    },
                    rel: E,
                    target: v,
                    isExternal: c.value,
                    isActive: !1,
                    isExactActive: !1
                }) : null : Be("a", {
                    ref: f,
                    href: p,
                    rel: E,
                    target: v
                }, (b = a.default) == null ? void 0 : b.call(a))
            }
        }
    })
}
const om = uC(Ew);

function fC() {
    const e = ge();
    if (e._observer) return e._observer;
    let t = null;
    const n = new Map,
        r = (i, o) => (t || (t = new IntersectionObserver(s => {
            for (const l of s) {
                const c = n.get(l.target);
                (l.isIntersecting || l.intersectionRatio > 0) && c && c()
            }
        })), n.set(i, o), t.observe(i), () => {
            n.delete(i), t.unobserve(i), n.size === 0 && (t.disconnect(), t = null)
        });
    return e._observer = {
        observe: r
    }
}

function dC() {
    const e = navigator.connection;
    return !!(e && (e.saveData || /2g/.test(e.effectiveType)))
}
const pC = Qe(e => {
        const t = JE();
        return e.vueApp.use(t), za(t), e.payload && e.payload.pinia && (t.state.value = e.payload.pinia), {
            provide: {
                pinia: t
            }
        }
    }),
    hC = $i(() => D(() => Promise.resolve().then(() => HM), void 0,
        import.meta.url).then(e => e.default)),
    mC = $i(() => D(() =>
        import ("./IconCSS.ecb2127c.js"), ["./IconCSS.ecb2127c.js", "./IconCSS.9ed40f66.css"],
        import.meta.url).then(e => e.default)),
    gC = [
        ["Icon", hC],
        ["IconCSS", mC]
    ],
    yC = Qe({
        name: "nuxt:global-components",
        setup(e) {
            for (const [t, n] of gC) e.vueApp.component(t, n), e.vueApp.component("Lazy" + t, n)
        }
    }),
    Gn = {
        default: () => D(() =>
            import ("./default.54fbe86f.js"), ["./default.54fbe86f.js", "./client-only.be8c7cca.js", "./Tooltip.06538c8d.js", "./default.a93f0aa5.css"],
            import.meta.url).then(e => e.default || e),
        error: () => D(() =>
            import ("./error.d4c5cb83.js"), [],
            import.meta.url).then(e => e.default || e)
    },
    bC = Qe({
        name: "nuxt:prefetch",
        setup(e) {
            const t = pt();
            e.hooks.hook("app:mounted", () => {
                t.beforeEach(async n => {
                    var a;
                    const r = (a = n == null ? void 0 : n.meta) == null ? void 0 : a.layout;
                    r && typeof Gn[r] == "function" && await Gn[r]()
                })
            }), e.hooks.hook("link:prefetch", n => {
                var o, s, l, c;
                if (or(n)) return;
                const r = t.resolve(n);
                if (!r) return;
                const a = (o = r == null ? void 0 : r.meta) == null ? void 0 : o.layout;
                let i = Array.isArray((s = r == null ? void 0 : r.meta) == null ? void 0 : s.middleware) ? (l = r == null ? void 0 : r.meta) == null ? void 0 : l.middleware : [(c = r == null ? void 0 : r.meta) == null ? void 0 : c.middleware];
                i = i.filter(u => typeof u == "string");
                for (const u of i) typeof pa[u] == "function" && pa[u]();
                a && typeof Gn[a] == "function" && Gn[a]()
            })
        }
    });

function Pf(e, ...t) {
    var n;
    (n = window.dataLayer) == null || n.push(arguments)
}

function vC({
    id: e,
    config: t
}) {
    window.dataLayer = window.dataLayer || [], Pf("js", new Date), Pf("config", e, t)
}
const _C = Qe(() => {
    const {
        gtag: {
            id: e,
            config: t,
            initialConsent: n,
            loadingStrategy: r
        }
    } = Nt().public;
    if (!e || (vC({
            id: e,
            config: t
        }), !n)) return;
    const a = r === "async" ? "async" : "defer";
    wo({
        script: [{
            src: `https://www.googletagmanager.com/gtag/js?id=${e}`,
            [a]: !0
        }]
    })
});

function kr(e) {
    return Nr() ? (lo(e), !0) : !1
}

function It(e) {
    return typeof e == "function" ? e() : pe(e)
}
const Ra = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const wC = e => e != null,
    EC = Object.prototype.toString,
    Xi = e => EC.call(e) === "[object Object]",
    xf = () => +Date.now(),
    _r = () => {};

function sm(e, t) {
    function n(...r) {
        return new Promise((a, i) => {
            Promise.resolve(e(() => t.apply(this, r), {
                fn: t,
                thisArg: this,
                args: r
            })).then(a).catch(i)
        })
    }
    return n
}
const lm = e => e();

function CC(e, t = {}) {
    let n, r, a = _r;
    const i = s => {
        clearTimeout(s), a(), a = _r
    };
    return s => {
        const l = It(e),
            c = It(t.maxWait);
        return n && i(n), l <= 0 || c !== void 0 && c <= 0 ? (r && (i(r), r = null), Promise.resolve(s())) : new Promise((u, f) => {
            a = t.rejectOnCancel ? f : u, c && !r && (r = setTimeout(() => {
                n && i(n), r = null, u(s())
            }, c)), n = setTimeout(() => {
                r && i(r), r = null, u(s())
            }, l)
        })
    }
}

function AC(e = lm) {
    const t = Q(!0);

    function n() {
        t.value = !1
    }

    function r() {
        t.value = !0
    }
    const a = (...i) => {
        t.value && e(...i)
    };
    return {
        isActive: Ka(t),
        pause: n,
        resume: r,
        eventFilter: a
    }
}

function LC(e) {
    let t;

    function n() {
        return t || (t = e()), t
    }
    return n.reset = async () => {
        const r = t;
        t = void 0, r && await r
    }, n
}

function cm(e) {
    return e || yt()
}

function AP(e, t = 200, n = {}) {
    return sm(CC(t, n), e)
}

function SC(e, t, n = {}) {
    const {
        eventFilter: r = lm,
        ...a
    } = n;
    return we(e, sm(r, t), a)
}

function TC(e, t, n = {}) {
    const {
        eventFilter: r,
        ...a
    } = n, {
        eventFilter: i,
        pause: o,
        resume: s,
        isActive: l
    } = AC(r);
    return {
        stop: SC(e, t, { ...a,
            eventFilter: i
        }),
        pause: o,
        resume: s,
        isActive: l
    }
}

function kC(e, t = !0, n) {
    const r = cm(n);
    r ? Jt(e, r) : t ? e() : St(e)
}

function RC(e, t) {
    const n = cm(t);
    n && Rn(e, n)
}

function um(e, t = 1e3, n = {}) {
    const {
        immediate: r = !0,
        immediateCallback: a = !1
    } = n;
    let i = null;
    const o = Q(!1);

    function s() {
        i && (clearInterval(i), i = null)
    }

    function l() {
        o.value = !1, s()
    }

    function c() {
        const u = It(t);
        u <= 0 || (o.value = !0, a && e(), s(), i = setInterval(e, u))
    }
    if (r && Ra && c(), _e(t) || typeof t == "function") {
        const u = we(t, () => {
            o.value && Ra && c()
        });
        kr(u)
    }
    return kr(l), {
        isActive: o,
        pause: l,
        resume: c
    }
}

function OC(e, t, n = {}) {
    const {
        immediate: r = !0
    } = n, a = Q(!1);
    let i = null;

    function o() {
        i && (clearTimeout(i), i = null)
    }

    function s() {
        a.value = !1, o()
    }

    function l(...c) {
        o(), a.value = !0, i = setTimeout(() => {
            a.value = !1, i = null, e(...c)
        }, It(t))
    }
    return r && (a.value = !0, Ra && l()), kr(s), {
        isPending: Ka(a),
        start: l,
        stop: s
    }
}

function ma(e) {
    var t;
    const n = It(e);
    return (t = n == null ? void 0 : n.$el) != null ? t : n
}
const Rr = Ra ? window : void 0,
    fm = Ra ? window.navigator : void 0;

function at(...e) {
    let t, n, r, a;
    if (typeof e[0] == "string" || Array.isArray(e[0]) ? ([n, r, a] = e, t = Rr) : [t, n, r, a] = e, !t) return _r;
    Array.isArray(n) || (n = [n]), Array.isArray(r) || (r = [r]);
    const i = [],
        o = () => {
            i.forEach(u => u()), i.length = 0
        },
        s = (u, f, d, p) => (u.addEventListener(f, d, p), () => u.removeEventListener(f, d, p)),
        l = we(() => [ma(t), It(a)], ([u, f]) => {
            if (o(), !u) return;
            const d = Xi(f) ? { ...f
            } : f;
            i.push(...n.flatMap(p => r.map(v => s(u, p, v, d))))
        }, {
            immediate: !0,
            flush: "post"
        }),
        c = () => {
            l(), o()
        };
    return kr(c), c
}

function MC() {
    const e = Q(!1);
    return yt() && Jt(() => {
        e.value = !0
    }), e
}

function Sc(e) {
    const t = MC();
    return W(() => (t.value, !!e()))
}

function dm(e, t = {}) {
    const {
        immediate: n = !0,
        fpsLimit: r = void 0,
        window: a = Rr
    } = t, i = Q(!1), o = r ? 1e3 / r : null;
    let s = 0,
        l = null;

    function c(d) {
        if (!i.value || !a) return;
        const p = d - (s || d);
        if (o && p < o) {
            l = a.requestAnimationFrame(c);
            return
        }
        e({
            delta: p,
            timestamp: d
        }), s = d, l = a.requestAnimationFrame(c)
    }

    function u() {
        !i.value && a && (i.value = !0, l = a.requestAnimationFrame(c))
    }

    function f() {
        i.value = !1, l != null && a && (a.cancelAnimationFrame(l), l = null)
    }
    return n && u(), kr(f), {
        isActive: Ka(i),
        pause: f,
        resume: u
    }
}

function If(e, t = {}) {
    const {
        controls: n = !1,
        navigator: r = fm
    } = t, a = Sc(() => r && "permissions" in r);
    let i;
    const o = typeof e == "string" ? {
            name: e
        } : e,
        s = Q(),
        l = () => {
            i && (s.value = i.state)
        },
        c = LC(async () => {
            if (a.value) {
                if (!i) try {
                    i = await r.permissions.query(o), at(i, "change", l), l()
                } catch {
                    s.value = "prompt"
                }
                return i
            }
        });
    return c(), n ? {
        state: s,
        isSupported: a,
        query: c
    } : s
}

function LP(e = {}) {
    const {
        navigator: t = fm,
        read: n = !1,
        source: r,
        copiedDuring: a = 1500,
        legacy: i = !1
    } = e, o = Sc(() => t && "clipboard" in t), s = If("clipboard-read"), l = If("clipboard-write"), c = W(() => o.value || i), u = Q(""), f = Q(!1), d = OC(() => f.value = !1, a);

    function p() {
        o.value && s.value !== "denied" ? t.clipboard.readText().then(h => {
            u.value = h
        }) : u.value = w()
    }
    c.value && n && at(["copy", "cut"], p);
    async function v(h = It(r)) {
        c.value && h != null && (o.value && l.value !== "denied" ? await t.clipboard.writeText(h) : E(h), u.value = h, f.value = !0, d.start())
    }

    function E(h) {
        const b = document.createElement("textarea");
        b.value = h ? ? "", b.style.position = "absolute", b.style.opacity = "0", document.body.appendChild(b), b.select(), document.execCommand("copy"), b.remove()
    }

    function w() {
        var h, b, m;
        return (m = (b = (h = document == null ? void 0 : document.getSelection) == null ? void 0 : h.call(document)) == null ? void 0 : b.toString()) != null ? m : ""
    }
    return {
        isSupported: c,
        text: u,
        copied: f,
        copy: v
    }
}
const gi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    yi = "__vueuse_ssr_handlers__",
    PC = xC();

function xC() {
    return yi in gi || (gi[yi] = gi[yi] || {}), gi[yi]
}

function IC(e, t) {
    return PC[e] || t
}

function DC(e) {
    return e == null ? "any" : e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof Date ? "date" : typeof e == "boolean" ? "boolean" : typeof e == "string" ? "string" : typeof e == "object" ? "object" : Number.isNaN(e) ? "any" : "number"
}
const NC = {
        boolean: {
            read: e => e === "true",
            write: e => String(e)
        },
        object: {
            read: e => JSON.parse(e),
            write: e => JSON.stringify(e)
        },
        number: {
            read: e => Number.parseFloat(e),
            write: e => String(e)
        },
        any: {
            read: e => e,
            write: e => String(e)
        },
        string: {
            read: e => e,
            write: e => String(e)
        },
        map: {
            read: e => new Map(JSON.parse(e)),
            write: e => JSON.stringify(Array.from(e.entries()))
        },
        set: {
            read: e => new Set(JSON.parse(e)),
            write: e => JSON.stringify(Array.from(e))
        },
        date: {
            read: e => new Date(e),
            write: e => e.toISOString()
        }
    },
    Df = "vueuse-storage";

function aa(e, t, n, r = {}) {
    var a;
    const {
        flush: i = "pre",
        deep: o = !0,
        listenToStorageChanges: s = !0,
        writeDefaults: l = !0,
        mergeDefaults: c = !1,
        shallow: u,
        window: f = Rr,
        eventFilter: d,
        onError: p = O => {
            console.error(O)
        },
        initOnMounted: v
    } = r, E = (u ? Er : Q)(typeof t == "function" ? t() : t);
    if (!n) try {
        n = IC("getDefaultStorage", () => {
            var O;
            return (O = Rr) == null ? void 0 : O.localStorage
        })()
    } catch (O) {
        p(O)
    }
    if (!n) return E;
    const w = It(t),
        h = DC(w),
        b = (a = r.serializer) != null ? a : NC[h],
        {
            pause: m,
            resume: y
        } = TC(E, () => C(E.value), {
            flush: i,
            deep: o,
            eventFilter: d
        });
    return f && s && kC(() => {
        at(f, "storage", R), at(f, Df, A), v && R()
    }), v || R(), E;

    function C(O) {
        try {
            if (O == null) n.removeItem(e);
            else {
                const N = b.write(O),
                    x = n.getItem(e);
                x !== N && (n.setItem(e, N), f && f.dispatchEvent(new CustomEvent(Df, {
                    detail: {
                        key: e,
                        oldValue: x,
                        newValue: N,
                        storageArea: n
                    }
                })))
            }
        } catch (N) {
            p(N)
        }
    }

    function S(O) {
        const N = O ? O.newValue : n.getItem(e);
        if (N == null) return l && w != null && n.setItem(e, b.write(w)), w;
        if (!O && c) {
            const x = b.read(N);
            return typeof c == "function" ? c(x, w) : h === "object" && !Array.isArray(x) ? { ...w,
                ...x
            } : x
        } else return typeof N != "string" ? N : b.read(N)
    }

    function A(O) {
        R(O.detail)
    }

    function R(O) {
        if (!(O && O.storageArea !== n)) {
            if (O && O.key == null) {
                E.value = w;
                return
            }
            if (!(O && O.key !== e)) {
                m();
                try {
                    (O == null ? void 0 : O.newValue) !== b.write(E.value) && (E.value = S(O))
                } catch (N) {
                    p(N)
                } finally {
                    O ? St(y) : y()
                }
            }
        }
    }
}

function FC(e, t, n = {}) {
    const {
        root: r,
        rootMargin: a = "0px",
        threshold: i = .1,
        window: o = Rr,
        immediate: s = !0
    } = n, l = Sc(() => o && "IntersectionObserver" in o), c = W(() => {
        const v = It(e);
        return (Array.isArray(v) ? v : [v]).map(ma).filter(wC)
    });
    let u = _r;
    const f = Q(s),
        d = l.value ? we(() => [c.value, ma(r), f.value], ([v, E]) => {
            if (u(), !f.value || !v.length) return;
            const w = new IntersectionObserver(t, {
                root: ma(E),
                rootMargin: a,
                threshold: i
            });
            v.forEach(h => h && w.observe(h)), u = () => {
                w.disconnect(), u = _r
            }
        }, {
            immediate: s,
            flush: "post"
        }) : _r,
        p = () => {
            u(), d(), f.value = !1
        };
    return kr(p), {
        isSupported: l,
        isActive: f,
        pause() {
            u(), f.value = !1
        },
        resume() {
            f.value = !0
        },
        stop: p
    }
}
const qr = new Map;

function SP(e) {
    const t = Nr();

    function n(s) {
        var l;
        const c = qr.get(e) || new Set;
        c.add(s), qr.set(e, c);
        const u = () => a(s);
        return (l = t == null ? void 0 : t.cleanups) == null || l.push(u), u
    }

    function r(s) {
        function l(...c) {
            a(l), s(...c)
        }
        return n(l)
    }

    function a(s) {
        const l = qr.get(e);
        l && (l.delete(s), l.size || i())
    }

    function i() {
        qr.delete(e)
    }

    function o(s, l) {
        var c;
        (c = qr.get(e)) == null || c.forEach(u => u(s, l))
    }
    return {
        on: n,
        once: r,
        off: a,
        emit: o,
        reset: i
    }
}

function BC(e, t, n = {}) {
    const {
        window: r = Rr
    } = n;
    return aa(e, t, r == null ? void 0 : r.localStorage, n)
}

function jC(e = {}) {
    const {
        controls: t = !1,
        interval: n = "requestAnimationFrame"
    } = e, r = Q(new Date), a = () => r.value = new Date, i = n === "requestAnimationFrame" ? dm(a, {
        immediate: !0
    }) : um(a, n, {
        immediate: !0
    });
    return t ? {
        now: r,
        ...i
    } : r
}
const $C = [{
        max: 6e4,
        value: 1e3,
        name: "second"
    }, {
        max: 276e4,
        value: 6e4,
        name: "minute"
    }, {
        max: 72e6,
        value: 36e5,
        name: "hour"
    }, {
        max: 5184e5,
        value: 864e5,
        name: "day"
    }, {
        max: 24192e5,
        value: 6048e5,
        name: "week"
    }, {
        max: 28512e6,
        value: 2592e6,
        name: "month"
    }, {
        max: Number.POSITIVE_INFINITY,
        value: 31536e6,
        name: "year"
    }],
    VC = {
        justNow: "just now",
        past: e => e.match(/\d/) ? `${e} ago` : e,
        future: e => e.match(/\d/) ? `in ${e}` : e,
        month: (e, t) => e === 1 ? t ? "last month" : "next month" : `${e} month${e>1?"s":""}`,
        year: (e, t) => e === 1 ? t ? "last year" : "next year" : `${e} year${e>1?"s":""}`,
        day: (e, t) => e === 1 ? t ? "yesterday" : "tomorrow" : `${e} day${e>1?"s":""}`,
        week: (e, t) => e === 1 ? t ? "last week" : "next week" : `${e} week${e>1?"s":""}`,
        hour: e => `${e} hour${e>1?"s":""}`,
        minute: e => `${e} minute${e>1?"s":""}`,
        second: e => `${e} second${e>1?"s":""}`,
        invalid: ""
    };

function HC(e) {
    return e.toISOString().slice(0, 10)
}

function TP(e, t = {}) {
    const {
        controls: n = !1,
        updateInterval: r = 3e4
    } = t, {
        now: a,
        ...i
    } = jC({
        interval: r,
        controls: !0
    }), o = W(() => KC(new Date(It(e)), t, It(a)));
    return n ? {
        timeAgo: o,
        ...i
    } : o
}

function KC(e, t = {}, n = Date.now()) {
    var r;
    const {
        max: a,
        messages: i = VC,
        fullDateFormatter: o = HC,
        units: s = $C,
        showSecond: l = !1,
        rounding: c = "round"
    } = t, u = typeof c == "number" ? w => +w.toFixed(c) : Math[c], f = +n - +e, d = Math.abs(f);

    function p(w, h) {
        return u(Math.abs(w) / h.value)
    }

    function v(w, h) {
        const b = p(w, h),
            m = w > 0,
            y = E(h.name, b, m);
        return E(m ? "past" : "future", y, m)
    }

    function E(w, h, b) {
        const m = i[w];
        return typeof m == "function" ? m(h, b) : m.replace("{0}", h.toString())
    }
    if (d < 6e4 && !l) return i.justNow;
    if (typeof a == "number" && d > a) return o(new Date(e));
    if (typeof a == "string") {
        const w = (r = s.find(h => h.name === a)) == null ? void 0 : r.max;
        if (w && d > w) return o(new Date(e))
    }
    for (const [w, h] of s.entries()) {
        if (p(f, h) <= 0 && s[w - 1]) return v(f, s[w - 1]);
        if (d < h.max) return v(f, h)
    }
    return i.invalid
}

function UC(e = {}) {
    const {
        controls: t = !1,
        offset: n = 0,
        immediate: r = !0,
        interval: a = "requestAnimationFrame",
        callback: i
    } = e, o = Q(xf() + n), s = () => o.value = xf() + n, l = i ? () => {
        s(), i(o.value)
    } : s, c = a === "requestAnimationFrame" ? dm(l, {
        immediate: r
    }) : um(l, a, {
        immediate: r
    });
    return t ? {
        timestamp: o,
        ...c
    } : o
}
const pm = 1 / 60 * 1e3,
    JC = typeof performance < "u" ? () => performance.now() : () => Date.now(),
    hm = typeof window < "u" ? e => window.requestAnimationFrame(e) : e => setTimeout(() => e(JC()), pm);

function GC(e) {
    let t = [],
        n = [],
        r = 0,
        a = !1,
        i = !1;
    const o = new WeakSet,
        s = {
            schedule: (l, c = !1, u = !1) => {
                const f = u && a,
                    d = f ? t : n;
                return c && o.add(l), d.indexOf(l) === -1 && (d.push(l), f && a && (r = t.length)), l
            },
            cancel: l => {
                const c = n.indexOf(l);
                c !== -1 && n.splice(c, 1), o.delete(l)
            },
            process: l => {
                if (a) {
                    i = !0;
                    return
                }
                if (a = !0, [t, n] = [n, t], n.length = 0, r = t.length, r)
                    for (let c = 0; c < r; c++) {
                        const u = t[c];
                        u(l), o.has(u) && (s.schedule(u), e())
                    }
                a = !1, i && (i = !1, s.process(l))
            }
        };
    return s
}
const WC = 40;
let rl = !0,
    Oa = !1,
    al = !1;
const wr = {
        delta: 0,
        timestamp: 0
    },
    Ya = ["read", "update", "preRender", "render", "postRender"],
    ko = Ya.reduce((e, t) => (e[t] = GC(() => Oa = !0), e), {}),
    il = Ya.reduce((e, t) => {
        const n = ko[t];
        return e[t] = (r, a = !1, i = !1) => (Oa || YC(), n.schedule(r, a, i)), e
    }, {}),
    zC = Ya.reduce((e, t) => (e[t] = ko[t].cancel, e), {});
Ya.reduce((e, t) => (e[t] = () => ko[t].process(wr), e), {});
const qC = e => ko[e].process(wr),
    mm = e => {
        Oa = !1, wr.delta = rl ? pm : Math.max(Math.min(e - wr.timestamp, WC), 1), wr.timestamp = e, al = !0, Ya.forEach(qC), al = !1, Oa && (rl = !1, hm(mm))
    },
    YC = () => {
        Oa = !0, rl = !0, al || hm(mm)
    },
    gm = () => wr;

function ym(e, t) {
    var n = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
        for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++) t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
    return n
}
var XC = function() {},
    Nf = function() {};
const ol = (e, t, n) => Math.min(Math.max(n, e), t),
    ls = .001,
    QC = .01,
    Ff = 10,
    ZC = .05,
    eA = 1;

function tA({
    duration: e = 800,
    bounce: t = .25,
    velocity: n = 0,
    mass: r = 1
}) {
    let a, i;
    XC(e <= Ff * 1e3);
    let o = 1 - t;
    o = ol(ZC, eA, o), e = ol(QC, Ff, e / 1e3), o < 1 ? (a = c => {
        const u = c * o,
            f = u * e,
            d = u - n,
            p = sl(c, o),
            v = Math.exp(-f);
        return ls - d / p * v
    }, i = c => {
        const f = c * o * e,
            d = f * n + n,
            p = Math.pow(o, 2) * Math.pow(c, 2) * e,
            v = Math.exp(-f),
            E = sl(Math.pow(c, 2), o);
        return (-a(c) + ls > 0 ? -1 : 1) * ((d - p) * v) / E
    }) : (a = c => {
        const u = Math.exp(-c * e),
            f = (c - n) * e + 1;
        return -ls + u * f
    }, i = c => {
        const u = Math.exp(-c * e),
            f = (n - c) * (e * e);
        return u * f
    });
    const s = 5 / e,
        l = rA(a, i, s);
    if (e = e * 1e3, isNaN(l)) return {
        stiffness: 100,
        damping: 10,
        duration: e
    }; {
        const c = Math.pow(l, 2) * r;
        return {
            stiffness: c,
            damping: o * 2 * Math.sqrt(r * c),
            duration: e
        }
    }
}
const nA = 12;

function rA(e, t, n) {
    let r = n;
    for (let a = 1; a < nA; a++) r = r - e(r) / t(r);
    return r
}

function sl(e, t) {
    return e * Math.sqrt(1 - t * t)
}
const aA = ["duration", "bounce"],
    iA = ["stiffness", "damping", "mass"];

function Bf(e, t) {
    return t.some(n => e[n] !== void 0)
}

function oA(e) {
    let t = Object.assign({
        velocity: 0,
        stiffness: 100,
        damping: 10,
        mass: 1,
        isResolvedFromDuration: !1
    }, e);
    if (!Bf(e, iA) && Bf(e, aA)) {
        const n = tA(e);
        t = Object.assign(Object.assign(Object.assign({}, t), n), {
            velocity: 0,
            mass: 1
        }), t.isResolvedFromDuration = !0
    }
    return t
}

function Tc(e) {
    var {
        from: t = 0,
        to: n = 1,
        restSpeed: r = 2,
        restDelta: a
    } = e, i = ym(e, ["from", "to", "restSpeed", "restDelta"]);
    const o = {
        done: !1,
        value: t
    };
    let {
        stiffness: s,
        damping: l,
        mass: c,
        velocity: u,
        duration: f,
        isResolvedFromDuration: d
    } = oA(i), p = jf, v = jf;

    function E() {
        const w = u ? -(u / 1e3) : 0,
            h = n - t,
            b = l / (2 * Math.sqrt(s * c)),
            m = Math.sqrt(s / c) / 1e3;
        if (a === void 0 && (a = Math.min(Math.abs(n - t) / 100, .4)), b < 1) {
            const y = sl(m, b);
            p = C => {
                const S = Math.exp(-b * m * C);
                return n - S * ((w + b * m * h) / y * Math.sin(y * C) + h * Math.cos(y * C))
            }, v = C => {
                const S = Math.exp(-b * m * C);
                return b * m * S * (Math.sin(y * C) * (w + b * m * h) / y + h * Math.cos(y * C)) - S * (Math.cos(y * C) * (w + b * m * h) - y * h * Math.sin(y * C))
            }
        } else if (b === 1) p = y => n - Math.exp(-m * y) * (h + (w + m * h) * y);
        else {
            const y = m * Math.sqrt(b * b - 1);
            p = C => {
                const S = Math.exp(-b * m * C),
                    A = Math.min(y * C, 300);
                return n - S * ((w + b * m * h) * Math.sinh(A) + y * h * Math.cosh(A)) / y
            }
        }
    }
    return E(), {
        next: w => {
            const h = p(w);
            if (d) o.done = w >= f;
            else {
                const b = v(w) * 1e3,
                    m = Math.abs(b) <= r,
                    y = Math.abs(n - h) <= a;
                o.done = m && y
            }
            return o.value = o.done ? n : h, o
        },
        flipTarget: () => {
            u = -u, [t, n] = [n, t], E()
        }
    }
}
Tc.needsInterpolation = (e, t) => typeof e == "string" || typeof t == "string";
const jf = e => 0,
    bm = (e, t, n) => {
        const r = t - e;
        return r === 0 ? 1 : (n - e) / r
    },
    kc = (e, t, n) => -n * e + n * t + e,
    vm = (e, t) => n => Math.max(Math.min(n, t), e),
    ga = e => e % 1 ? Number(e.toFixed(5)) : e,
    Ma = /(-)?([\d]*\.?[\d])+/g,
    ll = /(#[0-9a-f]{6}|#[0-9a-f]{3}|#(?:[0-9a-f]{2}){2,4}|(rgb|hsl)a?\((-?[\d\.]+%?[,\s]+){2}(-?[\d\.]+%?)\s*[\,\/]?\s*[\d\.]*%?\))/gi,
    sA = /^(#[0-9a-f]{3}|#(?:[0-9a-f]{2}){2,4}|(rgb|hsl)a?\((-?[\d\.]+%?[,\s]+){2}(-?[\d\.]+%?)\s*[\,\/]?\s*[\d\.]*%?\))$/i;

function Xa(e) {
    return typeof e == "string"
}
const Qa = {
        test: e => typeof e == "number",
        parse: parseFloat,
        transform: e => e
    },
    ya = Object.assign(Object.assign({}, Qa), {
        transform: vm(0, 1)
    }),
    bi = Object.assign(Object.assign({}, Qa), {
        default: 1
    }),
    Rc = e => ({
        test: t => Xa(t) && t.endsWith(e) && t.split(" ").length === 1,
        parse: parseFloat,
        transform: t => `${t}${e}`
    }),
    Fn = Rc("deg"),
    ba = Rc("%"),
    ce = Rc("px"),
    $f = Object.assign(Object.assign({}, ba), {
        parse: e => ba.parse(e) / 100,
        transform: e => ba.transform(e * 100)
    }),
    Oc = (e, t) => n => !!(Xa(n) && sA.test(n) && n.startsWith(e) || t && Object.prototype.hasOwnProperty.call(n, t)),
    _m = (e, t, n) => r => {
        if (!Xa(r)) return r;
        const [a, i, o, s] = r.match(Ma);
        return {
            [e]: parseFloat(a),
            [t]: parseFloat(i),
            [n]: parseFloat(o),
            alpha: s !== void 0 ? parseFloat(s) : 1
        }
    },
    Wn = {
        test: Oc("hsl", "hue"),
        parse: _m("hue", "saturation", "lightness"),
        transform: ({
            hue: e,
            saturation: t,
            lightness: n,
            alpha: r = 1
        }) => "hsla(" + Math.round(e) + ", " + ba.transform(ga(t)) + ", " + ba.transform(ga(n)) + ", " + ga(ya.transform(r)) + ")"
    },
    lA = vm(0, 255),
    cs = Object.assign(Object.assign({}, Qa), {
        transform: e => Math.round(lA(e))
    }),
    bn = {
        test: Oc("rgb", "red"),
        parse: _m("red", "green", "blue"),
        transform: ({
            red: e,
            green: t,
            blue: n,
            alpha: r = 1
        }) => "rgba(" + cs.transform(e) + ", " + cs.transform(t) + ", " + cs.transform(n) + ", " + ga(ya.transform(r)) + ")"
    };

function cA(e) {
    let t = "",
        n = "",
        r = "",
        a = "";
    return e.length > 5 ? (t = e.substr(1, 2), n = e.substr(3, 2), r = e.substr(5, 2), a = e.substr(7, 2)) : (t = e.substr(1, 1), n = e.substr(2, 1), r = e.substr(3, 1), a = e.substr(4, 1), t += t, n += n, r += r, a += a), {
        red: parseInt(t, 16),
        green: parseInt(n, 16),
        blue: parseInt(r, 16),
        alpha: a ? parseInt(a, 16) / 255 : 1
    }
}
const cl = {
        test: Oc("#"),
        parse: cA,
        transform: bn.transform
    },
    ut = {
        test: e => bn.test(e) || cl.test(e) || Wn.test(e),
        parse: e => bn.test(e) ? bn.parse(e) : Wn.test(e) ? Wn.parse(e) : cl.parse(e),
        transform: e => Xa(e) ? e : e.hasOwnProperty("red") ? bn.transform(e) : Wn.transform(e)
    },
    wm = "${c}",
    Em = "${n}";

function uA(e) {
    var t, n, r, a;
    return isNaN(e) && Xa(e) && ((n = (t = e.match(Ma)) === null || t === void 0 ? void 0 : t.length) !== null && n !== void 0 ? n : 0) + ((a = (r = e.match(ll)) === null || r === void 0 ? void 0 : r.length) !== null && a !== void 0 ? a : 0) > 0
}

function Cm(e) {
    typeof e == "number" && (e = `${e}`);
    const t = [];
    let n = 0;
    const r = e.match(ll);
    r && (n = r.length, e = e.replace(ll, wm), t.push(...r.map(ut.parse)));
    const a = e.match(Ma);
    return a && (e = e.replace(Ma, Em), t.push(...a.map(Qa.parse))), {
        values: t,
        numColors: n,
        tokenised: e
    }
}

function Am(e) {
    return Cm(e).values
}

function Lm(e) {
    const {
        values: t,
        numColors: n,
        tokenised: r
    } = Cm(e), a = t.length;
    return i => {
        let o = r;
        for (let s = 0; s < a; s++) o = o.replace(s < n ? wm : Em, s < n ? ut.transform(i[s]) : ga(i[s]));
        return o
    }
}
const fA = e => typeof e == "number" ? 0 : e;

function dA(e) {
    const t = Am(e);
    return Lm(e)(t.map(fA))
}
const Za = {
        test: uA,
        parse: Am,
        createTransformer: Lm,
        getAnimatableNone: dA
    },
    pA = new Set(["brightness", "contrast", "saturate", "opacity"]);

function hA(e) {
    let [t, n] = e.slice(0, -1).split("(");
    if (t === "drop-shadow") return e;
    const [r] = n.match(Ma) || [];
    if (!r) return e;
    const a = n.replace(r, "");
    let i = pA.has(t) ? 1 : 0;
    return r !== n && (i *= 100), t + "(" + i + a + ")"
}
const mA = /([a-z-]*)\(.*?\)/g,
    ul = Object.assign(Object.assign({}, Za), {
        getAnimatableNone: e => {
            const t = e.match(mA);
            return t ? t.map(hA).join(" ") : e
        }
    });

function us(e, t, n) {
    return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
}

function Vf({
    hue: e,
    saturation: t,
    lightness: n,
    alpha: r
}) {
    e /= 360, t /= 100, n /= 100;
    let a = 0,
        i = 0,
        o = 0;
    if (!t) a = i = o = n;
    else {
        const s = n < .5 ? n * (1 + t) : n + t - n * t,
            l = 2 * n - s;
        a = us(l, s, e + 1 / 3), i = us(l, s, e), o = us(l, s, e - 1 / 3)
    }
    return {
        red: Math.round(a * 255),
        green: Math.round(i * 255),
        blue: Math.round(o * 255),
        alpha: r
    }
}
const gA = (e, t, n) => {
        const r = e * e,
            a = t * t;
        return Math.sqrt(Math.max(0, n * (a - r) + r))
    },
    yA = [cl, bn, Wn],
    Hf = e => yA.find(t => t.test(e)),
    Sm = (e, t) => {
        let n = Hf(e),
            r = Hf(t),
            a = n.parse(e),
            i = r.parse(t);
        n === Wn && (a = Vf(a), n = bn), r === Wn && (i = Vf(i), r = bn);
        const o = Object.assign({}, a);
        return s => {
            for (const l in o) l !== "alpha" && (o[l] = gA(a[l], i[l], s));
            return o.alpha = kc(a.alpha, i.alpha, s), n.transform(o)
        }
    },
    bA = e => typeof e == "number",
    vA = (e, t) => n => t(e(n)),
    Tm = (...e) => e.reduce(vA);

function km(e, t) {
    return bA(e) ? n => kc(e, t, n) : ut.test(e) ? Sm(e, t) : Om(e, t)
}
const Rm = (e, t) => {
        const n = [...e],
            r = n.length,
            a = e.map((i, o) => km(i, t[o]));
        return i => {
            for (let o = 0; o < r; o++) n[o] = a[o](i);
            return n
        }
    },
    _A = (e, t) => {
        const n = Object.assign(Object.assign({}, e), t),
            r = {};
        for (const a in n) e[a] !== void 0 && t[a] !== void 0 && (r[a] = km(e[a], t[a]));
        return a => {
            for (const i in r) n[i] = r[i](a);
            return n
        }
    };

function Kf(e) {
    const t = Za.parse(e),
        n = t.length;
    let r = 0,
        a = 0,
        i = 0;
    for (let o = 0; o < n; o++) r || typeof t[o] == "number" ? r++ : t[o].hue !== void 0 ? i++ : a++;
    return {
        parsed: t,
        numNumbers: r,
        numRGB: a,
        numHSL: i
    }
}
const Om = (e, t) => {
        const n = Za.createTransformer(t),
            r = Kf(e),
            a = Kf(t);
        return r.numHSL === a.numHSL && r.numRGB === a.numRGB && r.numNumbers >= a.numNumbers ? Tm(Rm(r.parsed, a.parsed), n) : o => `${o>0?t:e}`
    },
    wA = (e, t) => n => kc(e, t, n);

function EA(e) {
    if (typeof e == "number") return wA;
    if (typeof e == "string") return ut.test(e) ? Sm : Om;
    if (Array.isArray(e)) return Rm;
    if (typeof e == "object") return _A
}

function CA(e, t, n) {
    const r = [],
        a = n || EA(e[0]),
        i = e.length - 1;
    for (let o = 0; o < i; o++) {
        let s = a(e[o], e[o + 1]);
        if (t) {
            const l = Array.isArray(t) ? t[o] : t;
            s = Tm(l, s)
        }
        r.push(s)
    }
    return r
}

function AA([e, t], [n]) {
    return r => n(bm(e, t, r))
}

function LA(e, t) {
    const n = e.length,
        r = n - 1;
    return a => {
        let i = 0,
            o = !1;
        if (a <= e[0] ? o = !0 : a >= e[r] && (i = r - 1, o = !0), !o) {
            let l = 1;
            for (; l < n && !(e[l] > a || l === r); l++);
            i = l - 1
        }
        const s = bm(e[i], e[i + 1], a);
        return t[i](s)
    }
}

function Mm(e, t, {
    clamp: n = !0,
    ease: r,
    mixer: a
} = {}) {
    const i = e.length;
    Nf(i === t.length), Nf(!r || !Array.isArray(r) || r.length === i - 1), e[0] > e[i - 1] && (e = [].concat(e), t = [].concat(t), e.reverse(), t.reverse());
    const o = CA(t, r, a),
        s = i === 2 ? AA(e, o) : LA(e, o);
    return n ? l => s(ol(e[0], e[i - 1], l)) : s
}
const Ro = e => t => 1 - e(1 - t),
    Mc = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
    SA = e => t => Math.pow(t, e),
    Pm = e => t => t * t * ((e + 1) * t - e),
    TA = e => {
        const t = Pm(e);
        return n => (n *= 2) < 1 ? .5 * t(n) : .5 * (2 - Math.pow(2, -10 * (n - 1)))
    },
    xm = 1.525,
    kA = 4 / 11,
    RA = 8 / 11,
    OA = 9 / 10,
    Im = e => e,
    Pc = SA(2),
    MA = Ro(Pc),
    Dm = Mc(Pc),
    Nm = e => 1 - Math.sin(Math.acos(e)),
    Fm = Ro(Nm),
    PA = Mc(Fm),
    xc = Pm(xm),
    xA = Ro(xc),
    IA = Mc(xc),
    DA = TA(xm),
    NA = 4356 / 361,
    FA = 35442 / 1805,
    BA = 16061 / 1805,
    Qi = e => {
        if (e === 1 || e === 0) return e;
        const t = e * e;
        return e < kA ? 7.5625 * t : e < RA ? 9.075 * t - 9.9 * e + 3.4 : e < OA ? NA * t - FA * e + BA : 10.8 * e * e - 20.52 * e + 10.72
    },
    jA = Ro(Qi),
    $A = e => e < .5 ? .5 * (1 - Qi(1 - e * 2)) : .5 * Qi(e * 2 - 1) + .5;

function VA(e, t) {
    return e.map(() => t || Dm).splice(0, e.length - 1)
}

function HA(e) {
    const t = e.length;
    return e.map((n, r) => r !== 0 ? r / (t - 1) : 0)
}

function KA(e, t) {
    return e.map(n => n * t)
}

function Ri({
    from: e = 0,
    to: t = 1,
    ease: n,
    offset: r,
    duration: a = 300
}) {
    const i = {
            done: !1,
            value: e
        },
        o = Array.isArray(t) ? t : [e, t],
        s = KA(r && r.length === o.length ? r : HA(o), a);

    function l() {
        return Mm(s, o, {
            ease: Array.isArray(n) ? n : VA(o, n)
        })
    }
    let c = l();
    return {
        next: u => (i.value = c(u), i.done = u >= a, i),
        flipTarget: () => {
            o.reverse(), c = l()
        }
    }
}

function UA({
    velocity: e = 0,
    from: t = 0,
    power: n = .8,
    timeConstant: r = 350,
    restDelta: a = .5,
    modifyTarget: i
}) {
    const o = {
        done: !1,
        value: t
    };
    let s = n * e;
    const l = t + s,
        c = i === void 0 ? l : i(l);
    return c !== l && (s = c - t), {
        next: u => {
            const f = -s * Math.exp(-u / r);
            return o.done = !(f > a || f < -a), o.value = o.done ? c : c + f, o
        },
        flipTarget: () => {}
    }
}
const Uf = {
    keyframes: Ri,
    spring: Tc,
    decay: UA
};

function JA(e) {
    if (Array.isArray(e.to)) return Ri;
    if (Uf[e.type]) return Uf[e.type];
    const t = new Set(Object.keys(e));
    return t.has("ease") || t.has("duration") && !t.has("dampingRatio") ? Ri : t.has("dampingRatio") || t.has("stiffness") || t.has("mass") || t.has("damping") || t.has("restSpeed") || t.has("restDelta") ? Tc : Ri
}

function Bm(e, t, n = 0) {
    return e - t - n
}

function GA(e, t, n = 0, r = !0) {
    return r ? Bm(t + -e, t, n) : t - (e - t) + n
}

function WA(e, t, n, r) {
    return r ? e >= t + n : e <= -n
}
const zA = e => {
    const t = ({
        delta: n
    }) => e(n);
    return {
        start: () => il.update(t, !0),
        stop: () => zC.update(t)
    }
};

function jm(e) {
    var t, n, {
            from: r,
            autoplay: a = !0,
            driver: i = zA,
            elapsed: o = 0,
            repeat: s = 0,
            repeatType: l = "loop",
            repeatDelay: c = 0,
            onPlay: u,
            onStop: f,
            onComplete: d,
            onRepeat: p,
            onUpdate: v
        } = e,
        E = ym(e, ["from", "autoplay", "driver", "elapsed", "repeat", "repeatType", "repeatDelay", "onPlay", "onStop", "onComplete", "onRepeat", "onUpdate"]);
    let {
        to: w
    } = E, h, b = 0, m = E.duration, y, C = !1, S = !0, A;
    const R = JA(E);
    !((n = (t = R).needsInterpolation) === null || n === void 0) && n.call(t, r, w) && (A = Mm([0, 100], [r, w], {
        clamp: !1
    }), r = 0, w = 100);
    const O = R(Object.assign(Object.assign({}, E), {
        from: r,
        to: w
    }));

    function N() {
        b++, l === "reverse" ? (S = b % 2 === 0, o = GA(o, m, c, S)) : (o = Bm(o, m, c), l === "mirror" && O.flipTarget()), C = !1, p && p()
    }

    function x() {
        h.stop(), d && d()
    }

    function M(ne) {
        if (S || (ne = -ne), o += ne, !C) {
            const te = O.next(Math.max(0, o));
            y = te.value, A && (y = A(y)), C = S ? te.done : o <= 0
        }
        v == null || v(y), C && (b === 0 && (m ? ? (m = o)), b < s ? WA(o, m, c, S) && N() : x())
    }

    function K() {
        u == null || u(), h = i(M), h.start()
    }
    return a && K(), {
        stop: () => {
            f == null || f(), h.stop()
        }
    }
}

function $m(e, t) {
    return t ? e * (1e3 / t) : 0
}

function qA({
    from: e = 0,
    velocity: t = 0,
    min: n,
    max: r,
    power: a = .8,
    timeConstant: i = 750,
    bounceStiffness: o = 500,
    bounceDamping: s = 10,
    restDelta: l = 1,
    modifyTarget: c,
    driver: u,
    onUpdate: f,
    onComplete: d,
    onStop: p
}) {
    let v;

    function E(m) {
        return n !== void 0 && m < n || r !== void 0 && m > r
    }

    function w(m) {
        return n === void 0 ? r : r === void 0 || Math.abs(n - m) < Math.abs(r - m) ? n : r
    }

    function h(m) {
        v == null || v.stop(), v = jm(Object.assign(Object.assign({}, m), {
            driver: u,
            onUpdate: y => {
                var C;
                f == null || f(y), (C = m.onUpdate) === null || C === void 0 || C.call(m, y)
            },
            onComplete: d,
            onStop: p
        }))
    }

    function b(m) {
        h(Object.assign({
            type: "spring",
            stiffness: o,
            damping: s,
            restDelta: l
        }, m))
    }
    if (E(e)) b({
        from: e,
        velocity: t,
        to: w(e)
    });
    else {
        let m = a * t + e;
        typeof c < "u" && (m = c(m));
        const y = w(m),
            C = y === n ? -1 : 1;
        let S, A;
        const R = O => {
            S = A, A = O, t = $m(O - S, gm().delta), (C === 1 && O > y || C === -1 && O < y) && b({
                from: O,
                to: y,
                velocity: t
            })
        };
        h({
            type: "decay",
            from: e,
            velocity: t,
            timeConstant: i,
            power: a,
            restDelta: l,
            modifyTarget: c,
            onUpdate: E(m) ? R : void 0
        })
    }
    return {
        stop: () => v == null ? void 0 : v.stop()
    }
}
const Vm = (e, t) => 1 - 3 * t + 3 * e,
    Hm = (e, t) => 3 * t - 6 * e,
    Km = e => 3 * e,
    Zi = (e, t, n) => ((Vm(t, n) * e + Hm(t, n)) * e + Km(t)) * e,
    Um = (e, t, n) => 3 * Vm(t, n) * e * e + 2 * Hm(t, n) * e + Km(t),
    YA = 1e-7,
    XA = 10;

function QA(e, t, n, r, a) {
    let i, o, s = 0;
    do o = t + (n - t) / 2, i = Zi(o, r, a) - e, i > 0 ? n = o : t = o; while (Math.abs(i) > YA && ++s < XA);
    return o
}
const ZA = 8,
    eL = .001;

function tL(e, t, n, r) {
    for (let a = 0; a < ZA; ++a) {
        const i = Um(t, n, r);
        if (i === 0) return t;
        const o = Zi(t, n, r) - e;
        t -= o / i
    }
    return t
}
const Oi = 11,
    vi = 1 / (Oi - 1);

function nL(e, t, n, r) {
    if (e === t && n === r) return Im;
    const a = new Float32Array(Oi);
    for (let o = 0; o < Oi; ++o) a[o] = Zi(o * vi, e, n);

    function i(o) {
        let s = 0,
            l = 1;
        const c = Oi - 1;
        for (; l !== c && a[l] <= o; ++l) s += vi;
        --l;
        const u = (o - a[l]) / (a[l + 1] - a[l]),
            f = s + u * vi,
            d = Um(f, e, n);
        return d >= eL ? tL(o, f, e, n) : d === 0 ? f : QA(o, s, s + vi, e, n)
    }
    return o => o === 0 || o === 1 ? o : Zi(i(o), t, r)
}
const fs = {};
class rL {
    constructor() {
        this.subscriptions = new Set
    }
    add(t) {
        return this.subscriptions.add(t), () => this.subscriptions.delete(t)
    }
    notify(t, n, r) {
        if (this.subscriptions.size)
            for (const a of this.subscriptions) a(t, n, r)
    }
    clear() {
        this.subscriptions.clear()
    }
}

function Jf(e) {
    return !isNaN(parseFloat(e))
}
class aL {
    constructor(t) {
        this.timeDelta = 0, this.lastUpdated = 0, this.updateSubscribers = new rL, this.canTrackVelocity = !1, this.updateAndNotify = n => {
            this.prev = this.current, this.current = n;
            const {
                delta: r,
                timestamp: a
            } = gm();
            this.lastUpdated !== a && (this.timeDelta = r, this.lastUpdated = a), il.postRender(this.scheduleVelocityCheck), this.updateSubscribers.notify(this.current)
        }, this.scheduleVelocityCheck = () => il.postRender(this.velocityCheck), this.velocityCheck = ({
            timestamp: n
        }) => {
            this.canTrackVelocity || (this.canTrackVelocity = Jf(this.current)), n !== this.lastUpdated && (this.prev = this.current)
        }, this.prev = this.current = t, this.canTrackVelocity = Jf(this.current)
    }
    onChange(t) {
        return this.updateSubscribers.add(t)
    }
    clearListeners() {
        this.updateSubscribers.clear()
    }
    set(t) {
        this.updateAndNotify(t)
    }
    get() {
        return this.current
    }
    getPrevious() {
        return this.prev
    }
    getVelocity() {
        return this.canTrackVelocity ? $m(parseFloat(this.current) - parseFloat(this.prev), this.timeDelta) : 0
    }
    start(t) {
        return this.stop(), new Promise(n => {
            const {
                stop: r
            } = t(n);
            this.stopAnimation = r
        }).then(() => this.clearAnimation())
    }
    stop() {
        this.stopAnimation && this.stopAnimation(), this.clearAnimation()
    }
    isAnimating() {
        return !!this.stopAnimation
    }
    clearAnimation() {
        this.stopAnimation = null
    }
    destroy() {
        this.updateSubscribers.clear(), this.stop()
    }
}

function iL(e) {
    return new aL(e)
}
const {
    isArray: oL
} = Array;

function sL() {
    const e = Q({}),
        t = r => {
            const a = i => {
                e.value[i] && (e.value[i].stop(), e.value[i].destroy(), delete e.value[i])
            };
            r ? oL(r) ? r.forEach(a) : a(r) : Object.keys(e.value).forEach(a)
        },
        n = (r, a, i) => {
            if (e.value[r]) return e.value[r];
            const o = iL(a);
            return o.onChange(s => i[r] = s), e.value[r] = o, o
        };
    return RC(t), {
        motionValues: e,
        get: n,
        stop: t
    }
}

function lL(e) {
    return Array.isArray(e)
}

function Bn() {
    return {
        type: "spring",
        stiffness: 500,
        damping: 25,
        restDelta: .5,
        restSpeed: 10
    }
}

function ds(e) {
    return {
        type: "spring",
        stiffness: 550,
        damping: e === 0 ? 2 * Math.sqrt(550) : 30,
        restDelta: .01,
        restSpeed: 10
    }
}

function cL(e) {
    return {
        type: "spring",
        stiffness: 550,
        damping: e === 0 ? 100 : 30,
        restDelta: .01,
        restSpeed: 10
    }
}

function ps() {
    return {
        type: "keyframes",
        ease: "linear",
        duration: 300
    }
}

function uL(e) {
    return {
        type: "keyframes",
        duration: 800,
        values: e
    }
}
const Gf = {
    default: cL,
    x: Bn,
    y: Bn,
    z: Bn,
    rotate: Bn,
    rotateX: Bn,
    rotateY: Bn,
    rotateZ: Bn,
    scaleX: ds,
    scaleY: ds,
    scale: ds,
    backgroundColor: ps,
    color: ps,
    opacity: ps
};

function Jm(e, t) {
    let n;
    return lL(t) ? n = uL : n = Gf[e] || Gf.default, {
        to: t,
        ...n(t)
    }
}
const Wf = { ...Qa,
        transform: Math.round
    },
    Gm = {
        color: ut,
        backgroundColor: ut,
        outlineColor: ut,
        fill: ut,
        stroke: ut,
        borderColor: ut,
        borderTopColor: ut,
        borderRightColor: ut,
        borderBottomColor: ut,
        borderLeftColor: ut,
        borderWidth: ce,
        borderTopWidth: ce,
        borderRightWidth: ce,
        borderBottomWidth: ce,
        borderLeftWidth: ce,
        borderRadius: ce,
        radius: ce,
        borderTopLeftRadius: ce,
        borderTopRightRadius: ce,
        borderBottomRightRadius: ce,
        borderBottomLeftRadius: ce,
        width: ce,
        maxWidth: ce,
        height: ce,
        maxHeight: ce,
        size: ce,
        top: ce,
        right: ce,
        bottom: ce,
        left: ce,
        padding: ce,
        paddingTop: ce,
        paddingRight: ce,
        paddingBottom: ce,
        paddingLeft: ce,
        margin: ce,
        marginTop: ce,
        marginRight: ce,
        marginBottom: ce,
        marginLeft: ce,
        rotate: Fn,
        rotateX: Fn,
        rotateY: Fn,
        rotateZ: Fn,
        scale: bi,
        scaleX: bi,
        scaleY: bi,
        scaleZ: bi,
        skew: Fn,
        skewX: Fn,
        skewY: Fn,
        distance: ce,
        translateX: ce,
        translateY: ce,
        translateZ: ce,
        x: ce,
        y: ce,
        z: ce,
        perspective: ce,
        transformPerspective: ce,
        opacity: ya,
        originX: $f,
        originY: $f,
        originZ: ce,
        zIndex: Wf,
        filter: ul,
        WebkitFilter: ul,
        fillOpacity: ya,
        strokeOpacity: ya,
        numOctaves: Wf
    },
    Ic = e => Gm[e];

function Wm(e, t) {
    return t && typeof e == "number" && t.transform ? t.transform(e) : e
}

function fL(e, t) {
    let n = Ic(e);
    return n !== ul && (n = Za), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
}
const dL = {
    linear: Im,
    easeIn: Pc,
    easeInOut: Dm,
    easeOut: MA,
    circIn: Nm,
    circInOut: PA,
    circOut: Fm,
    backIn: xc,
    backInOut: IA,
    backOut: xA,
    anticipate: DA,
    bounceIn: jA,
    bounceInOut: $A,
    bounceOut: Qi
};

function zf(e) {
    if (Array.isArray(e)) {
        const [t, n, r, a] = e;
        return nL(t, n, r, a)
    } else if (typeof e == "string") return dL[e];
    return e
}

function pL(e) {
    return Array.isArray(e) && typeof e[0] != "number"
}

function qf(e, t) {
    return e === "zIndex" ? !1 : !!(typeof t == "number" || Array.isArray(t) || typeof t == "string" && Za.test(t) && !t.startsWith("url("))
}

function hL(e) {
    return Array.isArray(e.to) && e.to[0] === null && (e.to = [...e.to], e.to[0] = e.from), e
}

function mL({
    ease: e,
    times: t,
    delay: n,
    ...r
}) {
    const a = { ...r
    };
    return t && (a.offset = t), e && (a.ease = pL(e) ? e.map(zf) : zf(e)), n && (a.elapsed = -n), a
}

function gL(e, t, n) {
    return Array.isArray(t.to) && (e.duration || (e.duration = 800)), hL(t), yL(e) || (e = { ...e,
        ...Jm(n, t.to)
    }), { ...t,
        ...mL(e)
    }
}

function yL({
    delay: e,
    repeat: t,
    repeatType: n,
    repeatDelay: r,
    from: a,
    ...i
}) {
    return !!Object.keys(i).length
}

function bL(e, t) {
    return e[t] || e.default || e
}

function vL(e, t, n, r, a) {
    const i = bL(r, e);
    let o = i.from === null || i.from === void 0 ? t.get() : i.from;
    const s = qf(e, n);
    o === "none" && s && typeof n == "string" && (o = fL(e, n));
    const l = qf(e, o);

    function c(f) {
        const d = {
            from: o,
            to: n,
            velocity: r.velocity ? r.velocity : t.getVelocity(),
            onUpdate: p => t.set(p)
        };
        return i.type === "inertia" || i.type === "decay" ? qA({ ...d,
            ...i
        }) : jm({ ...gL(i, d, e),
            onUpdate: p => {
                d.onUpdate(p), i.onUpdate && i.onUpdate(p)
            },
            onComplete: () => {
                r.onComplete && r.onComplete(), a && a(), f && f()
            }
        })
    }

    function u(f) {
        return t.set(n), r.onComplete && r.onComplete(), a && a(), f && f(), {
            stop: () => {}
        }
    }
    return !l || !s || i.type === !1 ? u : c
}

function _L() {
    const {
        motionValues: e,
        stop: t,
        get: n
    } = sL();
    return {
        motionValues: e,
        stop: t,
        push: (a, i, o, s = {}, l) => {
            const c = o[a],
                u = n(a, c, o);
            if (s && s.immediate) {
                u.set(i);
                return
            }
            const f = vL(a, u, i, s, l);
            u.start(f)
        }
    }
}

function wL(e, t = {}, {
    motionValues: n,
    push: r,
    stop: a
} = _L()) {
    const i = pe(t),
        o = Q(!1);
    we(n, f => {
        o.value = Object.values(f).filter(d => d.isAnimating()).length > 0
    }, {
        immediate: !0,
        deep: !0
    });
    const s = f => {
            if (!i || !i[f]) throw new Error(`The variant ${f} does not exist.`);
            return i[f]
        },
        l = f => (typeof f == "string" && (f = s(f)), Promise.all(Object.entries(f).map(([d, p]) => {
            if (d !== "transition") return new Promise(v => r(d, p, e, f.transition || Jm(d, f[d]), v))
        }).filter(Boolean)));
    return {
        isAnimating: o,
        apply: l,
        set: f => {
            const d = Xi(f) ? f : s(f);
            Object.entries(d).forEach(([p, v]) => {
                p !== "transition" && r(p, v, e, {
                    immediate: !0
                })
            })
        },
        leave: async f => {
            let d;
            if (i && (i.leave && (d = i.leave), !i.leave && i.initial && (d = i.initial)), !d) {
                f();
                return
            }
            await l(d), f()
        },
        stop: a
    }
}
const Dc = typeof window < "u",
    EL = () => Dc && window.onpointerdown === null,
    CL = () => Dc && window.ontouchstart === null,
    AL = () => Dc && window.onmousedown === null;

function LL({
    target: e,
    state: t,
    variants: n,
    apply: r
}) {
    const a = pe(n),
        i = Q(!1),
        o = Q(!1),
        s = Q(!1),
        l = W(() => {
            let u = [];
            return a && (a.hovered && (u = [...u, ...Object.keys(a.hovered)]), a.tapped && (u = [...u, ...Object.keys(a.tapped)]), a.focused && (u = [...u, ...Object.keys(a.focused)])), u
        }),
        c = W(() => {
            const u = {};
            Object.assign(u, t.value), i.value && a.hovered && Object.assign(u, a.hovered), o.value && a.tapped && Object.assign(u, a.tapped), s.value && a.focused && Object.assign(u, a.focused);
            for (const f in u) l.value.includes(f) || delete u[f];
            return u
        });
    a.hovered && (at(e, "mouseenter", () => i.value = !0), at(e, "mouseleave", () => {
        i.value = !1, o.value = !1
    }), at(e, "mouseout", () => {
        i.value = !1, o.value = !1
    })), a.tapped && (AL() && (at(e, "mousedown", () => o.value = !0), at(e, "mouseup", () => o.value = !1)), EL() && (at(e, "pointerdown", () => o.value = !0), at(e, "pointerup", () => o.value = !1)), CL() && (at(e, "touchstart", () => o.value = !0), at(e, "touchend", () => o.value = !1))), a.focused && (at(e, "focus", () => s.value = !0), at(e, "blur", () => s.value = !1)), we(c, r)
}

function SL({
    set: e,
    target: t,
    variants: n,
    variant: r
}) {
    const a = pe(n);
    we(() => t, () => {
        a && (a.initial && e("initial"), a.enter && (r.value = "enter"))
    }, {
        immediate: !0,
        flush: "pre"
    })
}

function TL({
    state: e,
    apply: t
}) {
    we(e, n => {
        n && t(n)
    }, {
        immediate: !0
    })
}

function kL({
    target: e,
    variants: t,
    variant: n
}) {
    const r = pe(t);
    r && (r.visible || r.visibleOnce) && FC(e, ([{
        isIntersecting: a
    }]) => {
        r.visible ? a ? n.value = "visible" : n.value = "initial" : r.visibleOnce && (a && n.value !== "visibleOnce" ? n.value = "visibleOnce" : n.value || (n.value = "initial"))
    })
}

function RL(e, t = {
    syncVariants: !0,
    lifeCycleHooks: !0,
    visibilityHooks: !0,
    eventListeners: !0
}) {
    t.lifeCycleHooks && SL(e), t.syncVariants && TL(e), t.visibilityHooks && kL(e), t.eventListeners && LL(e)
}

function zm(e = {}) {
    const t = tt({ ...e
        }),
        n = Q({});
    return we(t, () => {
        const r = {};
        for (const [a, i] of Object.entries(t)) {
            const o = Ic(a),
                s = Wm(i, o);
            r[a] = s
        }
        n.value = r
    }, {
        immediate: !0,
        deep: !0
    }), {
        state: t,
        style: n
    }
}

function Nc(e, t) {
    we(() => ma(e), n => {
        n && t(n)
    }, {
        immediate: !0
    })
}
const OL = {
    x: "translateX",
    y: "translateY",
    z: "translateZ"
};

function qm(e = {}, t = !0) {
    const n = tt({ ...e
        }),
        r = Q("");
    return we(n, a => {
        let i = "",
            o = !1;
        if (t && (a.x || a.y || a.z)) {
            const s = [a.x || 0, a.y || 0, a.z || 0].map(ce.transform).join(",");
            i += `translate3d(${s}) `, o = !0
        }
        for (const [s, l] of Object.entries(a)) {
            if (t && (s === "x" || s === "y" || s === "z")) continue;
            const c = Ic(s),
                u = Wm(l, c);
            i += `${OL[s]||s}(${u}) `
        }
        t && !o && (i += "translateZ(0px) "), r.value = i.trim()
    }, {
        immediate: !0,
        deep: !0
    }), {
        state: n,
        transform: r
    }
}
const ML = ["", "X", "Y", "Z"],
    PL = ["perspective", "translate", "scale", "rotate", "skew"],
    Ym = ["transformPerspective", "x", "y", "z"];
PL.forEach(e => {
    ML.forEach(t => {
        const n = e + t;
        Ym.push(n)
    })
});
const xL = new Set(Ym);

function Fc(e) {
    return xL.has(e)
}
const IL = new Set(["originX", "originY", "originZ"]);

function Xm(e) {
    return IL.has(e)
}

function DL(e) {
    const t = {},
        n = {};
    return Object.entries(e).forEach(([r, a]) => {
        Fc(r) || Xm(r) ? t[r] = a : n[r] = a
    }), {
        transform: t,
        style: n
    }
}

function Qm(e) {
    const {
        transform: t,
        style: n
    } = DL(e), {
        transform: r
    } = qm(t), {
        style: a
    } = zm(n);
    return r.value && (a.value.transform = r.value), a.value
}

function NL(e, t) {
    let n, r;
    const {
        state: a,
        style: i
    } = zm();
    return Nc(e, o => {
        r = o;
        for (const s of Object.keys(Gm)) o.style[s] === null || o.style[s] === "" || Fc(s) || Xm(s) || (a[s] = o.style[s]);
        n && Object.entries(n).forEach(([s, l]) => o.style[s] = l), t && t(a)
    }), we(i, o => {
        if (!r) {
            n = o;
            return
        }
        for (const s in o) r.style[s] = o[s]
    }, {
        immediate: !0
    }), {
        style: a
    }
}

function FL(e) {
    const t = e.trim().split(/\) |\)/);
    if (t.length === 1) return {};
    const n = r => r.endsWith("px") || r.endsWith("deg") ? parseFloat(r) : isNaN(Number(r)) ? Number(r) : r;
    return t.reduce((r, a) => {
        if (!a) return r;
        const [i, o] = a.split("("), l = o.split(",").map(u => n(u.endsWith(")") ? u.replace(")", "") : u.trim())), c = l.length === 1 ? l[0] : l;
        return { ...r,
            [i]: c
        }
    }, {})
}

function BL(e, t) {
    Object.entries(FL(t)).forEach(([n, r]) => {
        const a = ["x", "y", "z"];
        if (n === "translate3d") {
            if (r === 0) {
                a.forEach(i => e[i] = 0);
                return
            }
            r.forEach((i, o) => e[a[o]] = i);
            return
        }
        if (r = parseFloat(r), n === "translateX") {
            e.x = r;
            return
        }
        if (n === "translateY") {
            e.y = r;
            return
        }
        if (n === "translateZ") {
            e.z = r;
            return
        }
        e[n] = r
    })
}

function jL(e, t) {
    let n, r;
    const {
        state: a,
        transform: i
    } = qm();
    return Nc(e, o => {
        r = o, o.style.transform && BL(a, o.style.transform), n && (o.style.transform = n), t && t(a)
    }), we(i, o => {
        if (!r) {
            n = o;
            return
        }
        r.style.transform = o
    }, {
        immediate: !0
    }), {
        transform: a
    }
}

function $L(e, t) {
    const n = tt({}),
        r = o => Object.entries(o).forEach(([s, l]) => n[s] = l),
        {
            style: a
        } = NL(e, r),
        {
            transform: i
        } = jL(e, r);
    return we(n, o => {
        Object.entries(o).forEach(([s, l]) => {
            const c = Fc(s) ? i : a;
            c[s] && c[s] === l || (c[s] = l)
        })
    }, {
        immediate: !0,
        deep: !0
    }), Nc(e, () => t && r(t)), {
        motionProperties: n,
        style: a,
        transform: i
    }
}

function VL(e = {}) {
    const t = pe(e),
        n = Q();
    return {
        state: W(() => {
            if (n.value) return t[n.value]
        }),
        variant: n
    }
}

function Zm(e, t = {}, n) {
    const {
        motionProperties: r
    } = $L(e), {
        variant: a,
        state: i
    } = VL(t), o = wL(r, t), s = {
        target: e,
        variant: a,
        variants: t,
        state: i,
        motionProperties: r,
        ...o
    };
    return RL(s, n), s
}
const HL = ["initial", "enter", "leave", "visible", "visible-once", "hovered", "tapped", "focused", "delay"];

function KL(e, t) {
    const n = e.props ? e.props : e.data && e.data.attrs ? e.data.attrs : {};
    n && (n.variants && Xi(n.variants) && (t.value = { ...t.value,
        ...n.variants
    }), HL.forEach(r => {
        if (r === "delay") {
            if (n && n[r] && typeof n[r] == "number") {
                const a = n[r];
                t && t.value && (t.value.enter && (t.value.enter.transition || (t.value.enter.transition = {}), t.value.enter.transition = {
                    delay: a,
                    ...t.value.enter.transition
                }), t.value.visible && (t.value.visible.transition || (t.value.visible.transition = {}), t.value.visible.transition = {
                    delay: a,
                    ...t.value.visible.transition
                }), t.value.visibleOnce && (t.value.visibleOnce.transition || (t.value.visibleOnce.transition = {}), t.value.visibleOnce.transition = {
                    delay: a,
                    ...t.value.visibleOnce.transition
                }))
            }
            return
        }
        r === "visible-once" && (r = "visibleOnce"), n && n[r] && Xi(n[r]) && (t.value[r] = n[r])
    }))
}

function hs(e) {
    return {
        created: (n, r, a) => {
            const i = r.value && typeof r.value == "string" ? r.value : a.key;
            i && fs[i] && fs[i].stop();
            const o = Q(e || {});
            typeof r.value == "object" && (o.value = r.value), KL(a, o);
            const s = Zm(n, o);
            n.motionInstance = s, i && (fs[i] = s)
        },
        getSSRProps(n, r) {
            let {
                initial: a
            } = n.value || r && (r == null ? void 0 : r.props) || {};
            a = pe(a);
            const i = Eo((e == null ? void 0 : e.initial) || {}, a || {});
            return !i || Object.keys(i).length === 0 ? void 0 : {
                style: Qm(i)
            }
        }
    }
}
const UL = {
        initial: {
            opacity: 0
        },
        enter: {
            opacity: 1
        }
    },
    JL = {
        initial: {
            opacity: 0
        },
        visible: {
            opacity: 1
        }
    },
    GL = {
        initial: {
            opacity: 0
        },
        visibleOnce: {
            opacity: 1
        }
    },
    WL = {
        initial: {
            scale: 0,
            opacity: 0
        },
        enter: {
            scale: 1,
            opacity: 1
        }
    },
    zL = {
        initial: {
            scale: 0,
            opacity: 0
        },
        visible: {
            scale: 1,
            opacity: 1
        }
    },
    qL = {
        initial: {
            scale: 0,
            opacity: 0
        },
        visibleOnce: {
            scale: 1,
            opacity: 1
        }
    },
    YL = {
        initial: {
            x: -100,
            rotate: 90,
            opacity: 0
        },
        enter: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    XL = {
        initial: {
            x: -100,
            rotate: 90,
            opacity: 0
        },
        visible: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    QL = {
        initial: {
            x: -100,
            rotate: 90,
            opacity: 0
        },
        visibleOnce: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    ZL = {
        initial: {
            x: 100,
            rotate: -90,
            opacity: 0
        },
        enter: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    eS = {
        initial: {
            x: 100,
            rotate: -90,
            opacity: 0
        },
        visible: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    tS = {
        initial: {
            x: 100,
            rotate: -90,
            opacity: 0
        },
        visibleOnce: {
            x: 0,
            rotate: 0,
            opacity: 1
        }
    },
    nS = {
        initial: {
            y: -100,
            rotate: -90,
            opacity: 0
        },
        enter: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    rS = {
        initial: {
            y: -100,
            rotate: -90,
            opacity: 0
        },
        visible: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    aS = {
        initial: {
            y: -100,
            rotate: -90,
            opacity: 0
        },
        visibleOnce: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    iS = {
        initial: {
            y: 100,
            rotate: 90,
            opacity: 0
        },
        enter: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    oS = {
        initial: {
            y: 100,
            rotate: 90,
            opacity: 0
        },
        visible: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    sS = {
        initial: {
            y: 100,
            rotate: 90,
            opacity: 0
        },
        visibleOnce: {
            y: 0,
            rotate: 0,
            opacity: 1
        }
    },
    lS = {
        initial: {
            x: -100,
            opacity: 0
        },
        enter: {
            x: 0,
            opacity: 1
        }
    },
    cS = {
        initial: {
            x: -100,
            opacity: 0
        },
        visible: {
            x: 0,
            opacity: 1
        }
    },
    uS = {
        initial: {
            x: -100,
            opacity: 0
        },
        visibleOnce: {
            x: 0,
            opacity: 1
        }
    },
    fS = {
        initial: {
            x: 100,
            opacity: 0
        },
        enter: {
            x: 0,
            opacity: 1
        }
    },
    dS = {
        initial: {
            x: 100,
            opacity: 0
        },
        visible: {
            x: 0,
            opacity: 1
        }
    },
    pS = {
        initial: {
            x: 100,
            opacity: 0
        },
        visibleOnce: {
            x: 0,
            opacity: 1
        }
    },
    hS = {
        initial: {
            y: -100,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1
        }
    },
    mS = {
        initial: {
            y: -100,
            opacity: 0
        },
        visible: {
            y: 0,
            opacity: 1
        }
    },
    gS = {
        initial: {
            y: -100,
            opacity: 0
        },
        visibleOnce: {
            y: 0,
            opacity: 1
        }
    },
    yS = {
        initial: {
            y: 100,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1
        }
    },
    bS = {
        initial: {
            y: 100,
            opacity: 0
        },
        visible: {
            y: 0,
            opacity: 1
        }
    },
    vS = {
        initial: {
            y: 100,
            opacity: 0
        },
        visibleOnce: {
            y: 0,
            opacity: 1
        }
    },
    fl = {
        __proto__: null,
        fade: UL,
        fadeVisible: JL,
        fadeVisibleOnce: GL,
        pop: WL,
        popVisible: zL,
        popVisibleOnce: qL,
        rollBottom: iS,
        rollLeft: YL,
        rollRight: ZL,
        rollTop: nS,
        rollVisibleBottom: oS,
        rollVisibleLeft: XL,
        rollVisibleOnceBottom: sS,
        rollVisibleOnceLeft: QL,
        rollVisibleOnceRight: tS,
        rollVisibleOnceTop: aS,
        rollVisibleRight: eS,
        rollVisibleTop: rS,
        slideBottom: yS,
        slideLeft: lS,
        slideRight: fS,
        slideTop: hS,
        slideVisibleBottom: bS,
        slideVisibleLeft: cS,
        slideVisibleOnceBottom: vS,
        slideVisibleOnceLeft: uS,
        slideVisibleOnceRight: pS,
        slideVisibleOnceTop: gS,
        slideVisibleRight: dS,
        slideVisibleTop: mS
    },
    _S = Ne({
        props: {
            is: {
                type: [String, Object],
                required: !1
            },
            preset: {
                type: String,
                required: !1
            },
            instance: {
                type: Object,
                required: !1
            },
            variants: {
                type: Object,
                required: !1
            },
            initial: {
                type: Object,
                required: !1
            },
            enter: {
                type: Object,
                required: !1
            },
            leave: {
                type: Object,
                required: !1
            },
            visible: {
                type: Object,
                required: !1
            },
            visibleOnce: {
                type: Object,
                required: !1
            },
            hovered: {
                type: Object,
                required: !1
            },
            tapped: {
                type: Object,
                required: !1
            },
            focused: {
                type: Object,
                required: !1
            },
            delay: {
                type: [Number, String],
                required: !1
            }
        },
        setup(e) {
            var s;
            const t = Gb(),
                n = tt({});
            if (!e.is && !t.default) return () => Be("div", {});
            const r = W(() => {
                    let l;
                    return e.preset && (l = fl[e.preset]), l
                }),
                a = W(() => ({
                    initial: e.initial,
                    enter: e.enter,
                    leave: e.leave,
                    visible: e.visible,
                    visibleOnce: e.visibleOnce,
                    hovered: e.hovered,
                    tapped: e.tapped,
                    focused: e.focused
                })),
                i = W(() => {
                    const l = { ...a.value,
                        ...r.value || {},
                        ...e.variants || {}
                    };
                    return e.delay && (l.enter.transition = { ...l.enter.transition
                    }, l.enter.transition.delay = parseInt(e.delay)), l
                }),
                o = W(() => {
                    if (!e.is) return;
                    let l = e.is;
                    return typeof o.value == "string" && !Dy(l) && (l = Np(l)), l
                });
            if (((s = process == null ? void 0 : process.env) == null ? void 0 : s.NODE_ENV) === "development" || process != null && process.dev) {
                const l = c => {
                    var u;
                    (u = c.variants) != null && u.initial && c.set("initial"), setTimeout(() => {
                        var f, d, p;
                        (f = c.variants) != null && f.enter && c.apply("enter"), (d = c.variants) != null && d.visible && c.apply("visible"), (p = c.variants) != null && p.visibleOnce && c.apply("visibleOnce")
                    }, 10)
                };
                cc(() => Object.entries(n).forEach(([c, u]) => l(u)))
            }
            return {
                slots: t,
                component: o,
                motionConfig: i,
                instances: n
            }
        },
        render({
            slots: e,
            motionConfig: t,
            instances: n,
            component: r
        }) {
            var s;
            const a = Qm(t.initial || {}),
                i = (l, c) => (l.props || (l.props = {}), l.props.style = a, l.props.onVnodeMounted = ({
                    el: u
                }) => {
                    const f = Zm(u, t);
                    n[c] = f
                }, l);
            if (r) {
                const l = Be(r, void 0, e);
                return i(l, 0), l
            }
            return (((s = e.default) == null ? void 0 : s.call(e)) || []).map((l, c) => i(l, c))
        }
    });

function wS(e) {
    const t = "àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż·/_,:;",
        n = "aaaaaaaaaacccddeeeeeeeegghiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz------",
        r = new RegExp(t.split("").join("|"), "g");
    return e.toString().replace(/[A-Z]/g, a => `-${a}`).toLowerCase().replace(/\s+/g, "-").replace(r, a => n.charAt(t.indexOf(a))).replace(/&/g, "-and-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "")
}
const ES = {
        install(e, t) {
            if (e.directive("motion", hs()), e.component("Motion", _S), !t || t && !t.excludePresets)
                for (const n in fl) {
                    const r = fl[n];
                    e.directive(`motion-${wS(n)}`, hs(r))
                }
            if (t && t.directives)
                for (const n in t.directives) {
                    const r = t.directives[n];
                    !r.initial && __DEV__ && console.warn(`Your directive v-motion-${n} is missing initial variant!`), e.directive(`motion-${n}`, hs(r))
                }
        }
    },
    CS = Qe(e => {
        const {
            motion: t
        } = Nt();
        e.vueApp.use(ES, t)
    });

function Et() {
    for (var e = 0, t, n, r = ""; e < arguments.length;)(t = arguments[e++]) && (n = eg(t)) && (r && (r += " "), r += n);
    return r
}

function eg(e) {
    if (typeof e == "string") return e;
    for (var t, n = "", r = 0; r < e.length; r++) e[r] && (t = eg(e[r])) && (n && (n += " "), n += t);
    return n
}
var Bc = "-";

function AS(e) {
    var t = SS(e),
        n = e.conflictingClassGroups,
        r = e.conflictingClassGroupModifiers,
        a = r === void 0 ? {} : r;

    function i(s) {
        var l = s.split(Bc);
        return l[0] === "" && l.length !== 1 && l.shift(), tg(l, t) || LS(s)
    }

    function o(s, l) {
        var c = n[s] || [];
        return l && a[s] ? [].concat(c, a[s]) : c
    }
    return {
        getClassGroupId: i,
        getConflictingClassGroupIds: o
    }
}

function tg(e, t) {
    var o;
    if (e.length === 0) return t.classGroupId;
    var n = e[0],
        r = t.nextPart.get(n),
        a = r ? tg(e.slice(1), r) : void 0;
    if (a) return a;
    if (t.validators.length !== 0) {
        var i = e.join(Bc);
        return (o = t.validators.find(function(s) {
            var l = s.validator;
            return l(i)
        })) == null ? void 0 : o.classGroupId
    }
}
var Yf = /^\[(.+)\]$/;

function LS(e) {
    if (Yf.test(e)) {
        var t = Yf.exec(e)[1],
            n = t == null ? void 0 : t.substring(0, t.indexOf(":"));
        if (n) return "arbitrary.." + n
    }
}

function SS(e) {
    var t = e.theme,
        n = e.prefix,
        r = {
            nextPart: new Map,
            validators: []
        },
        a = kS(Object.entries(e.classGroups), n);
    return a.forEach(function(i) {
        var o = i[0],
            s = i[1];
        dl(s, r, o, t)
    }), r
}

function dl(e, t, n, r) {
    e.forEach(function(a) {
        if (typeof a == "string") {
            var i = a === "" ? t : Xf(t, a);
            i.classGroupId = n;
            return
        }
        if (typeof a == "function") {
            if (TS(a)) {
                dl(a(r), t, n, r);
                return
            }
            t.validators.push({
                validator: a,
                classGroupId: n
            });
            return
        }
        Object.entries(a).forEach(function(o) {
            var s = o[0],
                l = o[1];
            dl(l, Xf(t, s), n, r)
        })
    })
}

function Xf(e, t) {
    var n = e;
    return t.split(Bc).forEach(function(r) {
        n.nextPart.has(r) || n.nextPart.set(r, {
            nextPart: new Map,
            validators: []
        }), n = n.nextPart.get(r)
    }), n
}

function TS(e) {
    return e.isThemeGetter
}

function kS(e, t) {
    return t ? e.map(function(n) {
        var r = n[0],
            a = n[1],
            i = a.map(function(o) {
                return typeof o == "string" ? t + o : typeof o == "object" ? Object.fromEntries(Object.entries(o).map(function(s) {
                    var l = s[0],
                        c = s[1];
                    return [t + l, c]
                })) : o
            });
        return [r, i]
    }) : e
}

function RS(e) {
    if (e < 1) return {
        get: function() {},
        set: function() {}
    };
    var t = 0,
        n = new Map,
        r = new Map;

    function a(i, o) {
        n.set(i, o), t++, t > e && (t = 0, r = n, n = new Map)
    }
    return {
        get: function(o) {
            var s = n.get(o);
            if (s !== void 0) return s;
            if ((s = r.get(o)) !== void 0) return a(o, s), s
        },
        set: function(o, s) {
            n.has(o) ? n.set(o, s) : a(o, s)
        }
    }
}
var ng = "!";

function OS(e) {
    var t = e.separator || ":",
        n = t.length === 1,
        r = t[0],
        a = t.length;
    return function(o) {
        for (var s = [], l = 0, c = 0, u, f = 0; f < o.length; f++) {
            var d = o[f];
            if (l === 0) {
                if (d === r && (n || o.slice(f, f + a) === t)) {
                    s.push(o.slice(c, f)), c = f + a;
                    continue
                }
                if (d === "/") {
                    u = f;
                    continue
                }
            }
            d === "[" ? l++ : d === "]" && l--
        }
        var p = s.length === 0 ? o : o.substring(c),
            v = p.startsWith(ng),
            E = v ? p.substring(1) : p,
            w = u && u > c ? u - c : void 0;
        return {
            modifiers: s,
            hasImportantModifier: v,
            baseClassName: E,
            maybePostfixModifierPosition: w
        }
    }
}

function MS(e) {
    if (e.length <= 1) return e;
    var t = [],
        n = [];
    return e.forEach(function(r) {
        var a = r[0] === "[";
        a ? (t.push.apply(t, n.sort().concat([r])), n = []) : n.push(r)
    }), t.push.apply(t, n.sort()), t
}

function PS(e) {
    return {
        cache: RS(e.cacheSize),
        splitModifiers: OS(e),
        ...AS(e)
    }
}
var xS = /\s+/;

function IS(e, t) {
    var n = t.splitModifiers,
        r = t.getClassGroupId,
        a = t.getConflictingClassGroupIds,
        i = new Set;
    return e.trim().split(xS).map(function(o) {
        var s = n(o),
            l = s.modifiers,
            c = s.hasImportantModifier,
            u = s.baseClassName,
            f = s.maybePostfixModifierPosition,
            d = r(f ? u.substring(0, f) : u),
            p = !!f;
        if (!d) {
            if (!f) return {
                isTailwindClass: !1,
                originalClassName: o
            };
            if (d = r(u), !d) return {
                isTailwindClass: !1,
                originalClassName: o
            };
            p = !1
        }
        var v = MS(l).join(":"),
            E = c ? v + ng : v;
        return {
            isTailwindClass: !0,
            modifierId: E,
            classGroupId: d,
            originalClassName: o,
            hasPostfixModifier: p
        }
    }).reverse().filter(function(o) {
        if (!o.isTailwindClass) return !0;
        var s = o.modifierId,
            l = o.classGroupId,
            c = o.hasPostfixModifier,
            u = s + l;
        return i.has(u) ? !1 : (i.add(u), a(l, c).forEach(function(f) {
            return i.add(s + f)
        }), !0)
    }).reverse().map(function(o) {
        return o.originalClassName
    }).join(" ")
}

function pl() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
    var r, a, i, o = s;

    function s(c) {
        var u = t[0],
            f = t.slice(1),
            d = f.reduce(function(p, v) {
                return v(p)
            }, u());
        return r = PS(d), a = r.cache.get, i = r.cache.set, o = l, l(c)
    }

    function l(c) {
        var u = a(c);
        if (u) return u;
        var f = IS(c, r);
        return i(c, f), f
    }
    return function() {
        return o(Et.apply(null, arguments))
    }
}

function Re(e) {
    var t = function(r) {
        return r[e] || []
    };
    return t.isThemeGetter = !0, t
}
var rg = /^\[(?:([a-z-]+):)?(.+)\]$/i,
    DS = /^\d+\/\d+$/,
    NS = new Set(["px", "full", "screen"]),
    FS = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
    BS = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
    jS = /^-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;

function kt(e) {
    return zn(e) || NS.has(e) || DS.test(e) || hl(e)
}

function hl(e) {
    return sr(e, "length", JS)
}

function $S(e) {
    return sr(e, "size", ag)
}

function VS(e) {
    return sr(e, "position", ag)
}

function HS(e) {
    return sr(e, "url", GS)
}

function _i(e) {
    return sr(e, "number", zn)
}

function zn(e) {
    return !Number.isNaN(Number(e))
}

function KS(e) {
    return e.endsWith("%") && zn(e.slice(0, -1))
}

function Yr(e) {
    return Qf(e) || sr(e, "number", Qf)
}

function de(e) {
    return rg.test(e)
}

function Xr() {
    return !0
}

function un(e) {
    return FS.test(e)
}

function US(e) {
    return sr(e, "", WS)
}

function sr(e, t, n) {
    var r = rg.exec(e);
    return r ? r[1] ? r[1] === t : n(r[2]) : !1
}

function JS(e) {
    return BS.test(e)
}

function ag() {
    return !1
}

function GS(e) {
    return e.startsWith("url(")
}

function Qf(e) {
    return Number.isInteger(Number(e))
}

function WS(e) {
    return jS.test(e)
}

function ml() {
    var e = Re("colors"),
        t = Re("spacing"),
        n = Re("blur"),
        r = Re("brightness"),
        a = Re("borderColor"),
        i = Re("borderRadius"),
        o = Re("borderSpacing"),
        s = Re("borderWidth"),
        l = Re("contrast"),
        c = Re("grayscale"),
        u = Re("hueRotate"),
        f = Re("invert"),
        d = Re("gap"),
        p = Re("gradientColorStops"),
        v = Re("gradientColorStopPositions"),
        E = Re("inset"),
        w = Re("margin"),
        h = Re("opacity"),
        b = Re("padding"),
        m = Re("saturate"),
        y = Re("scale"),
        C = Re("sepia"),
        S = Re("skew"),
        A = Re("space"),
        R = Re("translate"),
        O = function() {
            return ["auto", "contain", "none"]
        },
        N = function() {
            return ["auto", "hidden", "clip", "visible", "scroll"]
        },
        x = function() {
            return ["auto", de, t]
        },
        M = function() {
            return [de, t]
        },
        K = function() {
            return ["", kt]
        },
        ne = function() {
            return ["auto", zn, de]
        },
        te = function() {
            return ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"]
        },
        J = function() {
            return ["solid", "dashed", "dotted", "double", "none"]
        },
        ae = function() {
            return ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter"]
        },
        X = function() {
            return ["start", "end", "center", "between", "around", "evenly", "stretch"]
        },
        Ce = function() {
            return ["", "0", de]
        },
        Ze = function() {
            return ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"]
        },
        je = function() {
            return [zn, _i]
        },
        Ie = function() {
            return [zn, de]
        };
    return {
        cacheSize: 500,
        theme: {
            colors: [Xr],
            spacing: [kt],
            blur: ["none", "", un, de],
            brightness: je(),
            borderColor: [e],
            borderRadius: ["none", "", "full", un, de],
            borderSpacing: M(),
            borderWidth: K(),
            contrast: je(),
            grayscale: Ce(),
            hueRotate: Ie(),
            invert: Ce(),
            gap: M(),
            gradientColorStops: [e],
            gradientColorStopPositions: [KS, hl],
            inset: x(),
            margin: x(),
            opacity: je(),
            padding: M(),
            saturate: je(),
            scale: je(),
            sepia: Ce(),
            skew: Ie(),
            space: M(),
            translate: M()
        },
        classGroups: {
            aspect: [{
                aspect: ["auto", "square", "video", de]
            }],
            container: ["container"],
            columns: [{
                columns: [un]
            }],
            "break-after": [{
                "break-after": Ze()
            }],
            "break-before": [{
                "break-before": Ze()
            }],
            "break-inside": [{
                "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
            }],
            "box-decoration": [{
                "box-decoration": ["slice", "clone"]
            }],
            box: [{
                box: ["border", "content"]
            }],
            display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
            float: [{
                float: ["right", "left", "none"]
            }],
            clear: [{
                clear: ["left", "right", "both", "none"]
            }],
            isolation: ["isolate", "isolation-auto"],
            "object-fit": [{
                object: ["contain", "cover", "fill", "none", "scale-down"]
            }],
            "object-position": [{
                object: [].concat(te(), [de])
            }],
            overflow: [{
                overflow: N()
            }],
            "overflow-x": [{
                "overflow-x": N()
            }],
            "overflow-y": [{
                "overflow-y": N()
            }],
            overscroll: [{
                overscroll: O()
            }],
            "overscroll-x": [{
                "overscroll-x": O()
            }],
            "overscroll-y": [{
                "overscroll-y": O()
            }],
            position: ["static", "fixed", "absolute", "relative", "sticky"],
            inset: [{
                inset: [E]
            }],
            "inset-x": [{
                "inset-x": [E]
            }],
            "inset-y": [{
                "inset-y": [E]
            }],
            start: [{
                start: [E]
            }],
            end: [{
                end: [E]
            }],
            top: [{
                top: [E]
            }],
            right: [{
                right: [E]
            }],
            bottom: [{
                bottom: [E]
            }],
            left: [{
                left: [E]
            }],
            visibility: ["visible", "invisible", "collapse"],
            z: [{
                z: ["auto", Yr]
            }],
            basis: [{
                basis: x()
            }],
            "flex-direction": [{
                flex: ["row", "row-reverse", "col", "col-reverse"]
            }],
            "flex-wrap": [{
                flex: ["wrap", "wrap-reverse", "nowrap"]
            }],
            flex: [{
                flex: ["1", "auto", "initial", "none", de]
            }],
            grow: [{
                grow: Ce()
            }],
            shrink: [{
                shrink: Ce()
            }],
            order: [{
                order: ["first", "last", "none", Yr]
            }],
            "grid-cols": [{
                "grid-cols": [Xr]
            }],
            "col-start-end": [{
                col: ["auto", {
                    span: ["full", Yr]
                }, de]
            }],
            "col-start": [{
                "col-start": ne()
            }],
            "col-end": [{
                "col-end": ne()
            }],
            "grid-rows": [{
                "grid-rows": [Xr]
            }],
            "row-start-end": [{
                row: ["auto", {
                    span: [Yr]
                }, de]
            }],
            "row-start": [{
                "row-start": ne()
            }],
            "row-end": [{
                "row-end": ne()
            }],
            "grid-flow": [{
                "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
            }],
            "auto-cols": [{
                "auto-cols": ["auto", "min", "max", "fr", de]
            }],
            "auto-rows": [{
                "auto-rows": ["auto", "min", "max", "fr", de]
            }],
            gap: [{
                gap: [d]
            }],
            "gap-x": [{
                "gap-x": [d]
            }],
            "gap-y": [{
                "gap-y": [d]
            }],
            "justify-content": [{
                justify: ["normal"].concat(X())
            }],
            "justify-items": [{
                "justify-items": ["start", "end", "center", "stretch"]
            }],
            "justify-self": [{
                "justify-self": ["auto", "start", "end", "center", "stretch"]
            }],
            "align-content": [{
                content: ["normal"].concat(X(), ["baseline"])
            }],
            "align-items": [{
                items: ["start", "end", "center", "baseline", "stretch"]
            }],
            "align-self": [{
                self: ["auto", "start", "end", "center", "stretch", "baseline"]
            }],
            "place-content": [{
                "place-content": [].concat(X(), ["baseline"])
            }],
            "place-items": [{
                "place-items": ["start", "end", "center", "baseline", "stretch"]
            }],
            "place-self": [{
                "place-self": ["auto", "start", "end", "center", "stretch"]
            }],
            p: [{
                p: [b]
            }],
            px: [{
                px: [b]
            }],
            py: [{
                py: [b]
            }],
            ps: [{
                ps: [b]
            }],
            pe: [{
                pe: [b]
            }],
            pt: [{
                pt: [b]
            }],
            pr: [{
                pr: [b]
            }],
            pb: [{
                pb: [b]
            }],
            pl: [{
                pl: [b]
            }],
            m: [{
                m: [w]
            }],
            mx: [{
                mx: [w]
            }],
            my: [{
                my: [w]
            }],
            ms: [{
                ms: [w]
            }],
            me: [{
                me: [w]
            }],
            mt: [{
                mt: [w]
            }],
            mr: [{
                mr: [w]
            }],
            mb: [{
                mb: [w]
            }],
            ml: [{
                ml: [w]
            }],
            "space-x": [{
                "space-x": [A]
            }],
            "space-x-reverse": ["space-x-reverse"],
            "space-y": [{
                "space-y": [A]
            }],
            "space-y-reverse": ["space-y-reverse"],
            w: [{
                w: ["auto", "min", "max", "fit", de, t]
            }],
            "min-w": [{
                "min-w": ["min", "max", "fit", de, kt]
            }],
            "max-w": [{
                "max-w": ["0", "none", "full", "min", "max", "fit", "prose", {
                    screen: [un]
                }, un, de]
            }],
            h: [{
                h: [de, t, "auto", "min", "max", "fit"]
            }],
            "min-h": [{
                "min-h": ["min", "max", "fit", de, kt]
            }],
            "max-h": [{
                "max-h": [de, t, "min", "max", "fit"]
            }],
            "font-size": [{
                text: ["base", un, hl]
            }],
            "font-smoothing": ["antialiased", "subpixel-antialiased"],
            "font-style": ["italic", "not-italic"],
            "font-weight": [{
                font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", _i]
            }],
            "font-family": [{
                font: [Xr]
            }],
            "fvn-normal": ["normal-nums"],
            "fvn-ordinal": ["ordinal"],
            "fvn-slashed-zero": ["slashed-zero"],
            "fvn-figure": ["lining-nums", "oldstyle-nums"],
            "fvn-spacing": ["proportional-nums", "tabular-nums"],
            "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
            tracking: [{
                tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", de]
            }],
            "line-clamp": [{
                "line-clamp": ["none", zn, _i]
            }],
            leading: [{
                leading: ["none", "tight", "snug", "normal", "relaxed", "loose", de, kt]
            }],
            "list-image": [{
                "list-image": ["none", de]
            }],
            "list-style-type": [{
                list: ["none", "disc", "decimal", de]
            }],
            "list-style-position": [{
                list: ["inside", "outside"]
            }],
            "placeholder-color": [{
                placeholder: [e]
            }],
            "placeholder-opacity": [{
                "placeholder-opacity": [h]
            }],
            "text-alignment": [{
                text: ["left", "center", "right", "justify", "start", "end"]
            }],
            "text-color": [{
                text: [e]
            }],
            "text-opacity": [{
                "text-opacity": [h]
            }],
            "text-decoration": ["underline", "overline", "line-through", "no-underline"],
            "text-decoration-style": [{
                decoration: [].concat(J(), ["wavy"])
            }],
            "text-decoration-thickness": [{
                decoration: ["auto", "from-font", kt]
            }],
            "underline-offset": [{
                "underline-offset": ["auto", de, kt]
            }],
            "text-decoration-color": [{
                decoration: [e]
            }],
            "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
            "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
            indent: [{
                indent: M()
            }],
            "vertical-align": [{
                align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", de]
            }],
            whitespace: [{
                whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
            }],
            break: [{
                break: ["normal", "words", "all", "keep"]
            }],
            hyphens: [{
                hyphens: ["none", "manual", "auto"]
            }],
            content: [{
                content: ["none", de]
            }],
            "bg-attachment": [{
                bg: ["fixed", "local", "scroll"]
            }],
            "bg-clip": [{
                "bg-clip": ["border", "padding", "content", "text"]
            }],
            "bg-opacity": [{
                "bg-opacity": [h]
            }],
            "bg-origin": [{
                "bg-origin": ["border", "padding", "content"]
            }],
            "bg-position": [{
                bg: [].concat(te(), [VS])
            }],
            "bg-repeat": [{
                bg: ["no-repeat", {
                    repeat: ["", "x", "y", "round", "space"]
                }]
            }],
            "bg-size": [{
                bg: ["auto", "cover", "contain", $S]
            }],
            "bg-image": [{
                bg: ["none", {
                    "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                }, HS]
            }],
            "bg-color": [{
                bg: [e]
            }],
            "gradient-from-pos": [{
                from: [v]
            }],
            "gradient-via-pos": [{
                via: [v]
            }],
            "gradient-to-pos": [{
                to: [v]
            }],
            "gradient-from": [{
                from: [p]
            }],
            "gradient-via": [{
                via: [p]
            }],
            "gradient-to": [{
                to: [p]
            }],
            rounded: [{
                rounded: [i]
            }],
            "rounded-s": [{
                "rounded-s": [i]
            }],
            "rounded-e": [{
                "rounded-e": [i]
            }],
            "rounded-t": [{
                "rounded-t": [i]
            }],
            "rounded-r": [{
                "rounded-r": [i]
            }],
            "rounded-b": [{
                "rounded-b": [i]
            }],
            "rounded-l": [{
                "rounded-l": [i]
            }],
            "rounded-ss": [{
                "rounded-ss": [i]
            }],
            "rounded-se": [{
                "rounded-se": [i]
            }],
            "rounded-ee": [{
                "rounded-ee": [i]
            }],
            "rounded-es": [{
                "rounded-es": [i]
            }],
            "rounded-tl": [{
                "rounded-tl": [i]
            }],
            "rounded-tr": [{
                "rounded-tr": [i]
            }],
            "rounded-br": [{
                "rounded-br": [i]
            }],
            "rounded-bl": [{
                "rounded-bl": [i]
            }],
            "border-w": [{
                border: [s]
            }],
            "border-w-x": [{
                "border-x": [s]
            }],
            "border-w-y": [{
                "border-y": [s]
            }],
            "border-w-s": [{
                "border-s": [s]
            }],
            "border-w-e": [{
                "border-e": [s]
            }],
            "border-w-t": [{
                "border-t": [s]
            }],
            "border-w-r": [{
                "border-r": [s]
            }],
            "border-w-b": [{
                "border-b": [s]
            }],
            "border-w-l": [{
                "border-l": [s]
            }],
            "border-opacity": [{
                "border-opacity": [h]
            }],
            "border-style": [{
                border: [].concat(J(), ["hidden"])
            }],
            "divide-x": [{
                "divide-x": [s]
            }],
            "divide-x-reverse": ["divide-x-reverse"],
            "divide-y": [{
                "divide-y": [s]
            }],
            "divide-y-reverse": ["divide-y-reverse"],
            "divide-opacity": [{
                "divide-opacity": [h]
            }],
            "divide-style": [{
                divide: J()
            }],
            "border-color": [{
                border: [a]
            }],
            "border-color-x": [{
                "border-x": [a]
            }],
            "border-color-y": [{
                "border-y": [a]
            }],
            "border-color-t": [{
                "border-t": [a]
            }],
            "border-color-r": [{
                "border-r": [a]
            }],
            "border-color-b": [{
                "border-b": [a]
            }],
            "border-color-l": [{
                "border-l": [a]
            }],
            "divide-color": [{
                divide: [a]
            }],
            "outline-style": [{
                outline: [""].concat(J())
            }],
            "outline-offset": [{
                "outline-offset": [de, kt]
            }],
            "outline-w": [{
                outline: [kt]
            }],
            "outline-color": [{
                outline: [e]
            }],
            "ring-w": [{
                ring: K()
            }],
            "ring-w-inset": ["ring-inset"],
            "ring-color": [{
                ring: [e]
            }],
            "ring-opacity": [{
                "ring-opacity": [h]
            }],
            "ring-offset-w": [{
                "ring-offset": [kt]
            }],
            "ring-offset-color": [{
                "ring-offset": [e]
            }],
            shadow: [{
                shadow: ["", "inner", "none", un, US]
            }],
            "shadow-color": [{
                shadow: [Xr]
            }],
            opacity: [{
                opacity: [h]
            }],
            "mix-blend": [{
                "mix-blend": ae()
            }],
            "bg-blend": [{
                "bg-blend": ae()
            }],
            filter: [{
                filter: ["", "none"]
            }],
            blur: [{
                blur: [n]
            }],
            brightness: [{
                brightness: [r]
            }],
            contrast: [{
                contrast: [l]
            }],
            "drop-shadow": [{
                "drop-shadow": ["", "none", un, de]
            }],
            grayscale: [{
                grayscale: [c]
            }],
            "hue-rotate": [{
                "hue-rotate": [u]
            }],
            invert: [{
                invert: [f]
            }],
            saturate: [{
                saturate: [m]
            }],
            sepia: [{
                sepia: [C]
            }],
            "backdrop-filter": [{
                "backdrop-filter": ["", "none"]
            }],
            "backdrop-blur": [{
                "backdrop-blur": [n]
            }],
            "backdrop-brightness": [{
                "backdrop-brightness": [r]
            }],
            "backdrop-contrast": [{
                "backdrop-contrast": [l]
            }],
            "backdrop-grayscale": [{
                "backdrop-grayscale": [c]
            }],
            "backdrop-hue-rotate": [{
                "backdrop-hue-rotate": [u]
            }],
            "backdrop-invert": [{
                "backdrop-invert": [f]
            }],
            "backdrop-opacity": [{
                "backdrop-opacity": [h]
            }],
            "backdrop-saturate": [{
                "backdrop-saturate": [m]
            }],
            "backdrop-sepia": [{
                "backdrop-sepia": [C]
            }],
            "border-collapse": [{
                border: ["collapse", "separate"]
            }],
            "border-spacing": [{
                "border-spacing": [o]
            }],
            "border-spacing-x": [{
                "border-spacing-x": [o]
            }],
            "border-spacing-y": [{
                "border-spacing-y": [o]
            }],
            "table-layout": [{
                table: ["auto", "fixed"]
            }],
            caption: [{
                caption: ["top", "bottom"]
            }],
            transition: [{
                transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", de]
            }],
            duration: [{
                duration: Ie()
            }],
            ease: [{
                ease: ["linear", "in", "out", "in-out", de]
            }],
            delay: [{
                delay: Ie()
            }],
            animate: [{
                animate: ["none", "spin", "ping", "pulse", "bounce", de]
            }],
            transform: [{
                transform: ["", "gpu", "none"]
            }],
            scale: [{
                scale: [y]
            }],
            "scale-x": [{
                "scale-x": [y]
            }],
            "scale-y": [{
                "scale-y": [y]
            }],
            rotate: [{
                rotate: [Yr, de]
            }],
            "translate-x": [{
                "translate-x": [R]
            }],
            "translate-y": [{
                "translate-y": [R]
            }],
            "skew-x": [{
                "skew-x": [S]
            }],
            "skew-y": [{
                "skew-y": [S]
            }],
            "transform-origin": [{
                origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", de]
            }],
            accent: [{
                accent: ["auto", e]
            }],
            appearance: ["appearance-none"],
            cursor: [{
                cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", de]
            }],
            "caret-color": [{
                caret: [e]
            }],
            "pointer-events": [{
                "pointer-events": ["none", "auto"]
            }],
            resize: [{
                resize: ["none", "y", "x", ""]
            }],
            "scroll-behavior": [{
                scroll: ["auto", "smooth"]
            }],
            "scroll-m": [{
                "scroll-m": M()
            }],
            "scroll-mx": [{
                "scroll-mx": M()
            }],
            "scroll-my": [{
                "scroll-my": M()
            }],
            "scroll-ms": [{
                "scroll-ms": M()
            }],
            "scroll-me": [{
                "scroll-me": M()
            }],
            "scroll-mt": [{
                "scroll-mt": M()
            }],
            "scroll-mr": [{
                "scroll-mr": M()
            }],
            "scroll-mb": [{
                "scroll-mb": M()
            }],
            "scroll-ml": [{
                "scroll-ml": M()
            }],
            "scroll-p": [{
                "scroll-p": M()
            }],
            "scroll-px": [{
                "scroll-px": M()
            }],
            "scroll-py": [{
                "scroll-py": M()
            }],
            "scroll-ps": [{
                "scroll-ps": M()
            }],
            "scroll-pe": [{
                "scroll-pe": M()
            }],
            "scroll-pt": [{
                "scroll-pt": M()
            }],
            "scroll-pr": [{
                "scroll-pr": M()
            }],
            "scroll-pb": [{
                "scroll-pb": M()
            }],
            "scroll-pl": [{
                "scroll-pl": M()
            }],
            "snap-align": [{
                snap: ["start", "end", "center", "align-none"]
            }],
            "snap-stop": [{
                snap: ["normal", "always"]
            }],
            "snap-type": [{
                snap: ["none", "x", "y", "both"]
            }],
            "snap-strictness": [{
                snap: ["mandatory", "proximity"]
            }],
            touch: [{
                touch: ["auto", "none", "pinch-zoom", "manipulation", {
                    pan: ["x", "left", "right", "y", "up", "down"]
                }]
            }],
            select: [{
                select: ["none", "text", "all", "auto"]
            }],
            "will-change": [{
                "will-change": ["auto", "scroll", "contents", "transform", de]
            }],
            fill: [{
                fill: [e, "none"]
            }],
            "stroke-w": [{
                stroke: [kt, _i]
            }],
            stroke: [{
                stroke: [e, "none"]
            }],
            sr: ["sr-only", "not-sr-only"]
        },
        conflictingClassGroups: {
            overflow: ["overflow-x", "overflow-y"],
            overscroll: ["overscroll-x", "overscroll-y"],
            inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
            "inset-x": ["right", "left"],
            "inset-y": ["top", "bottom"],
            flex: ["basis", "grow", "shrink"],
            gap: ["gap-x", "gap-y"],
            p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
            px: ["pr", "pl"],
            py: ["pt", "pb"],
            m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
            mx: ["mr", "ml"],
            my: ["mt", "mb"],
            "font-size": ["leading"],
            "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
            "fvn-ordinal": ["fvn-normal"],
            "fvn-slashed-zero": ["fvn-normal"],
            "fvn-figure": ["fvn-normal"],
            "fvn-spacing": ["fvn-normal"],
            "fvn-fraction": ["fvn-normal"],
            rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
            "rounded-s": ["rounded-ss", "rounded-es"],
            "rounded-e": ["rounded-se", "rounded-ee"],
            "rounded-t": ["rounded-tl", "rounded-tr"],
            "rounded-r": ["rounded-tr", "rounded-br"],
            "rounded-b": ["rounded-br", "rounded-bl"],
            "rounded-l": ["rounded-tl", "rounded-bl"],
            "border-spacing": ["border-spacing-x", "border-spacing-y"],
            "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
            "border-w-x": ["border-w-r", "border-w-l"],
            "border-w-y": ["border-w-t", "border-w-b"],
            "border-color": ["border-color-t", "border-color-r", "border-color-b", "border-color-l"],
            "border-color-x": ["border-color-r", "border-color-l"],
            "border-color-y": ["border-color-t", "border-color-b"],
            "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
            "scroll-mx": ["scroll-mr", "scroll-ml"],
            "scroll-my": ["scroll-mt", "scroll-mb"],
            "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
            "scroll-px": ["scroll-pr", "scroll-pl"],
            "scroll-py": ["scroll-pt", "scroll-pb"]
        },
        conflictingClassGroupModifiers: {
            "font-size": ["leading"]
        }
    }
}

function zS(e, t) {
    for (var n in t) ig(e, n, t[n]);
    return e
}
var qS = Object.prototype.hasOwnProperty,
    YS = new Set(["string", "number", "boolean"]);

function ig(e, t, n) {
    if (!qS.call(e, t) || YS.has(typeof n) || n === null) {
        e[t] = n;
        return
    }
    if (Array.isArray(n) && Array.isArray(e[t])) {
        e[t] = e[t].concat(n);
        return
    }
    if (typeof n == "object" && typeof e[t] == "object") {
        if (e[t] === null) {
            e[t] = n;
            return
        }
        for (var r in n) ig(e[t], r, n[r])
    }
}

function XS(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
    return typeof e == "function" ? pl.apply(void 0, [ml, e].concat(n)) : pl.apply(void 0, [function() {
        return zS(ml(), e)
    }].concat(n))
}
var Or = pl(ml);

function QS(e, t) {
    const n = { ...e
    };
    for (const r of t) delete n[r];
    return n
}

function ZS(e, t, n) {
    typeof t == "string" && (t = t.split(".").map(a => {
        const i = Number(a);
        return isNaN(i) ? a : i
    }));
    let r = e;
    for (const a of t) {
        if (r == null) return n;
        r = r[a]
    }
    return r !== void 0 ? r : n
}
const eT = XS({
        classGroups: {
            icons: [e => /^i-/.test(e)]
        }
    }),
    tT = wc((e, t, n, r) => {
        if (r !== "default" && typeof e[t] == "string" && typeof n == "string" && e[t] && n) return e[t] = eT(e[t], n), !0
    });

function ei(e, ...t) {
    return e === "override" ? Eo({}, ...t) : tT({}, ...t)
}

function Zf(e) {
    const t = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    e = e.replace(t, function(r, a, i, o) {
        return a + a + i + i + o + o
    });
    const n = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
    return n ? `${parseInt(n[1],16)} ${parseInt(n[2],16)} ${parseInt(n[3],16)}` : null
}

function kP(e) {
    const t = parseFloat(e);
    return isNaN(t) ? e : t
}
const nT = "inherit",
    rT = "currentColor",
    aT = "transparent",
    iT = "#000",
    oT = "#fff",
    sT = {
        50: "#f8fafc",
        100: "#f1f5f9",
        200: "#e2e8f0",
        300: "#cbd5e1",
        400: "#94a3b8",
        500: "#64748b",
        600: "#475569",
        700: "#334155",
        800: "#1e293b",
        900: "#0f172a",
        950: "#020617"
    },
    lT = {
        50: "rgb(var(--color-gray-50) / <alpha-value>)",
        100: "rgb(var(--color-gray-100) / <alpha-value>)",
        200: "rgb(var(--color-gray-200) / <alpha-value>)",
        300: "rgb(var(--color-gray-300) / <alpha-value>)",
        400: "rgb(var(--color-gray-400) / <alpha-value>)",
        500: "rgb(var(--color-gray-500) / <alpha-value>)",
        600: "rgb(var(--color-gray-600) / <alpha-value>)",
        700: "rgb(var(--color-gray-700) / <alpha-value>)",
        800: "rgb(var(--color-gray-800) / <alpha-value>)",
        900: "rgb(var(--color-gray-900) / <alpha-value>)",
        950: "rgb(var(--color-gray-950) / <alpha-value>)"
    },
    cT = {
        50: "#fafafa",
        100: "#f4f4f5",
        200: "#e4e4e7",
        300: "#d4d4d8",
        400: "#a1a1aa",
        500: "#71717a",
        600: "#52525b",
        700: "#3f3f46",
        800: "#27272a",
        900: "#18181b",
        950: "#09090b"
    },
    uT = {
        50: "#fafafa",
        100: "#f5f5f5",
        200: "#e5e5e5",
        300: "#d4d4d4",
        400: "#a3a3a3",
        500: "#737373",
        600: "#525252",
        700: "#404040",
        800: "#262626",
        900: "#171717",
        950: "#0a0a0a"
    },
    fT = {
        50: "#fafaf9",
        100: "#f5f5f4",
        200: "#e7e5e4",
        300: "#d6d3d1",
        400: "#a8a29e",
        500: "#78716c",
        600: "#57534e",
        700: "#44403c",
        800: "#292524",
        900: "#1c1917",
        950: "#0c0a09"
    },
    dT = {
        50: "#fef2f2",
        100: "#fee2e2",
        200: "#fecaca",
        300: "#fca5a5",
        400: "#f87171",
        500: "#ef4444",
        600: "#dc2626",
        700: "#b91c1c",
        800: "#991b1b",
        900: "#7f1d1d",
        950: "#450a0a"
    },
    pT = {
        50: "#fff7ed",
        100: "#ffedd5",
        200: "#fed7aa",
        300: "#fdba74",
        400: "#fb923c",
        500: "#f97316",
        600: "#ea580c",
        700: "#c2410c",
        800: "#9a3412",
        900: "#7c2d12",
        950: "#431407"
    },
    hT = {
        50: "#fffbeb",
        100: "#fef3c7",
        200: "#fde68a",
        300: "#fcd34d",
        400: "#fbbf24",
        500: "#f59e0b",
        600: "#d97706",
        700: "#b45309",
        800: "#92400e",
        900: "#78350f",
        950: "#451a03"
    },
    mT = {
        50: "#fefce8",
        100: "#fef9c3",
        200: "#fef08a",
        300: "#fde047",
        400: "#facc15",
        500: "#eab308",
        600: "#ca8a04",
        700: "#a16207",
        800: "#854d0e",
        900: "#713f12",
        950: "#422006"
    },
    gT = {
        50: "#f7fee7",
        100: "#ecfccb",
        200: "#d9f99d",
        300: "#bef264",
        400: "#a3e635",
        500: "#84cc16",
        600: "#65a30d",
        700: "#4d7c0f",
        800: "#3f6212",
        900: "#365314",
        950: "#1a2e05"
    },
    yT = {
        50: "#f0fdf4",
        100: "#dcfce7",
        200: "#bbf7d0",
        300: "#86efac",
        400: "#4ade80",
        500: "#22c55e",
        600: "#16a34a",
        700: "#15803d",
        800: "#166534",
        900: "#14532d",
        950: "#052e16"
    },
    bT = {
        50: "#ecfdf5",
        100: "#d1fae5",
        200: "#a7f3d0",
        300: "#6ee7b7",
        400: "#34d399",
        500: "#10b981",
        600: "#059669",
        700: "#047857",
        800: "#065f46",
        900: "#064e3b",
        950: "#022c22"
    },
    vT = {
        50: "#f0fdfa",
        100: "#ccfbf1",
        200: "#99f6e4",
        300: "#5eead4",
        400: "#2dd4bf",
        500: "#14b8a6",
        600: "#0d9488",
        700: "#0f766e",
        800: "#115e59",
        900: "#134e4a",
        950: "#042f2e"
    },
    _T = {
        50: "#ecfeff",
        100: "#cffafe",
        200: "#a5f3fc",
        300: "#67e8f9",
        400: "#22d3ee",
        500: "#06b6d4",
        600: "#0891b2",
        700: "#0e7490",
        800: "#155e75",
        900: "#164e63",
        950: "#083344"
    },
    wT = {
        50: "#f0f9ff",
        100: "#e0f2fe",
        200: "#bae6fd",
        300: "#7dd3fc",
        400: "#38bdf8",
        500: "#0ea5e9",
        600: "#0284c7",
        700: "#0369a1",
        800: "#075985",
        900: "#0c4a6e",
        950: "#082f49"
    },
    ET = {
        50: "#eff6ff",
        100: "#dbeafe",
        200: "#bfdbfe",
        300: "#93c5fd",
        400: "#60a5fa",
        500: "#3b82f6",
        600: "#2563eb",
        700: "#1d4ed8",
        800: "#1e40af",
        900: "#1e3a8a",
        950: "#172554"
    },
    CT = {
        50: "#eef2ff",
        100: "#e0e7ff",
        200: "#c7d2fe",
        300: "#a5b4fc",
        400: "#818cf8",
        500: "#6366f1",
        600: "#4f46e5",
        700: "#4338ca",
        800: "#3730a3",
        900: "#312e81",
        950: "#1e1b4b"
    },
    AT = {
        50: "#f5f3ff",
        100: "#ede9fe",
        200: "#ddd6fe",
        300: "#c4b5fd",
        400: "#a78bfa",
        500: "#8b5cf6",
        600: "#7c3aed",
        700: "#6d28d9",
        800: "#5b21b6",
        900: "#4c1d95",
        950: "#2e1065"
    },
    LT = {
        50: "#faf5ff",
        100: "#f3e8ff",
        200: "#e9d5ff",
        300: "#d8b4fe",
        400: "#c084fc",
        500: "#a855f7",
        600: "#9333ea",
        700: "#7e22ce",
        800: "#6b21a8",
        900: "#581c87",
        950: "#3b0764"
    },
    ST = {
        50: "#fdf4ff",
        100: "#fae8ff",
        200: "#f5d0fe",
        300: "#f0abfc",
        400: "#e879f9",
        500: "#d946ef",
        600: "#c026d3",
        700: "#a21caf",
        800: "#86198f",
        900: "#701a75",
        950: "#4a044e"
    },
    TT = {
        50: "#fdf2f8",
        100: "#fce7f3",
        200: "#fbcfe8",
        300: "#f9a8d4",
        400: "#f472b6",
        500: "#ec4899",
        600: "#db2777",
        700: "#be185d",
        800: "#9d174d",
        900: "#831843",
        950: "#500724"
    },
    kT = {
        50: "#fff1f2",
        100: "#ffe4e6",
        200: "#fecdd3",
        300: "#fda4af",
        400: "#fb7185",
        500: "#f43f5e",
        600: "#e11d48",
        700: "#be123c",
        800: "#9f1239",
        900: "#881337",
        950: "#4c0519"
    },
    RT = {
        50: "rgb(var(--color-primary-50) / <alpha-value>)",
        100: "rgb(var(--color-primary-100) / <alpha-value>)",
        200: "rgb(var(--color-primary-200) / <alpha-value>)",
        300: "rgb(var(--color-primary-300) / <alpha-value>)",
        400: "rgb(var(--color-primary-400) / <alpha-value>)",
        500: "rgb(var(--color-primary-500) / <alpha-value>)",
        600: "rgb(var(--color-primary-600) / <alpha-value>)",
        700: "rgb(var(--color-primary-700) / <alpha-value>)",
        800: "rgb(var(--color-primary-800) / <alpha-value>)",
        900: "rgb(var(--color-primary-900) / <alpha-value>)",
        950: "rgb(var(--color-primary-950) / <alpha-value>)",
        DEFAULT: "rgb(var(--color-primary-DEFAULT) / <alpha-value>)"
    },
    OT = {
        50: "#f9fafb",
        100: "#f3f4f6",
        200: "#e5e7eb",
        300: "#d1d5db",
        400: "#9ca3af",
        500: "#6b7280",
        600: "#4b5563",
        700: "#374151",
        800: "#1f2937",
        900: "#111827",
        950: "#030712"
    },
    wi = {
        inherit: nT,
        current: rT,
        transparent: aT,
        black: iT,
        white: oT,
        slate: sT,
        gray: lT,
        zinc: cT,
        neutral: uT,
        stone: fT,
        red: dT,
        orange: pT,
        amber: hT,
        yellow: mT,
        lime: gT,
        green: yT,
        emerald: bT,
        teal: vT,
        cyan: _T,
        sky: wT,
        blue: ET,
        indigo: CT,
        violet: AT,
        purple: LT,
        fuchsia: ST,
        pink: TT,
        rose: kT,
        primary: RT,
        cool: OT
    },
    MT = Qe(() => {
        const e = Wa(),
            t = ge(),
            n = W(() => {
                const a = wi[e.ui.primary],
                    i = wi[e.ui.gray];
                return a || console.warn(`[@nuxt/ui] Primary color '${e.ui.primary}' not found in Tailwind config`), i || console.warn(`[@nuxt/ui] Gray color '${e.ui.gray}' not found in Tailwind config`), `:root {
${Object.entries(a||wi.green).map(([o,s])=>`--color-primary-${o}: ${Zf(s)};`).join(`
`)}
--color-primary-DEFAULT: var(--color-primary-500);

${Object.entries(i||wi.cool).map(([o,s])=>`--color-gray-${o}: ${Zf(s)};`).join(`
`)}
}

.dark {
  --color-primary-DEFAULT: var(--color-primary-400);
}
`
            }),
            r = {
                style: [{
                    innerHTML: () => n.value,
                    tagPriority: -2,
                    id: "nuxt-ui-colors"
                }]
            };
        if (t.isHydrating && !t.payload.serverRendered) {
            const a = document.createElement("style");
            a.innerHTML = n.value, a.setAttribute("data-nuxt-ui-colors", ""), document.head.appendChild(a), r.script = [{
                innerHTML: "document.head.removeChild(document.querySelector('[data-nuxt-ui-colors]'))"
            }]
        }
        wo(r)
    }),
    PT = Qe(() => {});
/*!
 * shared v9.8.0
 * (c) 2023 kazuya kawaguchi
 * Released under the MIT License.
 */
const gl = typeof window < "u",
    On = (e, t = !1) => t ? Symbol.for(e) : Symbol(e),
    xT = (e, t, n) => IT({
        l: e,
        k: t,
        s: n
    }),
    IT = e => JSON.stringify(e).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027"),
    ze = e => typeof e == "number" && isFinite(e),
    DT = e => sg(e) === "[object Date]",
    eo = e => sg(e) === "[object RegExp]",
    Oo = e => me(e) && Object.keys(e).length === 0,
    Ye = Object.assign;
let ed;
const jc = () => ed || (ed = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

function td(e) {
    return e.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
}
const NT = Object.prototype.hasOwnProperty;

function Pa(e, t) {
    return NT.call(e, t)
}
const He = Array.isArray,
    Se = e => typeof e == "function",
    Y = e => typeof e == "string",
    De = e => typeof e == "boolean",
    be = e => e !== null && typeof e == "object",
    FT = e => be(e) && Se(e.then) && Se(e.catch),
    og = Object.prototype.toString,
    sg = e => og.call(e),
    me = e => {
        if (!be(e)) return !1;
        const t = Object.getPrototypeOf(e);
        return t === null || t.constructor === Object
    },
    BT = e => e == null ? "" : He(e) || me(e) && e.toString === og ? JSON.stringify(e, null, 2) : String(e);

function $c(e, t = "") {
    return e.reduce((n, r, a) => a === 0 ? n + r : n + t + r, "")
}

function Vc(e) {
    let t = e;
    return () => ++t
}

function jT(e, t) {
    typeof console < "u" && (console.warn("[intlify] " + e), t && console.warn(t.stack))
}
const Ei = e => !be(e) || He(e);

function An(e, t) {
    if (Ei(e) || Ei(t)) throw new Error("Invalid value");
    for (const n in e) Pa(e, n) && (Ei(e[n]) || Ei(t[n]) ? t[n] = e[n] : An(e[n], t[n]))
}
/*!
 * message-compiler v9.8.0
 * (c) 2023 kazuya kawaguchi
 * Released under the MIT License.
 */
function $T(e, t, n) {
    return {
        line: e,
        column: t,
        offset: n
    }
}

function yl(e, t, n) {
    const r = {
        start: e,
        end: t
    };
    return n != null && (r.source = n), r
}
const ve = {
    EXPECTED_TOKEN: 1,
    INVALID_TOKEN_IN_PLACEHOLDER: 2,
    UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
    UNKNOWN_ESCAPE_SEQUENCE: 4,
    INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
    UNBALANCED_CLOSING_BRACE: 6,
    UNTERMINATED_CLOSING_BRACE: 7,
    EMPTY_PLACEHOLDER: 8,
    NOT_ALLOW_NEST_PLACEHOLDER: 9,
    INVALID_LINKED_FORMAT: 10,
    MUST_HAVE_MESSAGES_IN_PLURAL: 11,
    UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
    UNEXPECTED_EMPTY_LINKED_KEY: 13,
    UNEXPECTED_LEXICAL_ANALYSIS: 14,
    UNHANDLED_CODEGEN_NODE_TYPE: 15,
    UNHANDLED_MINIFIER_NODE_TYPE: 16,
    __EXTEND_POINT__: 17
};

function Mo(e, t, n = {}) {
    const {
        domain: r,
        messages: a,
        args: i
    } = n, o = e, s = new SyntaxError(String(o));
    return s.code = e, t && (s.location = t), s.domain = r, s
}

function VT(e) {
    throw e
}
const Wt = " ",
    HT = "\r",
    rt = `
`,
    KT = String.fromCharCode(8232),
    UT = String.fromCharCode(8233);

function JT(e) {
    const t = e;
    let n = 0,
        r = 1,
        a = 1,
        i = 0;
    const o = A => t[A] === HT && t[A + 1] === rt,
        s = A => t[A] === rt,
        l = A => t[A] === UT,
        c = A => t[A] === KT,
        u = A => o(A) || s(A) || l(A) || c(A),
        f = () => n,
        d = () => r,
        p = () => a,
        v = () => i,
        E = A => o(A) || l(A) || c(A) ? rt : t[A],
        w = () => E(n),
        h = () => E(n + i);

    function b() {
        return i = 0, u(n) && (r++, a = 0), o(n) && n++, n++, a++, t[n]
    }

    function m() {
        return o(n + i) && i++, i++, t[n + i]
    }

    function y() {
        n = 0, r = 1, a = 1, i = 0
    }

    function C(A = 0) {
        i = A
    }

    function S() {
        const A = n + i;
        for (; A !== n;) b();
        i = 0
    }
    return {
        index: f,
        line: d,
        column: p,
        peekOffset: v,
        charAt: E,
        currentChar: w,
        currentPeek: h,
        next: b,
        peek: m,
        reset: y,
        resetPeek: C,
        skipToPeek: S
    }
}
const fn = void 0,
    GT = ".",
    nd = "'",
    WT = "tokenizer";

function zT(e, t = {}) {
    const n = t.location !== !1,
        r = JT(e),
        a = () => r.index(),
        i = () => $T(r.line(), r.column(), r.index()),
        o = i(),
        s = a(),
        l = {
            currentType: 14,
            offset: s,
            startLoc: o,
            endLoc: o,
            lastType: 14,
            lastOffset: s,
            lastStartLoc: o,
            lastEndLoc: o,
            braceNest: 0,
            inLinked: !1,
            text: ""
        },
        c = () => l,
        {
            onError: u
        } = t;

    function f(g, _, T, ...P) {
        const F = c();
        if (_.column += T, _.offset += T, u) {
            const $ = n ? yl(F.startLoc, _) : null,
                H = Mo(g, $, {
                    domain: WT,
                    args: P
                });
            u(H)
        }
    }

    function d(g, _, T) {
        g.endLoc = i(), g.currentType = _;
        const P = {
            type: _
        };
        return n && (P.loc = yl(g.startLoc, g.endLoc)), T != null && (P.value = T), P
    }
    const p = g => d(g, 14);

    function v(g, _) {
        return g.currentChar() === _ ? (g.next(), _) : (f(ve.EXPECTED_TOKEN, i(), 0, _), "")
    }

    function E(g) {
        let _ = "";
        for (; g.currentPeek() === Wt || g.currentPeek() === rt;) _ += g.currentPeek(), g.peek();
        return _
    }

    function w(g) {
        const _ = E(g);
        return g.skipToPeek(), _
    }

    function h(g) {
        if (g === fn) return !1;
        const _ = g.charCodeAt(0);
        return _ >= 97 && _ <= 122 || _ >= 65 && _ <= 90 || _ === 95
    }

    function b(g) {
        if (g === fn) return !1;
        const _ = g.charCodeAt(0);
        return _ >= 48 && _ <= 57
    }

    function m(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 2) return !1;
        E(g);
        const P = h(g.currentPeek());
        return g.resetPeek(), P
    }

    function y(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 2) return !1;
        E(g);
        const P = g.currentPeek() === "-" ? g.peek() : g.currentPeek(),
            F = b(P);
        return g.resetPeek(), F
    }

    function C(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 2) return !1;
        E(g);
        const P = g.currentPeek() === nd;
        return g.resetPeek(), P
    }

    function S(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 8) return !1;
        E(g);
        const P = g.currentPeek() === ".";
        return g.resetPeek(), P
    }

    function A(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 9) return !1;
        E(g);
        const P = h(g.currentPeek());
        return g.resetPeek(), P
    }

    function R(g, _) {
        const {
            currentType: T
        } = _;
        if (!(T === 8 || T === 12)) return !1;
        E(g);
        const P = g.currentPeek() === ":";
        return g.resetPeek(), P
    }

    function O(g, _) {
        const {
            currentType: T
        } = _;
        if (T !== 10) return !1;
        const P = () => {
                const $ = g.currentPeek();
                return $ === "{" ? h(g.peek()) : $ === "@" || $ === "%" || $ === "|" || $ === ":" || $ === "." || $ === Wt || !$ ? !1 : $ === rt ? (g.peek(), P()) : h($)
            },
            F = P();
        return g.resetPeek(), F
    }

    function N(g) {
        E(g);
        const _ = g.currentPeek() === "|";
        return g.resetPeek(), _
    }

    function x(g) {
        const _ = E(g),
            T = g.currentPeek() === "%" && g.peek() === "{";
        return g.resetPeek(), {
            isModulo: T,
            hasSpace: _.length > 0
        }
    }

    function M(g, _ = !0) {
        const T = (F = !1, $ = "", H = !1) => {
                const U = g.currentPeek();
                return U === "{" ? $ === "%" ? !1 : F : U === "@" || !U ? $ === "%" ? !0 : F : U === "%" ? (g.peek(), T(F, "%", !0)) : U === "|" ? $ === "%" || H ? !0 : !($ === Wt || $ === rt) : U === Wt ? (g.peek(), T(!0, Wt, H)) : U === rt ? (g.peek(), T(!0, rt, H)) : !0
            },
            P = T();
        return _ && g.resetPeek(), P
    }

    function K(g, _) {
        const T = g.currentChar();
        return T === fn ? fn : _(T) ? (g.next(), T) : null
    }

    function ne(g) {
        return K(g, T => {
            const P = T.charCodeAt(0);
            return P >= 97 && P <= 122 || P >= 65 && P <= 90 || P >= 48 && P <= 57 || P === 95 || P === 36
        })
    }

    function te(g) {
        return K(g, T => {
            const P = T.charCodeAt(0);
            return P >= 48 && P <= 57
        })
    }

    function J(g) {
        return K(g, T => {
            const P = T.charCodeAt(0);
            return P >= 48 && P <= 57 || P >= 65 && P <= 70 || P >= 97 && P <= 102
        })
    }

    function ae(g) {
        let _ = "",
            T = "";
        for (; _ = te(g);) T += _;
        return T
    }

    function X(g) {
        w(g);
        const _ = g.currentChar();
        return _ !== "%" && f(ve.EXPECTED_TOKEN, i(), 0, _), g.next(), "%"
    }

    function Ce(g) {
        let _ = "";
        for (;;) {
            const T = g.currentChar();
            if (T === "{" || T === "}" || T === "@" || T === "|" || !T) break;
            if (T === "%")
                if (M(g)) _ += T, g.next();
                else break;
            else if (T === Wt || T === rt)
                if (M(g)) _ += T, g.next();
                else {
                    if (N(g)) break;
                    _ += T, g.next()
                }
            else _ += T, g.next()
        }
        return _
    }

    function Ze(g) {
        w(g);
        let _ = "",
            T = "";
        for (; _ = ne(g);) T += _;
        return g.currentChar() === fn && f(ve.UNTERMINATED_CLOSING_BRACE, i(), 0), T
    }

    function je(g) {
        w(g);
        let _ = "";
        return g.currentChar() === "-" ? (g.next(), _ += `-${ae(g)}`) : _ += ae(g), g.currentChar() === fn && f(ve.UNTERMINATED_CLOSING_BRACE, i(), 0), _
    }

    function Ie(g) {
        w(g), v(g, "'");
        let _ = "",
            T = "";
        const P = $ => $ !== nd && $ !== rt;
        for (; _ = K(g, P);) _ === "\\" ? T += Me(g) : T += _;
        const F = g.currentChar();
        return F === rt || F === fn ? (f(ve.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, i(), 0), F === rt && (g.next(), v(g, "'")), T) : (v(g, "'"), T)
    }

    function Me(g) {
        const _ = g.currentChar();
        switch (_) {
            case "\\":
            case "'":
                return g.next(), `\\${_}`;
            case "u":
                return Tt(g, _, 4);
            case "U":
                return Tt(g, _, 6);
            default:
                return f(ve.UNKNOWN_ESCAPE_SEQUENCE, i(), 0, _), ""
        }
    }

    function Tt(g, _, T) {
        v(g, _);
        let P = "";
        for (let F = 0; F < T; F++) {
            const $ = J(g);
            if (!$) {
                f(ve.INVALID_UNICODE_ESCAPE_SEQUENCE, i(), 0, `\\${_}${P}${g.currentChar()}`);
                break
            }
            P += $
        }
        return `\\${_}${P}`
    }

    function xn(g) {
        w(g);
        let _ = "",
            T = "";
        const P = F => F !== "{" && F !== "}" && F !== Wt && F !== rt;
        for (; _ = K(g, P);) T += _;
        return T
    }

    function $e(g) {
        let _ = "",
            T = "";
        for (; _ = ne(g);) T += _;
        return T
    }

    function j(g) {
        const _ = (T = !1, P) => {
            const F = g.currentChar();
            return F === "{" || F === "%" || F === "@" || F === "|" || F === "(" || F === ")" || !F || F === Wt ? P : F === rt || F === GT ? (P += F, g.next(), _(T, P)) : (P += F, g.next(), _(!0, P))
        };
        return _(!1, "")
    }

    function q(g) {
        w(g);
        const _ = v(g, "|");
        return w(g), _
    }

    function G(g, _) {
        let T = null;
        switch (g.currentChar()) {
            case "{":
                return _.braceNest >= 1 && f(ve.NOT_ALLOW_NEST_PLACEHOLDER, i(), 0), g.next(), T = d(_, 2, "{"), w(g), _.braceNest++, T;
            case "}":
                return _.braceNest > 0 && _.currentType === 2 && f(ve.EMPTY_PLACEHOLDER, i(), 0), g.next(), T = d(_, 3, "}"), _.braceNest--, _.braceNest > 0 && w(g), _.inLinked && _.braceNest === 0 && (_.inLinked = !1), T;
            case "@":
                return _.braceNest > 0 && f(ve.UNTERMINATED_CLOSING_BRACE, i(), 0), T = ee(g, _) || p(_), _.braceNest = 0, T;
            default:
                let F = !0,
                    $ = !0,
                    H = !0;
                if (N(g)) return _.braceNest > 0 && f(ve.UNTERMINATED_CLOSING_BRACE, i(), 0), T = d(_, 1, q(g)), _.braceNest = 0, _.inLinked = !1, T;
                if (_.braceNest > 0 && (_.currentType === 5 || _.currentType === 6 || _.currentType === 7)) return f(ve.UNTERMINATED_CLOSING_BRACE, i(), 0), _.braceNest = 0, ue(g, _);
                if (F = m(g, _)) return T = d(_, 5, Ze(g)), w(g), T;
                if ($ = y(g, _)) return T = d(_, 6, je(g)), w(g), T;
                if (H = C(g, _)) return T = d(_, 7, Ie(g)), w(g), T;
                if (!F && !$ && !H) return T = d(_, 13, xn(g)), f(ve.INVALID_TOKEN_IN_PLACEHOLDER, i(), 0, T.value), w(g), T;
                break
        }
        return T
    }

    function ee(g, _) {
        const {
            currentType: T
        } = _;
        let P = null;
        const F = g.currentChar();
        switch ((T === 8 || T === 9 || T === 12 || T === 10) && (F === rt || F === Wt) && f(ve.INVALID_LINKED_FORMAT, i(), 0), F) {
            case "@":
                return g.next(), P = d(_, 8, "@"), _.inLinked = !0, P;
            case ".":
                return w(g), g.next(), d(_, 9, ".");
            case ":":
                return w(g), g.next(), d(_, 10, ":");
            default:
                return N(g) ? (P = d(_, 1, q(g)), _.braceNest = 0, _.inLinked = !1, P) : S(g, _) || R(g, _) ? (w(g), ee(g, _)) : A(g, _) ? (w(g), d(_, 12, $e(g))) : O(g, _) ? (w(g), F === "{" ? G(g, _) || P : d(_, 11, j(g))) : (T === 8 && f(ve.INVALID_LINKED_FORMAT, i(), 0), _.braceNest = 0, _.inLinked = !1, ue(g, _))
        }
    }

    function ue(g, _) {
        let T = {
            type: 14
        };
        if (_.braceNest > 0) return G(g, _) || p(_);
        if (_.inLinked) return ee(g, _) || p(_);
        switch (g.currentChar()) {
            case "{":
                return G(g, _) || p(_);
            case "}":
                return f(ve.UNBALANCED_CLOSING_BRACE, i(), 0), g.next(), d(_, 3, "}");
            case "@":
                return ee(g, _) || p(_);
            default:
                if (N(g)) return T = d(_, 1, q(g)), _.braceNest = 0, _.inLinked = !1, T;
                const {
                    isModulo: F,
                    hasSpace: $
                } = x(g);
                if (F) return $ ? d(_, 0, Ce(g)) : d(_, 4, X(g));
                if (M(g)) return d(_, 0, Ce(g));
                break
        }
        return T
    }

    function L() {
        const {
            currentType: g,
            offset: _,
            startLoc: T,
            endLoc: P
        } = l;
        return l.lastType = g, l.lastOffset = _, l.lastStartLoc = T, l.lastEndLoc = P, l.offset = a(), l.startLoc = i(), r.currentChar() === fn ? d(l, 14) : ue(r, l)
    }
    return {
        nextToken: L,
        currentOffset: a,
        currentPosition: i,
        context: c
    }
}
const qT = "parser",
    YT = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;

function XT(e, t, n) {
    switch (e) {
        case "\\\\":
            return "\\";
        case "\\'":
            return "'";
        default:
            {
                const r = parseInt(t || n, 16);
                return r <= 55295 || r >= 57344 ? String.fromCodePoint(r) : "�"
            }
    }
}

function QT(e = {}) {
    const t = e.location !== !1,
        {
            onError: n
        } = e;

    function r(h, b, m, y, ...C) {
        const S = h.currentPosition();
        if (S.offset += y, S.column += y, n) {
            const A = t ? yl(m, S) : null,
                R = Mo(b, A, {
                    domain: qT,
                    args: C
                });
            n(R)
        }
    }

    function a(h, b, m) {
        const y = {
            type: h
        };
        return t && (y.start = b, y.end = b, y.loc = {
            start: m,
            end: m
        }), y
    }

    function i(h, b, m, y) {
        y && (h.type = y), t && (h.end = b, h.loc && (h.loc.end = m))
    }

    function o(h, b) {
        const m = h.context(),
            y = a(3, m.offset, m.startLoc);
        return y.value = b, i(y, h.currentOffset(), h.currentPosition()), y
    }

    function s(h, b) {
        const m = h.context(),
            {
                lastOffset: y,
                lastStartLoc: C
            } = m,
            S = a(5, y, C);
        return S.index = parseInt(b, 10), h.nextToken(), i(S, h.currentOffset(), h.currentPosition()), S
    }

    function l(h, b) {
        const m = h.context(),
            {
                lastOffset: y,
                lastStartLoc: C
            } = m,
            S = a(4, y, C);
        return S.key = b, h.nextToken(), i(S, h.currentOffset(), h.currentPosition()), S
    }

    function c(h, b) {
        const m = h.context(),
            {
                lastOffset: y,
                lastStartLoc: C
            } = m,
            S = a(9, y, C);
        return S.value = b.replace(YT, XT), h.nextToken(), i(S, h.currentOffset(), h.currentPosition()), S
    }

    function u(h) {
        const b = h.nextToken(),
            m = h.context(),
            {
                lastOffset: y,
                lastStartLoc: C
            } = m,
            S = a(8, y, C);
        return b.type !== 12 ? (r(h, ve.UNEXPECTED_EMPTY_LINKED_MODIFIER, m.lastStartLoc, 0), S.value = "", i(S, y, C), {
            nextConsumeToken: b,
            node: S
        }) : (b.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, m.lastStartLoc, 0, Bt(b)), S.value = b.value || "", i(S, h.currentOffset(), h.currentPosition()), {
            node: S
        })
    }

    function f(h, b) {
        const m = h.context(),
            y = a(7, m.offset, m.startLoc);
        return y.value = b, i(y, h.currentOffset(), h.currentPosition()), y
    }

    function d(h) {
        const b = h.context(),
            m = a(6, b.offset, b.startLoc);
        let y = h.nextToken();
        if (y.type === 9) {
            const C = u(h);
            m.modifier = C.node, y = C.nextConsumeToken || h.nextToken()
        }
        switch (y.type !== 10 && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(y)), y = h.nextToken(), y.type === 2 && (y = h.nextToken()), y.type) {
            case 11:
                y.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(y)), m.key = f(h, y.value || "");
                break;
            case 5:
                y.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(y)), m.key = l(h, y.value || "");
                break;
            case 6:
                y.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(y)), m.key = s(h, y.value || "");
                break;
            case 7:
                y.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(y)), m.key = c(h, y.value || "");
                break;
            default:
                r(h, ve.UNEXPECTED_EMPTY_LINKED_KEY, b.lastStartLoc, 0);
                const C = h.context(),
                    S = a(7, C.offset, C.startLoc);
                return S.value = "", i(S, C.offset, C.startLoc), m.key = S, i(m, C.offset, C.startLoc), {
                    nextConsumeToken: y,
                    node: m
                }
        }
        return i(m, h.currentOffset(), h.currentPosition()), {
            node: m
        }
    }

    function p(h) {
        const b = h.context(),
            m = b.currentType === 1 ? h.currentOffset() : b.offset,
            y = b.currentType === 1 ? b.endLoc : b.startLoc,
            C = a(2, m, y);
        C.items = [];
        let S = null;
        do {
            const O = S || h.nextToken();
            switch (S = null, O.type) {
                case 0:
                    O.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(O)), C.items.push(o(h, O.value || ""));
                    break;
                case 6:
                    O.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(O)), C.items.push(s(h, O.value || ""));
                    break;
                case 5:
                    O.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(O)), C.items.push(l(h, O.value || ""));
                    break;
                case 7:
                    O.value == null && r(h, ve.UNEXPECTED_LEXICAL_ANALYSIS, b.lastStartLoc, 0, Bt(O)), C.items.push(c(h, O.value || ""));
                    break;
                case 8:
                    const N = d(h);
                    C.items.push(N.node), S = N.nextConsumeToken || null;
                    break
            }
        } while (b.currentType !== 14 && b.currentType !== 1);
        const A = b.currentType === 1 ? b.lastOffset : h.currentOffset(),
            R = b.currentType === 1 ? b.lastEndLoc : h.currentPosition();
        return i(C, A, R), C
    }

    function v(h, b, m, y) {
        const C = h.context();
        let S = y.items.length === 0;
        const A = a(1, b, m);
        A.cases = [], A.cases.push(y);
        do {
            const R = p(h);
            S || (S = R.items.length === 0), A.cases.push(R)
        } while (C.currentType !== 14);
        return S && r(h, ve.MUST_HAVE_MESSAGES_IN_PLURAL, m, 0), i(A, h.currentOffset(), h.currentPosition()), A
    }

    function E(h) {
        const b = h.context(),
            {
                offset: m,
                startLoc: y
            } = b,
            C = p(h);
        return b.currentType === 14 ? C : v(h, m, y, C)
    }

    function w(h) {
        const b = zT(h, Ye({}, e)),
            m = b.context(),
            y = a(0, m.offset, m.startLoc);
        return t && y.loc && (y.loc.source = h), y.body = E(b), e.onCacheKey && (y.cacheKey = e.onCacheKey(h)), m.currentType !== 14 && r(b, ve.UNEXPECTED_LEXICAL_ANALYSIS, m.lastStartLoc, 0, h[m.offset] || ""), i(y, b.currentOffset(), b.currentPosition()), y
    }
    return {
        parse: w
    }
}

function Bt(e) {
    if (e.type === 14) return "EOF";
    const t = (e.value || "").replace(/\r?\n/gu, "\\n");
    return t.length > 10 ? t.slice(0, 9) + "…" : t
}

function ZT(e, t = {}) {
    const n = {
        ast: e,
        helpers: new Set
    };
    return {
        context: () => n,
        helper: i => (n.helpers.add(i), i)
    }
}

function rd(e, t) {
    for (let n = 0; n < e.length; n++) Hc(e[n], t)
}

function Hc(e, t) {
    switch (e.type) {
        case 1:
            rd(e.cases, t), t.helper("plural");
            break;
        case 2:
            rd(e.items, t);
            break;
        case 6:
            Hc(e.key, t), t.helper("linked"), t.helper("type");
            break;
        case 5:
            t.helper("interpolate"), t.helper("list");
            break;
        case 4:
            t.helper("interpolate"), t.helper("named");
            break
    }
}

function ek(e, t = {}) {
    const n = ZT(e);
    n.helper("normalize"), e.body && Hc(e.body, n);
    const r = n.context();
    e.helpers = Array.from(r.helpers)
}

function tk(e) {
    const t = e.body;
    return t.type === 2 ? ad(t) : t.cases.forEach(n => ad(n)), e
}

function ad(e) {
    if (e.items.length === 1) {
        const t = e.items[0];
        (t.type === 3 || t.type === 9) && (e.static = t.value, delete t.value)
    } else {
        const t = [];
        for (let n = 0; n < e.items.length; n++) {
            const r = e.items[n];
            if (!(r.type === 3 || r.type === 9) || r.value == null) break;
            t.push(r.value)
        }
        if (t.length === e.items.length) {
            e.static = $c(t);
            for (let n = 0; n < e.items.length; n++) {
                const r = e.items[n];
                (r.type === 3 || r.type === 9) && delete r.value
            }
        }
    }
}

function hr(e) {
    switch (e.t = e.type, e.type) {
        case 0:
            const t = e;
            hr(t.body), t.b = t.body, delete t.body;
            break;
        case 1:
            const n = e,
                r = n.cases;
            for (let u = 0; u < r.length; u++) hr(r[u]);
            n.c = r, delete n.cases;
            break;
        case 2:
            const a = e,
                i = a.items;
            for (let u = 0; u < i.length; u++) hr(i[u]);
            a.i = i, delete a.items, a.static && (a.s = a.static, delete a.static);
            break;
        case 3:
        case 9:
        case 8:
        case 7:
            const o = e;
            o.value && (o.v = o.value, delete o.value);
            break;
        case 6:
            const s = e;
            hr(s.key), s.k = s.key, delete s.key, s.modifier && (hr(s.modifier), s.m = s.modifier, delete s.modifier);
            break;
        case 5:
            const l = e;
            l.i = l.index, delete l.index;
            break;
        case 4:
            const c = e;
            c.k = c.key, delete c.key;
            break
    }
    delete e.type
}

function nk(e, t) {
    const {
        sourceMap: n,
        filename: r,
        breakLineCode: a,
        needIndent: i
    } = t, o = t.location !== !1, s = {
        filename: r,
        code: "",
        column: 1,
        line: 1,
        offset: 0,
        map: void 0,
        breakLineCode: a,
        needIndent: i,
        indentLevel: 0
    };
    o && e.loc && (s.source = e.loc.source);
    const l = () => s;

    function c(w, h) {
        s.code += w
    }

    function u(w, h = !0) {
        const b = h ? a : "";
        c(i ? b + "  ".repeat(w) : b)
    }

    function f(w = !0) {
        const h = ++s.indentLevel;
        w && u(h)
    }

    function d(w = !0) {
        const h = --s.indentLevel;
        w && u(h)
    }

    function p() {
        u(s.indentLevel)
    }
    return {
        context: l,
        push: c,
        indent: f,
        deindent: d,
        newline: p,
        helper: w => `_${w}`,
        needIndent: () => s.needIndent
    }
}

function rk(e, t) {
    const {
        helper: n
    } = e;
    e.push(`${n("linked")}(`), Mr(e, t.key), t.modifier ? (e.push(", "), Mr(e, t.modifier), e.push(", _type")) : e.push(", undefined, _type"), e.push(")")
}

function ak(e, t) {
    const {
        helper: n,
        needIndent: r
    } = e;
    e.push(`${n("normalize")}([`), e.indent(r());
    const a = t.items.length;
    for (let i = 0; i < a && (Mr(e, t.items[i]), i !== a - 1); i++) e.push(", ");
    e.deindent(r()), e.push("])")
}

function ik(e, t) {
    const {
        helper: n,
        needIndent: r
    } = e;
    if (t.cases.length > 1) {
        e.push(`${n("plural")}([`), e.indent(r());
        const a = t.cases.length;
        for (let i = 0; i < a && (Mr(e, t.cases[i]), i !== a - 1); i++) e.push(", ");
        e.deindent(r()), e.push("])")
    }
}

function ok(e, t) {
    t.body ? Mr(e, t.body) : e.push("null")
}

function Mr(e, t) {
    const {
        helper: n
    } = e;
    switch (t.type) {
        case 0:
            ok(e, t);
            break;
        case 1:
            ik(e, t);
            break;
        case 2:
            ak(e, t);
            break;
        case 6:
            rk(e, t);
            break;
        case 8:
            e.push(JSON.stringify(t.value), t);
            break;
        case 7:
            e.push(JSON.stringify(t.value), t);
            break;
        case 5:
            e.push(`${n("interpolate")}(${n("list")}(${t.index}))`, t);
            break;
        case 4:
            e.push(`${n("interpolate")}(${n("named")}(${JSON.stringify(t.key)}))`, t);
            break;
        case 9:
            e.push(JSON.stringify(t.value), t);
            break;
        case 3:
            e.push(JSON.stringify(t.value), t);
            break
    }
}
const sk = (e, t = {}) => {
    const n = Y(t.mode) ? t.mode : "normal",
        r = Y(t.filename) ? t.filename : "message.intl",
        a = !!t.sourceMap,
        i = t.breakLineCode != null ? t.breakLineCode : n === "arrow" ? ";" : `
`,
        o = t.needIndent ? t.needIndent : n !== "arrow",
        s = e.helpers || [],
        l = nk(e, {
            mode: n,
            filename: r,
            sourceMap: a,
            breakLineCode: i,
            needIndent: o
        });
    l.push(n === "normal" ? "function __msg__ (ctx) {" : "(ctx) => {"), l.indent(o), s.length > 0 && (l.push(`const { ${$c(s.map(f=>`${f}: _${f}`),", ")} } = ctx`), l.newline()), l.push("return "), Mr(l, e), l.deindent(o), l.push("}"), delete e.helpers;
    const {
        code: c,
        map: u
    } = l.context();
    return {
        ast: e,
        code: c,
        map: u ? u.toJSON() : void 0
    }
};

function lk(e, t = {}) {
    const n = Ye({}, t),
        r = !!n.jit,
        a = !!n.minify,
        i = n.optimize == null ? !0 : n.optimize,
        s = QT(n).parse(e);
    return r ? (i && tk(s), a && hr(s), {
        ast: s,
        code: ""
    }) : (ek(s, n), sk(s, n))
}
/*!
 * core-base v9.8.0
 * (c) 2023 kazuya kawaguchi
 * Released under the MIT License.
 */
function ck() {
    typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (jc().__INTLIFY_PROD_DEVTOOLS__ = !1)
}
const Mn = [];
Mn[0] = {
    w: [0],
    i: [3, 0],
    "[": [4],
    o: [7]
};
Mn[1] = {
    w: [1],
    ".": [2],
    "[": [4],
    o: [7]
};
Mn[2] = {
    w: [2],
    i: [3, 0],
    0: [3, 0]
};
Mn[3] = {
    i: [3, 0],
    0: [3, 0],
    w: [1, 1],
    ".": [2, 1],
    "[": [4, 1],
    o: [7, 1]
};
Mn[4] = {
    "'": [5, 0],
    '"': [6, 0],
    "[": [4, 2],
    "]": [1, 3],
    o: 8,
    l: [4, 0]
};
Mn[5] = {
    "'": [4, 0],
    o: 8,
    l: [5, 0]
};
Mn[6] = {
    '"': [4, 0],
    o: 8,
    l: [6, 0]
};
const uk = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;

function fk(e) {
    return uk.test(e)
}

function dk(e) {
    const t = e.charCodeAt(0),
        n = e.charCodeAt(e.length - 1);
    return t === n && (t === 34 || t === 39) ? e.slice(1, -1) : e
}

function pk(e) {
    if (e == null) return "o";
    switch (e.charCodeAt(0)) {
        case 91:
        case 93:
        case 46:
        case 34:
        case 39:
            return e;
        case 95:
        case 36:
        case 45:
            return "i";
        case 9:
        case 10:
        case 13:
        case 160:
        case 65279:
        case 8232:
        case 8233:
            return "w"
    }
    return "i"
}

function hk(e) {
    const t = e.trim();
    return e.charAt(0) === "0" && isNaN(parseInt(e)) ? !1 : fk(t) ? dk(t) : "*" + t
}

function mk(e) {
    const t = [];
    let n = -1,
        r = 0,
        a = 0,
        i, o, s, l, c, u, f;
    const d = [];
    d[0] = () => {
        o === void 0 ? o = s : o += s
    }, d[1] = () => {
        o !== void 0 && (t.push(o), o = void 0)
    }, d[2] = () => {
        d[0](), a++
    }, d[3] = () => {
        if (a > 0) a--, r = 4, d[0]();
        else {
            if (a = 0, o === void 0 || (o = hk(o), o === !1)) return !1;
            d[1]()
        }
    };

    function p() {
        const v = e[n + 1];
        if (r === 5 && v === "'" || r === 6 && v === '"') return n++, s = "\\" + v, d[0](), !0
    }
    for (; r !== null;)
        if (n++, i = e[n], !(i === "\\" && p())) {
            if (l = pk(i), f = Mn[r], c = f[l] || f.l || 8, c === 8 || (r = c[0], c[1] !== void 0 && (u = d[c[1]], u && (s = i, u() === !1)))) return;
            if (r === 7) return t
        }
}
const id = new Map;

function gk(e, t) {
    return be(e) ? e[t] : null
}

function yk(e, t) {
    if (!be(e)) return null;
    let n = id.get(t);
    if (n || (n = mk(t), n && id.set(t, n)), !n) return null;
    const r = n.length;
    let a = e,
        i = 0;
    for (; i < r;) {
        const o = a[n[i]];
        if (o === void 0 || Se(a)) return null;
        a = o, i++
    }
    return a
}
const bk = e => e,
    vk = e => "",
    _k = "text",
    wk = e => e.length === 0 ? "" : $c(e),
    Ek = BT;

function od(e, t) {
    return e = Math.abs(e), t === 2 ? e ? e > 1 ? 1 : 0 : 1 : e ? Math.min(e, 2) : 0
}

function Ck(e) {
    const t = ze(e.pluralIndex) ? e.pluralIndex : -1;
    return e.named && (ze(e.named.count) || ze(e.named.n)) ? ze(e.named.count) ? e.named.count : ze(e.named.n) ? e.named.n : t : t
}

function Ak(e, t) {
    t.count || (t.count = e), t.n || (t.n = e)
}

function Lk(e = {}) {
    const t = e.locale,
        n = Ck(e),
        r = be(e.pluralRules) && Y(t) && Se(e.pluralRules[t]) ? e.pluralRules[t] : od,
        a = be(e.pluralRules) && Y(t) && Se(e.pluralRules[t]) ? od : void 0,
        i = h => h[r(n, h.length, a)],
        o = e.list || [],
        s = h => o[h],
        l = e.named || {};
    ze(e.pluralIndex) && Ak(n, l);
    const c = h => l[h];

    function u(h) {
        const b = Se(e.messages) ? e.messages(h) : be(e.messages) ? e.messages[h] : !1;
        return b || (e.parent ? e.parent.message(h) : vk)
    }
    const f = h => e.modifiers ? e.modifiers[h] : bk,
        d = me(e.processor) && Se(e.processor.normalize) ? e.processor.normalize : wk,
        p = me(e.processor) && Se(e.processor.interpolate) ? e.processor.interpolate : Ek,
        v = me(e.processor) && Y(e.processor.type) ? e.processor.type : _k,
        w = {
            list: s,
            named: c,
            plural: i,
            linked: (h, ...b) => {
                const [m, y] = b;
                let C = "text",
                    S = "";
                b.length === 1 ? be(m) ? (S = m.modifier || S, C = m.type || C) : Y(m) && (S = m || S) : b.length === 2 && (Y(m) && (S = m || S), Y(y) && (C = y || C));
                const A = u(h)(w),
                    R = C === "vnode" && He(A) && S ? A[0] : A;
                return S ? f(S)(R, C) : R
            },
            message: u,
            type: v,
            interpolate: p,
            normalize: d,
            values: Ye({}, o, l)
        };
    return w
}
let xa = null;

function Sk(e) {
    xa = e
}

function Tk(e, t, n) {
    xa && xa.emit("i18n:init", {
        timestamp: Date.now(),
        i18n: e,
        version: t,
        meta: n
    })
}
const kk = Rk("function:translate");

function Rk(e) {
    return t => xa && xa.emit(e, t)
}
const Ok = {
        NOT_FOUND_KEY: 1,
        FALLBACK_TO_TRANSLATE: 2,
        CANNOT_FORMAT_NUMBER: 3,
        FALLBACK_TO_NUMBER_FORMAT: 4,
        CANNOT_FORMAT_DATE: 5,
        FALLBACK_TO_DATE_FORMAT: 6,
        EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER: 7,
        __EXTEND_POINT__: 8
    },
    lg = ve.__EXTEND_POINT__,
    jn = Vc(lg),
    Ht = {
        INVALID_ARGUMENT: lg,
        INVALID_DATE_ARGUMENT: jn(),
        INVALID_ISO_DATE_ARGUMENT: jn(),
        NOT_SUPPORT_NON_STRING_MESSAGE: jn(),
        NOT_SUPPORT_LOCALE_PROMISE_VALUE: jn(),
        NOT_SUPPORT_LOCALE_ASYNC_FUNCTION: jn(),
        NOT_SUPPORT_LOCALE_TYPE: jn(),
        __EXTEND_POINT__: jn()
    };

function Qt(e) {
    return Mo(e, null, void 0)
}

function Kc(e, t) {
    return t.locale != null ? sd(t.locale) : sd(e.locale)
}
let ms;

function sd(e) {
    if (Y(e)) return e;
    if (Se(e)) {
        if (e.resolvedOnce && ms != null) return ms;
        if (e.constructor.name === "Function") {
            const t = e();
            if (FT(t)) throw Qt(Ht.NOT_SUPPORT_LOCALE_PROMISE_VALUE);
            return ms = t
        } else throw Qt(Ht.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION)
    } else throw Qt(Ht.NOT_SUPPORT_LOCALE_TYPE)
}

function Mk(e, t, n) {
    return [...new Set([n, ...He(t) ? t : be(t) ? Object.keys(t) : Y(t) ? [t] : [n]])]
}

function cg(e, t, n) {
    const r = Y(n) ? n : to,
        a = e;
    a.__localeChainCache || (a.__localeChainCache = new Map);
    let i = a.__localeChainCache.get(r);
    if (!i) {
        i = [];
        let o = [n];
        for (; He(o);) o = ld(i, o, t);
        const s = He(t) || !me(t) ? t : t.default ? t.default : null;
        o = Y(s) ? [s] : s, He(o) && ld(i, o, !1), a.__localeChainCache.set(r, i)
    }
    return i
}

function ld(e, t, n) {
    let r = !0;
    for (let a = 0; a < t.length && De(r); a++) {
        const i = t[a];
        Y(i) && (r = Pk(e, t[a], n))
    }
    return r
}

function Pk(e, t, n) {
    let r;
    const a = t.split("-");
    do {
        const i = a.join("-");
        r = xk(e, i, n), a.splice(-1, 1)
    } while (a.length && r === !0);
    return r
}

function xk(e, t, n) {
    let r = !1;
    if (!e.includes(t) && (r = !0, t)) {
        r = t[t.length - 1] !== "!";
        const a = t.replace(/!/g, "");
        e.push(a), (He(n) || me(n)) && n[a] && (r = n[a])
    }
    return r
}
const Ik = "9.8.0",
    Po = -1,
    to = "en-US",
    cd = "",
    ud = e => `${e.charAt(0).toLocaleUpperCase()}${e.substr(1)}`;

function Dk() {
    return {
        upper: (e, t) => t === "text" && Y(e) ? e.toUpperCase() : t === "vnode" && be(e) && "__v_isVNode" in e ? e.children.toUpperCase() : e,
        lower: (e, t) => t === "text" && Y(e) ? e.toLowerCase() : t === "vnode" && be(e) && "__v_isVNode" in e ? e.children.toLowerCase() : e,
        capitalize: (e, t) => t === "text" && Y(e) ? ud(e) : t === "vnode" && be(e) && "__v_isVNode" in e ? ud(e.children) : e
    }
}
let ug;

function Nk(e) {
    ug = e
}
let fg;

function Fk(e) {
    fg = e
}
let dg;

function Bk(e) {
    dg = e
}
let pg = null;
const jk = e => {
        pg = e
    },
    $k = () => pg;
let hg = null;
const fd = e => {
        hg = e
    },
    Vk = () => hg;
let dd = 0;

function Hk(e = {}) {
    const t = Se(e.onWarn) ? e.onWarn : jT,
        n = Y(e.version) ? e.version : Ik,
        r = Y(e.locale) || Se(e.locale) ? e.locale : to,
        a = Se(r) ? to : r,
        i = He(e.fallbackLocale) || me(e.fallbackLocale) || Y(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : a,
        o = me(e.messages) ? e.messages : {
            [a]: {}
        },
        s = me(e.datetimeFormats) ? e.datetimeFormats : {
            [a]: {}
        },
        l = me(e.numberFormats) ? e.numberFormats : {
            [a]: {}
        },
        c = Ye({}, e.modifiers || {}, Dk()),
        u = e.pluralRules || {},
        f = Se(e.missing) ? e.missing : null,
        d = De(e.missingWarn) || eo(e.missingWarn) ? e.missingWarn : !0,
        p = De(e.fallbackWarn) || eo(e.fallbackWarn) ? e.fallbackWarn : !0,
        v = !!e.fallbackFormat,
        E = !!e.unresolving,
        w = Se(e.postTranslation) ? e.postTranslation : null,
        h = me(e.processor) ? e.processor : null,
        b = De(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
        m = !!e.escapeParameter,
        y = Se(e.messageCompiler) ? e.messageCompiler : ug,
        C = Se(e.messageResolver) ? e.messageResolver : fg || gk,
        S = Se(e.localeFallbacker) ? e.localeFallbacker : dg || Mk,
        A = be(e.fallbackContext) ? e.fallbackContext : void 0,
        R = e,
        O = be(R.__datetimeFormatters) ? R.__datetimeFormatters : new Map,
        N = be(R.__numberFormatters) ? R.__numberFormatters : new Map,
        x = be(R.__meta) ? R.__meta : {};
    dd++;
    const M = {
        version: n,
        cid: dd,
        locale: r,
        fallbackLocale: i,
        messages: o,
        modifiers: c,
        pluralRules: u,
        missing: f,
        missingWarn: d,
        fallbackWarn: p,
        fallbackFormat: v,
        unresolving: E,
        postTranslation: w,
        processor: h,
        warnHtmlMessage: b,
        escapeParameter: m,
        messageCompiler: y,
        messageResolver: C,
        localeFallbacker: S,
        fallbackContext: A,
        onWarn: t,
        __meta: x
    };
    return M.datetimeFormats = s, M.numberFormats = l, M.__datetimeFormatters = O, M.__numberFormatters = N, __INTLIFY_PROD_DEVTOOLS__ && Tk(M, n, x), M
}

function Uc(e, t, n, r, a) {
    const {
        missing: i,
        onWarn: o
    } = e;
    if (i !== null) {
        const s = i(e, n, t, a);
        return Y(s) ? s : t
    } else return t
}

function Qr(e, t, n) {
    const r = e;
    r.__localeChainCache = new Map, e.localeFallbacker(e, n, t)
}

function gs(e) {
    return n => Kk(n, e)
}

function Kk(e, t) {
    const n = t.b || t.body;
    if ((n.t || n.type) === 1) {
        const r = n,
            a = r.c || r.cases;
        return e.plural(a.reduce((i, o) => [...i, pd(e, o)], []))
    } else return pd(e, n)
}

function pd(e, t) {
    const n = t.s || t.static;
    if (n) return e.type === "text" ? n : e.normalize([n]); {
        const r = (t.i || t.items).reduce((a, i) => [...a, bl(e, i)], []);
        return e.normalize(r)
    }
}

function bl(e, t) {
    const n = t.t || t.type;
    switch (n) {
        case 3:
            const r = t;
            return r.v || r.value;
        case 9:
            const a = t;
            return a.v || a.value;
        case 4:
            const i = t;
            return e.interpolate(e.named(i.k || i.key));
        case 5:
            const o = t;
            return e.interpolate(e.list(o.i != null ? o.i : o.index));
        case 6:
            const s = t,
                l = s.m || s.modifier;
            return e.linked(bl(e, s.k || s.key), l ? bl(e, l) : void 0, e.type);
        case 7:
            const c = t;
            return c.v || c.value;
        case 8:
            const u = t;
            return u.v || u.value;
        default:
            throw new Error(`unhandled node type on format message part: ${n}`)
    }
}
const Uk = e => e;
let Ci = Object.create(null);
const Pr = e => be(e) && (e.t === 0 || e.type === 0) && ("b" in e || "body" in e);

function Jk(e, t = {}) {
    let n = !1;
    const r = t.onError || VT;
    return t.onError = a => {
        n = !0, r(a)
    }, { ...lk(e, t),
        detectError: n
    }
}

function Gk(e, t) {
    if (Y(e)) {
        De(t.warnHtmlMessage) && t.warnHtmlMessage;
        const r = (t.onCacheKey || Uk)(e),
            a = Ci[r];
        if (a) return a;
        const {
            ast: i,
            detectError: o
        } = Jk(e, { ...t,
            location: !1,
            jit: !0
        }), s = gs(i);
        return o ? s : Ci[r] = s
    } else {
        const n = e.cacheKey;
        if (n) {
            const r = Ci[n];
            return r || (Ci[n] = gs(e))
        } else return gs(e)
    }
}
const hd = () => "",
    _t = e => Se(e);

function md(e, ...t) {
    const {
        fallbackFormat: n,
        postTranslation: r,
        unresolving: a,
        messageCompiler: i,
        fallbackLocale: o,
        messages: s
    } = e, [l, c] = vl(...t), u = De(c.missingWarn) ? c.missingWarn : e.missingWarn, f = De(c.fallbackWarn) ? c.fallbackWarn : e.fallbackWarn, d = De(c.escapeParameter) ? c.escapeParameter : e.escapeParameter, p = !!c.resolvedMessage, v = Y(c.default) || De(c.default) ? De(c.default) ? i ? l : () => l : c.default : n ? i ? l : () => l : "", E = n || v !== "", w = Kc(e, c);
    d && Wk(c);
    let [h, b, m] = p ? [l, w, s[w] || {}] : mg(e, l, w, o, f, u), y = h, C = l;
    if (!p && !(Y(y) || Pr(y) || _t(y)) && E && (y = v, C = y), !p && (!(Y(y) || Pr(y) || _t(y)) || !Y(b))) return a ? Po : l;
    let S = !1;
    const A = () => {
            S = !0
        },
        R = _t(y) ? y : gg(e, l, b, y, C, A);
    if (S) return y;
    const O = Yk(e, b, m, c),
        N = Lk(O),
        x = zk(e, R, N),
        M = r ? r(x, l) : x;
    if (__INTLIFY_PROD_DEVTOOLS__) {
        const K = {
            timestamp: Date.now(),
            key: Y(l) ? l : _t(y) ? y.key : "",
            locale: b || (_t(y) ? y.locale : ""),
            format: Y(y) ? y : _t(y) ? y.source : "",
            message: M
        };
        K.meta = Ye({}, e.__meta, $k() || {}), kk(K)
    }
    return M
}

function Wk(e) {
    He(e.list) ? e.list = e.list.map(t => Y(t) ? td(t) : t) : be(e.named) && Object.keys(e.named).forEach(t => {
        Y(e.named[t]) && (e.named[t] = td(e.named[t]))
    })
}

function mg(e, t, n, r, a, i) {
    const {
        messages: o,
        onWarn: s,
        messageResolver: l,
        localeFallbacker: c
    } = e, u = c(e, r, n);
    let f = {},
        d, p = null;
    const v = "translate";
    for (let E = 0; E < u.length && (d = u[E], f = o[d] || {}, (p = l(f, t)) === null && (p = f[t]), !(Y(p) || Pr(p) || _t(p))); E++) {
        const w = Uc(e, t, d, i, v);
        w !== t && (p = w)
    }
    return [p, d, f]
}

function gg(e, t, n, r, a, i) {
    const {
        messageCompiler: o,
        warnHtmlMessage: s
    } = e;
    if (_t(r)) {
        const c = r;
        return c.locale = c.locale || n, c.key = c.key || t, c
    }
    if (o == null) {
        const c = () => r;
        return c.locale = n, c.key = t, c
    }
    const l = o(r, qk(e, n, a, r, s, i));
    return l.locale = n, l.key = t, l.source = r, l
}

function zk(e, t, n) {
    return t(n)
}

function vl(...e) {
    const [t, n, r] = e, a = {};
    if (!Y(t) && !ze(t) && !_t(t) && !Pr(t)) throw Qt(Ht.INVALID_ARGUMENT);
    const i = ze(t) ? String(t) : (_t(t), t);
    return ze(n) ? a.plural = n : Y(n) ? a.default = n : me(n) && !Oo(n) ? a.named = n : He(n) && (a.list = n), ze(r) ? a.plural = r : Y(r) ? a.default = r : me(r) && Ye(a, r), [i, a]
}

function qk(e, t, n, r, a, i) {
    return {
        locale: t,
        key: n,
        warnHtmlMessage: a,
        onError: o => {
            throw i && i(o), o
        },
        onCacheKey: o => xT(t, n, o)
    }
}

function Yk(e, t, n, r) {
    const {
        modifiers: a,
        pluralRules: i,
        messageResolver: o,
        fallbackLocale: s,
        fallbackWarn: l,
        missingWarn: c,
        fallbackContext: u
    } = e, d = {
        locale: t,
        modifiers: a,
        pluralRules: i,
        messages: p => {
            let v = o(n, p);
            if (v == null && u) {
                const [, , E] = mg(u, p, t, s, l, c);
                v = o(E, p)
            }
            if (Y(v) || Pr(v)) {
                let E = !1;
                const h = gg(e, p, t, v, p, () => {
                    E = !0
                });
                return E ? hd : h
            } else return _t(v) ? v : hd
        }
    };
    return e.processor && (d.processor = e.processor), r.list && (d.list = r.list), r.named && (d.named = r.named), ze(r.plural) && (d.pluralIndex = r.plural), d
}

function gd(e, ...t) {
    const {
        datetimeFormats: n,
        unresolving: r,
        fallbackLocale: a,
        onWarn: i,
        localeFallbacker: o
    } = e, {
        __datetimeFormatters: s
    } = e, [l, c, u, f] = _l(...t), d = De(u.missingWarn) ? u.missingWarn : e.missingWarn;
    De(u.fallbackWarn) ? u.fallbackWarn : e.fallbackWarn;
    const p = !!u.part,
        v = Kc(e, u),
        E = o(e, a, v);
    if (!Y(l) || l === "") return new Intl.DateTimeFormat(v, f).format(c);
    let w = {},
        h, b = null;
    const m = "datetime format";
    for (let S = 0; S < E.length && (h = E[S], w = n[h] || {}, b = w[l], !me(b)); S++) Uc(e, l, h, d, m);
    if (!me(b) || !Y(h)) return r ? Po : l;
    let y = `${h}__${l}`;
    Oo(f) || (y = `${y}__${JSON.stringify(f)}`);
    let C = s.get(y);
    return C || (C = new Intl.DateTimeFormat(h, Ye({}, b, f)), s.set(y, C)), p ? C.formatToParts(c) : C.format(c)
}
const yg = ["localeMatcher", "weekday", "era", "year", "month", "day", "hour", "minute", "second", "timeZoneName", "formatMatcher", "hour12", "timeZone", "dateStyle", "timeStyle", "calendar", "dayPeriod", "numberingSystem", "hourCycle", "fractionalSecondDigits"];

function _l(...e) {
    const [t, n, r, a] = e, i = {};
    let o = {},
        s;
    if (Y(t)) {
        const l = t.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
        if (!l) throw Qt(Ht.INVALID_ISO_DATE_ARGUMENT);
        const c = l[3] ? l[3].trim().startsWith("T") ? `${l[1].trim()}${l[3].trim()}` : `${l[1].trim()}T${l[3].trim()}` : l[1].trim();
        s = new Date(c);
        try {
            s.toISOString()
        } catch {
            throw Qt(Ht.INVALID_ISO_DATE_ARGUMENT)
        }
    } else if (DT(t)) {
        if (isNaN(t.getTime())) throw Qt(Ht.INVALID_DATE_ARGUMENT);
        s = t
    } else if (ze(t)) s = t;
    else throw Qt(Ht.INVALID_ARGUMENT);
    return Y(n) ? i.key = n : me(n) && Object.keys(n).forEach(l => {
        yg.includes(l) ? o[l] = n[l] : i[l] = n[l]
    }), Y(r) ? i.locale = r : me(r) && (o = r), me(a) && (o = a), [i.key || "", s, i, o]
}

function yd(e, t, n) {
    const r = e;
    for (const a in n) {
        const i = `${t}__${a}`;
        r.__datetimeFormatters.has(i) && r.__datetimeFormatters.delete(i)
    }
}

function bd(e, ...t) {
    const {
        numberFormats: n,
        unresolving: r,
        fallbackLocale: a,
        onWarn: i,
        localeFallbacker: o
    } = e, {
        __numberFormatters: s
    } = e, [l, c, u, f] = wl(...t), d = De(u.missingWarn) ? u.missingWarn : e.missingWarn;
    De(u.fallbackWarn) ? u.fallbackWarn : e.fallbackWarn;
    const p = !!u.part,
        v = Kc(e, u),
        E = o(e, a, v);
    if (!Y(l) || l === "") return new Intl.NumberFormat(v, f).format(c);
    let w = {},
        h, b = null;
    const m = "number format";
    for (let S = 0; S < E.length && (h = E[S], w = n[h] || {}, b = w[l], !me(b)); S++) Uc(e, l, h, d, m);
    if (!me(b) || !Y(h)) return r ? Po : l;
    let y = `${h}__${l}`;
    Oo(f) || (y = `${y}__${JSON.stringify(f)}`);
    let C = s.get(y);
    return C || (C = new Intl.NumberFormat(h, Ye({}, b, f)), s.set(y, C)), p ? C.formatToParts(c) : C.format(c)
}
const bg = ["localeMatcher", "style", "currency", "currencyDisplay", "currencySign", "useGrouping", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits", "compactDisplay", "notation", "signDisplay", "unit", "unitDisplay", "roundingMode", "roundingPriority", "roundingIncrement", "trailingZeroDisplay"];

function wl(...e) {
    const [t, n, r, a] = e, i = {};
    let o = {};
    if (!ze(t)) throw Qt(Ht.INVALID_ARGUMENT);
    const s = t;
    return Y(n) ? i.key = n : me(n) && Object.keys(n).forEach(l => {
        bg.includes(l) ? o[l] = n[l] : i[l] = n[l]
    }), Y(r) ? i.locale = r : me(r) && (o = r), me(a) && (o = a), [i.key || "", s, i, o]
}

function vd(e, t, n) {
    const r = e;
    for (const a in n) {
        const i = `${t}__${a}`;
        r.__numberFormatters.has(i) && r.__numberFormatters.delete(i)
    }
}
ck();
/*!
 * vue-i18n v9.8.0
 * (c) 2023 kazuya kawaguchi
 * Released under the MIT License.
 */
const Xk = "9.8.0";

function Qk() {
    typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (jc().__INTLIFY_PROD_DEVTOOLS__ = !1)
}
const vg = Ok.__EXTEND_POINT__,
    dn = Vc(vg);
dn(), dn(), dn(), dn(), dn(), dn(), dn(), dn();
const _g = Ht.__EXTEND_POINT__,
    lt = Vc(_g),
    Lt = {
        UNEXPECTED_RETURN_TYPE: _g,
        INVALID_ARGUMENT: lt(),
        MUST_BE_CALL_SETUP_TOP: lt(),
        NOT_INSTALLED: lt(),
        NOT_AVAILABLE_IN_LEGACY_MODE: lt(),
        REQUIRED_VALUE: lt(),
        INVALID_VALUE: lt(),
        CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: lt(),
        NOT_INSTALLED_WITH_PROVIDE: lt(),
        UNEXPECTED_ERROR: lt(),
        NOT_COMPATIBLE_LEGACY_VUE_I18N: lt(),
        BRIDGE_SUPPORT_VUE_2_ONLY: lt(),
        MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION: lt(),
        NOT_AVAILABLE_COMPOSITION_IN_LEGACY: lt(),
        __EXTEND_POINT__: lt()
    };

function Dt(e, ...t) {
    return Mo(e, null, void 0)
}
const El = On("__translateVNode"),
    Cl = On("__datetimeParts"),
    Al = On("__numberParts"),
    Zk = On("__setPluralRules"),
    eR = On("__injectWithOption"),
    Ll = On("__dispose");

function Ia(e) {
    if (!be(e)) return e;
    for (const t in e)
        if (Pa(e, t))
            if (!t.includes(".")) be(e[t]) && Ia(e[t]);
            else {
                const n = t.split("."),
                    r = n.length - 1;
                let a = e,
                    i = !1;
                for (let o = 0; o < r; o++) {
                    if (n[o] in a || (a[n[o]] = {}), !be(a[n[o]])) {
                        i = !0;
                        break
                    }
                    a = a[n[o]]
                }
                i || (a[n[r]] = e[t], delete e[t]), be(a[n[r]]) && Ia(a[n[r]])
            }
    return e
}

function wg(e, t) {
    const {
        messages: n,
        __i18n: r,
        messageResolver: a,
        flatJson: i
    } = t, o = me(n) ? n : He(r) ? {} : {
        [e]: {}
    };
    if (He(r) && r.forEach(s => {
            if ("locale" in s && "resource" in s) {
                const {
                    locale: l,
                    resource: c
                } = s;
                l ? (o[l] = o[l] || {}, An(c, o[l])) : An(c, o)
            } else Y(s) && An(JSON.parse(s), o)
        }), a == null && i)
        for (const s in o) Pa(o, s) && Ia(o[s]);
    return o
}

function Eg(e) {
    return e.type
}

function tR(e, t, n) {
    let r = be(t.messages) ? t.messages : {};
    "__i18nGlobal" in n && (r = wg(e.locale.value, {
        messages: r,
        __i18n: n.__i18nGlobal
    }));
    const a = Object.keys(r);
    a.length && a.forEach(i => {
        e.mergeLocaleMessage(i, r[i])
    }); {
        if (be(t.datetimeFormats)) {
            const i = Object.keys(t.datetimeFormats);
            i.length && i.forEach(o => {
                e.mergeDateTimeFormat(o, t.datetimeFormats[o])
            })
        }
        if (be(t.numberFormats)) {
            const i = Object.keys(t.numberFormats);
            i.length && i.forEach(o => {
                e.mergeNumberFormat(o, t.numberFormats[o])
            })
        }
    }
}

function _d(e) {
    return Ae(nr, null, e, 0)
}
const wd = "__INTLIFY_META__",
    Ed = () => [],
    nR = () => !1;
let Cd = 0;

function Ad(e) {
    return (t, n, r, a) => e(n, r, yt() || void 0, a)
}
const rR = () => {
    const e = yt();
    let t = null;
    return e && (t = Eg(e)[wd]) ? {
        [wd]: t
    } : null
};

function Cg(e = {}, t) {
    const {
        __root: n,
        __injectWithOption: r
    } = e, a = n === void 0, i = e.flatJson;
    let o = De(e.inheritLocale) ? e.inheritLocale : !0;
    const s = Q(n && o ? n.locale.value : Y(e.locale) ? e.locale : to),
        l = Q(n && o ? n.fallbackLocale.value : Y(e.fallbackLocale) || He(e.fallbackLocale) || me(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : s.value),
        c = Q(wg(s.value, e)),
        u = Q(me(e.datetimeFormats) ? e.datetimeFormats : {
            [s.value]: {}
        }),
        f = Q(me(e.numberFormats) ? e.numberFormats : {
            [s.value]: {}
        });
    let d = n ? n.missingWarn : De(e.missingWarn) || eo(e.missingWarn) ? e.missingWarn : !0,
        p = n ? n.fallbackWarn : De(e.fallbackWarn) || eo(e.fallbackWarn) ? e.fallbackWarn : !0,
        v = n ? n.fallbackRoot : De(e.fallbackRoot) ? e.fallbackRoot : !0,
        E = !!e.fallbackFormat,
        w = Se(e.missing) ? e.missing : null,
        h = Se(e.missing) ? Ad(e.missing) : null,
        b = Se(e.postTranslation) ? e.postTranslation : null,
        m = n ? n.warnHtmlMessage : De(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
        y = !!e.escapeParameter;
    const C = n ? n.modifiers : me(e.modifiers) ? e.modifiers : {};
    let S = e.pluralRules || n && n.pluralRules,
        A;
    A = (() => {
        a && fd(null);
        const I = {
            version: Xk,
            locale: s.value,
            fallbackLocale: l.value,
            messages: c.value,
            modifiers: C,
            pluralRules: S,
            missing: h === null ? void 0 : h,
            missingWarn: d,
            fallbackWarn: p,
            fallbackFormat: E,
            unresolving: !0,
            postTranslation: b === null ? void 0 : b,
            warnHtmlMessage: m,
            escapeParameter: y,
            messageResolver: e.messageResolver,
            messageCompiler: e.messageCompiler,
            __meta: {
                framework: "vue"
            }
        };
        I.datetimeFormats = u.value, I.numberFormats = f.value, I.__datetimeFormatters = me(A) ? A.__datetimeFormatters : void 0, I.__numberFormatters = me(A) ? A.__numberFormatters : void 0;
        const B = Hk(I);
        return a && fd(B), B
    })(), Qr(A, s.value, l.value);

    function O() {
        return [s.value, l.value, c.value, u.value, f.value]
    }
    const N = W({
            get: () => s.value,
            set: I => {
                s.value = I, A.locale = s.value
            }
        }),
        x = W({
            get: () => l.value,
            set: I => {
                l.value = I, A.fallbackLocale = l.value, Qr(A, s.value, I)
            }
        }),
        M = W(() => c.value),
        K = W(() => u.value),
        ne = W(() => f.value);

    function te() {
        return Se(b) ? b : null
    }

    function J(I) {
        b = I, A.postTranslation = I
    }

    function ae() {
        return w
    }

    function X(I) {
        I !== null && (h = Ad(I)), w = I, A.missing = h
    }
    const Ce = (I, B, Z, oe, fe, ke) => {
        O();
        let We;
        try {
            __INTLIFY_PROD_DEVTOOLS__,
            a || (A.fallbackContext = n ? Vk() : void 0),
            We = I(A)
        }
        finally {
            __INTLIFY_PROD_DEVTOOLS__,
            a || (A.fallbackContext = void 0)
        }
        if (Z !== "translate exists" && ze(We) && We === Po || Z === "translate exists" && !We) {
            const [rn, Ho] = B();
            return n && v ? oe(n) : fe(rn)
        } else {
            if (ke(We)) return We;
            throw Dt(Lt.UNEXPECTED_RETURN_TYPE)
        }
    };

    function Ze(...I) {
        return Ce(B => Reflect.apply(md, null, [B, ...I]), () => vl(...I), "translate", B => Reflect.apply(B.t, B, [...I]), B => B, B => Y(B))
    }

    function je(...I) {
        const [B, Z, oe] = I;
        if (oe && !be(oe)) throw Dt(Lt.INVALID_ARGUMENT);
        return Ze(B, Z, Ye({
            resolvedMessage: !0
        }, oe || {}))
    }

    function Ie(...I) {
        return Ce(B => Reflect.apply(gd, null, [B, ...I]), () => _l(...I), "datetime format", B => Reflect.apply(B.d, B, [...I]), () => cd, B => Y(B))
    }

    function Me(...I) {
        return Ce(B => Reflect.apply(bd, null, [B, ...I]), () => wl(...I), "number format", B => Reflect.apply(B.n, B, [...I]), () => cd, B => Y(B))
    }

    function Tt(I) {
        return I.map(B => Y(B) || ze(B) || De(B) ? _d(String(B)) : B)
    }
    const $e = {
        normalize: Tt,
        interpolate: I => I,
        type: "vnode"
    };

    function j(...I) {
        return Ce(B => {
            let Z;
            const oe = B;
            try {
                oe.processor = $e, Z = Reflect.apply(md, null, [oe, ...I])
            } finally {
                oe.processor = null
            }
            return Z
        }, () => vl(...I), "translate", B => B[El](...I), B => [_d(B)], B => He(B))
    }

    function q(...I) {
        return Ce(B => Reflect.apply(bd, null, [B, ...I]), () => wl(...I), "number format", B => B[Al](...I), Ed, B => Y(B) || He(B))
    }

    function G(...I) {
        return Ce(B => Reflect.apply(gd, null, [B, ...I]), () => _l(...I), "datetime format", B => B[Cl](...I), Ed, B => Y(B) || He(B))
    }

    function ee(I) {
        S = I, A.pluralRules = S
    }

    function ue(I, B) {
        return Ce(() => {
            if (!I) return !1;
            const Z = Y(B) ? B : s.value,
                oe = _(Z),
                fe = A.messageResolver(oe, I);
            return Pr(fe) || _t(fe) || Y(fe)
        }, () => [I], "translate exists", Z => Reflect.apply(Z.te, Z, [I, B]), nR, Z => De(Z))
    }

    function L(I) {
        let B = null;
        const Z = cg(A, l.value, s.value);
        for (let oe = 0; oe < Z.length; oe++) {
            const fe = c.value[Z[oe]] || {},
                ke = A.messageResolver(fe, I);
            if (ke != null) {
                B = ke;
                break
            }
        }
        return B
    }

    function g(I) {
        const B = L(I);
        return B ? ? (n ? n.tm(I) || {} : {})
    }

    function _(I) {
        return c.value[I] || {}
    }

    function T(I, B) {
        if (i) {
            const Z = {
                [I]: B
            };
            for (const oe in Z) Pa(Z, oe) && Ia(Z[oe]);
            B = Z[I]
        }
        c.value[I] = B, A.messages = c.value
    }

    function P(I, B) {
        c.value[I] = c.value[I] || {};
        const Z = {
            [I]: B
        };
        for (const oe in Z) Pa(Z, oe) && Ia(Z[oe]);
        B = Z[I], An(B, c.value[I]), A.messages = c.value
    }

    function F(I) {
        return u.value[I] || {}
    }

    function $(I, B) {
        u.value[I] = B, A.datetimeFormats = u.value, yd(A, I, B)
    }

    function H(I, B) {
        u.value[I] = Ye(u.value[I] || {}, B), A.datetimeFormats = u.value, yd(A, I, B)
    }

    function U(I) {
        return f.value[I] || {}
    }

    function V(I, B) {
        f.value[I] = B, A.numberFormats = f.value, vd(A, I, B)
    }

    function re(I, B) {
        f.value[I] = Ye(f.value[I] || {}, B), A.numberFormats = f.value, vd(A, I, B)
    }
    Cd++, n && gl && (we(n.locale, I => {
        o && (s.value = I, A.locale = I, Qr(A, s.value, l.value))
    }), we(n.fallbackLocale, I => {
        o && (l.value = I, A.fallbackLocale = I, Qr(A, s.value, l.value))
    }));
    const z = {
        id: Cd,
        locale: N,
        fallbackLocale: x,
        get inheritLocale() {
            return o
        },
        set inheritLocale(I) {
            o = I, I && n && (s.value = n.locale.value, l.value = n.fallbackLocale.value, Qr(A, s.value, l.value))
        },
        get availableLocales() {
            return Object.keys(c.value).sort()
        },
        messages: M,
        get modifiers() {
            return C
        },
        get pluralRules() {
            return S || {}
        },
        get isGlobal() {
            return a
        },
        get missingWarn() {
            return d
        },
        set missingWarn(I) {
            d = I, A.missingWarn = d
        },
        get fallbackWarn() {
            return p
        },
        set fallbackWarn(I) {
            p = I, A.fallbackWarn = p
        },
        get fallbackRoot() {
            return v
        },
        set fallbackRoot(I) {
            v = I
        },
        get fallbackFormat() {
            return E
        },
        set fallbackFormat(I) {
            E = I, A.fallbackFormat = E
        },
        get warnHtmlMessage() {
            return m
        },
        set warnHtmlMessage(I) {
            m = I, A.warnHtmlMessage = I
        },
        get escapeParameter() {
            return y
        },
        set escapeParameter(I) {
            y = I, A.escapeParameter = I
        },
        t: Ze,
        getLocaleMessage: _,
        setLocaleMessage: T,
        mergeLocaleMessage: P,
        getPostTranslationHandler: te,
        setPostTranslationHandler: J,
        getMissingHandler: ae,
        setMissingHandler: X,
        [Zk]: ee
    };
    return z.datetimeFormats = K, z.numberFormats = ne, z.rt = je, z.te = ue, z.tm = g, z.d = Ie, z.n = Me, z.getDateTimeFormat = F, z.setDateTimeFormat = $, z.mergeDateTimeFormat = H, z.getNumberFormat = U, z.setNumberFormat = V, z.mergeNumberFormat = re, z[eR] = r, z[El] = j, z[Cl] = G, z[Al] = q, z
}
const Jc = {
    tag: {
        type: [String, Object]
    },
    locale: {
        type: String
    },
    scope: {
        type: String,
        validator: e => e === "parent" || e === "global",
        default: "parent"
    },
    i18n: {
        type: Object
    }
};

function aR({
    slots: e
}, t) {
    return t.length === 1 && t[0] === "default" ? (e.default ? e.default() : []).reduce((r, a) => [...r, ...a.type === Fe ? a.children : [a]], []) : t.reduce((n, r) => {
        const a = e[r];
        return a && (n[r] = a()), n
    }, {})
}

function Ag(e) {
    return Fe
}
const iR = Ne({
        name: "i18n-t",
        props: Ye({
            keypath: {
                type: String,
                required: !0
            },
            plural: {
                type: [Number, String],
                validator: e => ze(e) || !isNaN(e)
            }
        }, Jc),
        setup(e, t) {
            const {
                slots: n,
                attrs: r
            } = t, a = e.i18n || Kr({
                useScope: e.scope,
                __useComponent: !0
            });
            return () => {
                const i = Object.keys(n).filter(f => f !== "_"),
                    o = {};
                e.locale && (o.locale = e.locale), e.plural !== void 0 && (o.plural = Y(e.plural) ? +e.plural : e.plural);
                const s = aR(t, i),
                    l = a[El](e.keypath, s, o),
                    c = Ye({}, r),
                    u = Y(e.tag) || be(e.tag) ? e.tag : Ag();
                return Be(u, c, l)
            }
        }
    }),
    Ld = iR;

function oR(e) {
    return He(e) && !Y(e[0])
}

function Lg(e, t, n, r) {
    const {
        slots: a,
        attrs: i
    } = t;
    return () => {
        const o = {
            part: !0
        };
        let s = {};
        e.locale && (o.locale = e.locale), Y(e.format) ? o.key = e.format : be(e.format) && (Y(e.format.key) && (o.key = e.format.key), s = Object.keys(e.format).reduce((d, p) => n.includes(p) ? Ye({}, d, {
            [p]: e.format[p]
        }) : d, {}));
        const l = r(e.value, o, s);
        let c = [o.key];
        He(l) ? c = l.map((d, p) => {
            const v = a[d.type],
                E = v ? v({
                    [d.type]: d.value,
                    index: p,
                    parts: l
                }) : [d.value];
            return oR(E) && (E[0].key = `${d.type}-${p}`), E
        }) : Y(l) && (c = [l]);
        const u = Ye({}, i),
            f = Y(e.tag) || be(e.tag) ? e.tag : Ag();
        return Be(f, u, c)
    }
}
const sR = Ne({
        name: "i18n-n",
        props: Ye({
            value: {
                type: Number,
                required: !0
            },
            format: {
                type: [String, Object]
            }
        }, Jc),
        setup(e, t) {
            const n = e.i18n || Kr({
                useScope: "parent",
                __useComponent: !0
            });
            return Lg(e, t, bg, (...r) => n[Al](...r))
        }
    }),
    Sd = sR,
    lR = Ne({
        name: "i18n-d",
        props: Ye({
            value: {
                type: [Number, Date],
                required: !0
            },
            format: {
                type: [String, Object]
            }
        }, Jc),
        setup(e, t) {
            const n = e.i18n || Kr({
                useScope: "parent",
                __useComponent: !0
            });
            return Lg(e, t, yg, (...r) => n[Cl](...r))
        }
    }),
    Td = lR;

function cR(e, t) {
    const n = e;
    if (e.mode === "composition") return n.__getInstance(t) || e.global; {
        const r = n.__getInstance(t);
        return r != null ? r.__composer : e.global.__composer
    }
}

function uR(e) {
    const t = o => {
        const {
            instance: s,
            modifiers: l,
            value: c
        } = o;
        if (!s || !s.$) throw Dt(Lt.UNEXPECTED_ERROR);
        const u = cR(e, s.$),
            f = kd(c);
        return [Reflect.apply(u.t, u, [...Rd(f)]), u]
    };
    return {
        created: (o, s) => {
            const [l, c] = t(s);
            gl && e.global === c && (o.__i18nWatcher = we(c.locale, () => {
                s.instance && s.instance.$forceUpdate()
            })), o.__composer = c, o.textContent = l
        },
        unmounted: o => {
            gl && o.__i18nWatcher && (o.__i18nWatcher(), o.__i18nWatcher = void 0, delete o.__i18nWatcher), o.__composer && (o.__composer = void 0, delete o.__composer)
        },
        beforeUpdate: (o, {
            value: s
        }) => {
            if (o.__composer) {
                const l = o.__composer,
                    c = kd(s);
                o.textContent = Reflect.apply(l.t, l, [...Rd(c)])
            }
        },
        getSSRProps: o => {
            const [s] = t(o);
            return {
                textContent: s
            }
        }
    }
}

function kd(e) {
    if (Y(e)) return {
        path: e
    };
    if (me(e)) {
        if (!("path" in e)) throw Dt(Lt.REQUIRED_VALUE, "path");
        return e
    } else throw Dt(Lt.INVALID_VALUE)
}

function Rd(e) {
    const {
        path: t,
        locale: n,
        args: r,
        choice: a,
        plural: i
    } = e, o = {}, s = r || {};
    return Y(n) && (o.locale = n), ze(a) && (o.plural = a), ze(i) && (o.plural = i), [t, s, o]
}

function fR(e, t, ...n) {
    const r = me(n[0]) ? n[0] : {},
        a = !!r.useI18nComponentName;
    (De(r.globalInstall) ? r.globalInstall : !0) && ([a ? "i18n" : Ld.name, "I18nT"].forEach(o => e.component(o, Ld)), [Sd.name, "I18nN"].forEach(o => e.component(o, Sd)), [Td.name, "I18nD"].forEach(o => e.component(o, Td))), e.directive("t", uR(t))
}
const dR = On("global-vue-i18n");

function pR(e = {}, t) {
    const n = De(e.globalInjection) ? e.globalInjection : !0,
        r = !0,
        a = new Map,
        [i, o] = hR(e),
        s = On("");

    function l(f) {
        return a.get(f) || null
    }

    function c(f, d) {
        a.set(f, d)
    }

    function u(f) {
        a.delete(f)
    } {
        const f = {
            get mode() {
                return "composition"
            },
            get allowComposition() {
                return r
            },
            async install(d, ...p) {
                if (d.__VUE_I18N_SYMBOL__ = s, d.provide(d.__VUE_I18N_SYMBOL__, f), me(p[0])) {
                    const w = p[0];
                    f.__composerExtend = w.__composerExtend, f.__vueI18nExtend = w.__vueI18nExtend
                }
                let v = null;
                n && (v = ER(d, f.global)), fR(d, f, ...p);
                const E = d.unmount;
                d.unmount = () => {
                    v && v(), f.dispose(), E()
                }
            },
            get global() {
                return o
            },
            dispose() {
                i.stop()
            },
            __instances: a,
            __getInstance: l,
            __setInstance: c,
            __deleteInstance: u
        };
        return f
    }
}

function Kr(e = {}) {
    const t = yt();
    if (t == null) throw Dt(Lt.MUST_BE_CALL_SETUP_TOP);
    if (!t.isCE && t.appContext.app != null && !t.appContext.app.__VUE_I18N_SYMBOL__) throw Dt(Lt.NOT_INSTALLED);
    const n = mR(t),
        r = yR(n),
        a = Eg(t),
        i = gR(e, a);
    if (i === "global") return tR(r, e, a), r;
    if (i === "parent") {
        let l = bR(n, t, e.__useComponent);
        return l == null && (l = r), l
    }
    const o = n;
    let s = o.__getInstance(t);
    if (s == null) {
        const l = Ye({}, e);
        "__i18n" in a && (l.__i18n = a.__i18n), r && (l.__root = r), s = Cg(l), o.__composerExtend && (s[Ll] = o.__composerExtend(s)), _R(o, t, s), o.__setInstance(t, s)
    }
    return s
}

function hR(e, t, n) {
    const r = Va(); {
        const a = r.run(() => Cg(e));
        if (a == null) throw Dt(Lt.UNEXPECTED_ERROR);
        return [r, a]
    }
}

function mR(e) {
    {
        const t = Je(e.isCE ? dR : e.appContext.app.__VUE_I18N_SYMBOL__);
        if (!t) throw Dt(e.isCE ? Lt.NOT_INSTALLED_WITH_PROVIDE : Lt.UNEXPECTED_ERROR);
        return t
    }
}

function gR(e, t) {
    return Oo(e) ? "__i18n" in t ? "local" : "global" : e.useScope ? e.useScope : "local"
}

function yR(e) {
    return e.mode === "composition" ? e.global : e.global.__composer
}

function bR(e, t, n = !1) {
    let r = null;
    const a = t.root;
    let i = vR(t, n);
    for (; i != null;) {
        const o = e;
        if (e.mode === "composition" && (r = o.__getInstance(i)), r != null || a === i) break;
        i = i.parent
    }
    return r
}

function vR(e, t = !1) {
    return e == null ? null : t && e.vnode.ctx || e.parent
}

function _R(e, t, n) {
    Jt(() => {}, t), Rn(() => {
        const r = n;
        e.__deleteInstance(t);
        const a = r[Ll];
        a && (a(), delete r[Ll])
    }, t)
}
const wR = ["locale", "fallbackLocale", "availableLocales"],
    Od = ["t", "rt", "d", "n", "tm", "te"];

function ER(e, t) {
    const n = Object.create(null);
    return wR.forEach(a => {
        const i = Object.getOwnPropertyDescriptor(t, a);
        if (!i) throw Dt(Lt.UNEXPECTED_ERROR);
        const o = _e(i.value) ? {
            get() {
                return i.value.value
            },
            set(s) {
                i.value.value = s
            }
        } : {
            get() {
                return i.get && i.get()
            }
        };
        Object.defineProperty(n, a, o)
    }), e.config.globalProperties.$i18n = n, Od.forEach(a => {
        const i = Object.getOwnPropertyDescriptor(t, a);
        if (!i || !i.value) throw Dt(Lt.UNEXPECTED_ERROR);
        Object.defineProperty(e.config.globalProperties, `$${a}`, i)
    }), () => {
        delete e.config.globalProperties.$i18n, Od.forEach(a => {
            delete e.config.globalProperties[`$${a}`]
        })
    }
}
Qk();
Nk(Gk);
Fk(yk);
Bk(cg);
if (__INTLIFY_PROD_DEVTOOLS__) {
    const e = jc();
    e.__INTLIFY__ = !0, Sk(e.__INTLIFY_DEVTOOLS_GLOBAL_HOOK__)
}
const Sg = {
        PREFIX: "prefix",
        PREFIX_EXCEPT_DEFAULT: "prefix_except_default",
        PREFIX_AND_DEFAULT: "prefix_and_default",
        NO_PREFIX: "no_prefix"
    },
    CR = "",
    AR = Sg.PREFIX_EXCEPT_DEFAULT,
    LR = !1,
    SR = "___",
    TR = "default",
    kR = "ltr",
    RR = "",
    Tg = "";
/*!
 * shared v9.4.1
 * (c) 2023 kazuya kawaguchi
 * Released under the MIT License.
 */
const OR = (e, t = !1) => t ? Symbol.for(e) : Symbol(e),
    xo = Object.assign,
    MR = Array.isArray,
    Sl = e => typeof e == "function",
    xr = e => typeof e == "string",
    PR = e => typeof e == "symbol",
    Gc = e => e !== null && typeof e == "object",
    kg = /\+/g;

function Rg(e = "") {
    try {
        return decodeURIComponent("" + e)
    } catch {
        return "" + e
    }
}

function xR(e) {
    return Rg(e.replace(kg, " "))
}

function IR(e) {
    return Rg(e.replace(kg, " "))
}

function DR(e = "") {
    const t = {};
    e[0] === "?" && (e = e.slice(1));
    for (const n of e.split("&")) {
        const r = n.match(/([^=]+)=?(.*)/) || [];
        if (r.length < 2) continue;
        const a = xR(r[1]);
        if (a === "__proto__" || a === "constructor") continue;
        const i = IR(r[2] || "");
        t[a] === void 0 ? t[a] = i : Array.isArray(t[a]) ? t[a].push(i) : t[a] = [t[a], i]
    }
    return t
}
const NR = /\/$|\/\?/;

function Tl(e = "", t = !1) {
    return t ? NR.test(e) : e.endsWith("/")
}

function FR(e = "", t = !1) {
    if (!t) return (Tl(e) ? e.slice(0, -1) : e) || "/";
    if (!Tl(e, !0)) return e || "/";
    const [n, ...r] = e.split("?");
    return (n.slice(0, -1) || "/") + (r.length > 0 ? `?${r.join("?")}` : "")
}

function BR(e = "", t = !1) {
    if (!t) return e.endsWith("/") ? e : e + "/";
    if (Tl(e, !0)) return e || "/";
    const [n, ...r] = e.split("?");
    return n + "/" + (r.length > 0 ? `?${r.join("?")}` : "")
}

function jR(e = "") {
    const [t = "", n = "", r = ""] = (e.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
    return {
        pathname: t,
        search: n,
        hash: r
    }
}
const Og = typeof window < "u";

function Mg(e, t) {
    typeof console < "u" && (console.warn("[vue-i18n-routing] " + e), t && console.warn(t.stack))
}

function $R(e) {
    e = e || [];
    const t = [];
    for (const n of e) xr(n) ? t.push({
        code: n
    }) : t.push(n);
    return t
}

function lr(e) {
    return e != null && "global" in e && "mode" in e
}

function Ur(e) {
    return e != null && !("__composer" in e) && _e(e.locale)
}

function cr(e) {
    return e != null && "__composer" in e
}

function ti(e) {
    return e != null && !("__composer" in e) && !_e(e.locale)
}

function Io(e) {
    return e != null && ("__VUE_I18N_BRIDGE__" in e || "_sync" in e)
}

function kn(e) {
    return lr(e) ? Ur(e.global) ? e.global : e.global.__composer : cr(e) ? e.__composer : e
}

function Do(e) {
    const t = lr(e) ? e.global : e;
    return Ur(t) ? t.locale.value : (ti(t) || cr(t) || Io(t), t.locale)
}

function VR(e) {
    const t = lr(e) ? e.global : e;
    return Ur(t) ? t.locales.value : (ti(t) || cr(t) || Io(t), t.locales)
}

function HR(e) {
    const t = lr(e) ? e.global : e;
    return Ur(t) ? t.localeCodes.value : (ti(t) || cr(t) || Io(t), t.localeCodes)
}

function Pg(e, t) {
    const n = lr(e) ? e.global : e;
    if (Ur(n)) n.locale.value = t;
    else if (ti(n) || cr(n) || Io(n)) n.locale = t;
    else throw new Error("TODO:")
}

function Md(e) {
    return _e(e) ? e.value : e
}

function xg(e) {
    return xr(e) ? e : PR(e) ? e.toString() : "(null)"
}

function Pd(e, t, {
    defaultLocale: n,
    strategy: r,
    routesNameSeparator: a,
    defaultLocaleRouteNameSuffix: i
}) {
    let o = xg(e) + (r === "no_prefix" ? "" : a + t);
    return t === n && r === "prefix_and_default" && (o += a + i), o
}

function xd(e, t) {
    return Sl(e) ? e(t) : e
}

function KR(e, t) {
    const n = [];
    for (const [r, a] of t.entries()) {
        const i = e.find(o => o.iso.toLowerCase() === a.toLowerCase());
        if (i) {
            n.push({
                code: i.code,
                score: 1 - r / t.length
            });
            break
        }
    }
    for (const [r, a] of t.entries()) {
        const i = a.split("-")[0].toLowerCase(),
            o = e.find(s => s.iso.split("-")[0].toLowerCase() === i);
        if (o) {
            n.push({
                code: o.code,
                score: .999 - r / t.length
            });
            break
        }
    }
    return n
}
const UR = KR;

function JR(e, t) {
    return e.score === t.score ? t.code.length - e.code.length : t.score - e.score
}
const GR = JR;

function WR(e, t, {
    matcher: n = UR,
    comparer: r = GR
} = {}) {
    const a = [];
    for (const o of e) {
        const {
            code: s
        } = o, l = o.iso || s;
        a.push({
            code: s,
            iso: l
        })
    }
    const i = n(a, t);
    return i.length > 1 && i.sort(r), i.length ? i[0].code : ""
}

function $n(e) {
    return function() {
        return Reflect.apply(e, {
            getRouteBaseName: this.getRouteBaseName,
            localePath: this.localePath,
            localeRoute: this.localeRoute,
            localeLocation: this.localeLocation,
            resolveRoute: this.resolveRoute,
            switchLocalePath: this.switchLocalePath,
            localeHead: this.localeHead,
            i18n: this.$i18n,
            route: this.$route,
            router: this.$router
        }, arguments)
    }
}

function zR(e, {
    locales: t = [],
    localeCodes: n = [],
    baseUrl: r = RR,
    hooks: a = {},
    context: i = {}
} = {}) {
    const o = Va(),
        s = e.install;
    return e.install = (l, ...c) => {
        const u = XR(c[0]) ? xo({}, c[0]) : {
            inject: !0
        };
        u.inject == null && (u.inject = !0);
        const f = u.__composerExtend;
        if (u.__composerExtend = E => {
                const w = kn(e);
                E.locales = W(() => w.locales.value), E.localeCodes = W(() => w.localeCodes.value), E.baseUrl = W(() => w.baseUrl.value);
                let h;
                return Sl(f) && (h = Reflect.apply(f, u, [E])), () => {
                    h && h()
                }
            }, e.mode === "legacy") {
            const E = u.__vueI18nExtend;
            u.__vueI18nExtend = w => {
                Id(w, a.onExtendVueI18n);
                let h;
                return Sl(E) && (h = Reflect.apply(E, u, [w])), () => {
                    h && h()
                }
            }
        }
        c[0] = u, Reflect.apply(s, e, [l, ...c]);
        const d = kn(e);
        o.run(() => {
            qR(d, {
                locales: t,
                localeCodes: n,
                baseUrl: r,
                hooks: a,
                context: i
            }), e.mode === "legacy" && cr(e.global) && Id(e.global, a.onExtendVueI18n)
        });
        const p = l,
            v = e.mode === "composition" ? p.config.globalProperties.$i18n : null;
        if (v && YR(v, d, a.onExtendExportedGlobal), u.inject && l.mixin({
                methods: {
                    resolveRoute: $n(Fo),
                    localePath: $n(No),
                    localeRoute: $n(Wc),
                    localeLocation: $n(s1),
                    switchLocalePath: $n(Da),
                    getRouteBaseName: $n(Ir),
                    localeHead: $n(zc)
                }
            }), p.unmount) {
            const E = p.unmount;
            p.unmount = () => {
                o.stop(), E()
            }
        }
    }, o
}

function qR(e, t) {
    const {
        locales: n,
        localeCodes: r,
        baseUrl: a,
        context: i
    } = t, o = Q(n), s = Q(r), l = Q("");
    e.locales = W(() => o.value), e.localeCodes = W(() => s.value), e.baseUrl = W(() => l.value), Og ? we(e.locale, () => {
        l.value = xd(a, i)
    }, {
        immediate: !0
    }) : l.value = xd(a, i), t.hooks && t.hooks.onExtendComposer && t.hooks.onExtendComposer(e)
}

function Ig(e, t, n) {
    const r = [{
        locales: {
            get() {
                return e.locales.value
            }
        },
        localeCodes: {
            get() {
                return e.localeCodes.value
            }
        },
        baseUrl: {
            get() {
                return e.baseUrl.value
            }
        }
    }];
    n && r.push(n(e));
    for (const a of r)
        for (const [i, o] of Object.entries(a)) Object.defineProperty(t, i, o)
}

function YR(e, t, n) {
    Ig(t, e, n)
}

function Id(e, t) {
    const n = kn(e);
    Ig(n, e, t)
}

function XR(e) {
    return Gc(e) && ("inject" in e || "__composerExtend" in e || "__vueI18nExtend" in e)
}
const kl = OR("vue-i18n-routing-gor");

function QR(e, t) {
    e[kl] ? Mg("already registered global options") : e[kl] = t
}

function ZR(e) {
    return e[kl] ? ? {}
}

function Rl(e) {
    return new RegExp(`^/(${e.join("|")})(?:/|$)`, "i")
}

function e1(e, t, n) {
    const r = `(${e.join("|")})`,
        a = `(?:${t}${n})?`,
        i = new RegExp(`${t}${r}${a}$`, "i"),
        o = Rl(e);
    return l => {
        if (Gc(l)) {
            if (l.name) {
                const u = (xr(l.name) ? l.name : l.name.toString()).match(i);
                if (u && u.length > 1) return u[1]
            } else if (l.path) {
                const c = l.path.match(o);
                if (c && c.length > 1) return c[1]
            }
        } else if (xr(l)) {
            const c = l.match(o);
            if (c && c.length > 1) return c[1]
        }
        return ""
    }
}

function ni(e, t, {
    defaultLocale: n = CR,
    defaultDirection: r = kR,
    defaultLocaleRouteNameSuffix: a = TR,
    routesNameSeparator: i = SR,
    strategy: o = AR,
    trailingSlash: s = LR,
    localeCodes: l = [],
    prefixable: c = Dg,
    switchLocalePathIntercepter: u = Ng,
    dynamicRouteParamsKey: f = Tg
} = {}) {
    const d = ZR(e);
    return {
        defaultLocale: t.defaultLocale || d.defaultLocale || n,
        defaultDirection: t.defaultDirection || d.defaultDirection || r,
        defaultLocaleRouteNameSuffix: t.defaultLocaleRouteNameSuffix || d.defaultLocaleRouteNameSuffix || a,
        routesNameSeparator: t.routesNameSeparator || d.routesNameSeparator || i,
        strategy: t.strategy || d.strategy || o,
        trailingSlash: t.trailingSlash || d.trailingSlash || s,
        localeCodes: t.localeCodes || d.localeCodes || l,
        prefixable: t.prefixable || d.prefixable || c,
        switchLocalePathIntercepter: t.switchLocalePathIntercepter || d.switchLocalePathIntercepter || u,
        dynamicRouteParamsKey: t.dynamicRouteParamsKey || d.dynamicRouteParamsKey || f,
        dynamicParamsInterceptor: d.dynamicParamsInterceptor || void 0
    }
}

function t1(e, t) {
    return [e.slice(0, t), e.slice(t)]
}

function n1(e) {
    const {
        fullPath: t,
        query: n,
        hash: r,
        name: a,
        path: i,
        params: o,
        meta: s,
        redirectedFrom: l,
        matched: c
    } = e;
    return {
        fullPath: t,
        params: o,
        query: n,
        hash: r,
        name: a,
        path: i,
        meta: s,
        matched: c,
        redirectedFrom: l
    }
}

function r1(e) {
    return UE
}

function a1(e, t, n, r) {
    var a, i;
    if (n !== "prefix") return e.resolve(t);
    const [o, s] = t1(t.path, 1), l = `${o}${r}${s===""?s:`/${s}`}`, c = (i = (a = e.options) == null ? void 0 : a.routes) == null ? void 0 : i.find(f => f.path === l);
    if (c == null) return t;
    const u = xo({}, t, c);
    return u.path = l, e.resolve(u)
}
const i1 = new Set(["prefix_and_default", "prefix_except_default"]);

function o1(e) {
    const {
        currentLocale: t,
        defaultLocale: n,
        strategy: r
    } = e;
    return !(t === n && i1.has(r)) && r !== "no_prefix"
}
const Dg = o1;

function Ir(e) {
    const t = this.router,
        {
            routesNameSeparator: n
        } = ni(t, this),
        r = e != null ? _e(e) ? pe(e) : e : this.route;
    return r == null || !r.name ? void 0 : xg(r.name).split(n)[0]
}

function No(e, t) {
    var n;
    const r = Fo.call(this, e, t);
    return r == null ? "" : ((n = r.redirectedFrom) == null ? void 0 : n.fullPath) || r.fullPath
}

function Wc(e, t) {
    const n = Fo.call(this, e, t);
    return n ? ? void 0
}

function s1(e, t) {
    const n = Fo.call(this, e, t);
    return n ? ? void 0
}

function Fo(e, t) {
    const n = this.router,
        r = this.i18n,
        a = t || Do(r),
        {
            routesNameSeparator: i,
            defaultLocale: o,
            defaultLocaleRouteNameSuffix: s,
            strategy: l,
            trailingSlash: c,
            prefixable: u
        } = ni(n, this);
    let f;
    if (xr(e))
        if (e[0] === "/") {
            const {
                pathname: v,
                search: E,
                hash: w
            } = jR(e), h = DR(E);
            f = {
                path: v,
                query: h,
                hash: w
            }
        } else f = {
            name: e
        };
    else f = e;
    let d = xo({}, f);
    if ((v => "path" in v && !!v.path && !("name" in v))(d)) {
        let v = null;
        try {
            v = a1(n, d, l, a)
        } catch {}
        const E = v,
            w = Ir.call(this, E);
        xr(w) ? (d = {
            name: Pd(w, a, {
                defaultLocale: o,
                strategy: l,
                routesNameSeparator: i,
                defaultLocaleRouteNameSuffix: s
            }),
            params: E.params,
            query: E.query,
            hash: E.hash
        }, d.state = E.state) : (u({
            currentLocale: a,
            defaultLocale: o,
            strategy: l
        }) && (d.path = `/${a}${d.path}`), d.path = c ? BR(d.path, !0) : FR(d.path, !0))
    } else !d.name && !("path" in d) && (d.name = Ir.call(this, this.route)), d.name = Pd(d.name, a, {
        defaultLocale: o,
        strategy: l,
        routesNameSeparator: i,
        defaultLocaleRouteNameSuffix: s
    });
    try {
        const v = n.resolve(d);
        return (r1(v) ? v.name : v.route.name) ? v : n.resolve(e)
    } catch (v) {
        if (typeof v == "object" && "type" in v && v.type === 1) return null
    }
}
const Ng = e => e;

function l1(e, t) {
    const n = {};
    if (t === Tg) return n;
    const r = e.meta;
    return _e(r) ? r.value[t] || n : r[t] || n
}

function Da(e) {
    var t, n;
    const r = this.route,
        a = Ir.call(this, r);
    if (!a) return "";
    const {
        switchLocalePathIntercepter: i,
        dynamicRouteParamsKey: o,
        dynamicParamsInterceptor: s
    } = ni(this.router, this), c = n1(r), u = (n = (t = s == null ? void 0 : s()) == null ? void 0 : t.value) == null ? void 0 : n[e], f = l1(r, o)[e] || {}, d = u ? ? f ? ? {}, p = {
        name: a,
        params: { ...c.params,
            ...d
        }
    }, v = xo({}, c, p);
    let E = No.call(this, v, e);
    return E = i(E, e), E
}

function zc({
    addDirAttribute: e = !1,
    addSeoAttributes: t = !1,
    identifierAttribute: n = "hid"
} = {}) {
    const r = this.router,
        a = this.i18n,
        {
            defaultDirection: i
        } = ni(r, this),
        o = {
            htmlAttrs: {},
            link: [],
            meta: []
        };
    if (a.locales == null || a.baseUrl == null) return o;
    const s = Do(a),
        l = VR(a),
        c = $R(l).find(d => d.code === s) || {
            code: s
        },
        u = c.iso,
        f = c.dir || i;
    return e && (o.htmlAttrs.dir = f), t && s && a.locales && (u && (o.htmlAttrs.lang = u), c1.call(this, l, pe(a.baseUrl), o.link, n), u1.call(this, pe(a.baseUrl), o.link, o.meta, n, t), f1(c, u, o.meta, n), d1(l, u, o.meta, n)), o
}

function c1(e, t, n, r) {
    const a = this.router,
        {
            defaultLocale: i,
            strategy: o
        } = ni(a, this);
    if (o === Sg.NO_PREFIX) return;
    const s = new Map;
    for (const l of e) {
        const c = l.iso;
        if (!c) {
            Mg("Locale ISO code is required to generate alternate link");
            continue
        }
        const [u, f] = c.split("-");
        u && f && (l.isCatchallLocale || !s.has(u)) && s.set(u, l), s.set(c, l)
    }
    for (const [l, c] of s.entries()) {
        const u = Da.call(this, c.code);
        u && n.push({
            [r]: `i18n-alt-${l}`,
            rel: "alternate",
            href: Ol(u, t),
            hreflang: l
        })
    }
    if (i) {
        const l = Da.call(this, i);
        l && n.push({
            [r]: "i18n-xd",
            rel: "alternate",
            href: Ol(l, t),
            hreflang: "x-default"
        })
    }
}

function u1(e, t, n, r, a) {
    const i = this.route,
        o = Wc.call(this, { ...i,
            name: Ir.call(this, i)
        });
    if (o) {
        let s = Ol(o.path, e);
        const l = Gc(a) && a.canonicalQueries || [];
        if (l.length) {
            const c = o.query,
                u = new URLSearchParams;
            for (const d of l)
                if (d in c) {
                    const p = c[d];
                    MR(p) ? p.forEach(v => u.append(d, v || "")) : u.append(d, p || "")
                }
            const f = u.toString();
            f && (s = `${s}?${f}`)
        }
        t.push({
            [r]: "i18n-can",
            rel: "canonical",
            href: s
        }), n.push({
            [r]: "i18n-og-url",
            property: "og:url",
            content: s
        })
    }
}

function f1(e, t, n, r) {
    e && t && n.push({
        [r]: "i18n-og",
        property: "og:locale",
        content: Fg(t)
    })
}

function d1(e, t, n, r) {
    const a = e.filter(i => {
        const o = i.iso;
        return o && o !== t
    });
    if (a.length) {
        const i = a.map(o => ({
            [r]: `i18n-og-alt-${o.iso}`,
            property: "og:locale:alternate",
            content: Fg(o.iso)
        }));
        n.push(...i)
    }
}

function Fg(e) {
    return (e || "").replace(/-/g, "_")
}

function Ol(e, t) {
    return e.match(/^https?:\/\//) ? e : t + e
}

function Bg(e, t) {
    const {
        router: n,
        route: r,
        i18n: a,
        defaultLocale: i,
        strategy: o,
        defaultLocaleRouteNameSuffix: s,
        trailingSlash: l,
        routesNameSeparator: c
    } = e;
    return function(...u) {
        return Reflect.apply(t, {
            router: n,
            route: r,
            i18n: a,
            defaultLocale: i,
            strategy: o,
            defaultLocaleRouteNameSuffix: s,
            trailingSlash: l,
            routesNameSeparator: c
        }, u)
    }
}

function p1({
    router: e = Lc(),
    route: t = So(),
    i18n: n = Kr(),
    defaultLocale: r = void 0,
    defaultLocaleRouteNameSuffix: a = void 0,
    routesNameSeparator: i = void 0,
    strategy: o = void 0,
    trailingSlash: s = void 0
} = {}) {
    return Bg({
        router: e,
        route: t,
        i18n: n,
        defaultLocale: r,
        defaultLocaleRouteNameSuffix: a,
        routesNameSeparator: i,
        strategy: o,
        trailingSlash: s
    }, No)
}

function jg({
    router: e = Lc(),
    route: t = So(),
    i18n: n = Kr(),
    defaultLocale: r = void 0,
    defaultLocaleRouteNameSuffix: a = void 0,
    routesNameSeparator: i = void 0,
    strategy: o = void 0,
    trailingSlash: s = void 0
} = {}) {
    return Bg({
        router: e,
        route: t,
        i18n: n,
        defaultLocale: r,
        defaultLocaleRouteNameSuffix: a,
        routesNameSeparator: i,
        strategy: o,
        trailingSlash: s
    }, Da)
}

function h1({
    addDirAttribute: e = !1,
    addSeoAttributes: t = !1,
    identifierAttribute: n = "hid",
    strategy: r = void 0,
    defaultLocale: a = void 0,
    route: i = So(),
    router: o = Lc(),
    i18n: s = Kr()
} = {}) {
    const l = o,
        c = Q({
            htmlAttrs: {},
            link: [],
            meta: []
        });

    function u() {
        c.value = {
            htmlAttrs: {},
            link: [],
            meta: []
        }
    }

    function f(d) {
        c.value = Reflect.apply(zc, {
            router: o,
            route: d,
            i18n: s,
            defaultLocale: a,
            strategy: r
        }, [{
            addDirAttribute: e,
            addSeoAttributes: t,
            identifierAttribute: n
        }])
    }
    if (Og) {
        const d = lc(() => {
            u(), f(Md(l.currentRoute))
        });
        Rn(() => d())
    } else f(Md(l.currentRoute));
    return c
}
const dr = ["en", "de", "es", "fr", "it", "pl", "pt", "ru", "tr", "uk", "vi", "ar", "th", "ko", "zh", "ja"],
    ys = {
        en: [{
            key: "../locales/en.json",
            load: () => D(() =>
                import ("./en.ea093e64.js"), [],
                import.meta.url),
            cache: !0
        }],
        de: [{
            key: "../locales/de.json",
            load: () => D(() =>
                import ("./de.e4b24b9e.js"), [],
                import.meta.url),
            cache: !0
        }],
        es: [{
            key: "../locales/es.json",
            load: () => D(() =>
                import ("./es.1a5a9219.js"), [],
                import.meta.url),
            cache: !0
        }],
        fr: [{
            key: "../locales/fr.json",
            load: () => D(() =>
                import ("./fr.bd1b771d.js"), [],
                import.meta.url),
            cache: !0
        }],
        it: [{
            key: "../locales/it.json",
            load: () => D(() =>
                import ("./it.ad36b380.js"), [],
                import.meta.url),
            cache: !0
        }],
        pl: [{
            key: "../locales/pl.json",
            load: () => D(() =>
                import ("./pl.1e4edd89.js"), [],
                import.meta.url),
            cache: !0
        }],
        pt: [{
            key: "../locales/pt.json",
            load: () => D(() =>
                import ("./pt.2a63f5b8.js"), [],
                import.meta.url),
            cache: !0
        }],
        ru: [{
            key: "../locales/ru.json",
            load: () => D(() =>
                import ("./ru.710ed566.js"), [],
                import.meta.url),
            cache: !0
        }],
        tr: [{
            key: "../locales/tr.json",
            load: () => D(() =>
                import ("./tr.e223ce9e.js"), [],
                import.meta.url),
            cache: !0
        }],
        uk: [{
            key: "../locales/uk.json",
            load: () => D(() =>
                import ("./uk.58b83978.js"), [],
                import.meta.url),
            cache: !0
        }],
        vi: [{
            key: "../locales/vi.json",
            load: () => D(() =>
                import ("./vi.ec9fa1d5.js"), [],
                import.meta.url),
            cache: !0
        }],
        ar: [{
            key: "../locales/ar.json",
            load: () => D(() =>
                import ("./ar.26d9c66a.js"), [],
                import.meta.url),
            cache: !0
        }],
        th: [{
            key: "../locales/th.json",
            load: () => D(() =>
                import ("./th.4efa6d9d.js"), [],
                import.meta.url),
            cache: !0
        }],
        ko: [{
            key: "../locales/ko.json",
            load: () => D(() =>
                import ("./ko.539483bc.js"), [],
                import.meta.url),
            cache: !0
        }],
        zh: [{
            key: "../locales/zh.json",
            load: () => D(() =>
                import ("./zh.0e6fd766.js"), [],
                import.meta.url),
            cache: !0
        }],
        ja: [{
            key: "../locales/ja.json",
            load: () => D(() =>
                import ("./ja.a32ba470.js"), [],
                import.meta.url),
            cache: !0
        }]
    },
    m1 = [],
    g1 = {
        experimental: {
            localeDetector: ""
        },
        bundle: {
            compositionOnly: !0,
            runtimeOnly: !1,
            fullInstall: !0,
            dropMessageCompiler: !1
        },
        compilation: {
            jit: !0,
            strictMessage: !0,
            escapeHtml: !1
        },
        customBlocks: {
            defaultSFCLang: "json",
            globalSFCScope: !1
        },
        vueI18n: "",
        locales: [{
            code: "en",
            iso: "en",
            name: "English",
            files: ["locales/en.json"]
        }, {
            code: "de",
            iso: "de",
            name: "Deutsch",
            files: ["locales/de.json"]
        }, {
            code: "es",
            iso: "es",
            name: "Español",
            files: ["locales/es.json"]
        }, {
            code: "fr",
            iso: "fr",
            name: "Français",
            files: ["locales/fr.json"]
        }, {
            code: "it",
            iso: "it",
            name: "Italiano",
            files: ["locales/it.json"]
        }, {
            code: "pl",
            iso: "pl",
            name: "Polski",
            files: ["locales/pl.json"]
        }, {
            code: "pt",
            iso: "pt",
            name: "Português",
            files: ["locales/pt.json"]
        }, {
            code: "ru",
            iso: "ru",
            name: "Русский",
            files: ["locales/ru.json"]
        }, {
            code: "tr",
            iso: "tr",
            name: "Türkçe",
            files: ["locales/tr.json"]
        }, {
            code: "uk",
            iso: "uk",
            name: "Українська",
            files: ["locales/uk.json"]
        }, {
            code: "vi",
            iso: "vi",
            name: "Tiếng Việt",
            files: ["locales/vi.json"]
        }, {
            code: "ar",
            iso: "ar",
            name: "العربية",
            files: ["locales/ar.json"]
        }, {
            code: "th",
            iso: "th",
            name: "ไทย",
            files: ["locales/th.json"]
        }, {
            code: "ko",
            iso: "ko",
            name: "한국어",
            files: ["locales/ko.json"]
        }, {
            code: "zh",
            iso: "zh",
            name: "中文",
            files: ["locales/zh.json"]
        }, {
            code: "ja",
            iso: "ja",
            name: "日本語",
            files: ["locales/ja.json"]
        }],
        defaultLocale: "en",
        defaultDirection: "ltr",
        routesNameSeparator: "___",
        trailingSlash: !0,
        defaultLocaleRouteNameSuffix: "default",
        strategy: "prefix",
        lazy: !0,
        langDir: "locales/",
        rootRedirect: null,
        detectBrowserLanguage: {
            alwaysRedirect: !0,
            cookieCrossOrigin: !1,
            cookieDomain: null,
            cookieKey: "i18n_redirected",
            cookieSecure: !1,
            fallbackLocale: "en",
            redirectOn: "root",
            useCookie: !0
        },
        differentDomains: !1,
        baseUrl: "https://mail.tm",
        dynamicRouteParams: !1,
        customRoutes: "page",
        pages: {},
        skipSettingLocaleOnNavigate: !1,
        types: "composition",
        debug: !1,
        parallelPlugin: !1,
        i18nModules: []
    },
    gt = {
        experimental: {
            localeDetector: ""
        },
        bundle: {
            compositionOnly: !0,
            runtimeOnly: !1,
            fullInstall: !0,
            dropMessageCompiler: !1
        },
        compilation: {
            jit: !0,
            strictMessage: !0,
            escapeHtml: !1
        },
        customBlocks: {
            defaultSFCLang: "json",
            globalSFCScope: !1
        },
        vueI18n: "",
        locales: [],
        defaultLocale: "",
        defaultDirection: "ltr",
        routesNameSeparator: "___",
        trailingSlash: !1,
        defaultLocaleRouteNameSuffix: "default",
        strategy: "prefix_except_default",
        lazy: !1,
        langDir: null,
        rootRedirect: null,
        detectBrowserLanguage: {
            alwaysRedirect: !1,
            cookieCrossOrigin: !1,
            cookieDomain: null,
            cookieKey: "i18n_redirected",
            cookieSecure: !1,
            fallbackLocale: "",
            redirectOn: "root",
            useCookie: !0
        },
        differentDomains: !1,
        baseUrl: "",
        dynamicRouteParams: !1,
        customRoutes: "page",
        pages: {},
        skipSettingLocaleOnNavigate: !1,
        types: "composition",
        debug: !1,
        parallelPlugin: !1
    },
    Ml = {
        __normalizedLocales: [{
            code: "en",
            iso: "en",
            name: "English",
            files: [{
                path: "locales/en.json"
            }]
        }, {
            code: "de",
            iso: "de",
            name: "Deutsch",
            files: [{
                path: "locales/de.json"
            }]
        }, {
            code: "es",
            iso: "es",
            name: "Español",
            files: [{
                path: "locales/es.json"
            }]
        }, {
            code: "fr",
            iso: "fr",
            name: "Français",
            files: [{
                path: "locales/fr.json"
            }]
        }, {
            code: "it",
            iso: "it",
            name: "Italiano",
            files: [{
                path: "locales/it.json"
            }]
        }, {
            code: "pl",
            iso: "pl",
            name: "Polski",
            files: [{
                path: "locales/pl.json"
            }]
        }, {
            code: "pt",
            iso: "pt",
            name: "Português",
            files: [{
                path: "locales/pt.json"
            }]
        }, {
            code: "ru",
            iso: "ru",
            name: "Русский",
            files: [{
                path: "locales/ru.json"
            }]
        }, {
            code: "tr",
            iso: "tr",
            name: "Türkçe",
            files: [{
                path: "locales/tr.json"
            }]
        }, {
            code: "uk",
            iso: "uk",
            name: "Українська",
            files: [{
                path: "locales/uk.json"
            }]
        }, {
            code: "vi",
            iso: "vi",
            name: "Tiếng Việt",
            files: [{
                path: "locales/vi.json"
            }]
        }, {
            code: "ar",
            iso: "ar",
            name: "العربية",
            files: [{
                path: "locales/ar.json"
            }]
        }, {
            code: "th",
            iso: "th",
            name: "ไทย",
            files: [{
                path: "locales/th.json"
            }]
        }, {
            code: "ko",
            iso: "ko",
            name: "한국어",
            files: [{
                path: "locales/ko.json"
            }]
        }, {
            code: "zh",
            iso: "zh",
            name: "中文",
            files: [{
                path: "locales/zh.json"
            }]
        }, {
            code: "ja",
            iso: "ja",
            name: "日本語",
            files: [{
                path: "locales/ja.json"
            }]
        }]
    },
    $g = "@nuxtjs/i18n",
    y1 = !1,
    b1 = !1;
async function v1(e, t) {
    const n = {
        messages: {}
    };
    for (const r of e) {
        const {
            default: a
        } = await r(), i = typeof a == "function" ? await t.runWithContext(async () => await a()) : a;
        An(i, n)
    }
    return n
}

function Vg(e, t) {
    let n = [];
    if (He(e)) n = e;
    else if (be(e)) {
        const r = [...t, "default"];
        for (const a of r) e[a] && (n = [...n, ...e[a].filter(Boolean)])
    } else Y(e) && t.every(r => r !== e) && n.push(e);
    return n
}
async function _1(e, t, n) {
    const {
        defaultLocale: r,
        initialLocale: a,
        localeCodes: i,
        fallbackLocale: o,
        lazy: s,
        cacheMessages: l
    } = n, c = (f, d) => {
        const p = e[f] || {};
        An(d, p), e[f] = p
    };
    if (s && o) {
        const f = Vg(o, [r, a]);
        await Promise.all(f.map(d => no({
            locale: d,
            setter: c,
            localeMessages: t
        }, l)))
    }
    const u = s ? [...new Set().add(r).add(a)] : i;
    return await Promise.all(u.map(f => no({
        locale: f,
        setter: c,
        localeMessages: t
    }, l))), e
}
async function w1(e, {
    key: t,
    load: n
}, r) {
    let a = null;
    try {
        const i = await n().then(o => o.default || o);
        Se(i) ? a = await i(e) : (a = i, a != null && r && r.set(t, a))
    } catch (i) {
        console.error("Failed locale loading: " + i.message)
    }
    return a
}
async function no({
    locale: e,
    localeMessages: t,
    setter: n
}, r) {
    const a = t[e];
    if (a == null) {
        console.warn("Could not find messages for locale code: " + e);
        return
    }
    const i = {};
    for (const o of a) {
        let s = null;
        r && r.has(o.key) && o.cache ? s = r.get(o.key) : s = await w1(e, o, r), s != null && An(s, i)
    }
    n(e, i)
}

function E1(e) {
    return $g + " " + e
}

function C1(e) {
    return e != null && ("__VUE_I18N_BRIDGE__" in e || "_sync" in e)
}

function Bo(e, t, ...n) {
    const r = lr(e) ? e.global : e,
        [a, i] = [r, r[t]];
    return Reflect.apply(i, a, [...n])
}

function A1(e, t) {
    const n = lr(e) ? e.global : e;
    return Ur(n) ? n[t].value : (ti(n) || cr(n) || C1(n), n[t])
}

function Dd(e, t, n) {
    Object.defineProperty(e, t, {
        get: () => n
    })
}

function L1(e, t) {
    return function() {
        return Reflect.apply(t, {
            i18n: e.$i18n,
            getRouteBaseName: e.$getRouteBaseName,
            localePath: e.$localePath,
            localeRoute: e.$localeRoute,
            switchLocalePath: e.$switchLocalePath,
            localeHead: e.$localeHead,
            route: e.$router.currentRoute.value,
            router: e.$router
        }, arguments)
    }
}

function Hg(e) {
    let t;
    return navigator.languages && (t = WR(e.__normalizedLocales, navigator.languages)), t
}

function qc({
    useCookie: e = gt.detectBrowserLanguage.useCookie,
    cookieKey: t = gt.detectBrowserLanguage.cookieKey,
    localeCodes: n = []
} = {}) {
    if (!e) return;
    const a = am(t).value ? ? void 0;
    if (a && n.includes(a)) return a
}

function S1(e, {
    useCookie: t = gt.detectBrowserLanguage.useCookie,
    cookieKey: n = gt.detectBrowserLanguage.cookieKey,
    cookieDomain: r = gt.detectBrowserLanguage.cookieDomain,
    cookieSecure: a = gt.detectBrowserLanguage.cookieSecure,
    cookieCrossOrigin: i = gt.detectBrowserLanguage.cookieCrossOrigin
} = {}) {
    if (!t) return;
    const o = new Date,
        s = {
            expires: new Date(o.setDate(o.getDate() + 365)),
            path: "/",
            sameSite: i ? "none" : "lax",
            secure: i || a
        };
    r && (s.domain = r);
    const l = am(n, s);
    l.value = e
}
const T1 = {
    locale: "",
    stat: !1,
    reason: "unknown",
    from: "unknown"
};

function k1(e, t, n, r, a, i = [], o = "") {
    const {
        strategy: s
    } = t, {
        ssg: l,
        callType: c,
        firstAccess: u
    } = a;
    if (!u) return {
        locale: s === "no_prefix" ? o : "",
        stat: !1,
        reason: "first_access_only"
    };
    const {
        redirectOn: f,
        alwaysRedirect: d,
        useCookie: p,
        fallbackLocale: v
    } = t.detectBrowserLanguage, E = Y(e) ? e : e.path;
    if (s !== "no_prefix") {
        if (f === "root") {
            if (E !== "/") return {
                locale: "",
                stat: !1,
                reason: "not_redirect_on_root"
            }
        } else if (f === "no prefix" && !d && E.match(Rl(i))) return {
            locale: "",
            stat: !1,
            reason: "not_redirect_on_no_prefix"
        }
    }
    let w = "unknown",
        h, b;
    p && (b = h = qc({ ...t.detectBrowserLanguage,
        localeCodes: i
    }), w = "cookie"), b || (b = Hg(n), w = "navigator_or_header");
    const m = b || v;
    !b && v && (w = "fallback");
    const y = o || r.locale;
    if (m && (!p || d || !h)) {
        if (s === "no_prefix") return {
            locale: m,
            stat: !0,
            from: w
        };
        if (c === "setup" && m !== y) return {
            locale: m,
            stat: !0,
            from: w
        };
        if (d) {
            const C = E === "/",
                S = f === "all",
                A = f === "no prefix" && !E.match(Rl(i));
            if (C || S || A) return {
                locale: m,
                stat: !0,
                from: w
            }
        }
    }
    return l === "ssg_setup" && m ? {
        locale: m,
        stat: !0,
        from: w
    } : (w === "navigator_or_header" || w === "cookie") && m ? {
        locale: m,
        stat: !0,
        from: w
    } : {
        locale: "",
        stat: !1,
        reason: "not_found_match"
    }
}

function R1() {
    let e;
    return e = window.location.host, e
}

function O1(e) {
    let t = R1() || "";
    if (t) {
        const n = e.find(r => {
            if (r && r.domain) {
                let a = r.domain;
                return or(r.domain) && (a = r.domain.replace(/(http|https):\/\//, "")), a === t
            }
            return !1
        });
        if (n) return n.code;
        t = ""
    }
    return t
}

function Kg(e, t) {
    var o, s;
    const r = Nt().public.i18n,
        a = t.find(l => l.code === e),
        i = ((s = (o = r == null ? void 0 : r.locales) == null ? void 0 : o[e]) == null ? void 0 : s.domain) ? ? (a == null ? void 0 : a.domain);
    if (i) {
        if (or(i, {
                strict: !0
            })) return i;
        let l;
        return l = new URL(window.location.origin).protocol, l + "//" + i
    }
    console.warn(E1("Could not find domain name for locale " + e))
}

function M1(e, t) {
    return Bo(e, "setLocaleCookie", t)
}

function P1(e, t, n) {
    return Bo(e, "mergeLocaleMessage", t, n)
}

function x1(e, t, n, r, a) {
    return Bo(e, "onBeforeLanguageSwitch", t, n, r, a)
}

function I1(e, t, n) {
    return Bo(e, "onLanguageSwitched", t, n)
}
async function Nd(e, t, n, {
    useCookie: r = gt.detectBrowserLanguage.useCookie,
    skipSettingLocaleOnNavigate: a = gt.skipSettingLocaleOnNavigate,
    differentDomains: i = gt.differentDomains,
    initial: o = !1,
    cacheMessages: s = void 0,
    lazy: l = !1
} = {}) {
    const c = ge();
    let u = !1;
    const f = Do(n);
    if (!e) return [u, f];
    if (!o && i) return [u, f];
    if (f === e) return [u, f];
    const d = await x1(n, f, e, o, c),
        p = HR(n);
    if (d && p && p.includes(d)) {
        if (d === f) return [u, f];
        e = d
    }
    const v = A1(n, "fallbackLocale");
    if (l) {
        const E = (w, h) => P1(n, w, h);
        if (v) {
            const w = Vg(v, [e]);
            await Promise.all(w.map(h => no({
                locale: h,
                setter: E,
                localeMessages: t
            }, s)))
        }
        await no({
            locale: e,
            setter: E,
            localeMessages: t
        }, s)
    }
    return a ? [u, f] : (r && M1(n, e), Pg(n, e), await I1(n, f, e), u = !0, [u, f])
}

function Fd(e, t, n, r, a, i, o, s = []) {
    const {
        strategy: l,
        defaultLocale: c,
        differentDomains: u
    } = n, f = Se(a) ? a() : a, {
        locale: d,
        stat: p,
        reason: v,
        from: E
    } = n.detectBrowserLanguage ? k1(e, n, Ml, r, i, s, f) : T1;
    if (v === "detect_ignore_on_ssg") return f;
    if ((E === "navigator_or_header" || E === "cookie" || E === "fallback") && d) return d;
    let w = d;
    return w || (u ? w = O1(o) : l !== "no_prefix" ? w = t(e) : n.detectBrowserLanguage || (w = f)), !w && n.detectBrowserLanguage && n.detectBrowserLanguage.useCookie && (w = qc({ ...n.detectBrowserLanguage,
        localeCodes: s
    }) || ""), w || (w = c || ""), w
}

function Bd({
    route: e,
    targetLocale: t,
    routeLocaleGetter: n,
    nuxtI18nOptions: r,
    calledWithRouting: a = !1
}) {
    const i = ge(),
        {
            strategy: o,
            differentDomains: s
        } = r;
    let l = "";
    const {
        fullPath: c
    } = e.to;
    if (!s && (a || o !== "no_prefix") && n(e.to) !== t) {
        const u = i.$switchLocalePath(t) || i.$localePath(c, t);
        Y(u) && u && !Vs(u, c) && !u.startsWith("//") && (l = e.from && e.from.fullPath === u ? "" : u)
    }
    if ((s || b1) && n(e.to) !== t) {
        const f = jg({
            i18n: kn(i.$i18n),
            route: e.to,
            router: i.$router
        })(t);
        Y(f) && f && !Vs(f, c) && !f.startsWith("//") && (l = f)
    }
    return l
}

function D1(e) {
    return be(e) && "path" in e && "statusCode" in e
}
const N1 = () => qa($g + ":redirect", () => "");

function jd(e, t) {
    return Dh(e, {
        redirectCode: t
    })
}
async function $d(e, {
    status: t = 302,
    rootRedirect: n = gt.rootRedirect,
    differentDomains: r = gt.differentDomains,
    skipSettingLocaleOnNavigate: a = gt.skipSettingLocaleOnNavigate,
    enableNavigate: i = !1
} = {}) {
    const {
        i18n: o,
        locale: s,
        route: l
    } = e;
    let {
        redirectPath: c
    } = e;
    if (l.path === "/" && n) return Y(n) ? c = "/" + n : D1(n) && (c = "/" + n.path, t = n.statusCode), jd(c, t);
    if (!(a && (o.__pendingLocale = s, o.__pendingLocalePromise = new Promise(u => {
            o.__resolvePendingLocalePromise = u
        }), !i))) {
        if (r) {
            const u = N1();
            u.value && u.value !== c && (u.value = "", window.location.assign(c))
        } else if (c) return jd(c, t)
    }
}

function F1(e, t) {
    Dd(e, "$i18n", t.global);
    for (const n of [
            ["getRouteBaseName", Ir],
            ["localePath", No],
            ["localeRoute", Wc],
            ["switchLocalePath", Da],
            ["localeHead", zc]
        ]) Dd(e, "$" + n[0], L1(e, n[1]))
}

function B1(e) {
    return t => Dg(t) && !e
}

function j1(e, t) {
    return (n, r) => {
        if (e) {
            const a = Kg(r, t);
            return a ? $r(a, n) : n
        } else return Ng(n)
    }
}

function $1(e, t) {
    return () => {
        var c;
        const n = ge(),
            r = Nt();
        if (Se(e)) return e(n);
        const {
            differentDomains: a,
            localeCodeLoader: i,
            normalizedLocales: o
        } = t, s = Se(i) ? i() : i;
        if (a && s) {
            const u = Kg(s, o);
            if (u) return u
        }
        const l = (c = r == null ? void 0 : r.public) == null ? void 0 : c.i18n;
        return l != null && l.baseUrl ? l.baseUrl : e
    }
}
const bs = new Map,
    V1 = Qe({
        name: "i18n:plugin",
        parallel: y1,
        async setup(e) {
            let t, n;
            const r = pt(),
                a = Hr(),
                {
                    vueApp: i
                } = e,
                o = e,
                s = { ...g1
                },
                l = ([t, n] = Cn(() => v1(m1, ge())), t = await t, n(), t),
                c = s.detectBrowserLanguage && s.detectBrowserLanguage.useCookie,
                {
                    __normalizedLocales: u
                } = Ml,
                {
                    defaultLocale: f,
                    differentDomains: d,
                    skipSettingLocaleOnNavigate: p,
                    lazy: v,
                    routesNameSeparator: E,
                    defaultLocaleRouteNameSuffix: w,
                    strategy: h,
                    rootRedirect: b
                } = s;
            s.baseUrl = $1(s.baseUrl, {
                differentDomains: d,
                localeCodeLoader: f,
                normalizedLocales: u
            });
            const m = e1(dr, E, w);
            l.messages = l.messages || {}, l.fallbackLocale = l.fallbackLocale ? ? !1, QR(r, { ...s,
                dynamicRouteParamsKey: "nuxtI18n",
                switchLocalePathIntercepter: j1(d, u),
                prefixable: B1(d)
            });
            const y = x => x || l.locale || "en-US";
            let C = Fd(a, m, s, l, y(f), {
                ssg: "normal",
                callType: "setup",
                firstAccess: !0
            }, u, dr);
            l.messages = ([t, n] = Cn(() => _1(l.messages, ys, { ...s,
                initialLocale: C,
                fallbackLocale: l.fallbackLocale,
                localeCodes: dr,
                cacheMessages: bs
            })), t = await t, n(), t), C = y(C);
            const S = pR({ ...l,
                locale: C
            });
            let A = !0;
            const R = x => C !== x && A;
            zR(S, {
                locales: s.locales,
                localeCodes: dr,
                baseUrl: s.baseUrl,
                context: o,
                hooks: {
                    onExtendComposer(x) {
                        x.strategy = h, x.localeProperties = W(() => u.find(M => M.code === x.locale.value) || {
                            code: x.locale.value
                        }), x.setLocale = async M => {
                            const K = R(M),
                                [ne] = await Nd(M, ys, S, {
                                    useCookie: c,
                                    differentDomains: d,
                                    initial: K,
                                    cacheMessages: bs,
                                    skipSettingLocaleOnNavigate: p,
                                    lazy: v
                                });
                            ne && K && (A = !1);
                            const te = Bd({
                                route: {
                                    to: a
                                },
                                targetLocale: M,
                                routeLocaleGetter: m,
                                nuxtI18nOptions: s
                            });
                            await $d({
                                i18n: S,
                                redirectPath: te,
                                locale: M,
                                route: a
                            }, {
                                differentDomains: d,
                                skipSettingLocaleOnNavigate: p,
                                rootRedirect: b,
                                enableNavigate: !0
                            })
                        }, x.differentDomains = d, x.defaultLocale = f, x.getBrowserLocale = () => Hg(Ml), x.getLocaleCookie = () => qc({ ...s.detectBrowserLanguage,
                            localeCodes: dr
                        }), x.setLocaleCookie = M => S1(M, s.detectBrowserLanguage || void 0), x.onBeforeLanguageSwitch = (M, K, ne, te) => e.callHook("i18n:beforeLocaleSwitch", {
                            oldLocale: M,
                            newLocale: K,
                            initialSetup: ne,
                            context: te
                        }), x.onLanguageSwitched = (M, K) => e.callHook("i18n:localeSwitched", {
                            oldLocale: M,
                            newLocale: K
                        }), x.finalizePendingLocaleChange = async () => {
                            S.__pendingLocale && (Pg(S, S.__pendingLocale), S.__resolvePendingLocalePromise && await S.__resolvePendingLocalePromise(), S.__pendingLocale = void 0)
                        }, x.waitForPendingLocaleChange = async () => {
                            S.__pendingLocale && S.__pendingLocalePromise && await S.__pendingLocalePromise
                        }
                    },
                    onExtendExportedGlobal(x) {
                        return {
                            strategy: {
                                get() {
                                    return x.strategy
                                }
                            },
                            localeProperties: {
                                get() {
                                    return x.localeProperties.value
                                }
                            },
                            setLocale: {
                                get() {
                                    return async M => Reflect.apply(x.setLocale, x, [M])
                                }
                            },
                            differentDomains: {
                                get() {
                                    return x.differentDomains
                                }
                            },
                            defaultLocale: {
                                get() {
                                    return x.defaultLocale
                                }
                            },
                            getBrowserLocale: {
                                get() {
                                    return () => Reflect.apply(x.getBrowserLocale, x, [])
                                }
                            },
                            getLocaleCookie: {
                                get() {
                                    return () => Reflect.apply(x.getLocaleCookie, x, [])
                                }
                            },
                            setLocaleCookie: {
                                get() {
                                    return M => Reflect.apply(x.setLocaleCookie, x, [M])
                                }
                            },
                            onBeforeLanguageSwitch: {
                                get() {
                                    return (M, K, ne, te) => Reflect.apply(x.onBeforeLanguageSwitch, x, [M, K, ne, te])
                                }
                            },
                            onLanguageSwitched: {
                                get() {
                                    return (M, K) => Reflect.apply(x.onLanguageSwitched, x, [M, K])
                                }
                            },
                            finalizePendingLocaleChange: {
                                get() {
                                    return () => Reflect.apply(x.finalizePendingLocaleChange, x, [])
                                }
                            },
                            waitForPendingLocaleChange: {
                                get() {
                                    return () => Reflect.apply(x.waitForPendingLocaleChange, x, [])
                                }
                            }
                        }
                    },
                    onExtendVueI18n(x) {
                        return {
                            strategy: {
                                get() {
                                    return x.strategy
                                }
                            },
                            localeProperties: {
                                get() {
                                    return x.localeProperties.value
                                }
                            },
                            setLocale: {
                                get() {
                                    return async M => Reflect.apply(x.setLocale, x, [M])
                                }
                            },
                            differentDomains: {
                                get() {
                                    return x.differentDomains
                                }
                            },
                            defaultLocale: {
                                get() {
                                    return x.defaultLocale
                                }
                            },
                            getBrowserLocale: {
                                get() {
                                    return () => Reflect.apply(x.getBrowserLocale, x, [])
                                }
                            },
                            getLocaleCookie: {
                                get() {
                                    return () => Reflect.apply(x.getLocaleCookie, x, [])
                                }
                            },
                            setLocaleCookie: {
                                get() {
                                    return M => Reflect.apply(x.setLocaleCookie, x, [M])
                                }
                            },
                            onBeforeLanguageSwitch: {
                                get() {
                                    return (M, K, ne, te) => Reflect.apply(x.onBeforeLanguageSwitch, x, [M, K, ne, te])
                                }
                            },
                            onLanguageSwitched: {
                                get() {
                                    return (M, K) => Reflect.apply(x.onLanguageSwitched, x, [M, K])
                                }
                            },
                            finalizePendingLocaleChange: {
                                get() {
                                    return () => Reflect.apply(x.finalizePendingLocaleChange, x, [])
                                }
                            },
                            waitForPendingLocaleChange: {
                                get() {
                                    return () => Reflect.apply(x.waitForPendingLocaleChange, x, [])
                                }
                            }
                        }
                    }
                }
            });
            const O = {
                __composerExtend: x => {
                    const M = kn(S);
                    return x.strategy = M.strategy, x.localeProperties = W(() => M.localeProperties.value), x.setLocale = M.setLocale, x.differentDomains = M.differentDomains, x.getBrowserLocale = M.getBrowserLocale, x.getLocaleCookie = M.getLocaleCookie, x.setLocaleCookie = M.setLocaleCookie, x.onBeforeLanguageSwitch = M.onBeforeLanguageSwitch, x.onLanguageSwitched = M.onLanguageSwitched, x.finalizePendingLocaleChange = M.finalizePendingLocaleChange, x.waitForPendingLocaleChange = M.waitForPendingLocaleChange, () => {}
                }
            };
            i.use(S, O), F1(o, S);
            let N = 0;
            gw("locale-changing", async (x, M) => {
                let K, ne;
                const te = Fd(x, m, s, l, () => Do(S) || y(f), {
                        ssg: "normal",
                        callType: "routing",
                        firstAccess: N === 0
                    }, u, dr),
                    J = R(te),
                    [ae] = ([K, ne] = Cn(() => Nd(te, ys, S, {
                        useCookie: c,
                        differentDomains: d,
                        initial: J,
                        cacheMessages: bs,
                        skipSettingLocaleOnNavigate: p,
                        lazy: v
                    })), K = await K, ne(), K);
                ae && J && (A = !1);
                const X = Bd({
                    route: {
                        to: x,
                        from: M
                    },
                    targetLocale: te,
                    routeLocaleGetter: s.strategy === "no_prefix" ? () => te : m,
                    nuxtI18nOptions: s,
                    calledWithRouting: !0
                });
                return N++, $d({
                    i18n: S,
                    redirectPath: X,
                    locale: te,
                    route: x
                }, {
                    differentDomains: d,
                    skipSettingLocaleOnNavigate: p,
                    rootRedirect: b
                })
            }, {
                global: !0
            })
        }
    });

function H1(e = {}) {
    const {
        immediate: t = !1,
        onNeedRefresh: n,
        onOfflineReady: r,
        onRegistered: a,
        onRegisteredSW: i,
        onRegisterError: o
    } = e;
    let s, l;
    const c = async (f = !0) => {
        await l
    };
    async function u() {
        if ("serviceWorker" in navigator) {
            const {
                Workbox: f
            } = await D(() =>
                import ("./workbox-window.prod.es5.a7b12eab.js"), [],
                import.meta.url);
            s = new f("/sw.js", {
                scope: "/",
                type: "classic"
            }), s.addEventListener("activated", d => {
                (d.isUpdate || d.isExternal) && window.location.reload()
            }), s.addEventListener("installed", d => {
                d.isUpdate || r == null || r()
            }), s.register({
                immediate: t
            }).then(d => {
                i ? i("/sw.js", d) : a == null || a(d)
            }).catch(d => {
                o == null || o(d)
            })
        }
    }
    return l = u(), c
}

function K1(e = {}) {
    const {
        immediate: t = !0,
        onNeedRefresh: n,
        onOfflineReady: r,
        onRegistered: a,
        onRegisteredSW: i,
        onRegisterError: o
    } = e, s = Q(!1), l = Q(!1);
    return {
        updateServiceWorker: H1({
            immediate: t,
            onNeedRefresh() {
                s.value = !0, n == null || n()
            },
            onOfflineReady() {
                l.value = !0, r == null || r()
            },
            onRegistered: a,
            onRegisteredSW: i,
            onRegisterError: o
        }),
        offlineReady: l,
        needRefresh: s
    }
}
const U1 = "standalone",
    J1 = void 0,
    G1 = Qe(() => {
        const e = Q(!1),
            t = Q(!1),
            n = Q(!1),
            r = Q(!0),
            a = navigator.userAgent,
            i = a.match(/iPhone|iPad|iPod/),
            o = `${U1}`,
            s = window.matchMedia(`(display-mode: ${o})`).matches,
            l = Q(!!(s || i && !a.match(/Safari/))),
            c = Q(l.value);
        window.matchMedia(`(display-mode: ${o})`).addEventListener("change", b => {
            !c.value && b.matches && (c.value = !0)
        });
        let u;
        const f = () => u,
            {
                offlineReady: d,
                needRefresh: p,
                updateServiceWorker: v
            } = K1({
                immediate: !0,
                onRegisterError() {
                    e.value = !0
                },
                onRegisteredSW(b, m) {
                    u = m
                }
            }),
            E = async () => {
                d.value = !1, p.value = !1
            };
        let w = () => Promise.resolve(),
            h = () => {};
        if (!r.value) {
            let b;
            const m = y => {
                y.preventDefault(), b = y, n.value = !0
            };
            window.addEventListener("beforeinstallprompt", m), window.addEventListener("appinstalled", () => {
                b = void 0, n.value = !1
            }), h = () => {
                b = void 0, n.value = !1, window.removeEventListener("beforeinstallprompt", m), r.value = !0, localStorage.setItem(J1, "true")
            }, w = async () => {
                if (!n.value || !b) {
                    n.value = !1;
                    return
                }
                n.value = !1, await St(), b.prompt(), await b.userChoice
            }
        }
        return {
            provide: {
                pwa: tt({
                    isInstalled: l,
                    isPWAInstalled: c,
                    showInstallPrompt: n,
                    cancelInstall: h,
                    install: w,
                    swActivated: t,
                    registrationError: e,
                    offlineReady: d,
                    needRefresh: p,
                    updateServiceWorker: v,
                    cancelPrompt: E,
                    getSWRegistration: f
                })
            }
        }
    }),
    W1 = "__NUXT_COLOR_MODE__",
    RP = "ColorScheme",
    z1 = "nuxt-color-mode",
    zt = window[W1] || {},
    q1 = Qe(e => {
        const t = qa("color-mode", () => tt({
            preference: zt.preference,
            value: zt.value,
            unknown: !1,
            forced: !1
        })).value;
        pt().afterEach(a => {
            const i = a.meta.colorMode;
            i && i !== "system" ? (t.value = i, t.forced = !0) : (i === "system" && console.warn("You cannot force the colorMode to system at the page level."), t.forced = !1, t.value = t.preference === "system" ? zt.getColorScheme() : t.preference)
        });
        let n;

        function r() {
            n || !window.matchMedia || (n = window.matchMedia("(prefers-color-scheme: dark)"), n.addEventListener("change", () => {
                !t.forced && t.preference === "system" && (t.value = zt.getColorScheme())
            }))
        }
        we(() => t.preference, a => {
            var i;
            t.forced || (a === "system" ? (t.value = zt.getColorScheme(), r()) : t.value = a, (i = window.localStorage) == null || i.setItem(z1, a))
        }, {
            immediate: !0
        }), we(() => t.value, (a, i) => {
            zt.removeColorScheme(i), zt.addColorScheme(a)
        }), t.preference === "system" && r(), e.hook("app:mounted", () => {
            t.unknown && (t.preference = zt.preference, t.value = zt.value, t.unknown = !1)
        }), e.provide("colorMode", t)
    }),
    Y1 = Qe({
        name: "nuxt:chunk-reload",
        setup(e) {
            const t = pt(),
                n = Nt(),
                r = new Set;
            t.beforeEach(() => {
                r.clear()
            }), e.hook("app:chunkError", ({
                error: i
            }) => {
                r.add(i)
            });

            function a(i) {
                const s = "href" in i && i.href.startsWith("#") ? n.app.baseURL + i.href : $r(n.app.baseURL, i.fullPath);
                sC({
                    path: s,
                    persistState: !0
                })
            }
            e.hook("app:manifest:update", () => {
                t.beforeResolve(a)
            }), t.onError((i, o) => {
                r.has(i) && a(o)
            })
        }
    }),
    X1 = Qe(e => {
        let t;
        async function n() {
            const r = await Fh();
            t && clearTimeout(t), t = setTimeout(n, 1e3 * 60 * 60);
            const a = await $fetch(bc("builds/latest.json"));
            a.id !== r.id && e.hooks.callHook("app:manifest:update", a)
        }
        tm(() => {
            t = setTimeout(n, 1e3 * 60 * 60)
        })
    });

function Ug() {
    const e = qa("notifications", () => []);

    function t(r) {
        const a = {
            id: new Date().getTime().toString(),
            ...r
        };
        return e.value.findIndex(o => o.id === a.id) === -1 && e.value.push(a), a
    }

    function n(r) {
        e.value = e.value.filter(a => a.id !== r)
    }
    return {
        add: t,
        remove: n
    }
}
async function Q1(e, t) {
    const n = e.getReader();
    let r;
    for (; !(r = await n.read()).done;) t(r.value)
}

function Z1(e) {
    let t, n, r, a = !1;
    return function(o) {
        t === void 0 ? (t = o, n = 0, r = -1) : t = tO(t, o);
        const s = t.length;
        let l = 0;
        for (; n < s;) {
            a && (t[n] === 10 && (l = ++n), a = !1);
            let c = -1;
            for (; n < s && c === -1; ++n) switch (t[n]) {
                case 58:
                    r === -1 && (r = n - l);
                    break;
                case 13:
                    a = !0;
                case 10:
                    c = n;
                    break
            }
            if (c === -1) break;
            e(t.subarray(l, c), r), l = n, r = -1
        }
        l === s ? t = void 0 : l !== 0 && (t = t.subarray(l), n -= l)
    }
}

function eO(e, t, n) {
    let r = Vd();
    const a = new TextDecoder;
    return function(o, s) {
        if (o.length === 0) n == null || n(r), r = Vd();
        else if (s > 0) {
            const l = a.decode(o.subarray(0, s)),
                c = s + (o[s + 1] === 32 ? 2 : 1),
                u = a.decode(o.subarray(c));
            switch (l) {
                case "data":
                    r.data = r.data ? r.data + `
` + u : u;
                    break;
                case "event":
                    r.event = u;
                    break;
                case "id":
                    e(r.id = u);
                    break;
                case "retry":
                    const f = parseInt(u, 10);
                    isNaN(f) || t(r.retry = f);
                    break
            }
        }
    }
}

function tO(e, t) {
    const n = new Uint8Array(e.length + t.length);
    return n.set(e), n.set(t, e.length), n
}

function Vd() {
    return {
        data: "",
        event: "",
        id: "",
        retry: void 0
    }
}
var nO = globalThis && globalThis.__rest || function(e, t) {
    var n = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
        for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++) t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
    return n
};
const Pl = "text/event-stream",
    rO = 1e3,
    Hd = "last-event-id";

function aO(e, t) {
    var {
        signal: n,
        headers: r,
        onopen: a,
        onmessage: i,
        onclose: o,
        onerror: s,
        openWhenHidden: l,
        fetch: c
    } = t, u = nO(t, ["signal", "headers", "onopen", "onmessage", "onclose", "onerror", "openWhenHidden", "fetch"]);
    return new Promise((f, d) => {
        const p = Object.assign({}, r);
        p.accept || (p.accept = Pl);
        let v;

        function E() {
            v.abort(), document.hidden || C()
        }
        l || document.addEventListener("visibilitychange", E);
        let w = rO,
            h = 0;

        function b() {
            document.removeEventListener("visibilitychange", E), window.clearTimeout(h), v.abort()
        }
        n == null || n.addEventListener("abort", () => {
            b(), f()
        });
        const m = c ? ? window.fetch,
            y = a ? ? iO;
        async function C() {
            var S;
            v = new AbortController;
            try {
                const A = await m(e, Object.assign(Object.assign({}, u), {
                    headers: p,
                    signal: v.signal
                }));
                await y(A), await Q1(A.body, Z1(eO(R => {
                    R ? p[Hd] = R : delete p[Hd]
                }, R => {
                    w = R
                }, i))), o == null || o(), b(), f()
            } catch (A) {
                if (!v.signal.aborted) try {
                    const R = (S = s == null ? void 0 : s(A)) !== null && S !== void 0 ? S : w;
                    window.clearTimeout(h), h = window.setTimeout(C, R)
                } catch (R) {
                    b(), d(R)
                }
            }
        }
        C()
    })
}

function iO(e) {
    const t = e.headers.get("content-type");
    if (!(t != null && t.startsWith(Pl))) throw new Error(`Expected content-type to be ${Pl}, Actual: ${t}`)
}
const Na = To("notification", () => {
    const e = Nt(),
        t = Ug(),
        n = BC("isWarned", !1);
    let r = new AbortController;
    const a = Q(!1);

    function i(c, u) {
        t.add({
            title: c.name,
            description: u.substring(0, 90),
            avatar: {
                alt: c.address.toUpperCase(),
                size: "lg",
                ui: {
                    background: "dark:bg-gray-700",
                    placeholder: "dark:text-gray-200"
                }
            },
            ui: {
                background: "dark:bg-gray-800 bg-white rounded-lg shadow-lg pointer-events-auto"
            }
        })
    }

    function o() {
        t.add({
            title: "Rate Limited",
            color: "red",
            description: "Please be patient while we process your request.",
            timeout: 7e3
        })
    }
    async function s() {
        if (vn().getSession.token && !a.value) try {
            return a.value = !0, await aO(`${e.public.mercure}?topic=/accounts/${vn().getSession.id}`, {
                headers: {
                    Authorization: `Bearer ${vn().getSession.token}`
                },
                signal: r.signal,
                onmessage(c) {
                    const u = JSON.parse(c.data),
                        f = u["@type"];
                    f === "Message" && (u.isDeleted ? ro().remove(u.id) : ro().add(u))
                }
            }), !0
        } catch {
            a.value = !1
        }
    }

    function l() {
        a.value = !1, r.abort(), r = new AbortController
    }
    return {
        isWarned: n,
        fire: i,
        rateLimit: o,
        subscribe: s,
        unsubscribe: l
    }
});

function oO(e) {
    const {
        route: t,
        router: n,
        i18n: r
    } = e || {};
    return p1({
        route: t || Hr(),
        router: n || pt(),
        i18n: r || kn(ge().$i18n)
    })
}

function OP(e) {
    const {
        route: t,
        router: n,
        i18n: r
    } = e || {};
    return jg({
        route: t || Hr(),
        router: n || pt(),
        i18n: r || kn(ge().$i18n)
    })
}

function MP(e) {
    const {
        addDirAttribute: t,
        addSeoAttributes: n,
        identifierAttribute: r,
        route: a,
        router: i,
        i18n: o
    } = e || {};
    return h1({
        addDirAttribute: t || !1,
        addSeoAttributes: n || !1,
        identifierAttribute: r || "hid",
        route: a || Hr(),
        router: i || pt(),
        i18n: o || kn(ge().$i18n)
    })
}
async function Jg() {
    const e = pt(),
        t = oO();
    await e.push(t("index"))
}
var Ue = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function sO(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}

function lO(e) {
    if (e.__esModule) return e;
    var t = e.default;
    if (typeof t == "function") {
        var n = function r() {
            return this instanceof r ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments)
        };
        n.prototype = t.prototype
    } else n = {};
    return Object.defineProperty(n, "__esModule", {
        value: !0
    }), Object.keys(e).forEach(function(r) {
        var a = Object.getOwnPropertyDescriptor(e, r);
        Object.defineProperty(n, r, a.get ? a : {
            enumerable: !0,
            get: function() {
                return e[r]
            }
        })
    }), n
}
var Gg = {
    exports: {}
};
(function(e, t) {
    (function(n, r) {
        r()
    })(Ue, function() {
        function n(c, u) {
            return typeof u > "u" ? u = {
                autoBom: !1
            } : typeof u != "object" && (console.warn("Deprecated: Expected third argument to be a object"), u = {
                autoBom: !u
            }), u.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(c.type) ? new Blob(["\uFEFF", c], {
                type: c.type
            }) : c
        }

        function r(c, u, f) {
            var d = new XMLHttpRequest;
            d.open("GET", c), d.responseType = "blob", d.onload = function() {
                l(d.response, u, f)
            }, d.onerror = function() {
                console.error("could not download file")
            }, d.send()
        }

        function a(c) {
            var u = new XMLHttpRequest;
            u.open("HEAD", c, !1);
            try {
                u.send()
            } catch {}
            return 200 <= u.status && 299 >= u.status
        }

        function i(c) {
            try {
                c.dispatchEvent(new MouseEvent("click"))
            } catch {
                var u = document.createEvent("MouseEvents");
                u.initMouseEvent("click", !0, !0, window, 0, 0, 0, 80, 20, !1, !1, !1, !1, 0, null), c.dispatchEvent(u)
            }
        }
        var o = typeof window == "object" && window.window === window ? window : typeof self == "object" && self.self === self ? self : typeof Ue == "object" && Ue.global === Ue ? Ue : void 0,
            s = o.navigator && /Macintosh/.test(navigator.userAgent) && /AppleWebKit/.test(navigator.userAgent) && !/Safari/.test(navigator.userAgent),
            l = o.saveAs || (typeof window != "object" || window !== o ? function() {} : "download" in HTMLAnchorElement.prototype && !s ? function(c, u, f) {
                var d = o.URL || o.webkitURL,
                    p = document.createElement("a");
                u = u || c.name || "download", p.download = u, p.rel = "noopener", typeof c == "string" ? (p.href = c, p.origin === location.origin ? i(p) : a(p.href) ? r(c, u, f) : i(p, p.target = "_blank")) : (p.href = d.createObjectURL(c), setTimeout(function() {
                    d.revokeObjectURL(p.href)
                }, 4e4), setTimeout(function() {
                    i(p)
                }, 0))
            } : "msSaveOrOpenBlob" in navigator ? function(c, u, f) {
                if (u = u || c.name || "download", typeof c != "string") navigator.msSaveOrOpenBlob(n(c, f), u);
                else if (a(c)) r(c, u, f);
                else {
                    var d = document.createElement("a");
                    d.href = c, d.target = "_blank", setTimeout(function() {
                        i(d)
                    })
                }
            } : function(c, u, f, d) {
                if (d = d || open("", "_blank"), d && (d.document.title = d.document.body.innerText = "downloading..."), typeof c == "string") return r(c, u, f);
                var p = c.type === "application/octet-stream",
                    v = /constructor/i.test(o.HTMLElement) || o.safari,
                    E = /CriOS\/[\d]+/.test(navigator.userAgent);
                if ((E || p && v || s) && typeof FileReader < "u") {
                    var w = new FileReader;
                    w.onloadend = function() {
                        var m = w.result;
                        m = E ? m : m.replace(/^data:[^;]*;/, "data:attachment/file;"), d ? d.location.href = m : location = m, d = null
                    }, w.readAsDataURL(c)
                } else {
                    var h = o.URL || o.webkitURL,
                        b = h.createObjectURL(c);
                    d ? d.location = b : location.href = b, d = null, setTimeout(function() {
                        h.revokeObjectURL(b)
                    }, 4e4)
                }
            });
        o.saveAs = l.saveAs = l, e.exports = l
    })
})(Gg);
var cO = Gg.exports;
const uO = sO(cO),
    ro = To("message", () => {
        const e = vn(),
            t = Nt(),
            n = Q([]),
            r = Q(null),
            a = Q(null),
            i = W(() => n.value);

        function o(m) {
            n.value = m
        }

        function s(m) {
            r.value = m
        }

        function l(m) {
            a.value = m
        }

        function c(m) {
            n.value = n.value.filter(y => y.id !== m)
        }

        function u() {
            n.value = []
        }

        function f(m) {
            const y = n.value.findIndex(C => C.id === m.id);
            if (y >= 0) {
                const C = n.value[y];
                n.value.splice(y, 1, { ...C,
                    ...m
                })
            } else n.value.unshift(m), Na().fire(m.from, m.intro)
        }
        async function d() {
            if (!e.getSession) {
                n.value.length > 0 && (n.value = []);
                return
            }
            await $fetch("/messages", {
                baseURL: t.public.api,
                method: "GET",
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`
                }
            }).then(m => o(m["hydra:member"])).catch(() => {
                n.value = []
            })
        }
        async function p(m) {
            await $fetch(`/messages/${m}`, {
                baseURL: t.public.api,
                method: "GET",
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`
                }
            }).then(y => {
                s(y), y.seen || v(m)
            }).catch(async y => {
                if (r.value = null, y.status === 404) throw yn({
                    statusCode: 404,
                    statusMessage: "Message not found"
                })
            })
        }
        async function v(m) {
            await $fetch(`/messages/${m}`, {
                baseURL: t.public.api,
                method: "PATCH",
                body: {
                    seen: !0
                },
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`,
                    "Content-Type": "application/merge-patch+json"
                }
            }).catch(async () => {
                r.value = null
            })
        }
        async function E(m) {
            await $fetch(`/sources/${m}`, {
                baseURL: t.public.api,
                method: "GET",
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`
                }
            }).then(y => l(y)).catch(async y => {
                if (a.value = null, y.status === 404) throw yn({
                    statusCode: 404,
                    statusMessage: "Source not found"
                })
            })
        }
        async function w(m, y, C) {
            const {
                saveAs: S
            } = uO;
            await $fetch(m, {
                baseURL: t.public.api,
                method: "GET",
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`
                },
                responseType: "blob"
            }).then(A => S(A, y, C)).catch(() => {
                Na().rateLimit()
            })
        }
        async function h(m) {
            await $fetch(m, {
                baseURL: t.public.api,
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${e.getSession.token}`
                }
            }), await Jg()
        }

        function b() {
            const m = window.open("", "", ""),
                y = r.value ? r.value.html ? r.value.html : r.value.text : !1;
            m.document.write(y), m.document.close(), m.focus(), m.print()
        }
        return {
            add: f,
            fetchMessages: d,
            fetchMessage: p,
            fetchSource: E,
            getMessages: i,
            clearMessages: u,
            markAsSeen: v,
            download: w,
            remove: c,
            message: r,
            source: a,
            print: b,
            destroy: h
        }
    }),
    fO = To("domain", () => {
        const e = Nt(),
            t = Q([]),
            n = W(() => t.value),
            r = W(() => {
                const o = t.value;
                return o[Math.floor(Math.random() * o.length)]
            });
        async function a() {
            await $fetch("/domains", {
                baseURL: e.public.api
            }).then(o => i(o["hydra:member"]))
        }

        function i(o) {
            t.value = o
        }
        return {
            getDomains: n,
            getDomain: r,
            fetchDomains: a
        }
    }),
    Kd = e => {
        e = 1831565813 + (e |= 0) | 0;
        let t = Math.imul(e ^ e >>> 15, 1 | e);
        return t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t, ((t ^ t >>> 14) >>> 0) / 4294967296
    };
class dO {
    constructor(t) {
        this.dictionaries = void 0, this.length = void 0, this.separator = void 0, this.style = void 0, this.seed = void 0;
        const {
            length: n,
            separator: r,
            dictionaries: a,
            style: i,
            seed: o
        } = t;
        this.dictionaries = a, this.separator = r, this.length = n, this.style = i, this.seed = o
    }
    generate() {
        if (!this.dictionaries) throw new Error('Cannot find any dictionary. Please provide at least one, or leave the "dictionary" field empty in the config object');
        if (this.length <= 0) throw new Error("Invalid length provided");
        if (this.length > this.dictionaries.length) throw new Error(`The length cannot be bigger than the number of dictionaries.
Length provided: ${this.length}. Number of dictionaries provided: ${this.dictionaries.length}`);
        let t = this.seed;
        return this.dictionaries.slice(0, this.length).reduce((n, r) => {
            let a;
            t ? (a = (o => {
                if (typeof o == "string") {
                    const s = o.split("").map(c => c.charCodeAt(0)).reduce((c, u) => c + u, 1),
                        l = Math.floor(Number(s));
                    return Kd(l)
                }
                return Kd(o)
            })(t), t = 4294967296 * a) : a = Math.random();
            let i = r[Math.floor(a * r.length)] || "";
            if (this.style === "lowerCase") i = i.toLowerCase();
            else if (this.style === "capital") {
                const [o, ...s] = i.split("");
                i = o.toUpperCase() + s.join("")
            } else this.style === "upperCase" && (i = i.toUpperCase());
            return n ? `${n}${this.separator}${i}` : `${i}`
        }, "")
    }
}
const Ud = {
        separator: "_",
        dictionaries: []
    },
    pO = e => {
        const t = [...e && e.dictionaries || Ud.dictionaries],
            n = { ...Ud,
                ...e,
                length: e && e.length || t.length,
                dictionaries: t
            };
        if (!e || !e.dictionaries || !e.dictionaries.length) throw new Error('A "dictionaries" array must be provided. This is a breaking change introduced starting from Unique Name Generator v4. Read more about the breaking change here: https://github.com/andreasonny83/unique-names-generator#migration-guide');
        return new dO(n).generate()
    };
var hO = ["able", "above", "absent", "absolute", "abstract", "abundant", "academic", "acceptable", "accepted", "accessible", "accurate", "accused", "active", "actual", "acute", "added", "additional", "adequate", "adjacent", "administrative", "adorable", "advanced", "adverse", "advisory", "aesthetic", "afraid", "aggregate", "aggressive", "agreeable", "agreed", "agricultural", "alert", "alive", "alleged", "allied", "alone", "alright", "alternative", "amateur", "amazing", "ambitious", "amused", "ancient", "angry", "annoyed", "annual", "anonymous", "anxious", "appalling", "apparent", "applicable", "appropriate", "arbitrary", "architectural", "armed", "arrogant", "artificial", "artistic", "ashamed", "asleep", "assistant", "associated", "atomic", "attractive", "automatic", "autonomous", "available", "average", "awake", "aware", "awful", "awkward", "back", "bad", "balanced", "bare", "basic", "beautiful", "beneficial", "better", "bewildered", "big", "binding", "biological", "bitter", "bizarre", "blank", "blind", "blonde", "bloody", "blushing", "boiling", "bold", "bored", "boring", "bottom", "brainy", "brave", "breakable", "breezy", "brief", "bright", "brilliant", "broad", "broken", "bumpy", "burning", "busy", "calm", "capable", "capitalist", "careful", "casual", "causal", "cautious", "central", "certain", "changing", "characteristic", "charming", "cheap", "cheerful", "chemical", "chief", "chilly", "chosen", "christian", "chronic", "chubby", "circular", "civic", "civil", "civilian", "classic", "classical", "clean", "clear", "clever", "clinical", "close", "closed", "cloudy", "clumsy", "coastal", "cognitive", "coherent", "cold", "collective", "colonial", "colorful", "colossal", "coloured", "colourful", "combative", "combined", "comfortable", "coming", "commercial", "common", "communist", "compact", "comparable", "comparative", "compatible", "competent", "competitive", "complete", "complex", "complicated", "comprehensive", "compulsory", "conceptual", "concerned", "concrete", "condemned", "confident", "confidential", "confused", "conscious", "conservation", "conservative", "considerable", "consistent", "constant", "constitutional", "contemporary", "content", "continental", "continued", "continuing", "continuous", "controlled", "controversial", "convenient", "conventional", "convinced", "convincing", "cooing", "cool", "cooperative", "corporate", "correct", "corresponding", "costly", "courageous", "crazy", "creative", "creepy", "criminal", "critical", "crooked", "crowded", "crucial", "crude", "cruel", "cuddly", "cultural", "curious", "curly", "current", "curved", "cute", "daily", "damaged", "damp", "dangerous", "dark", "dead", "deaf", "deafening", "dear", "decent", "decisive", "deep", "defeated", "defensive", "defiant", "definite", "deliberate", "delicate", "delicious", "delighted", "delightful", "democratic", "dependent", "depressed", "desirable", "desperate", "detailed", "determined", "developed", "developing", "devoted", "different", "difficult", "digital", "diplomatic", "direct", "dirty", "disabled", "disappointed", "disastrous", "disciplinary", "disgusted", "distant", "distinct", "distinctive", "distinguished", "disturbed", "disturbing", "diverse", "divine", "dizzy", "domestic", "dominant", "double", "doubtful", "drab", "dramatic", "dreadful", "driving", "drunk", "dry", "dual", "due", "dull", "dusty", "dutch", "dying", "dynamic", "eager", "early", "eastern", "easy", "economic", "educational", "eerie", "effective", "efficient", "elaborate", "elated", "elderly", "eldest", "electoral", "electric", "electrical", "electronic", "elegant", "eligible", "embarrassed", "embarrassing", "emotional", "empirical", "empty", "enchanting", "encouraging", "endless", "energetic", "enormous", "enthusiastic", "entire", "entitled", "envious", "environmental", "equal", "equivalent", "essential", "established", "estimated", "ethical", "ethnic", "eventual", "everyday", "evident", "evil", "evolutionary", "exact", "excellent", "exceptional", "excess", "excessive", "excited", "exciting", "exclusive", "existing", "exotic", "expected", "expensive", "experienced", "experimental", "explicit", "extended", "extensive", "external", "extra", "extraordinary", "extreme", "exuberant", "faint", "fair", "faithful", "familiar", "famous", "fancy", "fantastic", "far", "fascinating", "fashionable", "fast", "fat", "fatal", "favourable", "favourite", "federal", "fellow", "female", "feminist", "few", "fierce", "filthy", "final", "financial", "fine", "firm", "fiscal", "fit", "fixed", "flaky", "flat", "flexible", "fluffy", "fluttering", "flying", "following", "fond", "foolish", "foreign", "formal", "formidable", "forthcoming", "fortunate", "forward", "fragile", "frail", "frantic", "free", "frequent", "fresh", "friendly", "frightened", "front", "frozen", "full", "fun", "functional", "fundamental", "funny", "furious", "future", "fuzzy", "gastric", "gay", "general", "generous", "genetic", "gentle", "genuine", "geographical", "giant", "gigantic", "given", "glad", "glamorous", "gleaming", "global", "glorious", "golden", "good", "gorgeous", "gothic", "governing", "graceful", "gradual", "grand", "grateful", "greasy", "great", "grieving", "grim", "gross", "grotesque", "growing", "grubby", "grumpy", "guilty", "handicapped", "handsome", "happy", "hard", "harsh", "head", "healthy", "heavy", "helpful", "helpless", "hidden", "high", "hilarious", "hissing", "historic", "historical", "hollow", "holy", "homeless", "homely", "hon", "honest", "horizontal", "horrible", "hostile", "hot", "huge", "human", "hungry", "hurt", "hushed", "husky", "icy", "ideal", "identical", "ideological", "ill", "illegal", "imaginative", "immediate", "immense", "imperial", "implicit", "important", "impossible", "impressed", "impressive", "improved", "inadequate", "inappropriate", "inc", "inclined", "increased", "increasing", "incredible", "independent", "indirect", "individual", "industrial", "inevitable", "influential", "informal", "inherent", "initial", "injured", "inland", "inner", "innocent", "innovative", "inquisitive", "instant", "institutional", "insufficient", "intact", "integral", "integrated", "intellectual", "intelligent", "intense", "intensive", "interested", "interesting", "interim", "interior", "intermediate", "internal", "international", "intimate", "invisible", "involved", "irrelevant", "isolated", "itchy", "jealous", "jittery", "joint", "jolly", "joyous", "judicial", "juicy", "junior", "just", "keen", "key", "kind", "known", "labour", "large", "late", "latin", "lazy", "leading", "left", "legal", "legislative", "legitimate", "lengthy", "lesser", "level", "lexical", "liable", "liberal", "light", "like", "likely", "limited", "linear", "linguistic", "liquid", "literary", "little", "live", "lively", "living", "local", "logical", "lonely", "long", "loose", "lost", "loud", "lovely", "low", "loyal", "ltd", "lucky", "mad", "magic", "magnetic", "magnificent", "main", "major", "male", "mammoth", "managerial", "managing", "manual", "many", "marginal", "marine", "marked", "married", "marvellous", "marxist", "mass", "massive", "mathematical", "mature", "maximum", "mean", "meaningful", "mechanical", "medical", "medieval", "melodic", "melted", "mental", "mere", "metropolitan", "mid", "middle", "mighty", "mild", "military", "miniature", "minimal", "minimum", "ministerial", "minor", "miserable", "misleading", "missing", "misty", "mixed", "moaning", "mobile", "moderate", "modern", "modest", "molecular", "monetary", "monthly", "moral", "motionless", "muddy", "multiple", "mushy", "musical", "mute", "mutual", "mysterious", "naked", "narrow", "nasty", "national", "native", "natural", "naughty", "naval", "near", "nearby", "neat", "necessary", "negative", "neighbouring", "nervous", "net", "neutral", "new", "nice", "noble", "noisy", "normal", "northern", "nosy", "notable", "novel", "nuclear", "numerous", "nursing", "nutritious", "nutty", "obedient", "objective", "obliged", "obnoxious", "obvious", "occasional", "occupational", "odd", "official", "ok", "okay", "old", "olympic", "only", "open", "operational", "opposite", "optimistic", "oral", "ordinary", "organic", "organisational", "original", "orthodox", "other", "outdoor", "outer", "outrageous", "outside", "outstanding", "overall", "overseas", "overwhelming", "painful", "pale", "panicky", "parallel", "parental", "parliamentary", "partial", "particular", "passing", "passive", "past", "patient", "payable", "peaceful", "peculiar", "perfect", "permanent", "persistent", "personal", "petite", "philosophical", "physical", "plain", "planned", "plastic", "pleasant", "pleased", "poised", "polite", "political", "poor", "popular", "positive", "possible", "potential", "powerful", "practical", "precious", "precise", "preferred", "pregnant", "preliminary", "premier", "prepared", "present", "presidential", "pretty", "previous", "prickly", "primary", "prime", "primitive", "principal", "printed", "prior", "private", "probable", "productive", "professional", "profitable", "profound", "progressive", "prominent", "promising", "proper", "proposed", "prospective", "protective", "protestant", "proud", "provincial", "psychiatric", "psychological", "public", "puny", "pure", "purring", "puzzled", "quaint", "qualified", "quarrelsome", "querulous", "quick", "quickest", "quiet", "quintessential", "quixotic", "racial", "radical", "rainy", "random", "rapid", "rare", "raspy", "rational", "ratty", "raw", "ready", "real", "realistic", "rear", "reasonable", "recent", "reduced", "redundant", "regional", "registered", "regular", "regulatory", "related", "relative", "relaxed", "relevant", "reliable", "relieved", "religious", "reluctant", "remaining", "remarkable", "remote", "renewed", "representative", "repulsive", "required", "resident", "residential", "resonant", "respectable", "respective", "responsible", "resulting", "retail", "retired", "revolutionary", "rich", "ridiculous", "right", "rigid", "ripe", "rising", "rival", "roasted", "robust", "rolling", "romantic", "rotten", "rough", "round", "royal", "rubber", "rude", "ruling", "running", "rural", "sacred", "sad", "safe", "salty", "satisfactory", "satisfied", "scared", "scary", "scattered", "scientific", "scornful", "scrawny", "screeching", "secondary", "secret", "secure", "select", "selected", "selective", "selfish", "semantic", "senior", "sensible", "sensitive", "separate", "serious", "severe", "sexual", "shaggy", "shaky", "shallow", "shared", "sharp", "sheer", "shiny", "shivering", "shocked", "short", "shrill", "shy", "sick", "significant", "silent", "silky", "silly", "similar", "simple", "single", "skilled", "skinny", "sleepy", "slight", "slim", "slimy", "slippery", "slow", "small", "smart", "smiling", "smoggy", "smooth", "social", "socialist", "soft", "solar", "sole", "solid", "sophisticated", "sore", "sorry", "sound", "sour", "southern", "soviet", "spare", "sparkling", "spatial", "special", "specific", "specified", "spectacular", "spicy", "spiritual", "splendid", "spontaneous", "sporting", "spotless", "spotty", "square", "squealing", "stable", "stale", "standard", "static", "statistical", "statutory", "steady", "steep", "sticky", "stiff", "still", "stingy", "stormy", "straight", "straightforward", "strange", "strategic", "strict", "striking", "striped", "strong", "structural", "stuck", "stupid", "subjective", "subsequent", "substantial", "subtle", "successful", "successive", "sudden", "sufficient", "suitable", "sunny", "super", "superb", "superior", "supporting", "supposed", "supreme", "sure", "surprised", "surprising", "surrounding", "surviving", "suspicious", "sweet", "swift", "symbolic", "sympathetic", "systematic", "tall", "tame", "tart", "tasteless", "tasty", "technical", "technological", "teenage", "temporary", "tender", "tense", "terrible", "territorial", "testy", "then", "theoretical", "thick", "thin", "thirsty", "thorough", "thoughtful", "thoughtless", "thundering", "tight", "tiny", "tired", "top", "tory", "total", "tough", "toxic", "traditional", "tragic", "tremendous", "tricky", "tropical", "troubled", "typical", "ugliest", "ugly", "ultimate", "unable", "unacceptable", "unaware", "uncertain", "unchanged", "uncomfortable", "unconscious", "underground", "underlying", "unemployed", "uneven", "unexpected", "unfair", "unfortunate", "unhappy", "uniform", "uninterested", "unique", "united", "universal", "unknown", "unlikely", "unnecessary", "unpleasant", "unsightly", "unusual", "unwilling", "upper", "upset", "uptight", "urban", "urgent", "used", "useful", "useless", "usual", "vague", "valid", "valuable", "variable", "varied", "various", "varying", "vast", "verbal", "vertical", "very", "vicarious", "vicious", "victorious", "violent", "visible", "visiting", "visual", "vital", "vitreous", "vivacious", "vivid", "vocal", "vocational", "voiceless", "voluminous", "voluntary", "vulnerable", "wandering", "warm", "wasteful", "watery", "weak", "wealthy", "weary", "wee", "weekly", "weird", "welcome", "well", "western", "wet", "whispering", "whole", "wicked", "wide", "widespread", "wild", "wilful", "willing", "willowy", "wily", "wise", "wispy", "wittering", "witty", "wonderful", "wooden", "working", "worldwide", "worried", "worrying", "worthwhile", "worthy", "written", "wrong", "xenacious", "xenial", "xenogeneic", "xenophobic", "xeric", "xerothermic", "yabbering", "yammering", "yappiest", "yappy", "yawning", "yearling", "yearning", "yeasty", "yelling", "yelping", "yielding", "yodelling", "young", "youngest", "youthful", "ytterbic", "yucky", "yummy", "zany", "zealous", "zeroth", "zestful", "zesty", "zippy", "zonal", "zoophagous", "zygomorphic", "zygotic"],
    mO = ["amaranth", "amber", "amethyst", "apricot", "aqua", "aquamarine", "azure", "beige", "black", "blue", "blush", "bronze", "brown", "chocolate", "coffee", "copper", "coral", "crimson", "cyan", "emerald", "fuchsia", "gold", "gray", "green", "harlequin", "indigo", "ivory", "jade", "lavender", "lime", "magenta", "maroon", "moccasin", "olive", "orange", "peach", "pink", "plum", "purple", "red", "rose", "salmon", "sapphire", "scarlet", "silver", "tan", "teal", "tomato", "turquoise", "violet", "white", "yellow"],
    gO = ["Aaren", "Aarika", "Abagael", "Abagail", "Abbe", "Abbey", "Abbi", "Abbie", "Abby", "Abbye", "Abigael", "Abigail", "Abigale", "Abra", "Ada", "Adah", "Adaline", "Adan", "Adara", "Adda", "Addi", "Addia", "Addie", "Addy", "Adel", "Adela", "Adelaida", "Adelaide", "Adele", "Adelheid", "Adelice", "Adelina", "Adelind", "Adeline", "Adella", "Adelle", "Adena", "Adey", "Adi", "Adiana", "Adina", "Adora", "Adore", "Adoree", "Adorne", "Adrea", "Adria", "Adriaens", "Adrian", "Adriana", "Adriane", "Adrianna", "Adrianne", "Adriena", "Adrienne", "Aeriel", "Aeriela", "Aeriell", "Afton", "Ag", "Agace", "Agata", "Agatha", "Agathe", "Aggi", "Aggie", "Aggy", "Agna", "Agnella", "Agnes", "Agnese", "Agnesse", "Agneta", "Agnola", "Agretha", "Aida", "Aidan", "Aigneis", "Aila", "Aile", "Ailee", "Aileen", "Ailene", "Ailey", "Aili", "Ailina", "Ailis", "Ailsun", "Ailyn", "Aime", "Aimee", "Aimil", "Aindrea", "Ainslee", "Ainsley", "Ainslie", "Ajay", "Alaine", "Alameda", "Alana", "Alanah", "Alane", "Alanna", "Alayne", "Alberta", "Albertina", "Albertine", "Albina", "Alecia", "Aleda", "Aleece", "Aleen", "Alejandra", "Alejandrina", "Alena", "Alene", "Alessandra", "Aleta", "Alethea", "Alex", "Alexa", "Alexandra", "Alexandrina", "Alexi", "Alexia", "Alexina", "Alexine", "Alexis", "Alfi", "Alfie", "Alfreda", "Alfy", "Ali", "Alia", "Alica", "Alice", "Alicea", "Alicia", "Alida", "Alidia", "Alie", "Alika", "Alikee", "Alina", "Aline", "Alis", "Alisa", "Alisha", "Alison", "Alissa", "Alisun", "Alix", "Aliza", "Alla", "Alleen", "Allegra", "Allene", "Alli", "Allianora", "Allie", "Allina", "Allis", "Allison", "Allissa", "Allix", "Allsun", "Allx", "Ally", "Allyce", "Allyn", "Allys", "Allyson", "Alma", "Almeda", "Almeria", "Almeta", "Almira", "Almire", "Aloise", "Aloisia", "Aloysia", "Alta", "Althea", "Alvera", "Alverta", "Alvina", "Alvinia", "Alvira", "Alyce", "Alyda", "Alys", "Alysa", "Alyse", "Alysia", "Alyson", "Alyss", "Alyssa", "Amabel", "Amabelle", "Amalea", "Amalee", "Amaleta", "Amalia", "Amalie", "Amalita", "Amalle", "Amanda", "Amandi", "Amandie", "Amandy", "Amara", "Amargo", "Amata", "Amber", "Amberly", "Ambur", "Ame", "Amelia", "Amelie", "Amelina", "Ameline", "Amelita", "Ami", "Amie", "Amii", "Amil", "Amitie", "Amity", "Ammamaria", "Amy", "Amye", "Ana", "Anabal", "Anabel", "Anabella", "Anabelle", "Analiese", "Analise", "Anallese", "Anallise", "Anastasia", "Anastasie", "Anastassia", "Anatola", "Andee", "Andeee", "Anderea", "Andi", "Andie", "Andra", "Andrea", "Andreana", "Andree", "Andrei", "Andria", "Andriana", "Andriette", "Andromache", "Andy", "Anestassia", "Anet", "Anett", "Anetta", "Anette", "Ange", "Angel", "Angela", "Angele", "Angelia", "Angelica", "Angelika", "Angelina", "Angeline", "Angelique", "Angelita", "Angelle", "Angie", "Angil", "Angy", "Ania", "Anica", "Anissa", "Anita", "Anitra", "Anjanette", "Anjela", "Ann", "Ann-marie", "Anna", "Anna-diana", "Anna-diane", "Anna-maria", "Annabal", "Annabel", "Annabela", "Annabell", "Annabella", "Annabelle", "Annadiana", "Annadiane", "Annalee", "Annaliese", "Annalise", "Annamaria", "Annamarie", "Anne", "Anne-corinne", "Anne-marie", "Annecorinne", "Anneliese", "Annelise", "Annemarie", "Annetta", "Annette", "Anni", "Annice", "Annie", "Annis", "Annissa", "Annmaria", "Annmarie", "Annnora", "Annora", "Anny", "Anselma", "Ansley", "Anstice", "Anthe", "Anthea", "Anthia", "Anthiathia", "Antoinette", "Antonella", "Antonetta", "Antonia", "Antonie", "Antonietta", "Antonina", "Anya", "Appolonia", "April", "Aprilette", "Ara", "Arabel", "Arabela", "Arabele", "Arabella", "Arabelle", "Arda", "Ardath", "Ardeen", "Ardelia", "Ardelis", "Ardella", "Ardelle", "Arden", "Ardene", "Ardenia", "Ardine", "Ardis", "Ardisj", "Ardith", "Ardra", "Ardyce", "Ardys", "Ardyth", "Aretha", "Ariadne", "Ariana", "Aridatha", "Ariel", "Ariela", "Ariella", "Arielle", "Arlana", "Arlee", "Arleen", "Arlen", "Arlena", "Arlene", "Arleta", "Arlette", "Arleyne", "Arlie", "Arliene", "Arlina", "Arlinda", "Arline", "Arluene", "Arly", "Arlyn", "Arlyne", "Aryn", "Ashely", "Ashia", "Ashien", "Ashil", "Ashla", "Ashlan", "Ashlee", "Ashleigh", "Ashlen", "Ashley", "Ashli", "Ashlie", "Ashly", "Asia", "Astra", "Astrid", "Astrix", "Atalanta", "Athena", "Athene", "Atlanta", "Atlante", "Auberta", "Aubine", "Aubree", "Aubrette", "Aubrey", "Aubrie", "Aubry", "Audi", "Audie", "Audra", "Audre", "Audrey", "Audrie", "Audry", "Audrye", "Audy", "Augusta", "Auguste", "Augustina", "Augustine", "Aundrea", "Aura", "Aurea", "Aurel", "Aurelea", "Aurelia", "Aurelie", "Auria", "Aurie", "Aurilia", "Aurlie", "Auroora", "Aurora", "Aurore", "Austin", "Austina", "Austine", "Ava", "Aveline", "Averil", "Averyl", "Avie", "Avis", "Aviva", "Avivah", "Avril", "Avrit", "Ayn", "Bab", "Babara", "Babb", "Babbette", "Babbie", "Babette", "Babita", "Babs", "Bambi", "Bambie", "Bamby", "Barb", "Barbabra", "Barbara", "Barbara-anne", "Barbaraanne", "Barbe", "Barbee", "Barbette", "Barbey", "Barbi", "Barbie", "Barbra", "Barby", "Bari", "Barrie", "Barry", "Basia", "Bathsheba", "Batsheva", "Bea", "Beatrice", "Beatrisa", "Beatrix", "Beatriz", "Bebe", "Becca", "Becka", "Becki", "Beckie", "Becky", "Bee", "Beilul", "Beitris", "Bekki", "Bel", "Belia", "Belicia", "Belinda", "Belita", "Bell", "Bella", "Bellanca", "Belle", "Bellina", "Belva", "Belvia", "Bendite", "Benedetta", "Benedicta", "Benedikta", "Benetta", "Benita", "Benni", "Bennie", "Benny", "Benoite", "Berenice", "Beret", "Berget", "Berna", "Bernadene", "Bernadette", "Bernadina", "Bernadine", "Bernardina", "Bernardine", "Bernelle", "Bernete", "Bernetta", "Bernette", "Berni", "Bernice", "Bernie", "Bernita", "Berny", "Berri", "Berrie", "Berry", "Bert", "Berta", "Berte", "Bertha", "Berthe", "Berti", "Bertie", "Bertina", "Bertine", "Berty", "Beryl", "Beryle", "Bess", "Bessie", "Bessy", "Beth", "Bethanne", "Bethany", "Bethena", "Bethina", "Betsey", "Betsy", "Betta", "Bette", "Bette-ann", "Betteann", "Betteanne", "Betti", "Bettina", "Bettine", "Betty", "Bettye", "Beulah", "Bev", "Beverie", "Beverlee", "Beverley", "Beverlie", "Beverly", "Bevvy", "Bianca", "Bianka", "Bibbie", "Bibby", "Bibbye", "Bibi", "Biddie", "Biddy", "Bidget", "Bili", "Bill", "Billi", "Billie", "Billy", "Billye", "Binni", "Binnie", "Binny", "Bird", "Birdie", "Birgit", "Birgitta", "Blair", "Blaire", "Blake", "Blakelee", "Blakeley", "Blanca", "Blanch", "Blancha", "Blanche", "Blinni", "Blinnie", "Blinny", "Bliss", "Blisse", "Blithe", "Blondell", "Blondelle", "Blondie", "Blondy", "Blythe", "Bobbe", "Bobbee", "Bobbette", "Bobbi", "Bobbie", "Bobby", "Bobbye", "Bobette", "Bobina", "Bobine", "Bobinette", "Bonita", "Bonnee", "Bonni", "Bonnibelle", "Bonnie", "Bonny", "Brana", "Brandais", "Brande", "Brandea", "Brandi", "Brandice", "Brandie", "Brandise", "Brandy", "Breanne", "Brear", "Bree", "Breena", "Bren", "Brena", "Brenda", "Brenn", "Brenna", "Brett", "Bria", "Briana", "Brianna", "Brianne", "Bride", "Bridget", "Bridgette", "Bridie", "Brier", "Brietta", "Brigid", "Brigida", "Brigit", "Brigitta", "Brigitte", "Brina", "Briney", "Brinn", "Brinna", "Briny", "Brit", "Brita", "Britney", "Britni", "Britt", "Britta", "Brittan", "Brittaney", "Brittani", "Brittany", "Britte", "Britteny", "Brittne", "Brittney", "Brittni", "Brook", "Brooke", "Brooks", "Brunhilda", "Brunhilde", "Bryana", "Bryn", "Bryna", "Brynn", "Brynna", "Brynne", "Buffy", "Bunni", "Bunnie", "Bunny", "Cacilia", "Cacilie", "Cahra", "Cairistiona", "Caitlin", "Caitrin", "Cal", "Calida", "Calla", "Calley", "Calli", "Callida", "Callie", "Cally", "Calypso", "Cam", "Camala", "Camel", "Camella", "Camellia", "Cami", "Camila", "Camile", "Camilla", "Camille", "Cammi", "Cammie", "Cammy", "Candace", "Candi", "Candice", "Candida", "Candide", "Candie", "Candis", "Candra", "Candy", "Caprice", "Cara", "Caralie", "Caren", "Carena", "Caresa", "Caressa", "Caresse", "Carey", "Cari", "Caria", "Carie", "Caril", "Carilyn", "Carin", "Carina", "Carine", "Cariotta", "Carissa", "Carita", "Caritta", "Carla", "Carlee", "Carleen", "Carlen", "Carlene", "Carley", "Carlie", "Carlin", "Carlina", "Carline", "Carlita", "Carlota", "Carlotta", "Carly", "Carlye", "Carlyn", "Carlynn", "Carlynne", "Carma", "Carmel", "Carmela", "Carmelia", "Carmelina", "Carmelita", "Carmella", "Carmelle", "Carmen", "Carmencita", "Carmina", "Carmine", "Carmita", "Carmon", "Caro", "Carol", "Carol-jean", "Carola", "Carolan", "Carolann", "Carole", "Carolee", "Carolin", "Carolina", "Caroline", "Caroljean", "Carolyn", "Carolyne", "Carolynn", "Caron", "Carree", "Carri", "Carrie", "Carrissa", "Carroll", "Carry", "Cary", "Caryl", "Caryn", "Casandra", "Casey", "Casi", "Casie", "Cass", "Cassandra", "Cassandre", "Cassandry", "Cassaundra", "Cassey", "Cassi", "Cassie", "Cassondra", "Cassy", "Catarina", "Cate", "Caterina", "Catha", "Catharina", "Catharine", "Cathe", "Cathee", "Catherin", "Catherina", "Catherine", "Cathi", "Cathie", "Cathleen", "Cathlene", "Cathrin", "Cathrine", "Cathryn", "Cathy", "Cathyleen", "Cati", "Catie", "Catina", "Catlaina", "Catlee", "Catlin", "Catrina", "Catriona", "Caty", "Caye", "Cayla", "Cecelia", "Cecil", "Cecile", "Ceciley", "Cecilia", "Cecilla", "Cecily", "Ceil", "Cele", "Celene", "Celesta", "Celeste", "Celestia", "Celestina", "Celestine", "Celestyn", "Celestyna", "Celia", "Celie", "Celina", "Celinda", "Celine", "Celinka", "Celisse", "Celka", "Celle", "Cesya", "Chad", "Chanda", "Chandal", "Chandra", "Channa", "Chantal", "Chantalle", "Charil", "Charin", "Charis", "Charissa", "Charisse", "Charita", "Charity", "Charla", "Charlean", "Charleen", "Charlena", "Charlene", "Charline", "Charlot", "Charlotta", "Charlotte", "Charmain", "Charmaine", "Charmane", "Charmian", "Charmine", "Charmion", "Charo", "Charyl", "Chastity", "Chelsae", "Chelsea", "Chelsey", "Chelsie", "Chelsy", "Cher", "Chere", "Cherey", "Cheri", "Cherianne", "Cherice", "Cherida", "Cherie", "Cherilyn", "Cherilynn", "Cherin", "Cherise", "Cherish", "Cherlyn", "Cherri", "Cherrita", "Cherry", "Chery", "Cherye", "Cheryl", "Cheslie", "Chiarra", "Chickie", "Chicky", "Chiquia", "Chiquita", "Chlo", "Chloe", "Chloette", "Chloris", "Chris", "Chrissie", "Chrissy", "Christa", "Christabel", "Christabella", "Christal", "Christalle", "Christan", "Christean", "Christel", "Christen", "Christi", "Christian", "Christiana", "Christiane", "Christie", "Christin", "Christina", "Christine", "Christy", "Christye", "Christyna", "Chrysa", "Chrysler", "Chrystal", "Chryste", "Chrystel", "Cicely", "Cicily", "Ciel", "Cilka", "Cinda", "Cindee", "Cindelyn", "Cinderella", "Cindi", "Cindie", "Cindra", "Cindy", "Cinnamon", "Cissiee", "Cissy", "Clair", "Claire", "Clara", "Clarabelle", "Clare", "Claresta", "Clareta", "Claretta", "Clarette", "Clarey", "Clari", "Claribel", "Clarice", "Clarie", "Clarinda", "Clarine", "Clarissa", "Clarisse", "Clarita", "Clary", "Claude", "Claudelle", "Claudetta", "Claudette", "Claudia", "Claudie", "Claudina", "Claudine", "Clea", "Clem", "Clemence", "Clementia", "Clementina", "Clementine", "Clemmie", "Clemmy", "Cleo", "Cleopatra", "Clerissa", "Clio", "Clo", "Cloe", "Cloris", "Clotilda", "Clovis", "Codee", "Codi", "Codie", "Cody", "Coleen", "Colene", "Coletta", "Colette", "Colleen", "Collen", "Collete", "Collette", "Collie", "Colline", "Colly", "Con", "Concettina", "Conchita", "Concordia", "Conni", "Connie", "Conny", "Consolata", "Constance", "Constancia", "Constancy", "Constanta", "Constantia", "Constantina", "Constantine", "Consuela", "Consuelo", "Cookie", "Cora", "Corabel", "Corabella", "Corabelle", "Coral", "Coralie", "Coraline", "Coralyn", "Cordelia", "Cordelie", "Cordey", "Cordi", "Cordie", "Cordula", "Cordy", "Coreen", "Corella", "Corenda", "Corene", "Coretta", "Corette", "Corey", "Cori", "Corie", "Corilla", "Corina", "Corine", "Corinna", "Corinne", "Coriss", "Corissa", "Corliss", "Corly", "Cornela", "Cornelia", "Cornelle", "Cornie", "Corny", "Correna", "Correy", "Corri", "Corrianne", "Corrie", "Corrina", "Corrine", "Corrinne", "Corry", "Cortney", "Cory", "Cosetta", "Cosette", "Costanza", "Courtenay", "Courtnay", "Courtney", "Crin", "Cris", "Crissie", "Crissy", "Crista", "Cristabel", "Cristal", "Cristen", "Cristi", "Cristie", "Cristin", "Cristina", "Cristine", "Cristionna", "Cristy", "Crysta", "Crystal", "Crystie", "Cthrine", "Cyb", "Cybil", "Cybill", "Cymbre", "Cynde", "Cyndi", "Cyndia", "Cyndie", "Cyndy", "Cynthea", "Cynthia", "Cynthie", "Cynthy", "Dacey", "Dacia", "Dacie", "Dacy", "Dael", "Daffi", "Daffie", "Daffy", "Dagmar", "Dahlia", "Daile", "Daisey", "Daisi", "Daisie", "Daisy", "Dale", "Dalenna", "Dalia", "Dalila", "Dallas", "Daloris", "Damara", "Damaris", "Damita", "Dana", "Danell", "Danella", "Danette", "Dani", "Dania", "Danica", "Danice", "Daniela", "Daniele", "Daniella", "Danielle", "Danika", "Danila", "Danit", "Danita", "Danna", "Danni", "Dannie", "Danny", "Dannye", "Danya", "Danyelle", "Danyette", "Daphene", "Daphna", "Daphne", "Dara", "Darb", "Darbie", "Darby", "Darcee", "Darcey", "Darci", "Darcie", "Darcy", "Darda", "Dareen", "Darell", "Darelle", "Dari", "Daria", "Darice", "Darla", "Darleen", "Darlene", "Darline", "Darlleen", "Daron", "Darrelle", "Darryl", "Darsey", "Darsie", "Darya", "Daryl", "Daryn", "Dasha", "Dasi", "Dasie", "Dasya", "Datha", "Daune", "Daveen", "Daveta", "Davida", "Davina", "Davine", "Davita", "Dawn", "Dawna", "Dayle", "Dayna", "Ddene", "De", "Deana", "Deane", "Deanna", "Deanne", "Deb", "Debbi", "Debbie", "Debby", "Debee", "Debera", "Debi", "Debor", "Debora", "Deborah", "Debra", "Dede", "Dedie", "Dedra", "Dee", "Deeann", "Deeanne", "Deedee", "Deena", "Deerdre", "Deeyn", "Dehlia", "Deidre", "Deina", "Deirdre", "Del", "Dela", "Delcina", "Delcine", "Delia", "Delila", "Delilah", "Delinda", "Dell", "Della", "Delly", "Delora", "Delores", "Deloria", "Deloris", "Delphine", "Delphinia", "Demeter", "Demetra", "Demetria", "Demetris", "Dena", "Deni", "Denice", "Denise", "Denna", "Denni", "Dennie", "Denny", "Deny", "Denys", "Denyse", "Deonne", "Desdemona", "Desirae", "Desiree", "Desiri", "Deva", "Devan", "Devi", "Devin", "Devina", "Devinne", "Devon", "Devondra", "Devonna", "Devonne", "Devora", "Di", "Diahann", "Dian", "Diana", "Diandra", "Diane", "Diane-marie", "Dianemarie", "Diann", "Dianna", "Dianne", "Diannne", "Didi", "Dido", "Diena", "Dierdre", "Dina", "Dinah", "Dinnie", "Dinny", "Dion", "Dione", "Dionis", "Dionne", "Dita", "Dix", "Dixie", "Dniren", "Dode", "Dodi", "Dodie", "Dody", "Doe", "Doll", "Dolley", "Dolli", "Dollie", "Dolly", "Dolores", "Dolorita", "Doloritas", "Domeniga", "Dominga", "Domini", "Dominica", "Dominique", "Dona", "Donella", "Donelle", "Donetta", "Donia", "Donica", "Donielle", "Donna", "Donnamarie", "Donni", "Donnie", "Donny", "Dora", "Doralia", "Doralin", "Doralyn", "Doralynn", "Doralynne", "Dore", "Doreen", "Dorelia", "Dorella", "Dorelle", "Dorena", "Dorene", "Doretta", "Dorette", "Dorey", "Dori", "Doria", "Dorian", "Dorice", "Dorie", "Dorine", "Doris", "Dorisa", "Dorise", "Dorita", "Doro", "Dorolice", "Dorolisa", "Dorotea", "Doroteya", "Dorothea", "Dorothee", "Dorothy", "Dorree", "Dorri", "Dorrie", "Dorris", "Dorry", "Dorthea", "Dorthy", "Dory", "Dosi", "Dot", "Doti", "Dotti", "Dottie", "Dotty", "Dre", "Dreddy", "Dredi", "Drona", "Dru", "Druci", "Drucie", "Drucill", "Drucy", "Drusi", "Drusie", "Drusilla", "Drusy", "Dulce", "Dulcea", "Dulci", "Dulcia", "Dulciana", "Dulcie", "Dulcine", "Dulcinea", "Dulcy", "Dulsea", "Dusty", "Dyan", "Dyana", "Dyane", "Dyann", "Dyanna", "Dyanne", "Dyna", "Dynah", "Eachelle", "Eada", "Eadie", "Eadith", "Ealasaid", "Eartha", "Easter", "Eba", "Ebba", "Ebonee", "Ebony", "Eda", "Eddi", "Eddie", "Eddy", "Ede", "Edee", "Edeline", "Eden", "Edi", "Edie", "Edin", "Edita", "Edith", "Editha", "Edithe", "Ediva", "Edna", "Edwina", "Edy", "Edyth", "Edythe", "Effie", "Eileen", "Eilis", "Eimile", "Eirena", "Ekaterina", "Elaina", "Elaine", "Elana", "Elane", "Elayne", "Elberta", "Elbertina", "Elbertine", "Eleanor", "Eleanora", "Eleanore", "Electra", "Eleen", "Elena", "Elene", "Eleni", "Elenore", "Eleonora", "Eleonore", "Elfie", "Elfreda", "Elfrida", "Elfrieda", "Elga", "Elianora", "Elianore", "Elicia", "Elie", "Elinor", "Elinore", "Elisa", "Elisabet", "Elisabeth", "Elisabetta", "Elise", "Elisha", "Elissa", "Elita", "Eliza", "Elizabet", "Elizabeth", "Elka", "Elke", "Ella", "Elladine", "Elle", "Ellen", "Ellene", "Ellette", "Elli", "Ellie", "Ellissa", "Elly", "Ellyn", "Ellynn", "Elmira", "Elna", "Elnora", "Elnore", "Eloisa", "Eloise", "Elonore", "Elora", "Elsa", "Elsbeth", "Else", "Elset", "Elsey", "Elsi", "Elsie", "Elsinore", "Elspeth", "Elsy", "Elva", "Elvera", "Elvina", "Elvira", "Elwira", "Elyn", "Elyse", "Elysee", "Elysha", "Elysia", "Elyssa", "Em", "Ema", "Emalee", "Emalia", "Emelda", "Emelia", "Emelina", "Emeline", "Emelita", "Emelyne", "Emera", "Emilee", "Emili", "Emilia", "Emilie", "Emiline", "Emily", "Emlyn", "Emlynn", "Emlynne", "Emma", "Emmalee", "Emmaline", "Emmalyn", "Emmalynn", "Emmalynne", "Emmeline", "Emmey", "Emmi", "Emmie", "Emmy", "Emmye", "Emogene", "Emyle", "Emylee", "Engracia", "Enid", "Enrica", "Enrichetta", "Enrika", "Enriqueta", "Eolanda", "Eolande", "Eran", "Erda", "Erena", "Erica", "Ericha", "Ericka", "Erika", "Erin", "Erina", "Erinn", "Erinna", "Erma", "Ermengarde", "Ermentrude", "Ermina", "Erminia", "Erminie", "Erna", "Ernaline", "Ernesta", "Ernestine", "Ertha", "Eryn", "Esma", "Esmaria", "Esme", "Esmeralda", "Essa", "Essie", "Essy", "Esta", "Estel", "Estele", "Estell", "Estella", "Estelle", "Ester", "Esther", "Estrella", "Estrellita", "Ethel", "Ethelda", "Ethelin", "Ethelind", "Etheline", "Ethelyn", "Ethyl", "Etta", "Etti", "Ettie", "Etty", "Eudora", "Eugenia", "Eugenie", "Eugine", "Eula", "Eulalie", "Eunice", "Euphemia", "Eustacia", "Eva", "Evaleen", "Evangelia", "Evangelin", "Evangelina", "Evangeline", "Evania", "Evanne", "Eve", "Eveleen", "Evelina", "Eveline", "Evelyn", "Evey", "Evie", "Evita", "Evonne", "Evvie", "Evvy", "Evy", "Eyde", "Eydie", "Ezmeralda", "Fae", "Faina", "Faith", "Fallon", "Fan", "Fanchette", "Fanchon", "Fancie", "Fancy", "Fanechka", "Fania", "Fanni", "Fannie", "Fanny", "Fanya", "Fara", "Farah", "Farand", "Farica", "Farra", "Farrah", "Farrand", "Faun", "Faunie", "Faustina", "Faustine", "Fawn", "Fawne", "Fawnia", "Fay", "Faydra", "Faye", "Fayette", "Fayina", "Fayre", "Fayth", "Faythe", "Federica", "Fedora", "Felecia", "Felicdad", "Felice", "Felicia", "Felicity", "Felicle", "Felipa", "Felisha", "Felita", "Feliza", "Fenelia", "Feodora", "Ferdinanda", "Ferdinande", "Fern", "Fernanda", "Fernande", "Fernandina", "Ferne", "Fey", "Fiann", "Fianna", "Fidela", "Fidelia", "Fidelity", "Fifi", "Fifine", "Filia", "Filide", "Filippa", "Fina", "Fiona", "Fionna", "Fionnula", "Fiorenze", "Fleur", "Fleurette", "Flo", "Flor", "Flora", "Florance", "Flore", "Florella", "Florence", "Florencia", "Florentia", "Florenza", "Florette", "Flori", "Floria", "Florida", "Florie", "Florina", "Florinda", "Floris", "Florri", "Florrie", "Florry", "Flory", "Flossi", "Flossie", "Flossy", "Flss", "Fran", "Francene", "Frances", "Francesca", "Francine", "Francisca", "Franciska", "Francoise", "Francyne", "Frank", "Frankie", "Franky", "Franni", "Frannie", "Franny", "Frayda", "Fred", "Freda", "Freddi", "Freddie", "Freddy", "Fredelia", "Frederica", "Fredericka", "Frederique", "Fredi", "Fredia", "Fredra", "Fredrika", "Freida", "Frieda", "Friederike", "Fulvia", "Gabbey", "Gabbi", "Gabbie", "Gabey", "Gabi", "Gabie", "Gabriel", "Gabriela", "Gabriell", "Gabriella", "Gabrielle", "Gabriellia", "Gabrila", "Gaby", "Gae", "Gael", "Gail", "Gale", "Galina", "Garland", "Garnet", "Garnette", "Gates", "Gavra", "Gavrielle", "Gay", "Gaye", "Gayel", "Gayla", "Gayle", "Gayleen", "Gaylene", "Gaynor", "Gelya", "Gena", "Gene", "Geneva", "Genevieve", "Genevra", "Genia", "Genna", "Genni", "Gennie", "Gennifer", "Genny", "Genovera", "Genvieve", "George", "Georgeanna", "Georgeanne", "Georgena", "Georgeta", "Georgetta", "Georgette", "Georgia", "Georgiana", "Georgianna", "Georgianne", "Georgie", "Georgina", "Georgine", "Geralda", "Geraldine", "Gerda", "Gerhardine", "Geri", "Gerianna", "Gerianne", "Gerladina", "Germain", "Germaine", "Germana", "Gerri", "Gerrie", "Gerrilee", "Gerry", "Gert", "Gerta", "Gerti", "Gertie", "Gertrud", "Gertruda", "Gertrude", "Gertrudis", "Gerty", "Giacinta", "Giana", "Gianina", "Gianna", "Gigi", "Gilberta", "Gilberte", "Gilbertina", "Gilbertine", "Gilda", "Gilemette", "Gill", "Gillan", "Gilli", "Gillian", "Gillie", "Gilligan", "Gilly", "Gina", "Ginelle", "Ginevra", "Ginger", "Ginni", "Ginnie", "Ginnifer", "Ginny", "Giorgia", "Giovanna", "Gipsy", "Giralda", "Gisela", "Gisele", "Gisella", "Giselle", "Giuditta", "Giulia", "Giulietta", "Giustina", "Gizela", "Glad", "Gladi", "Gladys", "Gleda", "Glen", "Glenda", "Glenine", "Glenn", "Glenna", "Glennie", "Glennis", "Glori", "Gloria", "Gloriana", "Gloriane", "Glory", "Glyn", "Glynda", "Glynis", "Glynnis", "Gnni", "Godiva", "Golda", "Goldarina", "Goldi", "Goldia", "Goldie", "Goldina", "Goldy", "Grace", "Gracia", "Gracie", "Grata", "Gratia", "Gratiana", "Gray", "Grayce", "Grazia", "Greer", "Greta", "Gretal", "Gretchen", "Grete", "Gretel", "Grethel", "Gretna", "Gretta", "Grier", "Griselda", "Grissel", "Guendolen", "Guenevere", "Guenna", "Guglielma", "Gui", "Guillema", "Guillemette", "Guinevere", "Guinna", "Gunilla", "Gus", "Gusella", "Gussi", "Gussie", "Gussy", "Gusta", "Gusti", "Gustie", "Gusty", "Gwen", "Gwendolen", "Gwendolin", "Gwendolyn", "Gweneth", "Gwenette", "Gwenneth", "Gwenni", "Gwennie", "Gwenny", "Gwenora", "Gwenore", "Gwyn", "Gwyneth", "Gwynne", "Gypsy", "Hadria", "Hailee", "Haily", "Haleigh", "Halette", "Haley", "Hali", "Halie", "Halimeda", "Halley", "Halli", "Hallie", "Hally", "Hana", "Hanna", "Hannah", "Hanni", "Hannie", "Hannis", "Hanny", "Happy", "Harlene", "Harley", "Harli", "Harlie", "Harmonia", "Harmonie", "Harmony", "Harri", "Harrie", "Harriet", "Harriett", "Harrietta", "Harriette", "Harriot", "Harriott", "Hatti", "Hattie", "Hatty", "Hayley", "Hazel", "Heath", "Heather", "Heda", "Hedda", "Heddi", "Heddie", "Hedi", "Hedvig", "Hedvige", "Hedwig", "Hedwiga", "Hedy", "Heida", "Heidi", "Heidie", "Helaina", "Helaine", "Helen", "Helen-elizabeth", "Helena", "Helene", "Helenka", "Helga", "Helge", "Helli", "Heloise", "Helsa", "Helyn", "Hendrika", "Henka", "Henrie", "Henrieta", "Henrietta", "Henriette", "Henryetta", "Hephzibah", "Hermia", "Hermina", "Hermine", "Herminia", "Hermione", "Herta", "Hertha", "Hester", "Hesther", "Hestia", "Hetti", "Hettie", "Hetty", "Hilary", "Hilda", "Hildagard", "Hildagarde", "Hilde", "Hildegaard", "Hildegarde", "Hildy", "Hillary", "Hilliary", "Hinda", "Holli", "Hollie", "Holly", "Holly-anne", "Hollyanne", "Honey", "Honor", "Honoria", "Hope", "Horatia", "Hortense", "Hortensia", "Hulda", "Hyacinth", "Hyacintha", "Hyacinthe", "Hyacinthia", "Hyacinthie", "Hynda", "Ianthe", "Ibbie", "Ibby", "Ida", "Idalia", "Idalina", "Idaline", "Idell", "Idelle", "Idette", "Ileana", "Ileane", "Ilene", "Ilise", "Ilka", "Illa", "Ilsa", "Ilse", "Ilysa", "Ilyse", "Ilyssa", "Imelda", "Imogen", "Imogene", "Imojean", "Ina", "Indira", "Ines", "Inesita", "Inessa", "Inez", "Inga", "Ingaberg", "Ingaborg", "Inge", "Ingeberg", "Ingeborg", "Inger", "Ingrid", "Ingunna", "Inna", "Iolande", "Iolanthe", "Iona", "Iormina", "Ira", "Irena", "Irene", "Irina", "Iris", "Irita", "Irma", "Isa", "Isabel", "Isabelita", "Isabella", "Isabelle", "Isadora", "Isahella", "Iseabal", "Isidora", "Isis", "Isobel", "Issi", "Issie", "Issy", "Ivett", "Ivette", "Ivie", "Ivonne", "Ivory", "Ivy", "Izabel", "Jacenta", "Jacinda", "Jacinta", "Jacintha", "Jacinthe", "Jackelyn", "Jacki", "Jackie", "Jacklin", "Jacklyn", "Jackquelin", "Jackqueline", "Jacky", "Jaclin", "Jaclyn", "Jacquelin", "Jacqueline", "Jacquelyn", "Jacquelynn", "Jacquenetta", "Jacquenette", "Jacquetta", "Jacquette", "Jacqui", "Jacquie", "Jacynth", "Jada", "Jade", "Jaime", "Jaimie", "Jaine", "Jami", "Jamie", "Jamima", "Jammie", "Jan", "Jana", "Janaya", "Janaye", "Jandy", "Jane", "Janean", "Janeczka", "Janeen", "Janel", "Janela", "Janella", "Janelle", "Janene", "Janenna", "Janessa", "Janet", "Janeta", "Janetta", "Janette", "Janeva", "Janey", "Jania", "Janice", "Janie", "Janifer", "Janina", "Janine", "Janis", "Janith", "Janka", "Janna", "Jannel", "Jannelle", "Janot", "Jany", "Jaquelin", "Jaquelyn", "Jaquenetta", "Jaquenette", "Jaquith", "Jasmin", "Jasmina", "Jasmine", "Jayme", "Jaymee", "Jayne", "Jaynell", "Jazmin", "Jean", "Jeana", "Jeane", "Jeanelle", "Jeanette", "Jeanie", "Jeanine", "Jeanna", "Jeanne", "Jeannette", "Jeannie", "Jeannine", "Jehanna", "Jelene", "Jemie", "Jemima", "Jemimah", "Jemmie", "Jemmy", "Jen", "Jena", "Jenda", "Jenelle", "Jeni", "Jenica", "Jeniece", "Jenifer", "Jeniffer", "Jenilee", "Jenine", "Jenn", "Jenna", "Jennee", "Jennette", "Jenni", "Jennica", "Jennie", "Jennifer", "Jennilee", "Jennine", "Jenny", "Jeralee", "Jere", "Jeri", "Jermaine", "Jerrie", "Jerrilee", "Jerrilyn", "Jerrine", "Jerry", "Jerrylee", "Jess", "Jessa", "Jessalin", "Jessalyn", "Jessamine", "Jessamyn", "Jesse", "Jesselyn", "Jessi", "Jessica", "Jessie", "Jessika", "Jessy", "Jewel", "Jewell", "Jewelle", "Jill", "Jillana", "Jillane", "Jillayne", "Jilleen", "Jillene", "Jilli", "Jillian", "Jillie", "Jilly", "Jinny", "Jo", "Jo-ann", "Jo-anne", "Joan", "Joana", "Joane", "Joanie", "Joann", "Joanna", "Joanne", "Joannes", "Jobey", "Jobi", "Jobie", "Jobina", "Joby", "Jobye", "Jobyna", "Jocelin", "Joceline", "Jocelyn", "Jocelyne", "Jodee", "Jodi", "Jodie", "Jody", "Joeann", "Joela", "Joelie", "Joell", "Joella", "Joelle", "Joellen", "Joelly", "Joellyn", "Joelynn", "Joete", "Joey", "Johanna", "Johannah", "Johna", "Johnath", "Johnette", "Johnna", "Joice", "Jojo", "Jolee", "Joleen", "Jolene", "Joletta", "Joli", "Jolie", "Joline", "Joly", "Jolyn", "Jolynn", "Jonell", "Joni", "Jonie", "Jonis", "Jordain", "Jordan", "Jordana", "Jordanna", "Jorey", "Jori", "Jorie", "Jorrie", "Jorry", "Joscelin", "Josee", "Josefa", "Josefina", "Josepha", "Josephina", "Josephine", "Josey", "Josi", "Josie", "Josselyn", "Josy", "Jourdan", "Joy", "Joya", "Joyan", "Joyann", "Joyce", "Joycelin", "Joye", "Jsandye", "Juana", "Juanita", "Judi", "Judie", "Judith", "Juditha", "Judy", "Judye", "Juieta", "Julee", "Juli", "Julia", "Juliana", "Juliane", "Juliann", "Julianna", "Julianne", "Julie", "Julienne", "Juliet", "Julieta", "Julietta", "Juliette", "Julina", "Juline", "Julissa", "Julita", "June", "Junette", "Junia", "Junie", "Junina", "Justina", "Justine", "Justinn", "Jyoti", "Kacey", "Kacie", "Kacy", "Kaela", "Kai", "Kaia", "Kaila", "Kaile", "Kailey", "Kaitlin", "Kaitlyn", "Kaitlynn", "Kaja", "Kakalina", "Kala", "Kaleena", "Kali", "Kalie", "Kalila", "Kalina", "Kalinda", "Kalindi", "Kalli", "Kally", "Kameko", "Kamila", "Kamilah", "Kamillah", "Kandace", "Kandy", "Kania", "Kanya", "Kara", "Kara-lynn", "Karalee", "Karalynn", "Kare", "Karee", "Karel", "Karen", "Karena", "Kari", "Karia", "Karie", "Karil", "Karilynn", "Karin", "Karina", "Karine", "Kariotta", "Karisa", "Karissa", "Karita", "Karla", "Karlee", "Karleen", "Karlen", "Karlene", "Karlie", "Karlotta", "Karlotte", "Karly", "Karlyn", "Karmen", "Karna", "Karol", "Karola", "Karole", "Karolina", "Karoline", "Karoly", "Karon", "Karrah", "Karrie", "Karry", "Kary", "Karyl", "Karylin", "Karyn", "Kasey", "Kass", "Kassandra", "Kassey", "Kassi", "Kassia", "Kassie", "Kat", "Kata", "Katalin", "Kate", "Katee", "Katerina", "Katerine", "Katey", "Kath", "Katha", "Katharina", "Katharine", "Katharyn", "Kathe", "Katherina", "Katherine", "Katheryn", "Kathi", "Kathie", "Kathleen", "Kathlin", "Kathrine", "Kathryn", "Kathryne", "Kathy", "Kathye", "Kati", "Katie", "Katina", "Katine", "Katinka", "Katleen", "Katlin", "Katrina", "Katrine", "Katrinka", "Katti", "Kattie", "Katuscha", "Katusha", "Katy", "Katya", "Kay", "Kaycee", "Kaye", "Kayla", "Kayle", "Kaylee", "Kayley", "Kaylil", "Kaylyn", "Keeley", "Keelia", "Keely", "Kelcey", "Kelci", "Kelcie", "Kelcy", "Kelila", "Kellen", "Kelley", "Kelli", "Kellia", "Kellie", "Kellina", "Kellsie", "Kelly", "Kellyann", "Kelsey", "Kelsi", "Kelsy", "Kendra", "Kendre", "Kenna", "Keri", "Keriann", "Kerianne", "Kerri", "Kerrie", "Kerrill", "Kerrin", "Kerry", "Kerstin", "Kesley", "Keslie", "Kessia", "Kessiah", "Ketti", "Kettie", "Ketty", "Kevina", "Kevyn", "Ki", "Kiah", "Kial", "Kiele", "Kiersten", "Kikelia", "Kiley", "Kim", "Kimberlee", "Kimberley", "Kimberli", "Kimberly", "Kimberlyn", "Kimbra", "Kimmi", "Kimmie", "Kimmy", "Kinna", "Kip", "Kipp", "Kippie", "Kippy", "Kira", "Kirbee", "Kirbie", "Kirby", "Kiri", "Kirsten", "Kirsteni", "Kirsti", "Kirstin", "Kirstyn", "Kissee", "Kissiah", "Kissie", "Kit", "Kitti", "Kittie", "Kitty", "Kizzee", "Kizzie", "Klara", "Klarika", "Klarrisa", "Konstance", "Konstanze", "Koo", "Kora", "Koral", "Koralle", "Kordula", "Kore", "Korella", "Koren", "Koressa", "Kori", "Korie", "Korney", "Korrie", "Korry", "Kris", "Krissie", "Krissy", "Krista", "Kristal", "Kristan", "Kriste", "Kristel", "Kristen", "Kristi", "Kristien", "Kristin", "Kristina", "Kristine", "Kristy", "Kristyn", "Krysta", "Krystal", "Krystalle", "Krystle", "Krystyna", "Kyla", "Kyle", "Kylen", "Kylie", "Kylila", "Kylynn", "Kym", "Kynthia", "Kyrstin", "Lacee", "Lacey", "Lacie", "Lacy", "Ladonna", "Laetitia", "Laina", "Lainey", "Lana", "Lanae", "Lane", "Lanette", "Laney", "Lani", "Lanie", "Lanita", "Lanna", "Lanni", "Lanny", "Lara", "Laraine", "Lari", "Larina", "Larine", "Larisa", "Larissa", "Lark", "Laryssa", "Latashia", "Latia", "Latisha", "Latrena", "Latrina", "Laura", "Lauraine", "Laural", "Lauralee", "Laure", "Lauree", "Laureen", "Laurel", "Laurella", "Lauren", "Laurena", "Laurene", "Lauretta", "Laurette", "Lauri", "Laurianne", "Laurice", "Laurie", "Lauryn", "Lavena", "Laverna", "Laverne", "Lavina", "Lavinia", "Lavinie", "Layla", "Layne", "Layney", "Lea", "Leah", "Leandra", "Leann", "Leanna", "Leanor", "Leanora", "Lebbie", "Leda", "Lee", "Leeann", "Leeanne", "Leela", "Leelah", "Leena", "Leesa", "Leese", "Legra", "Leia", "Leigh", "Leigha", "Leila", "Leilah", "Leisha", "Lela", "Lelah", "Leland", "Lelia", "Lena", "Lenee", "Lenette", "Lenka", "Lenna", "Lenora", "Lenore", "Leodora", "Leoine", "Leola", "Leoline", "Leona", "Leonanie", "Leone", "Leonelle", "Leonie", "Leonora", "Leonore", "Leontine", "Leontyne", "Leora", "Leshia", "Lesley", "Lesli", "Leslie", "Lesly", "Lesya", "Leta", "Lethia", "Leticia", "Letisha", "Letitia", "Letizia", "Letta", "Letti", "Lettie", "Letty", "Lexi", "Lexie", "Lexine", "Lexis", "Lexy", "Leyla", "Lezlie", "Lia", "Lian", "Liana", "Liane", "Lianna", "Lianne", "Lib", "Libbey", "Libbi", "Libbie", "Libby", "Licha", "Lida", "Lidia", "Liesa", "Lil", "Lila", "Lilah", "Lilas", "Lilia", "Lilian", "Liliane", "Lilias", "Lilith", "Lilla", "Lilli", "Lillian", "Lillis", "Lilllie", "Lilly", "Lily", "Lilyan", "Lin", "Lina", "Lind", "Linda", "Lindi", "Lindie", "Lindsay", "Lindsey", "Lindsy", "Lindy", "Linea", "Linell", "Linet", "Linette", "Linn", "Linnea", "Linnell", "Linnet", "Linnie", "Linzy", "Lira", "Lisa", "Lisabeth", "Lisbeth", "Lise", "Lisetta", "Lisette", "Lisha", "Lishe", "Lissa", "Lissi", "Lissie", "Lissy", "Lita", "Liuka", "Liv", "Liva", "Livia", "Livvie", "Livvy", "Livvyy", "Livy", "Liz", "Liza", "Lizabeth", "Lizbeth", "Lizette", "Lizzie", "Lizzy", "Loella", "Lois", "Loise", "Lola", "Loleta", "Lolita", "Lolly", "Lona", "Lonee", "Loni", "Lonna", "Lonni", "Lonnie", "Lora", "Lorain", "Loraine", "Loralee", "Loralie", "Loralyn", "Loree", "Loreen", "Lorelei", "Lorelle", "Loren", "Lorena", "Lorene", "Lorenza", "Loretta", "Lorette", "Lori", "Loria", "Lorianna", "Lorianne", "Lorie", "Lorilee", "Lorilyn", "Lorinda", "Lorine", "Lorita", "Lorna", "Lorne", "Lorraine", "Lorrayne", "Lorri", "Lorrie", "Lorrin", "Lorry", "Lory", "Lotta", "Lotte", "Lotti", "Lottie", "Lotty", "Lou", "Louella", "Louisa", "Louise", "Louisette", "Loutitia", "Lu", "Luce", "Luci", "Lucia", "Luciana", "Lucie", "Lucienne", "Lucila", "Lucilia", "Lucille", "Lucina", "Lucinda", "Lucine", "Lucita", "Lucky", "Lucretia", "Lucy", "Ludovika", "Luella", "Luelle", "Luisa", "Luise", "Lula", "Lulita", "Lulu", "Lura", "Lurette", "Lurleen", "Lurlene", "Lurline", "Lusa", "Luz", "Lyda", "Lydia", "Lydie", "Lyn", "Lynda", "Lynde", "Lyndel", "Lyndell", "Lyndsay", "Lyndsey", "Lyndsie", "Lyndy", "Lynea", "Lynelle", "Lynett", "Lynette", "Lynn", "Lynna", "Lynne", "Lynnea", "Lynnell", "Lynnelle", "Lynnet", "Lynnett", "Lynnette", "Lynsey", "Lyssa", "Mab", "Mabel", "Mabelle", "Mable", "Mada", "Madalena", "Madalyn", "Maddalena", "Maddi", "Maddie", "Maddy", "Madel", "Madelaine", "Madeleine", "Madelena", "Madelene", "Madelin", "Madelina", "Madeline", "Madella", "Madelle", "Madelon", "Madelyn", "Madge", "Madlen", "Madlin", "Madonna", "Mady", "Mae", "Maegan", "Mag", "Magda", "Magdaia", "Magdalen", "Magdalena", "Magdalene", "Maggee", "Maggi", "Maggie", "Maggy", "Mahala", "Mahalia", "Maia", "Maible", "Maiga", "Maighdiln", "Mair", "Maire", "Maisey", "Maisie", "Maitilde", "Mala", "Malanie", "Malena", "Malia", "Malina", "Malinda", "Malinde", "Malissa", "Malissia", "Mallissa", "Mallorie", "Mallory", "Malorie", "Malory", "Malva", "Malvina", "Malynda", "Mame", "Mamie", "Manda", "Mandi", "Mandie", "Mandy", "Manon", "Manya", "Mara", "Marabel", "Marcela", "Marcelia", "Marcella", "Marcelle", "Marcellina", "Marcelline", "Marchelle", "Marci", "Marcia", "Marcie", "Marcile", "Marcille", "Marcy", "Mareah", "Maren", "Marena", "Maressa", "Marga", "Margalit", "Margalo", "Margaret", "Margareta", "Margarete", "Margaretha", "Margarethe", "Margaretta", "Margarette", "Margarita", "Margaux", "Marge", "Margeaux", "Margery", "Marget", "Margette", "Margi", "Margie", "Margit", "Margo", "Margot", "Margret", "Marguerite", "Margy", "Mari", "Maria", "Mariam", "Marian", "Mariana", "Mariann", "Marianna", "Marianne", "Maribel", "Maribelle", "Maribeth", "Marice", "Maridel", "Marie", "Marie-ann", "Marie-jeanne", "Marieann", "Mariejeanne", "Mariel", "Mariele", "Marielle", "Mariellen", "Marietta", "Mariette", "Marigold", "Marijo", "Marika", "Marilee", "Marilin", "Marillin", "Marilyn", "Marin", "Marina", "Marinna", "Marion", "Mariquilla", "Maris", "Marisa", "Mariska", "Marissa", "Marita", "Maritsa", "Mariya", "Marj", "Marja", "Marje", "Marji", "Marjie", "Marjorie", "Marjory", "Marjy", "Marketa", "Marla", "Marlane", "Marleah", "Marlee", "Marleen", "Marlena", "Marlene", "Marley", "Marlie", "Marline", "Marlo", "Marlyn", "Marna", "Marne", "Marney", "Marni", "Marnia", "Marnie", "Marquita", "Marrilee", "Marris", "Marrissa", "Marsha", "Marsiella", "Marta", "Martelle", "Martguerita", "Martha", "Marthe", "Marthena", "Marti", "Martica", "Martie", "Martina", "Martita", "Marty", "Martynne", "Mary", "Marya", "Maryann", "Maryanna", "Maryanne", "Marybelle", "Marybeth", "Maryellen", "Maryjane", "Maryjo", "Maryl", "Marylee", "Marylin", "Marylinda", "Marylou", "Marylynne", "Maryrose", "Marys", "Marysa", "Masha", "Matelda", "Mathilda", "Mathilde", "Matilda", "Matilde", "Matti", "Mattie", "Matty", "Maud", "Maude", "Maudie", "Maura", "Maure", "Maureen", "Maureene", "Maurene", "Maurine", "Maurise", "Maurita", "Maurizia", "Mavis", "Mavra", "Max", "Maxi", "Maxie", "Maxine", "Maxy", "May", "Maybelle", "Maye", "Mead", "Meade", "Meagan", "Meaghan", "Meara", "Mechelle", "Meg", "Megan", "Megen", "Meggi", "Meggie", "Meggy", "Meghan", "Meghann", "Mehetabel", "Mei", "Mel", "Mela", "Melamie", "Melania", "Melanie", "Melantha", "Melany", "Melba", "Melesa", "Melessa", "Melicent", "Melina", "Melinda", "Melinde", "Melisa", "Melisande", "Melisandra", "Melisenda", "Melisent", "Melissa", "Melisse", "Melita", "Melitta", "Mella", "Melli", "Mellicent", "Mellie", "Mellisa", "Mellisent", "Melloney", "Melly", "Melodee", "Melodie", "Melody", "Melonie", "Melony", "Melosa", "Melva", "Mercedes", "Merci", "Mercie", "Mercy", "Meredith", "Meredithe", "Meridel", "Meridith", "Meriel", "Merilee", "Merilyn", "Meris", "Merissa", "Merl", "Merla", "Merle", "Merlina", "Merline", "Merna", "Merola", "Merralee", "Merridie", "Merrie", "Merrielle", "Merrile", "Merrilee", "Merrili", "Merrill", "Merrily", "Merry", "Mersey", "Meryl", "Meta", "Mia", "Micaela", "Michaela", "Michaelina", "Michaeline", "Michaella", "Michal", "Michel", "Michele", "Michelina", "Micheline", "Michell", "Michelle", "Micki", "Mickie", "Micky", "Midge", "Mignon", "Mignonne", "Miguela", "Miguelita", "Mikaela", "Mil", "Mildred", "Mildrid", "Milena", "Milicent", "Milissent", "Milka", "Milli", "Millicent", "Millie", "Millisent", "Milly", "Milzie", "Mimi", "Min", "Mina", "Minda", "Mindy", "Minerva", "Minetta", "Minette", "Minna", "Minnaminnie", "Minne", "Minni", "Minnie", "Minnnie", "Minny", "Minta", "Miquela", "Mira", "Mirabel", "Mirabella", "Mirabelle", "Miran", "Miranda", "Mireielle", "Mireille", "Mirella", "Mirelle", "Miriam", "Mirilla", "Mirna", "Misha", "Missie", "Missy", "Misti", "Misty", "Mitzi", "Modesta", "Modestia", "Modestine", "Modesty", "Moina", "Moira", "Moll", "Mollee", "Molli", "Mollie", "Molly", "Mommy", "Mona", "Monah", "Monica", "Monika", "Monique", "Mora", "Moreen", "Morena", "Morgan", "Morgana", "Morganica", "Morganne", "Morgen", "Moria", "Morissa", "Morna", "Moselle", "Moyna", "Moyra", "Mozelle", "Muffin", "Mufi", "Mufinella", "Muire", "Mureil", "Murial", "Muriel", "Murielle", "Myra", "Myrah", "Myranda", "Myriam", "Myrilla", "Myrle", "Myrlene", "Myrna", "Myrta", "Myrtia", "Myrtice", "Myrtie", "Myrtle", "Nada", "Nadean", "Nadeen", "Nadia", "Nadine", "Nadiya", "Nady", "Nadya", "Nalani", "Nan", "Nana", "Nananne", "Nance", "Nancee", "Nancey", "Nanci", "Nancie", "Nancy", "Nanete", "Nanette", "Nani", "Nanice", "Nanine", "Nannette", "Nanni", "Nannie", "Nanny", "Nanon", "Naoma", "Naomi", "Nara", "Nari", "Nariko", "Nat", "Nata", "Natala", "Natalee", "Natalie", "Natalina", "Nataline", "Natalya", "Natasha", "Natassia", "Nathalia", "Nathalie", "Natividad", "Natka", "Natty", "Neala", "Neda", "Nedda", "Nedi", "Neely", "Neila", "Neile", "Neilla", "Neille", "Nelia", "Nelie", "Nell", "Nelle", "Nelli", "Nellie", "Nelly", "Nerissa", "Nerita", "Nert", "Nerta", "Nerte", "Nerti", "Nertie", "Nerty", "Nessa", "Nessi", "Nessie", "Nessy", "Nesta", "Netta", "Netti", "Nettie", "Nettle", "Netty", "Nevsa", "Neysa", "Nichol", "Nichole", "Nicholle", "Nicki", "Nickie", "Nicky", "Nicol", "Nicola", "Nicole", "Nicolea", "Nicolette", "Nicoli", "Nicolina", "Nicoline", "Nicolle", "Nikaniki", "Nike", "Niki", "Nikki", "Nikkie", "Nikoletta", "Nikolia", "Nina", "Ninetta", "Ninette", "Ninnetta", "Ninnette", "Ninon", "Nissa", "Nisse", "Nissie", "Nissy", "Nita", "Nixie", "Noami", "Noel", "Noelani", "Noell", "Noella", "Noelle", "Noellyn", "Noelyn", "Noemi", "Nola", "Nolana", "Nolie", "Nollie", "Nomi", "Nona", "Nonah", "Noni", "Nonie", "Nonna", "Nonnah", "Nora", "Norah", "Norean", "Noreen", "Norene", "Norina", "Norine", "Norma", "Norri", "Norrie", "Norry", "Novelia", "Nydia", "Nyssa", "Octavia", "Odele", "Odelia", "Odelinda", "Odella", "Odelle", "Odessa", "Odetta", "Odette", "Odilia", "Odille", "Ofelia", "Ofella", "Ofilia", "Ola", "Olenka", "Olga", "Olia", "Olimpia", "Olive", "Olivette", "Olivia", "Olivie", "Oliy", "Ollie", "Olly", "Olva", "Olwen", "Olympe", "Olympia", "Olympie", "Ondrea", "Oneida", "Onida", "Oona", "Opal", "Opalina", "Opaline", "Ophelia", "Ophelie", "Ora", "Oralee", "Oralia", "Oralie", "Oralla", "Oralle", "Orel", "Orelee", "Orelia", "Orelie", "Orella", "Orelle", "Oriana", "Orly", "Orsa", "Orsola", "Ortensia", "Otha", "Othelia", "Othella", "Othilia", "Othilie", "Ottilie", "Page", "Paige", "Paloma", "Pam", "Pamela", "Pamelina", "Pamella", "Pammi", "Pammie", "Pammy", "Pandora", "Pansie", "Pansy", "Paola", "Paolina", "Papagena", "Pat", "Patience", "Patrica", "Patrice", "Patricia", "Patrizia", "Patsy", "Patti", "Pattie", "Patty", "Paula", "Paule", "Pauletta", "Paulette", "Pauli", "Paulie", "Paulina", "Pauline", "Paulita", "Pauly", "Pavia", "Pavla", "Pearl", "Pearla", "Pearle", "Pearline", "Peg", "Pegeen", "Peggi", "Peggie", "Peggy", "Pen", "Penelopa", "Penelope", "Penni", "Pennie", "Penny", "Pepi", "Pepita", "Peri", "Peria", "Perl", "Perla", "Perle", "Perri", "Perrine", "Perry", "Persis", "Pet", "Peta", "Petra", "Petrina", "Petronella", "Petronia", "Petronilla", "Petronille", "Petunia", "Phaedra", "Phaidra", "Phebe", "Phedra", "Phelia", "Phil", "Philipa", "Philippa", "Philippe", "Philippine", "Philis", "Phillida", "Phillie", "Phillis", "Philly", "Philomena", "Phoebe", "Phylis", "Phyllida", "Phyllis", "Phyllys", "Phylys", "Pia", "Pier", "Pierette", "Pierrette", "Pietra", "Piper", "Pippa", "Pippy", "Polly", "Pollyanna", "Pooh", "Poppy", "Portia", "Pris", "Prisca", "Priscella", "Priscilla", "Prissie", "Pru", "Prudence", "Prudi", "Prudy", "Prue", "Queenie", "Quentin", "Querida", "Quinn", "Quinta", "Quintana", "Quintilla", "Quintina", "Rachael", "Rachel", "Rachele", "Rachelle", "Rae", "Raeann", "Raf", "Rafa", "Rafaela", "Rafaelia", "Rafaelita", "Rahal", "Rahel", "Raina", "Raine", "Rakel", "Ralina", "Ramona", "Ramonda", "Rana", "Randa", "Randee", "Randene", "Randi", "Randie", "Randy", "Ranee", "Rani", "Rania", "Ranice", "Ranique", "Ranna", "Raphaela", "Raquel", "Raquela", "Rasia", "Rasla", "Raven", "Ray", "Raychel", "Raye", "Rayna", "Raynell", "Rayshell", "Rea", "Reba", "Rebbecca", "Rebe", "Rebeca", "Rebecca", "Rebecka", "Rebeka", "Rebekah", "Rebekkah", "Ree", "Reeba", "Reena", "Reeta", "Reeva", "Regan", "Reggi", "Reggie", "Regina", "Regine", "Reiko", "Reina", "Reine", "Remy", "Rena", "Renae", "Renata", "Renate", "Rene", "Renee", "Renell", "Renelle", "Renie", "Rennie", "Reta", "Retha", "Revkah", "Rey", "Reyna", "Rhea", "Rheba", "Rheta", "Rhetta", "Rhiamon", "Rhianna", "Rhianon", "Rhoda", "Rhodia", "Rhodie", "Rhody", "Rhona", "Rhonda", "Riane", "Riannon", "Rianon", "Rica", "Ricca", "Rici", "Ricki", "Rickie", "Ricky", "Riki", "Rikki", "Rina", "Risa", "Rita", "Riva", "Rivalee", "Rivi", "Rivkah", "Rivy", "Roana", "Roanna", "Roanne", "Robbi", "Robbie", "Robbin", "Robby", "Robbyn", "Robena", "Robenia", "Roberta", "Robin", "Robina", "Robinet", "Robinett", "Robinetta", "Robinette", "Robinia", "Roby", "Robyn", "Roch", "Rochell", "Rochella", "Rochelle", "Rochette", "Roda", "Rodi", "Rodie", "Rodina", "Rois", "Romola", "Romona", "Romonda", "Romy", "Rona", "Ronalda", "Ronda", "Ronica", "Ronna", "Ronni", "Ronnica", "Ronnie", "Ronny", "Roobbie", "Rora", "Rori", "Rorie", "Rory", "Ros", "Rosa", "Rosabel", "Rosabella", "Rosabelle", "Rosaleen", "Rosalia", "Rosalie", "Rosalind", "Rosalinda", "Rosalinde", "Rosaline", "Rosalyn", "Rosalynd", "Rosamond", "Rosamund", "Rosana", "Rosanna", "Rosanne", "Rose", "Roseann", "Roseanna", "Roseanne", "Roselia", "Roselin", "Roseline", "Rosella", "Roselle", "Rosemaria", "Rosemarie", "Rosemary", "Rosemonde", "Rosene", "Rosetta", "Rosette", "Roshelle", "Rosie", "Rosina", "Rosita", "Roslyn", "Rosmunda", "Rosy", "Row", "Rowe", "Rowena", "Roxana", "Roxane", "Roxanna", "Roxanne", "Roxi", "Roxie", "Roxine", "Roxy", "Roz", "Rozalie", "Rozalin", "Rozamond", "Rozanna", "Rozanne", "Roze", "Rozele", "Rozella", "Rozelle", "Rozina", "Rubetta", "Rubi", "Rubia", "Rubie", "Rubina", "Ruby", "Ruperta", "Ruth", "Ruthann", "Ruthanne", "Ruthe", "Ruthi", "Ruthie", "Ruthy", "Ryann", "Rycca", "Saba", "Sabina", "Sabine", "Sabra", "Sabrina", "Sacha", "Sada", "Sadella", "Sadie", "Sadye", "Saidee", "Sal", "Salaidh", "Sallee", "Salli", "Sallie", "Sally", "Sallyann", "Sallyanne", "Saloma", "Salome", "Salomi", "Sam", "Samantha", "Samara", "Samaria", "Sammy", "Sande", "Sandi", "Sandie", "Sandra", "Sandy", "Sandye", "Sapphira", "Sapphire", "Sara", "Sara-ann", "Saraann", "Sarah", "Sarajane", "Saree", "Sarena", "Sarene", "Sarette", "Sari", "Sarina", "Sarine", "Sarita", "Sascha", "Sasha", "Sashenka", "Saudra", "Saundra", "Savina", "Sayre", "Scarlet", "Scarlett", "Sean", "Seana", "Seka", "Sela", "Selena", "Selene", "Selestina", "Selia", "Selie", "Selina", "Selinda", "Seline", "Sella", "Selle", "Selma", "Sena", "Sephira", "Serena", "Serene", "Shae", "Shaina", "Shaine", "Shalna", "Shalne", "Shana", "Shanda", "Shandee", "Shandeigh", "Shandie", "Shandra", "Shandy", "Shane", "Shani", "Shanie", "Shanna", "Shannah", "Shannen", "Shannon", "Shanon", "Shanta", "Shantee", "Shara", "Sharai", "Shari", "Sharia", "Sharity", "Sharl", "Sharla", "Sharleen", "Sharlene", "Sharline", "Sharon", "Sharona", "Sharron", "Sharyl", "Shaun", "Shauna", "Shawn", "Shawna", "Shawnee", "Shay", "Shayla", "Shaylah", "Shaylyn", "Shaylynn", "Shayna", "Shayne", "Shea", "Sheba", "Sheela", "Sheelagh", "Sheelah", "Sheena", "Sheeree", "Sheila", "Sheila-kathryn", "Sheilah", "Shel", "Shela", "Shelagh", "Shelba", "Shelbi", "Shelby", "Shelia", "Shell", "Shelley", "Shelli", "Shellie", "Shelly", "Shena", "Sher", "Sheree", "Sheri", "Sherie", "Sherill", "Sherilyn", "Sherline", "Sherri", "Sherrie", "Sherry", "Sherye", "Sheryl", "Shina", "Shir", "Shirl", "Shirlee", "Shirleen", "Shirlene", "Shirley", "Shirline", "Shoshana", "Shoshanna", "Siana", "Sianna", "Sib", "Sibbie", "Sibby", "Sibeal", "Sibel", "Sibella", "Sibelle", "Sibilla", "Sibley", "Sibyl", "Sibylla", "Sibylle", "Sidoney", "Sidonia", "Sidonnie", "Sigrid", "Sile", "Sileas", "Silva", "Silvana", "Silvia", "Silvie", "Simona", "Simone", "Simonette", "Simonne", "Sindee", "Siobhan", "Sioux", "Siouxie", "Sisely", "Sisile", "Sissie", "Sissy", "Siusan", "Sofia", "Sofie", "Sondra", "Sonia", "Sonja", "Sonni", "Sonnie", "Sonnnie", "Sonny", "Sonya", "Sophey", "Sophi", "Sophia", "Sophie", "Sophronia", "Sorcha", "Sosanna", "Stace", "Stacee", "Stacey", "Staci", "Stacia", "Stacie", "Stacy", "Stafani", "Star", "Starla", "Starlene", "Starlin", "Starr", "Stefa", "Stefania", "Stefanie", "Steffane", "Steffi", "Steffie", "Stella", "Stepha", "Stephana", "Stephani", "Stephanie", "Stephannie", "Stephenie", "Stephi", "Stephie", "Stephine", "Stesha", "Stevana", "Stevena", "Stoddard", "Storm", "Stormi", "Stormie", "Stormy", "Sue", "Suellen", "Sukey", "Suki", "Sula", "Sunny", "Sunshine", "Susan", "Susana", "Susanetta", "Susann", "Susanna", "Susannah", "Susanne", "Susette", "Susi", "Susie", "Susy", "Suzann", "Suzanna", "Suzanne", "Suzette", "Suzi", "Suzie", "Suzy", "Sybil", "Sybila", "Sybilla", "Sybille", "Sybyl", "Sydel", "Sydelle", "Sydney", "Sylvia", "Tabatha", "Tabbatha", "Tabbi", "Tabbie", "Tabbitha", "Tabby", "Tabina", "Tabitha", "Taffy", "Talia", "Tallia", "Tallie", "Tallou", "Tallulah", "Tally", "Talya", "Talyah", "Tamar", "Tamara", "Tamarah", "Tamarra", "Tamera", "Tami", "Tamiko", "Tamma", "Tammara", "Tammi", "Tammie", "Tammy", "Tamqrah", "Tamra", "Tana", "Tandi", "Tandie", "Tandy", "Tanhya", "Tani", "Tania", "Tanitansy", "Tansy", "Tanya", "Tara", "Tarah", "Tarra", "Tarrah", "Taryn", "Tasha", "Tasia", "Tate", "Tatiana", "Tatiania", "Tatum", "Tawnya", "Tawsha", "Ted", "Tedda", "Teddi", "Teddie", "Teddy", "Tedi", "Tedra", "Teena", "Teirtza", "Teodora", "Tera", "Teresa", "Terese", "Teresina", "Teresita", "Teressa", "Teri", "Teriann", "Terra", "Terri", "Terrie", "Terrijo", "Terry", "Terrye", "Tersina", "Terza", "Tess", "Tessa", "Tessi", "Tessie", "Tessy", "Thalia", "Thea", "Theadora", "Theda", "Thekla", "Thelma", "Theo", "Theodora", "Theodosia", "Theresa", "Therese", "Theresina", "Theresita", "Theressa", "Therine", "Thia", "Thomasa", "Thomasin", "Thomasina", "Thomasine", "Tiena", "Tierney", "Tiertza", "Tiff", "Tiffani", "Tiffanie", "Tiffany", "Tiffi", "Tiffie", "Tiffy", "Tilda", "Tildi", "Tildie", "Tildy", "Tillie", "Tilly", "Tim", "Timi", "Timmi", "Timmie", "Timmy", "Timothea", "Tina", "Tine", "Tiphani", "Tiphanie", "Tiphany", "Tish", "Tisha", "Tobe", "Tobey", "Tobi", "Toby", "Tobye", "Toinette", "Toma", "Tomasina", "Tomasine", "Tomi", "Tommi", "Tommie", "Tommy", "Toni", "Tonia", "Tonie", "Tony", "Tonya", "Tonye", "Tootsie", "Torey", "Tori", "Torie", "Torrie", "Tory", "Tova", "Tove", "Tracee", "Tracey", "Traci", "Tracie", "Tracy", "Trenna", "Tresa", "Trescha", "Tressa", "Tricia", "Trina", "Trish", "Trisha", "Trista", "Trix", "Trixi", "Trixie", "Trixy", "Truda", "Trude", "Trudey", "Trudi", "Trudie", "Trudy", "Trula", "Tuesday", "Twila", "Twyla", "Tybi", "Tybie", "Tyne", "Ula", "Ulla", "Ulrica", "Ulrika", "Ulrikaumeko", "Ulrike", "Umeko", "Una", "Ursa", "Ursala", "Ursola", "Ursula", "Ursulina", "Ursuline", "Uta", "Val", "Valaree", "Valaria", "Vale", "Valeda", "Valencia", "Valene", "Valenka", "Valentia", "Valentina", "Valentine", "Valera", "Valeria", "Valerie", "Valery", "Valerye", "Valida", "Valina", "Valli", "Vallie", "Vally", "Valma", "Valry", "Van", "Vanda", "Vanessa", "Vania", "Vanna", "Vanni", "Vannie", "Vanny", "Vanya", "Veda", "Velma", "Velvet", "Venita", "Venus", "Vera", "Veradis", "Vere", "Verena", "Verene", "Veriee", "Verile", "Verina", "Verine", "Verla", "Verna", "Vernice", "Veronica", "Veronika", "Veronike", "Veronique", "Vevay", "Vi", "Vicki", "Vickie", "Vicky", "Victoria", "Vida", "Viki", "Vikki", "Vikky", "Vilhelmina", "Vilma", "Vin", "Vina", "Vinita", "Vinni", "Vinnie", "Vinny", "Viola", "Violante", "Viole", "Violet", "Violetta", "Violette", "Virgie", "Virgina", "Virginia", "Virginie", "Vita", "Vitia", "Vitoria", "Vittoria", "Viv", "Viva", "Vivi", "Vivia", "Vivian", "Viviana", "Vivianna", "Vivianne", "Vivie", "Vivien", "Viviene", "Vivienne", "Viviyan", "Vivyan", "Vivyanne", "Vonni", "Vonnie", "Vonny", "Vyky", "Wallie", "Wallis", "Walliw", "Wally", "Waly", "Wanda", "Wandie", "Wandis", "Waneta", "Wanids", "Wenda", "Wendeline", "Wendi", "Wendie", "Wendy", "Wendye", "Wenona", "Wenonah", "Whitney", "Wileen", "Wilhelmina", "Wilhelmine", "Wilie", "Willa", "Willabella", "Willamina", "Willetta", "Willette", "Willi", "Willie", "Willow", "Willy", "Willyt", "Wilma", "Wilmette", "Wilona", "Wilone", "Wilow", "Windy", "Wini", "Winifred", "Winna", "Winnah", "Winne", "Winni", "Winnie", "Winnifred", "Winny", "Winona", "Winonah", "Wren", "Wrennie", "Wylma", "Wynn", "Wynne", "Wynnie", "Wynny", "Xaviera", "Xena", "Xenia", "Xylia", "Xylina", "Yalonda", "Yasmeen", "Yasmin", "Yelena", "Yetta", "Yettie", "Yetty", "Yevette", "Ynes", "Ynez", "Yoko", "Yolanda", "Yolande", "Yolane", "Yolanthe", "Yoshi", "Yoshiko", "Yovonnda", "Ysabel", "Yvette", "Yvonne", "Zabrina", "Zahara", "Zandra", "Zaneta", "Zara", "Zarah", "Zaria", "Zarla", "Zea", "Zelda", "Zelma", "Zena", "Zenia", "Zia", "Zilvia", "Zita", "Zitella", "Zoe", "Zola", "Zonda", "Zondra", "Zonnya", "Zora", "Zorah", "Zorana", "Zorina", "Zorine", "Zsazsa", "Zulema", "Zuzana"];
class yO {
    static generate(t = {}) {
        let n = t.min || 1,
            r = t.max || 999;
        if (t.length) {
            const a = Math.pow(10, t.length);
            return n = a / 10, r = a - 1, [`${Math.floor(Math.random()*(r-n))+n}`]
        }
        return [`${Math.floor(Math.random()*(r-n))+n}`]
    }
}
var Wg = {},
    zg = {},
    qg = {},
    Yg = {},
    Mt = {};
const bO = {},
    vO = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: bO
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    _O = lO(vO);
Object.defineProperty(Mt, "__esModule", {
    value: !0
});
Mt.getCrypto = Mt.getRootWebCrypto = Mt.getWebCrypto = Mt.getNodeCrypto = void 0;
var Yc = function() {
    if (!(typeof window < "u" && window.crypto)) return typeof window > "u" && typeof crypto < "u" ? void 0 : _O
};
Mt.getNodeCrypto = Yc;
var Xc = function() {
    if (typeof window < "u" && window.crypto) return window.crypto.subtle;
    if (typeof window > "u" && typeof crypto < "u") return crypto.subtle
};
Mt.getWebCrypto = Xc;
var Xg = function() {
    if (typeof window < "u" && window.crypto) return window.crypto;
    if (typeof window > "u" && typeof crypto < "u") return crypto
};
Mt.getRootWebCrypto = Xg;
var Qg = function() {
    var e = Xc(),
        t = Yc();
    return typeof t < "u" ? {
        name: "nodeCrypto",
        crypto: t
    } : typeof e < "u" ? {
        name: "webCrypto",
        crypto: e
    } : {
        name: void 0
    }
};
Mt.getCrypto = Qg;
Mt.default = {
    getNodeCrypto: Yc,
    getWebCrypto: Xc,
    getRootWebCrypto: Xg,
    getCrypto: Qg
};
(function(e) {
    var t = Ue && Ue.__createBinding || (Object.create ? function(c, u, f, d) {
            d === void 0 && (d = f), Object.defineProperty(c, d, {
                enumerable: !0,
                get: function() {
                    return u[f]
                }
            })
        } : function(c, u, f, d) {
            d === void 0 && (d = f), c[d] = u[f]
        }),
        n = Ue && Ue.__setModuleDefault || (Object.create ? function(c, u) {
            Object.defineProperty(c, "default", {
                enumerable: !0,
                value: u
            })
        } : function(c, u) {
            c.default = u
        }),
        r = Ue && Ue.__importStar || function(c) {
            if (c && c.__esModule) return c;
            var u = {};
            if (c != null)
                for (var f in c) f !== "default" && Object.prototype.hasOwnProperty.call(c, f) && t(u, c, f);
            return n(u, c), u
        };
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.getRandomBytes = e.getRandomSampledString = e.getRandomAsciiString = e.getRandomString = void 0;
    var a = r(Mt),
        i = function(c) {
            for (var u = (0, e.getRandomBytes)(c), f = (0, e.getRandomBytes)(c), d = "", p = 0; p < c; p++) f[p] = f[p] % 3, u[p] = f[p] === 0 ? u[p] % 10 + 48 : u[p] % 26 + (f[p] === 1 ? 65 : 97), d += String.fromCharCode(u[p]);
            return d
        };
    e.getRandomString = i;
    var o = function(c) {
        for (var u = (0, e.getRandomBytes)(c), f = "", d = 0; d < c; d++) u[d] = u[d] % 94 + 32, f += String.fromCharCode(u[d]);
        return f
    };
    e.getRandomAsciiString = o;
    var s = function(c, u) {
        var f = u.length;
        if (f === 0) return "";
        for (var d = (0, e.getRandomBytes)(c), p = "", v = 0; v < c; v++) p += u[d[v] % f];
        return p
    };
    e.getRandomSampledString = s;
    var l = function(c) {
        var u = a.getRootWebCrypto(),
            f = a.getNodeCrypto();
        if (typeof u < "u" && typeof u.getRandomValues == "function") {
            var d = new Uint8Array(c);
            return u.getRandomValues(d), d
        } else {
            if (typeof f < "u") return new Uint8Array(f.randomBytes(c));
            throw new Error("UnsupportedEnvironment")
        }
    };
    e.getRandomBytes = l
})(Yg);
(function(e) {
    var t = Ue && Ue.__createBinding || (Object.create ? function(i, o, s, l) {
            l === void 0 && (l = s), Object.defineProperty(i, l, {
                enumerable: !0,
                get: function() {
                    return o[s]
                }
            })
        } : function(i, o, s, l) {
            l === void 0 && (l = s), i[l] = o[s]
        }),
        n = Ue && Ue.__setModuleDefault || (Object.create ? function(i, o) {
            Object.defineProperty(i, "default", {
                enumerable: !0,
                value: o
            })
        } : function(i, o) {
            i.default = o
        }),
        r = Ue && Ue.__importStar || function(i) {
            if (i && i.__esModule) return i;
            var o = {};
            if (i != null)
                for (var s in i) s !== "default" && Object.prototype.hasOwnProperty.call(i, s) && t(o, i, s);
            return n(o, i), o
        };
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.getRandomSampledString = e.getRandomString = e.getRandomAsciiString = e.getRandomBytes = void 0;
    var a = r(Yg);
    e.getRandomBytes = a.getRandomBytes, e.getRandomAsciiString = a.getRandomAsciiString, e.getRandomString = a.getRandomString, e.getRandomSampledString = a.getRandomSampledString, e.default = {
        getRandomBytes: e.getRandomBytes,
        getRandomAsciiString: e.getRandomAsciiString,
        getRandomString: e.getRandomString,
        getRandomSampledString: e.getRandomSampledString
    }
})(qg);
(function(e) {
    var t = Ue && Ue.__importDefault || function(h) {
        return h && h.__esModule ? h : {
            default: h
        }
    };
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.generateMultiple = e.generate = void 0;
    var n = t(qg),
        r = 256,
        a = void 0,
        i = new Uint8Array,
        o = function() {
            (a === void 0 || a >= i.length) && (a = 0, i = n.default.getRandomBytes(r));
            var h = i[a];
            return a += 1, h
        },
        s = function(h) {
            for (var b = o(); b >= 256 - 256 % h;) b = o();
            return b % h
        },
        l = "abcdefghijklmnopqrstuvwxyz",
        c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        u = "0123456789",
        f = "\\!@#$%^&*()+_-=}{[]|:;\"/?.><,`~'",
        d = /[ilLI|`oO0]/g,
        p = [{
            name: "lowercase",
            rule: /[a-z]/
        }, {
            name: "uppercase",
            rule: /[A-Z]/
        }, {
            name: "numbers",
            rule: /[0-9]/
        }, {
            name: "symbols",
            rule: /[\\!@#$%^&*()+_\-=}{[\]|:;"/?.><,`~']/
        }],
        v = function(h, b) {
            for (var m = "", y = h.length, C = b.length, S = 0; S < y; S++) m += b[s(C)];
            if (h.strict) {
                var A = p.every(function(R) {
                    if (h[R.name || "uppercase"] == !1) return !0;
                    if (R.name === "symbols" && typeof h[R.name] == "string") {
                        var O = new RegExp("[".concat(h[R.name], "]"));
                        return O.test(m)
                    }
                    return R.rule.test(m)
                });
                if (!A) return v(h, b)
            }
            return m
        },
        E = function(h) {
            if (h = h || {}, Object.prototype.hasOwnProperty.call(h, "length") || (h.length = 10), Object.prototype.hasOwnProperty.call(h, "numbers") || (h.numbers = !1), Object.prototype.hasOwnProperty.call(h, "symbols") || (h.symbols = !1), Object.prototype.hasOwnProperty.call(h, "exclude") || (h.exclude = ""), Object.prototype.hasOwnProperty.call(h, "uppercase") || (h.uppercase = !0), Object.prototype.hasOwnProperty.call(h, "lowercase") || (h.lowercase = !0), Object.prototype.hasOwnProperty.call(h, "excludeSimilarCharacters") || (h.excludeSimilarCharacters = !1), Object.prototype.hasOwnProperty.call(h, "strict") || (h.strict = !1), h.strict) {
                var b = 1 + (h.numbers ? 1 : 0) + (h.symbols ? 1 : 0) + (h.uppercase ? 1 : 0);
                if (b > h.length) throw new TypeError("Length must correlate with strict guidelines")
            }
            var m = "";
            if (h.lowercase && (m += l), h.uppercase && (m += c), h.numbers && (m += u), h.symbols && (typeof h.symbols == "string" ? m += h.symbols : m += f), !m) throw new TypeError("At least one rule for pools must be true");
            h.excludeSimilarCharacters && (m = m.replace(d, ""));
            for (var y = h.exclude.length; y--;) m = m.replace(h.exclude[y], "");
            return v(h, m)
        };
    e.generate = E;
    var w = function(h, b) {
        for (var m = [], y = 0; y < h; y++) m.push((0, e.generate)(b));
        return m
    };
    e.generateMultiple = w
})(zg);
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.generateMultiple = e.generate = void 0;
    var t = zg;
    Object.defineProperty(e, "generate", {
        enumerable: !0,
        get: function() {
            return t.generate
        }
    }), Object.defineProperty(e, "generateMultiple", {
        enumerable: !0,
        get: function() {
            return t.generateMultiple
        }
    }), e.default = {
        generate: t.generate,
        generateMultiple: t.generateMultiple
    }
})(Wg);
const vn = To("account", () => {
        const e = Nt(),
            t = aa("accounts", []),
            n = aa("active", {}),
            r = aa("account", {}),
            a = aa("vuex", {}),
            i = W(() => t.value.filter(A => A.id !== n.value.id)),
            o = W(() => n.value),
            s = W(() => {
                var A;
                return (A = r.value) != null && A.token ? r.value : null
            }),
            l = W(() => n.value ? n.value.address : "Loading...");

        function c(A) {
            return R => t.value.find(O => O.id === R)
        }

        function u(A) {
            t.value.find(R => R.id === A.id) || t.value.push(A), n.value = A
        }

        function f() {
            var A, R;
            try {
                (R = (A = a.value) == null ? void 0 : A.accounts) != null && R.list.length && a.value.accounts.list.forEach(O => {
                    u({
                        id: O.id,
                        address: O.address,
                        password: O.password
                    })
                }), a.value = null
            } catch {
                a.value = null
            }
        }

        function d(A) {
            n.value = t.value.find(R => R.id === A)
        }

        function p() {
            var A;
            if ((A = n.value) != null && A.id) {
                const R = n.value.id;
                t.value = t.value.filter(O => O.id !== R)
            }
        }

        function v() {
            n.value = null, r.value = null
        }

        function E(A) {
            r.value = A
        }
        async function w(A) {
            E(null), await $fetch("/token", {
                baseURL: e.public.api,
                method: "POST",
                body: {
                    address: A.address.toLowerCase(),
                    password: A.password
                }
            }).then(async R => {
                E(R), await b(), u({
                    id: R.id,
                    address: A.address,
                    password: A.password
                }), d(R.id), await S({
                    notificationsAction: !0,
                    messagesAction: !0
                }), await ro().fetchMessages(), await Na().subscribe()
            }).catch(R => {
                var O;
                throw R.data ? ((O = R.data) == null ? void 0 : O.message) ? ? "Error!" : R.data
            })
        }
        async function h(A, R, O) {
            await $fetch("/accounts", {
                baseURL: e.public.api,
                method: "POST",
                body: {
                    address: `${A.toLowerCase()}@${R}`,
                    password: O
                }
            }).then(async N => {
                await w({
                    address: N.address,
                    password: O
                })
            }).catch(N => {
                var x;
                throw ((x = N.data) == null ? void 0 : x.status) === 422 ? N.data.violations[0].message : N.data ? N.data["hydra:description"] ? ? "Error!" : N.data.message
            })
        }
        async function b() {
            r.value.token && await $fetch("/me", {
                baseURL: e.public.api,
                method: "GET",
                headers: {
                    Authorization: `Bearer ${r.value.token}`
                }
            }).then(A => (E({ ...r.value,
                ...A
            }), { ...r.value,
                ...A
            })).catch(A => {
                throw A.data ? A.data.message ? ? "Error!" : A.data.message
            })
        }
        async function m(A = !1) {
            var N;
            const R = fO();
            await R.fetchDomains();
            const O = R.getDomain.domain;
            if (f(), A) {
                const x = t.value;
                x.length && (n.value = x.shift())
            }
            if (!((N = n.value) != null && N.address)) {
                const x = yO.generate({
                        length: Math.floor(Math.random() * 4) + 1
                    }),
                    M = [gO, mO, hO, x],
                    [K, ne] = M.sort(() => Math.random() - .5).slice(0, 2),
                    te = pO({
                        dictionaries: [K, ne],
                        length: 2,
                        separator: "",
                        style: "lowerCase"
                    }),
                    J = Wg.generate({
                        length: 10,
                        numbers: !0,
                        symbols: !0
                    });
                try {
                    await h(te, O, J)
                } catch {
                    return m(A)
                }
            }
            return await w({
                address: n.value.address,
                password: n.value.password
            })
        }
        async function y() {
            return r.value.id ? (await $fetch(`/accounts/${r.value.id}`, {
                baseURL: e.public.api,
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${r.value.token}`
                }
            }), await C()) : await C()
        }
        async function C(A) {
            const {
                removeAction: R = !0,
                autoAction: O = !0,
                redirectAction: N = !0
            } = A || {};
            await S({
                removeAction: R,
                removeActiveAction: !0,
                autoAction: O,
                selectionAction: !0,
                redirectAction: N
            })
        }
        async function S(A) {
            const {
                removeAction: R = !1,
                removeActiveAction: O = !1,
                logoutAction: N = !1,
                autoAction: x = !1,
                redirectAction: M = !1,
                notificationsAction: K = !0,
                messagesAction: ne = !0,
                selectionAction: te = !1
            } = A || {};
            R && p(), N && C(), O && v(), K && Na().unsubscribe(), ne && ro().clearMessages(), x && await m(te), M && await Jg()
        }
        return {
            auto: m,
            create: h,
            getAccountById: c,
            getList: i,
            getActive: o,
            getAddress: l,
            getSession: s,
            destroy: y,
            fetchSession: b,
            login: w,
            logout: C,
            list: t,
            active: n,
            session: r,
            startImport: f
        }
    }),
    Jd = Q(!1),
    wO = Qe({
        async setup(e) {},
        hooks: {
            "page:finish": async function() {
                Jd.value || (Jd.value = !0, vn().startImport(), vn().getSession ? await vn().fetchSession() : await vn().auto(!0), await Na().subscribe())
            }
        }
    }),
    EO = Qe({
        async setup(e) {
            wo({
                script: [{
                    type: "text/javascript",
                    async: !0,
                    children: '!function(){var t=document.createElement("script"),e=document.getElementsByTagName("script")[0],a="https://cmp.quantcast.com".concat("/choice/","mDmnCcUxwdmpF","/","mail.tm","/choice.js?tag_version=V2"),n=0;t.async=!0,t.type="text/javascript",t.src=a,e.parentNode.insertBefore(t,e),function(){for(var t,a=[],i=window;i;){try{if(i.frames.__tcfapiLocator){t=i;break}}catch(t){}if(i===window.top)break;i=i.parent}t||(function t(){var e,a=i.document,n=!!i.frames.__tcfapiLocator;return n||(a.body?((e=a.createElement("iframe")).style.cssText="display:none",e.name="__tcfapiLocator",a.body.appendChild(e)):setTimeout(t,5)),!n}(),i.__tcfapi=function(){var t,e=arguments;if(!e.length)return a;"setGdprApplies"===e[0]?3<e.length&&2===e[2]&&"boolean"==typeof e[3]&&(t=e[3],"function"==typeof e[2]&&e[2]("set",!0)):"ping"===e[0]?"function"==typeof e[2]&&e[2]({gdprApplies:t,cmpLoaded:!1,cmpStatus:"stub"}):("init"===e[0]&&"object"==typeof e[3]&&(e[3]=Object.assign(e[3],{tag_version:"V2"})),a.push(e))},i.addEventListener("message",function(a){var n="string"==typeof a.data,t={};try{t=n?JSON.parse(a.data):a.data}catch(a){}var i=t.__tcfapiCall;i&&window.__tcfapi(i.command,i.version,function(t,e){e={__tcfapiReturn:{returnValue:t,success:e,callId:i.callId}};n&&(e=JSON.stringify(e)),a&&a.source&&a.source.postMessage&&a.source.postMessage(e,"*")},i.parameter)},!1))}();function i(){var t=arguments;typeof window.__uspapi!==i&&setTimeout(function(){void 0!==window.__uspapi&&window.__uspapi.apply(window.__uspapi,t)},500)}var o;void 0===window.__uspapi&&(window.__uspapi=i,o=setInterval(function(){n++,window.__uspapi===i&&n<3?console.warn("USP is not accessible"):clearInterval(o)},6e3))}()'
                }, {
                    type: "text/javascript",
                    "data-cfasync": "false",
                    children: `window.freestar = window.freestar || {};
          window.freestar.hitTime = Date.now();
          window.freestar.queue = window.freestar.queue || [];
          window.freestar.config = window.freestar.config || {};
          window.freestar.config.enabled_slots = window.freestar.config.enabled_slots || [];`
                }, {
                    "data-cfasync": "false",
                    src: "https://a.pub.network/mail-tm/pubfig.min.js",
                    async: !0
                }]
            })
        }
    }),
    CO = [Ow, Pw, HE, pC, yC, bC, _C, CS, MT, PT, V1, G1, q1, Y1, X1, wO, EO],
    Gd = {
        pwaInDevEnvironment: !1,
        webManifest: {
            href: "/manifest.webmanifest",
            useCredentials: !1,
            linkTag: '<link rel="manifest" href="/manifest.webmanifest">'
        }
    },
    AO = Ne({
        async setup() {
            if (Gd) {
                const e = Q({
                    link: []
                });
                wo(e);
                const {
                    webManifest: t
                } = Gd;
                if (t) {
                    const {
                        href: n,
                        useCredentials: r
                    } = t;
                    r ? e.value.link.push({
                        rel: "manifest",
                        href: n,
                        crossorigin: "use-credentials"
                    }) : e.value.link.push({
                        rel: "manifest",
                        href: n
                    })
                }
            }
            return () => null
        }
    }),
    LO = (e, t) => t.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, n => {
        var r;
        return ((r = e.params[n.slice(1)]) == null ? void 0 : r.toString()) || ""
    }),
    xl = (e, t) => {
        const n = e.route.matched.find(a => {
                var i;
                return ((i = a.components) == null ? void 0 : i.default) === e.Component.type
            }),
            r = t ? ? (n == null ? void 0 : n.meta.key) ? ? (n && LO(e.route, n));
        return typeof r == "function" ? r(e.route) : r
    },
    SO = (e, t) => ({
        default: () => e ? Be(Fb, e === !0 ? {} : e, t) : t
    }),
    TO = Ne({
        props: {
            vnode: {
                type: Object,
                required: !0
            },
            route: {
                type: Object,
                required: !0
            },
            vnodeRef: Object,
            renderKey: String,
            trackRootNodes: Boolean
        },
        setup(e) {
            const t = e.renderKey,
                n = e.route,
                r = {};
            for (const a in e.route) Object.defineProperty(r, a, {
                get: () => t === e.renderKey ? e.route[a] : n[a]
            });
            return Qn(Vr, Ha(r)), () => Be(e.vnode, {
                ref: e.vnodeRef
            })
        }
    }),
    kO = Ne({
        name: "NuxtPage",
        inheritAttrs: !1,
        props: {
            name: {
                type: String
            },
            transition: {
                type: [Boolean, Object],
                default: void 0
            },
            keepalive: {
                type: [Boolean, Object],
                default: void 0
            },
            route: {
                type: Object
            },
            pageKey: {
                type: [Function, String],
                default: null
            }
        },
        setup(e, {
            attrs: t,
            expose: n
        }) {
            const r = ge(),
                a = Q(),
                i = Je(Vr, null);
            n({
                pageRef: a
            });
            const o = Je(Ih, null);
            let s;
            const l = r.deferHydration();
            return () => Be(qh, {
                name: e.name,
                route: e.route,
                ...t
            }, {
                default: c => {
                    const u = MO(i, c.route, c.Component),
                        f = i && i.matched.length === c.route.matched.length;
                    if (!c.Component) {
                        if (s && !f) return s;
                        l();
                        return
                    }
                    if (s && o && !o.isCurrent(c.route)) return s;
                    if (u && i && (!o || o != null && o.isCurrent(i))) return f ? s : null;
                    const d = xl(c, e.pageKey),
                        p = !!(e.transition ? ? c.route.meta.pageTransition ? ? Ys),
                        v = p && OO([e.transition, c.route.meta.pageTransition, Ys, {
                            onAfterLeave: () => {
                                r.callHook("page:transition:finish", c.Component)
                            }
                        }].filter(Boolean)),
                        E = e.keepalive ? ? c.route.meta.keepalive ? ? ww;
                    return s = Yh(Ga, p && v, SO(E, Be(oc, {
                        suspensible: !0,
                        onPending: () => r.callHook("page:start", c.Component),
                        onResolve: () => {
                            St(() => r.callHook("page:finish", c.Component).finally(l))
                        }
                    }, {
                        default: () => {
                            const w = Be(TO, {
                                key: d || void 0,
                                vnode: c.Component,
                                route: c.route,
                                renderKey: d || void 0,
                                trackRootNodes: p,
                                vnodeRef: a
                            });
                            return E && (w.type.name = c.Component.type.name || c.Component.type.__name || "RouteProvider"), w
                        }
                    }))).default(), s
                }
            })
        }
    });

function RO(e) {
    return Array.isArray(e) ? e : e ? [e] : []
}

function OO(e) {
    const t = e.map(n => ({ ...n,
        onAfterLeave: RO(n.onAfterLeave)
    }));
    return Eo(...t)
}

function MO(e, t, n) {
    if (!e) return !1;
    const r = t.matched.findIndex(a => {
        var i;
        return ((i = a.components) == null ? void 0 : i.default) === (n == null ? void 0 : n.type)
    });
    return !r || r === -1 ? !1 : t.matched.slice(0, r).some((a, i) => {
        var o, s, l;
        return ((o = a.components) == null ? void 0 : o.default) !== ((l = (s = e.matched[i]) == null ? void 0 : s.components) == null ? void 0 : l.default)
    }) || n && xl({
        route: t,
        Component: n
    }) !== xl({
        route: e,
        Component: n
    })
}
const PO = Ne({
        name: "LayoutLoader",
        inheritAttrs: !1,
        props: {
            name: String,
            layoutProps: Object
        },
        async setup(e, t) {
            const n = await Gn[e.name]().then(r => r.default || r);
            return () => Be(n, e.layoutProps, t.slots)
        }
    }),
    xO = Ne({
        name: "NuxtLayout",
        inheritAttrs: !1,
        props: {
            name: {
                type: [String, Boolean, Object],
                default: null
            }
        },
        setup(e, t) {
            const n = ge(),
                r = Je(Vr),
                a = r === Hr() ? So() : r,
                i = W(() => pe(e.name) ? ? a.meta.layout ? ? "default"),
                o = Q();
            t.expose({
                layoutRef: o
            });
            const s = n.deferHydration();
            return () => {
                const l = i.value && i.value in Gn,
                    c = a.meta.layoutTransition ? ? _w;
                return Yh(Ga, l && c, {
                    default: () => Be(oc, {
                        suspensible: !0,
                        onResolve: () => {
                            St(s)
                        }
                    }, {
                        default: () => Be(IO, {
                            layoutProps: it(t.attrs, {
                                ref: o
                            }),
                            key: i.value || void 0,
                            name: i.value,
                            shouldProvide: !e.name,
                            hasTransition: !!c
                        }, t.slots)
                    })
                }).default()
            }
        }
    }),
    IO = Ne({
        name: "NuxtLayoutProvider",
        inheritAttrs: !1,
        props: {
            name: {
                type: [String, Boolean]
            },
            layoutProps: {
                type: Object
            },
            hasTransition: {
                type: Boolean
            },
            shouldProvide: {
                type: Boolean
            }
        },
        setup(e, t) {
            const n = e.name;
            return e.shouldProvide && Qn(Ih, {
                isCurrent: r => n === (r.meta.layout ? ? "default")
            }), () => {
                var r, a;
                return !n || typeof n == "string" && !(n in Gn) ? (a = (r = t.slots).default) == null ? void 0 : a.call(r) : Be(PO, {
                    key: n,
                    layoutProps: e.layoutProps,
                    name: n
                }, t.slots)
            }
        }
    }),
    Zg = Object.freeze({
        left: 0,
        top: 0,
        width: 16,
        height: 16
    }),
    ey = Object.freeze({
        rotate: 0,
        vFlip: !1,
        hFlip: !1
    }),
    Qc = Object.freeze({ ...Zg,
        ...ey
    });
Object.freeze({ ...Qc,
    body: "",
    hidden: !1
});
({ ...Zg
});
const ty = Object.freeze({
        width: null,
        height: null
    }),
    ny = Object.freeze({ ...ty,
        ...ey
    });

function DO(e, t) {
    const n = { ...e
    };
    for (const r in t) {
        const a = t[r],
            i = typeof a;
        r in ty ? (a === null || a && (i === "string" || i === "number")) && (n[r] = a) : i === typeof n[r] && (n[r] = r === "rotate" ? a % 4 : a)
    }
    return n
}
const NO = /[\s,]+/;

function FO(e, t) {
    t.split(NO).forEach(n => {
        switch (n.trim()) {
            case "horizontal":
                e.hFlip = !0;
                break;
            case "vertical":
                e.vFlip = !0;
                break
        }
    })
}

function BO(e, t = 0) {
    const n = e.replace(/^-?[0-9.]*/, "");

    function r(a) {
        for (; a < 0;) a += 4;
        return a % 4
    }
    if (n === "") {
        const a = parseInt(e);
        return isNaN(a) ? 0 : r(a)
    } else if (n !== e) {
        let a = 0;
        switch (n) {
            case "%":
                a = 25;
                break;
            case "deg":
                a = 90
        }
        if (a) {
            let i = parseFloat(e.slice(0, e.length - n.length));
            return isNaN(i) ? 0 : (i = i / a, i % 1 === 0 ? r(i) : 0)
        }
    }
    return t
}
const jO = /(-?[0-9.]*[0-9]+[0-9.]*)/g,
    $O = /^-?[0-9.]*[0-9]+[0-9.]*$/g;

function Wd(e, t, n) {
    if (t === 1) return e;
    if (n = n || 100, typeof e == "number") return Math.ceil(e * t * n) / n;
    if (typeof e != "string") return e;
    const r = e.split(jO);
    if (r === null || !r.length) return e;
    const a = [];
    let i = r.shift(),
        o = $O.test(i);
    for (;;) {
        if (o) {
            const s = parseFloat(i);
            isNaN(s) ? a.push(i) : a.push(Math.ceil(s * t * n) / n)
        } else a.push(i);
        if (i = r.shift(), i === void 0) return a.join("");
        o = !o
    }
}
const VO = e => e === "unset" || e === "undefined" || e === "none";

function HO(e, t) {
    const n = { ...Qc,
            ...e
        },
        r = { ...ny,
            ...t
        },
        a = {
            left: n.left,
            top: n.top,
            width: n.width,
            height: n.height
        };
    let i = n.body;
    [n, r].forEach(v => {
        const E = [],
            w = v.hFlip,
            h = v.vFlip;
        let b = v.rotate;
        w ? h ? b += 2 : (E.push("translate(" + (a.width + a.left).toString() + " " + (0 - a.top).toString() + ")"), E.push("scale(-1 1)"), a.top = a.left = 0) : h && (E.push("translate(" + (0 - a.left).toString() + " " + (a.height + a.top).toString() + ")"), E.push("scale(1 -1)"), a.top = a.left = 0);
        let m;
        switch (b < 0 && (b -= Math.floor(b / 4) * 4), b = b % 4, b) {
            case 1:
                m = a.height / 2 + a.top, E.unshift("rotate(90 " + m.toString() + " " + m.toString() + ")");
                break;
            case 2:
                E.unshift("rotate(180 " + (a.width / 2 + a.left).toString() + " " + (a.height / 2 + a.top).toString() + ")");
                break;
            case 3:
                m = a.width / 2 + a.left, E.unshift("rotate(-90 " + m.toString() + " " + m.toString() + ")");
                break
        }
        b % 2 === 1 && (a.left !== a.top && (m = a.left, a.left = a.top, a.top = m), a.width !== a.height && (m = a.width, a.width = a.height, a.height = m)), E.length && (i = '<g transform="' + E.join(" ") + '">' + i + "</g>")
    });
    const o = r.width,
        s = r.height,
        l = a.width,
        c = a.height;
    let u, f;
    o === null ? (f = s === null ? "1em" : s === "auto" ? c : s, u = Wd(f, l / c)) : (u = o === "auto" ? l : o, f = s === null ? Wd(u, c / l) : s === "auto" ? c : s);
    const d = {},
        p = (v, E) => {
            VO(E) || (d[v] = E.toString())
        };
    return p("width", u), p("height", f), d.viewBox = a.left.toString() + " " + a.top.toString() + " " + l.toString() + " " + c.toString(), {
        attributes: d,
        body: i
    }
}
const KO = /\sid="(\S+)"/g,
    UO = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let JO = 0;

function GO(e, t = UO) {
    const n = [];
    let r;
    for (; r = KO.exec(e);) n.push(r[1]);
    if (!n.length) return e;
    const a = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
    return n.forEach(i => {
        const o = typeof t == "function" ? t(i) : t + (JO++).toString(),
            s = i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + o + a + "$3")
    }), e = e.replace(new RegExp(a, "g"), ""), e
}

function WO(e, t) {
    let n = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
    for (const r in t) n += " " + r + '="' + t[r] + '"';
    return '<svg xmlns="http://www.w3.org/2000/svg"' + n + ">" + e + "</svg>"
}

function zO(e) {
    return e.replace(/"/g, "'").replace(/%/g, "%25").replace(/#/g, "%23").replace(/</g, "%3C").replace(/>/g, "%3E").replace(/\s+/g, " ")
}

function qO(e) {
    return "data:image/svg+xml," + zO(e)
}

function YO(e) {
    return 'url("' + qO(e) + '")'
}
const zd = { ...ny,
        inline: !1
    },
    XO = {
        xmlns: "http://www.w3.org/2000/svg",
        "xmlns:xlink": "http://www.w3.org/1999/xlink",
        "aria-hidden": !0,
        role: "img"
    },
    QO = {
        display: "inline-block"
    },
    Il = {
        backgroundColor: "currentColor"
    },
    ry = {
        backgroundColor: "transparent"
    },
    qd = {
        Image: "var(--svg)",
        Repeat: "no-repeat",
        Size: "100% 100%"
    },
    Yd = {
        webkitMask: Il,
        mask: Il,
        background: ry
    };
for (const e in Yd) {
    const t = Yd[e];
    for (const n in qd) t[e + n] = qd[n]
}
const Mi = {};
["horizontal", "vertical"].forEach(e => {
    const t = e.slice(0, 1) + "Flip";
    Mi[e + "-flip"] = t, Mi[e.slice(0, 1) + "-flip"] = t, Mi[e + "Flip"] = t
});

function Xd(e) {
    return e + (e.match(/^[-0-9.]+$/) ? "px" : "")
}
const ZO = (e, t) => {
        const n = DO(zd, t),
            r = { ...XO
            },
            a = t.mode || "svg",
            i = {},
            o = t.style,
            s = typeof o == "object" && !(o instanceof Array) ? o : {};
        for (let E in t) {
            const w = t[E];
            if (w !== void 0) switch (E) {
                case "icon":
                case "style":
                case "onLoad":
                case "mode":
                    break;
                case "inline":
                case "hFlip":
                case "vFlip":
                    n[E] = w === !0 || w === "true" || w === 1;
                    break;
                case "flip":
                    typeof w == "string" && FO(n, w);
                    break;
                case "color":
                    i.color = w;
                    break;
                case "rotate":
                    typeof w == "string" ? n[E] = BO(w) : typeof w == "number" && (n[E] = w);
                    break;
                case "ariaHidden":
                case "aria-hidden":
                    w !== !0 && w !== "true" && delete r["aria-hidden"];
                    break;
                default:
                    {
                        const h = Mi[E];h ? (w === !0 || w === "true" || w === 1) && (n[h] = !0) : zd[E] === void 0 && (r[E] = w)
                    }
            }
        }
        const l = HO(e, n),
            c = l.attributes;
        if (n.inline && (i.verticalAlign = "-0.125em"), a === "svg") {
            r.style = { ...i,
                ...s
            }, Object.assign(r, c);
            let E = 0,
                w = t.id;
            return typeof w == "string" && (w = w.replace(/-/g, "_")), r.innerHTML = GO(l.body, w ? () => w + "ID" + E++ : "iconifyVue"), Be("svg", r)
        }
        const {
            body: u,
            width: f,
            height: d
        } = e, p = a === "mask" || (a === "bg" ? !1 : u.indexOf("currentColor") !== -1), v = WO(u, { ...c,
            width: f + "",
            height: d + ""
        });
        return r.style = { ...i,
            "--svg": YO(v),
            width: Xd(c.width),
            height: Xd(c.height),
            ...QO,
            ...p ? Il : ry,
            ...s
        }, Be("span", r)
    },
    eM = Object.create(null),
    tM = Ne({
        inheritAttrs: !1,
        render() {
            const e = this.$attrs,
                t = e.icon,
                n = typeof t == "string" ? eM[t] : typeof t == "object" ? t : null;
            return n === null || typeof n != "object" || typeof n.body != "string" ? this.$slots.default ? this.$slots.default() : null : ZO({ ...Qc,
                ...n
            }, e)
        }
    }),
    va = /^[a-z0-9]+(-[a-z0-9]+)*$/,
    jo = (e, t, n, r = "") => {
        const a = e.split(":");
        if (e.slice(0, 1) === "@") {
            if (a.length < 2 || a.length > 3) return null;
            r = a.shift().slice(1)
        }
        if (a.length > 3 || !a.length) return null;
        if (a.length > 1) {
            const s = a.pop(),
                l = a.pop(),
                c = {
                    provider: a.length > 0 ? a[0] : r,
                    prefix: l,
                    name: s
                };
            return t && !Pi(c) ? null : c
        }
        const i = a[0],
            o = i.split("-");
        if (o.length > 1) {
            const s = {
                provider: r,
                prefix: o.shift(),
                name: o.join("-")
            };
            return t && !Pi(s) ? null : s
        }
        if (n && r === "") {
            const s = {
                provider: r,
                prefix: "",
                name: i
            };
            return t && !Pi(s, n) ? null : s
        }
        return null
    },
    Pi = (e, t) => e ? !!((e.provider === "" || e.provider.match(va)) && (t && e.prefix === "" || e.prefix.match(va)) && e.name.match(va)) : !1,
    ay = Object.freeze({
        left: 0,
        top: 0,
        width: 16,
        height: 16
    }),
    ao = Object.freeze({
        rotate: 0,
        vFlip: !1,
        hFlip: !1
    }),
    Zc = Object.freeze({ ...ay,
        ...ao
    }),
    Dl = Object.freeze({ ...Zc,
        body: "",
        hidden: !1
    });

function nM(e, t) {
    const n = {};
    !e.hFlip != !t.hFlip && (n.hFlip = !0), !e.vFlip != !t.vFlip && (n.vFlip = !0);
    const r = ((e.rotate || 0) + (t.rotate || 0)) % 4;
    return r && (n.rotate = r), n
}

function Qd(e, t) {
    const n = nM(e, t);
    for (const r in Dl) r in ao ? r in e && !(r in n) && (n[r] = ao[r]) : r in t ? n[r] = t[r] : r in e && (n[r] = e[r]);
    return n
}

function rM(e, t) {
    const n = e.icons,
        r = e.aliases || Object.create(null),
        a = Object.create(null);

    function i(o) {
        if (n[o]) return a[o] = [];
        if (!(o in a)) {
            a[o] = null;
            const s = r[o] && r[o].parent,
                l = s && i(s);
            l && (a[o] = [s].concat(l))
        }
        return a[o]
    }
    return (t || Object.keys(n).concat(Object.keys(r))).forEach(i), a
}

function aM(e, t, n) {
    const r = e.icons,
        a = e.aliases || Object.create(null);
    let i = {};

    function o(s) {
        i = Qd(r[s] || a[s], i)
    }
    return o(t), n.forEach(o), Qd(e, i)
}

function iy(e, t) {
    const n = [];
    if (typeof e != "object" || typeof e.icons != "object") return n;
    e.not_found instanceof Array && e.not_found.forEach(a => {
        t(a, null), n.push(a)
    });
    const r = rM(e);
    for (const a in r) {
        const i = r[a];
        i && (t(a, aM(e, a, i)), n.push(a))
    }
    return n
}
const iM = {
    provider: "",
    aliases: {},
    not_found: {},
    ...ay
};

function vs(e, t) {
    for (const n in t)
        if (n in e && typeof e[n] != typeof t[n]) return !1;
    return !0
}

function oy(e) {
    if (typeof e != "object" || e === null) return null;
    const t = e;
    if (typeof t.prefix != "string" || !e.icons || typeof e.icons != "object" || !vs(e, iM)) return null;
    const n = t.icons;
    for (const a in n) {
        const i = n[a];
        if (!a.match(va) || typeof i.body != "string" || !vs(i, Dl)) return null
    }
    const r = t.aliases || Object.create(null);
    for (const a in r) {
        const i = r[a],
            o = i.parent;
        if (!a.match(va) || typeof o != "string" || !n[o] && !r[o] || !vs(i, Dl)) return null
    }
    return t
}
const Zd = Object.create(null);

function oM(e, t) {
    return {
        provider: e,
        prefix: t,
        icons: Object.create(null),
        missing: new Set
    }
}

function rr(e, t) {
    const n = Zd[e] || (Zd[e] = Object.create(null));
    return n[t] || (n[t] = oM(e, t))
}

function eu(e, t) {
    return oy(t) ? iy(t, (n, r) => {
        r ? e.icons[n] = r : e.missing.add(n)
    }) : []
}

function sM(e, t, n) {
    try {
        if (typeof n.body == "string") return e.icons[t] = { ...n
        }, !0
    } catch {}
    return !1
}
let Fa = !1;

function sy(e) {
    return typeof e == "boolean" && (Fa = e), Fa
}

function lM(e) {
    const t = typeof e == "string" ? jo(e, !0, Fa) : e;
    if (t) {
        const n = rr(t.provider, t.prefix),
            r = t.name;
        return n.icons[r] || (n.missing.has(r) ? null : void 0)
    }
}

function cM(e, t) {
    const n = jo(e, !0, Fa);
    if (!n) return !1;
    const r = rr(n.provider, n.prefix);
    return sM(r, n.name, t)
}

function uM(e, t) {
    if (typeof e != "object") return !1;
    if (typeof t != "string" && (t = e.provider || ""), Fa && !t && !e.prefix) {
        let a = !1;
        return oy(e) && (e.prefix = "", iy(e, (i, o) => {
            o && cM(i, o) && (a = !0)
        })), a
    }
    const n = e.prefix;
    if (!Pi({
            provider: t,
            prefix: n,
            name: "a"
        })) return !1;
    const r = rr(t, n);
    return !!eu(r, e)
}
const fM = Object.freeze({
        width: null,
        height: null
    }),
    dM = Object.freeze({ ...fM,
        ...ao
    });
"" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
const Nl = Object.create(null);

function pM(e, t) {
    Nl[e] = t
}

function Fl(e) {
    return Nl[e] || Nl[""]
}

function tu(e) {
    let t;
    if (typeof e.resources == "string") t = [e.resources];
    else if (t = e.resources, !(t instanceof Array) || !t.length) return null;
    return {
        resources: t,
        path: e.path || "/",
        maxURL: e.maxURL || 500,
        rotate: e.rotate || 750,
        timeout: e.timeout || 5e3,
        random: e.random === !0,
        index: e.index || 0,
        dataAfterTimeout: e.dataAfterTimeout !== !1
    }
}
const nu = Object.create(null),
    Zr = ["https://api.simplesvg.com", "https://api.unisvg.com"],
    xi = [];
for (; Zr.length > 0;) Zr.length === 1 || Math.random() > .5 ? xi.push(Zr.shift()) : xi.push(Zr.pop());
nu[""] = tu({
    resources: ["https://api.iconify.design"].concat(xi)
});

function Bl(e, t) {
    const n = tu(t);
    return n === null ? !1 : (nu[e] = n, !0)
}

function ru(e) {
    return nu[e]
}
const hM = () => {
    let e;
    try {
        if (e = fetch, typeof e == "function") return e
    } catch {}
};
let ep = hM();

function mM(e, t) {
    const n = ru(e);
    if (!n) return 0;
    let r;
    if (!n.maxURL) r = 0;
    else {
        let a = 0;
        n.resources.forEach(o => {
            a = Math.max(a, o.length)
        });
        const i = t + ".json?icons=";
        r = n.maxURL - a - n.path.length - i.length
    }
    return r
}

function gM(e) {
    return e === 404
}
const yM = (e, t, n) => {
    const r = [],
        a = mM(e, t),
        i = "icons";
    let o = {
            type: i,
            provider: e,
            prefix: t,
            icons: []
        },
        s = 0;
    return n.forEach((l, c) => {
        s += l.length + 1, s >= a && c > 0 && (r.push(o), o = {
            type: i,
            provider: e,
            prefix: t,
            icons: []
        }, s = l.length), o.icons.push(l)
    }), r.push(o), r
};

function bM(e) {
    if (typeof e == "string") {
        const t = ru(e);
        if (t) return t.path
    }
    return "/"
}
const vM = (e, t, n) => {
        if (!ep) {
            n("abort", 424);
            return
        }
        let r = bM(t.provider);
        switch (t.type) {
            case "icons":
                {
                    const i = t.prefix,
                        s = t.icons.join(","),
                        l = new URLSearchParams({
                            icons: s
                        });r += i + ".json?" + l.toString();
                    break
                }
            case "custom":
                {
                    const i = t.uri;r += i.slice(0, 1) === "/" ? i.slice(1) : i;
                    break
                }
            default:
                n("abort", 400);
                return
        }
        let a = 503;
        ep(e + r).then(i => {
            const o = i.status;
            if (o !== 200) {
                setTimeout(() => {
                    n(gM(o) ? "abort" : "next", o)
                });
                return
            }
            return a = 501, i.json()
        }).then(i => {
            if (typeof i != "object" || i === null) {
                setTimeout(() => {
                    i === 404 ? n("abort", i) : n("next", a)
                });
                return
            }
            setTimeout(() => {
                n("success", i)
            })
        }).catch(() => {
            n("next", a)
        })
    },
    _M = {
        prepare: yM,
        send: vM
    };

function wM(e) {
    const t = {
            loaded: [],
            missing: [],
            pending: []
        },
        n = Object.create(null);
    e.sort((a, i) => a.provider !== i.provider ? a.provider.localeCompare(i.provider) : a.prefix !== i.prefix ? a.prefix.localeCompare(i.prefix) : a.name.localeCompare(i.name));
    let r = {
        provider: "",
        prefix: "",
        name: ""
    };
    return e.forEach(a => {
        if (r.name === a.name && r.prefix === a.prefix && r.provider === a.provider) return;
        r = a;
        const i = a.provider,
            o = a.prefix,
            s = a.name,
            l = n[i] || (n[i] = Object.create(null)),
            c = l[o] || (l[o] = rr(i, o));
        let u;
        s in c.icons ? u = t.loaded : o === "" || c.missing.has(s) ? u = t.missing : u = t.pending;
        const f = {
            provider: i,
            prefix: o,
            name: s
        };
        u.push(f)
    }), t
}

function ly(e, t) {
    e.forEach(n => {
        const r = n.loaderCallbacks;
        r && (n.loaderCallbacks = r.filter(a => a.id !== t))
    })
}

function EM(e) {
    e.pendingCallbacksFlag || (e.pendingCallbacksFlag = !0, setTimeout(() => {
        e.pendingCallbacksFlag = !1;
        const t = e.loaderCallbacks ? e.loaderCallbacks.slice(0) : [];
        if (!t.length) return;
        let n = !1;
        const r = e.provider,
            a = e.prefix;
        t.forEach(i => {
            const o = i.icons,
                s = o.pending.length;
            o.pending = o.pending.filter(l => {
                if (l.prefix !== a) return !0;
                const c = l.name;
                if (e.icons[c]) o.loaded.push({
                    provider: r,
                    prefix: a,
                    name: c
                });
                else if (e.missing.has(c)) o.missing.push({
                    provider: r,
                    prefix: a,
                    name: c
                });
                else return n = !0, !0;
                return !1
            }), o.pending.length !== s && (n || ly([e], i.id), i.callback(o.loaded.slice(0), o.missing.slice(0), o.pending.slice(0), i.abort))
        })
    }))
}
let CM = 0;

function AM(e, t, n) {
    const r = CM++,
        a = ly.bind(null, n, r);
    if (!t.pending.length) return a;
    const i = {
        id: r,
        icons: t,
        callback: e,
        abort: a
    };
    return n.forEach(o => {
        (o.loaderCallbacks || (o.loaderCallbacks = [])).push(i)
    }), a
}

function LM(e, t = !0, n = !1) {
    const r = [];
    return e.forEach(a => {
        const i = typeof a == "string" ? jo(a, t, n) : a;
        i && r.push(i)
    }), r
}
var SM = {
    resources: [],
    index: 0,
    timeout: 2e3,
    rotate: 750,
    random: !1,
    dataAfterTimeout: !1
};

function TM(e, t, n, r) {
    const a = e.resources.length,
        i = e.random ? Math.floor(Math.random() * a) : e.index;
    let o;
    if (e.random) {
        let S = e.resources.slice(0);
        for (o = []; S.length > 1;) {
            const A = Math.floor(Math.random() * S.length);
            o.push(S[A]), S = S.slice(0, A).concat(S.slice(A + 1))
        }
        o = o.concat(S)
    } else o = e.resources.slice(i).concat(e.resources.slice(0, i));
    const s = Date.now();
    let l = "pending",
        c = 0,
        u, f = null,
        d = [],
        p = [];
    typeof r == "function" && p.push(r);

    function v() {
        f && (clearTimeout(f), f = null)
    }

    function E() {
        l === "pending" && (l = "aborted"), v(), d.forEach(S => {
            S.status === "pending" && (S.status = "aborted")
        }), d = []
    }

    function w(S, A) {
        A && (p = []), typeof S == "function" && p.push(S)
    }

    function h() {
        return {
            startTime: s,
            payload: t,
            status: l,
            queriesSent: c,
            queriesPending: d.length,
            subscribe: w,
            abort: E
        }
    }

    function b() {
        l = "failed", p.forEach(S => {
            S(void 0, u)
        })
    }

    function m() {
        d.forEach(S => {
            S.status === "pending" && (S.status = "aborted")
        }), d = []
    }

    function y(S, A, R) {
        const O = A !== "success";
        switch (d = d.filter(N => N !== S), l) {
            case "pending":
                break;
            case "failed":
                if (O || !e.dataAfterTimeout) return;
                break;
            default:
                return
        }
        if (A === "abort") {
            u = R, b();
            return
        }
        if (O) {
            u = R, d.length || (o.length ? C() : b());
            return
        }
        if (v(), m(), !e.random) {
            const N = e.resources.indexOf(S.resource);
            N !== -1 && N !== e.index && (e.index = N)
        }
        l = "completed", p.forEach(N => {
            N(R)
        })
    }

    function C() {
        if (l !== "pending") return;
        v();
        const S = o.shift();
        if (S === void 0) {
            if (d.length) {
                f = setTimeout(() => {
                    v(), l === "pending" && (m(), b())
                }, e.timeout);
                return
            }
            b();
            return
        }
        const A = {
            status: "pending",
            resource: S,
            callback: (R, O) => {
                y(A, R, O)
            }
        };
        d.push(A), c++, f = setTimeout(C, e.rotate), n(S, t, A.callback)
    }
    return setTimeout(C), h
}

function cy(e) {
    const t = { ...SM,
        ...e
    };
    let n = [];

    function r() {
        n = n.filter(s => s().status === "pending")
    }

    function a(s, l, c) {
        const u = TM(t, s, l, (f, d) => {
            r(), c && c(f, d)
        });
        return n.push(u), u
    }

    function i(s) {
        return n.find(l => s(l)) || null
    }
    return {
        query: a,
        find: i,
        setIndex: s => {
            t.index = s
        },
        getIndex: () => t.index,
        cleanup: r
    }
}

function tp() {}
const _s = Object.create(null);

function kM(e) {
    if (!_s[e]) {
        const t = ru(e);
        if (!t) return;
        const n = cy(t),
            r = {
                config: t,
                redundancy: n
            };
        _s[e] = r
    }
    return _s[e]
}

function RM(e, t, n) {
    let r, a;
    if (typeof e == "string") {
        const i = Fl(e);
        if (!i) return n(void 0, 424), tp;
        a = i.send;
        const o = kM(e);
        o && (r = o.redundancy)
    } else {
        const i = tu(e);
        if (i) {
            r = cy(i);
            const o = e.resources ? e.resources[0] : "",
                s = Fl(o);
            s && (a = s.send)
        }
    }
    return !r || !a ? (n(void 0, 424), tp) : r.query(t, a, n)().abort
}
const np = "iconify2",
    Ba = "iconify",
    uy = Ba + "-count",
    rp = Ba + "-version",
    fy = 36e5,
    OM = 168;

function jl(e, t) {
    try {
        return e.getItem(t)
    } catch {}
}

function au(e, t, n) {
    try {
        return e.setItem(t, n), !0
    } catch {}
}

function ap(e, t) {
    try {
        e.removeItem(t)
    } catch {}
}

function $l(e, t) {
    return au(e, uy, t.toString())
}

function Vl(e) {
    return parseInt(jl(e, uy)) || 0
}
const $o = {
        local: !0,
        session: !0
    },
    dy = {
        local: new Set,
        session: new Set
    };
let iu = !1;

function MM(e) {
    iu = e
}
let Ai = typeof window > "u" ? {} : window;

function py(e) {
    const t = e + "Storage";
    try {
        if (Ai && Ai[t] && typeof Ai[t].length == "number") return Ai[t]
    } catch {}
    $o[e] = !1
}

function hy(e, t) {
    const n = py(e);
    if (!n) return;
    const r = jl(n, rp);
    if (r !== np) {
        if (r) {
            const s = Vl(n);
            for (let l = 0; l < s; l++) ap(n, Ba + l.toString())
        }
        au(n, rp, np), $l(n, 0);
        return
    }
    const a = Math.floor(Date.now() / fy) - OM,
        i = s => {
            const l = Ba + s.toString(),
                c = jl(n, l);
            if (typeof c == "string") {
                try {
                    const u = JSON.parse(c);
                    if (typeof u == "object" && typeof u.cached == "number" && u.cached > a && typeof u.provider == "string" && typeof u.data == "object" && typeof u.data.prefix == "string" && t(u, s)) return !0
                } catch {}
                ap(n, l)
            }
        };
    let o = Vl(n);
    for (let s = o - 1; s >= 0; s--) i(s) || (s === o - 1 ? (o--, $l(n, o)) : dy[e].add(s))
}

function my() {
    if (!iu) {
        MM(!0);
        for (const e in $o) hy(e, t => {
            const n = t.data,
                r = t.provider,
                a = n.prefix,
                i = rr(r, a);
            if (!eu(i, n).length) return !1;
            const o = n.lastModified || -1;
            return i.lastModifiedCached = i.lastModifiedCached ? Math.min(i.lastModifiedCached, o) : o, !0
        })
    }
}

function PM(e, t) {
    const n = e.lastModifiedCached;
    if (n && n >= t) return n === t;
    if (e.lastModifiedCached = t, n)
        for (const r in $o) hy(r, a => {
            const i = a.data;
            return a.provider !== e.provider || i.prefix !== e.prefix || i.lastModified === t
        });
    return !0
}

function xM(e, t) {
    iu || my();

    function n(r) {
        let a;
        if (!$o[r] || !(a = py(r))) return;
        const i = dy[r];
        let o;
        if (i.size) i.delete(o = Array.from(i).shift());
        else if (o = Vl(a), !$l(a, o + 1)) return;
        const s = {
            cached: Math.floor(Date.now() / fy),
            provider: e.provider,
            data: t
        };
        return au(a, Ba + o.toString(), JSON.stringify(s))
    }
    t.lastModified && !PM(e, t.lastModified) || Object.keys(t.icons).length && (t.not_found && (t = Object.assign({}, t), delete t.not_found), n("local") || n("session"))
}

function ip() {}

function IM(e) {
    e.iconsLoaderFlag || (e.iconsLoaderFlag = !0, setTimeout(() => {
        e.iconsLoaderFlag = !1, EM(e)
    }))
}

function DM(e, t) {
    e.iconsToLoad ? e.iconsToLoad = e.iconsToLoad.concat(t).sort() : e.iconsToLoad = t, e.iconsQueueFlag || (e.iconsQueueFlag = !0, setTimeout(() => {
        e.iconsQueueFlag = !1;
        const {
            provider: n,
            prefix: r
        } = e, a = e.iconsToLoad;
        delete e.iconsToLoad;
        let i;
        if (!a || !(i = Fl(n))) return;
        i.prepare(n, r, a).forEach(s => {
            RM(n, s, l => {
                if (typeof l != "object") s.icons.forEach(c => {
                    e.missing.add(c)
                });
                else try {
                    const c = eu(e, l);
                    if (!c.length) return;
                    const u = e.pendingIcons;
                    u && c.forEach(f => {
                        u.delete(f)
                    }), xM(e, l)
                } catch (c) {
                    console.error(c)
                }
                IM(e)
            })
        })
    }))
}
const NM = (e, t) => {
        const n = LM(e, !0, sy()),
            r = wM(n);
        if (!r.pending.length) {
            let l = !0;
            return t && setTimeout(() => {
                l && t(r.loaded, r.missing, r.pending, ip)
            }), () => {
                l = !1
            }
        }
        const a = Object.create(null),
            i = [];
        let o, s;
        return r.pending.forEach(l => {
            const {
                provider: c,
                prefix: u
            } = l;
            if (u === s && c === o) return;
            o = c, s = u, i.push(rr(c, u));
            const f = a[c] || (a[c] = Object.create(null));
            f[u] || (f[u] = [])
        }), r.pending.forEach(l => {
            const {
                provider: c,
                prefix: u,
                name: f
            } = l, d = rr(c, u), p = d.pendingIcons || (d.pendingIcons = new Set);
            p.has(f) || (p.add(f), a[c][u].push(f))
        }), i.forEach(l => {
            const {
                provider: c,
                prefix: u
            } = l;
            a[c][u].length && DM(l, a[c][u])
        }), t ? AM(t, r, i) : ip
    },
    FM = e => new Promise((t, n) => {
        const r = typeof e == "string" ? jo(e, !0) : e;
        if (!r) {
            n(e);
            return
        }
        NM([r || e], a => {
            if (a.length && r) {
                const i = lM(r);
                if (i) {
                    t({ ...Zc,
                        ...i
                    });
                    return
                }
            }
            n(e)
        })
    });
({ ...dM
});
const op = {
        backgroundColor: "currentColor"
    },
    BM = {
        backgroundColor: "transparent"
    },
    sp = {
        Image: "var(--svg)",
        Repeat: "no-repeat",
        Size: "100% 100%"
    },
    lp = {
        webkitMask: op,
        mask: op,
        background: BM
    };
for (const e in lp) {
    const t = lp[e];
    for (const n in sp) t[e + n] = sp[n]
}
const ws = {};
["horizontal", "vertical"].forEach(e => {
    const t = e.slice(0, 1) + "Flip";
    ws[e + "-flip"] = t, ws[e.slice(0, 1) + "-flip"] = t, ws[e + "Flip"] = t
});
sy(!0);
pM("", _M);
if (typeof document < "u" && typeof window < "u") {
    my();
    const e = window;
    if (e.IconifyPreload !== void 0) {
        const t = e.IconifyPreload,
            n = "Invalid IconifyPreload syntax.";
        typeof t == "object" && t !== null && (t instanceof Array ? t : [t]).forEach(r => {
            try {
                (typeof r != "object" || r === null || r instanceof Array || typeof r.icons != "object" || typeof r.prefix != "string" || !uM(r)) && console.error(n)
            } catch {
                console.error(n)
            }
        })
    }
    if (e.IconifyProviders !== void 0) {
        const t = e.IconifyProviders;
        if (typeof t == "object" && t !== null)
            for (let n in t) {
                const r = "IconifyProviders[" + n + "] is invalid.";
                try {
                    const a = t[n];
                    if (typeof a != "object" || !a || a.resources === void 0) continue;
                    Bl(n, a) || console.error(r)
                } catch {
                    console.error(r)
                }
            }
    }
}({ ...Zc
});
const jM = ["fluent-emoji-high-contrast", "material-symbols-light", "cryptocurrency-color", "icon-park-outline", "icon-park-twotone", "fluent-emoji-flat", "emojione-monotone", "streamline-emojis", "heroicons-outline", "simple-line-icons", "material-symbols", "flat-color-icons", "icon-park-solid", "pepicons-pencil", "heroicons-solid", "pepicons-print", "cryptocurrency", "pixelarticons", "system-uicons", "devicon-plain", "entypo-social", "grommet-icons", "vscode-icons", "pepicons-pop", "svg-spinners", "fluent-emoji", "simple-icons", "circle-flags", "medical-icon", "icomoon-free", "majesticons", "radix-icons", "humbleicons", "fa6-regular", "emojione-v1", "skill-icons", "academicons", "healthicons", "fluent-mdl2", "teenyicons", "ant-design", "gravity-ui", "akar-icons", "lets-icons", "streamline", "fa6-brands", "file-icons", "game-icons", "foundation", "fa-regular", "mono-icons", "iconamoon", "zondicons", "mdi-light", "eos-icons", "gridicons", "icon-park", "heroicons", "fa6-solid", "meteocons", "arcticons", "dashicons", "fa-brands", "websymbol", "fontelico", "mingcute", "bytesize", "guidance", "openmoji", "emojione", "nonicons", "brandico", "flagpack", "fa-solid", "fontisto", "si-glyph", "pepicons", "iconoir", "tdesign", "clarity", "octicon", "codicon", "pajamas", "formkit", "line-md", "twemoji", "noto-v1", "fxemoji", "devicon", "raphael", "flat-ui", "topcoat", "feather", "tabler", "carbon", "lucide", "memory", "mynaui", "circum", "fluent", "nimbus", "entypo", "icons8", "subway", "vaadin", "solar", "basil", "typcn", "charm", "prime", "quill", "logos", "covid", "maki", "gala", "ooui", "noto", "flag", "iwwa", "zmdi", "bpmn", "mdi", "ion", "uil", "bxs", "cil", "uiw", "uim", "uit", "uis", "jam", "bxl", "cib", "cif", "gis", "map", "geo", "fad", "eva", "wpf", "whh", "ic", "ph", "ri", "bi", "bx", "gg", "ci", "ep", "fe", "mi", "ei", "wi", "la", "fa", "oi", "et", "el", "ls", "vs", "il", "ps"];

function $M(e = "") {
    let t, n = "";
    if (e[0] === "@" && e.includes(":") && (n = e.split(":")[0].slice(1), e = e.split(":").slice(1).join(":")), e.startsWith("i-")) {
        e = e.replace(/^i-/, "");
        for (const r of jM)
            if (e.startsWith(r)) {
                t = r, e = e.slice(r.length + 1);
                break
            }
    } else if (e.includes(":")) {
        const [r, a] = e.split(":");
        t = r, e = a
    }
    return {
        provider: n,
        prefix: t || "",
        name: e || ""
    }
}
const VM = Ne({
    __name: "Icon",
    props: {
        name: {
            type: String,
            required: !0
        },
        size: {
            type: String,
            default: ""
        }
    },
    async setup(e) {
        let t, n;
        const r = ge(),
            a = Wa(),
            i = e;
        we(() => {
            var w;
            return (w = a.nuxtIcon) == null ? void 0 : w.iconifyApiOptions
        }, () => {
            var w, h, b, m, y, C;
            if ((h = (w = a.nuxtIcon) == null ? void 0 : w.iconifyApiOptions) != null && h.url) {
                try {
                    new URL(a.nuxtIcon.iconifyApiOptions.url)
                } catch {
                    console.warn("Nuxt Icon: Invalid custom Iconify API URL");
                    return
                }
                if ((m = (b = a.nuxtIcon) == null ? void 0 : b.iconifyApiOptions) != null && m.publicApiFallback) {
                    Bl("custom", {
                        resources: [(y = a.nuxtIcon) == null ? void 0 : y.iconifyApiOptions.url],
                        index: 0
                    });
                    return
                }
                Bl("", {
                    resources: [(C = a.nuxtIcon) == null ? void 0 : C.iconifyApiOptions.url]
                })
            }
        }, {
            immediate: !0
        });
        const o = qa("icons", () => ({})),
            s = Q(!1),
            l = W(() => {
                var w, h;
                return (h = (w = a.nuxtIcon) == null ? void 0 : w.aliases) != null && h[i.name] ? a.nuxtIcon.aliases[i.name] : i.name
            }),
            c = W(() => $M(l.value)),
            u = W(() => [c.value.provider, c.value.prefix, c.value.name].filter(Boolean).join(":")),
            f = W(() => {
                var w;
                return (w = o.value) == null ? void 0 : w[u.value]
            }),
            d = W(() => r.vueApp.component(l.value)),
            p = W(() => {
                var h, b, m;
                if (!i.size && typeof((h = a.nuxtIcon) == null ? void 0 : h.size) == "boolean" && !((b = a.nuxtIcon) != null && b.size)) return;
                const w = i.size || ((m = a.nuxtIcon) == null ? void 0 : m.size) || "1em";
                return String(Number(w)) === w ? `${w}px` : w
            }),
            v = W(() => {
                var w;
                return ((w = a == null ? void 0 : a.nuxtIcon) == null ? void 0 : w.class) ? ? "icon"
            });
        async function E() {
            var w;
            d.value || (w = o.value) != null && w[u.value] || (s.value = !0, o.value[u.value] = await FM(c.value).catch(() => {}), s.value = !1)
        }
        return we(l, E), !d.value && ([t, n] = zb(() => E()), t = await t, n()), (w, h) => s.value ? (le(), Ke("span", {
            key: 0,
            class: Le(v.value),
            style: er({
                width: p.value,
                height: p.value
            })
        }, null, 6)) : f.value ? (le(), Pe(pe(tM), {
            key: 1,
            icon: f.value,
            class: Le(v.value),
            width: p.value,
            height: p.value
        }, null, 8, ["icon", "class", "width", "height"])) : d.value ? (le(), Pe(ac(d.value), {
            key: 2,
            class: Le(v.value),
            width: p.value,
            height: p.value
        }, null, 8, ["class", "width", "height"])) : (le(), Ke("span", {
            key: 3,
            class: Le(v.value),
            style: er({
                fontSize: p.value,
                lineHeight: p.value,
                width: p.value,
                height: p.value
            })
        }, [Kt(w.$slots, "default", {}, () => [La(qn(e.name), 1)], !0)], 6))
    }
});
const Pn = (e, t) => {
        const n = e.__vccOpts || e;
        for (const [r, a] of t) n[r] = a;
        return n
    },
    gy = Pn(VM, [
        ["__scopeId", "data-v-4b0ba236"]
    ]),
    HM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: gy
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    KM = Ne({
        props: {
            name: {
                type: String,
                required: !0
            },
            dynamic: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const t = Wa();
            return {
                dynamic: W(() => {
                    var r, a;
                    return e.dynamic || ((a = (r = t.ui) == null ? void 0 : r.icons) == null ? void 0 : a.dynamic)
                })
            }
        }
    });

function UM(e, t, n, r, a, i) {
    const o = gy;
    return e.dynamic ? (le(), Pe(o, {
        key: 0,
        name: e.name
    }, null, 8, ["name"])) : (le(), Ke("span", {
        key: 1,
        class: Le(e.name)
    }, null, 2))
}
const Jr = Pn(KM, [
        ["render", UM]
    ]),
    Vo = (e, t, n, r, a = !1) => {
        const i = Wb(),
            o = Wa(),
            s = W(() => {
                var d;
                const c = Jo(t),
                    u = Jo(n),
                    f = Jo(r);
                return ei((c == null ? void 0 : c.strategy) || ((d = o.ui) == null ? void 0 : d.strategy), f ? {
                    wrapper: f
                } : {}, c || {}, a ? ZS(o.ui, e, {}) : {}, u || {})
            }),
            l = W(() => QS(i, ["class"]));
        return {
            ui: s,
            attrs: l
        }
    },
    JM = {
        wrapper: "relative inline-flex items-center justify-center flex-shrink-0",
        background: "bg-gray-100 dark:bg-gray-800",
        rounded: "rounded-full",
        text: "font-medium leading-none text-gray-900 dark:text-white truncate",
        placeholder: "font-medium leading-none text-gray-500 dark:text-gray-400 truncate",
        size: {
            "3xs": "h-4 w-4 text-[8px]",
            "2xs": "h-5 w-5 text-[10px]",
            xs: "h-6 w-6 text-xs",
            sm: "h-8 w-8 text-sm",
            md: "h-10 w-10 text-base",
            lg: "h-12 w-12 text-lg",
            xl: "h-14 w-14 text-xl",
            "2xl": "h-16 w-16 text-2xl",
            "3xl": "h-20 w-20 text-3xl"
        },
        chip: {
            base: "absolute rounded-full ring-1 ring-white dark:ring-gray-900 flex items-center justify-center text-white dark:text-gray-900 font-medium",
            background: "bg-{color}-500 dark:bg-{color}-400",
            position: {
                "top-right": "top-0 right-0",
                "bottom-right": "bottom-0 right-0",
                "top-left": "top-0 left-0",
                "bottom-left": "bottom-0 left-0"
            },
            size: {
                "3xs": "h-[4px] min-w-[4px] text-[4px] p-px",
                "2xs": "h-[5px] min-w-[5px] text-[5px] p-px",
                xs: "h-1.5 min-w-[0.375rem] text-[6px] p-px",
                sm: "h-2 min-w-[0.5rem] text-[7px] p-0.5",
                md: "h-2.5 min-w-[0.625rem] text-[8px] p-0.5",
                lg: "h-3 min-w-[0.75rem] text-[10px] p-0.5",
                xl: "h-3.5 min-w-[0.875rem] text-[11px] p-1",
                "2xl": "h-4 min-w-[1rem] text-[12px] p-1",
                "3xl": "h-5 min-w-[1.25rem] text-[14px] p-1"
            }
        },
        icon: {
            base: "text-gray-500 dark:text-gray-400 flex-shrink-0",
            size: {
                "3xs": "h-2 w-2",
                "2xs": "h-2.5 w-2.5",
                xs: "h-3 w-3",
                sm: "h-4 w-4",
                md: "h-5 w-5",
                lg: "h-6 w-6",
                xl: "h-7 w-7",
                "2xl": "h-8 w-8",
                "3xl": "h-10 w-10"
            }
        },
        default: {
            size: "sm",
            icon: null,
            chipColor: null,
            chipPosition: "top-right"
        }
    },
    GM = {
        base: "focus:outline-none focus-visible:outline-0 disabled:cursor-not-allowed disabled:opacity-75 flex-shrink-0",
        font: "font-medium",
        rounded: "rounded-md",
        size: {
            "2xs": "text-xs",
            xs: "text-xs",
            sm: "text-sm",
            md: "text-sm",
            lg: "text-sm",
            xl: "text-base"
        },
        gap: {
            "2xs": "gap-x-1",
            xs: "gap-x-1.5",
            sm: "gap-x-1.5",
            md: "gap-x-2",
            lg: "gap-x-2.5",
            xl: "gap-x-2.5"
        },
        padding: {
            "2xs": "px-2 py-1",
            xs: "px-2.5 py-1.5",
            sm: "px-2.5 py-1.5",
            md: "px-3 py-2",
            lg: "px-3.5 py-2.5",
            xl: "px-3.5 py-2.5"
        },
        square: {
            "2xs": "p-1",
            xs: "p-1.5",
            sm: "p-1.5",
            md: "p-2",
            lg: "p-2.5",
            xl: "p-2.5"
        },
        color: {
            white: {
                solid: "shadow-sm ring-1 ring-inset ring-gray-300 dark:ring-gray-700 text-gray-900 dark:text-white bg-white hover:bg-gray-50 disabled:bg-white dark:bg-gray-900 dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
                ghost: "text-gray-900 dark:text-white hover:bg-white dark:hover:bg-gray-900 focus-visible:ring-inset focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400"
            },
            gray: {
                solid: "shadow-sm ring-1 ring-inset ring-gray-300 dark:ring-gray-700 text-gray-700 dark:text-gray-200 bg-gray-50 hover:bg-gray-100 disabled:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-700/50 dark:disabled:bg-gray-800 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
                ghost: "text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-gray-800 focus-visible:ring-inset focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
                link: "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 underline-offset-4 hover:underline focus-visible:ring-inset focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400"
            },
            black: {
                solid: "shadow-sm text-white dark:text-gray-900 bg-gray-900 hover:bg-gray-800 disabled:bg-gray-900 dark:bg-white dark:hover:bg-gray-100 dark:disabled:bg-white focus-visible:ring-inset focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
                link: "text-gray-900 dark:text-white underline-offset-4 hover:underline focus-visible:ring-inset focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400"
            }
        },
        variant: {
            solid: "shadow-sm text-white dark:text-gray-900 bg-{color}-500 hover:bg-{color}-600 disabled:bg-{color}-500 dark:bg-{color}-400 dark:hover:bg-{color}-500 dark:disabled:bg-{color}-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-{color}-500 dark:focus-visible:outline-{color}-400",
            outline: "ring-1 ring-inset ring-current text-{color}-500 dark:text-{color}-400 hover:bg-{color}-50 disabled:bg-transparent dark:hover:bg-{color}-950 dark:disabled:bg-transparent focus-visible:ring-2 focus-visible:ring-{color}-500 dark:focus-visible:ring-{color}-400",
            soft: "text-{color}-500 dark:text-{color}-400 bg-{color}-50 hover:bg-{color}-100 disabled:bg-{color}-50 dark:bg-{color}-950 dark:hover:bg-{color}-900 dark:disabled:bg-{color}-950 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-{color}-500 dark:focus-visible:ring-{color}-400",
            ghost: "text-{color}-500 dark:text-{color}-400 hover:bg-{color}-50 disabled:bg-transparent dark:hover:bg-{color}-950 dark:disabled:bg-transparent focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-{color}-500 dark:focus-visible:ring-{color}-400",
            link: "text-{color}-500 hover:text-{color}-600 disabled:text-{color}-500 dark:text-{color}-400 dark:hover:text-{color}-500 dark:disabled:text-{color}-400 underline-offset-4 hover:underline focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-{color}-500 dark:focus-visible:ring-{color}-400"
        },
        icon: {
            base: "flex-shrink-0",
            size: {
                "2xs": "h-4 w-4",
                xs: "h-4 w-4",
                sm: "h-5 w-5",
                md: "h-5 w-5",
                lg: "h-5 w-5",
                xl: "h-6 w-6"
            }
        },
        default: {
            size: "sm",
            variant: "solid",
            color: "primary",
            loadingIcon: "i-heroicons-arrow-path-20-solid"
        }
    },
    yy = {
        base: "before:w-2 before:h-2",
        ring: "before:ring-1 before:ring-gray-200 dark:before:ring-gray-800",
        rounded: "before:rounded-sm",
        background: "before:bg-gray-200 dark:before:bg-gray-800",
        shadow: "before:shadow",
        placement: 'group-data-[popper-placement*="right"]:-left-1 group-data-[popper-placement*="left"]:-right-1 group-data-[popper-placement*="top"]:-bottom-1 group-data-[popper-placement*="bottom"]:-top-1'
    },
    PP = {
        wrapper: "relative inline-flex text-left rtl:text-right",
        container: "z-20 group",
        width: "w-48",
        height: "",
        background: "bg-white dark:bg-gray-800",
        shadow: "shadow-lg",
        rounded: "rounded-md",
        ring: "ring-1 ring-gray-200 dark:ring-gray-700",
        base: "relative focus:outline-none overflow-y-auto scroll-py-1",
        divide: "divide-y divide-gray-200 dark:divide-gray-700",
        padding: "p-1",
        item: {
            base: "group flex items-center gap-2 w-full",
            rounded: "rounded-md",
            padding: "px-2 py-1.5",
            size: "text-sm",
            active: "bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white",
            inactive: "text-gray-700 dark:text-gray-200",
            disabled: "cursor-not-allowed opacity-50",
            icon: {
                base: "flex-shrink-0 h-4 w-4",
                active: "text-gray-500 dark:text-gray-400",
                inactive: "text-gray-400 dark:text-gray-500"
            },
            avatar: {
                base: "flex-shrink-0",
                size: "3xs"
            },
            shortcuts: "hidden md:inline-flex flex-shrink-0 gap-0.5 ms-auto"
        },
        transition: {
            enterActiveClass: "transition duration-100 ease-out",
            enterFromClass: "transform scale-95 opacity-0",
            enterToClass: "transform scale-100 opacity-100",
            leaveActiveClass: "transition duration-75 ease-in",
            leaveFromClass: "transform scale-100 opacity-100",
            leaveToClass: "transform scale-95 opacity-0"
        },
        popper: {
            placement: "bottom-end",
            strategy: "fixed"
        },
        arrow: { ...yy,
            ring: "before:ring-1 before:ring-gray-200 dark:before:ring-gray-700",
            background: "before:bg-white dark:before:bg-gray-700"
        }
    },
    by = {
        wrapper: "relative",
        base: "relative block w-full disabled:cursor-not-allowed disabled:opacity-75 focus:outline-none border-0",
        rounded: "rounded-md",
        placeholder: "placeholder-gray-400 dark:placeholder-gray-500",
        size: {
            "2xs": "text-xs",
            xs: "text-xs",
            sm: "text-sm",
            md: "text-sm",
            lg: "text-sm",
            xl: "text-base"
        },
        gap: {
            "2xs": "gap-x-1",
            xs: "gap-x-1.5",
            sm: "gap-x-1.5",
            md: "gap-x-2",
            lg: "gap-x-2.5",
            xl: "gap-x-2.5"
        },
        padding: {
            "2xs": "px-2 py-1",
            xs: "px-2.5 py-1.5",
            sm: "px-2.5 py-1.5",
            md: "px-3 py-2",
            lg: "px-3.5 py-2.5",
            xl: "px-3.5 py-2.5"
        },
        leading: {
            padding: {
                "2xs": "ps-7",
                xs: "ps-8",
                sm: "ps-9",
                md: "ps-10",
                lg: "ps-11",
                xl: "ps-12"
            }
        },
        trailing: {
            padding: {
                "2xs": "pe-7",
                xs: "pe-8",
                sm: "pe-9",
                md: "pe-10",
                lg: "pe-11",
                xl: "pe-12"
            }
        },
        color: {
            white: {
                outline: "shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400"
            },
            gray: {
                outline: "shadow-sm bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400"
            }
        },
        variant: {
            outline: "shadow-sm bg-transparent text-gray-900 dark:text-white ring-1 ring-inset ring-{color}-500 dark:ring-{color}-400 focus:ring-2 focus:ring-{color}-500 dark:focus:ring-{color}-400",
            none: "bg-transparent focus:ring-0 focus:shadow-none"
        },
        icon: {
            base: "flex-shrink-0 text-gray-400 dark:text-gray-500",
            color: "text-{color}-500 dark:text-{color}-400",
            size: {
                "2xs": "h-4 w-4",
                xs: "h-4 w-4",
                sm: "h-5 w-5",
                md: "h-5 w-5",
                lg: "h-5 w-5",
                xl: "h-6 w-6"
            },
            leading: {
                wrapper: "absolute inset-y-0 start-0 flex items-center",
                pointer: "pointer-events-none",
                padding: {
                    "2xs": "ps-2",
                    xs: "ps-2.5",
                    sm: "ps-2.5",
                    md: "ps-3",
                    lg: "ps-3.5",
                    xl: "ps-3.5"
                }
            },
            trailing: {
                wrapper: "absolute inset-y-0 end-0 flex items-center",
                pointer: "pointer-events-none",
                padding: {
                    "2xs": "pe-2",
                    xs: "pe-2.5",
                    sm: "pe-2.5",
                    md: "pe-3",
                    lg: "pe-3.5",
                    xl: "pe-3.5"
                }
            }
        },
        default: {
            size: "sm",
            color: "white",
            variant: "outline",
            loadingIcon: "i-heroicons-arrow-path-20-solid"
        }
    };
({ ...by
});
const xP = { ...by,
    placeholder: "text-gray-900 dark:text-white",
    default: {
        size: "sm",
        color: "white",
        variant: "outline",
        loadingIcon: "i-heroicons-arrow-path-20-solid",
        trailingIcon: "i-heroicons-chevron-down-20-solid"
    }
};
({ ...yy
});
const WM = {
        wrapper: "w-full pointer-events-auto",
        container: "relative overflow-hidden",
        title: "text-sm font-medium text-gray-900 dark:text-white",
        description: "mt-1 text-sm leading-4 text-gray-500 dark:text-gray-400",
        actions: "flex items-center gap-2 mt-3 flex-shrink-0",
        background: "bg-white dark:bg-gray-900",
        shadow: "shadow-lg",
        rounded: "rounded-lg",
        padding: "p-4",
        gap: "gap-3",
        ring: "ring-1 ring-gray-200 dark:ring-gray-800",
        icon: {
            base: "flex-shrink-0 w-5 h-5",
            color: "text-{color}-500 dark:text-{color}-400"
        },
        avatar: {
            base: "flex-shrink-0 self-center",
            size: "md"
        },
        progress: {
            base: "absolute bottom-0 end-0 start-0 h-1",
            background: "bg-{color}-500 dark:bg-{color}-400"
        },
        transition: {
            enterActiveClass: "transform ease-out duration-300 transition",
            enterFromClass: "translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2",
            enterToClass: "translate-y-0 opacity-100 sm:translate-x-0",
            leaveActiveClass: "transition ease-in duration-100",
            leaveFromClass: "opacity-100",
            leaveToClass: "opacity-0"
        },
        default: {
            color: "primary",
            icon: null,
            timeout: 5e3,
            closeButton: {
                icon: "i-heroicons-x-mark-20-solid",
                color: "gray",
                variant: "link",
                padded: !1
            },
            actionButton: {
                size: "xs",
                color: "white"
            }
        }
    },
    zM = {
        wrapper: "fixed flex flex-col justify-end z-[55]",
        position: "bottom-0 end-0",
        width: "w-full sm:w-96",
        container: "px-4 sm:px-6 py-6 space-y-3 overflow-y-auto"
    },
    Vn = ei(At.ui.strategy, At.ui.avatar, JM),
    qM = Ne({
        components: {
            UIcon: Jr
        },
        inheritAttrs: !1,
        props: {
            src: {
                type: [String, Boolean],
                default: null
            },
            alt: {
                type: String,
                default: null
            },
            text: {
                type: String,
                default: null
            },
            icon: {
                type: String,
                default: () => Vn.default.icon
            },
            size: {
                type: String,
                default: () => Vn.default.size,
                validator(e) {
                    return Object.keys(Vn.size).includes(e)
                }
            },
            chipColor: {
                type: String,
                default: () => Vn.default.chipColor,
                validator(e) {
                    return ["gray", ...At.ui.colors].includes(e)
                }
            },
            chipPosition: {
                type: String,
                default: () => Vn.default.chipPosition,
                validator(e) {
                    return Object.keys(Vn.chip.position).includes(e)
                }
            },
            chipText: {
                type: [String, Number],
                default: null
            },
            imgClass: {
                type: String,
                default: ""
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Vo("avatar", ir(e, "ui"), Vn), r = W(() => typeof e.src == "boolean" ? null : e.src), a = W(() => (e.alt || "").split(" ").map(f => f.charAt(0)).join("").substring(0, 2)), i = W(() => Or(Et(t.value.wrapper, (c.value || !r.value) && t.value.background, t.value.rounded, t.value.size[e.size]), e.class)), o = W(() => Or(Et(t.value.rounded, t.value.size[e.size]), e.imgClass)), s = W(() => Et(t.value.icon.base, t.value.icon.size[e.size])), l = W(() => Et(t.value.chip.base, t.value.chip.size[e.size], t.value.chip.position[e.chipPosition], t.value.chip.background.replaceAll("{color}", e.chipColor))), c = Q(!1);
            we(() => e.src, () => {
                c.value && (c.value = !1)
            });

            function u() {
                c.value = !0
            }
            return {
                ui: t,
                attrs: n,
                wrapperClass: i,
                imgClass: o,
                iconClass: s,
                chipClass: l,
                url: r,
                placeholder: a,
                error: c,
                onError: u
            }
        }
    }),
    YM = ["alt", "src"];

function XM(e, t, n, r, a, i) {
    const o = Jr;
    return le(), Ke("span", {
        class: Le(e.wrapperClass)
    }, [e.url && !e.error ? (le(), Ke("img", it({
        key: 0,
        class: e.imgClass,
        alt: e.alt,
        src: e.url
    }, e.attrs, {
        onError: t[0] || (t[0] = (...s) => e.onError && e.onError(...s))
    }), null, 16, YM)) : e.text ? (le(), Ke("span", {
        key: 1,
        class: Le(e.ui.text)
    }, qn(e.text), 3)) : e.icon ? (le(), Pe(o, {
        key: 2,
        name: e.icon,
        class: Le(e.iconClass)
    }, null, 8, ["name", "class"])) : e.placeholder ? (le(), Ke("span", {
        key: 3,
        class: Le(e.ui.placeholder)
    }, qn(e.placeholder), 3)) : ft("", !0), e.chipColor ? (le(), Ke("span", {
        key: 4,
        class: Le(e.chipClass)
    }, qn(e.chipText), 3)) : ft("", !0), Kt(e.$slots, "default")], 2)
}
const vy = Pn(qM, [
        ["render", XM]
    ]),
    QM = Ne({
        inheritAttrs: !1,
        props: { ...om.props,
            as: {
                type: String,
                default: "button"
            },
            disabled: {
                type: Boolean,
                default: null
            },
            active: {
                type: Boolean,
                default: !1
            },
            exact: {
                type: Boolean,
                default: !1
            },
            exactQuery: {
                type: Boolean,
                default: !1
            },
            exactHash: {
                type: Boolean,
                default: !1
            },
            inactiveClass: {
                type: String,
                default: void 0
            }
        },
        setup(e) {
            function t(n, r, {
                isActive: a,
                isExactActive: i
            }) {
                return e.exactQuery && !tC(n.query, r.query) || e.exactHash && n.hash !== r.hash ? e.inactiveClass : e.exact && i || !e.exact && a ? e.activeClass : e.inactiveClass
            }
            return {
                resolveLinkClass: t
            }
        }
    }),
    ZM = ["href", "aria-disabled", "role", "rel", "target", "onClick"];

function eP(e, t, n, r, a, i) {
    const o = om;
    return e.to ? (le(), Pe(o, it({
        key: 1
    }, e.$props, {
        custom: ""
    }), {
        default: Sn(({
            route: s,
            href: l,
            target: c,
            rel: u,
            navigate: f,
            isActive: d,
            isExactActive: p,
            isExternal: v
        }) => [Xt("a", it(e.$attrs, {
            href: e.disabled ? void 0 : l,
            "aria-disabled": e.disabled ? "true" : void 0,
            role: e.disabled ? "link" : void 0,
            rel: u,
            target: c,
            class: e.active ? e.activeClass : e.resolveLinkClass(s, e._.provides[Vr] || e.$route, {
                isActive: d,
                isExactActive: p
            }),
            onClick: E => !v && f(E)
        }), [Kt(e.$slots, "default", Gl(bo({
            isActive: e.exact ? p : d
        })))], 16, ZM)]),
        _: 3
    }, 16)) : (le(), Pe(ac(e.as), it({
        key: 0,
        disabled: e.disabled
    }, e.$attrs, {
        class: e.active ? e.activeClass : e.inactiveClass
    }), {
        default: Sn(() => [Kt(e.$slots, "default")]),
        _: 3
    }, 16, ["disabled", "class"]))
}
const _y = Pn(QM, [
    ["render", eP]
]);

function tP({
    ui: e,
    props: t
}) {
    const n = yt();
    let r = n.parent,
        a;
    for (; r && !a;) {
        if (r.type.name === "ButtonGroup") {
            a = Je(`group-${r.uid}`);
            break
        }
        r = r.parent
    }
    const i = W(() => a == null ? void 0 : a.value.children.indexOf(n));
    return Jt(() => {
        a == null || a.value.register(n)
    }), Rn(() => {
        a == null || a.value.unregister(n)
    }), {
        size: W(() => (a == null ? void 0 : a.value.size) || t.size),
        rounded: W(() => !a || i.value === -1 ? e.value.rounded : a.value.children.length === 1 ? a.value.ui.rounded : i.value === 0 ? a.value.rounded.start : i.value === a.value.children.length - 1 ? a.value.rounded.end : "rounded-none")
    }
}
const qt = ei(At.ui.strategy, At.ui.button, GM),
    nP = Ne({
        components: {
            UIcon: Jr,
            ULink: _y
        },
        inheritAttrs: !1,
        props: {
            type: {
                type: String,
                default: "button"
            },
            block: {
                type: Boolean,
                default: !1
            },
            label: {
                type: String,
                default: null
            },
            loading: {
                type: Boolean,
                default: !1
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            padded: {
                type: Boolean,
                default: !0
            },
            size: {
                type: String,
                default: () => qt.default.size,
                validator(e) {
                    return Object.keys(qt.size).includes(e)
                }
            },
            color: {
                type: String,
                default: () => qt.default.color,
                validator(e) {
                    return [...At.ui.colors, ...Object.keys(qt.color)].includes(e)
                }
            },
            variant: {
                type: String,
                default: () => qt.default.variant,
                validator(e) {
                    return [...Object.keys(qt.variant), ...Object.values(qt.color).flatMap(t => Object.keys(t))].includes(e)
                }
            },
            icon: {
                type: String,
                default: null
            },
            loadingIcon: {
                type: String,
                default: () => qt.default.loadingIcon
            },
            leadingIcon: {
                type: String,
                default: null
            },
            trailingIcon: {
                type: String,
                default: null
            },
            trailing: {
                type: Boolean,
                default: !1
            },
            leading: {
                type: Boolean,
                default: !1
            },
            square: {
                type: Boolean,
                default: !1
            },
            truncate: {
                type: Boolean,
                default: !1
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e, {
            slots: t
        }) {
            const {
                ui: n,
                attrs: r
            } = Vo("button", ir(e, "ui"), qt), {
                size: a,
                rounded: i
            } = tP({
                ui: n,
                props: e
            }), o = W(() => e.icon && e.leading || e.icon && !e.trailing || e.loading && !e.trailing || e.leadingIcon), s = W(() => e.icon && e.trailing || e.loading && e.trailing || e.trailingIcon), l = W(() => e.square || !t.default && !e.label), c = W(() => {
                var E, w;
                const v = ((w = (E = n.value.color) == null ? void 0 : E[e.color]) == null ? void 0 : w[e.variant]) || n.value.variant[e.variant];
                return Or(Et(n.value.base, n.value.font, i.value, n.value.size[a.value], n.value.gap[a.value], e.padded && n.value[l.value ? "square" : "padding"][a.value], v == null ? void 0 : v.replaceAll("{color}", e.color), e.block ? "w-full flex justify-center items-center" : "inline-flex items-center"), e.class)
            }), u = W(() => e.loading ? e.loadingIcon : e.leadingIcon || e.icon), f = W(() => e.loading && !o.value ? e.loadingIcon : e.trailingIcon || e.icon), d = W(() => Et(n.value.icon.base, n.value.icon.size[a.value], e.loading && "animate-spin")), p = W(() => Et(n.value.icon.base, n.value.icon.size[a.value], e.loading && !o.value && "animate-spin"));
            return {
                attrs: r,
                isLeading: o,
                isTrailing: s,
                isSquare: l,
                buttonClass: c,
                leadingIconName: u,
                trailingIconName: f,
                leadingIconClass: d,
                trailingIconClass: p
            }
        }
    });

function rP(e, t, n, r, a, i) {
    const o = Jr,
        s = _y;
    return le(), Pe(s, it({
        type: e.type,
        disabled: e.disabled || e.loading,
        class: e.buttonClass
    }, e.attrs), {
        default: Sn(() => [Kt(e.$slots, "leading", {
            disabled: e.disabled,
            loading: e.loading
        }, () => [e.isLeading && e.leadingIconName ? (le(), Pe(o, {
            key: 0,
            name: e.leadingIconName,
            class: Le(e.leadingIconClass),
            "aria-hidden": "true"
        }, null, 8, ["name", "class"])) : ft("", !0)]), Kt(e.$slots, "default", {}, () => [e.label ? (le(), Ke("span", {
            key: 0,
            class: Le([e.truncate ? "text-left break-all line-clamp-1" : ""])
        }, qn(e.label), 3)) : ft("", !0)]), Kt(e.$slots, "trailing", {
            disabled: e.disabled,
            loading: e.loading
        }, () => [e.isTrailing && e.trailingIconName ? (le(), Pe(o, {
            key: 0,
            name: e.trailingIconName,
            class: Le(e.trailingIconClass),
            "aria-hidden": "true"
        }, null, 8, ["name", "class"])) : ft("", !0)])]),
        _: 3
    }, 16, ["type", "disabled", "class"])
}
const wy = Pn(nP, [
    ["render", rP]
]);

function aP(e, t, n) {
    let r = null;
    const {
        pause: a,
        resume: i,
        timestamp: o
    } = UC({ ...n || {},
        controls: !0
    }), s = Q(null), l = W(() => s.value ? t - (o.value - s.value) : 0);

    function c(...E) {
        r = setTimeout(() => {
            r = null, s.value = null, e(...E)
        }, l.value)
    }

    function u() {
        r && (clearTimeout(r), r = null)
    }

    function f() {
        s.value = Date.now(), c()
    }

    function d() {
        u(), a()
    }

    function p() {
        u(), a()
    }

    function v() {
        c(), i(), s.value = (s.value || 0) + (Date.now() - o.value)
    }
    return f(), {
        start: f,
        stop: d,
        pause: p,
        resume: v,
        remaining: l
    }
}
const ea = ei(At.ui.strategy, At.ui.notification, WM),
    iP = Ne({
        components: {
            UIcon: Jr,
            UAvatar: vy,
            UButton: wy
        },
        inheritAttrs: !1,
        props: {
            id: {
                type: [String, Number],
                required: !0
            },
            title: {
                type: String,
                required: !0
            },
            description: {
                type: String,
                default: null
            },
            icon: {
                type: String,
                default: () => ea.default.icon
            },
            avatar: {
                type: Object,
                default: null
            },
            closeButton: {
                type: Object,
                default: () => ea.default.closeButton
            },
            timeout: {
                type: Number,
                default: () => ea.default.timeout
            },
            actions: {
                type: Array,
                default: () => []
            },
            callback: {
                type: Function,
                default: null
            },
            color: {
                type: String,
                default: () => ea.default.color,
                validator(e) {
                    return ["gray", ...At.ui.colors].includes(e)
                }
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        emits: ["close"],
        setup(e, {
            emit: t
        }) {
            const {
                ui: n,
                attrs: r
            } = Vo("notification", ir(e, "ui"), ea);
            let a = null;
            const i = Q(e.timeout),
                o = W(() => Or(Et(n.value.wrapper, n.value.background, n.value.rounded, n.value.shadow), e.class)),
                s = W(() => {
                    var v;
                    return Et(n.value.progress.base, (v = n.value.progress.background) == null ? void 0 : v.replaceAll("{color}", e.color))
                }),
                l = W(() => ({
                    width: `${i.value/e.timeout*100||0}%`
                })),
                c = W(() => {
                    var v;
                    return Et(n.value.icon.base, (v = n.value.icon.color) == null ? void 0 : v.replaceAll("{color}", e.color))
                });

            function u() {
                a && a.pause()
            }

            function f() {
                a && a.resume()
            }

            function d() {
                a && a.stop(), e.callback && e.callback(), t("close")
            }

            function p(v) {
                a && a.stop(), v.click && v.click(), t("close")
            }
            return Jt(() => {
                e.timeout && (a = aP(() => {
                    d()
                }, e.timeout), lc(() => {
                    i.value = a.remaining.value
                }))
            }), Rn(() => {
                a && a.stop()
            }), {
                ui: n,
                attrs: r,
                wrapperClass: o,
                progressClass: s,
                progressStyle: l,
                iconClass: c,
                onMouseover: u,
                onMouseleave: f,
                onClose: d,
                onAction: p,
                twMerge: Or
            }
        }
    }),
    oP = {
        class: "w-0 flex-1"
    };

function sP(e, t, n, r, a, i) {
    const o = Jr,
        s = vy,
        l = wy;
    return le(), Pe(Ga, it({
        appear: ""
    }, e.ui.transition), {
        default: Sn(() => [Xt("div", it({
            class: e.wrapperClass,
            role: "status"
        }, e.attrs, {
            onMouseover: t[0] || (t[0] = (...c) => e.onMouseover && e.onMouseover(...c)),
            onMouseleave: t[1] || (t[1] = (...c) => e.onMouseleave && e.onMouseleave(...c))
        }), [Xt("div", {
            class: Le([e.ui.container, e.ui.rounded, e.ui.ring])
        }, [Xt("div", {
            class: Le(["flex", [e.ui.padding, e.ui.gap, {
                "items-start": e.description || e.$slots.description,
                "items-center": !e.description && !e.$slots.description
            }]])
        }, [e.icon ? (le(), Pe(o, {
            key: 0,
            name: e.icon,
            class: Le(e.iconClass)
        }, null, 8, ["name", "class"])) : ft("", !0), e.avatar ? (le(), Pe(s, it({
            key: 1
        }, {
            size: e.ui.avatar.size,
            ...e.avatar
        }, {
            class: e.ui.avatar.base
        }), null, 16, ["class"])) : ft("", !0), Xt("div", oP, [Xt("p", {
            class: Le(e.ui.title)
        }, [Kt(e.$slots, "title", {
            title: e.title
        }, () => [La(qn(e.title), 1)])], 2), e.description || e.$slots.description ? (le(), Ke("p", {
            key: 0,
            class: Le(e.ui.description)
        }, [Kt(e.$slots, "description", {
            description: e.description
        }, () => [La(qn(e.description), 1)])], 2)) : ft("", !0), (e.description || e.$slots.description) && e.actions.length ? (le(), Ke("div", {
            key: 1,
            class: Le(e.ui.actions)
        }, [(le(!0), Ke(Fe, null, Vi(e.actions, (c, u) => (le(), Pe(l, it({
            key: u
        }, { ...e.ui.default.actionButton,
            ...c
        }, {
            onClick: ts(f => e.onAction(c), ["stop"])
        }), null, 16, ["onClick"]))), 128))], 2)) : ft("", !0)]), e.closeButton || !e.description && !e.$slots.description && e.actions.length ? (le(), Ke("div", {
            key: 2,
            class: Le(e.twMerge(e.ui.actions, "mt-0"))
        }, [!e.description && !e.$slots.description && e.actions.length ? (le(!0), Ke(Fe, {
            key: 0
        }, Vi(e.actions, (c, u) => (le(), Pe(l, it({
            key: u
        }, { ...e.ui.default.actionButton,
            ...c
        }, {
            onClick: ts(f => e.onAction(c), ["stop"])
        }), null, 16, ["onClick"]))), 128)) : ft("", !0), e.closeButton ? (le(), Pe(l, it({
            key: 1,
            "aria-label": "Close"
        }, { ...e.ui.default.closeButton,
            ...e.closeButton
        }, {
            onClick: ts(e.onClose, ["stop"])
        }), null, 16, ["onClick"])) : ft("", !0)], 2)) : ft("", !0)], 2), e.timeout ? (le(), Ke("div", {
            key: 0,
            class: Le(e.progressClass),
            style: er(e.progressStyle)
        }, null, 6)) : ft("", !0)], 2)], 16)]),
        _: 3
    }, 16)
}
const Ey = Pn(iP, [
        ["render", sP]
    ]),
    lP = ei(At.ui.strategy, At.ui.notifications, zM),
    cP = Ne({
        components: {
            UNotification: Ey
        },
        inheritAttrs: !1,
        props: {
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Vo("notifications", ir(e, "ui"), lP), r = Ug(), a = qa("notifications", () => []), i = W(() => Or(Et(t.value.wrapper, t.value.position, t.value.width), e.class));
            return {
                ui: t,
                attrs: n,
                toast: r,
                notifications: a,
                wrapperClass: i
            }
        }
    });

function uP(e, t, n, r, a, i) {
    const o = Ey;
    return le(), Pe(hv, {
        to: "body"
    }, [Xt("div", it({
        class: e.wrapperClass,
        role: "region"
    }, e.attrs), [e.notifications.length ? (le(), Ke("div", {
        key: 0,
        class: Le(e.ui.container)
    }, [(le(!0), Ke(Fe, null, Vi(e.notifications, s => (le(), Ke("div", {
        key: s.id
    }, [Ae(o, it(s, {
        class: s.click && "cursor-pointer",
        onClick: l => s.click && s.click(s),
        onClose: l => e.toast.remove(s.id)
    }), Ub({
        _: 2
    }, [Vi(e.$slots, (l, c) => ({
        name: c,
        fn: Sn(u => [Kt(e.$slots, c, Gl(bo(u)))])
    }))]), 1040, ["class", "onClick", "onClose"])]))), 128))], 2)) : ft("", !0)], 16)])
}
const fP = Pn(cP, [
    ["render", uP]
]);
const dP = {};

function pP(e, t) {
    const n = AO,
        r = kO,
        a = xO,
        i = fP;
    return le(), Ke(Fe, null, [Ae(n), Ae(a, null, {
        default: Sn(() => [Ae(r)]),
        _: 1
    }), Ae(i)], 64)
}
const hP = Pn(dP, [
        ["render", pP]
    ]),
    mP = {
        __name: "nuxt-error-page",
        props: {
            error: Object
        },
        setup(e) {
            const n = e.error;
            (n.stack || "").split(`
`).splice(1).map(f => ({
                text: f.replace("webpack:/", "").replace(".vue", ".js").trim(),
                internal: f.includes("node_modules") && !f.includes(".cache") || f.includes("internal") || f.includes("new Promise")
            })).map(f => `<span class="stack${f.internal?" internal":""}">${f.text}</span>`).join(`
`);
            const r = Number(n.statusCode || 500),
                a = r === 404,
                i = n.statusMessage ? ? (a ? "Page Not Found" : "Internal Server Error"),
                o = n.message || n.toString(),
                s = void 0,
                u = a ? $i(() => D(() =>
                    import ("./error-404.bfb6aae2.js"), ["./error-404.bfb6aae2.js", "./error-404.871584dc.css"],
                    import.meta.url).then(f => f.default || f)) : $i(() => D(() =>
                    import ("./error-500.b91575b5.js"), ["./error-500.b91575b5.js", "./error-500.5504fd74.css"],
                    import.meta.url).then(f => f.default || f));
            return (f, d) => (le(), Pe(pe(u), Gl(bo({
                statusCode: pe(r),
                statusMessage: pe(i),
                description: pe(o),
                stack: pe(s)
            })), null, 16))
        }
    },
    cp = {
        __name: "nuxt-root",
        setup(e) {
            const t = () => null,
                n = ge(),
                r = n.deferHydration(),
                a = !1;
            Qn(Vr, Hr()), n.hooks.callHookWith(s => s.map(l => l()), "vue:setup");
            const i = Co();
            Wp((s, l, c) => {
                if (n.hooks.callHook("vue:error", s, l, c).catch(u => console.error("[nuxt] Error in `vue:error` hook", u)), mw(s) && (s.fatal || s.unhandled)) return n.runWithContext(() => yn(s)), !1
            });
            const o = !1;
            return (s, l) => (le(), Pe(oc, {
                onResolve: pe(r)
            }, {
                default: Sn(() => [pe(i) ? (le(), Pe(pe(mP), {
                    key: 0,
                    error: pe(i)
                }, null, 8, ["error"])) : pe(o) ? (le(), Pe(pe(t), {
                    key: 1,
                    context: pe(o)
                }, null, 8, ["context"])) : pe(a) ? (le(), Pe(ac(pe(a)), {
                    key: 2
                })) : (le(), Pe(pe(hP), {
                    key: 3
                }))]),
                _: 1
            }, 8, ["onResolve"]))
        }
    };
let up; {
    let e;
    up = async function() {
        var o, s;
        if (e) return e;
        const r = !!((o = window.__NUXT__) != null && o.serverRendered || ((s = document.getElementById("__NUXT_DATA__")) == null ? void 0 : s.dataset.ssr) === "true") ? e0(cp) : Zv(cp),
            a = r_({
                vueApp: r
            });
        async function i(l) {
            await a.callHook("app:error", l), a.payload.error = a.payload.error || l
        }
        r.config.errorHandler = i;
        try {
            await i_(a, CO)
        } catch (l) {
            i(l)
        }
        try {
            await a.hooks.callHook("app:created", r), await a.hooks.callHook("app:beforeMount", r), r.mount(Cw), await a.hooks.callHook("app:mounted", r), await St()
        } catch (l) {
            i(l)
        }
        return r.config.errorHandler === i && (r.config.errorHandler = void 0), r
    }, e = up().catch(t => {
        console.error("Error while mounting app:", t)
    })
}
export {
    tn as $, Et as A, Kt as B, Le as C, it as D, vy as E, Jt as F, ro as G, Pe as H, Fe as I, Vi as J, Hr as K, TP as L, ts as M, oO as N, wP as O, Wa as P, $M as Q, er as R, Gl as S, Jr as T, vn as U, LP as V, bP as W, vP as X, Or as Y, ac as Z, Pn as _, Xt as a, Be as a0, Je as a1, Qn as a2, lc as a3, St as a4, Rn as a5, we as a6, hv as a7, tt as a8, Er as a9, Np as aa, _e as ab, wy as ac, RP as ad, qa as ae, PP as af, Eo as ag, QS as ah, Ga as ai, OP as aj, AP as ak, xP as al, tP as am, ZS as an, by as ao, kP as ap, bo as aq, SP as ar, To as as, fO as at, EP as au, MP as av, yy as aw, ma as ax, Ae as b, Ke as c, La as d, om as e, yP as f, Ne as g, pt as h, pe as i, Kr as j, _P as k, Na as l, Zm as m, ft as n, le as o, gP as p, ei as q, Q as r, CP as s, qn as t, wo as u, At as v, Sn as w, Vo as x, ir as y, W as z
};