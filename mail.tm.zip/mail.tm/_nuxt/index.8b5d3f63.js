import {
    _ as F,
    s as V,
    l as T,
    r as l,
    m as U,
    o,
    c as r,
    a as e,
    t as a,
    i as g,
    n as p,
    d as _,
    p as H,
    f as P,
    q as J,
    v as k,
    g as R,
    x as q,
    y as z,
    z as L,
    A as G,
    B,
    C as O,
    D as W,
    b as y,
    w,
    E as Y,
    e as K,
    j as Q,
    F as X,
    G as I,
    u as ee,
    H as j,
    I as D,
    J as te
} from "./entry.43614be6.js";
import {
    _ as se
} from "./client-only.be8c7cca.js";
const ae = {
    wrapper: "relative inline-flex items-center justify-center flex-shrink-0",
    base: "absolute rounded-full ring-1 ring-white dark:ring-gray-900 flex items-center justify-center text-white dark:text-gray-900 font-medium whitespace-nowrap",
    background: "bg-{color}-500 dark:bg-{color}-400",
    position: {
        "top-right": "top-0 right-0",
        "bottom-right": "bottom-0 right-0",
        "top-left": "top-0 left-0",
        "bottom-left": "bottom-0 left-0"
    },
    translate: {
        "top-right": "-translate-y-1/2 translate-x-1/2 transform",
        "bottom-right": "translate-y-1/2 translate-x-1/2 transform",
        "top-left": "-translate-y-1/2 -translate-x-1/2 transform",
        "bottom-left": "translate-y-1/2 -translate-x-1/2 transform"
    },
    size: {
        "3xs": "h-[4px] min-w-[4px] text-[4px] p-px",
        "2xs": "h-[5px] min-w-[5px] text-[5px] p-px",
        xs: "h-1.5 min-w-[0.375rem] text-[6px] p-px",
        sm: "h-2 min-w-[0.5rem] text-[7px] p-0.5",
        md: "h-2.5 min-w-[0.625rem] text-[8px] p-0.5",
        lg: "h-3 min-w-[0.75rem] text-[10px] p-0.5",
        xl: "h-3.5 min-w-[0.875rem] text-[11px] p-1",
        "2xl": "h-4 min-w-[1rem] text-[12px] p-1",
        "3xl": "h-5 min-w-[1.25rem] text-[14px] p-1"
    },
    default: {
        size: "sm",
        color: "primary",
        position: "top-right",
        inset: !1
    }
};
const v = t => (H("data-v-4eae4850"), t = t(), P(), t),
    le = {
        class: "lg:h-full flex flex-col items-center justify-center"
    },
    oe = {
        id: "envelope",
        class: "relative mx-auto"
    },
    ne = {
        class: "h-56 w-56",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 1035 832"
    },
    re = v(() => e("div", {
        class: "envelope-glowing"
    }, null, -1)),
    ie = {
        class: "text-2xl leading-9 tracking-tight text-gray-900 sm:text-2xl sm:leading-10 dark:text-gray-300"
    },
    ce = {
        key: 0,
        class: "text-center text-gray-700 lg:max-w-2xl dark:text-gray-400 text-lg"
    },
    de = {
        key: 1,
        class: "text-center text-gray-700 lg:max-w-2xl dark:text-gray-400 text-lg"
    },
    me = {
        key: 2,
        class: "mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-20 lg:max-w-none"
    },
    ge = {
        class: "grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3"
    },
    ue = {
        class: "flex flex-col"
    },
    he = {
        class: "flex items-center gap-x-3 text-base font-extralight leading-7 text-gray-900 dark:text-gray-400"
    },
    pe = v(() => e("svg", {
        class: "h-5 w-5 flex-none text-indigo-600 dark:text-indigo-500",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        "stroke-width": "1.5",
        stroke: "currentColor"
    }, [e("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        d: "M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"
    })], -1)),
    xe = {
        class: "mt-4 flex flex-auto flex-col text-base leading-7 text-gray-700 dark:text-gray-400"
    },
    fe = {
        class: "flex-auto"
    },
    _e = {
        class: "flex flex-col"
    },
    ye = {
        class: "flex items-center gap-x-3 text-base font-extralight leading-7 text-gray-900 dark:text-gray-400"
    },
    ve = v(() => e("svg", {
        class: "h-5 w-5 flex-none text-indigo-600 dark:text-indigo-500",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        "stroke-width": "1.5",
        stroke: "currentColor"
    }, [e("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        d: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
    })], -1)),
    ke = {
        class: "mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600 dark:text-gray-400"
    },
    we = {
        class: "flex-auto"
    },
    be = {
        class: "flex flex-col"
    },
    $e = {
        class: "flex items-center gap-x-3 text-base font-extralight leading-7 text-gray-900 dark:text-gray-400"
    },
    Ze = v(() => e("svg", {
        class: "h-5 w-5 flex-none text-indigo-600 dark:text-indigo-500",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        "stroke-width": "1.5",
        stroke: "currentColor"
    }, [e("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        d: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
    })], -1)),
    Ce = {
        class: "mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600 dark:text-gray-400"
    },
    Se = {
        class: "flex-auto"
    },
    Me = {
        __name: "Envelope",
        setup(t) {
            const {
                isWarned: s
            } = V(T()), i = l(null), c = l(null), u = l(null), d = l(null), x = l(null), f = l(null), h = l(null), b = l(null), $ = l(null), Z = l(null), C = l(null), S = l(null), E = l(null), A = l(null);
            return [i, c, u, d, x, f, h, b, $, Z, C, S].forEach((n, M) => {
                const {
                    variant: N
                } = U(n, {
                    initial: {
                        y: 10
                    },
                    enter: {
                        y: 0,
                        transition: {
                            type: "spring",
                            stiffness: 350,
                            damping: 20,
                            delay: M * 50,
                            onComplete: () => {
                                N.value = "levitate"
                            }
                        }
                    },
                    levitate: {
                        y: 18,
                        transition: {
                            duration: 2400,
                            repeat: Number.POSITIVE_INFINITY,
                            ease: "easeInOut",
                            repeatType: "mirror"
                        }
                    }
                })
            }), (n, M) => (o(), r("div", le, [e("div", oe, [(o(), r("svg", ne, [e("path", {
                ref_key: "background",
                ref: i,
                opacity: ".1",
                d: "M601 95c-66-2-129-20-189-39S291 15 227 4c-42-6-90-7-123 11S61 64 55 93c-4 21-6 44 5 64 8 14 23 26 33 39 34 47 10 105-28 150-17 22-37 42-51 65s-19 49-8 72c12 23 40 40 70 53 61 24 133 31 203 35 156 9 313 5 469 1 57-1 115-2 172-10 32-4 64-10 87-26 29-20 36-54 17-80-33-42-123-52-146-98-13-25 0-52 19-76 39-49 105-93 108-149 2-39-29-78-78-97-51-19-122-17-160 15-39 33-107 46-166 44ZM514.5 831.6c160.604 0 290.8-13.118 290.8-29.3 0-16.182-130.196-29.3-290.8-29.3s-290.8 13.118-290.8 29.3c0 16.182 130.196 29.3 290.8 29.3Z",
                fill: "#6C63FF"
            }, null, 512), e("path", {
                ref_key: "branchDark",
                ref: c,
                d: "M249 799s-13-73-61-109c-20-15-35-36-42-60l-5-34",
                stroke: "#535461",
                "stroke-width": "2",
                "stroke-miterlimit": "10"
            }, null, 512), e("path", {
                ref_key: "leavesDarkShadow",
                ref: x,
                d: "M111 573c4 8 30 24 30 24s4-30 0-37c-4-8-14-12-23-8s-11 14-7 21Zm-3 55c8 5 39 4 39 4s-14-26-22-31-18-2-22 5-3 18 5 22Zm39 74c10 0 37-16 37-16s-27-16-36-16-17 7-17 16 7 16 16 16Zm43 49c9 2 39-9 39-9s-23-20-33-22-17 4-19 13 4 17 13 18Zm-10-132c-3 8-28 27-28 27s-7-29-3-38 12-12 21-9 13 12 10 20Zm49 59c-5 7-35 17-35 17s3-30 9-36c6-7 16-9 23-3 7 4 9 14 4 21l-1 1Zm40 63c-4 7-31 23-31 23s-3-30 2-38 14-11 22-7 12 14 7 22Z",
                fill: "#6C63FF"
            }, null, 512), e("path", {
                ref_key: "leavesDark",
                ref: d,
                opacity: ".25",
                d: "M111 573c4 8 30 24 30 24s4-30 0-37c-4-8-14-12-23-8s-11 14-7 21Zm-3 55c8 5 39 4 39 4s-14-26-22-31-18-2-22 5-3 18 5 22Zm39 74c10 0 37-16 37-16s-27-16-36-16-17 7-17 16 7 16 16 16Zm43 49c9 2 39-9 39-9s-23-20-33-22-17 4-19 13 4 17 13 18Zm-10-132c-3 8-28 27-28 27s-7-29-3-38 12-12 21-9 13 12 10 20Zm49 59c-5 7-35 17-35 17s3-30 9-36c6-7 16-9 23-3 7 4 9 14 4 21l-1 1Zm40 63c-4 7-31 23-31 23s-3-30 2-38 14-11 22-7 12 14 7 22Z",
                fill: "#000"
            }, null, 512), e("path", {
                ref_key: "branchLight",
                ref: u,
                d: "M247 797s20-72-9-123c-11-22-16-46-12-70 2-12 5-23 10-34",
                stroke: "#535461",
                "stroke-width": "2",
                "stroke-miterlimit": "10"
            }, null, 512), e("path", {
                ref_key: "leavesLight",
                ref: f,
                d: "M218 538c0 9 18 33 18 33s16-25 15-34-8-16-17-15-16 7-16 16Zm-26 49c5 7 34 19 34 19s-1-30-7-37c-5-7-15-9-23-4a15.005 15.005 0 0 0-6.919 10.106A14.99 14.99 0 0 0 192 587Zm4 83c9 3 40-1 40-1s-17-25-26-28-18 0-22 7 0 18 8 22Zm18 61c8 5 39 7 39 7s-12-28-20-33-18-3-23 4-4 17 3 22h1Zm47-124c-6 6-37 13-37 13s7-29 13-35c7-7 17-7 24-1 6 6 7 15 1 22l-1 1Zm21 72c-9 4-40 2-40 2s15-26 23-30 19-1 23 6c5 8 2 18-6 22Zm9 73c-7 5-39 9-39 9s11-29 18-34 18-4 24 3a15 15 0 0 1-3 22Z",
                fill: "#6C63FF"
            }, null, 512), e("path", {
                ref_key: "letterClosingShadow",
                ref: Z,
                d: "M579 214 317 384l171 308c1 3 4 5 7 6l155 37c5 2 11-1 13-6l77-160 84-112-199-236a35 35 0 0 0-46-7Z",
                fill: "#DCDFED"
            }, null, 512), e("path", {
                ref_key: "letterClosing",
                ref: $,
                opacity: ".1",
                d: "m827 459-1 1-49 65-1 2-33 44-66 136-2 4-9 19c-2 5-8 8-13 7l-155-38c-3-1-6-3-8-6l-15-27-2-4-107-194-1-2-45-81 5-3 41-27h1l87-56 5-4 122-79c15-10 35-7 46 7l91 107 4 5 67 78v1l33 39 4 5 1 1Z",
                fill: "#000"
            }, null, 512), e("path", {
                ref_key: "paperShadow",
                ref: A,
                opacity: ".1",
                d: "m786 412-8 56-2 17-2 36v3l-7 188a11.999 11.999 0 0 1-14 11l-78-17h-1l-200-45-4-1-110-24 3-169v-6l1-51v-57l87-56 6-3c80 8 187 24 259 35l4 5 66 78Z",
                fill: "#000"
            }, null, 512), e("path", {
                ref_key: "paper",
                ref: E,
                d: "m795 346-9 66-9 60-2 17-2 36-7 191a11.999 11.999 0 0 1-14 11l-79-17-200-45-114-25 3-175 1-51 1-60v-62c19-1 50 1 87 5a5591.76 5591.76 0 0 1 344 49Z",
                fill: "#6C63FF"
            }, null, 512), e("path", {
                ref_key: "letterBodyInside",
                ref: b,
                opacity: ".1",
                d: "m820 452-43 20-215 106-199-164-41-33-5 3 45 81-3 175 114 25 15 27c1 3 4 5 7 6l155 37c5 2 11-1 13-6l10-19 78 17c7 2 13-2 15-9v-2l7-191 50-67v-1l-3-5Z",
                fill: "#000"
            }, null, 512), e("path", {
                ref_key: "letterBody",
                ref: h,
                d: "m317 384-18 305c0 6 4 11 9 13l474 105a11.994 11.994 0 0 0 9.442-2.391A11.997 11.997 0 0 0 796 796l28-339-262 129-245-202Z",
                fill: "#DCDFED"
            }, null, 512), e("path", {
                ref_key: "letterOpenShadow",
                ref: S,
                opacity: ".1",
                d: "m303 696 246-151c7-5 17-3 23 3l220 257c1 1 1 0 0 0L303 696c-2 1-2 0 0 0Z",
                fill: "#000"
            }, null, 512), e("path", {
                ref_key: "letterOpen",
                ref: C,
                d: "m304 696 244-147c8-5 18-3 24 4l218 251v3l-2 1-483-107-2-3 1-2Z",
                fill: "#E3E5F1"
            }, null, 512)])), re]), e("h1", ie, a(n.$t("home.content_title")), 1), g(s) ? p("", !0) : (o(), r("span", ce, a(n.$t("home.content")), 1)), g(s) ? (o(), r("span", de, a(n.$t("home.desc")), 1)) : p("", !0), g(s) ? p("", !0) : (o(), r("div", me, [e("dl", ge, [e("div", ue, [e("dt", he, [pe, _(" " + a(n.$t("home.feature_a_title")), 1)]), e("dd", xe, [e("p", fe, a(n.$t("home.feature_a_desc")), 1)])]), e("div", _e, [e("dt", ye, [ve, _(" " + a(n.$t("home.feature_b_title")), 1)]), e("dd", ke, [e("p", we, a(n.$t("home.feature_b_desc")), 1)])]), e("div", be, [e("dt", $e, [Ze, _(" " + a(n.$t("home.feature_c_title")), 1)]), e("dd", Ce, [e("p", Se, a(n.$t("home.feature_c_desc")), 1)])])])]))]))
        }
    },
    ze = F(Me, [
        ["__scopeId", "data-v-4eae4850"]
    ]),
    m = J(k.ui.strategy, k.ui.chip, ae),
    Be = R({
        inheritAttrs: !1,
        props: {
            size: {
                type: String,
                default: () => m.default.size,
                validator(t) {
                    return Object.keys(m.size).includes(t)
                }
            },
            color: {
                type: String,
                default: () => m.default.color,
                validator(t) {
                    return ["gray", ...k.ui.colors].includes(t)
                }
            },
            position: {
                type: String,
                default: () => m.default.position,
                validator(t) {
                    return Object.keys(m.position).includes(t)
                }
            },
            text: {
                type: [String, Number],
                default: null
            },
            inset: {
                type: Boolean,
                default: () => m.default.inset
            },
            show: {
                type: Boolean,
                default: !0
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(t) {
            const {
                ui: s,
                attrs: i
            } = q("chip", z(t, "ui"), m, z(t, "class")), c = L(() => G(s.value.base, s.value.size[t.size], s.value.position[t.position], t.inset ? null : s.value.translate[t.position], s.value.background.replaceAll("{color}", t.color)));
            return {
                ui: s,
                attrs: i,
                chipClass: c
            }
        }
    });

function Ie(t, s, i, c, u, d) {
    return o(), r("div", W({
        class: t.ui.wrapper
    }, t.attrs), [B(t.$slots, "default"), t.show ? (o(), r("span", {
        key: 0,
        class: O(t.chipClass)
    }, [B(t.$slots, "content", {}, () => [_(a(t.text), 1)])], 2)) : p("", !0)], 16)
}
const je = F(Be, [
        ["render", Ie]
    ]),
    De = {
        key: 0
    },
    Fe = {
        class: "flex items-center px-4 py-4 sm:px-6"
    },
    Le = {
        class: "min-w-0 flex flex-1 items-center"
    },
    Oe = {
        class: "flex-shrink-0"
    },
    Ee = {
        class: "relative inline-block"
    },
    Ae = {
        class: "min-w-0 flex-1 px-4 md:grid md:grid-cols-2 md:gap-4"
    },
    Ne = {
        class: "truncate text-sm font-medium leading-5 text-indigo-600 dark:text-indigo-400"
    },
    Ve = {
        class: "mt-2 flex items-center text-sm leading-5 text-gray-500 dark:text-gray-400"
    },
    Te = e("svg", {
        class: "mr-1.5 h-5 w-5 flex-shrink-0 text-gray-400",
        fill: "currentColor",
        viewBox: "0 0 20 20"
    }, [e("path", {
        "fill-rule": "evenodd",
        d: "M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884zM18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z",
        "clip-rule": "evenodd"
    })], -1),
    Ue = {
        class: "truncate"
    },
    He = {
        class: "hidden md:block"
    },
    Pe = {
        class: "truncate text-sm leading-5 text-gray-900 dark:text-gray-300"
    },
    Je = {
        class: "mt-2 flex items-center truncate text-sm leading-5 text-gray-400 dark:text-gray-400"
    },
    Re = e("div", null, [e("svg", {
        class: "h-5 w-5 text-gray-400",
        fill: "currentColor",
        viewBox: "0 0 20 20"
    }, [e("path", {
        "fill-rule": "evenodd",
        d: "M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z",
        "clip-rule": "evenodd"
    })])], -1),
    qe = {
        __name: "List",
        props: {
            message: {
                type: Object,
                default: () => ({})
            }
        },
        setup(t) {
            return (s, i) => {
                const c = Y,
                    u = je,
                    d = K;
                return t.message ? (o(), r("li", De, [y(d, {
                    to: s.localePath({
                        name: "view-id",
                        params: {
                            id: t.message.id
                        }
                    }),
                    class: "group block transition hover:bg-gray-50 focus:outline-none dark:focus:bg-gray-700 dark:hover:bg-gray-700"
                }, {
                    default: w(() => [e("div", Fe, [e("div", Le, [e("div", Oe, [e("span", Ee, [y(u, {
                        show: !t.message.seen,
                        inset: "",
                        size: "lg",
                        position: "bottom-right",
                        ui: {
                            base: "ring-0",
                            background: "bg-blue-500  dark:bg-blue-600"
                        }
                    }, {
                        default: w(() => [y(c, {
                            size: "lg",
                            alt: t.message.from.address.toUpperCase(),
                            ui: {
                                background: " transition bg-gray-200 dark:bg-gray-700 dark:group-hover:bg-gray-800/75  group-hover:bg-gray-300",
                                placeholder: "font-medium leading-none text-gray-600 dark:text-gray-300 dark:group-hover:text-gray-200 group-hover:text-gray-700 truncate"
                            }
                        }, null, 8, ["alt"])]),
                        _: 1
                    }, 8, ["show"])])]), e("div", Ae, [e("div", null, [e("div", Ne, a(t.message.from.name), 1), e("div", Ve, [Te, e("span", Ue, a(t.message.from.address), 1)])]), e("div", He, [e("div", null, [e("div", Pe, a(t.message.subject) + " ", 1), e("div", Je, a(t.message.intro), 1)])])])]), Re])]),
                    _: 1
                }, 8, ["to"])])) : p("", !0)
            }
        }
    },
    Ge = {
        class: "mt-2 md:flex md:items-center md:justify-between"
    },
    We = {
        class: "min-w-0 flex-1"
    },
    Ye = {
        class: "text-2xl font-bold leading-7 text-gray-900 sm:truncate dark:text-gray-300"
    },
    Ke = {
        class: "mt-6 overflow-hidden bg-white shadow sm:rounded-md dark:bg-gray-800"
    },
    Qe = {
        class: "divide-y divide-gray-200 dark:divide-gray-700"
    },
    st = {
        __name: "index",
        setup(t) {
            const {
                t: s
            } = Q(), i = L(() => I().getMessages);
            return X(async () => {
                await I().fetchMessages()
            }), ee({
                title: s("home.title"),
                meta: [{
                    hid: "description",
                    name: "description",
                    content: s("home.desc")
                }, {
                    hid: "og:title",
                    name: "og:title",
                    content: s("home.title")
                }, {
                    hid: "og:description",
                    name: "og:description",
                    content: s("home.desc")
                }, {
                    hid: "og:image",
                    name: "og:image",
                    content: "https://mail.tm/mailtm.png"
                }, {
                    hid: "twitter:card",
                    name: "twitter:card",
                    content: "summary_large_image"
                }, {
                    hid: "twitter:image",
                    name: "twitter:image",
                    content: "https://mail.tm/mailtm.png"
                }, {
                    hid: "twitter:title",
                    name: "twitter:title",
                    content: s("home.title")
                }, {
                    hid: "twitter:description",
                    name: "twitter:description",
                    content: s("home.desc")
                }]
            }), (c, u) => {
                const d = ze,
                    x = qe,
                    f = se;
                return o(), r("div", {
                    class: O(["mx-auto max-w-7xl px-4 lg:max-w-full md:px-8 sm:px-6", {
                        "h-full": g(i).length === 0
                    }])
                }, [g(i).length === 0 ? (o(), j(d, {
                    key: 0
                })) : (o(), r(D, {
                    key: 1
                }, [e("div", Ge, [e("div", We, [e("h2", Ye, a(g(s)("feature.inbox")), 1)])]), e("div", Ke, [e("ul", Qe, [y(f, null, {
                    default: w(() => [(o(!0), r(D, null, te(g(i), h => (o(), j(x, {
                        key: h["@id"],
                        message: h
                    }, null, 8, ["message"]))), 128))]),
                    _: 1
                })])])], 64))], 2)
            }
        }
    };
export {
    st as
    default
};