import {
    aw as Tt,
    q as ut,
    v as xe,
    _ as lt,
    g as pt,
    x as ct,
    y as je,
    z as dt,
    Y as Mt,
    A as St,
    o as J,
    c as Z,
    B as Be,
    d as ye,
    t as Te,
    D as Me,
    r as be,
    F as Lt,
    a3 as Rt,
    ax as et,
    ag as Wt,
    C as ge,
    b as Ht,
    w as tt,
    a as Se,
    n as De,
    I as Nt,
    J as Vt,
    H as zt,
    ai as Ft
} from "./entry.43614be6.js";
const qt = {
        base: "inline-flex items-center justify-center text-gray-900 dark:text-white",
        padding: "px-1",
        size: {
            xs: "h-4 min-w-[16px] text-[10px]",
            sm: "h-5 min-w-[20px] text-[11px]",
            md: "h-6 min-w-[24px] text-[12px]"
        },
        rounded: "rounded",
        font: "font-medium font-sans",
        background: "bg-gray-100 dark:bg-gray-800",
        ring: "ring-1 ring-gray-300 dark:ring-gray-700 ring-inset",
        default: {
            size: "sm"
        }
    },
    It = {
        wrapper: "relative inline-flex",
        container: "z-20 group",
        width: "max-w-xs",
        background: "bg-white dark:bg-gray-900",
        color: "text-gray-900 dark:text-white",
        shadow: "shadow",
        rounded: "rounded",
        ring: "ring-1 ring-gray-200 dark:ring-gray-800",
        base: "[@media(pointer:coarse)]:hidden h-6 px-2 py-1 text-xs font-normal truncate relative",
        shortcuts: "hidden md:inline-flex flex-shrink-0 gap-0.5",
        transition: {
            enterActiveClass: "transition ease-out duration-200",
            enterFromClass: "opacity-0 translate-y-1",
            enterToClass: "opacity-100 translate-y-0",
            leaveActiveClass: "transition ease-in duration-150",
            leaveFromClass: "opacity-100 translate-y-0",
            leaveToClass: "opacity-0 translate-y-1"
        },
        popper: {
            strategy: "fixed"
        },
        arrow: Tt
    },
    Pe = ut(xe.ui.strategy, xe.ui.kbd, qt),
    Ut = pt({
        inheritAttrs: !1,
        props: {
            value: {
                type: String,
                default: null
            },
            size: {
                type: String,
                default: () => Pe.default.size,
                validator(e) {
                    return Object.keys(Pe.size).includes(e)
                }
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: r
            } = ct("kbd", je(e, "ui"), Pe), n = dt(() => Mt(St(t.value.base, t.value.size[e.size], t.value.padding, t.value.rounded, t.value.font, t.value.background, t.value.ring), e.class));
            return {
                ui: t,
                attrs: r,
                kbdClass: n
            }
        }
    });

function Xt(e, t, r, n, a, s) {
    return J(), Z("kbd", Me({
        class: e.kbdClass
    }, e.attrs), [Be(e.$slots, "default", {}, () => [ye(Te(e.value), 1)])], 16)
}
const vt = lt(Ut, [
    ["render", Xt]
]);

function T(e) {
    if (e == null) return window;
    if (e.toString() !== "[object Window]") {
        var t = e.ownerDocument;
        return t && t.defaultView || window
    }
    return e
}

function G(e) {
    var t = T(e).Element;
    return e instanceof t || e instanceof Element
}

function M(e) {
    var t = T(e).HTMLElement;
    return e instanceof t || e instanceof HTMLElement
}

function We(e) {
    if (typeof ShadowRoot > "u") return !1;
    var t = T(e).ShadowRoot;
    return e instanceof t || e instanceof ShadowRoot
}
var K = Math.max,
    Oe = Math.min,
    _ = Math.round;

function Le() {
    var e = navigator.userAgentData;
    return e != null && e.brands && Array.isArray(e.brands) ? e.brands.map(function(t) {
        return t.brand + "/" + t.version
    }).join(" ") : navigator.userAgent
}

function mt() {
    return !/^((?!chrome|android).)*safari/i.test(Le())
}

function ee(e, t, r) {
    t === void 0 && (t = !1), r === void 0 && (r = !1);
    var n = e.getBoundingClientRect(),
        a = 1,
        s = 1;
    t && M(e) && (a = e.offsetWidth > 0 && _(n.width) / e.offsetWidth || 1, s = e.offsetHeight > 0 && _(n.height) / e.offsetHeight || 1);
    var f = G(e) ? T(e) : window,
        o = f.visualViewport,
        i = !mt() && r,
        l = (n.left + (i && o ? o.offsetLeft : 0)) / a,
        u = (n.top + (i && o ? o.offsetTop : 0)) / s,
        v = n.width / a,
        g = n.height / s;
    return {
        width: v,
        height: g,
        top: u,
        right: l + v,
        bottom: u + g,
        left: l,
        x: l,
        y: u
    }
}

function He(e) {
    var t = T(e),
        r = t.pageXOffset,
        n = t.pageYOffset;
    return {
        scrollLeft: r,
        scrollTop: n
    }
}

function Yt(e) {
    return {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    }
}

function Jt(e) {
    return e === T(e) || !M(e) ? He(e) : Yt(e)
}

function N(e) {
    return e ? (e.nodeName || "").toLowerCase() : null
}

function F(e) {
    return ((G(e) ? e.ownerDocument : e.document) || window.document).documentElement
}

function Ne(e) {
    return ee(F(e)).left + He(e).scrollLeft
}

function V(e) {
    return T(e).getComputedStyle(e)
}

function Ve(e) {
    var t = V(e),
        r = t.overflow,
        n = t.overflowX,
        a = t.overflowY;
    return /auto|scroll|overlay|hidden/.test(r + a + n)
}

function Kt(e) {
    var t = e.getBoundingClientRect(),
        r = _(t.width) / e.offsetWidth || 1,
        n = _(t.height) / e.offsetHeight || 1;
    return r !== 1 || n !== 1
}

function Gt(e, t, r) {
    r === void 0 && (r = !1);
    var n = M(t),
        a = M(t) && Kt(t),
        s = F(t),
        f = ee(e, a, r),
        o = {
            scrollLeft: 0,
            scrollTop: 0
        },
        i = {
            x: 0,
            y: 0
        };
    return (n || !n && !r) && ((N(t) !== "body" || Ve(s)) && (o = Jt(t)), M(t) ? (i = ee(t, !0), i.x += t.clientLeft, i.y += t.clientTop) : s && (i.x = Ne(s))), {
        x: f.left + o.scrollLeft - i.x,
        y: f.top + o.scrollTop - i.y,
        width: f.width,
        height: f.height
    }
}

function ze(e) {
    var t = ee(e),
        r = e.offsetWidth,
        n = e.offsetHeight;
    return Math.abs(t.width - r) <= 1 && (r = t.width), Math.abs(t.height - n) <= 1 && (n = t.height), {
        x: e.offsetLeft,
        y: e.offsetTop,
        width: r,
        height: n
    }
}

function Ae(e) {
    return N(e) === "html" ? e : e.assignedSlot || e.parentNode || (We(e) ? e.host : null) || F(e)
}

function gt(e) {
    return ["html", "body", "#document"].indexOf(N(e)) >= 0 ? e.ownerDocument.body : M(e) && Ve(e) ? e : gt(Ae(e))
}

function ie(e, t) {
    var r;
    t === void 0 && (t = []);
    var n = gt(e),
        a = n === ((r = e.ownerDocument) == null ? void 0 : r.body),
        s = T(n),
        f = a ? [s].concat(s.visualViewport || [], Ve(n) ? n : []) : n,
        o = t.concat(f);
    return a ? o : o.concat(ie(Ae(f)))
}

function Qt(e) {
    return ["table", "td", "th"].indexOf(N(e)) >= 0
}

function rt(e) {
    return !M(e) || V(e).position === "fixed" ? null : e.offsetParent
}

function Zt(e) {
    var t = /firefox/i.test(Le()),
        r = /Trident/i.test(Le());
    if (r && M(e)) {
        var n = V(e);
        if (n.position === "fixed") return null
    }
    var a = Ae(e);
    for (We(a) && (a = a.host); M(a) && ["html", "body"].indexOf(N(a)) < 0;) {
        var s = V(a);
        if (s.transform !== "none" || s.perspective !== "none" || s.contain === "paint" || ["transform", "perspective"].indexOf(s.willChange) !== -1 || t && s.willChange === "filter" || t && s.filter && s.filter !== "none") return a;
        a = a.parentNode
    }
    return null
}

function ue(e) {
    for (var t = T(e), r = rt(e); r && Qt(r) && V(r).position === "static";) r = rt(r);
    return r && (N(r) === "html" || N(r) === "body" && V(r).position === "static") ? t : r || Zt(e) || t
}
var j = "top",
    R = "bottom",
    W = "right",
    B = "left",
    Fe = "auto",
    le = [j, R, W, B],
    te = "start",
    fe = "end",
    _t = "clippingParents",
    ht = "viewport",
    oe = "popper",
    er = "reference",
    nt = le.reduce(function(e, t) {
        return e.concat([t + "-" + te, t + "-" + fe])
    }, []),
    yt = [].concat(le, [Fe]).reduce(function(e, t) {
        return e.concat([t, t + "-" + te, t + "-" + fe])
    }, []),
    tr = "beforeRead",
    rr = "read",
    nr = "afterRead",
    ar = "beforeMain",
    or = "main",
    ir = "afterMain",
    sr = "beforeWrite",
    fr = "write",
    ur = "afterWrite",
    lr = [tr, rr, nr, ar, or, ir, sr, fr, ur];

function pr(e) {
    var t = new Map,
        r = new Set,
        n = [];
    e.forEach(function(s) {
        t.set(s.name, s)
    });

    function a(s) {
        r.add(s.name);
        var f = [].concat(s.requires || [], s.requiresIfExists || []);
        f.forEach(function(o) {
            if (!r.has(o)) {
                var i = t.get(o);
                i && a(i)
            }
        }), n.push(s)
    }
    return e.forEach(function(s) {
        r.has(s.name) || a(s)
    }), n
}

function cr(e) {
    var t = pr(e);
    return lr.reduce(function(r, n) {
        return r.concat(t.filter(function(a) {
            return a.phase === n
        }))
    }, [])
}

function dr(e) {
    var t;
    return function() {
        return t || (t = new Promise(function(r) {
            Promise.resolve().then(function() {
                t = void 0, r(e())
            })
        })), t
    }
}

function vr(e) {
    var t = e.reduce(function(r, n) {
        var a = r[n.name];
        return r[n.name] = a ? Object.assign({}, a, n, {
            options: Object.assign({}, a.options, n.options),
            data: Object.assign({}, a.data, n.data)
        }) : n, r
    }, {});
    return Object.keys(t).map(function(r) {
        return t[r]
    })
}

function mr(e, t) {
    var r = T(e),
        n = F(e),
        a = r.visualViewport,
        s = n.clientWidth,
        f = n.clientHeight,
        o = 0,
        i = 0;
    if (a) {
        s = a.width, f = a.height;
        var l = mt();
        (l || !l && t === "fixed") && (o = a.offsetLeft, i = a.offsetTop)
    }
    return {
        width: s,
        height: f,
        x: o + Ne(e),
        y: i
    }
}

function gr(e) {
    var t, r = F(e),
        n = He(e),
        a = (t = e.ownerDocument) == null ? void 0 : t.body,
        s = K(r.scrollWidth, r.clientWidth, a ? a.scrollWidth : 0, a ? a.clientWidth : 0),
        f = K(r.scrollHeight, r.clientHeight, a ? a.scrollHeight : 0, a ? a.clientHeight : 0),
        o = -n.scrollLeft + Ne(e),
        i = -n.scrollTop;
    return V(a || r).direction === "rtl" && (o += K(r.clientWidth, a ? a.clientWidth : 0) - s), {
        width: s,
        height: f,
        x: o,
        y: i
    }
}

function bt(e, t) {
    var r = t.getRootNode && t.getRootNode();
    if (e.contains(t)) return !0;
    if (r && We(r)) {
        var n = t;
        do {
            if (n && e.isSameNode(n)) return !0;
            n = n.parentNode || n.host
        } while (n)
    }
    return !1
}

function Re(e) {
    return Object.assign({}, e, {
        left: e.x,
        top: e.y,
        right: e.x + e.width,
        bottom: e.y + e.height
    })
}

function hr(e, t) {
    var r = ee(e, !1, t === "fixed");
    return r.top = r.top + e.clientTop, r.left = r.left + e.clientLeft, r.bottom = r.top + e.clientHeight, r.right = r.left + e.clientWidth, r.width = e.clientWidth, r.height = e.clientHeight, r.x = r.left, r.y = r.top, r
}

function at(e, t, r) {
    return t === ht ? Re(mr(e, r)) : G(t) ? hr(t, r) : Re(gr(F(e)))
}

function yr(e) {
    var t = ie(Ae(e)),
        r = ["absolute", "fixed"].indexOf(V(e).position) >= 0,
        n = r && M(e) ? ue(e) : e;
    return G(n) ? t.filter(function(a) {
        return G(a) && bt(a, n) && N(a) !== "body"
    }) : []
}

function br(e, t, r, n) {
    var a = t === "clippingParents" ? yr(e) : [].concat(t),
        s = [].concat(a, [r]),
        f = s[0],
        o = s.reduce(function(i, l) {
            var u = at(e, l, n);
            return i.top = K(u.top, i.top), i.right = Oe(u.right, i.right), i.bottom = Oe(u.bottom, i.bottom), i.left = K(u.left, i.left), i
        }, at(e, f, n));
    return o.width = o.right - o.left, o.height = o.bottom - o.top, o.x = o.left, o.y = o.top, o
}

function H(e) {
    return e.split("-")[0]
}

function re(e) {
    return e.split("-")[1]
}

function qe(e) {
    return ["top", "bottom"].indexOf(e) >= 0 ? "x" : "y"
}

function wt(e) {
    var t = e.reference,
        r = e.element,
        n = e.placement,
        a = n ? H(n) : null,
        s = n ? re(n) : null,
        f = t.x + t.width / 2 - r.width / 2,
        o = t.y + t.height / 2 - r.height / 2,
        i;
    switch (a) {
        case j:
            i = {
                x: f,
                y: t.y - r.height
            };
            break;
        case R:
            i = {
                x: f,
                y: t.y + t.height
            };
            break;
        case W:
            i = {
                x: t.x + t.width,
                y: o
            };
            break;
        case B:
            i = {
                x: t.x - r.width,
                y: o
            };
            break;
        default:
            i = {
                x: t.x,
                y: t.y
            }
    }
    var l = a ? qe(a) : null;
    if (l != null) {
        var u = l === "y" ? "height" : "width";
        switch (s) {
            case te:
                i[l] = i[l] - (t[u] / 2 - r[u] / 2);
                break;
            case fe:
                i[l] = i[l] + (t[u] / 2 - r[u] / 2);
                break
        }
    }
    return i
}

function xt() {
    return {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    }
}

function Ot(e) {
    return Object.assign({}, xt(), e)
}

function At(e, t) {
    return t.reduce(function(r, n) {
        return r[n] = e, r
    }, {})
}

function Ie(e, t) {
    t === void 0 && (t = {});
    var r = t,
        n = r.placement,
        a = n === void 0 ? e.placement : n,
        s = r.strategy,
        f = s === void 0 ? e.strategy : s,
        o = r.boundary,
        i = o === void 0 ? _t : o,
        l = r.rootBoundary,
        u = l === void 0 ? ht : l,
        v = r.elementContext,
        g = v === void 0 ? oe : v,
        p = r.altBoundary,
        h = p === void 0 ? !1 : p,
        m = r.padding,
        d = m === void 0 ? 0 : m,
        y = Ot(typeof d != "number" ? d : At(d, le)),
        x = g === oe ? er : oe,
        A = e.rects.popper,
        c = e.elements[h ? x : g],
        b = br(G(c) ? c : c.contextElement || F(e.elements.popper), i, u, f),
        w = ee(e.elements.reference),
        O = wt({
            reference: w,
            element: A,
            strategy: "absolute",
            placement: a
        }),
        $ = Re(Object.assign({}, A, O)),
        E = g === oe ? $ : w,
        k = {
            top: b.top - E.top + y.top,
            bottom: E.bottom - b.bottom + y.bottom,
            left: b.left - E.left + y.left,
            right: E.right - b.right + y.right
        },
        C = e.modifiersData.offset;
    if (g === oe && C) {
        var S = C[a];
        Object.keys(k).forEach(function(D) {
            var q = [W, R].indexOf(D) >= 0 ? 1 : -1,
                I = [j, R].indexOf(D) >= 0 ? "y" : "x";
            k[D] += S[I] * q
        })
    }
    return k
}
var ot = {
    placement: "bottom",
    modifiers: [],
    strategy: "absolute"
};

function it() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return !t.some(function(n) {
        return !(n && typeof n.getBoundingClientRect == "function")
    })
}

function wr(e) {
    e === void 0 && (e = {});
    var t = e,
        r = t.defaultModifiers,
        n = r === void 0 ? [] : r,
        a = t.defaultOptions,
        s = a === void 0 ? ot : a;
    return function(o, i, l) {
        l === void 0 && (l = s);
        var u = {
                placement: "bottom",
                orderedModifiers: [],
                options: Object.assign({}, ot, s),
                modifiersData: {},
                elements: {
                    reference: o,
                    popper: i
                },
                attributes: {},
                styles: {}
            },
            v = [],
            g = !1,
            p = {
                state: u,
                setOptions: function(y) {
                    var x = typeof y == "function" ? y(u.options) : y;
                    m(), u.options = Object.assign({}, s, u.options, x), u.scrollParents = {
                        reference: G(o) ? ie(o) : o.contextElement ? ie(o.contextElement) : [],
                        popper: ie(i)
                    };
                    var A = cr(vr([].concat(n, u.options.modifiers)));
                    return u.orderedModifiers = A.filter(function(c) {
                        return c.enabled
                    }), h(), p.update()
                },
                forceUpdate: function() {
                    if (!g) {
                        var y = u.elements,
                            x = y.reference,
                            A = y.popper;
                        if (it(x, A)) {
                            u.rects = {
                                reference: Gt(x, ue(A), u.options.strategy === "fixed"),
                                popper: ze(A)
                            }, u.reset = !1, u.placement = u.options.placement, u.orderedModifiers.forEach(function(k) {
                                return u.modifiersData[k.name] = Object.assign({}, k.data)
                            });
                            for (var c = 0; c < u.orderedModifiers.length; c++) {
                                if (u.reset === !0) {
                                    u.reset = !1, c = -1;
                                    continue
                                }
                                var b = u.orderedModifiers[c],
                                    w = b.fn,
                                    O = b.options,
                                    $ = O === void 0 ? {} : O,
                                    E = b.name;
                                typeof w == "function" && (u = w({
                                    state: u,
                                    options: $,
                                    name: E,
                                    instance: p
                                }) || u)
                            }
                        }
                    }
                },
                update: dr(function() {
                    return new Promise(function(d) {
                        p.forceUpdate(), d(u)
                    })
                }),
                destroy: function() {
                    m(), g = !0
                }
            };
        if (!it(o, i)) return p;
        p.setOptions(l).then(function(d) {
            !g && l.onFirstUpdate && l.onFirstUpdate(d)
        });

        function h() {
            u.orderedModifiers.forEach(function(d) {
                var y = d.name,
                    x = d.options,
                    A = x === void 0 ? {} : x,
                    c = d.effect;
                if (typeof c == "function") {
                    var b = c({
                            state: u,
                            name: y,
                            instance: p,
                            options: A
                        }),
                        w = function() {};
                    v.push(b || w)
                }
            })
        }

        function m() {
            v.forEach(function(d) {
                return d()
            }), v = []
        }
        return p
    }
}
var he = {
    passive: !0
};

function xr(e) {
    var t = e.state,
        r = e.instance,
        n = e.options,
        a = n.scroll,
        s = a === void 0 ? !0 : a,
        f = n.resize,
        o = f === void 0 ? !0 : f,
        i = T(t.elements.popper),
        l = [].concat(t.scrollParents.reference, t.scrollParents.popper);
    return s && l.forEach(function(u) {
            u.addEventListener("scroll", r.update, he)
        }), o && i.addEventListener("resize", r.update, he),
        function() {
            s && l.forEach(function(u) {
                u.removeEventListener("scroll", r.update, he)
            }), o && i.removeEventListener("resize", r.update, he)
        }
}
const kt = {
    name: "eventListeners",
    enabled: !0,
    phase: "write",
    fn: function() {},
    effect: xr,
    data: {}
};

function Or(e) {
    var t = e.state,
        r = e.name;
    t.modifiersData[r] = wt({
        reference: t.rects.reference,
        element: t.rects.popper,
        strategy: "absolute",
        placement: t.placement
    })
}
const Ar = {
    name: "popperOffsets",
    enabled: !0,
    phase: "read",
    fn: Or,
    data: {}
};
var kr = {
    top: "auto",
    right: "auto",
    bottom: "auto",
    left: "auto"
};

function Er(e, t) {
    var r = e.x,
        n = e.y,
        a = t.devicePixelRatio || 1;
    return {
        x: _(r * a) / a || 0,
        y: _(n * a) / a || 0
    }
}

function st(e) {
    var t, r = e.popper,
        n = e.popperRect,
        a = e.placement,
        s = e.variation,
        f = e.offsets,
        o = e.position,
        i = e.gpuAcceleration,
        l = e.adaptive,
        u = e.roundOffsets,
        v = e.isFixed,
        g = f.x,
        p = g === void 0 ? 0 : g,
        h = f.y,
        m = h === void 0 ? 0 : h,
        d = typeof u == "function" ? u({
            x: p,
            y: m
        }) : {
            x: p,
            y: m
        };
    p = d.x, m = d.y;
    var y = f.hasOwnProperty("x"),
        x = f.hasOwnProperty("y"),
        A = B,
        c = j,
        b = window;
    if (l) {
        var w = ue(r),
            O = "clientHeight",
            $ = "clientWidth";
        if (w === T(r) && (w = F(r), V(w).position !== "static" && o === "absolute" && (O = "scrollHeight", $ = "scrollWidth")), w = w, a === j || (a === B || a === W) && s === fe) {
            c = R;
            var E = v && w === b && b.visualViewport ? b.visualViewport.height : w[O];
            m -= E - n.height, m *= i ? 1 : -1
        }
        if (a === B || (a === j || a === R) && s === fe) {
            A = W;
            var k = v && w === b && b.visualViewport ? b.visualViewport.width : w[$];
            p -= k - n.width, p *= i ? 1 : -1
        }
    }
    var C = Object.assign({
            position: o
        }, l && kr),
        S = u === !0 ? Er({
            x: p,
            y: m
        }, T(r)) : {
            x: p,
            y: m
        };
    if (p = S.x, m = S.y, i) {
        var D;
        return Object.assign({}, C, (D = {}, D[c] = x ? "0" : "", D[A] = y ? "0" : "", D.transform = (b.devicePixelRatio || 1) <= 1 ? "translate(" + p + "px, " + m + "px)" : "translate3d(" + p + "px, " + m + "px, 0)", D))
    }
    return Object.assign({}, C, (t = {}, t[c] = x ? m + "px" : "", t[A] = y ? p + "px" : "", t.transform = "", t))
}

function $r(e) {
    var t = e.state,
        r = e.options,
        n = r.gpuAcceleration,
        a = n === void 0 ? !0 : n,
        s = r.adaptive,
        f = s === void 0 ? !0 : s,
        o = r.roundOffsets,
        i = o === void 0 ? !0 : o,
        l = {
            placement: H(t.placement),
            variation: re(t.placement),
            popper: t.elements.popper,
            popperRect: t.rects.popper,
            gpuAcceleration: a,
            isFixed: t.options.strategy === "fixed"
        };
    t.modifiersData.popperOffsets != null && (t.styles.popper = Object.assign({}, t.styles.popper, st(Object.assign({}, l, {
        offsets: t.modifiersData.popperOffsets,
        position: t.options.strategy,
        adaptive: f,
        roundOffsets: i
    })))), t.modifiersData.arrow != null && (t.styles.arrow = Object.assign({}, t.styles.arrow, st(Object.assign({}, l, {
        offsets: t.modifiersData.arrow,
        position: "absolute",
        adaptive: !1,
        roundOffsets: i
    })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
        "data-popper-placement": t.placement
    })
}
const Et = {
    name: "computeStyles",
    enabled: !0,
    phase: "beforeWrite",
    fn: $r,
    data: {}
};

function Cr(e) {
    var t = e.state;
    Object.keys(t.elements).forEach(function(r) {
        var n = t.styles[r] || {},
            a = t.attributes[r] || {},
            s = t.elements[r];
        !M(s) || !N(s) || (Object.assign(s.style, n), Object.keys(a).forEach(function(f) {
            var o = a[f];
            o === !1 ? s.removeAttribute(f) : s.setAttribute(f, o === !0 ? "" : o)
        }))
    })
}

function Dr(e) {
    var t = e.state,
        r = {
            popper: {
                position: t.options.strategy,
                left: "0",
                top: "0",
                margin: "0"
            },
            arrow: {
                position: "absolute"
            },
            reference: {}
        };
    return Object.assign(t.elements.popper.style, r.popper), t.styles = r, t.elements.arrow && Object.assign(t.elements.arrow.style, r.arrow),
        function() {
            Object.keys(t.elements).forEach(function(n) {
                var a = t.elements[n],
                    s = t.attributes[n] || {},
                    f = Object.keys(t.styles.hasOwnProperty(n) ? t.styles[n] : r[n]),
                    o = f.reduce(function(i, l) {
                        return i[l] = "", i
                    }, {});
                !M(a) || !N(a) || (Object.assign(a.style, o), Object.keys(s).forEach(function(i) {
                    a.removeAttribute(i)
                }))
            })
        }
}
const Pr = {
    name: "applyStyles",
    enabled: !0,
    phase: "write",
    fn: Cr,
    effect: Dr,
    requires: ["computeStyles"]
};
var jr = [kt, Ar, Et, Pr],
    Br = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };

function we(e) {
    return e.replace(/left|right|bottom|top/g, function(t) {
        return Br[t]
    })
}
var Tr = {
    start: "end",
    end: "start"
};

function ft(e) {
    return e.replace(/start|end/g, function(t) {
        return Tr[t]
    })
}

function Mr(e, t) {
    t === void 0 && (t = {});
    var r = t,
        n = r.placement,
        a = r.boundary,
        s = r.rootBoundary,
        f = r.padding,
        o = r.flipVariations,
        i = r.allowedAutoPlacements,
        l = i === void 0 ? yt : i,
        u = re(n),
        v = u ? o ? nt : nt.filter(function(h) {
            return re(h) === u
        }) : le,
        g = v.filter(function(h) {
            return l.indexOf(h) >= 0
        });
    g.length === 0 && (g = v);
    var p = g.reduce(function(h, m) {
        return h[m] = Ie(e, {
            placement: m,
            boundary: a,
            rootBoundary: s,
            padding: f
        })[H(m)], h
    }, {});
    return Object.keys(p).sort(function(h, m) {
        return p[h] - p[m]
    })
}

function Sr(e) {
    if (H(e) === Fe) return [];
    var t = we(e);
    return [ft(e), t, ft(t)]
}

function Lr(e) {
    var t = e.state,
        r = e.options,
        n = e.name;
    if (!t.modifiersData[n]._skip) {
        for (var a = r.mainAxis, s = a === void 0 ? !0 : a, f = r.altAxis, o = f === void 0 ? !0 : f, i = r.fallbackPlacements, l = r.padding, u = r.boundary, v = r.rootBoundary, g = r.altBoundary, p = r.flipVariations, h = p === void 0 ? !0 : p, m = r.allowedAutoPlacements, d = t.options.placement, y = H(d), x = y === d, A = i || (x || !h ? [we(d)] : Sr(d)), c = [d].concat(A).reduce(function(Q, z) {
                return Q.concat(H(z) === Fe ? Mr(t, {
                    placement: z,
                    boundary: u,
                    rootBoundary: v,
                    padding: l,
                    flipVariations: h,
                    allowedAutoPlacements: m
                }) : z)
            }, []), b = t.rects.reference, w = t.rects.popper, O = new Map, $ = !0, E = c[0], k = 0; k < c.length; k++) {
            var C = c[k],
                S = H(C),
                D = re(C) === te,
                q = [j, R].indexOf(S) >= 0,
                I = q ? "width" : "height",
                P = Ie(t, {
                    placement: C,
                    boundary: u,
                    rootBoundary: v,
                    altBoundary: g,
                    padding: l
                }),
                L = q ? D ? W : B : D ? R : j;
            b[I] > w[I] && (L = we(L));
            var pe = we(L),
                U = [];
            if (s && U.push(P[S] <= 0), o && U.push(P[L] <= 0, P[pe] <= 0), U.every(function(Q) {
                    return Q
                })) {
                E = C, $ = !1;
                break
            }
            O.set(C, U)
        }
        if ($)
            for (var ce = h ? 3 : 1, ke = function(z) {
                    var ae = c.find(function(ve) {
                        var X = O.get(ve);
                        if (X) return X.slice(0, z).every(function(Ee) {
                            return Ee
                        })
                    });
                    if (ae) return E = ae, "break"
                }, ne = ce; ne > 0; ne--) {
                var de = ke(ne);
                if (de === "break") break
            }
        t.placement !== E && (t.modifiersData[n]._skip = !0, t.placement = E, t.reset = !0)
    }
}
const Rr = {
    name: "flip",
    enabled: !0,
    phase: "main",
    fn: Lr,
    requiresIfExists: ["offset"],
    data: {
        _skip: !1
    }
};

function Wr(e, t, r) {
    var n = H(e),
        a = [B, j].indexOf(n) >= 0 ? -1 : 1,
        s = typeof r == "function" ? r(Object.assign({}, t, {
            placement: e
        })) : r,
        f = s[0],
        o = s[1];
    return f = f || 0, o = (o || 0) * a, [B, W].indexOf(n) >= 0 ? {
        x: o,
        y: f
    } : {
        x: f,
        y: o
    }
}

function Hr(e) {
    var t = e.state,
        r = e.options,
        n = e.name,
        a = r.offset,
        s = a === void 0 ? [0, 0] : a,
        f = yt.reduce(function(u, v) {
            return u[v] = Wr(v, t.rects, s), u
        }, {}),
        o = f[t.placement],
        i = o.x,
        l = o.y;
    t.modifiersData.popperOffsets != null && (t.modifiersData.popperOffsets.x += i, t.modifiersData.popperOffsets.y += l), t.modifiersData[n] = f
}
const Nr = {
    name: "offset",
    enabled: !0,
    phase: "main",
    requires: ["popperOffsets"],
    fn: Hr
};

function Vr(e) {
    return e === "x" ? "y" : "x"
}

function se(e, t, r) {
    return K(e, Oe(t, r))
}

function zr(e, t, r) {
    var n = se(e, t, r);
    return n > r ? r : n
}

function Fr(e) {
    var t = e.state,
        r = e.options,
        n = e.name,
        a = r.mainAxis,
        s = a === void 0 ? !0 : a,
        f = r.altAxis,
        o = f === void 0 ? !1 : f,
        i = r.boundary,
        l = r.rootBoundary,
        u = r.altBoundary,
        v = r.padding,
        g = r.tether,
        p = g === void 0 ? !0 : g,
        h = r.tetherOffset,
        m = h === void 0 ? 0 : h,
        d = Ie(t, {
            boundary: i,
            rootBoundary: l,
            padding: v,
            altBoundary: u
        }),
        y = H(t.placement),
        x = re(t.placement),
        A = !x,
        c = qe(y),
        b = Vr(c),
        w = t.modifiersData.popperOffsets,
        O = t.rects.reference,
        $ = t.rects.popper,
        E = typeof m == "function" ? m(Object.assign({}, t.rects, {
            placement: t.placement
        })) : m,
        k = typeof E == "number" ? {
            mainAxis: E,
            altAxis: E
        } : Object.assign({
            mainAxis: 0,
            altAxis: 0
        }, E),
        C = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null,
        S = {
            x: 0,
            y: 0
        };
    if (w) {
        if (s) {
            var D, q = c === "y" ? j : B,
                I = c === "y" ? R : W,
                P = c === "y" ? "height" : "width",
                L = w[c],
                pe = L + d[q],
                U = L - d[I],
                ce = p ? -$[P] / 2 : 0,
                ke = x === te ? O[P] : $[P],
                ne = x === te ? -$[P] : -O[P],
                de = t.elements.arrow,
                Q = p && de ? ze(de) : {
                    width: 0,
                    height: 0
                },
                z = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : xt(),
                ae = z[q],
                ve = z[I],
                X = se(0, O[P], Q[P]),
                Ee = A ? O[P] / 2 - ce - X - ae - k.mainAxis : ke - X - ae - k.mainAxis,
                $t = A ? -O[P] / 2 + ce + X + ve + k.mainAxis : ne + X + ve + k.mainAxis,
                $e = t.elements.arrow && ue(t.elements.arrow),
                Ct = $e ? c === "y" ? $e.clientTop || 0 : $e.clientLeft || 0 : 0,
                Ue = (D = C == null ? void 0 : C[c]) != null ? D : 0,
                Dt = L + Ee - Ue - Ct,
                Pt = L + $t - Ue,
                Xe = se(p ? Oe(pe, Dt) : pe, L, p ? K(U, Pt) : U);
            w[c] = Xe, S[c] = Xe - L
        }
        if (o) {
            var Ye, jt = c === "x" ? j : B,
                Bt = c === "x" ? R : W,
                Y = w[b],
                me = b === "y" ? "height" : "width",
                Je = Y + d[jt],
                Ke = Y - d[Bt],
                Ce = [j, B].indexOf(y) !== -1,
                Ge = (Ye = C == null ? void 0 : C[b]) != null ? Ye : 0,
                Qe = Ce ? Je : Y - O[me] - $[me] - Ge + k.altAxis,
                Ze = Ce ? Y + O[me] + $[me] - Ge - k.altAxis : Ke,
                _e = p && Ce ? zr(Qe, Y, Ze) : se(p ? Qe : Je, Y, p ? Ze : Ke);
            w[b] = _e, S[b] = _e - Y
        }
        t.modifiersData[n] = S
    }
}
const qr = {
    name: "preventOverflow",
    enabled: !0,
    phase: "main",
    fn: Fr,
    requiresIfExists: ["offset"]
};
var Ir = function(t, r) {
    return t = typeof t == "function" ? t(Object.assign({}, r.rects, {
        placement: r.placement
    })) : t, Ot(typeof t != "number" ? t : At(t, le))
};

function Ur(e) {
    var t, r = e.state,
        n = e.name,
        a = e.options,
        s = r.elements.arrow,
        f = r.modifiersData.popperOffsets,
        o = H(r.placement),
        i = qe(o),
        l = [B, W].indexOf(o) >= 0,
        u = l ? "height" : "width";
    if (!(!s || !f)) {
        var v = Ir(a.padding, r),
            g = ze(s),
            p = i === "y" ? j : B,
            h = i === "y" ? R : W,
            m = r.rects.reference[u] + r.rects.reference[i] - f[i] - r.rects.popper[u],
            d = f[i] - r.rects.reference[i],
            y = ue(s),
            x = y ? i === "y" ? y.clientHeight || 0 : y.clientWidth || 0 : 0,
            A = m / 2 - d / 2,
            c = v[p],
            b = x - g[u] - v[h],
            w = x / 2 - g[u] / 2 + A,
            O = se(c, w, b),
            $ = i;
        r.modifiersData[n] = (t = {}, t[$] = O, t.centerOffset = O - w, t)
    }
}

function Xr(e) {
    var t = e.state,
        r = e.options,
        n = r.element,
        a = n === void 0 ? "[data-popper-arrow]" : n;
    a != null && (typeof a == "string" && (a = t.elements.popper.querySelector(a), !a) || bt(t.elements.popper, a) && (t.elements.arrow = a))
}
const Yr = {
        name: "arrow",
        enabled: !0,
        phase: "main",
        fn: Ur,
        effect: Xr,
        requires: ["popperOffsets"],
        requiresIfExists: ["preventOverflow"]
    },
    Jr = wr({
        defaultModifiers: [...jr, Nr, Rr, qr, Et, kt, Yr]
    });

function Kr({
    locked: e = !1,
    overflowPadding: t = 8,
    offsetDistance: r = 8,
    offsetSkid: n = 0,
    gpuAcceleration: a = !0,
    adaptive: s = !0,
    scroll: f = !0,
    resize: o = !0,
    arrow: i = !1,
    placement: l,
    strategy: u
}, v) {
    const g = be(null),
        p = be(null),
        h = be(null);
    return Lt(() => {
        Rt(m => {
            if (!p.value || !g.value && !(v != null && v.value)) return;
            const d = et(p),
                y = (v == null ? void 0 : v.value) || et(g);
            if (!(d instanceof HTMLElement) || !y) return;
            const x = {
                modifiers: [{
                    name: "flip",
                    enabled: !e
                }, {
                    name: "preventOverflow",
                    options: {
                        padding: t
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: [n, r]
                    }
                }, {
                    name: "computeStyles",
                    options: {
                        adaptive: s,
                        gpuAcceleration: a
                    }
                }, {
                    name: "eventListeners",
                    options: {
                        scroll: f,
                        resize: o
                    }
                }, {
                    name: "arrow",
                    enabled: i
                }]
            };
            l && (x.placement = l), u && (x.strategy = u), h.value = Jr(y, d, x), m(h.value.destroy)
        })
    }), [g, p, h]
}
const Gr = ut(xe.ui.strategy, xe.ui.tooltip, It),
    Qr = pt({
        components: {
            UKbd: vt
        },
        inheritAttrs: !1,
        props: {
            text: {
                type: String,
                default: null
            },
            prevent: {
                type: Boolean,
                default: !1
            },
            shortcuts: {
                type: Array,
                default: () => []
            },
            openDelay: {
                type: Number,
                default: 0
            },
            closeDelay: {
                type: Number,
                default: 0
            },
            popper: {
                type: Object,
                default: () => ({})
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: r
            } = ct("tooltip", je(e, "ui"), Gr, je(e, "class")), n = dt(() => Wt({}, e.popper, t.value.popper)), [a, s] = Kr(n.value), f = be(!1);
            let o = null,
                i = null;

            function l() {
                i && (clearTimeout(i), i = null), !f.value && (o = o || setTimeout(() => {
                    f.value = !0, o = null
                }, e.openDelay))
            }

            function u() {
                o && (clearTimeout(o), o = null), f.value && (i = i || setTimeout(() => {
                    f.value = !1, i = null
                }, e.closeDelay))
            }
            return {
                ui: t,
                attrs: r,
                popper: n,
                trigger: a,
                container: s,
                open: f,
                onMouseOver: l,
                onMouseLeave: u
            }
        }
    }),
    Zr = Se("span", {
        class: "mx-1 text-gray-700 dark:text-gray-200"
    }, "·", -1);

function _r(e, t, r, n, a, s) {
    const f = vt;
    return J(), Z("div", Me({
        ref: "trigger",
        class: e.ui.wrapper
    }, e.attrs, {
        onMouseover: t[0] || (t[0] = (...o) => e.onMouseOver && e.onMouseOver(...o)),
        onMouseleave: t[1] || (t[1] = (...o) => e.onMouseLeave && e.onMouseLeave(...o))
    }), [Be(e.$slots, "default", {
        open: e.open
    }, () => [ye(" Hover ")]), e.open && !e.prevent ? (J(), Z("div", {
        key: 0,
        ref: "container",
        class: ge([e.ui.container, e.ui.width])
    }, [Ht(Ft, Me({
        appear: ""
    }, e.ui.transition), {
        default: tt(() => {
            var o;
            return [Se("div", null, [e.popper.arrow ? (J(), Z("div", {
                key: 0,
                "data-popper-arrow": "",
                class: ge(["invisible before:visible before:block before:rotate-45 before:z-[-1]", Object.values(e.ui.arrow)])
            }, null, 2)) : De("", !0), Se("div", {
                class: ge([e.ui.base, e.ui.background, e.ui.color, e.ui.rounded, e.ui.shadow, e.ui.ring])
            }, [Be(e.$slots, "text", {}, () => [ye(Te(e.text), 1)]), (o = e.shortcuts) != null && o.length ? (J(), Z("span", {
                key: 0,
                class: ge(e.ui.shortcuts)
            }, [Zr, (J(!0), Z(Nt, null, Vt(e.shortcuts, i => (J(), zt(f, {
                key: i,
                size: "xs"
            }, {
                default: tt(() => [ye(Te(i), 1)]),
                _: 2
            }, 1024))), 128))], 2)) : De("", !0)], 2)])]
        }),
        _: 3
    }, 16)], 2)) : De("", !0)], 16)
}
const tn = lt(Qr, [
    ["render", _r]
]);
export {
    tn as _, vt as a, Kr as u
};