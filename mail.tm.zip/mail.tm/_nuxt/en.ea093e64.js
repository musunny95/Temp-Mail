const t = {
    home: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Temp Mail - Secure, Instant, Fast"
            }
        },
        content_title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Temp Mail"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Feel free to use temporary email to register on dubious sites, forums or social networks. Protect your personal email address from spam."
            }
        },
        content: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Protect your personal email address from spam, bots, phishing and other online abuse. Temporary email address - no commitments and no risks. No strings attached, just security guaranteed. Temp mail lets you communicate without exposing your personal email to potential threats."
            }
        },
        content2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Our platform provides temporary, anonymous email addresses, guaranteeing zero commitments and absolute security. "
            }
        },
        feature_a_title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Secure"
            }
        },
        feature_a_desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Your email address is protected by a reliable password, generated randomly in your browser, providing a barrier against unauthorized access and potential breaches."
            }
        },
        feature_b_title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Instant"
            }
        },
        feature_b_desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No more wasting precious time on registrations, form-filling, or solving captchas. Your temp email address is ready for use instantly, putting you in control effortlessly."
            }
        },
        feature_c_title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fast"
            }
        },
        feature_c_desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Experience fast message delivery without the hassles of delays or restrictions. Our service is finely tuned for maximum delivery speed, ensuring you stay connected seamlessly."
            }
        }
    },
    feature: {
        back: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Back"
            }
        },
        cancel: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cancel"
            }
        },
        email: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email"
            }
        },
        username: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Username"
            }
        },
        password: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Password"
            }
        },
        copy_it: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Your temporary email address, click to copy!"
            }
        },
        view: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "View"
            }
        },
        previous: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Previous"
            }
        },
        next: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Next"
            }
        },
        signed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You are signed in as"
            }
        },
        copy: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Copy"
            }
        },
        inbox: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Inbox"
            }
        },
        refresh: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Refresh"
            }
        },
        support: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Support us by disabling ad blockеrs on our site"
            }
        },
        language: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Language"
            }
        },
        colorMode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Color Mode"
            }
        },
        dark: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dark"
            }
        },
        light: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Light"
            }
        },
        account: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Account"
            }
        }
    },
    view: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "View message"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Here you can view a message"
            }
        },
        download: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download"
            }
        },
        source: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Source"
            }
        },
        print: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Print"
            }
        },
        delete: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Delete"
            }
        },
        error: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Error"
            }
        },
        404: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Message not found!"
            }
        }
    },
    create: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Create an account"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Create"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Here you can create a new account for this you need to select a username, then domain and password!"
            }
        }
    },
    login: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Log in to your account"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Here you can log in to your account"
            }
        }
    },
    destroy: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Delete account"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Delete"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Are you sure you want to delete your account? All your data will be permanently deleted."
            }
        }
    },
    logout: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sign out from your account"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sign out"
            }
        }
    },
    explanation: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Warning!"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Keep in mind that all accounts have a password attached to them. Please, kindly take a note of your password, it's under the account dropdown (the letter icon next to the logout button). There is no way to reset your password."
            }
        },
        ok: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "OK"
            }
        }
    },
    privacy: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Privacy Policy"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Privacy"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Privacy policy explains what information do we collect and why."
            }
        },
        text_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Information is saved for many years on your conventional e-mail. This may be exposed to hacking or lost due to failure of service. By using ordinary email you are exposed to your personal information being hacked, stolen and misused whether your information is important or not.  If something important on your conventional mailbox is stored, what can you do?"
            }
        },
        text_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Using the temporary mail allows you to completely protect against loss of personal information. Your details: Information about your person and users with whom you communicate, IP-address, e-mail address, are completely confidential. Mail.tm Service does not store your IP-address at all. This means you are protected from all unauthorized actions that may endanger your information and compromise your privacy."
            }
        },
        text_3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'All emails and data temporarily stored on our service are permanently deleted. You can delete your temporary Email address at any time using the appropriate button "Delete" on the home page.'
            }
        },
        text_4: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Your privacy is the highest priority for us. You need not concern yourself about your data. We will provide full protection. Access to your data will only be provided to you personally and only for the lifetime of the temporary email address."
            }
        },
        text_5: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "We care about all our users."
            }
        },
        text_6: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Note:"
            }
        },
        text_7: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Administration of this is site can make changes to this Privacy Policy."
            }
        },
        text_8: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Last edited: 20.08.2022"
            }
        }
    },
    faq: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Frequently Asked Questions"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "FAQ"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Find answers to questions about temporary email service."
            }
        },
        text_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Temporary anonymous email service is specifically designed to protect your privacy. Answers to frequently asked questions will help you to clarify the service offered and to immediately make full use of our convenient and fully secure service."
            }
        },
        q_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "What is a temporary / disposable / anonymous mail?"
            }
        },
        a_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Disposable e-mail is a temporary and completely anonymous email address that does not require any registration."
            }
        },
        q_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Why do you need a temporary email address?"
            }
        },
        a_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "To register on dubious sites without jeopardising your personal data. It is particularly useful for all situations in which your privacy is important."
            }
        },
        q_3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How is it different from usual mail?"
            }
        },
        a_3_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Does not require registration"
            }
        },
        a_3_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "It is completely anonymous: personal data, address itself and emails are deleted after you delete the account"
            }
        },
        a_3_3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Messages are delivered instantly"
            }
        },
        a_3_4: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email address is generated automatically. You do not have to select the available username manually;"
            }
        },
        a_3_5: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The mailbox is protected from spam, hacking, exploits."
            }
        },
        q_4: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How do I send an email?"
            }
        },
        a_4: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Unfortunately, we do not provide this feature."
            }
        },
        q_5: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to extend the life time of temporary mail?"
            }
        },
        a_5: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You don't need to extend anything, your email account is valid until you'll delete it manually."
            }
        },
        q_6: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How long do you store incoming messages?"
            }
        },
        a_6: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "We do store messages for only 7 days. We're sorry, we can't store them indefinitely."
            }
        },
        q_7: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Can I check the received emails?"
            }
        },
        a_7: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Yes, they are displayed under the name of your mailbox."
            }
        },
        q_8: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do you keep and renew your domains used by this service?"
            }
        },
        a_8: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Yes, we do always keep renewing our domains and they won't disappear."
            }
        },
        q_9: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "I forgot my password, is there a way you can reset it?"
            }
        },
        a_9: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No, there is no way we could reset your password. Your password is being generated in your browser, and it's being stored encrypted."
            }
        },
        text_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "We have answered all frequently asked questions about temporary email. If you have any unanswered questions feel free to contact us."
            }
        }
    },
    feedback: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Feedback and comments"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Feedback"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Share your feedback and comments to help us improve temporary email service."
            }
        },
        text_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Temp Mail service is not just a one-off designed project. We strive for perfection, which is known to be impossible, but to approach it, is quite real. Therefore, all your suggestions and comments will not remain just text - we will take everything into account and implement them."
            }
        },
        text_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do you like our anonymous e-mail service? You can suggest our service to other users in a reviews. If you can think of ways to assist us to achieve perfection, your comments will allow our joint efforts to make the service more convenient, user friendly, and meet the needs of other users requiring a temporary email address."
            }
        },
        text_3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do not be indifferent - help us to become better, and we will provide you with the most secure anonymous box and the most comfortable user interface."
            }
        }
    },
    contact: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Contact us"
            }
        },
        short: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Contacts"
            }
        },
        desc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Contact us and give some feedback for disposable email service"
            }
        },
        text_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "If the answers to common questions and a detailed description on the home page about the Temp Mail service do not assist you let us know. Only from your feedback can we provide solutions for other users. If required we will consult with you at any time of the day. We will help to efficiently manage services on offer, to solve problems you may experience in receiving emails in the unlikely event they occur. "
            }
        },
        text_2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "However, we are confident that such issues will not arise. Our Temp Mail Service provides quality service and care for all of its users. Interface online service is totally user-friendly and clearly understood."
            }
        },
        text_3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Anyone can use temporary mail including those who have not previously used disposable email services."
            }
        },
        text_4: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Why choose Temp Mail?"
            }
        },
        text_5: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No fee and registration."
            }
        },
        text_6: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "A completely anonymous email address;"
            }
        },
        text_7: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "There is the possibility of deleting account."
            }
        },
        text_8: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do you have any questions or suggestions ? Please contact us via email. We will be happy to help and will consider all proposals for improving the interface and the mail service."
            }
        }
    }
};
export {
    t as
    default
};