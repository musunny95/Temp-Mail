import {
    N as Ca,
    o as b,
    H as j,
    w as k,
    i as $,
    a as c,
    e as at,
    q as Oe,
    v as P,
    _ as he,
    g as F,
    x as Be,
    y as ne,
    z as h,
    A as q,
    c as S,
    B as L,
    C,
    t as _,
    R as Rt,
    S as $e,
    D as z,
    n as O,
    d as X,
    T as Fe,
    s as Ae,
    U as se,
    b as y,
    r as w,
    F as N,
    V as Ia,
    W as Ea,
    X as At,
    Y as wt,
    Z as Ut,
    $ as Ta,
    a0 as Y,
    I as Q,
    a1 as Z,
    a2 as K,
    a3 as ee,
    a4 as Se,
    a5 as pe,
    a6 as We,
    a7 as Aa,
    a8 as $t,
    a9 as Oa,
    aa as xe,
    l as Ba,
    m as Fa,
    ab as nt,
    ac as Le,
    ad as La,
    ae as Da,
    af as ja,
    E as xt,
    ag as Ht,
    ah as Pa,
    ai as vt,
    J as He,
    j as qt,
    aj as za,
    ak as Na,
    al as Va,
    am as Wt,
    an as Ge,
    ao as Ra,
    ap as Ua,
    aq as Ha,
    M as _t,
    ar as qa,
    as as Wa,
    at as ze,
    au as Zt,
    av as Za,
    u as Ya,
    G as Ka
} from "./entry.43614be6.js";
import {
    _ as St
} from "./client-only.be8c7cca.js";
import {
    _ as je,
    a as Yt,
    u as Ga
} from "./Tooltip.06538c8d.js";
const Ja = {
        wrapper: "w-full flex flex-col gap-2",
        indicator: {
            container: "min-w-fit transition-all",
            text: "text-gray-400 dark:text-gray-500 text-end",
            size: {
                "2xs": "text-xs",
                xs: "text-xs",
                sm: "text-sm",
                md: "text-sm",
                lg: "text-sm",
                xl: "text-base",
                "2xl": "text-base"
            }
        },
        meter: {
            base: "appearance-none block w-full bg-none overflow-y-hidden",
            background: "bg-gray-200 dark:bg-gray-700",
            color: "text-{color}-500 dark:text-{color}-400",
            ring: "",
            rounded: "rounded-full",
            shadow: "",
            size: {
                "2xs": "h-px",
                xs: "h-0.5",
                sm: "h-1",
                md: "h-2",
                lg: "h-3",
                xl: "h-4",
                "2xl": "h-5"
            },
            appearance: {
                inner: "[&::-webkit-meter-inner-element]:block [&::-webkit-meter-inner-element]:relative [&::-webkit-meter-inner-element]:border-none [&::-webkit-meter-inner-element]:bg-none [&::-webkit-meter-inner-element]:bg-transparent",
                meter: "[&::-webkit-meter-bar]:border-none [&::-webkit-meter-bar]:bg-none [&::-webkit-meter-bar]:bg-transparent",
                bar: "[&::-webkit-meter-optimum-value]:border-none [&::-webkit-meter-optimum-value]:bg-none [&::-webkit-meter-optimum-value]:bg-current",
                value: "[&::-moz-meter-bar]:border-none [&::-moz-meter-bar]:bg-none [&::-moz-meter-bar]:bg-current"
            },
            bar: {
                transition: "[&::-webkit-meter-optimum-value]:transition-all [&::-moz-meter-bar]:transition-all",
                ring: "",
                rounded: "[&::-webkit-meter-optimum-value]:rounded-full [&::-moz-meter-bar]:rounded-full",
                size: {
                    "2xs": "[&::-webkit-meter-optimum-value]:h-px [&::-moz-meter-bar]:h-px",
                    xs: "[&::-webkit-meter-optimum-value]:h-0.5 [&::-moz-meter-bar]:h-0.5",
                    sm: "[&::-webkit-meter-optimum-value]:h-1 [&::-moz-meter-bar]:h-1",
                    md: "[&::-webkit-meter-optimum-value]:h-2 [&::-moz-meter-bar]:h-2",
                    lg: "[&::-webkit-meter-optimum-value]:h-3 [&::-moz-meter-bar]:h-3",
                    xl: "[&::-webkit-meter-optimum-value]:h-4 [&::-moz-meter-bar]:h-4",
                    "2xl": "[&::-webkit-meter-optimum-value]:h-5 [&::-moz-meter-bar]:h-5"
                }
            }
        },
        label: {
            base: "flex gap-2 items-center",
            text: "truncate",
            color: "text-{color}-500 dark:text-{color}-400",
            size: {
                "2xs": "text-xs",
                xs: "text-xs",
                sm: "text-sm",
                md: "text-sm",
                lg: "text-sm",
                xl: "text-base",
                "2xl": "text-base"
            }
        },
        color: {
            white: "text-white dark:text-black",
            black: "text-black dark:text-white",
            gray: "text-gray-500 dark:text-gray-400"
        },
        default: {
            size: "md",
            color: "primary"
        }
    },
    Xa = {
        wrapper: "",
        label: {
            wrapper: "flex content-center items-center justify-between",
            base: "block font-medium text-gray-700 dark:text-gray-200",
            required: "after:content-['*'] after:ms-0.5 after:text-red-500 dark:after:text-red-400"
        },
        size: {
            "2xs": "text-xs",
            xs: "text-xs",
            sm: "text-sm",
            md: "text-sm",
            lg: "text-sm",
            xl: "text-base"
        },
        container: "mt-1 relative",
        description: "text-gray-500 dark:text-gray-400",
        hint: "text-gray-500 dark:text-gray-400",
        help: "mt-2 text-gray-500 dark:text-gray-400",
        error: "mt-2 text-red-500 dark:text-red-400",
        default: {
            size: "sm"
        }
    },
    Qa = {
        base: "overflow-hidden",
        background: "bg-white dark:bg-gray-900",
        divide: "divide-y divide-gray-200 dark:divide-gray-800",
        ring: "ring-1 ring-gray-200 dark:ring-gray-800",
        rounded: "rounded-lg",
        shadow: "shadow",
        body: {
            base: "",
            background: "",
            padding: "px-4 py-5 sm:p-6"
        },
        header: {
            base: "",
            background: "",
            padding: "px-4 py-5 sm:px-6"
        },
        footer: {
            base: "",
            background: "",
            padding: "px-4 py-4 sm:px-6"
        }
    },
    en = {
        wrapper: "relative z-50",
        inner: "fixed inset-0 overflow-y-auto",
        container: "flex min-h-full items-end sm:items-center justify-center text-center",
        padding: "p-4 sm:p-0",
        margin: "sm:my-8",
        base: "relative text-left rtl:text-right overflow-hidden w-full flex flex-col",
        overlay: {
            base: "fixed inset-0 transition-opacity",
            background: "bg-gray-200/75 dark:bg-gray-800/75",
            transition: {
                enter: "ease-out duration-300",
                enterFrom: "opacity-0",
                enterTo: "opacity-100",
                leave: "ease-in duration-200",
                leaveFrom: "opacity-100",
                leaveTo: "opacity-0"
            }
        },
        background: "bg-white dark:bg-gray-900",
        ring: "",
        rounded: "rounded-lg",
        shadow: "shadow-xl",
        width: "sm:max-w-lg",
        height: "",
        transition: {
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
            enterTo: "opacity-100 translate-y-0 sm:scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
            leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        }
    };
const tn = c("svg", {
        class: "dark-img h-8",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 147 32"
    }, [c("path", {
        d: "M56.584 8.552c1.835 0 3.296.597 4.384 1.792 1.11 1.195 1.664 2.795 1.664 4.8V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.13-.8-1.984-.8-.939 0-1.675.31-2.208.928-.512.619-.768 1.515-.768 2.688V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.13-.8-1.984-.8-.917 0-1.653.31-2.208.928-.533.619-.8 1.515-.8 2.688V25h-4.128V9h4.128v1.696c.96-1.43 2.443-2.144 4.448-2.144 1.963 0 3.413.768 4.352 2.304 1.067-1.536 2.656-2.304 4.768-2.304ZM78.298 9h4.128v16h-4.128v-1.888c-1.237 1.557-2.976 2.336-5.216 2.336-2.133 0-3.968-.81-5.504-2.432-1.515-1.643-2.272-3.648-2.272-6.016s.757-4.363 2.272-5.984c1.536-1.643 3.37-2.464 5.504-2.464 2.24 0 3.979.779 5.216 2.336V9Zm-7.616 11.264c.832.832 1.888 1.248 3.168 1.248 1.28 0 2.336-.416 3.168-1.248.853-.853 1.28-1.941 1.28-3.264 0-1.323-.427-2.4-1.28-3.232-.832-.853-1.888-1.28-3.168-1.28-1.28 0-2.336.427-3.168 1.28-.832.832-1.248 1.91-1.248 3.232 0 1.323.416 2.41 1.248 3.264ZM88.217 7.08c-.682 0-1.28-.245-1.792-.736-.49-.512-.736-1.11-.736-1.792 0-.683.246-1.28.736-1.792.512-.512 1.11-.768 1.792-.768.704 0 1.302.256 1.792.768.512.512.768 1.11.768 1.792 0 .683-.256 1.28-.768 1.792-.49.49-1.088.736-1.792.736ZM86.17 25V9h4.128v16H86.17Zm7.907 0V1.64h4.128V25h-4.128Zm12.226-.384a2.62 2.62 0 0 1-1.92.8 2.618 2.618 0 0 1-1.92-.8 2.616 2.616 0 0 1-.8-1.92c0-.747.266-1.387.8-1.92a2.618 2.618 0 0 1 1.92-.8 2.62 2.62 0 0 1 1.92.8c.533.533.8 1.173.8 1.92a2.62 2.62 0 0 1-.8 1.92Z",
        fill: "#fff"
    }), c("path", {
        d: "M119.696 12.968h-3.616v6.656c0 .555.139.96.416 1.216.278.256.683.405 1.216.448.534.021 1.195.01 1.984-.032V25c-2.837.32-4.842.053-6.016-.8-1.152-.853-1.728-2.379-1.728-4.576v-6.656h-2.784V9h2.784V5.768l4.128-1.248V9h3.616v3.968Zm20.857-4.416c1.834 0 3.296.597 4.384 1.792 1.109 1.195 1.664 2.795 1.664 4.8V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.131-.8-1.984-.8-.939 0-1.675.31-2.208.928-.512.619-.768 1.515-.768 2.688V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.131-.8-1.984-.8-.918 0-1.654.31-2.208.928-.534.619-.8 1.515-.8 2.688V25h-4.128V9h4.128v1.696c.96-1.43 2.442-2.144 4.448-2.144 1.962 0 3.413.768 4.352 2.304 1.066-1.536 2.656-2.304 4.768-2.304Z",
        fill: "#6875F5"
    }), c("path", {
        "fill-rule": "evenodd",
        "clip-rule": "evenodd",
        d: "M24.486 7.512a12 12 0 1 0-1.972 18.568 2 2 0 1 1 2.174 3.356A16 16 0 1 1 32 15.998a6 6 0 0 1-9.6 4.802 8 8 0 1 1 1.6-4.802 2 2 0 1 0 4 0c0-3.074-1.172-6.14-3.514-8.486ZM20 15.998a4 4 0 1 0-8 0 4 4 0 0 0 8 0Z",
        fill: "#6875F5"
    })], -1),
    an = c("svg", {
        class: "light-img h-8",
        viewBox: "0 0 147 32",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    }, [c("path", {
        d: "M56.584 8.552c1.835 0 3.296.597 4.384 1.792 1.11 1.195 1.664 2.795 1.664 4.8V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.13-.8-1.984-.8-.939 0-1.675.31-2.208.928-.512.619-.768 1.515-.768 2.688V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.13-.8-1.984-.8-.917 0-1.653.31-2.208.928-.533.619-.8 1.515-.8 2.688V25h-4.128V9h4.128v1.696c.96-1.43 2.443-2.144 4.448-2.144 1.963 0 3.413.768 4.352 2.304 1.067-1.536 2.656-2.304 4.768-2.304ZM78.298 9h4.128v16h-4.128v-1.888c-1.237 1.557-2.976 2.336-5.216 2.336-2.133 0-3.968-.81-5.504-2.432-1.515-1.643-2.272-3.648-2.272-6.016s.757-4.363 2.272-5.984c1.536-1.643 3.37-2.464 5.504-2.464 2.24 0 3.979.779 5.216 2.336V9Zm-7.616 11.264c.832.832 1.888 1.248 3.168 1.248 1.28 0 2.336-.416 3.168-1.248.853-.853 1.28-1.941 1.28-3.264 0-1.323-.427-2.4-1.28-3.232-.832-.853-1.888-1.28-3.168-1.28-1.28 0-2.336.427-3.168 1.28-.832.832-1.248 1.91-1.248 3.232 0 1.323.416 2.41 1.248 3.264ZM88.217 7.08c-.682 0-1.28-.245-1.792-.736-.49-.512-.736-1.11-.736-1.792 0-.683.246-1.28.736-1.792.512-.512 1.11-.768 1.792-.768.704 0 1.302.256 1.792.768.512.512.768 1.11.768 1.792 0 .683-.256 1.28-.768 1.792-.49.49-1.088.736-1.792.736ZM86.17 25V9h4.128v16H86.17Zm7.907 0V1.64h4.128V25h-4.128Zm12.226-.384a2.62 2.62 0 0 1-1.92.8 2.618 2.618 0 0 1-1.92-.8 2.616 2.616 0 0 1-.8-1.92c0-.747.266-1.387.8-1.92a2.618 2.618 0 0 1 1.92-.8 2.62 2.62 0 0 1 1.92.8c.533.533.8 1.173.8 1.92a2.62 2.62 0 0 1-.8 1.92Z",
        fill: "#252F3F"
    }), c("path", {
        d: "M119.696 12.968h-3.616v6.656c0 .555.139.96.416 1.216.278.256.683.405 1.216.448.534.021 1.195.01 1.984-.032V25c-2.837.32-4.842.053-6.016-.8-1.152-.853-1.728-2.379-1.728-4.576v-6.656h-2.784V9h2.784V5.768l4.128-1.248V9h3.616v3.968Zm20.857-4.416c1.834 0 3.296.597 4.384 1.792 1.109 1.195 1.664 2.795 1.664 4.8V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.131-.8-1.984-.8-.939 0-1.675.31-2.208.928-.512.619-.768 1.515-.768 2.688V25h-4.128v-9.568c0-.96-.235-1.707-.704-2.24-.47-.533-1.131-.8-1.984-.8-.918 0-1.654.31-2.208.928-.534.619-.8 1.515-.8 2.688V25h-4.128V9h4.128v1.696c.96-1.43 2.442-2.144 4.448-2.144 1.962 0 3.413.768 4.352 2.304 1.066-1.536 2.656-2.304 4.768-2.304Z",
        fill: "#5850EC"
    }), c("path", {
        "fill-rule": "evenodd",
        "clip-rule": "evenodd",
        d: "M24.486 7.512a12 12 0 1 0-1.972 18.568 2 2 0 1 1 2.174 3.356A16 16 0 1 1 32 15.998a6 6 0 0 1-9.6 4.802 8 8 0 1 1 1.6-4.802 2 2 0 1 0 4 0c0-3.074-1.172-6.14-3.514-8.486ZM20 15.998a4 4 0 1 0-8 0 4 4 0 0 0 8 0Z",
        fill: "#5850EC"
    })], -1),
    nn = {
        __name: "Logo",
        setup(e) {
            const t = Ca();
            return (n, a) => {
                const r = at;
                return b(), j(r, {
                    to: $(t)("index"),
                    "aria-label": "Mail.tm"
                }, {
                    default: k(() => [tn, an]),
                    _: 1
                }, 8, ["to"])
            }
        }
    },
    Ne = Oe(P.ui.strategy, P.ui.meter, Ja),
    rn = F({
        inheritAttrs: !1,
        slots: Object,
        props: {
            value: {
                type: Number,
                default: 0
            },
            min: {
                type: Number,
                default: 0
            },
            max: {
                type: Number,
                default: 100
            },
            indicator: {
                type: Boolean,
                default: !1
            },
            label: {
                type: String,
                default: null
            },
            size: {
                type: String,
                default: () => Ne.default.size,
                validator(e) {
                    return Object.keys(Ne.meter.size).includes(e)
                }
            },
            color: {
                type: String,
                default: () => Ne.default.color,
                validator(e) {
                    return [...P.ui.colors, ...Object.keys(Ne.color)].includes(e)
                }
            },
            icon: {
                type: String,
                default: null
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Be("meter", ne(e, "ui"), Ne, ne(e, "class"));

            function a(p, g, v) {
                if (g == v) return p < g ? 0 : 100;
                g > v && (v = [g, g = v][0]);
                const x = (p - g) / (v - g) * 100;
                return Math.max(0, Math.min(100, x))
            }
            const r = h(() => q(t.value.indicator.container)),
                o = h(() => q(t.value.indicator.text, t.value.indicator.size[e.size])),
                l = h(() => q(t.value.meter.base, t.value.meter.background, t.value.meter.ring, t.value.meter.rounded, t.value.meter.shadow, t.value.color[e.color] ? ? t.value.meter.color.replaceAll("{color}", e.color), t.value.meter.size[e.size])),
                s = h(() => q(t.value.meter.appearance.inner, t.value.meter.appearance.meter, t.value.meter.appearance.bar, t.value.meter.appearance.value)),
                u = h(() => q(t.value.meter.bar.transition, t.value.meter.bar.ring, t.value.meter.bar.rounded, t.value.meter.bar.size[e.size])),
                i = h(() => q(t.value.label.base, t.value.label.text, t.value.color[e.color] ? ? t.value.label.color.replaceAll("{color}", e.color), t.value.label.size[e.size])),
                d = h(() => e.min > e.max ? e.max : e.min),
                f = h(() => e.max < e.min ? e.min : e.max),
                m = h(() => a(Number(e.value), d.value, f.value));
            return {
                ui: t,
                attrs: n,
                indicatorContainerClass: r,
                indicatorClass: o,
                meterClass: l,
                meterAppearanceClass: s,
                meterBarClass: u,
                labelClass: i,
                normalizedMin: d,
                normalizedMax: f,
                percent: m
            }
        }
    }),
    on = ["value", "min", "max"];

function ln(e, t, n, a, r, o) {
    const l = Fe;
    return b(), S("div", z({
        class: e.ui.wrapper
    }, e.attrs), [e.indicator || e.$slots.indicator ? L(e.$slots, "indicator", $e(z({
        key: 0
    }, {
        percent: e.percent,
        value: e.value
    })), () => [c("div", {
        class: C(e.indicatorContainerClass),
        style: Rt({
            width: `${e.percent}%`
        })
    }, [c("div", {
        class: C(e.indicatorClass)
    }, _(Math.round(e.percent)) + "% ", 3)], 6)]) : O("", !0), c("meter", {
        value: e.value,
        min: e.normalizedMin,
        max: e.normalizedMax,
        class: C([e.meterClass, e.meterAppearanceClass, e.meterBarClass])
    }, null, 10, on), e.label || e.$slots.label ? L(e.$slots, "label", $e(z({
        key: 1
    }, {
        percent: e.percent,
        value: e.value
    })), () => [c("div", {
        class: C(e.labelClass)
    }, [e.icon ? (b(), j(l, {
        key: 0,
        name: e.icon
    }, null, 8, ["name"])) : O("", !0), X(" " + _(e.label), 1)], 2)]) : O("", !0)], 16)
}
const sn = he(rn, [
        ["render", ln]
    ]),
    un = ["B", "kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
    dn = ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"],
    cn = ["b", "kbit", "Mbit", "Gbit", "Tbit", "Pbit", "Ebit", "Zbit", "Ybit"],
    fn = ["b", "kibit", "Mibit", "Gibit", "Tibit", "Pibit", "Eibit", "Zibit", "Yibit"],
    Ot = (e, t, n) => {
        let a = e;
        return typeof t == "string" || Array.isArray(t) ? a = e.toLocaleString(t, n) : (t === !0 || n !== void 0) && (a = e.toLocaleString(void 0, n)), a
    };

function Bt(e, t) {
    if (!Number.isFinite(e)) throw new TypeError(`Expected a finite number, got ${typeof e}: ${e}`);
    t = {
        bits: !1,
        binary: !1,
        space: !0,
        ...t
    };
    const n = t.bits ? t.binary ? fn : cn : t.binary ? dn : un,
        a = t.space ? " " : "";
    if (t.signed && e === 0) return ` 0${a}${n[0]}`;
    const r = e < 0,
        o = r ? "-" : t.signed ? "+" : "";
    r && (e = -e);
    let l;
    if (t.minimumFractionDigits !== void 0 && (l = {
            minimumFractionDigits: t.minimumFractionDigits
        }), t.maximumFractionDigits !== void 0 && (l = {
            maximumFractionDigits: t.maximumFractionDigits,
            ...l
        }), e < 1) {
        const d = Ot(e, t.locale, l);
        return o + d + a + n[0]
    }
    const s = Math.min(Math.floor(t.binary ? Math.log(e) / Math.log(1024) : Math.log10(e) / 3), n.length - 1);
    e /= (t.binary ? 1024 : 1e3) ** s, l || (e = e.toPrecision(3));
    const u = Ot(Number(e), t.locale, l),
        i = n[s];
    return o + u + a + i
}
const mn = {
        class: "px-3 py-2"
    },
    vn = {
        class: "mt-1 flex items-baseline text-sm"
    },
    gn = {
        class: "leading-5 text-gray-600 divide-y divide-y dark:text-gray-300"
    },
    pn = c("span", {
        class: "mx-2 text-gray-500 dark:text-gray-500"
    }, "/", -1),
    hn = {
        class: "font-medium leading-5 text-gray-500 dark:text-gray-400"
    },
    yn = {
        __name: "Storage",
        setup(e) {
            const {
                session: t
            } = Ae(se()), n = h(() => {
                var a;
                return (a = t.value) != null && a.address ? {
                    quota: t.value.quota,
                    used: t.value.used,
                    quotaPrettyBytes: Bt(t.value.quota),
                    usedPrettyBytes: Bt(t.value.used)
                } : {
                    quota: 0,
                    used: 0,
                    quotaPrettyBytes: "♾️",
                    usedPrettyBytes: "♾️"
                }
            });
            return (a, r) => {
                const o = sn;
                return b(), S("dl", mn, [y(o, {
                    value: $(n).used,
                    max: $(n).quota
                }, {
                    indicator: k(() => [c("dd", vn, [c("span", gn, _($(n).usedPrettyBytes), 1), pn, c("span", hn, _($(n).quotaPrettyBytes), 1)])]),
                    _: 1
                }, 8, ["value", "max"])])
            }
        }
    },
    bn = {
        class: "flex flex-shrink-0 border border-l-0 border-r-0 border-gray-200 p-2 dark:border-gray-700"
    },
    kn = {
        class: "mt-6 md:order-1 md:mt-0"
    },
    wn = {
        class: "flex justify-center md:order-2"
    },
    $n = {
        __name: "Support",
        setup(e) {
            const t = w(null),
                n = w(!0),
                a = w(0);
            N(() => {
                window.freestar.config.enabled_slots.push({
                    placementName: "mail.tm_leftsidebar",
                    slotId: "mail.tm_leftsidebar"
                }), r()
            });

            function r() {
                var o;
                a.value++, ((o = t.value) == null ? void 0 : o.innerHTML.length) > 0 && (n.value = !1), a.value < 20 && setTimeout(r, 7e3)
            }
            return (o, l) => {
                const s = St;
                return b(), S("div", bn, [c("div", kn, [c("div", {
                    class: C(["flex flex-col dark:text-gray-300 text-gray-600 text-sm font-medium leading-6 transition ease-in-out p-4 sm:p-6", $(n) ? "block" : "hidden"])
                }, _(o.$t("feature.support")) + " 🙏 ", 3), c("div", wn, [y(s, null, {
                    default: k(() => [c("div", {
                        id: "mail.tm_leftsidebar",
                        ref_key: "ad",
                        ref: t,
                        align: "center",
                        "data-freestar-ad": "__160x600"
                    }, null, 512)]),
                    _: 1
                })])])])
            }
        }
    },
    xn = {
        class: "flex flex-1"
    },
    _n = {
        class: "w-full flex ring-0 md:ml-0"
    },
    Sn = {
        for: "Dont_use_WEB_use_API",
        class: "sr-only"
    },
    Mn = {
        class: "group relative w-full text-gray-400"
    },
    Cn = {
        class: "pointer-events-none absolute inset-y-0 left-0 flex items-center"
    },
    In = {
        key: 0,
        class: "h-5 w-5 text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-500",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    },
    En = c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
    }, null, -1),
    Tn = [En],
    An = {
        key: 1,
        xmlns: "http://www.w3.org/2000/svg",
        class: "h-5 w-5 text-gray-400 dark:text-indigo-500 group-hover:text-gray-600 dark:group-hover:text-indigo-500",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        "stroke-width": "2"
    },
    On = c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    }, null, -1),
    Bn = [On],
    Fn = ["value"],
    Ln = {
        __name: "Mail",
        setup(e) {
            const {
                copy: t,
                copied: n
            } = Ia({
                legacy: !0
            }), a = w(null);
            let r = null;
            const o = h(() => se().getActive.address ? se().getActive.address : "...");

            function l() {
                try {
                    t(o.value);
                    const u = new Date().getTime();
                    u - r < 5e3 && (n.value = !1), r = u
                } catch {
                    s()
                }
            }

            function s() {
                a.value.focus(), a.value.select()
            }
            return (u, i) => {
                const d = je,
                    f = Ea("motion-pop");
                return b(), S("div", xn, [y(d, {
                    text: u.$t("feature.copy_it"),
                    shortcuts: ["⌘", "C"],
                    ui: {
                        wrapper: "w-full"
                    },
                    popper: {
                        placement: "bottom-start"
                    }
                }, {
                    default: k(() => [c("div", _n, [c("label", Sn, _(u.$t("feature.email")), 1), c("div", Mn, [c("div", Cn, [$(n) ? O("", !0) : At((b(), S("svg", In, Tn)), [
                        [f]
                    ]), $(n) ? At((b(), S("svg", An, Bn)), [
                        [f]
                    ]) : O("", !0)]), c("input", {
                        id: "Dont_use_WEB_use_API",
                        ref_key: "addressInput",
                        ref: a,
                        value: $(o),
                        placeholder: "...",
                        class: C(["block h-full w-full cursor-pointer select-all border-transparent py-2 pl-8 pr-3 text-gray-600 focus:border-transparent dark:bg-gray-900 sm:text-sm dark:text-gray-300 group-hover:text-gray-900 focus:outline-none focus:ring-0 dark:group-hover:text-gray-400 focus:placeholder-gray-400", {
                            "dark:text-indigo-500 dark:group-hover:text-indigo-500": $(n)
                        }]),
                        readonly: "readonly",
                        type: "email",
                        onClick: i[0] || (i[0] = m => l())
                    }, null, 10, Fn)])])]),
                    _: 1
                }, 8, ["text"])])
            }
        }
    },
    Dn = Oe(P.ui.strategy, P.ui.card, Qa),
    jn = F({
        inheritAttrs: !1,
        props: {
            as: {
                type: String,
                default: "div"
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Be("card", ne(e, "ui"), Dn), a = h(() => wt(q(t.value.base, t.value.rounded, t.value.divide, t.value.ring, t.value.shadow, t.value.background), e.class));
            return {
                ui: t,
                attrs: n,
                cardClass: a
            }
        }
    });

function Pn(e, t, n, a, r, o) {
    return b(), j(Ut(e.$attrs.onSubmit ? "form" : e.as), z({
        class: e.cardClass
    }, e.attrs), {
        default: k(() => [e.$slots.header ? (b(), S("div", {
            key: 0,
            class: C([e.ui.header.base, e.ui.header.padding, e.ui.header.background])
        }, [L(e.$slots, "header")], 2)) : O("", !0), c("div", {
            class: C([e.ui.body.base, e.ui.body.padding, e.ui.body.background])
        }, [L(e.$slots, "default")], 2), e.$slots.footer ? (b(), S("div", {
            key: 1,
            class: C([e.ui.footer.base, e.ui.footer.padding, e.ui.footer.background])
        }, [L(e.$slots, "footer")], 2)) : O("", !0)]),
        _: 3
    }, 16, ["class"])
}
const rt = he(jn, [
    ["render", Pn]
]);

function fe(e, t, ...n) {
    if (e in t) {
        let r = t[e];
        return typeof r == "function" ? r(...n) : r
    }
    let a = new Error(`Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(t).map(r=>`"${r}"`).join(", ")}.`);
    throw Error.captureStackTrace && Error.captureStackTrace(a, fe), a
}
var De = (e => (e[e.None = 0] = "None", e[e.RenderStrategy = 1] = "RenderStrategy", e[e.Static = 2] = "Static", e))(De || {}),
    _e = (e => (e[e.Unmount = 0] = "Unmount", e[e.Hidden = 1] = "Hidden", e))(_e || {});

function re({
    visible: e = !0,
    features: t = 0,
    ourProps: n,
    theirProps: a,
    ...r
}) {
    var o;
    let l = Gt(a, n),
        s = Object.assign(r, {
            props: l
        });
    if (e || t & 2 && l.static) return dt(s);
    if (t & 1) {
        let u = (o = l.unmount) == null || o ? 0 : 1;
        return fe(u, {
            0() {
                return null
            },
            1() {
                return dt({ ...r,
                    props: { ...l,
                        hidden: !0,
                        style: {
                            display: "none"
                        }
                    }
                })
            }
        })
    }
    return dt(s)
}

function dt({
    props: e,
    attrs: t,
    slots: n,
    slot: a,
    name: r
}) {
    var o, l;
    let {
        as: s,
        ...u
    } = Jt(e, ["unmount", "static"]), i = (o = n.default) == null ? void 0 : o.call(n, a), d = {};
    if (a) {
        let f = !1,
            m = [];
        for (let [p, g] of Object.entries(a)) typeof g == "boolean" && (f = !0), g === !0 && m.push(p);
        f && (d["data-headlessui-state"] = m.join(" "))
    }
    if (s === "template") {
        if (i = Kt(i ? ? []), Object.keys(u).length > 0 || Object.keys(t).length > 0) {
            let [f, ...m] = i ? ? [];
            if (!zn(f) || m.length > 0) throw new Error(['Passing props on "template"!', "", `The current component <${r} /> is rendering a "template".`, "However we need to passthrough the following props:", Object.keys(u).concat(Object.keys(t)).map(v => v.trim()).filter((v, x, I) => I.indexOf(v) === x).sort((v, x) => v.localeCompare(x)).map(v => `  - ${v}`).join(`
`), "", "You can apply a few solutions:", ['Add an `as="..."` prop, to ensure that we render an actual element instead of a "template".', "Render a single element as the child so that we can forward the props onto that element."].map(v => `  - ${v}`).join(`
`)].join(`
`));
            let p = Gt((l = f.props) != null ? l : {}, u),
                g = Ta(f, p);
            for (let v in p) v.startsWith("on") && (g.props || (g.props = {}), g.props[v] = p[v]);
            return g
        }
        return Array.isArray(i) && i.length === 1 ? i[0] : i
    }
    return Y(s, Object.assign({}, u, d), {
        default: () => i
    })
}

function Kt(e) {
    return e.flatMap(t => t.type === Q ? Kt(t.children) : [t])
}

function Gt(...e) {
    if (e.length === 0) return {};
    if (e.length === 1) return e[0];
    let t = {},
        n = {};
    for (let a of e)
        for (let r in a) r.startsWith("on") && typeof a[r] == "function" ? (n[r] != null || (n[r] = []), n[r].push(a[r])) : t[r] = a[r];
    if (t.disabled || t["aria-disabled"]) return Object.assign(t, Object.fromEntries(Object.keys(n).map(a => [a, void 0])));
    for (let a in n) Object.assign(t, {
        [a](r, ...o) {
            let l = n[a];
            for (let s of l) {
                if (r instanceof Event && r.defaultPrevented) return;
                s(r, ...o)
            }
        }
    });
    return t
}

function Jt(e, t = []) {
    let n = Object.assign({}, e);
    for (let a of t) a in n && delete n[a];
    return n
}

function zn(e) {
    return e == null ? !1 : typeof e.type == "string" || typeof e.type == "object" || typeof e.type == "function"
}
let Nn = 0;

function Vn() {
    return ++Nn
}

function Pe() {
    return Vn()
}
var U = (e => (e.Space = " ", e.Enter = "Enter", e.Escape = "Escape", e.Backspace = "Backspace", e.Delete = "Delete", e.ArrowLeft = "ArrowLeft", e.ArrowUp = "ArrowUp", e.ArrowRight = "ArrowRight", e.ArrowDown = "ArrowDown", e.Home = "Home", e.End = "End", e.PageUp = "PageUp", e.PageDown = "PageDown", e.Tab = "Tab", e))(U || {});

function Rn(e) {
    throw new Error("Unexpected object: " + e)
}
var ae = (e => (e[e.First = 0] = "First", e[e.Previous = 1] = "Previous", e[e.Next = 2] = "Next", e[e.Last = 3] = "Last", e[e.Specific = 4] = "Specific", e[e.Nothing = 5] = "Nothing", e))(ae || {});

function Un(e, t) {
    let n = t.resolveItems();
    if (n.length <= 0) return null;
    let a = t.resolveActiveIndex(),
        r = a ? ? -1,
        o = (() => {
            switch (e.focus) {
                case 0:
                    return n.findIndex(l => !t.resolveDisabled(l));
                case 1:
                    {
                        let l = n.slice().reverse().findIndex((s, u, i) => r !== -1 && i.length - u - 1 >= r ? !1 : !t.resolveDisabled(s));
                        return l === -1 ? l : n.length - 1 - l
                    }
                case 2:
                    return n.findIndex((l, s) => s <= r ? !1 : !t.resolveDisabled(l));
                case 3:
                    {
                        let l = n.slice().reverse().findIndex(s => !t.resolveDisabled(s));
                        return l === -1 ? l : n.length - 1 - l
                    }
                case 4:
                    return n.findIndex(l => t.resolveId(l) === e.id);
                case 5:
                    return null;
                default:
                    Rn(e)
            }
        })();
    return o === -1 ? a : o
}

function E(e) {
    var t;
    return e == null || e.value == null ? null : (t = e.value.$el) != null ? t : e.value
}
let Xt = Symbol("Context");
var W = (e => (e[e.Open = 1] = "Open", e[e.Closed = 2] = "Closed", e[e.Closing = 4] = "Closing", e[e.Opening = 8] = "Opening", e))(W || {});

function Hn() {
    return ot() !== null
}

function ot() {
    return Z(Xt, null)
}

function Qt(e) {
    K(Xt, e)
}

function Ft(e, t) {
    if (e) return e;
    let n = t ? ? "button";
    if (typeof n == "string" && n.toLowerCase() === "button") return "button"
}

function qn(e, t) {
    let n = w(Ft(e.value.type, e.value.as));
    return N(() => {
        n.value = Ft(e.value.type, e.value.as)
    }), ee(() => {
        var a;
        n.value || E(t) && E(t) instanceof HTMLButtonElement && !((a = E(t)) != null && a.hasAttribute("type")) && (n.value = "button")
    }), n
}
var Wn = Object.defineProperty,
    Zn = (e, t, n) => t in e ? Wn(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    Lt = (e, t, n) => (Zn(e, typeof t != "symbol" ? t + "" : t, n), n);
class Yn {
    constructor() {
        Lt(this, "current", this.detect()), Lt(this, "currentId", 0)
    }
    set(t) {
        this.current !== t && (this.currentId = 0, this.current = t)
    }
    reset() {
        this.set(this.detect())
    }
    nextId() {
        return ++this.currentId
    }
    get isServer() {
        return this.current === "server"
    }
    get isClient() {
        return this.current === "client"
    }
    detect() {
        return typeof window > "u" || typeof document > "u" ? "server" : "client"
    }
}
let Ze = new Yn;

function Ce(e) {
    if (Ze.isServer) return null;
    if (e instanceof Node) return e.ownerDocument;
    if (e != null && e.hasOwnProperty("value")) {
        let t = E(e);
        if (t) return t.ownerDocument
    }
    return document
}

function Kn({
    container: e,
    accept: t,
    walk: n,
    enabled: a
}) {
    ee(() => {
        let r = e.value;
        if (!r || a !== void 0 && !a.value) return;
        let o = Ce(e);
        if (!o) return;
        let l = Object.assign(u => t(u), {
                acceptNode: t
            }),
            s = o.createTreeWalker(r, NodeFilter.SHOW_ELEMENT, l, !1);
        for (; s.nextNode();) n(s.currentNode)
    })
}
let gt = ["[contentEditable=true]", "[tabindex]", "a[href]", "area[href]", "button:not([disabled])", "iframe", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])"].map(e => `${e}:not([tabindex='-1'])`).join(",");
var ge = (e => (e[e.First = 1] = "First", e[e.Previous = 2] = "Previous", e[e.Next = 4] = "Next", e[e.Last = 8] = "Last", e[e.WrapAround = 16] = "WrapAround", e[e.NoScroll = 32] = "NoScroll", e))(ge || {}),
    ea = (e => (e[e.Error = 0] = "Error", e[e.Overflow = 1] = "Overflow", e[e.Success = 2] = "Success", e[e.Underflow = 3] = "Underflow", e))(ea || {}),
    Gn = (e => (e[e.Previous = -1] = "Previous", e[e.Next = 1] = "Next", e))(Gn || {});

function ta(e = document.body) {
    return e == null ? [] : Array.from(e.querySelectorAll(gt)).sort((t, n) => Math.sign((t.tabIndex || Number.MAX_SAFE_INTEGER) - (n.tabIndex || Number.MAX_SAFE_INTEGER)))
}
var Mt = (e => (e[e.Strict = 0] = "Strict", e[e.Loose = 1] = "Loose", e))(Mt || {});

function Ct(e, t = 0) {
    var n;
    return e === ((n = Ce(e)) == null ? void 0 : n.body) ? !1 : fe(t, {
        0() {
            return e.matches(gt)
        },
        1() {
            let a = e;
            for (; a !== null;) {
                if (a.matches(gt)) return !0;
                a = a.parentElement
            }
            return !1
        }
    })
}

function aa(e) {
    let t = Ce(e);
    Se(() => {
        t && !Ct(t.activeElement, 0) && Me(e)
    })
}
var Jn = (e => (e[e.Keyboard = 0] = "Keyboard", e[e.Mouse = 1] = "Mouse", e))(Jn || {});
typeof window < "u" && typeof document < "u" && (document.addEventListener("keydown", e => {
    e.metaKey || e.altKey || e.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "")
}, !0), document.addEventListener("click", e => {
    e.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "")
}, !0));

function Me(e) {
    e == null || e.focus({
        preventScroll: !0
    })
}
let Xn = ["textarea", "input"].join(",");

function Qn(e) {
    var t, n;
    return (n = (t = e == null ? void 0 : e.matches) == null ? void 0 : t.call(e, Xn)) != null ? n : !1
}

function na(e, t = n => n) {
    return e.slice().sort((n, a) => {
        let r = t(n),
            o = t(a);
        if (r === null || o === null) return 0;
        let l = r.compareDocumentPosition(o);
        return l & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : l & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0
    })
}

function er(e, t) {
    return qe(ta(), t, {
        relativeTo: e
    })
}

function qe(e, t, {
    sorted: n = !0,
    relativeTo: a = null,
    skipElements: r = []
} = {}) {
    var o;
    let l = (o = Array.isArray(e) ? e.length > 0 ? e[0].ownerDocument : document : e == null ? void 0 : e.ownerDocument) != null ? o : document,
        s = Array.isArray(e) ? n ? na(e) : e : ta(e);
    r.length > 0 && s.length > 1 && (s = s.filter(g => !r.includes(g))), a = a ? ? l.activeElement;
    let u = (() => {
            if (t & 5) return 1;
            if (t & 10) return -1;
            throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")
        })(),
        i = (() => {
            if (t & 1) return 0;
            if (t & 2) return Math.max(0, s.indexOf(a)) - 1;
            if (t & 4) return Math.max(0, s.indexOf(a)) + 1;
            if (t & 8) return s.length - 1;
            throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")
        })(),
        d = t & 32 ? {
            preventScroll: !0
        } : {},
        f = 0,
        m = s.length,
        p;
    do {
        if (f >= m || f + m <= 0) return 0;
        let g = i + f;
        if (t & 16) g = (g + m) % m;
        else {
            if (g < 0) return 3;
            if (g >= m) return 1
        }
        p = s[g], p == null || p.focus(d), f += u
    } while (p !== l.activeElement);
    return t & 6 && Qn(p) && p.select(), 2
}

function Je(e, t, n) {
    Ze.isServer || ee(a => {
        document.addEventListener(e, t, n), a(() => document.removeEventListener(e, t, n))
    })
}

function ra(e, t, n) {
    Ze.isServer || ee(a => {
        window.addEventListener(e, t, n), a(() => window.removeEventListener(e, t, n))
    })
}

function oa(e, t, n = h(() => !0)) {
    function a(o, l) {
        if (!n.value || o.defaultPrevented) return;
        let s = l(o);
        if (s === null || !s.getRootNode().contains(s)) return;
        let u = function i(d) {
            return typeof d == "function" ? i(d()) : Array.isArray(d) || d instanceof Set ? d : [d]
        }(e);
        for (let i of u) {
            if (i === null) continue;
            let d = i instanceof HTMLElement ? i : E(i);
            if (d != null && d.contains(s) || o.composed && o.composedPath().includes(d)) return
        }
        return !Ct(s, Mt.Loose) && s.tabIndex !== -1 && o.preventDefault(), t(o, s)
    }
    let r = w(null);
    Je("pointerdown", o => {
        var l, s;
        n.value && (r.value = ((s = (l = o.composedPath) == null ? void 0 : l.call(o)) == null ? void 0 : s[0]) || o.target)
    }, !0), Je("mousedown", o => {
        var l, s;
        n.value && (r.value = ((s = (l = o.composedPath) == null ? void 0 : l.call(o)) == null ? void 0 : s[0]) || o.target)
    }, !0), Je("click", o => {
        r.value && (a(o, () => r.value), r.value = null)
    }, !0), Je("touchend", o => a(o, () => o.target instanceof HTMLElement ? o.target : null), !0), ra("blur", o => a(o, () => window.document.activeElement instanceof HTMLIFrameElement ? window.document.activeElement : null), !0)
}
var et = (e => (e[e.None = 1] = "None", e[e.Focusable = 2] = "Focusable", e[e.Hidden = 4] = "Hidden", e))(et || {});
let pt = F({
    name: "Hidden",
    props: {
        as: {
            type: [Object, String],
            default: "div"
        },
        features: {
            type: Number,
            default: 1
        }
    },
    setup(e, {
        slots: t,
        attrs: n
    }) {
        return () => {
            let {
                features: a,
                ...r
            } = e, o = {
                "aria-hidden": (a & 2) === 2 ? !0 : void 0,
                style: {
                    position: "fixed",
                    top: 1,
                    left: 1,
                    width: 1,
                    height: 0,
                    padding: 0,
                    margin: -1,
                    overflow: "hidden",
                    clip: "rect(0, 0, 0, 0)",
                    whiteSpace: "nowrap",
                    borderWidth: "0",
                    ...(a & 4) === 4 && (a & 2) !== 2 && {
                        display: "none"
                    }
                }
            };
            return re({
                ourProps: o,
                theirProps: r,
                slot: {},
                attrs: n,
                slots: t,
                name: "Hidden"
            })
        }
    }
});

function Dt(e) {
    return [e.screenX, e.screenY]
}

function tr() {
    let e = w([-1, -1]);
    return {
        wasMoved(t) {
            let n = Dt(t);
            return e.value[0] === n[0] && e.value[1] === n[1] ? !1 : (e.value = n, !0)
        },
        update(t) {
            e.value = Dt(t)
        }
    }
}

function ar() {
    return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0
}

function It(e) {
    typeof queueMicrotask == "function" ? queueMicrotask(e) : Promise.resolve().then(e).catch(t => setTimeout(() => {
        throw t
    }))
}

function Ye() {
    let e = [],
        t = {
            addEventListener(n, a, r, o) {
                return n.addEventListener(a, r, o), t.add(() => n.removeEventListener(a, r, o))
            },
            requestAnimationFrame(...n) {
                let a = requestAnimationFrame(...n);
                t.add(() => cancelAnimationFrame(a))
            },
            nextFrame(...n) {
                t.requestAnimationFrame(() => {
                    t.requestAnimationFrame(...n)
                })
            },
            setTimeout(...n) {
                let a = setTimeout(...n);
                t.add(() => clearTimeout(a))
            },
            microTask(...n) {
                let a = {
                    current: !0
                };
                return It(() => {
                    a.current && n[0]()
                }), t.add(() => {
                    a.current = !1
                })
            },
            style(n, a, r) {
                let o = n.style.getPropertyValue(a);
                return Object.assign(n.style, {
                    [a]: r
                }), this.add(() => {
                    Object.assign(n.style, {
                        [a]: o
                    })
                })
            },
            group(n) {
                let a = Ye();
                return n(a), this.add(() => a.dispose())
            },
            add(n) {
                return e.push(n), () => {
                    let a = e.indexOf(n);
                    if (a >= 0)
                        for (let r of e.splice(a, 1)) r()
                }
            },
            dispose() {
                for (let n of e.splice(0)) n()
            }
        };
    return t
}
var Ue = (e => (e[e.Forwards = 0] = "Forwards", e[e.Backwards = 1] = "Backwards", e))(Ue || {});

function nr() {
    let e = w(0);
    return ra("keydown", t => {
        t.key === "Tab" && (e.value = t.shiftKey ? 1 : 0)
    }), e
}

function la(e, t, n, a) {
    Ze.isServer || ee(r => {
        e = e ? ? window, e.addEventListener(t, n, a), r(() => e.removeEventListener(t, n, a))
    })
}

function rr(e) {
    function t() {
        document.readyState !== "loading" && (e(), document.removeEventListener("DOMContentLoaded", t))
    }
    typeof window < "u" && typeof document < "u" && (document.addEventListener("DOMContentLoaded", t), t())
}

function sa(e) {
    if (!e) return new Set;
    if (typeof e == "function") return new Set(e());
    let t = new Set;
    for (let n of e.value) {
        let a = E(n);
        a instanceof HTMLElement && t.add(a)
    }
    return t
}
var ia = (e => (e[e.None = 1] = "None", e[e.InitialFocus = 2] = "InitialFocus", e[e.TabLock = 4] = "TabLock", e[e.FocusLock = 8] = "FocusLock", e[e.RestoreFocus = 16] = "RestoreFocus", e[e.All = 30] = "All", e))(ia || {});
let Ve = Object.assign(F({
        name: "FocusTrap",
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            initialFocus: {
                type: Object,
                default: null
            },
            features: {
                type: Number,
                default: 30
            },
            containers: {
                type: [Object, Function],
                default: w(new Set)
            }
        },
        inheritAttrs: !1,
        setup(e, {
            attrs: t,
            slots: n,
            expose: a
        }) {
            let r = w(null);
            a({
                el: r,
                $el: r
            });
            let o = h(() => Ce(r)),
                l = w(!1);
            N(() => l.value = !0), pe(() => l.value = !1), lr({
                ownerDocument: o
            }, h(() => l.value && !!(e.features & 16)));
            let s = sr({
                ownerDocument: o,
                container: r,
                initialFocus: h(() => e.initialFocus)
            }, h(() => l.value && !!(e.features & 2)));
            ir({
                ownerDocument: o,
                container: r,
                containers: e.containers,
                previousActiveElement: s
            }, h(() => l.value && !!(e.features & 8)));
            let u = nr();

            function i(p) {
                let g = E(r);
                g && (v => v())(() => {
                    fe(u.value, {
                        [Ue.Forwards]: () => {
                            qe(g, ge.First, {
                                skipElements: [p.relatedTarget]
                            })
                        },
                        [Ue.Backwards]: () => {
                            qe(g, ge.Last, {
                                skipElements: [p.relatedTarget]
                            })
                        }
                    })
                })
            }
            let d = w(!1);

            function f(p) {
                p.key === "Tab" && (d.value = !0, requestAnimationFrame(() => {
                    d.value = !1
                }))
            }

            function m(p) {
                if (!l.value) return;
                let g = sa(e.containers);
                E(r) instanceof HTMLElement && g.add(E(r));
                let v = p.relatedTarget;
                v instanceof HTMLElement && v.dataset.headlessuiFocusGuard !== "true" && (ua(g, v) || (d.value ? qe(E(r), fe(u.value, {
                    [Ue.Forwards]: () => ge.Next,
                    [Ue.Backwards]: () => ge.Previous
                }) | ge.WrapAround, {
                    relativeTo: p.target
                }) : p.target instanceof HTMLElement && Me(p.target)))
            }
            return () => {
                let p = {},
                    g = {
                        ref: r,
                        onKeydown: f,
                        onFocusout: m
                    },
                    {
                        features: v,
                        initialFocus: x,
                        containers: I,
                        ...A
                    } = e;
                return Y(Q, [!!(v & 4) && Y(pt, {
                    as: "button",
                    type: "button",
                    "data-headlessui-focus-guard": !0,
                    onFocus: i,
                    features: et.Focusable
                }), re({
                    ourProps: g,
                    theirProps: { ...t,
                        ...A
                    },
                    slot: p,
                    attrs: t,
                    slots: n,
                    name: "FocusTrap"
                }), !!(v & 4) && Y(pt, {
                    as: "button",
                    type: "button",
                    "data-headlessui-focus-guard": !0,
                    onFocus: i,
                    features: et.Focusable
                })])
            }
        }
    }), {
        features: ia
    }),
    Ee = [];
rr(() => {
    function e(t) {
        t.target instanceof HTMLElement && t.target !== document.body && Ee[0] !== t.target && (Ee.unshift(t.target), Ee = Ee.filter(n => n != null && n.isConnected), Ee.splice(10))
    }
    window.addEventListener("click", e, {
        capture: !0
    }), window.addEventListener("mousedown", e, {
        capture: !0
    }), window.addEventListener("focus", e, {
        capture: !0
    }), document.body.addEventListener("click", e, {
        capture: !0
    }), document.body.addEventListener("mousedown", e, {
        capture: !0
    }), document.body.addEventListener("focus", e, {
        capture: !0
    })
});

function or(e) {
    let t = w(Ee.slice());
    return We([e], ([n], [a]) => {
        a === !0 && n === !1 ? It(() => {
            t.value.splice(0)
        }) : a === !1 && n === !0 && (t.value = Ee.slice())
    }, {
        flush: "post"
    }), () => {
        var n;
        return (n = t.value.find(a => a != null && a.isConnected)) != null ? n : null
    }
}

function lr({
    ownerDocument: e
}, t) {
    let n = or(t);
    N(() => {
        ee(() => {
            var a, r;
            t.value || ((a = e.value) == null ? void 0 : a.activeElement) === ((r = e.value) == null ? void 0 : r.body) && Me(n())
        }, {
            flush: "post"
        })
    }), pe(() => {
        t.value && Me(n())
    })
}

function sr({
    ownerDocument: e,
    container: t,
    initialFocus: n
}, a) {
    let r = w(null),
        o = w(!1);
    return N(() => o.value = !0), pe(() => o.value = !1), N(() => {
        We([t, n, a], (l, s) => {
            if (l.every((i, d) => (s == null ? void 0 : s[d]) === i) || !a.value) return;
            let u = E(t);
            u && It(() => {
                var i, d;
                if (!o.value) return;
                let f = E(n),
                    m = (i = e.value) == null ? void 0 : i.activeElement;
                if (f) {
                    if (f === m) {
                        r.value = m;
                        return
                    }
                } else if (u.contains(m)) {
                    r.value = m;
                    return
                }
                f ? Me(f) : qe(u, ge.First | ge.NoScroll) === ea.Error && console.warn("There are no focusable elements inside the <FocusTrap />"), r.value = (d = e.value) == null ? void 0 : d.activeElement
            })
        }, {
            immediate: !0,
            flush: "post"
        })
    }), r
}

function ir({
    ownerDocument: e,
    container: t,
    containers: n,
    previousActiveElement: a
}, r) {
    var o;
    la((o = e.value) == null ? void 0 : o.defaultView, "focus", l => {
        if (!r.value) return;
        let s = sa(n);
        E(t) instanceof HTMLElement && s.add(E(t));
        let u = a.value;
        if (!u) return;
        let i = l.target;
        i && i instanceof HTMLElement ? ua(s, i) ? (a.value = i, Me(i)) : (l.preventDefault(), l.stopPropagation(), Me(u)) : Me(a.value)
    }, !0)
}

function ua(e, t) {
    for (let n of e)
        if (n.contains(t)) return !0;
    return !1
}
let ct = new Map,
    Re = new Map;

function jt(e, t = w(!0)) {
    ee(n => {
        var a;
        if (!t.value) return;
        let r = E(e);
        if (!r) return;
        n(function() {
            var l;
            if (!r) return;
            let s = (l = Re.get(r)) != null ? l : 1;
            if (s === 1 ? Re.delete(r) : Re.set(r, s - 1), s !== 1) return;
            let u = ct.get(r);
            u && (u["aria-hidden"] === null ? r.removeAttribute("aria-hidden") : r.setAttribute("aria-hidden", u["aria-hidden"]), r.inert = u.inert, ct.delete(r))
        });
        let o = (a = Re.get(r)) != null ? a : 0;
        Re.set(r, o + 1), o === 0 && (ct.set(r, {
            "aria-hidden": r.getAttribute("aria-hidden"),
            inert: r.inert
        }), r.setAttribute("aria-hidden", "true"), r.inert = !0)
    })
}
let da = Symbol("ForcePortalRootContext");

function ur() {
    return Z(da, !1)
}
let Pt = F({
    name: "ForcePortalRoot",
    props: {
        as: {
            type: [Object, String],
            default: "template"
        },
        force: {
            type: Boolean,
            default: !1
        }
    },
    setup(e, {
        slots: t,
        attrs: n
    }) {
        return K(da, e.force), () => {
            let {
                force: a,
                ...r
            } = e;
            return re({
                theirProps: r,
                ourProps: {},
                slot: {},
                slots: t,
                attrs: n,
                name: "ForcePortalRoot"
            })
        }
    }
});

function dr(e) {
    let t = Ce(e);
    if (!t) {
        if (e === null) return null;
        throw new Error(`[Headless UI]: Cannot find ownerDocument for contextElement: ${e}`)
    }
    let n = t.getElementById("headlessui-portal-root");
    if (n) return n;
    let a = t.createElement("div");
    return a.setAttribute("id", "headlessui-portal-root"), t.body.appendChild(a)
}
let cr = F({
        name: "Portal",
        props: {
            as: {
                type: [Object, String],
                default: "div"
            }
        },
        setup(e, {
            slots: t,
            attrs: n
        }) {
            let a = w(null),
                r = h(() => Ce(a)),
                o = ur(),
                l = Z(ca, null),
                s = w(o === !0 || l == null ? dr(a.value) : l.resolveTarget());
            ee(() => {
                o || l != null && (s.value = l.resolveTarget())
            });
            let u = Z(ht, null);
            return N(() => {
                let i = E(a);
                i && u && pe(u.register(i))
            }), pe(() => {
                var i, d;
                let f = (i = r.value) == null ? void 0 : i.getElementById("headlessui-portal-root");
                f && s.value === f && s.value.children.length <= 0 && ((d = s.value.parentElement) == null || d.removeChild(s.value))
            }), () => {
                if (s.value === null) return null;
                let i = {
                    ref: a,
                    "data-headlessui-portal": ""
                };
                return Y(Aa, {
                    to: s.value
                }, re({
                    ourProps: i,
                    theirProps: e,
                    slot: {},
                    attrs: n,
                    slots: t,
                    name: "Portal"
                }))
            }
        }
    }),
    ht = Symbol("PortalParentContext");

function fr() {
    let e = Z(ht, null),
        t = w([]);

    function n(o) {
        return t.value.push(o), e && e.register(o), () => a(o)
    }

    function a(o) {
        let l = t.value.indexOf(o);
        l !== -1 && t.value.splice(l, 1), e && e.unregister(o)
    }
    let r = {
        register: n,
        unregister: a,
        portals: t
    };
    return [t, F({
        name: "PortalWrapper",
        setup(o, {
            slots: l
        }) {
            return K(ht, r), () => {
                var s;
                return (s = l.default) == null ? void 0 : s.call(l)
            }
        }
    })]
}
let ca = Symbol("PortalGroupContext"),
    mr = F({
        name: "PortalGroup",
        props: {
            as: {
                type: [Object, String],
                default: "template"
            },
            target: {
                type: Object,
                default: null
            }
        },
        setup(e, {
            attrs: t,
            slots: n
        }) {
            let a = $t({
                resolveTarget() {
                    return e.target
                }
            });
            return K(ca, a), () => {
                let {
                    target: r,
                    ...o
                } = e;
                return re({
                    theirProps: o,
                    ourProps: {},
                    slot: {},
                    attrs: t,
                    slots: n,
                    name: "PortalGroup"
                })
            }
        }
    }),
    fa = Symbol("StackContext");
var yt = (e => (e[e.Add = 0] = "Add", e[e.Remove = 1] = "Remove", e))(yt || {});

function vr() {
    return Z(fa, () => {})
}

function gr({
    type: e,
    enabled: t,
    element: n,
    onUpdate: a
}) {
    let r = vr();

    function o(...l) {
        a == null || a(...l), r(...l)
    }
    N(() => {
        We(t, (l, s) => {
            l ? o(0, e, n) : s === !0 && o(1, e, n)
        }, {
            immediate: !0,
            flush: "sync"
        })
    }), pe(() => {
        t.value && o(1, e, n)
    }), K(fa, o)
}
let pr = Symbol("DescriptionContext");

function hr({
    slot: e = w({}),
    name: t = "Description",
    props: n = {}
} = {}) {
    let a = w([]);

    function r(o) {
        return a.value.push(o), () => {
            let l = a.value.indexOf(o);
            l !== -1 && a.value.splice(l, 1)
        }
    }
    return K(pr, {
        register: r,
        slot: e,
        name: t,
        props: n
    }), h(() => a.value.length > 0 ? a.value.join(" ") : void 0)
}

function yr(e) {
    let t = Oa(e.getSnapshot());
    return pe(e.subscribe(() => {
        t.value = e.getSnapshot()
    })), t
}

function br(e, t) {
    let n = e(),
        a = new Set;
    return {
        getSnapshot() {
            return n
        },
        subscribe(r) {
            return a.add(r), () => a.delete(r)
        },
        dispatch(r, ...o) {
            let l = t[r].call(n, ...o);
            l && (n = l, a.forEach(s => s()))
        }
    }
}

function kr() {
    let e;
    return {
        before({
            doc: t
        }) {
            var n;
            let a = t.documentElement;
            e = ((n = t.defaultView) != null ? n : window).innerWidth - a.clientWidth
        },
        after({
            doc: t,
            d: n
        }) {
            let a = t.documentElement,
                r = a.clientWidth - a.offsetWidth,
                o = e - r;
            n.style(a, "paddingRight", `${o}px`)
        }
    }
}

function wr() {
    if (!ar()) return {};
    let e;
    return {
        before() {
            e = window.pageYOffset
        },
        after({
            doc: t,
            d: n,
            meta: a
        }) {
            function r(l) {
                return a.containers.flatMap(s => s()).some(s => s.contains(l))
            }
            if (window.getComputedStyle(t.documentElement).scrollBehavior !== "auto") {
                let l = Ye();
                l.style(t.documentElement, "scroll-behavior", "auto"), n.add(() => n.microTask(() => l.dispose()))
            }
            n.style(t.body, "marginTop", `-${e}px`), window.scrollTo(0, 0);
            let o = null;
            n.addEventListener(t, "click", l => {
                if (l.target instanceof HTMLElement) try {
                    let s = l.target.closest("a");
                    if (!s) return;
                    let {
                        hash: u
                    } = new URL(s.href), i = t.querySelector(u);
                    i && !r(i) && (o = i)
                } catch {}
            }, !0), n.addEventListener(t, "touchmove", l => {
                l.target instanceof HTMLElement && !r(l.target) && l.preventDefault()
            }, {
                passive: !1
            }), n.add(() => {
                window.scrollTo(0, window.pageYOffset + e), o && o.isConnected && (o.scrollIntoView({
                    block: "nearest"
                }), o = null)
            })
        }
    }
}

function $r() {
    return {
        before({
            doc: e,
            d: t
        }) {
            t.style(e.documentElement, "overflow", "hidden")
        }
    }
}

function xr(e) {
    let t = {};
    for (let n of e) Object.assign(t, n(t));
    return t
}
let Te = br(() => new Map, {
    PUSH(e, t) {
        var n;
        let a = (n = this.get(e)) != null ? n : {
            doc: e,
            count: 0,
            d: Ye(),
            meta: new Set
        };
        return a.count++, a.meta.add(t), this.set(e, a), this
    },
    POP(e, t) {
        let n = this.get(e);
        return n && (n.count--, n.meta.delete(t)), this
    },
    SCROLL_PREVENT({
        doc: e,
        d: t,
        meta: n
    }) {
        let a = {
                doc: e,
                d: t,
                meta: xr(n)
            },
            r = [wr(), kr(), $r()];
        r.forEach(({
            before: o
        }) => o == null ? void 0 : o(a)), r.forEach(({
            after: o
        }) => o == null ? void 0 : o(a))
    },
    SCROLL_ALLOW({
        d: e
    }) {
        e.dispose()
    },
    TEARDOWN({
        doc: e
    }) {
        this.delete(e)
    }
});
Te.subscribe(() => {
    let e = Te.getSnapshot(),
        t = new Map;
    for (let [n] of e) t.set(n, n.documentElement.style.overflow);
    for (let n of e.values()) {
        let a = t.get(n.doc) === "hidden",
            r = n.count !== 0;
        (r && !a || !r && a) && Te.dispatch(n.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", n), n.count === 0 && Te.dispatch("TEARDOWN", n)
    }
});

function _r(e, t, n) {
    let a = yr(Te),
        r = h(() => {
            let o = e.value ? a.value.get(e.value) : void 0;
            return o ? o.count > 0 : !1
        });
    return We([e, t], ([o, l], [s], u) => {
        if (!o || !l) return;
        Te.dispatch("PUSH", o, n);
        let i = !1;
        u(() => {
            i || (Te.dispatch("POP", s ? ? o, n), i = !0)
        })
    }, {
        immediate: !0
    }), r
}

function Sr({
    defaultContainers: e = [],
    portals: t,
    mainTreeNodeRef: n
} = {}) {
    let a = w(null),
        r = Ce(a);

    function o() {
        var l;
        let s = [];
        for (let u of e) u !== null && (u instanceof HTMLElement ? s.push(u) : "value" in u && u.value instanceof HTMLElement && s.push(u.value));
        if (t != null && t.value)
            for (let u of t.value) s.push(u);
        for (let u of (l = r == null ? void 0 : r.querySelectorAll("html > *, body > *")) != null ? l : []) u !== document.body && u !== document.head && u instanceof HTMLElement && u.id !== "headlessui-portal-root" && (u.contains(E(a)) || s.some(i => u.contains(i)) || s.push(u));
        return s
    }
    return {
        resolveContainers: o,
        contains(l) {
            return o().some(s => s.contains(l))
        },
        mainTreeNodeRef: a,
        MainTreeNode() {
            return n != null ? null : Y(pt, {
                features: et.Hidden,
                ref: a
            })
        }
    }
}
var Mr = (e => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(Mr || {});
let bt = Symbol("DialogContext");

function ma(e) {
    let t = Z(bt, null);
    if (t === null) {
        let n = new Error(`<${e} /> is missing a parent <Dialog /> component.`);
        throw Error.captureStackTrace && Error.captureStackTrace(n, ma), n
    }
    return t
}
let Xe = "DC8F892D-2EBD-447C-A4C8-A03058436FF4",
    Cr = F({
        name: "Dialog",
        inheritAttrs: !1,
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            static: {
                type: Boolean,
                default: !1
            },
            unmount: {
                type: Boolean,
                default: !0
            },
            open: {
                type: [Boolean, String],
                default: Xe
            },
            initialFocus: {
                type: Object,
                default: null
            },
            id: {
                type: String,
                default: () => `headlessui-dialog-${Pe()}`
            }
        },
        emits: {
            close: e => !0
        },
        setup(e, {
            emit: t,
            attrs: n,
            slots: a,
            expose: r
        }) {
            var o;
            let l = w(!1);
            N(() => {
                l.value = !0
            });
            let s = w(0),
                u = ot(),
                i = h(() => e.open === Xe && u !== null ? (u.value & W.Open) === W.Open : e.open),
                d = w(null),
                f = h(() => Ce(d));
            if (r({
                    el: d,
                    $el: d
                }), !(e.open !== Xe || u !== null)) throw new Error("You forgot to provide an `open` prop to the `Dialog`.");
            if (typeof i.value != "boolean") throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${i.value===Xe?void 0:e.open}`);
            let m = h(() => l.value && i.value ? 0 : 1),
                p = h(() => m.value === 0),
                g = h(() => s.value > 1),
                v = Z(bt, null) !== null,
                [x, I] = fr(),
                {
                    resolveContainers: A,
                    mainTreeNodeRef: T,
                    MainTreeNode: oe
                } = Sr({
                    portals: x,
                    defaultContainers: [h(() => {
                        var B;
                        return (B = V.panelRef.value) != null ? B : d.value
                    })]
                }),
                G = h(() => g.value ? "parent" : "leaf"),
                H = h(() => u !== null ? (u.value & W.Closing) === W.Closing : !1),
                ie = h(() => v || H.value ? !1 : p.value),
                ue = h(() => {
                    var B, R, de;
                    return (de = Array.from((R = (B = f.value) == null ? void 0 : B.querySelectorAll("body > *")) != null ? R : []).find(ce => ce.id === "headlessui-portal-root" ? !1 : ce.contains(E(T)) && ce instanceof HTMLElement)) != null ? de : null
                });
            jt(ue, ie);
            let me = h(() => g.value ? !0 : p.value),
                ye = h(() => {
                    var B, R, de;
                    return (de = Array.from((R = (B = f.value) == null ? void 0 : B.querySelectorAll("[data-headlessui-portal]")) != null ? R : []).find(ce => ce.contains(E(T)) && ce instanceof HTMLElement)) != null ? de : null
                });
            jt(ye, me), gr({
                type: "Dialog",
                enabled: h(() => m.value === 0),
                element: d,
                onUpdate: (B, R) => {
                    if (R === "Dialog") return fe(B, {
                        [yt.Add]: () => s.value += 1,
                        [yt.Remove]: () => s.value -= 1
                    })
                }
            });
            let le = hr({
                    name: "DialogDescription",
                    slot: h(() => ({
                        open: i.value
                    }))
                }),
                te = w(null),
                V = {
                    titleId: te,
                    panelRef: w(null),
                    dialogState: m,
                    setTitleId(B) {
                        te.value !== B && (te.value = B)
                    },
                    close() {
                        t("close", !1)
                    }
                };
            K(bt, V);
            let M = h(() => !(!p.value || g.value));
            oa(A, (B, R) => {
                V.close(), Se(() => R == null ? void 0 : R.focus())
            }, M);
            let D = h(() => !(g.value || m.value !== 0));
            la((o = f.value) == null ? void 0 : o.defaultView, "keydown", B => {
                D.value && (B.defaultPrevented || B.key === U.Escape && (B.preventDefault(), B.stopPropagation(), V.close()))
            });
            let J = h(() => !(H.value || m.value !== 0 || v));
            return _r(f, J, B => {
                var R;
                return {
                    containers: [...(R = B.containers) != null ? R : [], A]
                }
            }), ee(B => {
                if (m.value !== 0) return;
                let R = E(d);
                if (!R) return;
                let de = new ResizeObserver(ce => {
                    for (let Ke of ce) {
                        let be = Ke.target.getBoundingClientRect();
                        be.x === 0 && be.y === 0 && be.width === 0 && be.height === 0 && V.close()
                    }
                });
                de.observe(R), B(() => de.disconnect())
            }), () => {
                let {
                    id: B,
                    open: R,
                    initialFocus: de,
                    ...ce
                } = e, Ke = { ...n,
                    ref: d,
                    id: B,
                    role: "dialog",
                    "aria-modal": m.value === 0 ? !0 : void 0,
                    "aria-labelledby": te.value,
                    "aria-describedby": le.value
                }, be = {
                    open: m.value === 0
                };
                return Y(Pt, {
                    force: !0
                }, () => [Y(cr, () => Y(mr, {
                    target: d.value
                }, () => Y(Pt, {
                    force: !1
                }, () => Y(Ve, {
                    initialFocus: de,
                    containers: A,
                    features: p.value ? fe(G.value, {
                        parent: Ve.features.RestoreFocus,
                        leaf: Ve.features.All & ~Ve.features.FocusLock
                    }) : Ve.features.None
                }, () => Y(I, {}, () => re({
                    ourProps: Ke,
                    theirProps: { ...ce,
                        ...n
                    },
                    slot: be,
                    attrs: n,
                    slots: a,
                    visible: m.value === 0,
                    features: De.RenderStrategy | De.Static,
                    name: "Dialog"
                })))))), Y(oe)])
            }
        }
    }),
    Ir = F({
        name: "DialogPanel",
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            id: {
                type: String,
                default: () => `headlessui-dialog-panel-${Pe()}`
            }
        },
        setup(e, {
            attrs: t,
            slots: n,
            expose: a
        }) {
            let r = ma("DialogPanel");
            a({
                el: r.panelRef,
                $el: r.panelRef
            });

            function o(l) {
                l.stopPropagation()
            }
            return () => {
                let {
                    id: l,
                    ...s
                } = e, u = {
                    id: l,
                    ref: r.panelRef,
                    onClick: o
                };
                return re({
                    ourProps: u,
                    theirProps: s,
                    slot: {
                        open: r.dialogState.value === 0
                    },
                    attrs: t,
                    slots: n,
                    name: "DialogPanel"
                })
            }
        }
    }),
    zt = /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g;

function Nt(e) {
    var t, n;
    let a = (t = e.innerText) != null ? t : "",
        r = e.cloneNode(!0);
    if (!(r instanceof HTMLElement)) return a;
    let o = !1;
    for (let s of r.querySelectorAll('[hidden],[aria-hidden],[role="img"]')) s.remove(), o = !0;
    let l = o ? (n = r.innerText) != null ? n : "" : a;
    return zt.test(l) && (l = l.replace(zt, "")), l
}

function Er(e) {
    let t = e.getAttribute("aria-label");
    if (typeof t == "string") return t.trim();
    let n = e.getAttribute("aria-labelledby");
    if (n) {
        let a = n.split(" ").map(r => {
            let o = document.getElementById(r);
            if (o) {
                let l = o.getAttribute("aria-label");
                return typeof l == "string" ? l.trim() : Nt(o).trim()
            }
            return null
        }).filter(Boolean);
        if (a.length > 0) return a.join(", ")
    }
    return Nt(e).trim()
}

function Tr(e) {
    let t = w(""),
        n = w("");
    return () => {
        let a = E(e);
        if (!a) return "";
        let r = a.innerText;
        if (t.value === r) return n.value;
        let o = Er(a).trim().toLowerCase();
        return t.value = r, n.value = o, o
    }
}
var Ar = (e => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(Ar || {}),
    Or = (e => (e[e.Pointer = 0] = "Pointer", e[e.Other = 1] = "Other", e))(Or || {});

function Br(e) {
    requestAnimationFrame(() => requestAnimationFrame(e))
}
let va = Symbol("MenuContext");

function lt(e) {
    let t = Z(va, null);
    if (t === null) {
        let n = new Error(`<${e} /> is missing a parent <Menu /> component.`);
        throw Error.captureStackTrace && Error.captureStackTrace(n, lt), n
    }
    return t
}
let Fr = F({
        name: "Menu",
        props: {
            as: {
                type: [Object, String],
                default: "template"
            }
        },
        setup(e, {
            slots: t,
            attrs: n
        }) {
            let a = w(1),
                r = w(null),
                o = w(null),
                l = w([]),
                s = w(""),
                u = w(null),
                i = w(1);

            function d(m = p => p) {
                let p = u.value !== null ? l.value[u.value] : null,
                    g = na(m(l.value.slice()), x => E(x.dataRef.domRef)),
                    v = p ? g.indexOf(p) : null;
                return v === -1 && (v = null), {
                    items: g,
                    activeItemIndex: v
                }
            }
            let f = {
                menuState: a,
                buttonRef: r,
                itemsRef: o,
                items: l,
                searchQuery: s,
                activeItemIndex: u,
                activationTrigger: i,
                closeMenu: () => {
                    a.value = 1, u.value = null
                },
                openMenu: () => a.value = 0,
                goToItem(m, p, g) {
                    let v = d(),
                        x = Un(m === ae.Specific ? {
                            focus: ae.Specific,
                            id: p
                        } : {
                            focus: m
                        }, {
                            resolveItems: () => v.items,
                            resolveActiveIndex: () => v.activeItemIndex,
                            resolveId: I => I.id,
                            resolveDisabled: I => I.dataRef.disabled
                        });
                    s.value = "", u.value = x, i.value = g ? ? 1, l.value = v.items
                },
                search(m) {
                    let p = s.value !== "" ? 0 : 1;
                    s.value += m.toLowerCase();
                    let g = (u.value !== null ? l.value.slice(u.value + p).concat(l.value.slice(0, u.value + p)) : l.value).find(x => x.dataRef.textValue.startsWith(s.value) && !x.dataRef.disabled),
                        v = g ? l.value.indexOf(g) : -1;
                    v === -1 || v === u.value || (u.value = v, i.value = 1)
                },
                clearSearch() {
                    s.value = ""
                },
                registerItem(m, p) {
                    let g = d(v => [...v, {
                        id: m,
                        dataRef: p
                    }]);
                    l.value = g.items, u.value = g.activeItemIndex, i.value = 1
                },
                unregisterItem(m) {
                    let p = d(g => {
                        let v = g.findIndex(x => x.id === m);
                        return v !== -1 && g.splice(v, 1), g
                    });
                    l.value = p.items, u.value = p.activeItemIndex, i.value = 1
                }
            };
            return oa([r, o], (m, p) => {
                var g;
                f.closeMenu(), Ct(p, Mt.Loose) || (m.preventDefault(), (g = E(r)) == null || g.focus())
            }, h(() => a.value === 0)), K(va, f), Qt(h(() => fe(a.value, {
                0: W.Open,
                1: W.Closed
            }))), () => {
                let m = {
                    open: a.value === 0,
                    close: f.closeMenu
                };
                return re({
                    ourProps: {},
                    theirProps: e,
                    slot: m,
                    slots: t,
                    attrs: n,
                    name: "Menu"
                })
            }
        }
    }),
    Lr = F({
        name: "MenuButton",
        props: {
            disabled: {
                type: Boolean,
                default: !1
            },
            as: {
                type: [Object, String],
                default: "button"
            },
            id: {
                type: String,
                default: () => `headlessui-menu-button-${Pe()}`
            }
        },
        setup(e, {
            attrs: t,
            slots: n,
            expose: a
        }) {
            let r = lt("MenuButton");
            a({
                el: r.buttonRef,
                $el: r.buttonRef
            });

            function o(i) {
                switch (i.key) {
                    case U.Space:
                    case U.Enter:
                    case U.ArrowDown:
                        i.preventDefault(), i.stopPropagation(), r.openMenu(), Se(() => {
                            var d;
                            (d = E(r.itemsRef)) == null || d.focus({
                                preventScroll: !0
                            }), r.goToItem(ae.First)
                        });
                        break;
                    case U.ArrowUp:
                        i.preventDefault(), i.stopPropagation(), r.openMenu(), Se(() => {
                            var d;
                            (d = E(r.itemsRef)) == null || d.focus({
                                preventScroll: !0
                            }), r.goToItem(ae.Last)
                        });
                        break
                }
            }

            function l(i) {
                switch (i.key) {
                    case U.Space:
                        i.preventDefault();
                        break
                }
            }

            function s(i) {
                e.disabled || (r.menuState.value === 0 ? (r.closeMenu(), Se(() => {
                    var d;
                    return (d = E(r.buttonRef)) == null ? void 0 : d.focus({
                        preventScroll: !0
                    })
                })) : (i.preventDefault(), r.openMenu(), Br(() => {
                    var d;
                    return (d = E(r.itemsRef)) == null ? void 0 : d.focus({
                        preventScroll: !0
                    })
                })))
            }
            let u = qn(h(() => ({
                as: e.as,
                type: t.type
            })), r.buttonRef);
            return () => {
                var i;
                let d = {
                        open: r.menuState.value === 0
                    },
                    {
                        id: f,
                        ...m
                    } = e,
                    p = {
                        ref: r.buttonRef,
                        id: f,
                        type: u.value,
                        "aria-haspopup": "menu",
                        "aria-controls": (i = E(r.itemsRef)) == null ? void 0 : i.id,
                        "aria-expanded": r.menuState.value === 0,
                        onKeydown: o,
                        onKeyup: l,
                        onClick: s
                    };
                return re({
                    ourProps: p,
                    theirProps: m,
                    slot: d,
                    attrs: t,
                    slots: n,
                    name: "MenuButton"
                })
            }
        }
    }),
    Dr = F({
        name: "MenuItems",
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            static: {
                type: Boolean,
                default: !1
            },
            unmount: {
                type: Boolean,
                default: !0
            },
            id: {
                type: String,
                default: () => `headlessui-menu-items-${Pe()}`
            }
        },
        setup(e, {
            attrs: t,
            slots: n,
            expose: a
        }) {
            let r = lt("MenuItems"),
                o = w(null);
            a({
                el: r.itemsRef,
                $el: r.itemsRef
            }), Kn({
                container: h(() => E(r.itemsRef)),
                enabled: h(() => r.menuState.value === 0),
                accept(d) {
                    return d.getAttribute("role") === "menuitem" ? NodeFilter.FILTER_REJECT : d.hasAttribute("role") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
                },
                walk(d) {
                    d.setAttribute("role", "none")
                }
            });

            function l(d) {
                var f;
                switch (o.value && clearTimeout(o.value), d.key) {
                    case U.Space:
                        if (r.searchQuery.value !== "") return d.preventDefault(), d.stopPropagation(), r.search(d.key);
                    case U.Enter:
                        if (d.preventDefault(), d.stopPropagation(), r.activeItemIndex.value !== null) {
                            let m = r.items.value[r.activeItemIndex.value];
                            (f = E(m.dataRef.domRef)) == null || f.click()
                        }
                        r.closeMenu(), aa(E(r.buttonRef));
                        break;
                    case U.ArrowDown:
                        return d.preventDefault(), d.stopPropagation(), r.goToItem(ae.Next);
                    case U.ArrowUp:
                        return d.preventDefault(), d.stopPropagation(), r.goToItem(ae.Previous);
                    case U.Home:
                    case U.PageUp:
                        return d.preventDefault(), d.stopPropagation(), r.goToItem(ae.First);
                    case U.End:
                    case U.PageDown:
                        return d.preventDefault(), d.stopPropagation(), r.goToItem(ae.Last);
                    case U.Escape:
                        d.preventDefault(), d.stopPropagation(), r.closeMenu(), Se(() => {
                            var m;
                            return (m = E(r.buttonRef)) == null ? void 0 : m.focus({
                                preventScroll: !0
                            })
                        });
                        break;
                    case U.Tab:
                        d.preventDefault(), d.stopPropagation(), r.closeMenu(), Se(() => er(E(r.buttonRef), d.shiftKey ? ge.Previous : ge.Next));
                        break;
                    default:
                        d.key.length === 1 && (r.search(d.key), o.value = setTimeout(() => r.clearSearch(), 350));
                        break
                }
            }

            function s(d) {
                switch (d.key) {
                    case U.Space:
                        d.preventDefault();
                        break
                }
            }
            let u = ot(),
                i = h(() => u !== null ? (u.value & W.Open) === W.Open : r.menuState.value === 0);
            return () => {
                var d, f;
                let m = {
                        open: r.menuState.value === 0
                    },
                    {
                        id: p,
                        ...g
                    } = e,
                    v = {
                        "aria-activedescendant": r.activeItemIndex.value === null || (d = r.items.value[r.activeItemIndex.value]) == null ? void 0 : d.id,
                        "aria-labelledby": (f = E(r.buttonRef)) == null ? void 0 : f.id,
                        id: p,
                        onKeydown: l,
                        onKeyup: s,
                        role: "menu",
                        tabIndex: 0,
                        ref: r.itemsRef
                    };
                return re({
                    ourProps: v,
                    theirProps: g,
                    slot: m,
                    attrs: t,
                    slots: n,
                    features: De.RenderStrategy | De.Static,
                    visible: i.value,
                    name: "MenuItems"
                })
            }
        }
    }),
    jr = F({
        name: "MenuItem",
        inheritAttrs: !1,
        props: {
            as: {
                type: [Object, String],
                default: "template"
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            id: {
                type: String,
                default: () => `headlessui-menu-item-${Pe()}`
            }
        },
        setup(e, {
            slots: t,
            attrs: n,
            expose: a
        }) {
            let r = lt("MenuItem"),
                o = w(null);
            a({
                el: o,
                $el: o
            });
            let l = h(() => r.activeItemIndex.value !== null ? r.items.value[r.activeItemIndex.value].id === e.id : !1),
                s = Tr(o),
                u = h(() => ({
                    disabled: e.disabled,
                    get textValue() {
                        return s()
                    },
                    domRef: o
                }));
            N(() => r.registerItem(e.id, u)), pe(() => r.unregisterItem(e.id)), ee(() => {
                r.menuState.value === 0 && l.value && r.activationTrigger.value !== 0 && Se(() => {
                    var v, x;
                    return (x = (v = E(o)) == null ? void 0 : v.scrollIntoView) == null ? void 0 : x.call(v, {
                        block: "nearest"
                    })
                })
            });

            function i(v) {
                if (e.disabled) return v.preventDefault();
                r.closeMenu(), aa(E(r.buttonRef))
            }

            function d() {
                if (e.disabled) return r.goToItem(ae.Nothing);
                r.goToItem(ae.Specific, e.id)
            }
            let f = tr();

            function m(v) {
                f.update(v)
            }

            function p(v) {
                f.wasMoved(v) && (e.disabled || l.value || r.goToItem(ae.Specific, e.id, 0))
            }

            function g(v) {
                f.wasMoved(v) && (e.disabled || l.value && r.goToItem(ae.Nothing))
            }
            return () => {
                let {
                    disabled: v
                } = e, x = {
                    active: l.value,
                    disabled: v,
                    close: r.closeMenu
                }, {
                    id: I,
                    ...A
                } = e;
                return re({
                    ourProps: {
                        id: I,
                        ref: o,
                        role: "menuitem",
                        tabIndex: v === !0 ? void 0 : -1,
                        "aria-disabled": v === !0 ? !0 : void 0,
                        disabled: void 0,
                        onClick: i,
                        onFocus: d,
                        onPointerenter: m,
                        onMouseenter: m,
                        onPointermove: p,
                        onMousemove: p,
                        onPointerleave: g,
                        onMouseleave: g
                    },
                    theirProps: { ...n,
                        ...A
                    },
                    slot: x,
                    attrs: n,
                    slots: t,
                    name: "MenuItem"
                })
            }
        }
    });

function Pr(e) {
    let t = {
        called: !1
    };
    return (...n) => {
        if (!t.called) return t.called = !0, e(...n)
    }
}

function ft(e, ...t) {
    e && t.length > 0 && e.classList.add(...t)
}

function Qe(e, ...t) {
    e && t.length > 0 && e.classList.remove(...t)
}
var kt = (e => (e.Finished = "finished", e.Cancelled = "cancelled", e))(kt || {});

function zr(e, t) {
    let n = Ye();
    if (!e) return n.dispose;
    let {
        transitionDuration: a,
        transitionDelay: r
    } = getComputedStyle(e), [o, l] = [a, r].map(s => {
        let [u = 0] = s.split(",").filter(Boolean).map(i => i.includes("ms") ? parseFloat(i) : parseFloat(i) * 1e3).sort((i, d) => d - i);
        return u
    });
    return o !== 0 ? n.setTimeout(() => t("finished"), o + l) : t("finished"), n.add(() => t("cancelled")), n.dispose
}

function Vt(e, t, n, a, r, o) {
    let l = Ye(),
        s = o !== void 0 ? Pr(o) : () => {};
    return Qe(e, ...r), ft(e, ...t, ...n), l.nextFrame(() => {
        Qe(e, ...n), ft(e, ...a), l.add(zr(e, u => (Qe(e, ...a, ...t), ft(e, ...r), s(u))))
    }), l.add(() => Qe(e, ...t, ...n, ...a, ...r)), l.add(() => s("cancelled")), l.dispose
}

function Ie(e = "") {
    return e.split(" ").filter(t => t.trim().length > 1)
}
let Et = Symbol("TransitionContext");
var Nr = (e => (e.Visible = "visible", e.Hidden = "hidden", e))(Nr || {});

function Vr() {
    return Z(Et, null) !== null
}

function Rr() {
    let e = Z(Et, null);
    if (e === null) throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
    return e
}

function Ur() {
    let e = Z(Tt, null);
    if (e === null) throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
    return e
}
let Tt = Symbol("NestingContext");

function st(e) {
    return "children" in e ? st(e.children) : e.value.filter(({
        state: t
    }) => t === "visible").length > 0
}

function ga(e) {
    let t = w([]),
        n = w(!1);
    N(() => n.value = !0), pe(() => n.value = !1);

    function a(o, l = _e.Hidden) {
        let s = t.value.findIndex(({
            id: u
        }) => u === o);
        s !== -1 && (fe(l, {
            [_e.Unmount]() {
                t.value.splice(s, 1)
            },
            [_e.Hidden]() {
                t.value[s].state = "hidden"
            }
        }), !st(t) && n.value && (e == null || e()))
    }

    function r(o) {
        let l = t.value.find(({
            id: s
        }) => s === o);
        return l ? l.state !== "visible" && (l.state = "visible") : t.value.push({
            id: o,
            state: "visible"
        }), () => a(o, _e.Unmount)
    }
    return {
        children: t,
        register: r,
        unregister: a
    }
}
let pa = De.RenderStrategy,
    ha = F({
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            show: {
                type: [Boolean],
                default: null
            },
            unmount: {
                type: [Boolean],
                default: !0
            },
            appear: {
                type: [Boolean],
                default: !1
            },
            enter: {
                type: [String],
                default: ""
            },
            enterFrom: {
                type: [String],
                default: ""
            },
            enterTo: {
                type: [String],
                default: ""
            },
            entered: {
                type: [String],
                default: ""
            },
            leave: {
                type: [String],
                default: ""
            },
            leaveFrom: {
                type: [String],
                default: ""
            },
            leaveTo: {
                type: [String],
                default: ""
            }
        },
        emits: {
            beforeEnter: () => !0,
            afterEnter: () => !0,
            beforeLeave: () => !0,
            afterLeave: () => !0
        },
        setup(e, {
            emit: t,
            attrs: n,
            slots: a,
            expose: r
        }) {
            let o = w(0);

            function l() {
                o.value |= W.Opening, t("beforeEnter")
            }

            function s() {
                o.value &= ~W.Opening, t("afterEnter")
            }

            function u() {
                o.value |= W.Closing, t("beforeLeave")
            }

            function i() {
                o.value &= ~W.Closing, t("afterLeave")
            }
            if (!Vr() && Hn()) return () => Y(ya, { ...e,
                onBeforeEnter: l,
                onAfterEnter: s,
                onBeforeLeave: u,
                onAfterLeave: i
            }, a);
            let d = w(null),
                f = h(() => e.unmount ? _e.Unmount : _e.Hidden);
            r({
                el: d,
                $el: d
            });
            let {
                show: m,
                appear: p
            } = Rr(), {
                register: g,
                unregister: v
            } = Ur(), x = w(m.value ? "visible" : "hidden"), I = {
                value: !0
            }, A = Pe(), T = {
                value: !1
            }, oe = ga(() => {
                !T.value && x.value !== "hidden" && (x.value = "hidden", v(A), i())
            });
            N(() => {
                let V = g(A);
                pe(V)
            }), ee(() => {
                if (f.value === _e.Hidden && A) {
                    if (m.value && x.value !== "visible") {
                        x.value = "visible";
                        return
                    }
                    fe(x.value, {
                        hidden: () => v(A),
                        visible: () => g(A)
                    })
                }
            });
            let G = Ie(e.enter),
                H = Ie(e.enterFrom),
                ie = Ie(e.enterTo),
                ue = Ie(e.entered),
                me = Ie(e.leave),
                ye = Ie(e.leaveFrom),
                le = Ie(e.leaveTo);
            N(() => {
                ee(() => {
                    if (x.value === "visible") {
                        let V = E(d);
                        if (V instanceof Comment && V.data === "") throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?")
                    }
                })
            });

            function te(V) {
                let M = I.value && !p.value,
                    D = E(d);
                !D || !(D instanceof HTMLElement) || M || (T.value = !0, m.value && l(), m.value || u(), V(m.value ? Vt(D, G, H, ie, ue, J => {
                    T.value = !1, J === kt.Finished && s()
                }) : Vt(D, me, ye, le, ue, J => {
                    T.value = !1, J === kt.Finished && (st(oe) || (x.value = "hidden", v(A), i()))
                })))
            }
            return N(() => {
                We([m], (V, M, D) => {
                    te(D), I.value = !1
                }, {
                    immediate: !0
                })
            }), K(Tt, oe), Qt(h(() => fe(x.value, {
                visible: W.Open,
                hidden: W.Closed
            }) | o.value)), () => {
                let {
                    appear: V,
                    show: M,
                    enter: D,
                    enterFrom: J,
                    enterTo: B,
                    entered: R,
                    leave: de,
                    leaveFrom: ce,
                    leaveTo: Ke,
                    ...be
                } = e, Sa = {
                    ref: d
                }, Ma = { ...be,
                    ...p.value && m.value && Ze.isServer ? {
                        class: C([n.class, be.class, ...G, ...H])
                    } : {}
                };
                return re({
                    theirProps: Ma,
                    ourProps: Sa,
                    slot: {},
                    slots: a,
                    attrs: n,
                    features: pa,
                    visible: x.value === "visible",
                    name: "TransitionChild"
                })
            }
        }
    }),
    Hr = ha,
    ya = F({
        inheritAttrs: !1,
        props: {
            as: {
                type: [Object, String],
                default: "div"
            },
            show: {
                type: [Boolean],
                default: null
            },
            unmount: {
                type: [Boolean],
                default: !0
            },
            appear: {
                type: [Boolean],
                default: !1
            },
            enter: {
                type: [String],
                default: ""
            },
            enterFrom: {
                type: [String],
                default: ""
            },
            enterTo: {
                type: [String],
                default: ""
            },
            entered: {
                type: [String],
                default: ""
            },
            leave: {
                type: [String],
                default: ""
            },
            leaveFrom: {
                type: [String],
                default: ""
            },
            leaveTo: {
                type: [String],
                default: ""
            }
        },
        emits: {
            beforeEnter: () => !0,
            afterEnter: () => !0,
            beforeLeave: () => !0,
            afterLeave: () => !0
        },
        setup(e, {
            emit: t,
            attrs: n,
            slots: a
        }) {
            let r = ot(),
                o = h(() => e.show === null && r !== null ? (r.value & W.Open) === W.Open : e.show);
            ee(() => {
                if (![!0, !1].includes(o.value)) throw new Error('A <Transition /> is used but it is missing a `:show="true | false"` prop.')
            });
            let l = w(o.value ? "visible" : "hidden"),
                s = ga(() => {
                    l.value = "hidden"
                }),
                u = w(!0),
                i = {
                    show: o,
                    appear: h(() => e.appear || !u.value)
                };
            return N(() => {
                ee(() => {
                    u.value = !1, o.value ? l.value = "visible" : st(s) || (l.value = "hidden")
                })
            }), K(Tt, s), K(Et, i), () => {
                let d = Jt(e, ["show", "appear", "unmount", "onBeforeEnter", "onBeforeLeave", "onAfterEnter", "onAfterLeave"]),
                    f = {
                        unmount: e.unmount
                    };
                return re({
                    ourProps: { ...f,
                        as: "template"
                    },
                    theirProps: {},
                    slot: {},
                    slots: { ...a,
                        default: () => [Y(Hr, {
                            onBeforeEnter: () => t("beforeEnter"),
                            onAfterEnter: () => t("afterEnter"),
                            onBeforeLeave: () => t("beforeLeave"),
                            onAfterLeave: () => t("afterLeave"),
                            ...n,
                            ...f,
                            ...d
                        }, a.default)]
                    },
                    attrs: {},
                    features: pa,
                    visible: l.value === "visible",
                    name: "Transition"
                })
            }
        }
    });
const qr = Oe(P.ui.strategy, P.ui.modal, en),
    Wr = F({
        components: {
            HDialog: Cr,
            HDialogPanel: Ir,
            TransitionRoot: ya,
            TransitionChild: ha
        },
        inheritAttrs: !1,
        props: {
            modelValue: {
                type: Boolean,
                default: !1
            },
            appear: {
                type: Boolean,
                default: !1
            },
            overlay: {
                type: Boolean,
                default: !0
            },
            transition: {
                type: Boolean,
                default: !0
            },
            preventClose: {
                type: Boolean,
                default: !1
            },
            fullscreen: {
                type: Boolean,
                default: !1
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        emits: ["update:modelValue", "close"],
        setup(e, {
            emit: t
        }) {
            const {
                ui: n,
                attrs: a
            } = Be("modal", ne(e, "ui"), qr, ne(e, "class")), r = h({
                get() {
                    return e.modelValue
                },
                set(s) {
                    t("update:modelValue", s)
                }
            }), o = h(() => e.transition ? { ...n.value.transition
            } : {});

            function l(s) {
                r.value = s, t("close")
            }
            return {
                ui: n,
                attrs: a,
                isOpen: r,
                transitionClass: o,
                close: l
            }
        }
    });

function Zr(e, t, n, a, r, o) {
    const l = xe("TransitionChild"),
        s = xe("HDialogPanel"),
        u = xe("HDialog"),
        i = xe("TransitionRoot");
    return b(), j(i, {
        appear: e.appear,
        show: e.isOpen,
        as: "template"
    }, {
        default: k(() => [y(u, z({
            class: e.ui.wrapper
        }, e.attrs, {
            onClose: t[0] || (t[0] = d => !e.preventClose && e.close(d))
        }), {
            default: k(() => [e.overlay ? (b(), j(l, z({
                key: 0,
                as: "template",
                appear: e.appear
            }, e.ui.overlay.transition), {
                default: k(() => [c("div", {
                    class: C([e.ui.overlay.base, e.ui.overlay.background])
                }, null, 2)]),
                _: 1
            }, 16, ["appear"])) : O("", !0), c("div", {
                class: C(e.ui.inner)
            }, [c("div", {
                class: C([e.ui.container, !e.fullscreen && e.ui.padding])
            }, [y(l, z({
                as: "template",
                appear: e.appear
            }, e.transitionClass), {
                default: k(() => [y(s, {
                    class: C([e.ui.base, e.ui.background, e.ui.ring, e.ui.shadow, e.fullscreen ? "w-screen" : e.ui.width, e.fullscreen ? "h-screen" : e.ui.height, e.fullscreen ? "rounded-none" : e.ui.rounded, e.fullscreen ? "m-0" : e.ui.margin])
                }, {
                    default: k(() => [L(e.$slots, "default")]),
                    _: 3
                }, 8, ["class"])]),
                _: 3
            }, 16, ["appear"])], 2)], 2)]),
            _: 3
        }, 16, ["class"])]),
        _: 3
    }, 8, ["appear", "show"])
}
const it = he(Wr, [
        ["render", Zr]
    ]),
    Yr = {
        key: 0
    },
    Kr = c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    }, null, -1),
    Gr = [Kr],
    Jr = c("div", {
        class: "mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-400"
    }, [c("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        class: "h-6 w-6 text-yellow-600 dark:text-yellow-800",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    })])], -1),
    Xr = {
        class: "mb-5 mt-3 text-center sm:mt-5"
    },
    Qr = {
        class: "text-lg font-medium leading-6 text-gray-900 dark:text-gray-300"
    },
    eo = {
        class: "mt-2"
    },
    to = {
        class: "text-sm leading-5 text-gray-500 dark:text-gray-400"
    },
    ao = {
        __name: "Explanation",
        setup(e) {
            const {
                isWarned: t
            } = Ae(Ba()), n = w(null), a = w(!1);
            Fa(n, {
                initial: {
                    scale: 1
                },
                enter: {
                    scale: 1.1,
                    transition: {
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "mirror",
                        repeatDelay: 1400
                    }
                }
            });

            function r() {
                t.value = !0, a.value = !1
            }
            return (o, l) => {
                const s = Le,
                    u = je,
                    i = rt,
                    d = it;
                return $(t) ? O("", !0) : (b(), S("div", Yr, [y(u, {
                    text: o.$t("explanation.title")
                }, {
                    default: k(() => [y(s, {
                        color: "yellow",
                        class: "flex-1 justify-between",
                        variant: "link",
                        "aria-label": o.$t("explanation.title"),
                        title: o.$t("explanation.title"),
                        onClick: l[0] || (l[0] = f => a.value = !0)
                    }, {
                        default: k(() => [(b(), S("svg", {
                            ref_key: "warning",
                            ref: n,
                            xmlns: "http://www.w3.org/2000/svg",
                            class: "h-6 w-6 text-amber-500 dark:text-amber-600",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor"
                        }, Gr, 512))]),
                        _: 1
                    }, 8, ["aria-label", "title"])]),
                    _: 1
                }, 8, ["text"]), y(d, {
                    modelValue: $(a),
                    "onUpdate:modelValue": l[1] || (l[1] = f => nt(a) ? a.value = f : null)
                }, {
                    default: k(() => [y(i, {
                        ui: {
                            background: "dark:bg-gray-800",
                            divide: "divide-y divide-gray-100 dark:divide-gray-700"
                        }
                    }, {
                        default: k(() => [Jr, c("div", Xr, [c("h3", Qr, _(o.$t("explanation.title")), 1), c("div", eo, [c("p", to, _(o.$t("explanation.desc")), 1)])]), y(s, {
                            block: "",
                            color: "indigo",
                            variant: "solid",
                            onClick: r
                        }, {
                            default: k(() => [X(_(o.$t("explanation.ok")), 1)]),
                            _: 1
                        })]),
                        _: 1
                    })]),
                    _: 1
                }, 8, ["modelValue"])]))
            }
        }
    },
    no = {
        name: La,
        props: {
            placeholder: String,
            tag: {
                type: String,
                default: "span"
            }
        }
    };

function ro(e, t, n, a, r, o) {
    const l = St;
    return b(), j(l, {
        placeholder: n.placeholder,
        "placeholder-tag": n.tag
    }, {
        default: k(() => [L(e.$slots, "default")]),
        _: 3
    }, 8, ["placeholder", "placeholder-tag"])
}
const oo = he(no, [
        ["render", ro]
    ]),
    lo = () => Da("color-mode").value,
    so = c("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        fill: "currentColor",
        class: "h-6 w-6"
    }, [c("g", {
        class: "opacity-100 dark:opacity-0"
    }, [c("path", {
        d: "M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"
    })]), c("g", {
        class: "opacity-0 dark:opacity-100"
    }, [c("path", {
        "fill-rule": "evenodd",
        d: "M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z",
        "clip-rule": "evenodd"
    })])], -1),
    io = {
        __name: "ColorMode",
        setup(e) {
            const t = lo();

            function n() {
                t.preference = t.value === "dark" ? "light" : "dark"
            }
            const a = h(() => `${t.value==="light"?"Dark":"Light"} mode`);
            return (r, o) => {
                const l = Le,
                    s = je,
                    u = oo;
                return b(), j(u, {
                    placeholder: "...",
                    tag: "span"
                }, {
                    default: k(() => [y(s, {
                        text: $(a)
                    }, {
                        default: k(() => [y(l, {
                            color: "gray",
                            class: "flex-1 justify-between hover:text-stone-600 dark:hover:text-yellow-500",
                            variant: "link",
                            "aria-label": $(a),
                            title: $(a),
                            onClick: n
                        }, {
                            default: k(() => [so]),
                            _: 1
                        }, 8, ["aria-label", "title"])]),
                        _: 1
                    }, 8, ["text"])]),
                    _: 1
                })
            }
        }
    },
    uo = Oe(P.ui.strategy, P.ui.dropdown, ja),
    co = F({
        components: {
            HMenu: Fr,
            HMenuButton: Lr,
            HMenuItems: Dr,
            HMenuItem: jr,
            UIcon: Fe,
            UAvatar: xt,
            UKbd: Yt
        },
        inheritAttrs: !1,
        props: {
            items: {
                type: Array,
                default: () => []
            },
            mode: {
                type: String,
                default: "click",
                validator: e => ["click", "hover"].includes(e)
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            popper: {
                type: Object,
                default: () => ({})
            },
            openDelay: {
                type: Number,
                default: 0
            },
            closeDelay: {
                type: Number,
                default: 0
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Be("dropdown", ne(e, "ui"), uo, ne(e, "class")), a = h(() => Ht(e.mode === "hover" ? {
                offsetDistance: 0
            } : {}, e.popper, t.value.popper)), [r, o] = Ga(a.value), l = w(null);
            let s = null,
                u = null;
            N(() => {
                setTimeout(() => {
                    var x;
                    const g = (x = r.value) == null ? void 0 : x.$.provides;
                    if (!g) return;
                    const v = Object.getOwnPropertySymbols(g);
                    l.value = v.length && g[v[0]]
                }, 200)
            });
            const i = h(() => {
                var v, x;
                const g = ((v = e.popper) == null ? void 0 : v.offsetDistance) || ((x = t.value.popper) == null ? void 0 : x.offsetDistance) || 8;
                return e.mode === "hover" ? {
                    paddingTop: `${g}px`,
                    paddingBottom: `${g}px`
                } : {}
            });

            function d() {
                e.mode !== "hover" || !l.value || (u && (clearTimeout(u), u = null), l.value.menuState !== 0 && (s = s || setTimeout(() => {
                    l.value.openMenu && l.value.openMenu(), s = null
                }, e.openDelay)))
            }

            function f() {
                e.mode !== "hover" || !l.value || (s && (clearTimeout(s), s = null), l.value.menuState !== 1 && (u = u || setTimeout(() => {
                    l.value.closeMenu && l.value.closeMenu(), u = null
                }, e.closeDelay)))
            }

            function m(g, v, {
                href: x,
                navigate: I,
                close: A,
                isExternal: T
            }) {
                v.click && v.click(g), x && !T && (I(g), A())
            }
            return {
                ui: t,
                attrs: n,
                popper: a,
                trigger: r,
                container: o,
                containerStyle: i,
                onMouseOver: d,
                onMouseLeave: f,
                onClick: m,
                omit: Pa,
                NuxtLink: at
            }
        }
    }),
    fo = ["disabled"],
    mo = {
        class: "truncate"
    };

function vo(e, t, n, a, r, o) {
    const l = xe("HMenuButton"),
        s = Fe,
        u = xt,
        i = Yt,
        d = xe("HMenuItem"),
        f = at,
        m = xe("HMenuItems"),
        p = xe("HMenu");
    return b(), j(p, z({
        as: "div",
        class: e.ui.wrapper
    }, e.attrs, {
        onMouseleave: e.onMouseLeave
    }), {
        default: k(({
            open: g
        }) => [y(l, {
            ref: "trigger",
            as: "div",
            disabled: e.disabled,
            class: "inline-flex w-full",
            role: "button",
            onMouseover: e.onMouseOver
        }, {
            default: k(() => [L(e.$slots, "default", {
                open: g,
                disabled: e.disabled
            }, () => [c("button", {
                disabled: e.disabled
            }, " Open ", 8, fo)])]),
            _: 2
        }, 1032, ["disabled", "onMouseover"]), g && e.items.length ? (b(), S("div", {
            key: 0,
            ref: "container",
            class: C([e.ui.container, e.ui.width]),
            style: Rt(e.containerStyle),
            onMouseover: t[0] || (t[0] = (...v) => e.onMouseOver && e.onMouseOver(...v))
        }, [y(vt, z({
            appear: ""
        }, e.ui.transition), {
            default: k(() => [c("div", null, [e.popper.arrow ? (b(), S("div", {
                key: 0,
                "data-popper-arrow": "",
                class: C(["invisible before:visible before:block before:rotate-45 before:z-[-1]", Object.values(e.ui.arrow)])
            }, null, 2)) : O("", !0), y(m, {
                class: C([e.ui.base, e.ui.divide, e.ui.ring, e.ui.rounded, e.ui.shadow, e.ui.background, e.ui.height]),
                static: ""
            }, {
                default: k(() => [(b(!0), S(Q, null, He(e.items, (v, x) => (b(), S("div", {
                    key: x,
                    class: C(e.ui.padding)
                }, [(b(!0), S(Q, null, He(v, (I, A) => (b(), j(f, z({
                    key: A
                }, e.omit(I, ["label", "slot", "icon", "iconClass", "avatar", "shortcuts", "disabled", "click"]), {
                    custom: ""
                }), {
                    default: k(({
                        href: T,
                        target: oe,
                        rel: G,
                        navigate: H,
                        isExternal: ie
                    }) => [y(d, {
                        disabled: I.disabled
                    }, {
                        default: k(({
                            active: ue,
                            disabled: me,
                            close: ye
                        }) => [(b(), j(Ut(T ? "a" : "button"), {
                            href: me ? void 0 : T,
                            rel: G,
                            target: oe,
                            class: C([e.ui.item.base, e.ui.item.padding, e.ui.item.size, e.ui.item.rounded, ue ? e.ui.item.active : e.ui.item.inactive, me && e.ui.item.disabled]),
                            onClick: le => e.onClick(le, I, {
                                href: T,
                                navigate: H,
                                close: ye,
                                isExternal: ie
                            })
                        }, {
                            default: k(() => [L(e.$slots, I.slot || "item", {
                                item: I
                            }, () => {
                                var le;
                                return [I.icon ? (b(), j(s, {
                                    key: 0,
                                    name: I.icon,
                                    class: C([e.ui.item.icon.base, ue ? e.ui.item.icon.active : e.ui.item.icon.inactive, I.iconClass])
                                }, null, 8, ["name", "class"])) : I.avatar ? (b(), j(u, z({
                                    key: 1
                                }, {
                                    size: e.ui.item.avatar.size,
                                    ...I.avatar
                                }, {
                                    class: e.ui.item.avatar.base
                                }), null, 16, ["class"])) : O("", !0), c("span", mo, _(I.label), 1), (le = I.shortcuts) != null && le.length ? (b(), S("span", {
                                    key: 2,
                                    class: C(e.ui.item.shortcuts)
                                }, [(b(!0), S(Q, null, He(I.shortcuts, te => (b(), j(i, {
                                    key: te
                                }, {
                                    default: k(() => [X(_(te), 1)]),
                                    _: 2
                                }, 1024))), 128))], 2)) : O("", !0)]
                            })]),
                            _: 2
                        }, 1032, ["href", "rel", "target", "class", "onClick"]))]),
                        _: 2
                    }, 1032, ["disabled"])]),
                    _: 2
                }, 1040))), 128))], 2))), 128))]),
                _: 3
            }, 8, ["class"])])]),
            _: 3
        }, 16)], 38)) : O("", !0)]),
        _: 3
    }, 16, ["class", "onMouseleave"])
}
const ba = he(co, [
        ["render", vo]
    ]),
    go = c("svg", {
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        class: "h-6 w-6"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"
    })], -1),
    po = {
        __name: "Language",
        setup(e) {
            const {
                locale: t,
                locales: n
            } = qt(), a = za(), r = h(() => n.value.filter(o => o.code !== t.value).map(o => [{
                label: o.name,
                to: a(o.code)
            }]));
            return (o, l) => {
                const s = Le,
                    u = je,
                    i = ba;
                return b(), j(i, {
                    items: $(r),
                    ui: {
                        width: "w-32",
                        base: "max-h-48"
                    }
                }, {
                    item: k(({
                        item: d
                    }) => [X(_(d.label), 1)]),
                    default: k(() => [y(u, {
                        text: o.$t("feature.language")
                    }, {
                        default: k(() => [y(s, {
                            color: "gray",
                            class: "flex-1 justify-between hover:text-sky-600 dark:hover:text-sky-600",
                            "aria-label": o.$t("feature.language"),
                            title: o.$t("feature.language"),
                            variant: "link"
                        }, {
                            default: k(() => [go]),
                            _: 1
                        }, 8, ["aria-label", "title"])]),
                        _: 1
                    }, 8, ["text"])]),
                    _: 1
                }, 8, ["items"])
            }
        }
    };
let ho = 0;

function ka() {
    return `nuid-${ho++}`
}
const wa = (e, t) => {
        const n = Z("form-events", void 0),
            a = Z("form-group", void 0),
            r = Z("form-inputs", void 0),
            o = w(e == null ? void 0 : e.id);
        N(() => {
            o.value = e != null && e.isFieldset ? null : (e == null ? void 0 : e.id) ? ? ka(), a && (a.inputId.value = o.value, r && (r.value[a.name.value] = o))
        });
        const l = w(!1);

        function s(f, m) {
            n && n.emit({
                type: f,
                path: m
            })
        }

        function u() {
            s("blur", a == null ? void 0 : a.name.value), l.value = !0
        }

        function i() {
            s("change", a == null ? void 0 : a.name.value)
        }
        const d = Na(() => {
            (l.value || a != null && a.eagerValidation.value) && s("input", a == null ? void 0 : a.name.value)
        }, 300);
        return {
            inputId: o,
            name: h(() => (e == null ? void 0 : e.name) ? ? (a == null ? void 0 : a.name.value)),
            size: h(() => {
                var m;
                const f = t.size[a == null ? void 0 : a.size.value] ? a == null ? void 0 : a.size.value : null;
                return (e == null ? void 0 : e.size) ? ? f ? ? ((m = t == null ? void 0 : t.default) == null ? void 0 : m.size)
            }),
            color: h(() => {
                var f;
                return (f = a == null ? void 0 : a.error) != null && f.value ? "red" : e == null ? void 0 : e.color
            }),
            emitFormBlur: u,
            emitFormInput: d,
            emitFormChange: i
        }
    },
    ve = Oe(P.ui.strategy, P.ui.select, Va),
    yo = F({
        components: {
            UIcon: Fe
        },
        inheritAttrs: !1,
        props: {
            modelValue: {
                type: [String, Number, Object],
                default: ""
            },
            id: {
                type: String,
                default: null
            },
            name: {
                type: String,
                default: null
            },
            placeholder: {
                type: String,
                default: null
            },
            required: {
                type: Boolean,
                default: !1
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            icon: {
                type: String,
                default: null
            },
            loadingIcon: {
                type: String,
                default: () => ve.default.loadingIcon
            },
            leadingIcon: {
                type: String,
                default: null
            },
            trailingIcon: {
                type: String,
                default: () => ve.default.trailingIcon
            },
            trailing: {
                type: Boolean,
                default: !1
            },
            leading: {
                type: Boolean,
                default: !1
            },
            loading: {
                type: Boolean,
                default: !1
            },
            padded: {
                type: Boolean,
                default: !0
            },
            options: {
                type: Array,
                default: () => []
            },
            size: {
                type: String,
                default: null,
                validator(e) {
                    return Object.keys(ve.size).includes(e)
                }
            },
            color: {
                type: String,
                default: () => ve.default.color,
                validator(e) {
                    return [...P.ui.colors, ...Object.keys(ve.color)].includes(e)
                }
            },
            variant: {
                type: String,
                default: () => ve.default.variant,
                validator(e) {
                    return [...Object.keys(ve.variant), ...Object.values(ve.color).flatMap(t => Object.keys(t))].includes(e)
                }
            },
            optionAttribute: {
                type: String,
                default: "label"
            },
            valueAttribute: {
                type: String,
                default: "value"
            },
            selectClass: {
                type: String,
                default: null
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            }
        },
        emits: ["update:modelValue", "change"],
        setup(e, {
            emit: t,
            slots: n
        }) {
            const {
                ui: a,
                attrs: r
            } = Be("select", ne(e, "ui"), ve, ne(e, "class")), {
                size: o,
                rounded: l
            } = Wt({
                ui: a,
                props: e
            }), {
                emitFormChange: s,
                inputId: u,
                color: i,
                size: d,
                name: f
            } = wa(e, ve), m = h(() => o.value || d.value), p = M => {
                t("update:modelValue", M.target.value)
            }, g = M => {
                s(), t("change", M)
            }, v = M => Ge(M, e.valueAttribute, Ge(M, e.optionAttribute)), x = M => Ge(M, e.optionAttribute, Ge(M, e.valueAttribute)), I = M => ["string", "number", "boolean"].includes(typeof M) ? {
                [e.valueAttribute]: M,
                [e.optionAttribute]: M
            } : { ...M,
                [e.valueAttribute]: v(M),
                [e.optionAttribute]: x(M)
            }, A = h(() => e.options.map(M => I(M))), T = h(() => e.placeholder ? [{
                [e.valueAttribute]: "",
                [e.optionAttribute]: e.placeholder,
                disabled: !0
            }, ...A.value] : A.value), oe = h(() => {
                const M = I(e.modelValue),
                    D = T.value.find(J => J[e.valueAttribute] === M[e.valueAttribute]);
                return D ? D[e.valueAttribute] : ""
            }), G = h(() => {
                var D, J;
                const M = ((J = (D = a.value.color) == null ? void 0 : D[i.value]) == null ? void 0 : J[e.variant]) || a.value.variant[e.variant];
                return wt(q(a.value.base, l.value, a.value.size[m.value], e.padded ? a.value.padding[m.value] : "p-0", M == null ? void 0 : M.replaceAll("{color}", i.value), (H.value || n.leading) && a.value.leading.padding[m.value], (ie.value || n.trailing) && a.value.trailing.padding[m.value]), e.selectClass)
            }), H = h(() => e.icon && e.leading || e.icon && !e.trailing || e.loading && !e.trailing || e.leadingIcon), ie = h(() => e.icon && e.trailing || e.loading && e.trailing || e.trailingIcon), ue = h(() => e.loading ? e.loadingIcon : e.leadingIcon || e.icon), me = h(() => e.loading && !H.value ? e.loadingIcon : e.trailingIcon || e.icon), ye = h(() => q(a.value.icon.leading.wrapper, a.value.icon.leading.pointer, a.value.icon.leading.padding[m.value])), le = h(() => q(a.value.icon.base, P.ui.colors.includes(i.value) && a.value.icon.color.replaceAll("{color}", i.value), a.value.icon.size[m.value], e.loading && "animate-spin")), te = h(() => q(a.value.icon.trailing.wrapper, a.value.icon.trailing.pointer, a.value.icon.trailing.padding[m.value])), V = h(() => q(a.value.icon.base, P.ui.colors.includes(i.value) && a.value.icon.color.replaceAll("{color}", i.value), a.value.icon.size[m.value], e.loading && !H.value && "animate-spin"));
            return {
                ui: a,
                attrs: r,
                name: f,
                inputId: u,
                normalizedOptionsWithPlaceholder: T,
                normalizedValue: oe,
                isLeading: H,
                isTrailing: ie,
                selectClass: G,
                leadingIconName: ue,
                leadingIconClass: le,
                leadingWrapperIconClass: ye,
                trailingIconName: me,
                trailingIconClass: V,
                trailingWrapperIconClass: te,
                onInput: p,
                onChange: g
            }
        }
    }),
    bo = ["id", "name", "value", "required", "disabled"],
    ko = ["value", "label"],
    wo = ["value", "selected", "disabled", "textContent"],
    $o = ["value", "selected", "disabled", "textContent"];

function xo(e, t, n, a, r, o) {
    const l = Fe;
    return b(), S("div", {
        class: C(e.ui.wrapper)
    }, [c("select", z({
        id: e.inputId,
        name: e.name,
        value: e.modelValue,
        required: e.required,
        disabled: e.disabled || e.loading,
        class: ["form-select", e.selectClass]
    }, e.attrs, {
        onInput: t[0] || (t[0] = (...s) => e.onInput && e.onInput(...s)),
        onChange: t[1] || (t[1] = (...s) => e.onChange && e.onChange(...s))
    }), [(b(!0), S(Q, null, He(e.normalizedOptionsWithPlaceholder, (s, u) => (b(), S(Q, null, [s.children ? (b(), S("optgroup", {
        key: `${s[e.valueAttribute]}-optgroup-${u}`,
        value: s[e.valueAttribute],
        label: s[e.optionAttribute]
    }, [(b(!0), S(Q, null, He(s.children, (i, d) => (b(), S("option", {
        key: `${i[e.valueAttribute]}-${u}-${d}`,
        value: i[e.valueAttribute],
        selected: i[e.valueAttribute] === e.normalizedValue,
        disabled: i.disabled,
        textContent: _(i[e.optionAttribute])
    }, null, 8, wo))), 128))], 8, ko)) : (b(), S("option", {
        key: `${s[e.valueAttribute]}-${u}`,
        value: s[e.valueAttribute],
        selected: s[e.valueAttribute] === e.normalizedValue,
        disabled: s.disabled,
        textContent: _(s[e.optionAttribute])
    }, null, 8, $o))], 64))), 256))], 16, bo), e.isLeading && e.leadingIconName || e.$slots.leading ? (b(), S("span", {
        key: 0,
        class: C(e.leadingWrapperIconClass)
    }, [L(e.$slots, "leading", {
        disabled: e.disabled,
        loading: e.loading
    }, () => [y(l, {
        name: e.leadingIconName,
        class: C(e.leadingIconClass)
    }, null, 8, ["name", "class"])])], 2)) : O("", !0), e.isTrailing && e.trailingIconName || e.$slots.trailing ? (b(), S("span", {
        key: 1,
        class: C(e.trailingWrapperIconClass)
    }, [L(e.$slots, "trailing", {
        disabled: e.disabled,
        loading: e.loading
    }, () => [y(l, {
        name: e.trailingIconName,
        class: C(e.trailingIconClass),
        "aria-hidden": "true"
    }, null, 8, ["name", "class"])])], 2)) : O("", !0)], 2)
}
const _o = he(yo, [
        ["render", xo]
    ]),
    ke = Oe(P.ui.strategy, P.ui.input, Ra),
    So = F({
        components: {
            UIcon: Fe
        },
        inheritAttrs: !1,
        props: {
            modelValue: {
                type: [String, Number],
                default: ""
            },
            type: {
                type: String,
                default: "text"
            },
            id: {
                type: String,
                default: null
            },
            name: {
                type: String,
                default: null
            },
            placeholder: {
                type: String,
                default: null
            },
            required: {
                type: Boolean,
                default: !1
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            autofocus: {
                type: Boolean,
                default: !1
            },
            autofocusDelay: {
                type: Number,
                default: 100
            },
            icon: {
                type: String,
                default: null
            },
            loadingIcon: {
                type: String,
                default: () => ke.default.loadingIcon
            },
            leadingIcon: {
                type: String,
                default: null
            },
            trailingIcon: {
                type: String,
                default: null
            },
            trailing: {
                type: Boolean,
                default: !1
            },
            leading: {
                type: Boolean,
                default: !1
            },
            loading: {
                type: Boolean,
                default: !1
            },
            padded: {
                type: Boolean,
                default: !0
            },
            size: {
                type: String,
                default: null,
                validator(e) {
                    return Object.keys(ke.size).includes(e)
                }
            },
            color: {
                type: String,
                default: () => ke.default.color,
                validator(e) {
                    return [...P.ui.colors, ...Object.keys(ke.color)].includes(e)
                }
            },
            variant: {
                type: String,
                default: () => ke.default.variant,
                validator(e) {
                    return [...Object.keys(ke.variant), ...Object.values(ke.color).flatMap(t => Object.keys(t))].includes(e)
                }
            },
            inputClass: {
                type: String,
                default: null
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            },
            modelModifiers: {
                type: Object,
                default: () => ({})
            }
        },
        emits: ["update:modelValue", "blur"],
        setup(e, {
            emit: t,
            slots: n
        }) {
            const {
                ui: a,
                attrs: r
            } = Be("input", ne(e, "ui"), ke, ne(e, "class")), {
                size: o,
                rounded: l
            } = Wt({
                ui: a,
                props: e
            }), {
                emitFormBlur: s,
                emitFormInput: u,
                size: i,
                color: d,
                inputId: f,
                name: m
            } = wa(e, ke), p = h(() => o.value || i.value), g = w(Ht({}, e.modelModifiers, {
                trim: !1,
                lazy: !1,
                number: !1
            })), v = w(null), x = () => {
                var M;
                e.autofocus && ((M = v.value) == null || M.focus())
            }, I = M => {
                g.value.trim && (M = M.trim()), (g.value.number || e.type === "number") && (M = Ua(M)), t("update:modelValue", M), u()
            }, A = M => {
                g.value.lazy || I(M.target.value)
            }, T = M => {
                const D = M.target.value;
                g.value.lazy && I(D), g.value.trim && (M.target.value = D.trim())
            }, oe = M => {
                s(), t("blur", M)
            };
            N(() => {
                setTimeout(() => {
                    x()
                }, e.autofocusDelay)
            });
            const G = h(() => {
                    var D, J;
                    const M = ((J = (D = a.value.color) == null ? void 0 : D[d.value]) == null ? void 0 : J[e.variant]) || a.value.variant[e.variant];
                    return wt(q(a.value.base, l.value, a.value.placeholder, a.value.size[p.value], e.padded ? a.value.padding[p.value] : "p-0", M == null ? void 0 : M.replaceAll("{color}", d.value), (H.value || n.leading) && a.value.leading.padding[p.value], (ie.value || n.trailing) && a.value.trailing.padding[p.value]), e.inputClass)
                }),
                H = h(() => e.icon && e.leading || e.icon && !e.trailing || e.loading && !e.trailing || e.leadingIcon),
                ie = h(() => e.icon && e.trailing || e.loading && e.trailing || e.trailingIcon),
                ue = h(() => e.loading ? e.loadingIcon : e.leadingIcon || e.icon),
                me = h(() => e.loading && !H.value ? e.loadingIcon : e.trailingIcon || e.icon),
                ye = h(() => q(a.value.icon.leading.wrapper, a.value.icon.leading.pointer, a.value.icon.leading.padding[p.value])),
                le = h(() => q(a.value.icon.base, P.ui.colors.includes(d.value) && a.value.icon.color.replaceAll("{color}", d.value), a.value.icon.size[p.value], e.loading && "animate-spin")),
                te = h(() => q(a.value.icon.trailing.wrapper, a.value.icon.trailing.pointer, a.value.icon.trailing.padding[p.value])),
                V = h(() => q(a.value.icon.base, P.ui.colors.includes(d.value) && a.value.icon.color.replaceAll("{color}", d.value), a.value.icon.size[p.value], e.loading && !H.value && "animate-spin"));
            return {
                ui: a,
                attrs: r,
                name: m,
                inputId: f,
                input: v,
                isLeading: H,
                isTrailing: ie,
                inputClass: G,
                leadingIconName: ue,
                leadingIconClass: le,
                leadingWrapperIconClass: ye,
                trailingIconName: me,
                trailingIconClass: V,
                trailingWrapperIconClass: te,
                onInput: A,
                onChange: T,
                onBlur: oe
            }
        }
    }),
    Mo = ["id", "name", "value", "type", "required", "placeholder", "disabled"];

function Co(e, t, n, a, r, o) {
    const l = Fe;
    return b(), S("div", {
        class: C(e.ui.wrapper)
    }, [c("input", z({
        id: e.inputId,
        ref: "input",
        name: e.name,
        value: e.modelValue,
        type: e.type,
        required: e.required,
        placeholder: e.placeholder,
        disabled: e.disabled || e.loading,
        class: ["form-input", e.inputClass]
    }, e.attrs, {
        onInput: t[0] || (t[0] = (...s) => e.onInput && e.onInput(...s)),
        onBlur: t[1] || (t[1] = (...s) => e.onBlur && e.onBlur(...s)),
        onChange: t[2] || (t[2] = (...s) => e.onChange && e.onChange(...s))
    }), null, 16, Mo), L(e.$slots, "default"), e.isLeading && e.leadingIconName || e.$slots.leading ? (b(), S("span", {
        key: 0,
        class: C(e.leadingWrapperIconClass)
    }, [L(e.$slots, "leading", {
        disabled: e.disabled,
        loading: e.loading
    }, () => [y(l, {
        name: e.leadingIconName,
        class: C(e.leadingIconClass)
    }, null, 8, ["name", "class"])])], 2)) : O("", !0), e.isTrailing && e.trailingIconName || e.$slots.trailing ? (b(), S("span", {
        key: 1,
        class: C(e.trailingWrapperIconClass)
    }, [L(e.$slots, "trailing", {
        disabled: e.disabled,
        loading: e.loading
    }, () => [y(l, {
        name: e.trailingIconName,
        class: C(e.trailingIconClass)
    }, null, 8, ["name", "class"])])], 2)) : O("", !0)], 2)
}
const $a = he(So, [
        ["render", Co]
    ]),
    mt = Oe(P.ui.strategy, P.ui.formGroup, Xa),
    Io = F({
        inheritAttrs: !1,
        props: {
            name: {
                type: String,
                default: null
            },
            size: {
                type: String,
                default: null,
                validator(e) {
                    return Object.keys(mt.size).includes(e)
                }
            },
            label: {
                type: String,
                default: null
            },
            description: {
                type: String,
                default: null
            },
            required: {
                type: Boolean,
                default: !1
            },
            help: {
                type: String,
                default: null
            },
            error: {
                type: [String, Boolean],
                default: null
            },
            hint: {
                type: String,
                default: null
            },
            class: {
                type: [String, Object, Array],
                    default: void 0
            },
            ui: {
                type: Object,
                default: void 0
            },
            eagerValidation: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const {
                ui: t,
                attrs: n
            } = Be("formGroup", ne(e, "ui"), mt, ne(e, "class")), a = Z("form-errors", null), r = h(() => {
                var s, u;
                return e.error && typeof e.error == "string" || typeof e.error == "boolean" ? e.error : (u = (s = a == null ? void 0 : a.value) == null ? void 0 : s.find(i => i.path === e.name)) == null ? void 0 : u.message
            }), o = h(() => t.value.size[e.size ? ? mt.default.size]), l = w();
            return K("form-group", {
                error: r,
                inputId: l,
                name: h(() => e.name),
                size: h(() => e.size),
                eagerValidation: h(() => e.eagerValidation)
            }), {
                ui: t,
                attrs: n,
                inputId: l,
                size: o,
                error: r
            }
        }
    }),
    Eo = ["for"];

function To(e, t, n, a, r, o) {
    return b(), S("div", z({
        class: e.ui.wrapper
    }, e.attrs), [e.label || e.$slots.label ? (b(), S("div", {
        key: 0,
        class: C([e.ui.label.wrapper, e.size])
    }, [c("label", {
        for: e.inputId,
        class: C([e.ui.label.base, e.required ? e.ui.label.required : ""])
    }, [e.$slots.label ? L(e.$slots, "label", $e(z({
        key: 0
    }, {
        error: e.error,
        label: e.label,
        name: e.name,
        hint: e.hint,
        description: e.description,
        help: e.help
    }))) : (b(), S(Q, {
        key: 1
    }, [X(_(e.label), 1)], 64))], 10, Eo), e.hint || e.$slots.hint ? (b(), S("span", {
        key: 0,
        class: C([e.ui.hint])
    }, [e.$slots.hint ? L(e.$slots, "hint", $e(z({
        key: 0
    }, {
        error: e.error,
        label: e.label,
        name: e.name,
        hint: e.hint,
        description: e.description,
        help: e.help
    }))) : (b(), S(Q, {
        key: 1
    }, [X(_(e.hint), 1)], 64))], 2)) : O("", !0)], 2)) : O("", !0), e.description || e.$slots.description ? (b(), S("p", {
        key: 1,
        class: C([e.ui.description, e.size])
    }, [e.$slots.description ? L(e.$slots, "description", $e(z({
        key: 0
    }, {
        error: e.error,
        label: e.label,
        name: e.name,
        hint: e.hint,
        description: e.description,
        help: e.help
    }))) : (b(), S(Q, {
        key: 1
    }, [X(_(e.description), 1)], 64))], 2)) : O("", !0), c("div", {
        class: C([e.label ? e.ui.container : ""])
    }, [L(e.$slots, "default", $e(Ha({
        error: e.error
    }))), typeof e.error == "string" && e.error || e.$slots.error ? (b(), S("p", {
        key: 0,
        class: C([e.ui.error, e.size])
    }, [e.$slots.error ? L(e.$slots, "error", $e(z({
        key: 0
    }, {
        error: e.error,
        label: e.label,
        name: e.name,
        hint: e.hint,
        description: e.description,
        help: e.help
    }))) : (b(), S(Q, {
        key: 1
    }, [X(_(e.error), 1)], 64))], 2)) : e.help || e.$slots.help ? (b(), S("p", {
        key: 1,
        class: C([e.ui.help, e.size])
    }, [e.$slots.help ? L(e.$slots, "help", $e(z({
        key: 0
    }, {
        error: e.error,
        label: e.label,
        name: e.name,
        hint: e.hint,
        description: e.description,
        help: e.help
    }))) : (b(), S(Q, {
        key: 1
    }, [X(_(e.help), 1)], 64))], 2)) : O("", !0)], 2)], 16)
}
const xa = he(Io, [
    ["render", To]
]);
class tt extends Error {
    constructor(t) {
        super(t), this.message = t, Object.setPrototypeOf(this, tt.prototype)
    }
}
const Ao = F({
    props: {
        schema: {
            type: Object,
            default: void 0
        },
        state: {
            type: Object,
            required: !0
        },
        validate: {
            type: Function,
            default: () => []
        },
        validateOn: {
            type: Array,
            default: () => ["blur", "input", "change", "submit"]
        }
    },
    emits: ["submit", "error"],
    setup(e, {
        expose: t,
        emit: n
    }) {
        const a = qa(`form-${ka()}`);
        a.on(async i => {
            var d;
            i.type !== "submit" && ((d = e.validateOn) != null && d.includes(i.type)) && await s(i.path, {
                silent: !0
            })
        });
        const r = w([]);
        K("form-errors", r), K("form-events", a);
        const o = w({});
        K("form-inputs", o);
        async function l() {
            let i = await e.validate(e.state);
            if (e.schema)
                if (Lo(e.schema)) i = i.concat(await Do(e.state, e.schema));
                else if (Oo(e.schema)) i = i.concat(await Fo(e.state, e.schema));
            else if (jo(e.schema)) i = i.concat(await zo(e.state, e.schema));
            else if (No(e.schema)) i = i.concat(await Vo(e.state, e.schema));
            else throw new Error("Form validation failed: Unsupported form schema");
            return i
        }
        async function s(i, d = {
            silent: !1
        }) {
            if (i) {
                const f = r.value.filter(p => p.path !== i),
                    m = (await l()).filter(p => p.path === i);
                r.value = f.concat(m)
            } else r.value = await l();
            if (!d.silent && r.value.length > 0) throw new tt(`Form validation failed: ${JSON.stringify(r.value,null,2)}`);
            return e.state
        }
        async function u(i) {
            var d;
            try {
                (d = e.validateOn) != null && d.includes("submit") && await s();
                const f = { ...i,
                    data: e.state
                };
                n("submit", f)
            } catch (f) {
                if (!(f instanceof tt)) throw f;
                const m = { ...i,
                    errors: r.value.map(p => ({ ...p,
                        id: o.value[p.path]
                    }))
                };
                n("error", m)
            }
        }
        return t({
            validate: s,
            errors: r,
            setErrors(i, d) {
                r.value = i, d ? r.value = r.value.filter(f => f.path !== d).concat(i) : r.value = i
            },
            getErrors(i) {
                return i ? r.value.filter(d => d.path === i) : r.value
            },
            clear(i) {
                i ? r.value = r.value.filter(d => d.path === i) : r.value = []
            }
        }), {
            onSubmit: u
        }
    }
});

function Oo(e) {
    return e.validate && e.__isYupSchema__
}

function Bo(e) {
    return e.inner !== void 0
}
async function Fo(e, t) {
    try {
        return await t.validate(e, {
            abortEarly: !1
        }), []
    } catch (n) {
        if (Bo(n)) return n.inner.map(a => ({
            path: a.path ? ? "",
            message: a.message
        }));
        throw n
    }
}

function Lo(e) {
    return e.parse !== void 0
}
async function Do(e, t) {
    const n = await t.safeParseAsync(e);
    return n.success === !1 ? n.error.issues.map(a => ({
        path: a.path.join("."),
        message: a.message
    })) : []
}

function jo(e) {
    return e.validateAsync !== void 0 && e.id !== void 0
}

function Po(e) {
    return e.isJoi === !0
}
async function zo(e, t) {
    try {
        return await t.validateAsync(e, {
            abortEarly: !1
        }), []
    } catch (n) {
        if (Po(n)) return n.details.map(a => ({
            path: a.path.join("."),
            message: a.message
        }));
        throw n
    }
}

function No(e) {
    return e._parse !== void 0
}
async function Vo(e, t) {
    const n = await t._parse(e);
    return n.issues ? n.issues.map(a => ({
        path: a.path.map(r => r.key).join("."),
        message: a.message
    })) : []
}

function Ro(e, t, n, a, r, o) {
    return b(), S("form", {
        onSubmit: t[0] || (t[0] = _t((...l) => e.onSubmit && e.onSubmit(...l), ["prevent"]))
    }, [L(e.$slots, "default")], 32)
}
const _a = he(Ao, [
        ["render", Ro]
    ]),
    ut = Wa("modal", () => {
        const e = w(!1),
            t = w(!1),
            n = w(!1);
        return {
            createModal: e,
            loginModal: t,
            deleteModal: n
        }
    }),
    Uo = c("div", {
        class: "mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-indigo-100 dark:bg-indigo-400"
    }, [c("svg", {
        class: "h-6 w-6 text-indigo-600 dark:text-indigo-800",
        fill: "none",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    }, [c("path", {
        d: "M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
    })])], -1),
    Ho = {
        class: "mt-3 text-center sm:mt-5"
    },
    qo = {
        class: "text-lg font-medium leading-6 text-gray-900 dark:text-gray-300"
    },
    Wo = {
        class: "mt-2"
    },
    Zo = {
        class: "text-sm leading-5 text-gray-500"
    },
    Yo = {
        key: 0,
        class: "mt-2 text-sm text-red-600 dark:text-red-400"
    },
    Ko = {
        class: "mt-5 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:mt-8 sm:gap-3"
    },
    Go = {
        class: "w-full flex rounded-md shadow-sm sm:col-start-2"
    },
    Jo = {
        type: "button",
        class: "w-full inline-flex justify-center border border-gray-300 rounded-md bg-white px-4 py-2 text-base font-medium leading-6 text-gray-700 shadow-sm transition dark:border-gray-800 focus:border-blue-300 dark:bg-gray-700 sm:text-sm sm:leading-5 dark:text-gray-300 hover:text-gray-500 focus:outline-none focus:ring-blue dark:hover:bg-gray-600/25"
    },
    Xo = F({
        __name: "Create",
        setup(e) {
            const {
                createModal: t
            } = Ae(ut());
            N(async () => {
                ze().getDomains.length || await ze().fetchDomains()
            });
            const n = h(() => {
                    var d;
                    return (d = ze().getDomains) == null ? void 0 : d.map(f => ({
                        label: f.domain,
                        value: f.domain
                    }))
                }),
                a = h(() => ze().getDomain ? ze().getDomain.domain : void 0),
                r = w(!0),
                o = $t({
                    username: void 0,
                    domain: a,
                    password: void 0
                }),
                l = w(!1);

            function s(d) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d)
            }

            function u(d) {
                const f = [];
                return d.username || f.push({
                    path: "address",
                    message: "Required"
                }), d.username && !s(`${d.username}@${d.domain}`) && f.push({
                    path: "address",
                    message: "Invalid email"
                }), d.password || f.push({
                    path: "password",
                    message: "Required"
                }), f
            }
            async function i() {
                if (!u(o).length) try {
                    await se().create(o.username, o.domain, o.password), t.value = !1
                } catch (f) {
                    l.value = f
                }
            }
            return (d, f) => {
                const m = _o,
                    p = $a,
                    g = xa,
                    v = Le,
                    x = _a,
                    I = rt,
                    A = it;
                return b(), j(A, {
                    modelValue: $(t),
                    "onUpdate:modelValue": f[6] || (f[6] = T => nt(t) ? t.value = T : null)
                }, {
                    default: k(() => [y(I, {
                        ui: {
                            background: "dark:bg-gray-800"
                        }
                    }, {
                        default: k(() => [c("div", {
                            onKeyup: f[4] || (f[4] = Zt((...T) => d.login && d.login(...T), ["enter"]))
                        }, [Uo, c("div", Ho, [c("h3", qo, _(d.$t("create.title")), 1), c("div", Wo, [c("p", Zo, _(d.$t("create.desc")), 1)])]), y(x, {
                            validate: u,
                            state: $(o),
                            class: "mt-4",
                            onSubmit: d.login
                        }, {
                            default: k(() => [y(g, {
                                size: "md",
                                label: d.$t("feature.email"),
                                type: "email",
                                name: "address",
                                error: ""
                            }, {
                                default: k(() => [y(p, {
                                    modelValue: $(o).username,
                                    "onUpdate:modelValue": f[1] || (f[1] = T => $(o).username = T),
                                    placeholder: "johndoe",
                                    icon: "i-heroicons-envelope",
                                    ui: {
                                        icon: {
                                            trailing: {
                                                pointer: "",
                                                padding: {
                                                    md: "pe-0"
                                                }
                                            }
                                        }
                                    },
                                    required: ""
                                }, {
                                    trailing: k(() => [y(m, {
                                        modelValue: $(o).domain,
                                        "onUpdate:modelValue": f[0] || (f[0] = T => $(o).domain = T),
                                        options: $(n)
                                    }, null, 8, ["modelValue", "options"])]),
                                    _: 1
                                }, 8, ["modelValue"])]),
                                _: 1
                            }, 8, ["label"]), y(g, {
                                size: "md",
                                label: d.$t("feature.password"),
                                name: "password",
                                class: "mt-5",
                                error: ""
                            }, {
                                default: k(() => [y(p, {
                                    modelValue: $(o).password,
                                    "onUpdate:modelValue": f[3] || (f[3] = T => $(o).password = T),
                                    type: $(r) ? "password" : "text",
                                    placeholder: "******",
                                    icon: "i-heroicons-key",
                                    ui: {
                                        icon: {
                                            trailing: {
                                                pointer: ""
                                            }
                                        }
                                    }
                                }, {
                                    trailing: k(() => [y(v, {
                                        color: "gray",
                                        variant: "link",
                                        icon: $(r) ? "i-heroicons-eye-slash" : "i-heroicons-eye",
                                        padded: !1,
                                        onClick: f[2] || (f[2] = T => r.value = !$(r))
                                    }, null, 8, ["icon"])]),
                                    _: 1
                                }, 8, ["modelValue", "type"])]),
                                _: 1
                            }, 8, ["label"])]),
                            _: 1
                        }, 8, ["state", "onSubmit"]), $(l) ? (b(), S("p", Yo, _(d.$t("view.error")) + ": " + _($(l)), 1)) : O("", !0)], 32), c("div", Ko, [c("span", Go, [c("button", {
                            type: "button",
                            class: "w-full inline-flex justify-center border border-transparent rounded-md bg-indigo-600 px-4 py-2 text-base font-medium leading-6 text-white shadow-sm transition focus:border-indigo-700 dark:bg-indigo-700 hover:bg-indigo-500 sm:text-sm sm:leading-5 focus:outline-none focus:ring-indigo dark:hover:bg-indigo-800",
                            onClick: i
                        }, _(d.$t("create.short")), 1)]), c("span", {
                            class: "mt-3 w-full flex rounded-md shadow-sm sm:col-start-1 sm:mt-0",
                            onClick: f[5] || (f[5] = T => t.value = !1)
                        }, [c("button", Jo, _(d.$t("feature.cancel")), 1)])])]),
                        _: 1
                    })]),
                    _: 1
                }, 8, ["modelValue"])
            }
        }
    }),
    Qo = {
        class: "sm:flex sm:items-start"
    },
    el = c("div", {
        class: "mx-auto h-12 w-12 flex flex-shrink-0 items-center justify-center rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10"
    }, [c("svg", {
        class: "h-6 w-6 text-red-600",
        stroke: "currentColor",
        fill: "none",
        viewBox: "0 0 24 24"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
    })])], -1),
    tl = {
        class: "mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left"
    },
    al = {
        id: "modal-headline",
        class: "text-lg font-medium leading-6 text-gray-900 dark:text-gray-300"
    },
    nl = {
        class: "mt-2"
    },
    rl = {
        class: "text-sm leading-5 text-gray-500 dark:text-gray-400"
    },
    ol = {
        __name: "Delete",
        setup(e) {
            const {
                deleteModal: t
            } = Ae(ut());

            function n() {
                t.value = !1, se().destroy()
            }
            return (a, r) => {
                const o = rt,
                    l = it;
                return b(), j(l, {
                    modelValue: $(t),
                    "onUpdate:modelValue": r[1] || (r[1] = s => nt(t) ? t.value = s : null)
                }, {
                    default: k(() => [y(o, {
                        ui: {
                            divide: "divide-y-0",
                            background: "dark:bg-gray-800",
                            body: {
                                padding: "px-4 pb-4 pt-5 sm:p-6 sm:pb-4"
                            },
                            footer: {
                                padding: " bg-gray-50 dark:bg-gray-900/40 mt-5 sm:mt-4 sm:flex sm:flex-row-reverse"
                            }
                        }
                    }, {
                        footer: k(() => [c("button", {
                            type: "button",
                            class: "w-full inline-flex justify-center rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm sm:ml-3 sm:w-auto hover:bg-red-500 dark:text-red-100 dark:hover:bg-red-700",
                            onClick: _t(n, ["prevent"])
                        }, _(a.$t("destroy.short")), 1), c("button", {
                            type: "button",
                            class: "w-full inline-flex justify-center rounded-md bg-white px-4 py-2 text-sm text-gray-900 shadow-sm ring-1 ring-gray-300 ring-inset sm:mt-0 sm:w-auto dark:bg-gray-700 hover:bg-gray-50 dark:text-gray-300 dark:ring-0 dark:focus:border-gray-900 dark-active:bg-gray-900 dark:hover:bg-gray-700/50 dark:focus:outline-none dark:focus:ring-gray",
                            onClick: r[0] || (r[0] = s => t.value = !1)
                        }, _(a.$t("feature.cancel")), 1)]),
                        default: k(() => [c("div", Qo, [el, c("div", tl, [c("h3", al, _(a.$t("destroy.title")), 1), c("div", nl, [c("p", rl, _(a.$t("destroy.desc")), 1)])])])]),
                        _: 1
                    })]),
                    _: 1
                }, 8, ["modelValue"])
            }
        }
    },
    ll = c("div", {
        class: "mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-indigo-100 dark:bg-indigo-400"
    }, [c("svg", {
        class: "h-6 w-6 text-indigo-600 dark:text-indigo-800",
        fill: "none",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    }, [c("path", {
        d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
    })])], -1),
    sl = {
        class: "mt-3 text-center sm:mt-5"
    },
    il = {
        class: "text-lg font-medium leading-6 text-gray-900 dark:text-gray-300"
    },
    ul = {
        class: "mt-2"
    },
    dl = {
        class: "text-sm leading-5 text-gray-500"
    },
    cl = {
        key: 0,
        class: "mt-2 text-sm text-red-600 dark:text-red-400"
    },
    fl = {
        class: "mt-5 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:mt-8 sm:gap-3"
    },
    ml = {
        class: "w-full flex rounded-md shadow-sm sm:col-start-2"
    },
    vl = {
        type: "button",
        class: "w-full inline-flex justify-center border border-gray-300 rounded-md bg-white px-4 py-2 text-base font-medium leading-6 text-gray-700 shadow-sm transition dark:border-gray-800 focus:border-blue-300 dark:bg-gray-700 sm:text-sm sm:leading-5 dark:text-gray-300 hover:text-gray-500 focus:outline-none focus:ring-blue dark:hover:bg-gray-600/25"
    },
    gl = F({
        __name: "Login",
        setup(e) {
            const {
                loginModal: t
            } = Ae(ut()), n = w(!0), a = $t({
                address: void 0,
                password: void 0
            }), r = w(!1);

            function o(u) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(u)
            }

            function l(u) {
                const i = [];
                return r.value = !1, u.address || i.push({
                    path: "address",
                    message: "Required"
                }), u.address && !o(u.address) && i.push({
                    path: "address",
                    message: "Invalid email"
                }), u.password || i.push({
                    path: "password",
                    message: "Required"
                }), i
            }
            async function s() {
                if (!l(a).length) try {
                    await se().login(a), t.value = !1
                } catch (i) {
                    r.value = i
                }
            }
            return (u, i) => {
                const d = $a,
                    f = xa,
                    m = Le,
                    p = _a,
                    g = rt,
                    v = it;
                return b(), j(v, {
                    modelValue: $(t),
                    "onUpdate:modelValue": i[4] || (i[4] = x => nt(t) ? t.value = x : null)
                }, {
                    default: k(() => [y(g, {
                        ui: {
                            background: "dark:bg-gray-800"
                        }
                    }, {
                        default: k(() => [c("div", {
                            onKeyup: Zt(s, ["enter"])
                        }, [ll, c("div", sl, [c("h3", il, _(u.$t("login.title")), 1), c("div", ul, [c("p", dl, _(u.$t("login.desc")), 1)])]), y(p, {
                            validate: l,
                            state: $(a),
                            class: "mt-4",
                            onSubmit: u.onSubmit
                        }, {
                            default: k(() => [y(f, {
                                size: "md",
                                label: u.$t("feature.email"),
                                type: "email",
                                name: "address",
                                error: ""
                            }, {
                                default: k(() => [y(d, {
                                    modelValue: $(a).address,
                                    "onUpdate:modelValue": i[0] || (i[0] = x => $(a).address = x),
                                    placeholder: "test@test.com",
                                    icon: "i-heroicons-envelope",
                                    required: ""
                                }, null, 8, ["modelValue"])]),
                                _: 1
                            }, 8, ["label"]), y(f, {
                                size: "md",
                                label: u.$t("feature.password"),
                                name: "password",
                                class: "mt-5",
                                error: ""
                            }, {
                                default: k(() => [y(d, {
                                    modelValue: $(a).password,
                                    "onUpdate:modelValue": i[2] || (i[2] = x => $(a).password = x),
                                    type: $(n) ? "password" : "text",
                                    placeholder: "******",
                                    icon: "i-heroicons-key",
                                    ui: {
                                        icon: {
                                            trailing: {
                                                pointer: ""
                                            }
                                        }
                                    }
                                }, {
                                    trailing: k(() => [y(m, {
                                        color: "gray",
                                        variant: "link",
                                        icon: $(n) ? "i-heroicons-eye-slash" : "i-heroicons-eye",
                                        padded: !1,
                                        onClick: i[1] || (i[1] = x => n.value = !$(n))
                                    }, null, 8, ["icon"])]),
                                    _: 1
                                }, 8, ["modelValue", "type"])]),
                                _: 1
                            }, 8, ["label"])]),
                            _: 1
                        }, 8, ["state", "onSubmit"]), $(r) ? (b(), S("p", cl, _(u.$t("view.error")) + ": " + _($(r)), 1)) : O("", !0)], 32), c("div", fl, [c("span", ml, [c("button", {
                            type: "button",
                            class: "w-full inline-flex justify-center border border-transparent rounded-md bg-indigo-600 px-4 py-2 text-base font-medium leading-6 text-white shadow-sm transition focus:border-indigo-700 dark:bg-indigo-700 hover:bg-indigo-500 sm:text-sm sm:leading-5 focus:outline-none focus:ring-indigo dark:hover:bg-indigo-800",
                            onClick: s
                        }, _(u.$t("login.short")), 1)]), c("span", {
                            class: "mt-3 w-full flex rounded-md shadow-sm sm:col-start-1 sm:mt-0",
                            onClick: i[3] || (i[3] = x => t.value = !1)
                        }, [c("button", vl, _(u.$t("feature.cancel")), 1)])])]),
                        _: 1
                    })]),
                    _: 1
                }, 8, ["modelValue"])
            }
        }
    });
const pl = {
        class: "break-all text-left"
    },
    hl = {
        class: "text-sm leading-5 text-gray-700 dark:text-gray-400"
    },
    yl = {
        class: "cursor-pointer select-all text-sm font-medium leading-5 text-gray-800 dark:text-gray-200"
    },
    bl = {
        class: "text-sm leading-5 text-gray-700 dark:text-gray-400"
    },
    kl = {
        class: "truncate"
    },
    wl = {
        __name: "Accounts",
        setup(e) {
            const {
                t
            } = qt(), n = w(!0), {
                createModal: a,
                deleteModal: r,
                loginModal: o
            } = Ae(ut());

            function l() {
                n.value = !n.value
            }
            const {
                active: s
            } = Ae(se()), u = h(() => {
                var d;
                return (d = s.value) != null && d.address ? s.value : {
                    address: "...",
                    password: "..."
                }
            }), i = h(() => {
                const d = [
                    [{
                        slot: "account",
                        disabled: !0
                    }],
                    [{
                        label: t("create.title"),
                        icon: "i-heroicons-user-plus-20-solid",
                        click: () => {
                            a.value = !0
                        }
                    }, {
                        label: t("login.short"),
                        icon: "i-heroicons-user-20-solid",
                        click: () => {
                            o.value = !0
                        }
                    }, {
                        label: t("destroy.title"),
                        icon: "i-heroicons-trash-20-solid",
                        click: () => {
                            r.value = !0
                        }
                    }],
                    [{
                        label: t("logout.short"),
                        icon: "i-heroicons-arrow-right-on-rectangle-20-solid",
                        click: () => {
                            se().logout()
                        }
                    }]
                ];
                if (se().getList.length > 0) {
                    const f = se().getList.map(m => ({
                        slot: "accountList",
                        label: m.address,
                        click: () => {
                            se().login(m)
                        }
                    }));
                    d.findIndex(m => m[0].slot === "list") === -1 && d.splice(1, 0, f)
                } else d.splice(d.findIndex(f => f[0].slot === "list"), 1);
                return d
            });
            return (d, f) => {
                const m = xt,
                    p = Le,
                    g = je,
                    v = ba,
                    x = Xo,
                    I = ol,
                    A = gl;
                return b(), S(Q, null, [y(v, {
                    items: $(i),
                    popper: {
                        placement: "bottom-start"
                    },
                    ui: {
                        width: "w-56",
                        item: {
                            disabled: "cursor-text select-text opacity-100"
                        },
                        padding: "overflow-y-auto max-h-48"
                    }
                }, {
                    account: k(() => [c("div", pl, [c("p", hl, _($(t)("feature.signed")) + ": ", 1), c("p", yl, _($(u).address), 1), c("p", bl, [X(_($(t)("feature.password")) + ": ", 1), c("span", {
                        class: C(["cursor-pointer select-all", {
                            "account-blur": $(n)
                        }]),
                        onClick: l
                    }, _($(u).password), 3)])])]),
                    accountList: k(({
                        item: T
                    }) => [y(m, {
                        alt: T.label.toUpperCase(),
                        size: "xs",
                        ui: {
                            background: " bg-gray-200 dark:bg-gray-700",
                            placeholder: "font-medium leading-none text-gray-600 dark:text-gray-300 truncate"
                        }
                    }, null, 8, ["alt"]), c("span", kl, _(T.label), 1)]),
                    default: k(() => [y(g, {
                        text: $(t)("feature.account")
                    }, {
                        default: k(() => [y(p, {
                            color: "gray",
                            class: "group flex-1 justify-between",
                            variant: "link",
                            "aria-label": $(t)("logout.short"),
                            title: $(t)("logout.short")
                        }, {
                            default: k(() => [y(m, {
                                alt: $(u).address.toUpperCase(),
                                size: "xs",
                                ui: {
                                    background: " bg-gray-200 dark:bg-gray-700 dark:group-hover:bg-gray-600 group-hover:bg-gray-600",
                                    placeholder: "font-medium leading-none text-gray-600 dark:text-gray-300 dark:group-hover:text-white group-hover:text-white truncate"
                                }
                            }, null, 8, ["alt"])]),
                            _: 1
                        }, 8, ["aria-label", "title"])]),
                        _: 1
                    }, 8, ["text"])]),
                    _: 1
                }, 8, ["items"]), $(a) ? (b(), j(x, {
                    key: 0
                })) : O("", !0), $(r) ? (b(), j(I, {
                    key: 1
                })) : O("", !0), $(o) ? (b(), j(A, {
                    key: 2
                })) : O("", !0)], 64)
            }
        }
    },
    $l = he(wl, [
        ["__scopeId", "data-v-20a00b4a"]
    ]),
    xl = c("svg", {
        class: "h-6 w-6",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
    })], -1),
    _l = {
        __name: "Logout",
        setup(e) {
            async function t() {
                await se().logout()
            }
            return (n, a) => {
                const r = Le,
                    o = je;
                return b(), j(o, {
                    text: n.$t("logout.title")
                }, {
                    default: k(() => [y(r, {
                        color: "gray",
                        class: "flex-1 justify-between hover:text-purple-600 dark:hover:text-purple-500",
                        variant: "link",
                        "aria-label": n.$t("logout.short"),
                        title: n.$t("logout.short"),
                        onClick: t
                    }, {
                        default: k(() => [xl]),
                        _: 1
                    }, 8, ["aria-label", "title"])]),
                    _: 1
                }, 8, ["text"])
            }
        }
    },
    Sl = {
        class: "h-screen flex overflow-hidden bg-gray-100 antialiased dark:bg-gray-900"
    },
    Ml = {
        key: 0,
        class: "md:hidden"
    },
    Cl = {
        class: "fixed inset-0 z-40 flex"
    },
    Il = c("div", {
        class: "absolute inset-0 bg-gray-600 opacity-75 dark:bg-gray-800"
    }, null, -1),
    El = [Il],
    Tl = {
        key: 0,
        class: "relative max-w-xs w-full flex flex-1 flex-col bg-white pb-4 pt-5 dark:bg-gray-900"
    },
    Al = {
        class: "absolute right-0 top-0 p-1 -mr-14"
    },
    Ol = c("svg", {
        class: "h-6 w-6 text-white dark:text-gray-300",
        stroke: "currentColor",
        fill: "none",
        viewBox: "0 0 24 24"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M6 18L18 6M6 6l12 12"
    })], -1),
    Bl = [Ol],
    Fl = {
        class: "flex flex-shrink-0 items-center px-4"
    },
    Ll = {
        class: "mt-5 h-0 flex-1 overflow-y-auto"
    },
    Dl = {
        class: "px-2"
    },
    jl = c("path", {
        d: "M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
    }, null, -1),
    Pl = [jl],
    zl = c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
    }, null, -1),
    Nl = [zl],
    Vl = c("a", {
        href: "https://docs.mail.tm",
        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-base font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
    }, [c("span", {
        class: "truncate"
    }, " API ")], -1),
    Rl = {
        class: "truncate"
    },
    Ul = {
        class: "truncate"
    },
    Hl = {
        class: "truncate"
    },
    ql = {
        class: "truncate"
    },
    Wl = c("a", {
        href: "https://mail.gw",
        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-base font-medium leading-5 text-purple-800 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-purple-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
    }, [c("span", {
        class: "truncate"
    }, " Mail.gw ")], -1),
    Zl = c("div", {
        class: "w-14 flex-shrink-0"
    }, null, -1),
    Yl = {
        class: "hidden md:flex md:flex-shrink-0"
    },
    Kl = {
        class: "w-64 flex flex-col overflow-y-auto border-r border-gray-200 bg-white pb-4 pt-5 dark:border-gray-700 dark:bg-gray-900"
    },
    Gl = {
        class: "flex flex-shrink-0 items-center px-4"
    },
    Jl = {
        class: "mb-2 mt-5 flex flex-1 flex-col px-2"
    },
    Xl = {
        class: "flex-1"
    },
    Ql = c("path", {
        d: "M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
    }, null, -1),
    es = [Ql],
    ts = c("path", {
        fill: "none",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M19.4 9h.6V4m-.6 5c-1.2-2.9-4.1-5-7.4-5-4.1 0-7.5 3.1-8 7m10.9-2h4.4M4.6 15h-.5v5M20 13c-.5 3.9-3.9 7-7.9 7-3.4 0-6.2-2.1-7.4-5m4.4 0H4.6"
    }, null, -1),
    as = [ts],
    ns = {
        class: "mb-2 mt-2 px-2"
    },
    rs = c("a", {
        href: "https://docs.mail.tm",
        class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
    }, [c("span", {
        class: "truncate"
    }, " API ")], -1),
    os = {
        class: "truncate"
    },
    ls = {
        class: "truncate"
    },
    ss = {
        class: "truncate"
    },
    is = {
        class: "truncate"
    },
    us = c("a", {
        href: "https://mail.gw",
        class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-purple-800 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-purple-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
    }, [c("span", {
        class: "truncate"
    }, " Mail.gw ")], -1),
    ds = {
        class: "flex flex-shrink-0 border-t border-gray-200 px-4 pt-4 dark:border-gray-700"
    },
    cs = {
        class: "mt-8 md:order-1 md:mt-0"
    },
    fs = {
        class: "flex flex-col justify-center md:order-2"
    },
    ms = {
        class: "text-center text-sm leading-6 text-gray-500 dark:text-gray-400"
    },
    vs = c("div", {
        class: "px-4 text-[10px] text-gray-400 space-x-2"
    }, [c("a", {
        href: "#",
        onclick: "window.__uspapi('displayUspUi');"
    }, "Do Not Sell My Personal Information"), c("a", {
        href: "#",
        onclick: "window.__tcfapi('displayConsentUi', 2, function() {} );"
    }, "Change Consent")], -1),
    gs = {
        class: "w-0 flex flex-1 flex-col overflow-hidden"
    },
    ps = {
        class: "relative h-16 flex flex-shrink-0 items-center border-b border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-900"
    },
    hs = c("svg", {
        class: "h-6 w-6",
        stroke: "currentColor",
        fill: "none",
        viewBox: "0 0 24 24"
    }, [c("path", {
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "stroke-width": "2",
        d: "M4 6h16M4 12h16M4 18h7"
    })], -1),
    ys = [hs],
    bs = {
        class: "flex flex-1 justify-between px-4"
    },
    ks = {
        class: "flex items-center md:ml-6 sm:ml-4"
    },
    ws = {
        class: "relative z-0 flex-1 overflow-y-auto py-6 focus:outline-none",
        tabindex: "0"
    },
    we = "bg-gray-100 dark:bg-gray-800",
    Ss = F({
        __name: "default",
        setup(e) {
            const t = Za({
                addSeoAttributes: !0
            });
            Ya({
                htmlAttrs: {
                    lang: t.value.htmlAttrs.lang
                },
                link: [...t.value.link || []],
                meta: [...t.value.meta || []]
            });
            const n = w(!1);

            function a(u) {
                n.value = u
            }
            const r = w(!1),
                o = w(!1);

            function l() {
                o.value = !0, setTimeout(() => o.value = !1, 700)
            }
            async function s() {
                r.value = !0, setTimeout(() => r.value = !1, 500), await Ka().fetchMessages()
            }
            return (u, i) => {
                const d = nn,
                    f = at,
                    m = yn,
                    p = St,
                    g = $n,
                    v = Ln,
                    x = ao,
                    I = io,
                    A = po,
                    T = $l,
                    oe = _l;
                return b(), S("div", Sl, [$(n) ? (b(), S("div", Ml, [c("div", Cl, [y(vt, {
                    "enter-active-class": "transition-opacity duration-300 ease-linear",
                    "enter-class": "opacity-0",
                    "enter-to-class": "opacity-100",
                    "leave-active-class": "transition-opacity duration-300 ease-linear",
                    "leave-class": "opacity-100",
                    "leave-to-class": "opacity-0"
                }, {
                    default: k(() => [$(n) ? (b(), S("div", {
                        key: 0,
                        class: "fixed inset-0 transition-opacity duration-300 ease-linear",
                        onClick: i[0] || (i[0] = G => a(!1))
                    }, El)) : O("", !0)]),
                    _: 1
                }), y(vt, {
                    "enter-active-class": "transition duration-300 ease-in-out transform",
                    "enter-class": "-translate-x-full",
                    "enter-to-class": "translate-x-0",
                    "leave-active-class": "transition duration-300 ease-in-out transform",
                    "leave-class": "translate-x-0",
                    "leave-to-class": "-translate-x-full"
                }, {
                    default: k(() => [$(n) ? (b(), S("div", Tl, [c("div", Al, [c("button", {
                        class: "h-12 w-12 flex items-center justify-center rounded-full focus:bg-gray-600 focus:outline-none",
                        "aria-label": "Close sidebar",
                        onClick: i[1] || (i[1] = G => a(!1))
                    }, Bl)]), c("div", Fl, [y(d)]), c("div", Ll, [c("nav", Dl, [y(f, {
                        to: u.localePath("index"),
                        class: "group flex items-center rounded-md px-2 py-2 text-base font-medium leading-5 text-gray-900 transition hover:bg-gray-100 dark:text-gray-300 hover:text-gray-900 dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none",
                        onClick: l
                    }, {
                        default: k(() => [(b(), S("svg", {
                            fill: "none",
                            "stroke-linecap": "round",
                            class: C(["mr-4 h-6 w-6 text-gray-500 transition dark:text-gray-300 dark:text-gray-400 group-focus:text-gray-600 group-hover:text-gray-500 dark:group-focus:text-gray-300 dark:group-hover:text-gray-300", {
                                "animate-bounce": $(o)
                            }]),
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor"
                        }, Pl, 2)), X(" " + _(u.$t("feature.inbox")), 1)]),
                        _: 1
                    }, 8, ["to"]), y(f, {
                        to: u.localePath("index"),
                        class: "group mt-1 flex items-center rounded-md px-2 py-2 text-base font-medium leading-5 text-gray-600 transition hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none",
                        onClick: s
                    }, {
                        default: k(() => [(b(), S("svg", {
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            class: C(["mr-4 h-6 w-6 text-gray-400 transition dark:text-gray-400 group-focus:text-gray-500 group-hover:text-gray-500 dark:group-focus:text-gray-300 dark:group-hover:text-gray-300", {
                                "animate-spin": $(r)
                            }])
                        }, Nl, 2)), X(" " + _(u.$t("feature.refresh")), 1)]),
                        _: 1
                    }, 8, ["to"]), Vl, y(f, {
                        to: u.localePath("faq"),
                        "active-class": we,
                        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                    }, {
                        default: k(() => [c("span", Rl, _(u.$t("faq.short")), 1)]),
                        _: 1
                    }, 8, ["to"]), y(f, {
                        to: u.localePath("privacy"),
                        "active-class": we,
                        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-base font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                    }, {
                        default: k(() => [c("span", Ul, _(u.$t("privacy.short")), 1)]),
                        _: 1
                    }, 8, ["to"]), y(f, {
                        to: u.localePath("feedback"),
                        "active-class": we,
                        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-base font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none",
                        onClick: i[2] || (i[2] = G => a(!1))
                    }, {
                        default: k(() => [c("span", Hl, _(u.$t("feedback.short")), 1)]),
                        _: 1
                    }, 8, ["to"]), y(f, {
                        to: u.localePath("contact"),
                        "active-class": we,
                        class: "group mt-1 flex items-center rounded-md px-3 py-2 text-base font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                    }, {
                        default: k(() => [c("span", ql, _(u.$t("contact.short")), 1)]),
                        _: 1
                    }, 8, ["to"]), Wl, y(p, null, {
                        default: k(() => [y(m)]),
                        _: 1
                    })])])])) : O("", !0)]),
                    _: 1
                }), Zl])])) : O("", !0), c("div", Yl, [c("div", Kl, [c("div", Gl, [y(d)]), c("div", Jl, [c("nav", Xl, [y(f, {
                    to: u.localePath("index"),
                    class: "group flex items-center rounded-md px-2 py-2 text-sm font-medium leading-5 text-gray-900 transition hover:bg-gray-100 dark:text-gray-300 hover:text-gray-900 dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none",
                    onClick: l
                }, {
                    default: k(() => [(b(), S("svg", {
                        fill: "none",
                        "stroke-linecap": "round",
                        class: C(["mr-3 h-6 w-6 text-gray-500 transition dark:text-gray-300 dark:text-gray-400 group-focus:text-gray-600 group-hover:text-gray-500 dark:group-focus:text-gray-300 dark:group-hover:text-gray-300", {
                            "animate-bounce": $(o)
                        }]),
                        "stroke-linejoin": "round",
                        "stroke-width": "2",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor"
                    }, es, 2)), X(" " + _(u.$t("feature.inbox")), 1)]),
                    _: 1
                }, 8, ["to"]), y(f, {
                    to: u.localePath("index"),
                    class: "group mt-1 flex items-center rounded-md px-2 py-2 text-sm font-medium leading-5 text-gray-600 transition hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none",
                    onClick: s
                }, {
                    default: k(() => [(b(), S("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        "xml:space": "preserve",
                        viewBox: "0 0 24 24",
                        stroke: "currentColor",
                        class: C(["mr-3 h-6 w-6 text-gray-400 transition dark:text-gray-400 group-focus:text-gray-500 group-hover:text-gray-500 dark:group-focus:text-gray-300 dark:group-hover:text-gray-300", {
                            "animate-spin": $(r)
                        }])
                    }, as, 2)), X(" " + _(u.$t("feature.refresh")), 1)]),
                    _: 1
                }, 8, ["to"])])]), y(g), c("div", ns, [rs, y(f, {
                    to: u.localePath("faq"),
                    "active-class": we,
                    class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                }, {
                    default: k(() => [c("span", os, _(u.$t("faq.short")), 1)]),
                    _: 1
                }, 8, ["to"]), y(f, {
                    to: u.localePath("privacy"),
                    "active-class": we,
                    class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                }, {
                    default: k(() => [c("span", ls, _(u.$t("privacy.short")), 1)]),
                    _: 1
                }, 8, ["to"]), y(f, {
                    to: u.localePath("feedback"),
                    "active-class": we,
                    class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                }, {
                    default: k(() => [c("span", ss, _(u.$t("feedback.short")), 1)]),
                    _: 1
                }, 8, ["to"]), y(f, {
                    to: u.localePath("contact"),
                    "active-class": we,
                    class: "group flex items-center rounded-md px-3 py-2 text-sm font-medium leading-5 text-gray-600 transition focus:bg-gray-100 hover:bg-gray-50 dark:text-gray-300 hover:text-gray-900 focus:outline-none dark:focus:bg-gray-800 dark:hover:bg-gray-800 dark:focus:text-white dark:hover:text-white dark:focus:outline-none"
                }, {
                    default: k(() => [c("span", is, _(u.$t("contact.short")), 1)]),
                    _: 1
                }, 8, ["to"]), us, y(p, null, {
                    default: k(() => [y(m)]),
                    _: 1
                })]), c("div", ds, [c("div", cs, [c("div", fs, [c("p", ms, " © " + _(new Date().getFullYear()) + " Mail.tm ", 1)])])]), vs])]), c("div", gs, [y(p, null, {
                    default: k(() => [c("div", ps, [c("button", {
                        class: "border-r border-gray-200 px-4 text-gray-500 md:hidden dark:border-gray-600 focus:bg-gray-100 focus:text-gray-600 focus:outline-none dark:focus:bg-gray-900 dark:focus:text-gray-400",
                        "aria-label": "Open sidebar",
                        onClick: i[3] || (i[3] = _t(G => a(!0), ["stop"]))
                    }, ys), c("div", bs, [y(v), c("div", ks, [y(x), y(I), y(A), y(T), y(oe)])])])]),
                    _: 1
                }), c("main", ws, [L(u.$slots, "default")])])])
            }
        }
    });
export {
    Ss as
    default
};