if (!self.define) {
    let n, e = {};
    const l = (l, i) => (l = new URL(l + ".js", i).href, e[l] || new Promise((e => {
        if ("document" in self) {
            const n = document.createElement("script");
            n.src = l, n.onload = e, document.head.appendChild(n)
        } else n = l, importScripts(l), e()
    })).then((() => {
        let n = e[l];
        if (!n) throw new Error(`Module ${l} didn’t register its module`);
        return n
    })));
    self.define = (i, u) => {
        const s = n || ("document" in self ? document.currentScript.src : "") || location.href;
        if (e[s]) return;
        let r = {};
        const o = n => l(n, s),
            t = {
                module: {
                    uri: s
                },
                exports: r,
                require: o
            };
        e[s] = Promise.all(i.map((n => t[n] || o(n)))).then((n => (u(...n), r)))
    }
}
define(["./workbox-c0002b4a"], (function(n) {
    "use strict";
    self.skipWaiting(), n.clientsClaim(), n.precacheAndRoute([{
        url: "_nuxt/_...all_.8a9b27e5.js",
        revision: null
    }, {
        url: "_nuxt/_id_.aee15b9d.js",
        revision: null
    }, {
        url: "_nuxt/_id_.c0bba723.js",
        revision: null
    }, {
        url: "_nuxt/ar.26d9c66a.js",
        revision: null
    }, {
        url: "_nuxt/Back.6f380bb5.js",
        revision: null
    }, {
        url: "_nuxt/client-only.be8c7cca.js",
        revision: null
    }, {
        url: "_nuxt/de.e4b24b9e.js",
        revision: null
    }, {
        url: "_nuxt/default.54fbe86f.js",
        revision: null
    }, {
        url: "_nuxt/default.a93f0aa5.css",
        revision: null
    }, {
        url: "_nuxt/en.ea093e64.js",
        revision: null
    }, {
        url: "_nuxt/entry.254837ee.css",
        revision: null
    }, {
        url: "_nuxt/entry.43614be6.js",
        revision: null
    }, {
        url: "_nuxt/error-404.871584dc.css",
        revision: null
    }, {
        url: "_nuxt/error-404.bfb6aae2.js",
        revision: null
    }, {
        url: "_nuxt/error-500.5504fd74.css",
        revision: null
    }, {
        url: "_nuxt/error-500.b91575b5.js",
        revision: null
    }, {
        url: "_nuxt/error.d4c5cb83.js",
        revision: null
    }, {
        url: "_nuxt/es.1a5a9219.js",
        revision: null
    }, {
        url: "_nuxt/fr.bd1b771d.js",
        revision: null
    }, {
        url: "_nuxt/IconCSS.9ed40f66.css",
        revision: null
    }, {
        url: "_nuxt/IconCSS.ecb2127c.js",
        revision: null
    }, {
        url: "_nuxt/index.008dc6b4.css",
        revision: null
    }, {
        url: "_nuxt/index.1bdff377.css",
        revision: null
    }, {
        url: "_nuxt/index.2979365a.js",
        revision: null
    }, {
        url: "_nuxt/index.8b5d3f63.js",
        revision: null
    }, {
        url: "_nuxt/index.d5498dd1.js",
        revision: null
    }, {
        url: "_nuxt/index.d7d98898.js",
        revision: null
    }, {
        url: "_nuxt/index.e7cd235d.js",
        revision: null
    }, {
        url: "_nuxt/it.ad36b380.js",
        revision: null
    }, {
        url: "_nuxt/ja.a32ba470.js",
        revision: null
    }, {
        url: "_nuxt/ko.539483bc.js",
        revision: null
    }, {
        url: "_nuxt/pl.1e4edd89.js",
        revision: null
    }, {
        url: "_nuxt/pt.2a63f5b8.js",
        revision: null
    }, {
        url: "_nuxt/ru.710ed566.js",
        revision: null
    }, {
        url: "_nuxt/th.4efa6d9d.js",
        revision: null
    }, {
        url: "_nuxt/Title.b270e0d6.js",
        revision: null
    }, {
        url: "_nuxt/Tooltip.06538c8d.js",
        revision: null
    }, {
        url: "_nuxt/tr.e223ce9e.js",
        revision: null
    }, {
        url: "_nuxt/uk.58b83978.js",
        revision: null
    }, {
        url: "_nuxt/vi.ec9fa1d5.js",
        revision: null
    }, {
        url: "_nuxt/workbox-window.prod.es5.a7b12eab.js",
        revision: null
    }, {
        url: "_nuxt/zh.0e6fd766.js",
        revision: null
    }, {
        url: "apple-touch-icon.png",
        revision: "f7bc89b3bcc75eae2254b1ec4b4748aa"
    }, {
        url: "favicon-16x16.png",
        revision: "d24cd8c2b4aad76e2f4c1b2d9e255e94"
    }, {
        url: "favicon-32x32.png",
        revision: "d79594aa0dd8a8b47e82031ceda1457f"
    }, {
        url: "favicon.ico",
        revision: "e667533132e05c6016be0a7736983f07"
    }, {
        url: "favicon.png",
        revision: "19e25751a0c5cf9d79615c41e4753233"
    }, {
        url: "img/envelope.svg",
        revision: "7bfa9931d4efd0cd46c4eeb008d0aab5"
    }, {
        url: "img/logos/favicon.svg",
        revision: "775b6ab919b892c61a4d0211b3c2534d"
    }, {
        url: "img/logos/logo-dark.svg",
        revision: "d3cb078f90f59ed27ffe80ee521d46aa"
    }, {
        url: "img/logos/logo-white.svg",
        revision: "126fad72d6643969e95c86e732958c97"
    }, {
        url: "img/logos/mail.svg",
        revision: "89ae115eec279a4aa4f17db113131335"
    }, {
        url: "img/mailtm.png",
        revision: "176d87d326fef484593a530183563cce"
    }, {
        url: "mailtm.png",
        revision: "176d87d326fef484593a530183563cce"
    }, {
        url: "pwa-192x192.png",
        revision: "21bd71b46682f453dc433acbebb09b1d"
    }, {
        url: "pwa-512x512.png",
        revision: "e9bec4bbbf1bf972bd935f394aa89269"
    }, {
        url: "robots.txt",
        revision: "ce93eca91075cca6e13e9574775bd42f"
    }, {
        url: "_nuxt/builds/latest.json",
        revision: null
    }, {
        url: "_nuxt/builds/meta/8c2473c5-2989-4d49-b5a3-c8fc14ca9e69.json",
        revision: null
    }, {
        url: "manifest.webmanifest",
        revision: "4dd522688e2f0cbc3951bdb82ab4a861"
    }], {}), n.cleanupOutdatedCaches(), n.registerRoute(new n.NavigationRoute(n.createHandlerBoundToURL("/"), {
        denylist: [/^\/api\//]
    })), n.registerRoute(/^https:\/\/fonts.googleapis.com\/.*/i, new n.CacheFirst({
        cacheName: "google-fonts-cache",
        plugins: [new n.ExpirationPlugin({
            maxEntries: 10,
            maxAgeSeconds: 31536e3
        }), new n.CacheableResponsePlugin({
            statuses: [0, 200]
        })]
    }), "GET"), n.registerRoute(/^https:\/\/fonts.gstatic.com\/.*/i, new n.CacheFirst({
        cacheName: "gstatic-fonts-cache",
        plugins: [new n.ExpirationPlugin({
            maxEntries: 10,
            maxAgeSeconds: 31536e3
        }), new n.CacheableResponsePlugin({
            statuses: [0, 200]
        })]
    }), "GET")
}));