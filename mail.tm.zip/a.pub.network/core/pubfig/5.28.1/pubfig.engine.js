! function() {
    "use strict";
    var e = {
        analytics: "1.2.5",
        pbjs: "8.27.0"
    };
    const t = `https://a.pub.network/core/analytics/${e.analytics}/analytics.min.js`,
        n = `https://a.pub.network/core/prebid-analytics-${e.pbjs}.js`,
        i = [{
            siteId: 285,
            restrictedCountries: ["IN", "VN", "NP", "DZ", "IQ", "MA", "AF", "TR", "EG", "PK", "ID", "MA", "BD", "RS", "PH", "TN", "BG"]
        }],
        r = ["triplelift"],
        s = ["revolvingRail", "slidingUnit", "superflex", "interstitial"],
        a = [
            [468, 60],
            [728, 90],
            [970, 90],
            [970, 250],
            [300, 50],
            [300, 100],
            [320, 50],
            [320, 100],
            [120, 600],
            [160, 600],
            [300, 250],
            [300, 600],
            [336, 280],
            [1, 1],
            [0, 0]
        ],
        o = {
            v1: [{
                precision: 2,
                min: 0,
                max: 20,
                increment: .01
            }, {
                precision: 2,
                min: 20,
                max: 40,
                increment: .5
            }, {
                precision: 2,
                min: 40,
                max: 100,
                increment: 1
            }, {
                precision: 2,
                min: 100,
                max: 150,
                increment: 2.5
            }, {
                precision: 2,
                min: 150,
                max: 250,
                increment: 5
            }, {
                precision: 2,
                min: 250,
                max: 400,
                increment: 10
            }, {
                precision: 2,
                min: 400,
                max: 800,
                increment: 50
            }],
            v2: [{
                precision: 2,
                min: 0,
                max: 2,
                increment: .01
            }, {
                precision: 2,
                min: 2,
                max: 10,
                increment: .05
            }, {
                precision: 2,
                min: 10,
                max: 20,
                increment: .5
            }, {
                precision: 2,
                min: 20,
                max: 100,
                increment: 5
            }]
        },
        d = ["US", "CA", "AU", "GB", "IE"],
        l = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "EL", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "GB"],
        c = ["CA", "CT", "CO", "VA", "UT"],
        f = {
            title: "AD_QUALITY:",
            styles: "background: orange; color: purple; border-radius: 3px; padding: 3px"
        },
        u = {
            gumgum: '[id^="ad_is"]',
            thirtyThreeAcross: '[class^="ttx-lb"]',
            undertone: ".ut_container"
        },
        p = {
            videoAdhesion: {
                prettyName: "Sticky Footer Video Adhesion",
                disabled: !1
            },
            stickyFooter: {
                prettyName: "Sticky Footer",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            video: {
                prettyName: "Video",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            standAloneVideo: {
                prettyName: "Stand Alone Video",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            revolvingRail: {
                prettyName: "Revolving Rail",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            pushdown: {
                prettyName: "Pushdown",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            dynamicAds: {
                prettyName: "Dynamic Ads",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0,
                optionsPath: "dynamicAdOptions"
            },
            footerBidding: {
                prettyName: "Footer Bidding",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            superflex: {
                prettyName: "Superflex",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            slidingUnit: {
                prettyName: "Sliding Unit",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            sideWall: {
                prettyName: "Sidewall",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            pageGrabber: {
                prettyName: "Page Grabber",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            interstitial: {
                prettyName: "Interstitial",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            googleInterstitial: {
                prettyName: "Google Interstitial",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            dianomiContentRec: {
                prettyName: "Dianomi Content Recommendation",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            },
            lazyLoad: {
                prettyName: "Lazy Loaded Ads",
                disabled: !1,
                refreshDisabled: !1,
                refreshInterval: 0
            }
        },
        h = {
            root: null,
            rootMargin: "0px",
            threshold: .5
        },
        m = document.querySelector('script[src*="pubfig.min.js"]') ? document.querySelector('script[src*="pubfig.min.js"]').src.split("https://a.pub.network/")[1].split("/")[0] : "freestar-com",
        g = "dianomi_context_script",
        b = ["sortable"],
        y = "00000000-0000-0000-0000-000000000000",
        w = ["AU", "CA", "DE", "HK", "NZ", "SG", "US"],
        v = [371, 864, 1596, 1616, 1617, 1618, 1624, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1650, 1657, 1701, 1706, 1719, 1733, 1734, 1735, 1758, 1761, 1767, 1773, 1782, 1785, 1787, 1797, 1805, 1806, 1808, 1810, 1811, 1812, 1820, 1822, 1827, 1828, 1837, 1841, 1849, 1855, 1863, 1868, 1877, 1878, 1879, 1880, 1881, 1891, 1894, 1900, 1901, 1903, 1910, 1984, 1994, 1995, 1996, 2005, 2019, 2035, 2036, 2075, 2076, 2080, 2082, 2085, 2098, 2103, 2108, 2112, 2123, 2127, 2132, 2133, 2136, 2142, 2149, 2172, 2178, 2180, 2181, 2183, 2190, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2203, 2204, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2222, 2223, 2224, 2225, 2231, 2241, 2244, 2249, 2255, 2260, 2261, 2266, 2269, 2270, 2283, 2286, 2290, 2291, 2304, 2312, 2313, 2318, 2321, 2324, 2337, 2339, 2342, 2345, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2389, 2390, 2391, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2403, 2404, 2405, 2428, 2438, 2443, 2444, 2447, 2451, 2467, 2473, 2481, 2494, 2495, 2497, 2510, 2512, 2513, 2515, 2521, 2525, 2534, 2536, 2539, 2540, 2541, 2544, 2546, 2547, 2549, 2564, 2572, 2573, 2602, 2611, 2612, 2616, 2635, 2641, 3065, 3067, 3090, 3095, 3103, 3104, 3116, 3117, 3119, 3120, 3122, 3126, 3127, 3148, 3188, 3189, 3190, 3224, 3225, 3226, 3227, 3229, 3320, 3321, 3494, 3496, 3497, 3499, 3517, 3522, 3533, 3539, 3540, 3541, 3542, 3543, 3544, 3545, 3546, 3547, 3548, 3549, 3550, 3551, 3552, 3553, 3554, 3556, 3557, 3559, 3560, 3561, 3562, 3563, 3565, 3567, 3568, 3569, 3570, 3571, 3572, 3573, 3574, 3575, 3576, 3577, 3578, 3579, 3580, 3581, 3582, 3583, 3584, 3585, 3586, 3587, 3588, 3589, 3590, 3591, 3592, 3593, 3594, 3595, 3596, 3597, 3598, 3599, 3600, 3601, 3602, 3603, 3604, 3605, 3606, 3607, 3609, 3610, 3612, 3613, 3614, 3615, 3617, 3618, 3619, 3620, 3621, 3622, 3623, 3625, 3626, 3628, 3630, 3631, 3632, 3633, 3634, 3635, 3636, 3637, 3639, 3640, 3641, 3642, 3643, 3644, 3645, 3646, 3647, 3648, 3649, 3650, 3651, 3652, 3653, 3654, 3655, 3656, 3657, 3658, 3659, 3660, 3661, 3662, 3663, 3664, 3665, 3666, 3667, 3668, 3669, 3670, 3671, 3672, 3673, 3674, 3675, 3676, 3677, 3678, 3679, 3680, 3681, 3682, 3683, 3684, 3685, 3686, 3687, 3688, 3689, 3690, 3691, 3692, 3693, 5273, 5274, 5275, 5276, 5283, 5284, 5286, 5288, 5289, 5290, 5291, 5297, 5302, 5305, 5343, 5351, 5360, 5363, 5364, 5370, 5372, 5374, 5375, 5382, 5387, 5388, 5389, 5390, 5394, 5419, 5432, 5443, 5460, 5520, 5623, 5634, 5658, 5823, 5846, 5847, 5851, 5875, 5884, 5893, 5917, 5918, 5919, 5920, 5921, 5922, 5946, 5949, 5954, 5955, 5957, 5963, 5983, 5988, 5991, 5994, 6013, 6017, 6021, 6022, 6031, 6034, 6045, 6046, 6052, 6067, 6068, 6082, 6083, 6086, 6091, 6093, 6097, 6101, 6108, 2484, 5499, 1655, 2167, 2257, 2433, 2434, 2435, 2483, 2548, 2550, 2566, 2610, 2614, 2615, 3121, 3125, 3230, 3611, 5287, 5330, 5362, 5365, 5368, 5369, 5376, 5385, 5386, 5442, 5472, 5475, 5504].concat([2, 120, 128, 159, 5292]),
        I = ["BD", "DZ", "MM", "NI", "CM", "MR", "GN", "CG", "CN", "ET", "SS", "PK", "TN", "PS", "AO", "BJ", "VE", "HT", "TG", "MG", "SO", "GM", "KH", "YE", "IR", "RU", "SD", "VG", "TJ", "SM", "GL", "BQ", "TL", "AX", "MF", "MH", "MP", "TD", "VU", "WS", "BI", "SY", "DJ", "NE", "AS", "AI", "GQ", "CU", "PM", "SB", "PW", "FM", "YT", "TO", "CK", "ER", "MS", "UM", "GW", "BL", "NR", "KM", "KI", "FK", "CC", "CF", "TM", "WF", "ST", "IO", "TV", "NF", "SH", "VA", "EH", "KP", "NU", "AQ", "TK", "CX", "SJ", "PN"],
        A = {
            pubfigEngineLoadInit: "pubfig-engine-load-init",
            pubfigEngineSetupStart: "pubfig-engine-setup-start",
            pubfigEngineLoad: "pubfig-engine-load",
            pubfigSlotRequested: "pubfig-slotRequested",
            pubfigStickyFooterSlotRequested: "pubfig-sticky-footer-slotRequested",
            pubfigSlotRenderEnded: "pubfig-slotRenderEnded",
            pubfigEngineSetupEnd: "pubfig-engine-setup-end",
            pubfigStickyFooterSlotRenderEnded: "pubfig-sticky-footer-slotRenderEnded",
            pubfigPrebidFsRequestBids: "pubfig-prebid-fsRequestBids",
            pubfigPrebidAuctionInit: "pubfig-prebid-auctionInit",
            pubfigPrebidAuctionEnd: "pubfig-prebid-auctionEnd",
            pubfigLoaded: "pubfig-loaded",
            pubfigInitRequestStart: "pubfig-init-request-start",
            pubfigInitRequestEnd: "pubfig-init-request-end"
        };

    function k({
        value: e
    }) {
        return e && Array.isArray(e) && e.length > 0
    }

    function S(e) {
        return e === !!e
    }

    function x(e) {
        return "number" == typeof e
    }

    function E(e) {
        return "string" == typeof e
    }

    function O(e, t) {
        const n = "function" == typeof t ? t : e => e[t];
        return [...e.reduce(((e, t) => {
            const i = null == t ? t : n(t);
            return e.has(i) || e.set(i, t), e
        }), new Map).values()]
    }

    function _(e, t, n) {
        if (!t) return;
        const i = (Array.isArray(t) ? t : t.match(/([^[.\]])+/g)).reduce(((e, t) => e && e[t]), e);
        return void 0 === i ? n : i
    }

    function T(e, t) {
        const n = Math.max(...e.map(t));
        return e.find((e => t(e) === n))
    }

    function C(e, t) {
        const n = [],
            i = e.filter(((e, i) => t(e) && n.push(i)));
        return n.reverse().forEach((t => e.splice(t, 1))), i
    }

    function R(e) {
        return Object.prototype.toString.call(e).slice(8, -1).toLowerCase()
    }

    function N(e, t) {
        let n = R(e);
        return n === R(t) && ("array" === n ? function(e, t) {
            if (e.length !== t.length) return !1;
            for (let n = 0; n < e.length; n++)
                if (!N(e[n], t[n])) return !1;
            return !0
        }(e, t) : "object" === n ? function(e, t) {
            if (Object.keys(e).length !== Object.keys(t).length) return !1;
            for (let n in e)
                if (Object.prototype.hasOwnProperty.call(e, n) && !N(e[n], t[n])) return !1;
            return !0
        }(e, t) : "function" === n ? function(e, t) {
            return e.toString() === t.toString()
        }(e, t) : function(e, t) {
            return e === t
        }(e, t))
    }

    function M(e) {
        return e instanceof Object
    }

    function D(e) {
        if ("number" == typeof e) return e;
        if (function(e) {
                return "symbol" == typeof e
            }(e)) return NaN;
        if (M(e)) {
            const t = "function" == typeof e.valueOf ? e.valueOf() : e;
            e = M(t) ? t + "" : t
        }
        if ("string" != typeof e) return 0 === e ? e : +e;
        e = e.replace(/^\s+|\s+$/g, "");
        const t = /^0b[01]+$/i.test(e);
        return t || /^0o[0-7]+$/i.test(e) ? parseInt(e.slice(2), t ? 2 : 8) : /^[-+]0x[0-9a-f]+$/i.test(e) ? NaN : +e
    }

    function B(e) {
        return [...new Set(e.map((e => JSON.stringify(e))))].map((e => JSON.parse(e)))
    }
    var P = new class {
            constructor() {
                this.isReportingActive = 100 * Math.random() < 1, window.freestar = window.freestar || {}, window.freestar.performanceMarksData = window.freestar.performanceMarksData || {
                    pendingMarks: [],
                    processedMarks: []
                }
            }
            fetchPerformanceMarkDetails({
                markerName: e,
                compareToData: t
            }) {
                const n = performance.getEntriesByName(e, "mark");
                if (0 === n.length) return null;
                let i;
                t && (i = performance.getEntriesByName(t, "mark"));
                const r = n[0];
                return {
                    marker_name: r.name,
                    absolute_time: r.startTime.toFixed(2),
                    ...this.compareMarks({
                        mark: r,
                        compareToPerformanceMarkData: i
                    })
                }
            }
            compareMarks({
                mark: e,
                compareToPerformanceMarkData: t
            }) {
                if (!t) return {};
                const n = (e.startTime - t[0].startTime).toFixed(2);
                return {
                    compared_to: t[0].name,
                    relative_Time: n
                }
            }
            fetchUserDetails() {
                const {
                    deviceInfo: e,
                    locData: t
                } = window.freestar, {
                    browser: n,
                    os: i,
                    device: r
                } = e;
                return { ...t,
                    browser_name: n.name,
                    browser_version: n.version,
                    os_name: i.name,
                    os_version: i.version,
                    device_type: r.type
                }
            }
            isFirstLoad() {
                return null === sessionStorage.getItem("hasLoadedBefore") && (sessionStorage.setItem("hasLoadedBefore", "true"), !0)
            }
            sendPerformanceMarkerToQueue({
                markerName: e,
                compareTo: t
            }) {
                if (this.isReportingActive && !window.freestar.performanceMarksData.processedMarks.includes(e))
                    if (window.freestar.performanceMarksData.processedMarks.push(e), 0 === t.length) {
                        const t = this.fetchPerformanceMarkDetails({
                                markerName: e
                            }),
                            n = this.fetchUserDetails();
                        window.freestar && window.freestar.msg && window.freestar.msg.que && window.freestar.msg.que.push({
                            eventType: "customEvent",
                            args: {
                                eventType: "PERFORMANCE",
                                jsonValue: JSON.stringify({ ...t,
                                    ...n,
                                    is_first_load: this.isFirstLoad(),
                                    pubfig_version: window.freestar.version
                                }),
                                eventName: e.toUpperCase()
                            }
                        })
                    } else t.forEach((t => {
                        const n = this.fetchPerformanceMarkDetails({
                                markerName: e,
                                compareToData: t
                            }),
                            i = this.fetchUserDetails();
                        window.freestar && window.freestar.msg && window.freestar.msg.que && freestar.msg.que.push({
                            eventType: "customEvent",
                            args: {
                                eventType: "PERFORMANCE",
                                jsonValue: JSON.stringify({ ...n,
                                    ...i,
                                    is_first_load: this.isFirstLoad(),
                                    pubfig_version: window.freestar.version
                                }),
                                eventName: e.toUpperCase()
                            }
                        })
                    }))
            }
            pushAllPendingMarksToMsgQue() {
                window.freestar.performanceMarksData.pendingMarks.forEach((e => {
                    this.sendPerformanceMarkerToQueue(e)
                }))
            }
            logMark({
                markerName: e,
                compareTo: t = [],
                isFreestarDataCollectorInitialized: n = !0
            }) {
                performance.mark(e), n && window.freestar.deviceInfo && window.freestar.locData ? this.sendPerformanceMarkerToQueue({
                    markerName: e,
                    compareTo: t
                }) : window.freestar.performanceMarksData.pendingMarks.push({
                    markerName: e,
                    compareTo: t
                })
            }
            logPerformanceMarkers() {
                const e = performance.getEntriesByType("mark");
                for (const t of e) console.log(`Mark [${t.name}]: ${t.startTime.toFixed(2)}ms`)
            }
        },
        z = Function.prototype.toString,
        L = Object.create,
        j = Object.prototype.toString,
        F = function() {
            function e() {
                this._keys = [], this._values = []
            }
            return e.prototype.has = function(e) {
                return !!~this._keys.indexOf(e)
            }, e.prototype.get = function(e) {
                return this._values[this._keys.indexOf(e)]
            }, e.prototype.set = function(e, t) {
                this._keys.push(e), this._values.push(t)
            }, e
        }();
    var U = "undefined" != typeof WeakMap ? function() {
        return new WeakMap
    } : function() {
        return new F
    };

    function q(e) {
        if (!e) return L(null);
        var t = e.constructor;
        if (t === Object) return e === Object.prototype ? {} : L(e);
        if (~z.call(t).indexOf("[native code]")) try {
            return new t
        } catch (e) {}
        return L(e)
    }
    var $ = "g" === /test/g.flags ? function(e) {
        return e.flags
    } : function(e) {
        var t = "";
        return e.global && (t += "g"), e.ignoreCase && (t += "i"), e.multiline && (t += "m"), e.unicode && (t += "u"), e.sticky && (t += "y"), t
    };

    function H(e) {
        var t = j.call(e);
        return t.substring(8, t.length - 1)
    }
    var V = "undefined" != typeof Symbol ? function(e) {
            return e[Symbol.toStringTag] || H(e)
        } : H,
        G = Object.defineProperty,
        W = Object.getOwnPropertyDescriptor,
        Q = Object.getOwnPropertyNames,
        Y = Object.getOwnPropertySymbols,
        K = Object.prototype,
        J = K.hasOwnProperty,
        X = K.propertyIsEnumerable,
        Z = "function" == typeof Y;
    var ee = Z ? function(e) {
        return Q(e).concat(Y(e))
    } : Q;

    function te(e, t, n) {
        for (var i = ee(e), r = 0, s = i.length, a = void 0, o = void 0; r < s; ++r)
            if ("callee" !== (a = i[r]) && "caller" !== a)
                if (o = W(e, a)) {
                    o.get || o.set || (o.value = n.copier(o.value, n));
                    try {
                        G(t, a, o)
                    } catch (e) {
                        t[a] = o.value
                    }
                } else t[a] = n.copier(e[a], n);
        return t
    }

    function ne(e, t) {
        return e.slice(0)
    }

    function ie(e, t) {
        var n = new t.Constructor;
        return t.cache.set(e, n), e.forEach((function(e, i) {
            n.set(i, t.copier(e, t))
        })), n
    }
    var re = Z ? function(e, t) {
        var n = q(t.prototype);
        for (var i in t.cache.set(e, n), e) J.call(e, i) && (n[i] = t.copier(e[i], t));
        for (var r = Y(e), s = 0, a = r.length, o = void 0; s < a; ++s) o = r[s], X.call(e, o) && (n[o] = t.copier(e[o], t));
        return n
    } : function(e, t) {
        var n = q(t.prototype);
        for (var i in t.cache.set(e, n), e) J.call(e, i) && (n[i] = t.copier(e[i], t));
        return n
    };

    function se(e, t) {
        return new t.Constructor(e.valueOf())
    }

    function ae(e, t) {
        return e
    }

    function oe(e, t) {
        var n = new t.Constructor;
        return t.cache.set(e, n), e.forEach((function(e) {
            n.add(t.copier(e, t))
        })), n
    }
    var de = Array.isArray,
        le = Object.assign,
        ce = Object.getPrototypeOf || function(e) {
            return e.__proto__
        },
        fe = {
            array: function(e, t) {
                var n = new t.Constructor;
                t.cache.set(e, n);
                for (var i = 0, r = e.length; i < r; ++i) n[i] = t.copier(e[i], t);
                return n
            },
            arrayBuffer: ne,
            blob: function(e, t) {
                return e.slice(0, e.size, e.type)
            },
            dataView: function(e, t) {
                return new t.Constructor(ne(e.buffer))
            },
            date: function(e, t) {
                return new t.Constructor(e.getTime())
            },
            error: ae,
            map: ie,
            object: re,
            regExp: function(e, t) {
                var n = new t.Constructor(e.source, $(e));
                return n.lastIndex = e.lastIndex, n
            },
            set: oe
        },
        ue = le({}, fe, {
            array: function(e, t) {
                var n = new t.Constructor;
                return t.cache.set(e, n), te(e, n, t)
            },
            map: function(e, t) {
                return te(e, ie(e, t), t)
            },
            object: function(e, t) {
                var n = q(t.prototype);
                return t.cache.set(e, n), te(e, n, t)
            },
            set: function(e, t) {
                return te(e, oe(e, t), t)
            }
        });

    function pe(e) {
        var t = function(e) {
                return {
                    Arguments: e.object,
                    Array: e.array,
                    ArrayBuffer: e.arrayBuffer,
                    Blob: e.blob,
                    Boolean: se,
                    DataView: e.dataView,
                    Date: e.date,
                    Error: e.error,
                    Float32Array: e.arrayBuffer,
                    Float64Array: e.arrayBuffer,
                    Int8Array: e.arrayBuffer,
                    Int16Array: e.arrayBuffer,
                    Int32Array: e.arrayBuffer,
                    Map: e.map,
                    Number: se,
                    Object: e.object,
                    Promise: ae,
                    RegExp: e.regExp,
                    Set: e.set,
                    String: se,
                    WeakMap: ae,
                    WeakSet: ae,
                    Uint8Array: e.arrayBuffer,
                    Uint8ClampedArray: e.arrayBuffer,
                    Uint16Array: e.arrayBuffer,
                    Uint32Array: e.arrayBuffer,
                    Uint64Array: e.arrayBuffer
                }
            }(le({}, fe, e)),
            n = t.Array,
            i = t.Object;

        function r(e, r) {
            if (r.prototype = r.Constructor = void 0, !e || "object" != typeof e) return e;
            if (r.cache.has(e)) return r.cache.get(e);
            if (r.prototype = ce(e), r.Constructor = r.prototype && r.prototype.constructor, !r.Constructor || r.Constructor === Object) return i(e, r);
            if (de(e)) return n(e, r);
            var s = t[V(e)];
            return s ? s(e, r) : "function" == typeof e.then ? e : i(e, r)
        }
        return function(e) {
            return r(e, {
                Constructor: void 0,
                cache: U(),
                copier: r,
                prototype: void 0
            })
        }
    }
    pe(le({}, ue, {}));
    var he = pe({});

    function me(e) {
        this.advertiserId = e.advertiserId, this.campaignId = e.campaignId, this.creativeId = e.creativeId, this.lineItemId = e.lineItemId, this.size = e.size, this.sourceAgnosticCreativeId = e.sourceAgnosticCreativeId, this.sourceAgnosticLineItemId = e.sourceAgnosticLineItemId
    }
    const ge = ({
            placement: e,
            type: t
        }) => {
            let n = e && e[t] && null != e[t].active && !1 !== e[t].active;
            return !(n || !("dynamicAdOptionsV2" === t && e[t].dynamicAd2 || "pushdownOptions" === t && e[t].isPushdownUnit || "sideWallOptions" === t && 0 !== e[t].type || "stickyAdOptions" === t && e[t].stickyAdEnabled || "stickyFooterOptions" === t && Object.keys(e[t]).length > 0 && !1 !== e[t].active)) || n
        },
        be = ({
            placement: e,
            type: t
        }) => ge({
            placement: e,
            type: t
        }) ? e[t] : {};

    function ye({
        placementName: e,
        slotId: t
    }) {
        e && t && (freestar.dynamicSlotLibrary || (freestar.dynamicSlotLibrary = {}), freestar.dynamicSlotLibrary[t] = e)
    }

    function we({
        placementName: e,
        slotId: t,
        path: n
    }) {
        t && ye({
            placementName: e,
            slotId: t
        }), n && function({
            placementName: e,
            path: t
        }) {
            e && t && (window.freestar.dynamicPathLibrary || (freestar.dynamicPathLibrary = []), window.freestar.dynamicPathLibrary.push({
                placementName: e,
                path: t
            }))
        }({
            placementName: e,
            path: n
        })
    }

    function ve({
        slotId: e = null,
        path: t = null
    }) {
        return e ? function({
            slotId: e
        }) {
            function t() {
                const t = Ti({
                    name: e
                });
                return t && t.name ? t.name : "unknown"
            }
            return e ? freestar.dynamicSlotLibrary && freestar.dynamicSlotLibrary[e] ? freestar.dynamicSlotLibrary[e] : (freestar.dynamicSlotLibrary && freestar.dynamicSlotLibrary[e], t()) : "unknown"
        }({
            slotId: e
        }) : !!t && function({
            path: e
        }) {
            return e ? window.freestar.dynamicPathLibrary.find((t => t.path === e)) : "unknown"
        }({
            path: t
        })
    }
    const Ie = [],
        Ae = function(e) {
            const {
                lineItemId: t
            } = e, n = Ie.findIndex((e => e.lineItemId === t));
            if (t && n && n < 0) Ie.push({
                lineItemId: t,
                demandSourceType: null,
                slots: [e.slot.getSlotElementId()]
            });
            else if ("undefined" != n && void 0 !== Ie[n]) {
                Ie[n].slots.find((t => t === e.slot.getSlotElementId())) || Ie[n].slots.push(e.slot.getSlotElementId())
            }
        };

    function ke(e) {
        window.freestar.refreshLibrary[e] || (window.freestar.refreshLibrary[e] = {});
        const t = window.freestar.refreshLibrary[e],
            n = window.freestar.fsdata.directAdRefreshRate;
        n > 0 ? (t.refreshTime = n, t.disableRefresh = !1) : (t.refreshTime = -1, t.disableRefresh = !0)
    }
    const Se = async function() {
            const e = Ie.filter((e => null === e.demandSourceType));
            if (e.length > 0) {
                const t = await fetch(`${freestar.msg.dispensaryURL}/demand-source`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            lineItems: e.map((e => e.lineItemId))
                        }),
                        credentials: "include"
                    }),
                    n = await t.json();
                n.demandSources && (e => {
                    for (const t in e.demandSources) {
                        const n = Ie.findIndex((e => e.lineItemId === Number(t)));
                        Ie[n].demandSourceType = e.demandSources[t]
                    }
                })(n), xe()
            }
        },
        xe = function() {
            Ie.forEach((e => {
                "DIRECT" !== e.demandSourceType && "TRAFFICKED" !== e.demandSourceType || e.slots.forEach((e => {
                    ke(e)
                }))
            }))
        };
    const Ee = e => {
            let t = freestar.fsdata.adRefreshRate;
            try {
                t = freestar.adRefresher.getPlacementAdRefreshRate(null !== e.getAttribute("name") ? e.getAttribute("name") : e.id)
            } catch (e) {
                freestar.log(1, `Error: ${e}`)
            }
            freestar.refreshLibrary[e.id].refreshTime = t
        },
        Oe = ({
            bidder: e,
            adUnitCode: t,
            testData: n
        }, i) => {
            n && (freestar = n.freestar);
            const r = function() {
                const e = function() {
                    let e = Ti({
                        name: ve({
                            slotId: t
                        })
                    });
                    !e && freestar.dynamicSlotLibrary[t] && fsdata.placements[freestar.dynamicSlotLibrary[t]] && (e = freestar.fsdata.placements[freestar.dynamicSlotLibrary[t]]);
                    return e
                }();
                if (e && 1 == e.outOfPage) return -1;
                if (e && e.adRefreshRate && e.adRefreshRate > 0) return e.adRefreshRate;
                if (freestar.fsdata.adRefreshRate && freestar.fsdata.adRefreshRate > 0) return freestar.fsdata.adRefreshRate;
                return 0
            }();
            let s = x(r) ? r : void 0;
            return r && s && i && s > 0 && i.time > s && (freestar.refreshLibrary[t] || (freestar.refreshLibrary[t] = {}), freestar.refreshLibrary[t].refreshTime = i.time, s = i.time, freestar.log(10, `Set Refresh Rate: ${e} won. Changing refresh rate to ${i.time} due to ${i.rule}`)), s
        };

    function _e(e) {
        const t = window.freestar.dynamicSlotLibrary[e];
        t && (e = t);
        const n = Ti({
            name: ve({
                slotId: e
            })
        });
        return function({
            placement: e,
            refreshRate: t
        }) {
            if (freestar.config && freestar.config.products && e) {
                let n = !1;
                if (["stickyFooter", "sideWall", "pushdown", "stickyFooter", "revolvingRail", "dynamicAd"].forEach((i => {
                        if (freestar.config.products[i]) {
                            const r = ge({
                                    placement: e,
                                    type: `${i}Options`
                                }),
                                {
                                    refreshDisabled: s,
                                    refreshInterval: a
                                } = freestar.config.products[i];
                            r && (s && (n = !0), a && a > 15 && (t = a))
                        }
                    })), n) return 0
            }
            return t
        }({
            placement: n,
            refreshRate: n && n.ignoreSiteRefresh ? n.adRefreshRate : window.freestar.fsdata.adRefreshRate
        })
    }

    function Te({
        slotId: e,
        disableRefresh: t
    }) {
        freestar.refreshLibrary[e].disableRefresh = t, freestar.refreshLibrary[e].refreshTime = t ? 0 : _e(e)
    }

    function Ce() {
        return !!freestar.refreshLibrary || (freestar.log(1, "No refreshLibrary entries found, exiting..."), !1)
    }

    function Re({
        slotId: e = !1,
        methodName: t
    }) {
        return !!Ce() && (e ? !!freestar.refreshLibrary[e] || (freestar.log(1, `No entry found, exiting ${t}...`), !1) : (freestar.log(1, `No placement name provided, exiting ${t}...`), !1))
    }

    function Ne({
        placementName: e,
        disableRefresh: t
    }) {
        for (const n in freestar.refreshLibrary) freestar.refreshLibrary[n].placementName === e && Te({
            slotId: n,
            disableRefresh: t
        })
    }

    function Me({
        disableRefresh: e
    }) {
        if (Ce())
            for (const t in freestar.refreshLibrary) Te({
                slotId: t,
                disableRefresh: e
            })
    }

    function De() {
        return window.freestar.fsdata.refreshVersion && 2 === window.freestar.fsdata.refreshVersion
    }

    function Be(e) {
        const {
            name: t,
            detail: n
        } = e, i = new CustomEvent(t, {
            detail: n
        });
        window.dispatchEvent(i)
    }
    const Pe = ["click", "scroll"],
        ze = {},
        Le = () => void 0 !== window.freestar.config.pageSpeedOptimized ? window.freestar.config.pageSpeedOptimized : window.freestar.fsdata.pageSpeedOptimized,
        je = () => {
            Pe.forEach((e => document.removeEventListener(e, je)))
        },
        Fe = ({
            name: e,
            callback: t
        }) => {
            ze[e].waiting && !ze[e].called && (ze[e].called = !0, je(), t())
        },
        Ue = ({
            name: e,
            callback: t
        }) => {
            Object.prototype.hasOwnProperty.call(ze, e) || (ze[e] = {
                waiting: !0
            }, Pe.forEach((n => document.addEventListener(n, Fe.bind(null, {
                name: e,
                callback: t
            }), {
                once: !0
            }))))
        };
    var qe = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function $e(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }

    function He(e) {
        if (e.__esModule) return e;
        var t = e.default;
        if ("function" == typeof t) {
            var n = function e() {
                return this instanceof e ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments)
            };
            n.prototype = t.prototype
        } else n = {};
        return Object.defineProperty(n, "__esModule", {
            value: !0
        }), Object.keys(e).forEach((function(t) {
            var i = Object.getOwnPropertyDescriptor(e, t);
            Object.defineProperty(n, t, i.get ? i : {
                enumerable: !0,
                get: function() {
                    return e[t]
                }
            })
        })), n
    }
    var Ve = function(e) {
        return function(e) {
            return !!e && "object" == typeof e
        }(e) && ! function(e) {
            var t = Object.prototype.toString.call(e);
            return "[object RegExp]" === t || "[object Date]" === t || function(e) {
                return e.$$typeof === Ge
            }(e)
        }(e)
    };
    var Ge = "function" == typeof Symbol && Symbol.for ? Symbol.for("react.element") : 60103;

    function We(e, t) {
        return !1 !== t.clone && t.isMergeableObject(e) ? Xe((n = e, Array.isArray(n) ? [] : {}), e, t) : e;
        var n
    }

    function Qe(e, t, n) {
        return e.concat(t).map((function(e) {
            return We(e, n)
        }))
    }

    function Ye(e) {
        return Object.keys(e).concat(function(e) {
            return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter((function(t) {
                return Object.propertyIsEnumerable.call(e, t)
            })) : []
        }(e))
    }

    function Ke(e, t) {
        try {
            return t in e
        } catch (e) {
            return !1
        }
    }

    function Je(e, t, n) {
        var i = {};
        return n.isMergeableObject(e) && Ye(e).forEach((function(t) {
            i[t] = We(e[t], n)
        })), Ye(t).forEach((function(r) {
            (function(e, t) {
                return Ke(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t))
            })(e, r) || (Ke(e, r) && n.isMergeableObject(t[r]) ? i[r] = function(e, t) {
                if (!t.customMerge) return Xe;
                var n = t.customMerge(e);
                return "function" == typeof n ? n : Xe
            }(r, n)(e[r], t[r], n) : i[r] = We(t[r], n))
        })), i
    }

    function Xe(e, t, n) {
        (n = n || {}).arrayMerge = n.arrayMerge || Qe, n.isMergeableObject = n.isMergeableObject || Ve, n.cloneUnlessOtherwiseSpecified = We;
        var i = Array.isArray(t);
        return i === Array.isArray(e) ? i ? n.arrayMerge(e, t, n) : Je(e, t, n) : We(t, n)
    }
    Xe.all = function(e, t) {
        if (!Array.isArray(e)) throw new Error("first argument should be an array");
        return e.reduce((function(e, n) {
            return Xe(e, n, t)
        }), {})
    };
    var Ze = $e(Xe);
    class et {
        constructor(e) {
            this.adSlotId = e.getSlotElementId(), this.size = e.getSizes().map((e => "fluid" === e ? [1, 1] : [e.getWidth(), e.getHeight()])), this.adUnitPath = e.getAdUnitPath()
        }
    }

    function tt({
        slotArray: e
    }) {
        window.__iasPET.queue = window.__iasPET.queue || [], window.__iasPET.queue.push({
            adSlots: e,
            dataHandler: function() {
                window.__iasPET.setTargetingForGPT()
            }
        })
    }

    function nt({
        slot: e = null
    }) {
        void 0 !== window.__iasPET && (freestar.log(1, "Publisher SlotOperations IAS: iasPETTargeting found"), e ? tt({
            slotArray: [new et(e)]
        }) : function() {
            const e = [];
            Gt().forEach((t => e.push(new et(t)))), e.length && tt({
                slotArray: e
            })
        }())
    }

    function it(e) {
        e = e || 0, e++, window.moatPrebidApi && "function" == typeof window.moatPrebidApi.enableLogging ? (freestar.log(1, "Publisher SlotOperations Testing Moat: Logging Enabled"), window.moatPrebidApi.enableLogging()) : e < 10 && (freestar.log(1, "Publisher SlotOperations Testing Moat: Not set in global try again."), setTimeout((function() {
            it(e)
        }), 200))
    }

    function rt(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var i in n) e[i] = n[i]
        }
        return e
    }
    var st = function e(t, n) {
        function i(e, i, r) {
            if ("undefined" != typeof document) {
                "number" == typeof(r = rt({}, n, r)).expires && (r.expires = new Date(Date.now() + 864e5 * r.expires)), r.expires && (r.expires = r.expires.toUTCString()), e = encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                var s = "";
                for (var a in r) r[a] && (s += "; " + a, !0 !== r[a] && (s += "=" + r[a].split(";")[0]));
                return document.cookie = e + "=" + t.write(i, e) + s
            }
        }
        return Object.create({
            set: i,
            get: function(e) {
                if ("undefined" != typeof document && (!arguments.length || e)) {
                    for (var n = document.cookie ? document.cookie.split("; ") : [], i = {}, r = 0; r < n.length; r++) {
                        var s = n[r].split("="),
                            a = s.slice(1).join("=");
                        try {
                            var o = decodeURIComponent(s[0]);
                            if (i[o] = t.read(a, o), e === o) break
                        } catch (e) {}
                    }
                    return e ? i[e] : i
                }
            },
            remove: function(e, t) {
                i(e, "", rt({}, t, {
                    expires: -1
                }))
            },
            withAttributes: function(t) {
                return e(this.converter, rt({}, this.attributes, t))
            },
            withConverter: function(t) {
                return e(rt({}, this.converter, t), this.attributes)
            }
        }, {
            attributes: {
                value: Object.freeze(n)
            },
            converter: {
                value: Object.freeze(t)
            }
        })
    }({
        read: function(e) {
            return '"' === e[0] && (e = e.slice(1, -1)), e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
        },
        write: function(e) {
            return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
        }
    }, {
        path: "/"
    });

    function at({
        name: e,
        value: t,
        expires: n,
        path: i,
        domain: r
    }) {
        if (!e || !t) return !1;
        const s = {
            secure: !0
        };
        return n && (s.expires = n), i && (s.path = i), r && (s.domain = r), st.set(e, t, s), ot({
            name: e
        })
    }

    function ot({
        name: e
    }) {
        return st.get(e)
    }

    function dt() {
        return freestar.msg.pageviewCount = (e => {
            let t = Number(sessionStorage.getItem(e) || 0);
            return sessionStorage.setItem(e, ++t), t
        })("pageviews")
    }
    const lt = e => {
        e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        let t = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(window.location.search);
        return null === t ? "" : decodeURIComponent(t[1].replace(/\+/g, " "))
    };

    function ct({
        slot: e = null
    }) {
        nt({
                slot: e
            }),
            function({
                slot: e = null
            }) {
                window.moatPrebidApi && ("function" == typeof window.moatPrebidApi.slotDataAvailable && window.moatPrebidApi.slotDataAvailable() || "function" == typeof window.moatPrebidApi.pageDataAvailable && window.moatPrebidApi.pageDataAvailable()) && (freestar.log(1, "Publisher SlotOperations Moat: moatSlotTargetingReady"), e ? window.top.moatPrebidApi.setMoatTargetingForSlot(e) : window.moatPrebidApi.setMoatTargetingForAllSlots())
            }({
                slot: e
            })
    }
    const ft = {
        string: {
            type: "string",
            default: ""
        },
        array: {
            type: "array",
            default: []
        },
        object: {
            type: "object",
            default: {}
        },
        number: {
            type: "number",
            default: void 0
        }
    };

    function ut({
        key: e,
        type: t = ft.string.type
    }) {
        const n = sessionStorage.getItem(e);
        return t === ft.object.type ? n && M(JSON.parse(n)) ? JSON.parse(n) : ft.object.default : t === ft.array.type ? n && Array.isArray(JSON.parse(n)) ? JSON.parse(n) : ft.array.default : t === ft.number.type ? Number.isInteger(Number(n)) ? Number(n) : ft.number.default : n
    }

    function pt({
        key: e,
        type: t = ft.string,
        value: n
    }) {
        n && (t !== ft.object && t !== ft.array || (n = JSON.stringify(n)), sessionStorage.setItem(e, n))
    }

    function ht({
        key: e
    }) {
        sessionStorage.removeItem(e)
    }
    const mt = "fs.session";
    const gt = new class {
        constructor() {
            this.known = 0, this.init()
        }
        init() {
            const e = JSON.parse(ut({
                key: mt
            }));
            e && e.known && (this.known = 1)
        }
        update() {
            if (this.known) return;
            const e = this.computeIsKnownValue(),
                t = JSON.parse(ut({
                    key: mt
                }));
            let n = null;
            null == t ? n = {
                known: e
            } : (null == t.known || !t.known && e) && (n = Object.assign({}, t, {
                known: e
            })), n && pt({
                key: mt,
                type: ft.object,
                value: n
            }), this.known = e
        }
        isKnownByPrebidUser() {
            return Boolean(window.fsprebid && window.fsprebid.getUserIds && 0 !== Object.keys(window.fsprebid.getUserIds()).length)
        }
        computeIsKnownValue() {
            return Number(this.isKnownByPrebidUser())
        }
        isKnown() {
            return this.known != this.computeIsKnownValue() && this.update(), this.known
        }
    };
    let bt = lt("fsdebug"),
        yt = [];
    bt && "true" !== bt && !Number.isInteger(+bt) && (yt = bt.split(",").map((e => e.toUpperCase())));
    const wt = () => {
            const e = fsprebid.getBidResponses(),
                t = fsprebid.getAllWinningBids(),
                n = [];
            Object.keys(e).forEach((function(i) {
                e[i].bids.forEach((function(e) {
                    n.push({
                        bid: e,
                        adunit: i,
                        adId: e.adId,
                        bidder: e.bidder,
                        time: e.timeToRespond,
                        dims: `${e.width}x${e.height}`,
                        cpm: e.cpm,
                        msg: e.status,
                        rendered: !!t.find((function(t) {
                            return t.adId == e.adId
                        }))
                    })
                }))
            }))
        },
        vt = {
            title: "Pubfig"
        };
    class It {
        constructor() {
            this.logs = []
        }
        add(e) {
            this.logs.push(e)
        }
        show(e = vt) {
            if (0 === this.logs.length) return;
            let t = this.logs;
            this.logs = [], freestar.log(e, `\n${t.join("\n")}`)
        }
    }
    const At = class {
        static createInstance({
            ClassConstructor: e,
            instanceName: t
        }) {
            if (window.freestar = window.freestar || {}, window.freestar.instances = window.freestar.instances || {}, window.freestar.instances[t]) return window.freestar.instances[t];
            const n = new e;
            return window.freestar.instances[t] = n, n
        }
        static getInstanceFn({
            ClassConstructor: e,
            instanceName: t
        }) {
            return () => this.createInstance({
                ClassConstructor: e,
                instanceName: t
            })
        }
    }.getInstanceFn({
        ClassConstructor: class {
            constructor() {
                this.results = {}, this.ongoingRequests = new Map
            }
            clearClassCachedData({
                requestId: e
            }) {
                Object.prototype.hasOwnProperty.call(this.results, e) && delete this.results[e]
            }
            async fetch({
                fetchFn: e,
                requestId: t,
                onError: n,
                onSuccess: i
            }) {
                if (this.results[t]) return this.results[t];
                if (!this.ongoingRequests.has(t)) {
                    const r = e().then((e => {
                        const n = {
                            data: e,
                            error: null
                        };
                        return this.results[t] = n, i && i(e), n
                    }), (e => {
                        const i = {
                            data: null,
                            error: e
                        };
                        return this.results[t] = i, n && n(e), i
                    }));
                    this.ongoingRequests.set(t, r)
                }
                return this.ongoingRequests.get(t).finally((() => {
                    this.ongoingRequests.delete(t)
                }))
            }
        },
        instanceName: "requestHandler"
    });
    var kt, St, xt = {
        exports: {}
    };
    kt = xt, St = xt.exports,
        function(e, t) {
            var n = "function",
                i = "undefined",
                r = "object",
                s = "string",
                a = "major",
                o = "model",
                d = "name",
                l = "type",
                c = "vendor",
                f = "version",
                u = "architecture",
                p = "console",
                h = "mobile",
                m = "tablet",
                g = "smarttv",
                b = "wearable",
                y = "embedded",
                w = "Amazon",
                v = "Apple",
                I = "ASUS",
                A = "BlackBerry",
                k = "Browser",
                S = "Chrome",
                x = "Firefox",
                E = "Google",
                O = "Huawei",
                _ = "LG",
                T = "Microsoft",
                C = "Motorola",
                R = "Opera",
                N = "Samsung",
                M = "Sharp",
                D = "Sony",
                B = "Xiaomi",
                P = "Zebra",
                z = "Facebook",
                L = "Chromium OS",
                j = "Mac OS",
                F = function(e) {
                    for (var t = {}, n = 0; n < e.length; n++) t[e[n].toUpperCase()] = e[n];
                    return t
                },
                U = function(e, t) {
                    return typeof e === s && -1 !== q(t).indexOf(q(e))
                },
                q = function(e) {
                    return e.toLowerCase()
                },
                $ = function(e, t) {
                    if (typeof e === s) return e = e.replace(/^\s\s*/, ""), typeof t === i ? e : e.substring(0, 350)
                },
                H = function(e, i) {
                    for (var s, a, o, d, l, c, f = 0; f < i.length && !l;) {
                        var u = i[f],
                            p = i[f + 1];
                        for (s = a = 0; s < u.length && !l && u[s];)
                            if (l = u[s++].exec(e))
                                for (o = 0; o < p.length; o++) c = l[++a], typeof(d = p[o]) === r && d.length > 0 ? 2 === d.length ? typeof d[1] == n ? this[d[0]] = d[1].call(this, c) : this[d[0]] = d[1] : 3 === d.length ? typeof d[1] !== n || d[1].exec && d[1].test ? this[d[0]] = c ? c.replace(d[1], d[2]) : t : this[d[0]] = c ? d[1].call(this, c, d[2]) : t : 4 === d.length && (this[d[0]] = c ? d[3].call(this, c.replace(d[1], d[2])) : t) : this[d] = c || t;
                        f += 2
                    }
                },
                V = function(e, n) {
                    for (var i in n)
                        if (typeof n[i] === r && n[i].length > 0) {
                            for (var s = 0; s < n[i].length; s++)
                                if (U(n[i][s], e)) return "?" === i ? t : i
                        } else if (U(n[i], e)) return "?" === i ? t : i;
                    return e
                },
                G = {
                    ME: "4.90",
                    "NT 3.11": "NT3.51",
                    "NT 4.0": "NT4.0",
                    2e3: "NT 5.0",
                    XP: ["NT 5.1", "NT 5.2"],
                    Vista: "NT 6.0",
                    7: "NT 6.1",
                    8: "NT 6.2",
                    8.1: "NT 6.3",
                    10: ["NT 6.4", "NT 10.0"],
                    RT: "ARM"
                },
                W = {
                    browser: [
                        [/\b(?:crmo|crios)\/([\w\.]+)/i],
                        [f, [d, "Chrome"]],
                        [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                        [f, [d, "Edge"]],
                        [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
                        [d, f],
                        [/opios[\/ ]+([\w\.]+)/i],
                        [f, [d, R + " Mini"]],
                        [/\bopr\/([\w\.]+)/i],
                        [f, [d, R]],
                        [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i, /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i, /(ba?idubrowser)[\/ ]?([\w\.]+)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i, /(heytap|ovi)browser\/([\d\.]+)/i, /(weibo)__([\d\.]+)/i],
                        [d, f],
                        [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                        [f, [d, "UC" + k]],
                        [/microm.+\bqbcore\/([\w\.]+)/i, /\bqbcore\/([\w\.]+).+microm/i],
                        [f, [d, "WeChat(Win) Desktop"]],
                        [/micromessenger\/([\w\.]+)/i],
                        [f, [d, "WeChat"]],
                        [/konqueror\/([\w\.]+)/i],
                        [f, [d, "Konqueror"]],
                        [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                        [f, [d, "IE"]],
                        [/ya(?:search)?browser\/([\w\.]+)/i],
                        [f, [d, "Yandex"]],
                        [/(avast|avg)\/([\w\.]+)/i],
                        [
                            [d, /(.+)/, "$1 Secure " + k], f
                        ],
                        [/\bfocus\/([\w\.]+)/i],
                        [f, [d, x + " Focus"]],
                        [/\bopt\/([\w\.]+)/i],
                        [f, [d, R + " Touch"]],
                        [/coc_coc\w+\/([\w\.]+)/i],
                        [f, [d, "Coc Coc"]],
                        [/dolfin\/([\w\.]+)/i],
                        [f, [d, "Dolphin"]],
                        [/coast\/([\w\.]+)/i],
                        [f, [d, R + " Coast"]],
                        [/miuibrowser\/([\w\.]+)/i],
                        [f, [d, "MIUI " + k]],
                        [/fxios\/([-\w\.]+)/i],
                        [f, [d, x]],
                        [/\bqihu|(qi?ho?o?|360)browser/i],
                        [
                            [d, "360 " + k]
                        ],
                        [/(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i],
                        [
                            [d, /(.+)/, "$1 " + k], f
                        ],
                        [/(comodo_dragon)\/([\w\.]+)/i],
                        [
                            [d, /_/g, " "], f
                        ],
                        [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i],
                        [d, f],
                        [/(metasr)[\/ ]?([\w\.]+)/i, /(lbbrowser)/i, /\[(linkedin)app\]/i],
                        [d],
                        [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                        [
                            [d, z], f
                        ],
                        [/(kakao(?:talk|story))[\/ ]([\w\.]+)/i, /(naver)\(.*?(\d+\.[\w\.]+).*\)/i, /safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],
                        [d, f],
                        [/\bgsa\/([\w\.]+) .*safari\//i],
                        [f, [d, "GSA"]],
                        [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                        [f, [d, "TikTok"]],
                        [/headlesschrome(?:\/([\w\.]+)| )/i],
                        [f, [d, S + " Headless"]],
                        [/ wv\).+(chrome)\/([\w\.]+)/i],
                        [
                            [d, S + " WebView"], f
                        ],
                        [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                        [f, [d, "Android " + k]],
                        [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                        [d, f],
                        [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                        [f, [d, "Mobile Safari"]],
                        [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                        [f, d],
                        [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                        [d, [f, V, {
                            "1.0": "/8",
                            1.2: "/1",
                            1.3: "/3",
                            "2.0": "/412",
                            "2.0.2": "/416",
                            "2.0.3": "/417",
                            "2.0.4": "/419",
                            "?": "/"
                        }]],
                        [/(webkit|khtml)\/([\w\.]+)/i],
                        [d, f],
                        [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                        [
                            [d, "Netscape"], f
                        ],
                        [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                        [f, [d, x + " Reality"]],
                        [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /(links) \(([\w\.]+)/i, /panasonic;(viera)/i],
                        [d, f],
                        [/(cobalt)\/([\w\.]+)/i],
                        [d, [f, /master.|lts./, ""]]
                    ],
                    cpu: [
                        [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                        [
                            [u, "amd64"]
                        ],
                        [/(ia32(?=;))/i],
                        [
                            [u, q]
                        ],
                        [/((?:i[346]|x)86)[;\)]/i],
                        [
                            [u, "ia32"]
                        ],
                        [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                        [
                            [u, "arm64"]
                        ],
                        [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                        [
                            [u, "armhf"]
                        ],
                        [/windows (ce|mobile); ppc;/i],
                        [
                            [u, "arm"]
                        ],
                        [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                        [
                            [u, /ower/, "", q]
                        ],
                        [/(sun4\w)[;\)]/i],
                        [
                            [u, "sparc"]
                        ],
                        [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                        [
                            [u, q]
                        ]
                    ],
                    device: [
                        [/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
                        [o, [c, N],
                            [l, m]
                        ],
                        [/\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i, /samsung[- ]([-\w]+)/i, /sec-(sgh\w+)/i],
                        [o, [c, N],
                            [l, h]
                        ],
                        [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                        [o, [c, v],
                            [l, h]
                        ],
                        [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                        [o, [c, v],
                            [l, m]
                        ],
                        [/(macintosh);/i],
                        [o, [c, v]],
                        [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                        [o, [c, M],
                            [l, h]
                        ],
                        [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],
                        [o, [c, O],
                            [l, m]
                        ],
                        [/(?:huawei|honor)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],
                        [o, [c, O],
                            [l, h]
                        ],
                        [/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i],
                        [
                            [o, /_/g, " "],
                            [c, B],
                            [l, h]
                        ],
                        [/\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],
                        [
                            [o, /_/g, " "],
                            [c, B],
                            [l, m]
                        ],
                        [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
                        [o, [c, "OPPO"],
                            [l, h]
                        ],
                        [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                        [o, [c, "Vivo"],
                            [l, h]
                        ],
                        [/\b(rmx[12]\d{3})(?: bui|;|\))/i],
                        [o, [c, "Realme"],
                            [l, h]
                        ],
                        [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
                        [o, [c, C],
                            [l, h]
                        ],
                        [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                        [o, [c, C],
                            [l, m]
                        ],
                        [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
                        [o, [c, _],
                            [l, m]
                        ],
                        [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i, /\blg-?([\d\w]+) bui/i],
                        [o, [c, _],
                            [l, h]
                        ],
                        [/(ideatab[-\w ]+)/i, /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i],
                        [o, [c, "Lenovo"],
                            [l, m]
                        ],
                        [/(?:maemo|nokia).*(n900|lumia \d+)/i, /nokia[-_ ]?([-\w\.]*)/i],
                        [
                            [o, /_/g, " "],
                            [c, "Nokia"],
                            [l, h]
                        ],
                        [/(pixel c)\b/i],
                        [o, [c, E],
                            [l, m]
                        ],
                        [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                        [o, [c, E],
                            [l, h]
                        ],
                        [/droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                        [o, [c, D],
                            [l, h]
                        ],
                        [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                        [
                            [o, "Xperia Tablet"],
                            [c, D],
                            [l, m]
                        ],
                        [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
                        [o, [c, "OnePlus"],
                            [l, h]
                        ],
                        [/(alexa)webm/i, /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                        [o, [c, w],
                            [l, m]
                        ],
                        [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                        [
                            [o, /(.+)/g, "Fire Phone $1"],
                            [c, w],
                            [l, h]
                        ],
                        [/(playbook);[-\w\),; ]+(rim)/i],
                        [o, c, [l, m]],
                        [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                        [o, [c, A],
                            [l, h]
                        ],
                        [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
                        [o, [c, I],
                            [l, m]
                        ],
                        [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                        [o, [c, I],
                            [l, h]
                        ],
                        [/(nexus 9)/i],
                        [o, [c, "HTC"],
                            [l, m]
                        ],
                        [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],
                        [c, [o, /_/g, " "],
                            [l, h]
                        ],
                        [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                        [o, [c, "Acer"],
                            [l, m]
                        ],
                        [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                        [o, [c, "Meizu"],
                            [l, h]
                        ],
                        [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron|infinix|tecno)[-_ ]?([-\w]*)/i, /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i],
                        [c, o, [l, h]],
                        [/(kobo)\s(ereader|touch)/i, /(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
                        [c, o, [l, m]],
                        [/(surface duo)/i],
                        [o, [c, T],
                            [l, m]
                        ],
                        [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                        [o, [c, "Fairphone"],
                            [l, h]
                        ],
                        [/(u304aa)/i],
                        [o, [c, "AT&T"],
                            [l, h]
                        ],
                        [/\bsie-(\w*)/i],
                        [o, [c, "Siemens"],
                            [l, h]
                        ],
                        [/\b(rct\w+) b/i],
                        [o, [c, "RCA"],
                            [l, m]
                        ],
                        [/\b(venue[\d ]{2,7}) b/i],
                        [o, [c, "Dell"],
                            [l, m]
                        ],
                        [/\b(q(?:mv|ta)\w+) b/i],
                        [o, [c, "Verizon"],
                            [l, m]
                        ],
                        [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                        [o, [c, "Barnes & Noble"],
                            [l, m]
                        ],
                        [/\b(tm\d{3}\w+) b/i],
                        [o, [c, "NuVision"],
                            [l, m]
                        ],
                        [/\b(k88) b/i],
                        [o, [c, "ZTE"],
                            [l, m]
                        ],
                        [/\b(nx\d{3}j) b/i],
                        [o, [c, "ZTE"],
                            [l, h]
                        ],
                        [/\b(gen\d{3}) b.+49h/i],
                        [o, [c, "Swiss"],
                            [l, h]
                        ],
                        [/\b(zur\d{3}) b/i],
                        [o, [c, "Swiss"],
                            [l, m]
                        ],
                        [/\b((zeki)?tb.*\b) b/i],
                        [o, [c, "Zeki"],
                            [l, m]
                        ],
                        [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                        [
                            [c, "Dragon Touch"], o, [l, m]
                        ],
                        [/\b(ns-?\w{0,9}) b/i],
                        [o, [c, "Insignia"],
                            [l, m]
                        ],
                        [/\b((nxa|next)-?\w{0,9}) b/i],
                        [o, [c, "NextBook"],
                            [l, m]
                        ],
                        [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                        [
                            [c, "Voice"], o, [l, h]
                        ],
                        [/\b(lvtel\-)?(v1[12]) b/i],
                        [
                            [c, "LvTel"], o, [l, h]
                        ],
                        [/\b(ph-1) /i],
                        [o, [c, "Essential"],
                            [l, h]
                        ],
                        [/\b(v(100md|700na|7011|917g).*\b) b/i],
                        [o, [c, "Envizen"],
                            [l, m]
                        ],
                        [/\b(trio[-\w\. ]+) b/i],
                        [o, [c, "MachSpeed"],
                            [l, m]
                        ],
                        [/\btu_(1491) b/i],
                        [o, [c, "Rotor"],
                            [l, m]
                        ],
                        [/(shield[\w ]+) b/i],
                        [o, [c, "Nvidia"],
                            [l, m]
                        ],
                        [/(sprint) (\w+)/i],
                        [c, o, [l, h]],
                        [/(kin\.[onetw]{3})/i],
                        [
                            [o, /\./g, " "],
                            [c, T],
                            [l, h]
                        ],
                        [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                        [o, [c, P],
                            [l, m]
                        ],
                        [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                        [o, [c, P],
                            [l, h]
                        ],
                        [/smart-tv.+(samsung)/i],
                        [c, [l, g]],
                        [/hbbtv.+maple;(\d+)/i],
                        [
                            [o, /^/, "SmartTV"],
                            [c, N],
                            [l, g]
                        ],
                        [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                        [
                            [c, _],
                            [l, g]
                        ],
                        [/(apple) ?tv/i],
                        [c, [o, v + " TV"],
                            [l, g]
                        ],
                        [/crkey/i],
                        [
                            [o, S + "cast"],
                            [c, E],
                            [l, g]
                        ],
                        [/droid.+aft(\w+)( bui|\))/i],
                        [o, [c, w],
                            [l, g]
                        ],
                        [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                        [o, [c, M],
                            [l, g]
                        ],
                        [/(bravia[\w ]+)( bui|\))/i],
                        [o, [c, D],
                            [l, g]
                        ],
                        [/(mitv-\w{5}) bui/i],
                        [o, [c, B],
                            [l, g]
                        ],
                        [/Hbbtv.*(technisat) (.*);/i],
                        [c, o, [l, g]],
                        [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],
                        [
                            [c, $],
                            [o, $],
                            [l, g]
                        ],
                        [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                        [
                            [l, g]
                        ],
                        [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                        [c, o, [l, p]],
                        [/droid.+; (shield) bui/i],
                        [o, [c, "Nvidia"],
                            [l, p]
                        ],
                        [/(playstation [345portablevi]+)/i],
                        [o, [c, D],
                            [l, p]
                        ],
                        [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                        [o, [c, T],
                            [l, p]
                        ],
                        [/((pebble))app/i],
                        [c, o, [l, b]],
                        [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                        [o, [c, v],
                            [l, b]
                        ],
                        [/droid.+; (glass) \d/i],
                        [o, [c, E],
                            [l, b]
                        ],
                        [/droid.+; (wt63?0{2,3})\)/i],
                        [o, [c, P],
                            [l, b]
                        ],
                        [/(quest( 2| pro)?)/i],
                        [o, [c, z],
                            [l, b]
                        ],
                        [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                        [c, [l, y]],
                        [/(aeobc)\b/i],
                        [o, [c, w],
                            [l, y]
                        ],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i],
                        [o, [l, h]],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                        [o, [l, m]],
                        [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                        [
                            [l, m]
                        ],
                        [/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],
                        [
                            [l, h]
                        ],
                        [/(android[-\w\. ]{0,9});.+buil/i],
                        [o, [c, "Generic"]]
                    ],
                    engine: [
                        [/windows.+ edge\/([\w\.]+)/i],
                        [f, [d, "EdgeHTML"]],
                        [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                        [f, [d, "Blink"]],
                        [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i, /\b(libweb)/i],
                        [d, f],
                        [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [f, d]
                    ],
                    os: [
                        [/microsoft (windows) (vista|xp)/i],
                        [d, f],
                        [/(windows) nt 6\.2; (arm)/i, /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i, /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i],
                        [d, [f, V, G]],
                        [/(win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                        [
                            [d, "Windows"],
                            [f, V, G]
                        ],
                        [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i],
                        [
                            [f, /_/g, "."],
                            [d, "iOS"]
                        ],
                        [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
                        [
                            [d, j],
                            [f, /_/g, "."]
                        ],
                        [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                        [f, d],
                        [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i, /\((series40);/i],
                        [d, f],
                        [/\(bb(10);/i],
                        [f, [d, A]],
                        [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                        [f, [d, "Symbian"]],
                        [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
                        [f, [d, x + " OS"]],
                        [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                        [f, [d, "webOS"]],
                        [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                        [f, [d, "watchOS"]],
                        [/crkey\/([\d\.]+)/i],
                        [f, [d, S + "cast"]],
                        [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                        [
                            [d, L], f
                        ],
                        [/panasonic;(viera)/i, /(netrange)mmh/i, /(nettv)\/(\d+\.[\w\.]+)/i, /(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i],
                        [d, f],
                        [/(sunos) ?([\w\.\d]*)/i],
                        [
                            [d, "Solaris"], f
                        ],
                        [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, /(unix) ?([\w\.]*)/i],
                        [d, f]
                    ]
                },
                Q = function(p, g) {
                    if (typeof p === r && (g = p, p = t), !(this instanceof Q)) return new Q(p, g).getResult();
                    var b = typeof e !== i && e.navigator ? e.navigator : t,
                        y = p || (b && b.userAgent ? b.userAgent : ""),
                        w = b && b.userAgentData ? b.userAgentData : t,
                        v = g ? function(e, t) {
                            var n = {};
                            for (var i in e) t[i] && t[i].length % 2 == 0 ? n[i] = t[i].concat(e[i]) : n[i] = e[i];
                            return n
                        }(W, g) : W,
                        I = b && b.userAgent == y;
                    return this.getBrowser = function() {
                        var e = {};
                        return e[d] = t, e[f] = t, H.call(e, y, v.browser), e[a] = function(e) {
                            return typeof e === s ? e.replace(/[^\d\.]/g, "").split(".")[0] : t
                        }(e[f]), I && b && b.brave && typeof b.brave.isBrave == n && (e[d] = "Brave"), e
                    }, this.getCPU = function() {
                        var e = {};
                        return e[u] = t, H.call(e, y, v.cpu), e
                    }, this.getDevice = function() {
                        var e = {};
                        return e[c] = t, e[o] = t, e[l] = t, H.call(e, y, v.device), I && !e[l] && w && w.mobile && (e[l] = h), I && "Macintosh" == e[o] && b && typeof b.standalone !== i && b.maxTouchPoints && b.maxTouchPoints > 2 && (e[o] = "iPad", e[l] = m), e
                    }, this.getEngine = function() {
                        var e = {};
                        return e[d] = t, e[f] = t, H.call(e, y, v.engine), e
                    }, this.getOS = function() {
                        var e = {};
                        return e[d] = t, e[f] = t, H.call(e, y, v.os), I && !e[d] && w && "Unknown" != w.platform && (e[d] = w.platform.replace(/chrome os/i, L).replace(/macos/i, j)), e
                    }, this.getResult = function() {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    }, this.getUA = function() {
                        return y
                    }, this.setUA = function(e) {
                        return y = typeof e === s && e.length > 350 ? $(e, 350) : e, this
                    }, this.setUA(y), this
                };
            Q.VERSION = "1.0.36", Q.BROWSER = F([d, f, a]), Q.CPU = F([u]), Q.DEVICE = F([o, c, l, p, h, g, m, b, y]), Q.ENGINE = Q.OS = F([d, f]), kt.exports && (St = kt.exports = Q), St.UAParser = Q;
            var Y = typeof e !== i && (e.jQuery || e.Zepto);
            if (Y && !Y.ua) {
                var K = new Q;
                Y.ua = K.getResult(), Y.ua.get = function() {
                    return K.getUA()
                }, Y.ua.set = function(e) {
                    K.setUA(e);
                    var t = K.getResult();
                    for (var n in t) Y.ua[n] = t[n]
                }
            }
        }("object" == typeof window ? window : qe);
    var Et = xt.exports;
    const Ot = new class {
            constructor() {
                this.initManager()
            }
            initManager() {
                window.freestar = window.freestar || {}, this._setDeviceType()
            }
            _setDeviceType() {
                window.freestar.deviceInfo = Et.UAParser(), window.freestar.deviceInfo.device.type || (window.freestar.deviceInfo.device = {
                    type: "desktop"
                })
            }
            getFormattedDeviceType() {
                if (window.freestar) return "Apple" === window.freestar.deviceInfo.device.vendor ? "smartphone-ios" : window.freestar.deviceInfo.device.type
            }
        },
        _t = "4e799501-b8b6-4ef1-bad5-225b3dd1aa8d",
        Tt = "https://api.floors.dev/sgw/v1/floors",
        Ct = "fs.idealadstack.config",
        Rt = "https://optimise.net/";

    function Nt() {
        return window.freestar.fsdata.domain || location.host
    }
    const Mt = async () => {
            if (!JSON.parse(ut({
                    key: Ct
                }))) {
                let e = await fetch(`${Rt}?k=${gt.isKnown()}&d=${Nt()}&t=${Ot.getFormattedDeviceType()}${lt("fsiasdebug")?"&g=experiment":""}`, {
                    method: "GET",
                    credentials: "include",
                    headers: {
                        "x-api-key": _t
                    }
                });
                const t = e.headers;
                e = await e.text(), e = JSON.parse(e);
                const {
                    testGroup: n
                } = e, i = {
                    testGroup: n,
                    roundTripTime: t.get("fs-client-rtt"),
                    ...e.config
                };
                return pt({
                    key: Ct,
                    type: ft.object,
                    value: i
                }), i
            }
        },
        Dt = {
            title: "IDEAL AD STACK v3.0"
        },
        Bt = "fs.idealadstack.config";
    window.freestar = window.freestar || {};
    const Pt = new class {
            constructor() {
                this.active = !0, this.config = {}, this.configByRtt = null, this.errors = [], this.logs = new It, this.checkingForUserState = !1, this.bindEvents(), this.firstInit = this.init(), this.setupBypassFirstAuction()
            }
            setConfig(e) {
                this.config = e, this.configByRtt = null
            }
            getApiUrl() {
                return `${Rt}?k=${gt.isKnown()}&d=${Nt()}&t=${Ot.getFormattedDeviceType()}${lt("fsiasdebug")?"&g=experiment":""}`
            }
            sendErrorMessage() {
                window.freestar.msg.que.push({
                    eventType: "customEvent",
                    args: {
                        eventName: "DYNAMIC_AUCTION_TIMEOUT_TEST",
                        eventType: "ERRORS",
                        jsonValue: JSON.stringify({
                            errors: this.errors.join(", ")
                        })
                    }
                })
            }
            bindEvents() {
                window.freestar && window.freestar.queue && window.freestar.queue.push((() => {
                    window.fsprebid.onEvent("auctionEnd", (() => {
                        this.checkForUserStateChange()
                    }))
                }))
            }
            async init() {
                this.logs.add("Checking session storage for exsiting config...");
                let e = JSON.parse(ut({
                    key: Bt
                }));
                e ? (this.logs.add("Config found in session storage..."), this.setConfig(e)) : (this.logs.add(`Config not found, making a request to ${this.getApiUrl()}`), this.setConfig(await this.requestConfig()), void 0 === this.config.inAuctionTimeoutSegment && (this.config.inAuctionTimeoutSegment = Math.random() < 1)), this.validAPIResponse() ? (this.logs.add(`Checking if user is in Dynamic Auction Timeout test: ${this.config.inAuctionTimeoutSegment}`), this.config.inAuctionTimeoutSegment && (window.freestar.msg = window.freestar.msg || {}, window.freestar.msg.que = window.freestar.msg.que || [], window.freestar.msg.que.push({
                    eventType: "customEvent",
                    args: {
                        eventName: "DYNAMIC_AUCTION_TIMEOUT_TEST",
                        eventType: "RESULTS",
                        jsonValue: JSON.stringify({
                            clientMask: this.getConfigByRtt().clientServerMask
                        })
                    }
                })), pt({
                    key: Bt,
                    type: ft.object,
                    value: this.config
                })) : (this.logs.add("Config invalid!", JSON.stringify(this.config)), ht({
                    key: Bt
                })), this.setKVPs(), this.checkingForUserState = !1, this.logs.show(Dt)
            }
            isInDynamicAuctionTimeoutTest() {
                return this.config.inAuctionTimeoutSegment
            }
            getConfigByRtt() {
                return null == this.configByRtt && this.setConfigByRtt(), this.configByRtt
            }
            setConfigByRtt() {
                let e, t;
                if (null != this.config.roundTripTime && (t = Number(this.config.roundTripTime), !Number.isNaN(t) && this.config.clientServerRTT))
                    for (const n of this.config.clientServerRTT) t < n.lessThan && (null == e || e.lessThan > n.lessThan) && (e = n);
                const n = e ? `lessThan ${e.lessThan}` : "default";
                freestar.log(20, "setConfigByRtt", `Saw rtt ${t}, using ${n} config`), this.configByRtt = (e || this).config
            }
            getActiveClientBidders() {
                if (!this.active) return [];
                let {
                    clientServer: e = {}
                } = this.getConfigByRtt();
                return Object.keys(e).filter((t => "client" === e[t]))
            }
            getActiveServerBidders() {
                if (!this.active) return [];
                let {
                    clientServer: e = {}
                } = this.getConfigByRtt();
                return Object.keys(e).filter((t => "server" === e[t]))
            }
            getActiveBidders() {
                return [...this.getActiveClientBidders()].concat(this.getActiveServerBidders())
            }
            getInactiveBidders() {
                if (!this.active) return [];
                let {
                    clientServer: e = {}
                } = this.getConfigByRtt();
                return Object.keys(e).filter((t => "off" === e[t]))
            }
            getAllBidders() {
                let {
                    clientServer: e = {}
                } = this.config;
                return Object.keys(e)
            }
            getServerToServerDetails() {
                if (!this.active) return {};
                let {
                    testGroup: e
                } = this.config, {
                    clientServerMask: t
                } = this.getConfigByRtt();
                const n = this.getActiveServerBidders();
                return {
                    activeBidders: this.getActiveBidders(),
                    serverToServerNetworks: n,
                    clientServerMask: t,
                    testGroup: e
                }
            }
            getDynamicAuctionTimeoutDetails() {
                const {
                    inAuctionTimeoutSegment: e = !1,
                    maxTimeout: t = window.freestar.fsdata.timeout,
                    roundTripTime: n = null
                } = this.config;
                return {
                    inAuctionTimeoutSegment: e,
                    maxTimeout: t,
                    roundTripTime: n
                }
            }
            getMaxAuctionTimeout() {
                const {
                    maxTimeout: e
                } = this.getDynamicAuctionTimeoutDetails();
                return e
            }
            async requestConfig() {
                const {
                    data: e,
                    error: t
                } = await At().fetch({
                    requestId: "getIdealData",
                    fetchFn: Mt
                });
                return t && (this.active = !1, this.errors.push(t.toString())), e || {}
            }
            async checkForUserStateChange() {
                if (this.checkingForUserState) return;
                this.checkingForUserState = !0;
                (Number(googletag.pubads().getTargeting("floors_user").toString()) || 0) !== gt.isKnown() ? (ht({
                    key: Bt
                }), await this.init()) : this.checkingForUserState = !1
            }
            setKVPs() {
                const {
                    roundTripTime: e = null
                } = this.getDynamicAuctionTimeoutDetails(), {
                    clientServerMask: t = null,
                    testGroup: n = null
                } = this.getServerToServerDetails();
                freestar.queue.push((() => {
                    googletag.pubads().setTargeting("floors_user", String(gt.isKnown())), e && googletag.pubads().setTargeting("floors_rtt", `${e}`), t && googletag.pubads().setTargeting("fs_clientservermask", `${t}`), n && googletag.pubads().setTargeting("fs_testgroup", `${n}`)
                })), this.logs.add(`fs_clientservermask: ${t}\nfs_testgroup: ${n}\nfloors_user: ${gt.isKnown()}\nfloors_rtt: ${e}`)
            }
            validAPIResponse() {
                let e = !0;
                return 0 === this.errors.length && (0 === Object.keys(this.config).length ? this.errors.push("no params") : void 0 === this.config.maxTimeout && this.errors.push("no maxTimeout")), 0 !== this.errors.length && (e = !1, this.logs.add(`Config Errors: ${this.errors.join(", ")}`), this.sendErrorMessage()), this.active = e, e
            }
            getFirstInit() {
                return this.firstInit
            }
            async getFloorsData() {
                return await this.getFirstInit(), this.config && this.config.floors
            }
            getBypassFirstAuction() {
                const e = this.getConfigByRtt();
                return !!e && "off" === e.preGAMAuction
            }
            async setupBypassFirstAuction() {
                await this.getFirstInit(), this.getBypassFirstAuction() && fsprebid && fsprebid.que && fsprebid.que.push((function() {
                    fsprebid.removeAdUnit()
                }))
            }
            getFeatureConfig() {
                return this.config && this.config.features || {}
            }
            allowBrowsi() {
                return "off" !== this.getFeatureConfig().browsi
            }
            allowConfiant() {
                return "off" !== this.getFeatureConfig().confiant
            }
            allowBlockthrough() {
                return "off" !== this.getFeatureConfig().blockthrough
            }
        },
        zt = {
            root: null,
            threshold: .5
        };
    let Lt = new class {
        observe() {
            return null
        }
        unobserve() {
            return null
        }
        disconnect() {
            return null
        }
    };
    "IntersectionObserver" in window && (Lt = new IntersectionObserver((function(e) {
        e.forEach((e => {
            const t = freestar.refreshLibrary[e.target.id];
            if (t) {
                const n = jt.getRefreshCounter(t),
                    i = jt.getRefreshTime(t, e.target.id);
                if (i <= 0 || n < 0) return;
                n >= i && e.isIntersecting && e.intersectionRatio > .49 && (freestar.refreshLibrary[e.target.id].viewabilityThresholdMet = !0)
            }
        }))
    }), zt));
    class jt {
        constructor(e) {
            freestar.log(25, "REFRESH V2 Enabled"), this.slots = e || Gt(), this.time = {}, this.observers = {}, this.time.default = window.freestar.fsdata.adRefreshRate || 0, this.bidTimeout = window.freestar.fsdata.timeout, this.getPlacementAdRefreshRate = _e, freestar.refreshLibraryCreator = jt.refreshLibraryCreator, this.onLoad(e)
        }
        onLoad(e) {
            for (let t = 0; t < this.slots.length; t++) {
                const n = this.slots[t] ? this.slots[t].getSlotElementId() : void 0;
                if (jt.refreshLibraryCreator(n), e && e.length > 0 && this.slots[t]) {
                    const e = Ti({
                        name: ve({
                            slotId: n
                        })
                    });
                    this.observers[n] || e.outOfPage || (Lt.observe(document.getElementById(n)), this.observers[n] = !0), jt.refresh(n, document.getElementById(n))
                }
            }
            window.setInterval(function() {
                if (document.hasFocus())
                    for (const e in freestar.refreshLibrary) {
                        const t = document.getElementById(e);
                        t && (this.counter(t), this.observers[e] || (this.observers[e] = !0, Lt.observe(t)))
                    }
            }.bind(this), 1e3)
        }
        static refreshLibraryCreator(e, t) {
            e && (Array.isArray(e) || (e = [e]), t = t || void 0, e.forEach((e => {
                window.freestar.refreshLibrary[e] || (window.freestar.refreshLibrary[e] = {});
                const n = Ti({
                    name: ve({
                        slotId: e
                    })
                });
                if (!n) return void freestar.log(20, "refreshLibraryCreator", "Cannot find placement for ad slot", e);
                const i = window.freestar.refreshLibrary[e];
                if (i.viewabilityThresholdMet = !1, i.refreshTime && x(i.refreshTime) || (window.freestar.adRefresher && window.freestar.adRefresher.getPlacementAdRefreshRate ? i.refreshTime = Number(window.freestar.adRefresher.getPlacementAdRefreshRate(e)) : i.refreshTime = Number(_e(e))), i.refreshCounter && x(i.refreshCounter) || (i.refreshCounter = t || 0), i.viewPercentage && x(i.viewPercentage) || (i.viewPercentage = 100), !i.disableRefresh || !S(i.disableRefresh)) {
                    i.disableRefresh = !1;
                    const t = document.getElementById(e);
                    (t && -1 === Number(t.getAttribute("data-refresh-time")) || !0 === n.outOfPage) && (i.disableRefresh = !0)
                }
                i.timesRefreshed && x(i.timesRefreshed) || (i.timesRefreshed = 0), n.interstitialOptions && !0 === n.interstitialOptions.active && (i.disableRefresh = !0)
            })))
        }
        static isActive(e) {
            return Oi(e) ? (window.freestar.refreshLibrary[e.id].viewPercentage = 100, !0) : (window.freestar.refreshLibrary[e.id].viewPercentage = 0, !1)
        }
        static getRefreshTime(e, t) {
            let n = e.refreshTime;
            return (void 0 === n || isNaN(n) || null === n) && (n = _e(t), freestar.log(25, " ", "freestar.fsdata.adRefreshRate", n)), n
        }
        static getRefreshCounter(e) {
            let t = e.refreshCounter;
            return (void 0 === t || isNaN(t)) && (t = 0), t
        }
        counter(e) {
            const t = freestar.refreshLibrary[e.id],
                n = Ti({
                    name: ve({
                        slotId: e.id
                    })
                });
            if (n && n.lazyAd && !t.hasIntersectLazyAd) return void(t.refreshCounter = 0);
            if (t.disableRefresh) return;
            const i = jt.getRefreshTime(t, e.id);
            let r = jt.getRefreshCounter(t);
            if (!(i <= 0 || r < 0)) {
                if (r += 1, r >= .8 * i) {
                    const t = Wt({
                        elementId: e.id
                    });
                    t && t.setTargeting("fs_uuid", bi()), window.freestar.fsdata.isTriple13Enabled && !freestar.refreshLibrary[e.id].floorsRefreshed && (freestar.refreshLibrary[e.id].timesRefreshed += 1, n && $t.getFloorsData({
                        placement: n,
                        slotId: e.id,
                        callback: ({
                            result: n
                        }) => {
                            freestar.refreshLibrary[e.id].timesRefreshed -= 1, n && (freestar.refreshLibrary[e.id].floorsRefreshed = !0, t && (Object.keys(n).forEach((e => {
                                t.setTargeting(e, n[e])
                            })), freestar.log({
                                title: "FLOORS"
                            }, e.id, "Refreshed floors value.", n)))
                        }
                    })), Pt.checkForUserStateChange()
                }
                t.refreshCounter = r, freestar.log({
                    title: "REFRESH"
                }, e.id, t.refreshCounter), r >= i && (jt.isActive(e) || !0 === t.viewabilityThresholdMet) && (freestar.refreshLibrary[e.id].timesRefreshed += 1, t.viewabilityThresholdMet = !1, freestar.refreshLibrary[e.id].floorsRefreshed = !1, freestar.currentStickyFooter && freestar.currentStickyFooter.placement && e.id === freestar.currentStickyFooter.placement.name ? (freestar.log({
                    title: "REFRESH"
                }, e.id, "Refreshing sticky footer ad slot..."), freestar.currentStickyFooter.stickyFooterRefresh()) : (freestar.log({
                    title: "REFRESH"
                }, e.id, "Refreshing standard ad slot..."), Ee(e), freestar.refreshLibrary[e.id].refreshCounter = 0, jt.refresh(e.id)))
            }
        }
        static refresh(e) {
            jt.refreshSlots({
                slotIds: [e]
            }, !1)
        }
        static refreshSlots({
            slotIds: e
        } = {
            slotIds: null
        }, t = !0) {
            t && console.warn("freestar.freestarReloadAdSlot() has been deprecated and will be removed in the future use freestar.refreshAllSlots()"), freestar.log(1, `${e?"freestar.refresh":"freestar.refreshAllSlots"}${e?" : "+e:null}`),
                function(e = null) {
                    const t = null != e ? e : Object.keys(window.freestar.rebidControl);
                    t.forEach((e => function(e) {
                        const t = window.freestar.rebidControl[e];
                        t && (t.setTargeting(0), delete window.freestar.rebidControl[e])
                    }(e)))
                }(e), window.fsprebid.que.push((function() {
                    const t = [],
                        n = Gt().map((function(n) {
                            if (n) {
                                let i = n.getSlotElementId();
                                if (freestar.refreshLibrary[i] || jt.refreshLibraryCreator(i), freestar.refreshLibrary[i].refreshCounter++, freestar.refreshLibrary[i].dataRefreshId = bi(), freestar.refreshSlots.push({
                                        refreshId: freestar.refreshLibrary[i].dataRefreshId
                                    }), !e || e.indexOf(i) > -1) return freestar.refreshLibrary[i].viewabilityThresholdMet = !1, t.push(i), n.setTargeting("fsrefresh", `${freestar.refreshLibrary[i].timesRefreshed}`), n
                            }
                        })).filter((e => void 0 !== e));
                    e && !t.length || ji(t, n)
                }))
        }
    }
    class Ft {
        constructor() {
            this.slotMaxBids = {}, this.slotToPlacement = {}, this.placementToSlots = {}
        }
        initiateWatcher(e) {
            e.que.push((() => {
                e.onEvent("bidResponse", this.handleBidResponse.bind(this))
            }))
        }
        handleBidResponse(e) {
            this.addSlotPlacementAssociation(e.adUnitCode), this.addBidResponse(e)
        }
        addSlotPlacementAssociation(e) {
            if (e && !this.slotToPlacement[e]) {
                const t = ve({
                    slotId: e
                });
                t && (this.slotToPlacement[e] = t, this.placementToSlots[t] || (this.placementToSlots[t] = []), this.placementToSlots[t].push(e))
            }
        }
        addBidResponse(e) {
            const {
                adUnitCode: t,
                cpm: n
            } = e;
            t && n && (!this.slotMaxBids[t] || this.slotMaxBids[t] < n) && (this.slotMaxBids[t] = n)
        }
        getSlotMaxBid(e) {
            return Ft.validateMaxBid(this.slotMaxBids[e])
        }
        getPlacementMaxBidBySlot(e) {
            const t = this.slotToPlacement[e];
            return this.getPlacementMaxBid(t)
        }
        getPlacementMaxBid(e) {
            const t = this.placementToSlots[e] || [];
            return Ft.validateMaxBid(Math.max(...t.map((e => this.getSlotMaxBid(e)))))
        }
        static validateMaxBid(e) {
            return !Number.isNaN(e) && null != e && e > 0 ? e : null
        }
    }
    let Ut = null;

    function qt() {
        return null == Ut && (Ut = new Ft), Ut
    }
    const $t = new class {
        constructor(e, t) {
            this.idealAdStackManager = e, this.maxBidTracker = t, this.initialData = null, this.requests = [], this.maxBidRequests = {}
        }
        async getInitialFloorsData() {
            const {
                timestamp: e,
                floors: t
            } = this.getRequest(0);
            return this.initialData ? await t : this.initialData = {
                timestamp: e,
                floors: await t
            }, this.initialData
        }
        getRequest(e, t, n) {
            return t && null != n ? (this.maxBidRequests[t.name] || (this.maxBidRequests[t.name] = [null]), this.maxBidRequests[t.name][e] || (this.maxBidRequests[t.name][e] = []), this.maxBidRequests[t.name][e].find((e => e.maxBid === n)) || this.maxBidRequests[t.name][e].push({
                maxBid: n,
                timestamp: new Date,
                floors: this.fetchData(e, t.dfpId, n)
            }), this.maxBidRequests[t.name][e].find((e => e.maxBid === n))) : (this.requests[e] || (this.requests[e] = {
                timestamp: new Date,
                floors: this.fetchData(e)
            }), this.requests[e])
        }
        getRequestUrl(e, t, n, i, r) {
            const s = Nt(),
                a = "Apple" === e ? "smartphone-ios" : t,
                o = gt.isKnown(),
                d = i && null != r ? `&mb=${r}&au=${encodeURIComponent(i)}` : "";
            return `${Tt}?${`d=${s}&t=${a}&k=${o}&r=${n}${d}`}`
        }
        async fetchData(e, t, n) {
            let i;
            if (0 === e) {
                const e = await this.idealAdStackManager.getFloorsData();
                e && !e.error && e.length > 0 && (i = e)
            }
            if (!i) {
                const {
                    data: r,
                    error: s
                } = await At().fetch({
                    requestId: "getFloorsData",
                    fetchFn: () => async function(e, t, n, i, r) {
                        const s = Nt(),
                            a = "Apple" === e ? "smartphone-ios" : t,
                            o = gt.isKnown(),
                            d = i && null != r ? `&mb=${r}&au=${encodeURIComponent(i)}` : "",
                            l = fetch(`${Tt}?d=${s}&t=${a}&k=${o}&r=${n}${d}`, {
                                headers: {
                                    "x-api-key": _t
                                }
                            }),
                            c = await l;
                        return await c.json()
                    }(window.freestar.deviceInfo.device.vendor, window.freestar.deviceInfo.device.type, e, t, n)
                });
                if (At().clearClassCachedData({
                        requestId: "getFloorsData"
                    }), i = r, s) {
                    const r = t && null != n ? `, placement ${t}, maxBid ${n}` : "";
                    freestar.log(40, `Floors request for refresh ${e}${r} error`, s.toString()), i = []
                }
            }
            const {
                error: r,
                message: s
            } = i;
            return r && (freestar.msg.que.push({
                eventType: "customEvent",
                args: {
                    eventName: "FLOORS_ERROR",
                    eventType: "FETCH_RESPONSE",
                    jsonValue: JSON.stringify({
                        message: s
                    })
                }
            }), i = []), i
        }
        getFloor(e, t, n) {
            const i = t.find((e => n.dfpId === e.adUnit)),
                r = i ? i.upr : "timeout",
                s = i ? new Date(i.lastUpdated) : e;
            return {
                floors_id: r,
                floors_hour: String(s.getUTCHours())
            }
        }
        getInitialFloorKVP({
            placement: e,
            keyMap: t
        }) {
            return t || (t = {}), Object.assign(t, this.getFloor(this.initialData.timestamp, this.initialData.floors, e))
        }
        async getFloorsData({
            placement: e,
            slotId: t,
            callback: n,
            isRebid: i = !1
        }) {
            let r, s;
            if (!window.freestar.fsdata.isTriple13Enabled) return r = null, s = "inactive", void n({
                result: r,
                reason: s
            });
            const a = (function(e) {
                const t = freestar.refreshLibrary[e];
                if (t) return t.timesRefreshed
            }(t) || 0) + (i ? 1 : 0);
            let o, d;
            if (0 === a || i)({
                timestamp: o,
                floors: d
            } = this.getRequest(a));
            else {
                const n = this.maxBidTracker.getSlotMaxBid(t);
                ({
                    timestamp: o,
                    floors: d
                } = this.getRequest(a, e, n))
            }
            r = this.getFloor(o, await d, e), s = null, n && n({
                result: r,
                reason: s
            })
        }
    }(Pt, qt());

    function Ht({
        key: e,
        value: t
    }) {
        window.googletag.pubads && window.googletag.pubads().setTargeting(e, t)
    }

    function Vt({
        slot: e,
        key: t,
        value: n
    }) {
        e && e.setTargeting && t && n && e.setTargeting(t, n)
    }

    function Gt() {
        return window.googletag.pubads && window.googletag.pubads().getSlots()
    }

    function Wt({
        elementId: e
    }) {
        if (e) return Gt().filter((t => t.getSlotElementId() === e))[0]
    }

    function Qt({
        elementId: e
    }) {
        let t = Wt({
            elementId: e
        });
        t && (window.googletag.destroySlots([t]), e in freestar.refreshLibrary && delete freestar.refreshLibrary[e])
    }

    function Yt({
        specialDfpId: e,
        dfpId: t
    }) {
        return e || !t.includes("{{channel}}")
    }

    function Kt({
        dfpId: e,
        elementId: t
    }) {
        return window.googletag.defineOutOfPageSlot(e, t).addService(googletag.pubads())
    }

    function Jt({
        placement: e,
        sizes: t,
        id: n = null,
        specialDfpId: i = null,
        slotConfig: r
    }) {
        if (!e) return void freestar.log("No placement provided, exiting...");
        if (!t && (t = function(e) {
                let t = !1;
                return e.sizeMappings.some((e => {
                    if (bn() >= e.viewport.size[0]) return t = e.size.sort(((e, t) => e[0] + e[1] < t[0] + t[1] ? 1 : t[0] + t[1] < e[0] + e[1] ? -1 : 0)).filter((e => 35843 !== e[0])), !0
                })), t
            }(e), !t)) return void freestar.log("No sizes found at this resolution, exiting...");
        n || (n = e.name);
        let {
            outOfPage: s,
            dfpId: a,
            fluidAd: o
        } = e, d = Wt({
            elementId: n
        });
        if (d || (s ? Yt({
                specialDfpId: i,
                dfpId: a
            }) && (d = Kt({
                dfpId: i || a,
                elementId: n
            })) : (o && !t.includes("fluid") && t.push("fluid"), Yt({
                specialDfpId: i,
                dfpId: a
            }) && (d = googletag.defineSlot(i || a, t, n).addService(googletag.pubads())))), d) {
            if (freestar.fsdata.disableSingleRequest || googletag.pubads().enableSingleRequest(), googletag.enableServices(), function({
                    id: e,
                    placement: t
                }) {
                    freestar.gamMap[e] || (freestar.gamMap[e] = t.dfpId.indexOf("/15184186/") > -1)
                }({
                    id: n,
                    placement: e
                }), d.setTargeting) {
                let t = {
                    fsrefresh: "0",
                    fsrebid: "0",
                    fs_uuid: bi()
                };
                window.freestar.fsdata.isTriple13Enabled && (t = $t.getInitialFloorKVP({
                    placement: e,
                    keyMap: t
                })), Object.keys(t).forEach((e => {
                    d.setTargeting(e, t[e])
                }))
            }
            if (freestar.gptppid && freestar.gptppid.updateGoogleSlotTargeting(d), e && Vt({
                    slot: d,
                    key: "fs_placementName",
                    value: e.name
                }), r && r.targeting)
                for (const e in r.targeting) Object.prototype.hasOwnProperty.call(r.targeting, e) && Vt({
                    slot: d,
                    key: e,
                    value: r.targeting[e]
                });
            return ct({
                slot: d
            }), we({
                placementName: e.name,
                slotId: n,
                path: i || a
            }), d
        }
    }
    const Xt = new class {
        constructor() {
            this.map = {}
        }
        getStatus({
            adUnitCode: e = null
        }) {
            if (e) return this.getStatusByAdUnitCode({
                adUnitCode: e
            })
        }
        getStatusByAdUnitCode({
            adUnitCode: e
        }) {
            return this.map[e]
        }
        isAbleToRebid({
            elementId: e
        }) {
            return !this.map[e] || this.map[e].count < 2
        }
        isValidPlacement({
            placement: e = !1
        }) {
            return e && !e.interstitialOptions.active
        }
        rebid({
            elementId: e,
            slot: t
        }) {
            ji([e], t)
        }
        registerEventListeners() {
            window.freestar.locData.iso && -1 === d.indexOf(window.freestar.locData.iso) || freestar.queue.push((() => {
                googletag.pubads().addEventListener("slotRenderEnded", (e => {
                    if (e.isEmpty) {
                        const {
                            slot: t
                        } = e, n = t.getSlotElementId(), i = Ti({
                            name: ve({
                                slotId: n
                            })
                        });
                        freestar.msg.que.push({
                            eventType: "customEvent",
                            args: {
                                eventName: `EVENT_IS_EMPTY_CAN_REBID=${this.isValidPlacement({placement:i})&&this.isAbleToRebid({elementId:n})}`,
                                eventType: "REBID",
                                jsonValue: JSON.stringify({
                                    event: e
                                })
                            }
                        }), this.isValidPlacement({
                            placement: i
                        }) && this.isAbleToRebid({
                            elementId: n
                        }) && (this.track({
                            elementId: n
                        }), this.updateKeyValues({
                            slot: t,
                            data: {
                                fsrebid: String(this.map[n].count)
                            }
                        }), $t.getFloorsData({
                            placement: i,
                            slotId: n,
                            callback: ({
                                result: e
                            }) => {
                                window.freestar.log(1, `Floors called for rebid for blocked ad on ${i.name}`), e && t.updateTargetingFromMap(e), this.rebid({
                                    elementId: n,
                                    slot: t
                                })
                            },
                            isRebid: !0
                        }))
                    }
                }))
            }))
        }
        reset({
            elementId: e
        }) {
            const t = Wt({
                elementId: e
            });
            t && t.setTargeting("fsrebid", "0"), delete this.map[e]
        }
        track({
            elementId: e,
            type: t = "EMPTYRESPONSE"
        }) {
            this.map[e] || (this.map[e] = {
                count: 0,
                type: t
            }), this.map[e].count += 1
        }
        updateKeyValues({
            slot: e,
            data: t
        }) {
            e.updateTargetingFromMap(t)
        }
    };
    class Zt {
        constructor({
            eventType: e,
            args: t
        }) {
            this.eventType = e, this.args = t
        }
        send() {
            window.freestar.msg.que.push(this)
        }
    }

    function en({
        args: e
    }) {
        new Zt({
            eventType: "adBlocked",
            args: e
        }).send()
    }

    function tn({
        data: e
    }) {
        const {
            adId: t
        } = e.prebid, n = window.fsprebid.getAllWinningBids().find((e => e.adId === t));
        if (n) {
            en({
                    args: Ze({
                        blockingType: "prebid"
                    }, n)
                }),
                function({
                    bidResponse: e
                }) {
                    const t = ut(cn);
                    t.includes(e.bidder) || t.push(e.bidder);
                    pt({
                            key: ln,
                            value: t,
                            type: ft.array
                        }), sessionStorage.setItem(ln, JSON.stringify(t)),
                        function({
                            bidder: e
                        }) {
                            window.fsprebid.adUnits.forEach((t => {
                                t.bids = t.bids.filter((t => t.bidder !== e))
                            }))
                        }(e)
                }({
                    bidResponse: n
                })
        }
    }

    function nn({
        domId: e
    }) {
        Xt.track({
            elementId: e
        }), e && Xt.isAbleToRebid({
            elementId: e
        }) ? (window.freestar.log(f, `Rebid for blocked ad on ${e}`), window.freestar.freestarReloadAdSlot && window.freestar.freestarReloadAdSlot(e)) : window.freestar.log(f, `Rebid attempt maximum reached for ${e}. There will not be another attempt to fill`)
    }

    function rn(e) {
        const {
            data: t
        } = e;
        if ("CONFIANT_BLOCK" === t.message)
            if (t.prebid) {
                const e = t.prebid.s;
                tn({
                    data: t
                }), nn({
                    domId: e
                })
            } else {
                const e = t.dfp.s;
                ! function({
                    domId: e
                }) {
                    en({
                        args: {
                            blockingType: "dfp",
                            adUnitCode: e
                        }
                    })
                }({
                    data: t,
                    domId: e
                }), nn({
                    domId: e
                })
            }
    }

    function sn({
        type: e = "div",
        classList: t = [],
        id: n = !1,
        src: i = !1,
        name: r = !1,
        attributes: s = []
    }) {
        const a = document.createElement(e);
        return t.length && (a.className = t.join(" ")), i && (a.src = i), n && (a.id = n), r && a.setAttribute("name", r), s.length && s.forEach((e => {
            const t = Object.keys(e)[0];
            a.setAttribute(t, e[t])
        })), a
    }

    function an(e, t, n = null, i, r = !0) {
        try {
            const s = sn({
                type: "script",
                attributes: [{
                    "data-owner": "freestar"
                }]
            });
            e && (s.src = e), i && (s.textContent = i), n && (s.id = n), r && (s.async = r), s.type = "text/javascript", t && (s.onload = t), document.getElementsByTagName("head")[0].appendChild(s)
        } catch (e) {}
    }

    function on() {
        if (freestar.fsdata.adQualityOptions.vendor) return "desktop" === freestar.deviceInfo.device.type && freestar.fsdata.adQualityOptions.desktopEnabled || freestar.fsdata.adQualityOptions.mobileEnabled ? freestar.fsdata.adQualityOptions.vendor : null;
        switch (freestar.deviceInfo.device.type) {
            case "desktop":
                return freestar.fsdata.adQualityDesktopVendor;
            case "mobile":
                return freestar.fsdata.adQualityMobileVendor;
            default:
                return null
        }
    }

    function dn() {
        if (!freestar.hasAdQualityConfiantInit && window.freestar.fsdata.adQualityOptions && (window.freestar.fsdata.adQualityOptions.desktopEnabled || window.freestar.fsdata.adQualityOptions.mobileEnabled) && "CONFIANT" === window.freestar.fsdata.adQualityOptions.vendor) {
            const e = window.freestar.fsdata.adQualityOptions.vendorId,
                t = document.createElement("script");
            t.innerHTML = "window.confiant = window.confiant || {};\n        window.confiant.prebidNameSpace='fsprebid';\n        window.confiant.callback = function(blockingType, blockingId, isBlocked, wrapperId, tagId, impressionData) {\n        postMessage({\n          'message': 'CONFIANT_BLOCK',\n          'prebid': impressionData.prebid,\n          'dfp': impressionData.dfp,\n        })};", an(`https://cdn.confiant-integrations.net/${e}/gpt_and_prebid/config.js`), document.head.insertBefore(t, document.head.firstElementChild), freestar.log("inserted Confiant script"), window.addEventListener("message", rn), freestar.hasAdQualityConfiantInit = !0
        }
    }
    const ln = "fs.exclude.bidders",
        cn = {
            key: ln,
            type: ft.array.type
        };
    const fn = {
            appnexus: {
                id: 1,
                slug: "appnexus",
                networkBidAdjustment: 2,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        placementId: "29086448",
                        member: "7125",
                        invCode: ""
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                bidAdjustment: 0,
                allowedGeos: [],
                disallowedGeos: []
            },
            ix: {
                id: 47,
                slug: "ix",
                networkBidAdjustment: 0,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        siteId: "919177"
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                allowedGeos: [],
                disallowedGeos: []
            },
            openx: {
                id: 9,
                slug: "openx",
                networkBidAdjustment: 0,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        unit: "558892711",
                        delDomain: "freestar-d.openx.net"
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                bidAdjustment: 0,
                allowedGeos: [],
                disallowedGeos: []
            },
            pubmatic: {
                id: 24,
                slug: "pubmatic",
                networkBidAdjustment: 2,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        publisherId: "156696",
                        adSlot: "4927517",
                        outstreamAU: "5215190"
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                bidAdjustment: 0,
                allowedGeos: [],
                disallowedGeos: ["SS", "CD", "CF", "RU", "KP", "SY", "BI", "IQ", "IR", "AL", "UA", "YE", "LY", "VE", "SD", "CU", "LB", "BY", "ME", "SO", "ZW", "MK"]
            },
            rubicon: {
                id: 22,
                slug: "rubicon",
                networkBidAdjustment: 0,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        accountId: "16924",
                        zoneId: "2753756",
                        siteId: "347090",
                        sizeId: "203",
                        video: {
                            language: "en"
                        }
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                bidAdjustment: 0,
                allowedGeos: [],
                disallowedGeos: []
            },
            yieldmo: {
                id: 88,
                slug: "yieldmo",
                networkBidAdjustment: 0,
                sizes: [{
                    size: [
                        [0, 0]
                    ],
                    params: {
                        placementId: "3016733814794691083",
                        video: {
                            language: "en"
                        }
                    }
                }],
                preferredDesktop: !1,
                preferredMobile: !1,
                archived: !1,
                bidAdjustment: 0,
                isPrebidServer: !1,
                allowedGeos: [],
                disallowedGeos: []
            }
        },
        un = ({
            slug: e,
            newParams: t
        }) => {
            let n = fn[e];
            return Object.keys(t).forEach((e => {
                n.sizes[0].params[e] && (n.sizes[0].params[e] = t[e])
            })), n
        },
        pn = async () => {
            const e = JSON.parse(ut({
                    key: "fs.session"
                })),
                t = await gn();
            if (t) {
                const {
                    percentageOfTraffic: n
                } = t;
                if (Math.random() < n) return e.inVideoJSTest = !0, e.outstreamVideoPlayerParams = t, pt({
                    key: "fs.session",
                    value: e,
                    type: ft.object
                }), !0
            }
            return !1
        },
        hn = () => {
            const e = [];
            freestar.fsdata.placements.forEach((t => {
                t.sizeMappings.some((n => {
                    if (n.videoEnabled) {
                        const n = JSON.parse(JSON.stringify(t));
                        let i = Object.assign(n, {
                            name: t.name + "_outstream",
                            ignoreSiteBidders: !0,
                            stickyFooterOptions: {
                                active: !1
                            }
                        });
                        return i.sizeMappings = i.sizeMappings.map((e => (e.playerSize && "LARGE" === e.playerSize && (e.size = [
                            [400, 300]
                        ]), e.playerSize && "SMALL" === e.playerSize && (e.size = [
                            [300, 200]
                        ]), e))), e.push(i), !0
                    }
                }))
            })), freestar.fsdata.placements = freestar.fsdata.placements.concat(e), freestar.fsdata.videoTopLevelStoredRequestId = "4ace28ad-2eeb-47bf-9cc3-135b1966f81a"
        },
        mn = ({
            placement: e
        }) => {
            let t;
            try {
                t = `/${e.dfpId.split("/")[1]}/freestar_adx_video_outstream_${m}_${freestar.fsdata.siteId}`
            } catch (e) {
                t = "/15184186/vsquad-video-test"
            }
            return t
        },
        gn = async () => {
            let e = !1;
            const t = JSON.parse(ut({
                key: "fs.session"
            }));
            if (t.outstreamVideoPlayerParams) e = t.outstreamVideoPlayerParams;
            else {
                let t = await fetch(`https://a.pub.network/videojs-site-params/?path=${m}`, {
                    method: "GET"
                });
                if (t = await t.json(), 0 !== Object.keys(t).length) {
                    const {
                        networks: n,
                        storedRequest: i,
                        percentageOfTraffic: r = .3
                    } = t;
                    e = {
                        networks: [],
                        storedRequest: i,
                        percentageOfTraffic: r
                    }, Object.keys(n).forEach((t => {
                        const i = un({
                            slug: t,
                            newParams: n[t]
                        });
                        e.networks.push(i)
                    }))
                }
            }
            return e
        };

    function bn() {
        return window.innerWidth && document.documentElement.clientWidth ? Math.min(window.innerWidth, document.documentElement.clientWidth) : window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName("body")[0].clientWidth
    }

    function yn(e, t) {
        if (t.length > 0 && Array.isArray(t[0])) {
            let n = t.length;
            if (0 === t[0][0] && 0 === t[0][1]) return !0;
            for (; n--;)
                if (yn(e, t[n])) return !0
        }
        let n = e.length;
        for (; n--;)
            if (e[n][0] === t[0] && e[n][1] === t[1]) return !0;
        return !1
    }

    function wn(e, t) {
        let n = e.length;
        for (; n--;)
            if (e[n][0] === t[0] && e[n][1] === t[1]) return !0;
        return !1
    }

    function vn() {
        return freestar.fsdata.placements
    }

    function In(e) {
        return !(!e.validAdSizes || !e.bidders || 0 === e.bidders.length || e.stickyFooter || e.dynamicAd) && An(e)
    }

    function An(e) {
        return void 0 === freestar.config || void 0 === freestar.config.enabled_slots || function(e, t) {
            for (let n = 0; n < e.length; n++)
                if (e[n].placementName === t) {
                    if ("complete" !== document.readyState) return !0;
                    if (window.document.getElementById(t)) return !0
                }
            return !1
        }(freestar.config.enabled_slots, e.name)
    }

    function kn(e) {
        if (!e) return null;
        let t = null;
        try {
            t = JSON.parse(e)
        } catch (e) {
            t = null
        }
        return null !== t && t.length > 0 ? t : null
    }

    function Sn({
        network: e,
        adQualityBlockList: t
    }) {
        return function(e, t = !1) {
            if (!1 === t) return !0;
            let {
                allowedGeos: n = [],
                disallowedGeos: i = []
            } = e;
            const {
                iso: r
            } = t, s = freestar.networkMap[e.id];
            return s && (s.allowedGeos && s.allowedGeos.length && (n = s.allowedGeos), s.disallowedGeos && s.disallowedGeos.length && (i = s.disallowedGeos)), !(n && n.length && -1 === n.indexOf(r) || i && i.length && -1 !== i.indexOf(r)) || (freestar.log(1, `Users in ${freestar.locData.iso} are not allowed to use ${e.slug}!`), !1)
        }(e, window.freestar.locData) && function({
            network: e
        }) {
            if (!1 === freestar.networkMap || 0 === Object.keys(freestar.networkMap).length) return !0;
            const t = freestar.networkMap[e.id];
            return !t || Le() && -1 !== r.indexOf(e.slug) ? (freestar.log(1, "isNetworkActive - Page Speed Optimized in effect, or network is inactive filtering out", e.slug), !1) : !t || !S(t.active) || t.active
        }({
            network: e
        }) && function({
            network: e,
            adQualityBlockList: t
        }) {
            return !k({
                value: t
            }) || !t.includes(e.slug)
        }({
            network: e,
            adQualityBlockList: t
        })
    }
    async function xn() {
        const e = ut(cn),
            t = Pt.getInactiveBidders();

        function n(e, n, i) {
            const r = {
                    bidder: e.slug,
                    size: n.size,
                    params: n.params
                },
                s = function(e, t) {
                    if ("indexExchange".indexOf(t.bidder) > -1 && t.params && t.params.id && t.params.id < 0 && (t.dynamicId = !0), "conversant" === t.bidder) {
                        t.params.secure = freestar.isHttps;
                        for (const e in t.params) switch (e) {
                            case "bidfloor":
                            case "position":
                            case "maxduration":
                                t.params[e] = Number(t.params[e])
                        }
                    }
                    if ("cox" === t.bidder && (t.params.id = Number(t.params.id), t.params.siteId = Number(t.params.siteId)), "justpremium" === t.bidder && t.params && (t.params.allow = kn(t.params.allow), t.params.exclude = kn(t.params.exclude), void 0 === t.params.allow || null !== t.params.allow && 0 !== t.params.allow.length || delete t.params.allow, void 0 === t.params.exclude || null !== t.params.exclude && 0 !== t.params.exclude.length || delete t.params.exclude), "pulsepoint" === t.bidder)
                        for (const e in t.params) "cf" == e && (t.params[e] = t.params[e].replace("X", "x"));
                    if ("connectad" === t.bidder)
                        for (let e in t.params) "siteId" !== e && "networkId" !== e || (t.params[e] = Number(t.params[e]));
                    if ("grid" === t.bidder && t.params && t.params.uid && (t.params.uid = Number(t.params.uid)), "beachfront" === t.bidder)
                        for (var n in t.params) "video" != n && "banner" != n || (t.params[n] = "object" == typeof t.params[n] ? t.params[n] : JSON.parse(t.params[n]));
                    if ("undertone" === t.bidder && (t.params.publisherId = Number(t.params.publisherId), t.params.placementId = Number(t.params.placementId)), "zid" === t.bidder && (t.params.adUnitID = D(t.params.adUnitID)), "mantis" === t.bidder && (t.params.zone = e.name), "districtmDMX" === t.bidder && (t.params.dmxid = Number(t.params.dmxid), t.params.memberid = Number(t.params.memberid)), "answermedia" === t.bidder && (t.params.siteId = D(t.params.siteId), t.params.networkId = D(t.params.networkId), t.params.zoneIds && E(t.params.zoneIds) && t.params.zoneIds.split(",").length > 0 ? t.params.zoneIds = t.params.zoneIds.split(",").map((function(e) {
                            return D(e)
                        })) : t.params.zoneIds = []), "consumable" === t.bidder && (t.params.siteId = D(t.params.siteId), t.params.networkId = D(t.params.networkId), t.params.unitId = D(t.params.unitId)), ["appnexus", "appnexusAst", "brealtime", "pagescience", "defymedia", "gourmetads", "matomy", "featureforward", "oftmedia"].indexOf(t.bidder) > -1)
                        for (const e in t.params) "placementId" == e && (t.params[e] = Number(t.params[e])), ["allowSmallerSizes", "member", "invCode"].indexOf(e) > -1 && delete t.params[e];
                    return !(["defymedia", "zid"].indexOf(t.bidder) > -1) && ("sortable" === t.bidder && (t.params.tagId = e.name), !(!0 === e.stickyFooter && ["sharethrough", "triplelift"].indexOf(t.bidder) > -1) && ("criteo" === t.bidder && (t.params.zoneId = Number(t.params.zoneId)), he(t)))
                }(i, (wn((a = r).size, [0, 0]) && delete a.size, a));
            var a;
            s && function(e, n) {
                -1 === t.indexOf(e.bidder) && ("ix" === e.bidder ? n.sizes.forEach((t => {
                    const i = {
                        bidder: e.bidder,
                        params: {
                            siteId: e.params.siteId,
                            size: t
                        }
                    };
                    n.bidders.push(i)
                })) : e && n.bidders.push(e))
            }(s, i)
        }
        if (freestar.fsdata.placements.some((e => e.stickyFooterOptions.video))) {
            const e = JSON.parse(ut({
                key: "fs.session"
            }));
            e.inVideoJSTest || (e.inVideoJSTest = await pn()), (e.inVideoJSTest || lt("fs-use-videojs")) && (freestar.log({
                title: "PREBID VIDEO",
                styles: "background: black; color: white; border-radius: 3px; padding: 3px"
            }, "Session is participating in VideoJS test..."), hn())
        }
        let i = freestar.config.channel || freestar.fsdata.defaultChannel;
        i && (freestar.log(9, " Setting the channel to:" + i), freestar.config.orignalChannel = i), freestar.fsdata.placements = freestar.fsdata.placements.filter((e => !e.archived)), freestar.fsdata.placements.forEach((async t => {
            i && (t.dfpId = t.dfpId.replace("{{channel}}", i), freestar.log(9, " Setting the dfp id to:" + t.dfpId)), t.bidders = [], t.sizes = [], t.validAdSizes = !1, t.sizeMappings.sort((function(e, t) {
                return e.viewport.size[0] === t.viewport.size[0] ? 0 : e.viewport.size[0] > t.viewport.size[0] ? -1 : 1
            }));
            for (let e = 0; e < t.sizeMappings.length; e++) {
                let n = t.sizeMappings[e];
                if (bn() >= n.viewport.size[0]) {
                    for (let e = 0; e < n.size.length; e++) {
                        let i = n.size[e];
                        t.selectedSize = n, 35843 == i[0] ? (t.fluidAd = !0, t.validAdSizes = !0) : yn(n.size, i) && !wn(t.sizes, i) && (freestar.forceSize && N(freestar.forceSize.sort(), i.sort()) ? t.sizes.push(i) : freestar.forceSize || t.sizes.push(i))
                    }
                    t.sizes.length > 0 && (t.validAdSizes = !0);
                    break
                }
            }
            if (-1 !== t.name.indexOf("_outstream")) {
                const e = await gn();
                if (e) {
                    const {
                        networks: n,
                        storedRequest: i
                    } = e;
                    t.networks = n, t.storedRequest = i, t.videoGAMSlot = mn({
                        placement: t
                    }), freestar.fsdata.placementVideos = freestar.fsdata.placementVideos.map((e => (e.vendor = "PREBID", e))), t.sizes.push("desktop" === freestar.deviceInfo.device.type ? [400, 300] : [300, 200])
                }
            }
            t.ignoreSiteBidders || freestar.fsdata.networks.forEach((i => {
                Sn({
                    network: i,
                    adQualityBlockList: e
                }) && k({
                    value: i.sizes
                }) && i.sizes.forEach((e => {
                    yn(t.sizes, e.size) && n(i, e, t)
                }))
            }));
            let r = [];
            if (t.networks.forEach((i => {
                    Sn({
                        network: i,
                        adQualityBlockList: e
                    }) && i.sizes.forEach((e => {
                        if (r.push(e.size[0]), yn(t.sizes, e.size)) {
                            if (e.deviceExclusive && e.deviceExclusive.toLowerCase() !== freestar.deviceInfo.device.type) return;
                            n(i, e, t)
                        }
                    }))
                })), t.sizes = B(t.sizes), t.bidders = B(t.bidders), t.sizes.length > 0) {
                const {
                    active: e,
                    adhesionRemove: n
                } = be({
                    placement: t,
                    type: "stickyFooterOptions"
                });
                e && n && document.getElementById("fs-special-remove") && (t.bidders = t.bidders.filter((e => "33across" !== e.bidder || "gumgum" !== e.bidder)))
            }
        })), freestar.log(1, " freestar.fsdata.placements : " + JSON.stringify(freestar.fsdata.placements))
    }
    const En = ({
        adUnitPath: e
    }) => window.freestar.fsdata.placements.find((t => e === t.dfpId));

    function On() {
        const e = i,
            t = e.length;
        let n = !1;
        if (freestar.locData && freestar.locData.iso)
            for (let i = 0, r = t; i < r; i++) {
                const t = e[i];
                if (freestar.fsdata.siteId === t.siteId && t.restrictedCountries.indexOf(freestar.locData.iso) > -1) {
                    n = !0;
                    break
                }
            }
        return n
    }
    let _n = 0;
    const Tn = () => {
            if (_n++, _n < 5 && !window.fsprebid || !window.fsprebid.addAdUnits || !window.googletag || !window.googletag.pubads || !window.googletag.pubads().getSlots) return void setTimeout((function() {
                freestar.log(1, "RequestQue: There is an error with googletag or prebid loading in requestQueInitiate. Making another attempt."), Tn()
            }), 300);
            if (freestar.requests.que.length < 1) return void freestar.log(1, "RequestQue: nothing left in queue returning");
            let e = freestar.requests.que,
                t = [],
                n = [];
            freestar.log(1, "request que objects", e);
            Fi({
                adUnits: e.filter((e => 0 !== e.sizes.length)).filter((function(e) {
                    t.push(e.code);
                    const i = Wt({
                        elementId: e.code
                    });
                    if (i && n.push(i), !fsprebid.adUnits.filter((t => t.code === e.code))[0]) return e
                }))
            }), De() ? jt.refreshLibraryCreator(t) : freestar.refreshLibraryCreator(t), freestar.fsRequestBids(t, n, freestar.fsdata.timeout), freestar.requests.que = []
        },
        Cn = {},
        Rn = ({
            element: e,
            placement: t
        }) => {
            we({
                placementName: t.name,
                slotId: e.id
            });
            const {
                lazyLoadViewportHeight: n
            } = t.selectedSize;
            let i = Cn[n];
            i || (i = new IntersectionObserver(((e, t) => {
                e.forEach((e => {
                    if (Ni(e)) {
                        const n = ve({
                            slotId: e.target.id
                        });
                        n && (freestar.newAdSlots([{
                            placementName: n,
                            slotId: e.target.id,
                            source: "lazyAd"
                        }]), freestar.refreshLibrary[e.target.id].hasIntersectLazyAd = !0, t.unobserve(e.target))
                    }
                }))
            }), {
                root: null,
                rootMargin: `${n}% 0px ${n}% 0px`
            })), i.observe(e)
        },
        Nn = function({
            name: e
        }) {
            return !(!window.freestar.config.products[e] || !window.freestar.config.products[e].disabled) && (window.freestar.log(1, `${p[e].prettyName} Disabled via freestar.config.products.${e}.disabled`), !0)
        };
    class Mn {
        constructor() {
            this.scrollingAds = [], this.totalScrollHeight = 0
        }
        init() {
            freestar.fsdata.placements.filter((e => this.isSlidingUnit({
                placement: e
            }))).forEach((e => {
                this.attachSlidingUnit({
                    adUnit: e
                })
            }))
        }
        handleIntersection(e) {
            e.forEach((function(e) {
                if (e.isIntersecting) {
                    const {
                        boundingClientRect: t,
                        target: n
                    } = e, i = n.children[0], r = i.children[0];
                    let {
                        top: s,
                        bottom: a
                    } = t;
                    s += document.documentElement.scrollTop, a = a + document.documentElement.scrollTop - r.offsetHeight, freestar.debug && this.debug({
                        target: n,
                        top: s,
                        bottom: a
                    });
                    const o = this.scrollingAds.find((e => e.id === i.id));
                    if (o) {
                        let e = Math.max(document.documentElement.scrollTop + o.headerHeight, 0);
                        e > s && e < a ? (i.style.position = "fixed", i.style.top = o.headerHeight + "px", i.style.marginTop = "0px") : e > a ? (i.style.position = "", i.style.marginTop = o.maxHeight - r.offsetHeight + "px", i.style.top = "") : (i.style.position = "", i.style.marginTop = "0px", i.style.top = "")
                    }
                }
            }), this)
        }
        debug({
            target: e,
            top: t,
            bottom: n
        }) {
            const i = e.id;
            [...document.querySelectorAll(`.${i}.fs-sau`)].forEach((e => e.parentElement.removeChild(e)));
            const r = sn({
                type: "style",
                classList: ["fs-sau"]
            });
            r.textContent = `\n        .${i}.fs-sau-marker {\n            height: 2px;\n            width: 100%;\n            background-color: rgba(0,0,0,0.5);\n            position: absolute;\n            left: 0;\n            z-index: 1000;\n        }\n        .${i}.fs-sau-marker.fs-sau-top {\n            top: ${t}px;\n        }\n        .${i}.fs-sau-marker.fs-sau-bottom {\n            top: ${n}px;\n        }\n        `, document.head.appendChild(r);
            let s = sn({
                type: "div",
                classList: [i, "fs-sau", "fs-sau-marker", "fs-sau-top"]
            });
            document.body.appendChild(s), s = sn({
                type: "div",
                classList: [i, "fs-sau", "fs-sau-marker", "fs-sau-bottom"]
            }), document.body.appendChild(s)
        }
        isSlidingUnit({
            placement: e
        }) {
            return e.stickyAdOptions && e.stickyAdOptions.stickyAdEnabled
        }
        attachSlidingUnit({
            adUnit: e,
            slotId: t = null
        }) {
            if (!this.isSlidingUnit({
                    placement: e
                })) return;
            const n = document.querySelector(`#${t||e.name}`);
            let {
                adScrollHeight: i,
                headerHeight: r,
                stickyAdEnabled: s
            } = this.getPlacementStickyAdDetailsByScreenResolution(e);
            if (!s) {
                const t = be({
                    placement: e,
                    type: "stickyAdOptions"
                });
                r = t.headerHeight, i = t.adScrollHeight, s = t.stickyAdEnabled
            }
            if (n && s) {
                const {
                    freestarAd: e
                } = n.dataset;
                e && n.removeAttribute("data-freestar-ad");
                const s = t || n.getAttribute("id"),
                    a = document.createElement("div", {});
                a.setAttribute("id", s + "_container"), a.classList.add("sliding-ad-container"), a.style.overflow = "hidden", a.style.display = "inline-flex", a.style.justifyContent = "center", a.style.width = "100%", a.style.height = `${i}px`, n.parentNode.insertBefore(a, n), a.appendChild(n), this.scrollingAds.push({
                    id: s,
                    maxHeight: i,
                    headerHeight: r
                });
                new IntersectionObserver(this.handleIntersection.bind(this), {
                    rootMargin: `-${r}px 0px 0px 0px`,
                    threshold: this.buildThresholdList(i / 2)
                }).observe(a)
            }
        }
        buildThresholdList(e) {
            let t = [];
            for (let n = 5; n <= e; n++) {
                let i = n / e;
                t.push(i)
            }
            return t.push(0), t
        }
        getPlacementStickyAdDetailsByScreenResolution(e) {
            let t = !1;
            return e.sizeMappings.some((e => {
                if (bn() >= e.viewport.size[0]) {
                    const {
                        adScrollHeight: n,
                        headerHeight: i,
                        stickyAdEnabled: r
                    } = e;
                    return t = {
                        adScrollHeight: n,
                        headerHeight: i,
                        stickyAdEnabled: r
                    }, !0
                }
            })), t
        }
    }
    let Dn = null;

    function Bn() {
        return null === Dn && (Dn = new Mn), Dn
    }

    function Pn(e, t, n = null, i = null) {
        try {
            const n = function(e, t) {
                let n = {};
                return window.freestar.config.targeting && Array.isArray(window.freestar.config.targeting) && (n = window.freestar.config.targeting.find((function(e) {
                    return Object.keys(e).includes(t)
                }))), n && (e = { ...e,
                    ...n[t]
                }), e
            }(i, t);
            if (n)
                for (const t in n) e.setTargeting(t, n[t])
        } catch (e) {
            freestar.log(49, "ERROR:", "slotTargeting", ...arguments), freestar.log(49, "ERROR:", "slotTargeting", e)
        }
    }

    function zn(e) {
        return freestar.googletagCorrelatorUpdate = !0, freestar.log(25, "deleteAdSlots invoked and the following ID(s) will be destroyed", e), fsprebid.libLoaded && (googletag || googletag.destroySlots) ? void 0 === e ? (googletag.cmd.push((function() {
            googletag.destroySlots()
        })), void(freestar.refreshLibrary = {})) : (Array.isArray(e) || (e = [e]), void e.forEach((e => Qt({
            elementId: e
        })))) : (freestar.log(10, "destroyAdSlots", "Objects not ready, returning..."), freestar.queue.timers = freestar.queue.timers || {}, clearTimeout(freestar.queue.timers[e]), void(freestar.queue.timers[e] = setTimeout(zn, 100, ...arguments)))
    }

    function Ln({
        placement: e,
        element: t,
        newElement: n
    }) {
        const i = $n(e);
        i && (i.code = t.id, "lazyAd" === n.source ? freestar.requests.que.push(i) : e.selectedSize && e.selectedSize.lazyLoadViewportHeight > 0 ? Rn({
            element: t,
            placement: e
        }) : freestar.requests.que.push(i))
    }

    function jn({
        placement: e,
        slotId: t,
        targeting: n = {},
        placementName: i = null,
        newElement: r,
        element: s = null
    }) {
        function a(s, a) {
            if (a && i && (a.setAttribute("name", i), window.freestar.newAdSlotIds.push(t), e = Ti({
                    name: i
                }))) {
                window.freestar.dynamicSlots.push(t);
                const s = (e, t) => e[0] + e[1] < t[0] + t[1] ? 1 : t[0] + t[1] < e[0] + e[1] ? -1 : 0;
                let o = [];
                if (e.selectedSize && !0 === e.selectedSize.mediaTypes.includes("video") ? o = e.selectedSize.size.sort(s).filter((e => 35843 !== e[0]))[0] : e.sizeMappings.some((e => {
                        if (!0 === e.mediaTypes.includes("video") && bn() >= e.viewport.size[0]) return o = e.size.sort(s).filter((e => 35843 !== e[0])), !0
                    })), o.length > 0) {
                    const e = o[0] >= 500 ? [
                        [640, 360],
                        [552, 334]
                    ] : [
                        [400, 225],
                        [300, 169]
                    ];
                    a.setAttribute("data-freestar-ad", a.getAttribute("data-freestar-ad") + ` __${e[0][0]}x${e[0][1]}`)
                }
                window.googletag.cmd.push((function() {
                    if (e.sizes.length || e.fluidAd) {
                        let s = Wt({
                                elementId: t
                            }),
                            o = freestar.config.channel,
                            d = freestar.config.channel,
                            l = e.dfpId;
                        if (e.dfpId.indexOf("{{channel}}") > -1 ? o = "{{channel}}" : e.dfpId.indexOf(freestar.config.channel) > -1 ? o = freestar.config.channel : e.dfpId.indexOf(freestar.config.orignalChannel) > -1 && (o = freestar.config.orignalChannel), d && (r.path || o) && (l = e.dfpId.replace(d, r.path || o), s && window.googletag.destroySlots && (window.googletag.destroySlots([s]), s = void 0)), s || (s = Jt({
                                placement: e,
                                slotConfig: {
                                    targeting: n
                                },
                                sizes: e.sizes,
                                id: a.id,
                                specialDfpId: l
                            })), s) {
                            n = { ...n,
                                fs_ad_product: Fn(e)
                            };
                            Pn(s, t, i, (() => void 0 !== n && Object.keys(n).length ? n : void 0)())
                        }
                    }
                }))
            }
        }
        i = i && i.length ? i : e.name, s ? a(0, s) : function(e, t) {
            let n = document.getElementById(e);
            n ? t(null, n) : setTimeout((function() {
                n = document.getElementById(e), n ? t(null, n) : t(!0)
            }), 500)
        }(t, a)
    }

    function Fn(e) {
        let t = {};
        if (!e) return "";
        const n = ["revolvingRail", "dynamicAd", "slidingUnit", "topAdhesion", "standAloneVideo"].filter((function(n) {
            if (t = e[n + "Options"], t) return t && t.active
        }));
        return t = e.stickyFooterOptions, t && t.active && n.push(!0 === t.video ? "stickyFooterVideo" : "stickyFooter"), t = e.interstitialOptions, t && t.active && n.push("ZERGNET" === t.type ? "reengageInter" : "interstitial"), !0 === e.lazyAd && n.push("lazyLoad"), t = e.sideWallOptions, !t || 1 !== t.type && 2 !== t.type || n.push("sideWall"), t = e.pushdownOptions, t && t.isPushdownUnit && n.push("pushdown"), n.length <= 0 && n.push("banner"), n.filter((e => !Nn({
            name: e
        }))).join(",")
    }

    function Un(e, t = null) {
        if (!freestar.newAdSlotsAllowed) return function({
            elements: e = [],
            channel: t = null
        }) {
            freestar.newAdSlotsQueue.push(new class {
                constructor(e = [], t = null) {
                    this.elements = e, this.channel = t, this.used = !1
                }
                process() {
                    this.used || (freestar.log(1, "Invoking process for queued new ad slot for the following elements ", this.elements), freestar.log(1, "Invoking process for queued new ad slot using the following channel ", this.channel), this.used = !0, freestar.newAdSlots(this.elements, this.channel))
                }
            }(e, t))
        }({
            elements: e,
            channel: t
        }), void freestar.log(1, "The method newAdSlots not allowed while page grabber is active. Placement the following elements / channel in the newAdSlotsQueue : ", arguments);
        if (freestar.log(10, "newAdSlots invoked", ...arguments), On()) throw new Error("Ad serving is blocked in " + freestar.locData.iso);
        if (void 0 === e) return;
        Array.isArray(e) || (e = [e]);
        let n = O(e = e.filter((e => {
            const {
                placementName: t
            } = e, n = null != Ti({
                name: t
            });
            return n || freestar.log(30, "newAdSlots", `cannot find placement for ${t}, ignoring`), n
        })), "slotId");
        if (!window.freestar.loaded || !window.fsprebid.libLoaded || !window.googletag) return freestar.log(10, "newAdSlots", "Objects not ready, returning..."), freestar.queue.timers = freestar.queue.timers || {}, void(freestar.queue.timers && n[0] && n[0].slotId && (freestar.queue.timers[n[0].slotId] && clearTimeout(freestar.queue.timers[n[0].slotId]), freestar.queue.timers[n[0].slotId] = setTimeout(Un, 100, ...arguments)));
        !t && freestar.config.channel && (t = freestar.config.channel), freestar.config.orignalChannel || (freestar.config.orignalChannel = "{{channel}}"), t && freestar.config.orignalChannel != t && (freestar.log(99, "newAdSlots", "Channel is different than originally set, modifying dfpIds"), freestar.fsdata.placements = freestar.fsdata.placements.map((e => (e.dfpId = e.dfpId.replace(freestar.config.orignalChannel, t), e))), freestar.config.orignalChannel = t, freestar.log(99, "newAdSlots", "New dfpIDs", freestar.fsdata.placements.map((e => e.dfpId))));
        for (let e = 0; e < n.length; e++)
            if (-1 === freestar.enabledSlotsCalled.indexOf(n[e].slotId)) {
                De() ? jt.refreshLibraryCreator(n[e].placementName) : freestar.refreshLibraryCreator(n[e].placementName);
                const {
                    placementName: t,
                    slotId: i,
                    targeting: r
                } = n[e], s = document.getElementById(i), a = Ti({
                    name: t
                });
                if (a && (jn({
                        placement: a,
                        slotId: i,
                        targeting: r,
                        newElement: n[e],
                        element: s
                    }), s && (Ln({
                        placement: a,
                        element: s,
                        newElement: n[e]
                    }), freestar.newAdSlotsCalled.push(s.id), void 0 === n[e].skipSAU))) {
                    const e = Bn();
                    e.isSlidingUnit({
                        placement: a
                    }) && e.attachSlidingUnit({
                        adUnit: a,
                        slotId: i
                    })
                }
            }
        Tn()
    }
    class qn {
        constructor() {
            this.slug = "fsxs2s"
        }
        addToPlacementAsBidder() {
            return {
                bidder: this.slug,
                params: {}
            }
        }
        getSlug() {
            return this.slug
        }
        hasTopLevelStoredRequest() {
            const {
                topLevelStoredRequestId: e
            } = window.freestar.fsdata;
            return e && e.length
        }
        hasImpLevelStoredRequests() {
            const {
                placements: e
            } = window.freestar.fsdata;
            return e.filter((e => e.storedRequestId && e.storedRequestId.length)).length
        }
        hasValidStoredRequests() {
            return this.hasImpLevelStoredRequests() || this.hasTopLevelStoredRequest()
        }
    }

    function $n(e) {
        let t = {},
            n = he({
                code: e.name,
                sizes: e.sizes,
                mediaTypes: null,
                bids: e.bidders
            }),
            i = Fn(e);
        n.ortb2Imp = {
            ext: {
                data: {
                    fs_ad_product: i
                }
            },
            tagid: e.name
        }, e.storedRequestId && (n.ortb2Imp.ext.prebid = {
            storedrequest: {
                id: e.storedRequestId
            }
        });
        let r = !1;
        if (e.sizeMappings.forEach((n => {
                !r && bn() >= n.viewport.size[0] && (n.mediaTypes.forEach((i => {
                    var r;
                    void 0 === t[i] && (t[i] = {}), void 0 === t[i].sizes && (t[i].sizes = []), n.size.forEach((e => {
                        if (e[0] < 35843) {
                            if (("banner" === i || "native" === i) && "302x170, 443x250, 554x312, 640x360".includes(`${e[0]}x${e[1]}`)) return;
                            t[i].sizes.push(e)
                        }
                    })), t[i].sizes = (r = t[i].sizes, [...new Set(r)]);
                    const s = a.map((e => e.join("x"))),
                        o = e.sizes.filter((e => Array.isArray(e))).map((e => e.join("x")));
                    t[i].sizes = t[i].sizes.filter((e => {
                        if (-1 !== s.indexOf(e.join("x")) || -1 !== o.indexOf(e.join("x"))) return e
                    })), t[i].sizes = t[i].sizes.sort(((e, t) => e[0] + e[1] < t[0] + t[1] ? 1 : t[0] + t[1] < e[0] + e[1] ? -1 : 0)), "native" === i && (t[i] = Object.assign(t[i], {
                        type: "image",
                        sendTargetingKeys: !1
                    }))
                })), r = !0)
            })), n.mediaTypes = t, !n.bids) return;
        for (let e = n.bids.length - 1; e >= 0; e--) {
            if (n.bids[e].dynamicId && (n.bids[e].params.id = ++freestar.dynamicIdNum), n.bids[e].bidder) {
                const t = {
                        minViewPort: [0, 0],
                        relevantMediaTypes: ["banner", "native"]
                    },
                    r = {
                        minViewPort: [0, 0],
                        relevantMediaTypes: ["banner", "native", "video"]
                    };
                switch (n.bids[e].bidder) {
                    case "zid":
                        n.bids[e].params.adUnitID = Number(n.bids[e].params.adUnitID), n.bids[e].sizeConfig = [t];
                        break;
                    case "appnexus":
                        n.bids[e].params.keywords = {
                            fs_ad_product: [i || ""]
                        }, n.bids[e].sizeConfig = [r];
                        break;
                    case "amazon":
                        n.bids.splice(e, 1), n.bids[e].sizeConfig = [t];
                        break;
                    case "onemobile":
                        n.bids[e].params.ext = Object.assign(n.bids[e].params.ext || {}, {
                            req: location.href
                        }), n.bids[e].sizeConfig = [t];
                        break;
                    case "ttd":
                        n.bids[e].params.publisherId = freestar.fsdata.companyId, n.bids[e].sizeConfig = [t];
                        break;
                    case "gourmetads":
                        n.bids[e].params.use_pmt_rule && "true" === n.bids[e].params.use_pmt_rule && (n.bids[e].params.use_pmt_rule = !0), n.bids[e].params.usePaymentRule && "true" === n.bids[e].params.usePaymentRule && (n.bids[e].params.usePaymentRule = !0), n.bids[e].sizeConfig = [t];
                        break;
                    case "resetdigital":
                        Vn() || n.bids.splice(e, 1);
                        break;
                    case "pubmatic":
                    case "rubicon":
                    case "ix":
                    case "unruly":
                    case "yieldmo":
                    case "openx":
                    case "yahoo":
                    case "mediagrid":
                        n.bids[e].sizeConfig = [r];
                        break;
                    default:
                        n.bids[e].sizeConfig = [t]
                }
            }
            n.bids[e].size ? Hn(n.bids[e].size[0], n.mediaTypes.banner.sizes) || n.bids.splice(e, 1) : n.bids[e].params.size && (Hn(n.bids[e].params.size, n.mediaTypes.banner.sizes) || n.bids.splice(e, 1))
        }
        const s = new qn;
        return s.hasValidStoredRequests() && !e.ignoreSiteBidders && n.bids.push(s.addToPlacementAsBidder()), n
    }

    function Hn(e, t) {
        for (let n = 0; n < t.length; n++)
            if (JSON.stringify(e) === JSON.stringify(t[n])) return !0;
        return !1
    }

    function Vn() {
        const e = window.freestar.locData && window.freestar.locData.iso || null,
            t = window.freestar.locData && window.freestar.locData.state || null;
        return "US" === e && !["CA", "CO", "CT", "VA", "UT"].includes(t)
    }
    const Gn = () => window.freestar.fsdata.placements.find((e => e.interstitialOptions && e.interstitialOptions.active && "GOOGLE_INTERSTITIAL" === e.interstitialOptions.type));

    function Wn({
        event: e
    }) {
        return window.freestar.googleInterstitialPlacement && e.slot.getSlotElementId().includes(window.freestar.googleInterstitialPlacement.placement.dfpId)
    }
    let Qn;
    const Yn = new Uint8Array(16);

    function Kn() {
        if (!Qn && (Qn = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !Qn)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
        return Qn(Yn)
    }
    const Jn = [];
    for (let e = 0; e < 256; ++e) Jn.push((e + 256).toString(16).slice(1));
    var Xn = {
        randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
    };

    function Zn(e, t, n) {
        if (Xn.randomUUID && !t && !e) return Xn.randomUUID();
        const i = (e = e || {}).random || (e.rng || Kn)();
        if (i[6] = 15 & i[6] | 64, i[8] = 63 & i[8] | 128, t) {
            n = n || 0;
            for (let e = 0; e < 16; ++e) t[n + e] = i[e];
            return t
        }
        return function(e, t = 0) {
            return Jn[e[t + 0]] + Jn[e[t + 1]] + Jn[e[t + 2]] + Jn[e[t + 3]] + "-" + Jn[e[t + 4]] + Jn[e[t + 5]] + "-" + Jn[e[t + 6]] + Jn[e[t + 7]] + "-" + Jn[e[t + 8]] + Jn[e[t + 9]] + "-" + Jn[e[t + 10]] + Jn[e[t + 11]] + Jn[e[t + 12]] + Jn[e[t + 13]] + Jn[e[t + 14]] + Jn[e[t + 15]]
        }(i)
    }
    const ei = "_FOOTER_ONLY";

    function ti(e) {
        return e.freestarBrandingDisabled && !0 === e.freestarBrandingDisabled ? null : e && e.stickyFooterOptions && e.stickyFooterOptions.active ? ii() : ni()
    }

    function ni() {
        const {
            branding: e
        } = freestar.fsdata;
        return e && "NO_BRANDING" !== e && !e.endsWith(ei) ? e : null
    }

    function ii() {
        const {
            branding: e
        } = freestar.fsdata;
        return e && "NO_BRANDING" !== e ? e.endsWith(ei) ? e.slice(0, -ei.length) : e : null
    }

    function ri() {
        return freestar.fsdata.adQualityOptions && freestar.fsdata.adQualityOptions.confiantReportThisAdEnabled && Pt.allowConfiant() || "true" === lt("fsreportad")
    }
    const si = ({
            placement: e,
            sizes: t
        }) => {
            if (!e) return !1;
            const {
                pushdownOptions: n,
                stickyFooterOptions: i,
                interstitialOptions: r
            } = e;
            return !(n.isPushdownUnit || i.active || r.active || hi(t))
        },
        ai = ({
            ancillary: e,
            placement: t
        }) => {
            const n = Fn(t),
                i = sn({
                    type: "div",
                    classList: ["__fs-branding"]
                }),
                r = sn({
                    type: "a",
                    attributes: [{
                        href: `https://ads.freestar.com/?utm_campaign=branding&utm_medium=${n}&utm_source=${window.freestar.fsdata.domain}&utm_content=${t.name}`
                    }, {
                        target: "_blank"
                    }, {
                        rel: "noreferrer"
                    }]
                }),
                s = sn({
                    type: "img",
                    src: `https://a.pub.network/core/imgs/fslogo-${ti(t).toLowerCase()}.svg`,
                    attributes: [{
                        alt: "freestar"
                    }, {
                        width: "14"
                    }, {
                        height: "14"
                    }]
                });
            r.appendChild(s), i.appendChild(r), e.appendChild(i)
        };

    function oi(e, t, n) {
        const i = function(e, t) {
                if (freestar.currentStickyFooter && freestar.currentStickyFooter.placement) {
                    if (freestar.currentStickyFooter.placement.name === t.id) return "sticky-reportThisAd";
                    if (e.pushdownOptions.isPushdownUnit) return "pushdown-reportThisAd"
                }
                return null
            }(t, n),
            r = n.id,
            s = sn({
                id: `__fs-reportThisAd-${r}`
            }),
            a = `btn-${r}`,
            o = sn({
                classList: ["report-ad-container", i]
            }),
            d = sn({
                type: "button",
                id: a,
                classList: ["report-ad-button"],
                attributes: [{
                    "aria-label": "Report this ad"
                }]
            });
        d.style.marginTop = "8px", d.style.fontSize = "12px", d.style.color = "black", d.style.textDecoration = "none", d.style.cursor = "pointer", d.style.background = "none", d.style.marginLeft = "auto", d.style.marginRight = "auto", d.style.display = "block", d.style.border = "none", d.innerHTML = "Report this ad", d.addEventListener("click", (function(e) {
            try {
                const t = e.target.id.slice(4);
                window.confiant.services().reportSingleAd(t)
            } catch (e) {
                alert("Unable to report the ad: " + e.toString())
            }
        })), t.stickyFooterOptions && t.stickyFooterOptions.active && ("mobile" === freestar.deviceInfo.device.type && ("sticky-reportThisAd" === i && (o.style.top = "46px", o.style.right = "0px"), d.style.marginTop = "5px"), "NO_BRANDING" !== freestar.fsdata.branding && (d.style.display = "none")), o.appendChild(d), s.appendChild(o), e.appendChild(o)
    }
    const di = ({
            ancillary: e,
            placement: t,
            element: n
        }) => {
            if (null === n.querySelector(".report-ad-container") && (!t || !t.adQualityOptions || !0 !== t.adQualityOptions.disabled) && (freestar.fsdata.reportThisAd || freestar.fsdata.adQualityOptions && freestar.fsdata.adQualityOptions.confiantReportThisAdEnabled && Pt.allowConfiant() || "true" === lt("fsreportad"))) {
                "CONFIANT" == on() && freestar.fsdata.adQualityOptions && freestar.fsdata.adQualityOptions.confiantReportThisAdEnabled && Pt.allowConfiant() && oi(e, t, n)
            }
        },
        li = ({
            event: e
        }) => {
            ! function({
                event: e
            }) {
                t = e.slot.getSlotElementId(),
                    function({
                        element: e,
                        target: t,
                        targetIFrame: n,
                        placement: i
                    }) {
                        (function({
                            element: e,
                            target: t,
                            targetIFrame: n,
                            placement: i
                        }) {
                            if (!(e && t && n && i)) return void freestar.log(30, "not applying branding, missing attribute", {
                                element: e,
                                target: t,
                                targetIFrame: n,
                                placement: i
                            });
                            if (!ti(i)) return void freestar.log(20, "not applying branding, feature not active for placement", e.id, i);
                            const r = i.sizes.sort().reverse();
                            if (!isNaN(r[0][0]) && !si({
                                    placement: i,
                                    sizes: r
                                })) return void freestar.log(30, "not applying report-this-ad based on sizes or non-standard product type", e.id, r, i);
                            const s = ci(t);
                            s.querySelector(".__fs-branding") ? freestar.log(20, "Not applying branding, already exists!", e.id) : (freestar.log(20, "applying branding", e.id), ai({
                                ancillary: s,
                                placement: i
                            })), pi(e, n, s, r)
                        })({
                            element: e,
                            target: t,
                            targetIFrame: n,
                            placement: i
                        }),
                        function({
                            element: e,
                            target: t,
                            targetIFrame: n,
                            placement: i
                        }) {
                            if (!(e && t && n && i)) return void freestar.log(30, "not applying report-this-ad, missing attribute", {
                                element: e,
                                target: t,
                                targetIFrame: n,
                                placement: i
                            });
                            if (!ri()) return void freestar.log(20, "not applying report-this-ad, feature not active");
                            const {
                                stickyFooterOptions: r
                            } = i, s = i.sizes.sort().reverse();
                            if (!isNaN(s[0][0]) && !si({
                                    placement: i,
                                    sizes: s
                                }) && !r.active) return void freestar.log(30, "not applying report-this-ad based on sizes or non-standard product type", e.id, s, i);
                            const a = r.active ? t : ci(t);
                            freestar.log(20, "applying report-this-ad", e.id), di({
                                ancillary: a,
                                placement: i,
                                element: e
                            }), r.active || pi(e, n, a, s)
                        }({
                            element: e,
                            target: t,
                            targetIFrame: n,
                            placement: i
                        })
                    }(function(e) {
                        const t = document.getElementById(e),
                            n = !!t && t.querySelector('div[id*="google_ads_iframe_"]'),
                            i = !!n && n.querySelector("iframe"),
                            r = !!t && Ti({
                                name: t.getAttribute("name") || t.parentNode.getAttribute("name")
                            });
                        return {
                            element: t,
                            target: n,
                            targetIFrame: i,
                            placement: r
                        }
                    }(t));
                var t
            }({
                event: e
            })
        };

    function ci(e) {
        let t = e.querySelector(".__fs-ancillary");
        return t || (t = sn({
            type: "div",
            classList: ["__fs-ancillary"]
        }), e.appendChild(t)), t
    }
    const fi = {},
        ui = 10;

    function pi(e, t, n, i) {
        freestar.log(20, "setting ancillary style timeout", e.id), clearTimeout(fi[e.id]);
        const r = t.width <= 1 ? 1500 : ui;
        fi[e.id] = setTimeout((function() {
            freestar.log(20, "ancillary style timeout fired", e.id), n.style.setProperty("--childWidth", t.width < 2 ? i[0][0] + "px" : t.width + "px"), n.style.setProperty("visibility", "visible")
        }), r)
    }
    const hi = e => 1 === e.length && 1 === e[0][0] && 1 === e[0][1],
        mi = e => Array.isArray(e) && e.length > 1 && 35843 === e[0],
        gi = ({
            placement: e
        }) => {
            let t = "";
            if (!e) return t;
            const n = e.sizes.filter((e => Array.isArray(e))),
                i = {
                    w: T(n, (e => e[0])),
                    h: T(n, (e => e[1]))
                };
            return i.w && i.w.length && (t += `__${i.w.join("x")}`), i.h && i.h.length && (t += `  __${i.h.join("x")}`), ti(e) && (t += " __fsAncillary"), t
        };
    const bi = () => Zn();

    function yi() {
        let e = window.innerWidth,
            t = window.innerHeight,
            n = document.body,
            i = document.documentElement,
            r = Math.max(n.scrollHeight, n.offsetHeight, i.clientHeight, i.scrollHeight, i.offsetHeight),
            s = document.querySelector("link[rel='canonical']"),
            a = "";
        s && (a = s.getAttribute("href")), 0 === freestar.msg.loadTime && (freestar.msg.loadTime = Date.now() - freestar.hitTime), window.googletag.cmd.push((function() {
            freestar.msg.que.push({
                eventType: "browserInformation",
                args: {
                    canonical: a,
                    fpc: freestar.msg.fpc,
                    hitTime: freestar.hitTime,
                    loadTime: freestar.msg.loadTime,
                    winHeight: t,
                    winWidth: e,
                    maxHeight: r,
                    isServerToServer: freestar.server.diceRoll,
                    googleVersion: window.googletag.getVersion() || "",
                    admiralEnabled: !!ot({
                        name: "fs.admiral.whitelisted"
                    })
                }
            })
        }))
    }

    function wi(e) {
        vi(e, !0)
    }

    function vi(e, t) {
        if (!e) return;
        const n = e.slot.getSlotElementId(),
            i = e.slot.getAdUnitPath(),
            r = ve({
                slotId: n,
                path: i
            }),
            s = {
                elementId: n,
                creativeId: e.creativeId,
                adUnitPath: i,
                placementId: r,
                displayed: !e.isEmpty
            },
            a = e.slot.getTargeting("hb_auction_id");
        0 !== a.length && (s.auctionId = a[0]), r && "unknown" !== r && (Be({
            name: "adServerResponse",
            detail: s
        }), freestar.pushdownControl && freestar.pushdownControl.postGamResponse && freestar.pushdownControl.postGamResponse({
            event: e
        }), function({
            eventObject: e,
            event: t,
            complete: n
        }) {
            n ? t = freestar.dfpSlotInfo[e.elementId] : freestar.dfpSlotInfo[e.elementId] = t, t && e && !Wn({
                event: t
            }) && freestar.msg.que.push({
                seen: !1,
                eventType: "dfpResponse",
                slotId: e.elementId,
                args: {
                    placementId: e.placementId,
                    DfpId: e.adUnitPath,
                    advertiserId: t.advertiserId,
                    campaignId: t.campaignId,
                    isEmpty: t.isEmpty,
                    lineItemId: t.lineItemId,
                    serviceName: t.serviceName,
                    size: JSON.stringify(t.size),
                    sourceAgnosticCreativeId: t.sourceAgnosticCreativeId,
                    sourceAgnosticLineItemId: t.sourceAgnosticLineItemId,
                    parentDiv: e.elementId,
                    complete: n || !1,
                    auctionId: e.auctionId ? e.auctionId : null
                }
            }), t && Wn({
                event: t
            }) && (window.freestar.googleInterstitialPlacement || (window.freestar.googleInterstitialPlacement = {}), window.freestar.googleInterstitialPlacement.event = t)
        }({
            event: e,
            eventObject: s,
            complete: t
        }), function({
            event: e
        }) {
            if (e.isEmpty) return;
            const t = e.slot.getSlotElementId();
            if (!t) return;
            const n = freestar.bidsWon[t];
            n && n.time && Date.now() - n.time > 29e3 && delete freestar.bidsWon[t], e && (freestar.adReportTracking[t] = new me(e))
        }({
            event: e
        }), freestar.fsdata.customDirectAdRefresh && Se(), Ae(e))
    }

    function Ii(e) {
        if (freestar.debug < 50) return;
        freestar.log(25, "GPT Targeting - START ************************");
        let t = googletag.pubads().getTargetingKeys();
        for (let e = 0; e < t.length; e++) {
            let n = googletag.pubads().getTargeting(t[e]);
            freestar.log(25, "GPT Targeting - " + t[e] + " = " + n)
        }
        e ? Array.isArray(e) || (e = [e]) : e = Gt();
        for (let n = 0; n < e.length; n++) {
            let i = e[n],
                r = i.getSlotElementId();
            t = i.getTargetingKeys();
            for (let e = 0; e < t.length; e++) {
                let n = i.getTargeting(t[e]);
                freestar.log(25, " GPT Targeting - Slot (" + r + ")- " + t[e] + " = " + n)
            }
        }
        freestar.log(25, " GPT Targeting - END **************************")
    }
    const Ai = function(e = null) {
        const t = !!e && window.freestar.fsdata[`${e}ZIndex`];
        return t && t > 0 ? t : (() => {
            let e = 0;
            return Object.values(document.styleSheets).forEach((t => {
                try {
                    const n = t.cssRules;
                    Object.values(n).forEach((t => {
                        const {
                            style: n
                        } = t;
                        if (n) {
                            const t = parseInt(n.getPropertyValue("z-index"), 10);
                            t && t > e && (e = t)
                        }
                    }))
                } catch (e) {}
            })), Array.from(document.getElementsByTagName("*")).forEach((t => {
                const n = parseInt(t.style.zIndex, 10);
                n && n > e && (e = n)
            })), e + 1
        })()
    };

    function ki() {
        return document.body.getElementsByTagName("*")[0]
    }

    function Si(e, t, n) {
        return !!(t && e && n) && (document.body.insertBefore(t, e), document.body.getElementsByTagName("*")[0].id === n.name)
    }

    function xi(e) {
        let t = sn({
            type: "style",
            attributes: [{
                "data-owner": "freestar"
            }]
        });
        t.textContent = e, document.head.append(t)
    }

    function Ei(e = Gt() || []) {
        freestar.debug < 2 || e.forEach((e => function(e, t) {
            const n = document.getElementById(e);
            if (n) {
                let e = sn("div"),
                    i = document.createTextNode("FS - " + t);
                e.appendChild(i), n.insertBefore(e, n.childNodes[0])
            }
        }(e.getSlotElementId(), e.getAdUnitPath())))
    }

    function Oi(e) {
        let t = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
            n = e.getBoundingClientRect().top + Math.trunc(e.scrollHeight / 2);
        return n > 0 && n <= t
    }
    const _i = e => e.indexOf("#") > -1 ? document.querySelector(e) : document.querySelectorAll(e)[0],
        Ti = ({
            name: e
        }) => window.freestar.fsdata.placements.filter((t => t.name === e))[0];

    function Ci({
        placement: e,
        slotId: t,
        slotConfig: n,
        targeting: i = {}
    }) {
        if (!e) return;
        we({
            placementName: e.name,
            slotId: t || e.name
        });
        let r = function({
            slotIds: e
        }) {
            return Gt().map((function(t) {
                if (!e || e.indexOf(t.getSlotElementId()) > -1) return t
            })).filter((e => void 0 !== e))
        }({
            slotIds: [t || e.name]
        })[0];
        r || (r = Jt({
            placement: e,
            id: t,
            slotConfig: n
        })), r && Pn(r, e.name, null, Object.assign(i, {
            fs_ad_product: Fn(e)
        }));
        const s = $n(e);
        return t && (s.code = t), {
            slot: r,
            bidObject: s,
            placement: e
        }
    }
    const Ri = ({
            element: e
        }) => {
            let t = !1;
            return (({
                element: e
            }) => {
                const t = document.styleSheets,
                    n = [],
                    i = t.length;
                for (let r = 0; r < i; r++) try {
                    const i = t[r].cssRules,
                        s = i.length;
                    for (let t = 0; t < s; t++) e.matches(i[t].selectorText) && n.push(i[t].cssText)
                } catch (e) {}
                return n
            })({
                element: e
            }).forEach((e => {
                e.indexOf("overflow") > -1 && (t = !0)
            })), t
        },
        Ni = e => e.intersectionRatio > 0 && e.isIntersecting && _(e, "target.id.length", 0) > 1;

    function Mi() {
        if (!Pt.getBypassFirstAuction()) {
            const e = freestar.fsdata.networks.filter((e => "amazon" === e.slug))[0];
            if (e) {
                const t = -1 !== Pt.getAllBidders().indexOf("amazon"),
                    n = -1 !== Pt.getActiveBidders().indexOf("amazon");
                if (t && n) {
                    freestar.amazonNetwork = e;
                    const t = freestar.amazonNetwork.sizes.filter((e => e.params.publisherId))[0];
                    freestar.amazonPublisherId = t && t.params && t.params.publisherId && E(t.params.publisherId) ? t.params.publisherId : "0ab198dd-b265-462a-ae36-74e163ad6159", ! function(e, t, n, i, r, s, a) {
                        function o(n, i) {
                            t[e]._Q.push([n, i])
                        }
                        t[e] || (t[e] = {
                            init: function() {
                                o("i", arguments)
                            },
                            fetchBids: function() {
                                o("f", arguments)
                            },
                            setDisplayBids: function() {},
                            targetingKeys: function() {
                                return []
                            },
                            _Q: []
                        }, (s = n.createElement(i)).async = !0, s.src = "//c.amazon-adsystem.com/aax2/apstag.js", (a = n.getElementsByTagName(i)[0]).parentNode.insertBefore(s, a))
                    }("apstag", window, document, "script"), window.apstag.init({
                        pubID: freestar.amazonPublisherId,
                        adServer: "googletag",
                        schain: {
                            complete: 1,
                            ver: "1.0",
                            nodes: [{
                                asi: "freestar.com",
                                sid: `${window.freestar.fsdata.companyId}`,
                                hp: 1
                            }]
                        }
                    })
                }
            }
        }
    }

    function Di(e) {
        return e.bidders && e.bidders.some((({
            bidder: e
        }) => "amazon" === e))
    }

    function Bi(e) {
        let t = vn();
        for (let n = 0; n < t.length; n++)
            if (t[n].dfpId === e) return t[n];
        return null
    }

    function Pi(e) {
        let t = [];
        if (e)
            for (let n = 0; n < e.length; n++) {
                let i = null;
                try {
                    i = freestar.dynamicSlotLibrary[e[n].getSlotElementId()], i && (i = Ti({
                        name: i
                    })), i || (i = freestar.fsdata.placements.filter((t => {
                        if (e[n].getSlotElementId() === t.slotId) return t
                    })), 0 === i.length && (i = null)), i || (i = Bi(e[n].getAdUnitPath()))
                } catch (e) {
                    freestar.log(1, `Error: ${e}`)
                }
                if (i && Di(i)) {
                    const r = i.sizeMappings.find((e => bn() >= e.viewport.size[0]));
                    let s = r ? r.size : [];
                    if (s.length > 0 && (s = s.filter((e => 35843 !== e[0]))), s.length > 0) {
                        const i = e[n],
                            r = {
                                slotID: i.getSlotElementId(),
                                slotName: i.getAdUnitPath(),
                                sizes: s
                            };
                        t.push(he(r))
                    }
                }
            } else t = vn().filter((e => Di(e) && In(e))).map((e => function(e) {
                const t = e.sizeMappings.find((e => bn() >= e.viewport.size[0]));
                let n = t ? t.size : [];
                return n = n.filter((e => 35843 !== e[0])), he({
                    slotID: e.name,
                    slotName: e.dfpId,
                    sizes: n
                })
            }(e)));
        return t
    }

    function zi({
        adUnitCodesWithNoBids: e,
        isTimeout: t
    }) {
        Gt().forEach((n => {
            if (t) n.setTargeting("fsbid", "timeout");
            else if (e) {
                const t = n.getAdUnitPath(),
                    i = En({
                        adUnitPath: t
                    });
                i && e.indexOf(i.name) > -1 && n.setTargeting("fsbid", "0")
            }
        }))
    }

    function Li({
        auctionData: e
    }) {
        const {
            bidsReceived: t,
            noBids: n
        } = e, i = function({
            bidsReceived: e,
            noBids: t
        }) {
            let n = fsprebid.adUnits.map((e => e.code)).reduce(((e, t) => (e[t] = !1, e)), {});
            return e && e.forEach((e => {
                e.cpm > 0 && (n[e.adUnitCode] = !0)
            })), Object.keys(n).filter((e => 0 == n[e]))
        }({
            bidsReceived: t,
            noBids: n
        });
        zi({
            adUnitCodesWithNoBids: i,
            isTimeout: !1
        })
    }

    function ji(e, t, n, i) {
        if (!(e = function({
                elementIds: e
            }) {
                return e && e.length ? (Array.isArray(e) || (e = [e]), !(!e || !e.length) && e) : freestar.fsdata.placements.map((e => {
                    if (e.validAdSizes && !e.stickyFooter && !e.pushdownUnit && 0 === e.sideWallType && document.getElementById(e.name)) return e.name
                })).filter((e => void 0 !== e))
            }({
                elementIds: e
            })) || !e.length) return;
        Be({
            name: "auctionStarted",
            detail: !0
        }), P.logMark({
            markerName: A.pubfigPrebidFsRequestBids
        });
        const r = n || window.freestar.fsdata.timeout,
            s = {
                prebid: !1,
                aps: !1,
                adserverRequestSent: !1
            };

        function a(e) {
            freestar.debug && freestar.debug > 24 && "prebid" === e && setTimeout((() => {
                wt()
            }), 1500), freestar.log(1, " (" + freestar.requestReference.requestNum + ") Bidder back:", e), s.prebid && s.aps && l()
        }

        function o(e) {
            let t, n, i = !0;
            const r = fsprebid.getBidResponses()[e.domId],
                s = Ti({
                    name: ve({
                        slotId: e.placementName
                    })
                });
            return r && s ? (n = T(r.bids, (function(e) {
                return Number(e.cpm)
            })), t = s[`floor${freestar.deviceInfo.device.type.charAt(0).toUpperCase()+freestar.deviceInfo.device.type.slice(1)}`], x(t) && t > 0 && n && n.cpm && n.cpm < t && (i = !1), i) : i
        }

        function d(e) {
            return freestar.dynamicSlotLibrary[e] ? freestar.dynamicSlotLibrary[e] : e
        }

        function l() {
            !0 !== s.adserverRequestSent && (s.adserverRequestSent = !0, freestar.requestReference.bidTimer && clearTimeout(freestar.requestReference.bidTimer), freestar.log(2, " (" + freestar.requestReference.requestNum + ") Sending adserver request!"), googletag.cmd.push((function() {
                const t = {
                    activeIds: [],
                    activeSlots: []
                };
                if (Array.isArray(e) && e.length) {
                    const n = [];
                    freestar.log(2, " (" + freestar.requestReference.requestNum + ") Refresh Only:", e), freestar.amazonNetwork && apstag.setDisplayBids(e), e.forEach((e => {
                        let t = document.getElementById(e);
                        if (t) {
                            const e = Ti({
                                name: ve({
                                    slotId: t.getAttribute("name")
                                })
                            });
                            e && n.push(e.name)
                        }
                    }));
                    const i = function() {
                        const t = {
                            activeIds: [],
                            activeSlots: []
                        };
                        return e.forEach((e => {
                            const n = Wt({
                                elementId: e
                            });
                            n && t.activeSlots.push(n), o({
                                placementName: d(e),
                                domId: e
                            }) && t.activeIds.push(e)
                        })), t
                    }();
                    t.activeIds = i.activeIds, t.activeSlots = i.activeSlots
                } else freestar.log(2, " (" + freestar.requestReference.requestNum + ") Refresh All!"), freestar.amazonNetwork && apstag.setDisplayBids(), t.activeIds = function() {
                    const e = [];
                    return Gt().forEach((t => {
                        const n = t.getSlotElementId();
                        freestar.bidsWon && freestar.bidsWon[n] && !freestar.bidsWon[n] && (freestar.bidsWon[n].evaluated = !0, o({
                            placementName: d(n),
                            domId: n
                        }) && e.push(n))
                    })), e
                }();
                const n = function() {
                    let e = ot({
                        name: "_fs-test"
                    });
                    return e && (e = JSON.parse(e), e.items.some(((t, n) => {
                        t == e.selection && (e.selected = n, e.testGroup = t.indexOf("ab_test") > -1 ? 1 : 0)
                    }))), e
                }();
                n && (freestar.log(1, "Part of an A/B test... ", n), Ht({
                    key: "fs_test_variant_id",
                    value: String(n.testGroup)
                })), t.activeSlots.length && (t.activeIds.length && fsprebid.setTargetingForGPTAsync(t.activeIds), Ii(t.activeSlots), function(e) {
                    !0 === freestar.googletagCorrelatorUpdate ? (googletag.pubads().refresh(e), freestar.googletagCorrelatorUpdate = !1) : googletag.pubads().refresh(e, {
                        changeCorrelator: !1
                    })
                }(t.activeSlots), Ei(t.activeSlots)), i && i()
            })))
        }
        freestar.requestReference.bidTimer = null, freestar.requestReference.requestNum = ++freestar.bidRequestNum,
            function(e, t, n) {
                freestar.amazonNetwork && e.length ? freestar.amazonNetwork && (freestar.log(1, "valid Amazon Slots :", e), apstag.fetchBids({
                    slots: e,
                    timeout: n || 1e3
                }, (function(e) {
                    freestar.log(1, " (" + freestar.requestReference.requestNum + ") aps bids:", e), s.aps = !0, a("aps")
                }))) : (freestar.log(1, "no valid Amazon Slots : no amazon bidding"), s.aps = !0, a("aps"));
                const i = {
                    timeout: n || 1e3,
                    bidsBackHandler: function(e) {
                        freestar.log(1, " (" + freestar.requestReference.requestNum + ") prebid bid responses:", e), s.prebid = !0, a("prebid")
                    }
                };
                t && (i.adUnitCodes = t), fsprebid.que.push((function() {
                    fsprebid.requestBids(i)
                }))
            }(Pi(t), e, r), freestar.requestReference.bidTimer = window.setTimeout((function() {
                freestar.log(1, " (" + freestar.requestReference.requestNum + ") TIMEOUT!"), zi({
                    isTimeout: !0
                }), l()
            }), r)
    }

    function Fi({
        adUnits: e
    }) {
        if (Pt.getBypassFirstAuction()) return;
        Array.isArray(e) || (e = [e]);
        const t = e.filter((e => e && null != e.bids && e.bids.length > 0)),
            n = e.filter((e => !e || null == e.bids || 0 === e.bids.length));
        if (n.length > 0) {
            const e = n.map((e => e && e.code)).join(", ");
            freestar.log(20, `Not adding adUnits ${e} which have no bidders configured.`)
        }
        freestar.log(20, `Adding ${t.length} adUnits to fsprebid.`), fsprebid.que.push((function() {
            fsprebid.addAdUnits(t)
        }))
    }

    function Ui(e = new qn) {
        const {
            placements: t,
            networks: n
        } = window.freestar.fsdata, i = e => e.slug, r = n.map(i).concat(t.filter((e => e.networks.length)).map((({
            networks: e
        }) => e.map(i)))).flat().filter(((e, t, n) => n.indexOf(e) === t && !b.includes(e)));
        return e.hasValidStoredRequests() && r.push(e.getSlug()), r
    }

    function qi(e) {
        return e.sizes.forEach((e => {
            Object.keys(e.params).forEach((t => !e.params[t] && delete e.params[t]))
        }))
    }
    const $i = "Video Messaging: ";

    function Hi({
        eventType: e,
        args: t
    }) {
        window.freestar.msg.que.push({
            eventType: e,
            args: t
        })
    }

    function Vi({
        bidder: e,
        cpm: t = null,
        requestTimestamp: n,
        videoAd: i,
        playerType: r = null
    }) {
        const s = Date.now(),
            a = {
                bidder: e,
                cpm: t,
                playerType: r,
                placementId: i.name || i.id,
                requestTimestamp: n,
                responseTimestamp: s,
                timeToRespond: s - n
            };
        freestar.log({
            title: "VIDEO"
        }, $i + `bid won for bidder ${e} and placement id ${i.name}.\nVIDEO MSG OBJECT: ${JSON.stringify(a)}`), Hi({
            eventType: "outstreamBidWon",
            args: a
        })
    }

    function Gi({
        bidder: e,
        placementId: t,
        tagUrl: n
    }) {
        const i = {
            bidder: e,
            placementId: t,
            tagUrl: n
        };
        freestar.log({
            title: "VIDEO"
        }, $i + `tag loaded for bidder ${e} and placement id ${t}.\nVIDEO MSG OBJECT: ${JSON.stringify(i)}`), Hi({
            eventType: "outstreamTagLoad",
            args: i
        })
    }

    function Wi({
        type: e,
        device: t
    }) {
        return e && (t && "mobile" === t || "desktop" === t) && e[t] ? e[t] : e.mobile
    }

    function Qi({
        selectedSize: e
    }) {
        return e && e.videoAdhesionPosition && "DEFAULT_VIDEO_ADHESION_POSITION" !== e.videoAdhesionPosition ? e.videoAdhesionPosition : "BR"
    }
    const Yi = "PREBID VIDEO v1.5",
        Ki = {
            title: Yi,
            styles: "background: black; color: white; border-radius: 3px; padding: 3px"
        },
        Ji = {
            title: Yi,
            styles: "background: gold; color: black; border-radius: 3px; padding: 3px"
        },
        Xi = {
            title: Yi,
            styles: "background: lightblue; color: black; border-radius: 3px; padding: 3px"
        },
        Zi = {
            title: Yi,
            styles: "background: red; color: white; border-radius: 3px; padding: 3px"
        };
    let er = !1;

    function tr({
        callback: e = null,
        videoAd: t,
        placement: n,
        options: i = {
            rebid: !0
        }
    }) {
        er || (er = new nr), er.add({
            callback: e,
            placement: n,
            videoAd: t,
            options: i
        })
    }
    class nr {
        constructor() {
            this.loaded = !1, this.queued = !1, this.player = null, this.init()
        }
        init() {
            window.freestar.queue.push((() => {
                this.addVideoJSFiles(), this.bindVideoJSEvents()
            }))
        }
        addVideoJSFiles() {
            freestar.log(Ki, "Adding files...");
            [sn({
                type: "link",
                attributes: [{
                    rel: "stylesheet"
                }, {
                    href: "https://vjs.zencdn.net/7.20.2/video-js.css"
                }]
            }), sn({
                type: "link",
                attributes: [{
                    rel: "stylesheet"
                }, {
                    href: "https://cdnjs.cloudflare.com/ajax/libs/videojs-contrib-ads/6.9.0/videojs-contrib-ads.css"
                }]
            }), sn({
                type: "link",
                attributes: [{
                    rel: "stylesheet"
                }, {
                    href: "https://cdnjs.cloudflare.com/ajax/libs/videojs-ima/1.11.0/videojs.ima.css"
                }]
            })].forEach((e => {
                document.head.appendChild(e)
            })), an("https://vjs.zencdn.net/7.20.2/video.min.js", (() => {
                an("https://imasdk.googleapis.com/js/sdkloader/ima3.js", (() => {
                    an("https://cdnjs.cloudflare.com/ajax/libs/videojs-contrib-ads/6.9.0/videojs-contrib-ads.js", (() => {
                        an("https://cdnjs.cloudflare.com/ajax/libs/videojs-ima/1.11.0/videojs.ima.js", (() => {
                            freestar.log(Ki, "Loaded files..."), this.loaded = !0, this.queued && (this.player = new ir(this.queued))
                        }))
                    }))
                }))
            }))
        }
        bindVideoJSEvents() {
            freestar.log(Ki, "Binding events..."), window.fsprebid.onEvent("auctionEnd", (e => {
                let {
                    adUnitCodes: t,
                    bidderRequests: n,
                    bidsReceived: i,
                    bidsRejected: r,
                    noBids: s
                } = e;
                t.forEach((e => {
                    -1 !== e.indexOf("_outstream") && (0 !== r.length && r.forEach((t => {
                        this.sendEvent({
                            type: "BID_REJECTED",
                            value: {
                                adUnitCode: e,
                                bid: t
                            }
                        })
                    })), i = i.filter((e => "video" === e.mediaType)), freestar.log(Ki, "Video auction results...", `\n${e} -\nBidders Requested: ${JSON.stringify(n.map((e=>`${e.bidderCode}`)).toString("\n"))}\nBids Received: ${JSON.stringify(i.map((e=>`${e.adapterCode}`)).toString("\n"))}\nBids Rejected: ${JSON.stringify(r.map((e=>`${e.adapterCode}: ${e.rejectionReason}`)).toString("\n"))}\nNo Bids Received: ${JSON.stringify(s.map((e=>`${e.bidder}`)).toString("\n"))}\n                    `), this.timer = setTimeout((() => {
                        clearTimeout(this.timer), this.player.playing || (this.player.remove({}), this.sendEvent({
                            type: "TIMEOUT",
                            value: {}
                        }))
                    }), 1e4))
                }))
            })), window.fsprebid.onEvent("videoSetupComplete", (e => {
                freestar.log(Ki, "Video Player ready, playing ad...");
                const {
                    videoPlayer: t
                } = this.player;
                t.loadMedia({
                    id: "XVXVXVXV",
                    src: "https://a.pub.network/core/videos/blank1s-20231016.mp4",
                    type: "video/mp4"
                }), setTimeout((() => {
                    t.play()
                }), 500), this.sendEvent({
                    type: "SETUP_COMPLETE",
                    value: {
                        e: e
                    }
                })
            })), window.fsprebid.onEvent("videoAdComplete", (e => {
                freestar.log(Ki, "Video ad complete, removing..."), this.player.remove({}), this.sendEvent({
                    type: "AD_COMPLETE",
                    value: {
                        e: e
                    }
                })
            }));
            const e = [];
            window.fsprebid.onEvent("videoAdImpression", (t => {
                const n = window.fsprebid.getConfig("ortb2");
                n && n.ext && n.ext.prebid && (n.ext.prebid.storedrequest.id = window.freestar.fsdata.topLevelStoredRequestId), window.fsprebid.mergeConfig({
                    ortb2: n
                }), this.timer = setTimeout((() => {
                    clearTimeout(this.timer);
                    const n = fsprebid.getAllWinningBids().filter((t => -1 === e.indexOf(t.adId) && t.adUnitCode === this.player.prebidAdUnit.code)),
                        i = n.bidderCode || t.adServer,
                        r = n.cpm || null;
                    n ? (e.push(n.adId), freestar.log(Ji, "Prebid ad impression, sending event...")) : freestar.log(Xi, "GAM ad impression, sending event..."), Vi({
                        bidder: i,
                        cpm: r,
                        requestTimestamp: this.player.requestTimestamp,
                        videoAd: this.player.ogPlacement,
                        playerType: Yi
                    }), this.sendEvent({
                        type: "AD_IMPRESSION",
                        value: {
                            e: t,
                            renderedBid: n
                        }
                    })
                }), 750)
            })), window.fsprebid.onEvent("videoAdLoaded", (e => {
                freestar.log(Ki, "Video ad loaded, showing player..."), this.player.playing = !0, this.player.toggleDisplay(), this.sendEvent({
                    type: "AD_LOADED",
                    value: {
                        e: e
                    }
                })
            }));
            ["videoDestroyed", "videoAdRequest", "videoAdBreakStart", "videoAdLoaded", "videoAdStarted", "videoAdImpression", "videoAdPlay", "videoAdPause", "videoAdClick", "videoAdSkipped", "videoAdError", "videoAdComplete", "videoAdBreakEnd", "videoPlaylist", "videoPlaybackRequest", "videoAutostartBlocked", "videoPlayAttemptFailed", "videoContentLoaded", "videoPlay", "videoPause", "videoBuffer", "videoSeekStart", "videoSeekEnd", "videoMute", "videoVolume", "videoRenditionUpdate", "videoError", "videoPlaylistComplete", "videoFullscreen", "videoPlayerResize", "videoViewable", "videoCast", "videoAuctionAdLoadAttempt", "videoAuctionAdLoadQueued", "videoAuctionAdLoadAbort", "videoBidImpression", "videoBidError"].forEach((e => {
                window.fsprebid.onEvent(e, (t => {
                    if (-1 !== e.indexOf("Failed") || -1 !== e.indexOf("Error")) return freestar.log(Zi, t), this.player.remove({}), void this.sendEvent({
                        type: "ERROR",
                        value: {
                            event: e,
                            e: t
                        }
                    })
                }))
            }))
        }
        sendEvent({
            name: e = "PREBID_VIDEOJS",
            type: t,
            value: n
        }) {
            freestar.log(Ki, "Sending event...", e, t, n), window.freestar.msg.que.push({
                eventType: "customEvent",
                args: {
                    eventName: e,
                    eventType: t,
                    jsonValue: JSON.stringify(Object.assign({
                        name: this.player.ogPlacement.name
                    }, n))
                }
            })
        }
        add({
            callback: e = null,
            placement: t,
            videoAd: n,
            options: i = null
        }) {
            freestar.log(Ki, "Adding video player..."), this.loaded ? this.player = new ir({
                callback: e,
                placement: t,
                videoAd: n,
                options: i
            }) : this.queued = {
                callback: e,
                placement: t,
                videoAd: n,
                options: i
            }
        }
    }
    class ir {
        constructor({
            callback: e = null,
            placement: t,
            videoAd: n,
            options: i = {
                rebid: !0
            }
        }) {
            this.uuid = bi(), this.callback = e, this.ogPlacement = t, this.placement = freestar.fsdata.placements.filter((e => {
                if (this.ogPlacement.name + "_outstream" === e.name) return e
            }))[0], this.baseAdTagUrl = i.baseAdTagUrl ? i.baseAdTagUrl : `https://pubads.g.doubleclick.net/gampad/ads?iu=${this.placement.videoGAMSlot}&description_url={player.pageUrl}&tfcd=0&npa=0&sz=1x1&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator={random}&url={player.pageUrl}&nofb=1&max_ad_duration=15000&schain=1.0,1!freestar.com,${window.freestar.fsdata.companyId},1`, this.videoAd = n, this.requestTimestamp = new Date, this.prebidAdUnit = null, this.apsSlot = this.videoAd.amazonApsSlot || `springserve_${window.freestar.fsdata.siteId}_${location.host.split(".").length>2?location.host.split(".")[1]:location.host.split(".")[0]}`, this.apsBids = !1, this.requestCount = 0, this.options = i, this.init()
        }
        init() {
            const e = window.fsprebid.getConfig("s2sConfig");
            this.ogPBSBidders = e.bidders, window.apstag ? this.callAPS() : this.createPlayerAndBid()
        }
        createPlayerAndBid() {
            this.addCSS(), this.createVideoPlayerPrebidAdUnit(), this.createVideoPlayer(), this.updatePrebidConfig({}), this.addVideoPlayer(), this.requestBids()
        }
        addCSS() {
            const e = sn({
                type: "style"
            });
            let t = "400px",
                n = "225px";
            if ("desktop" === freestar.deviceInfo.device.type) "LARGE" === this.videoAd.playerSize ? (t = "400px", n = "225px") : (t = "312px", n = "176px");
            else "LARGE" === this.videoAd.playerSize ? (t = "100%", n = "175px") : (t = "45%", n = "112px");
            const i = "B" === this.videoAd.videoAdhesionPosition.split("")[0] ? "bottom" : "top",
                r = "R" === this.videoAd.videoAdhesionPosition.split("")[1] ? "right" : "left";
            e.textContent = `\n            #fs-player-container {\n                position: fixed;\n                border: 1px solid black;\n                border-radius: 5px;\n                overflow: visible;\n                ${i}: 0;\n                ${r}: 0;\n                width: ${t};\n                height: ${n};\n                background-color: black;\n                display: flex;\n                align-items: center;\n                justify-content: center;\n                transition: ${r} .5s;\n                z-index: 2147483647;\n            }\n            .fs-player-close {\n                position: absolute;\n                top: -13px;\n                right: 5px;\n                width: 20px;\n                height: 20px;\n                display: flex;\n                align-items: center;\n                justify-content: center;\n                z-index: 2147483647;\n            }\n            .fs-player-close button {\n                top: inherit !important;\n                right: inherit !important;\n            }\n            .fs-player-container-shim {\n                width: ${t};\n                height: ${n};\n            }\n            .fs-player-container-shim video {\n                width: ${t};\n                height: ${n};\n            }\n            #fs-player-container.fs-hide {\n                visibility: hidden;\n            }\n        `, "desktop" === freestar.deviceInfo.device.type && (e.textContent += `\n                #fs-player-container {\n                    box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.75);\n                    ${i}: 10px;\n                    width: ${t};\n                    height: ${n};\n                }\n                #fs-player-container.fs-hide {\n                    ${r}: -${t};\n                }\n                #fs-player-container.fs-show {\n                    ${r}: 10px;\n                }\n            `), document.head.appendChild(e)
        }
        callAPS() {
            window.apstag.fetchBids({
                slots: [{
                    slotID: this.apsSlot,
                    mediaType: "video"
                }]
            }, (e => {
                this.apsBids = e, this.createPlayerAndBid()
            }))
        }
        getAPSBids() {
            if (!this.apsBids || this.apsBids.length <= 0) return "";
            const e = this.apsBids[0];
            return freestar.log(Ki, "Checking for APS bids...", e), "&cust_params=" + encodeURIComponent("amznbid=" + e.amznbid + "&amzniid=" + e.amzniid)
        }
        createVideoPlayerPrebidAdUnit() {
            freestar.log(Ki, "Creating video player Prebid ad unit..."), window.fsprebid.removeAdUnit(this.placement.code), this.prebidAdUnit = Object.assign($n(this.placement), {
                code: this.placement.name,
                mediaTypes: {
                    video: {
                        api: [2],
                        context: "outstream",
                        delivery: 2,
                        linearity: 2,
                        maxduration: window.freestar.fsdata.adRefreshRate,
                        mimes: ["video/mp4", "application/javascript", "video/webm"],
                        minduration: 1,
                        placement: 5,
                        playbackmethod: [6],
                        playerSize: this.placement.sizes[0],
                        plcmt: 4,
                        protocols: [2, 3, 5, 6],
                        size: this.placement.sizes[0],
                        skip: 0,
                        useCacheKey: !0
                    }
                },
                video: {
                    divId: "fsOutstreamPlayer_" + this.uuid
                }
            }), window.fsprebid.addAdUnits([this.prebidAdUnit]), freestar.log(Ki, "Added new ad unit to Prebid", this.prebidAdUnit)
        }
        createVideoPlayer() {
            freestar.log(Ki, "Creating video player elements...");
            const e = sn({
                type: "div",
                id: "fs-player-container",
                classList: ["fs-hide"]
            });
            e.innerHTML = `\n            <div class='fs-player-close' aria-labe='Close Player'>\n                <button class='fs-close-button'>&nbsp;</button>\n            </div>\n            <div class='fs-player-container-shim'>\n                <video id='fsOutstreamPlayer_${this.uuid}' muted class='video-js vjs-default-skin' playsinline></video>\n            </div>\n        `, document.body.appendChild(e), e.querySelector("button").addEventListener("click", (() => {
                this.remove({
                    params: {
                        userEnded: !0
                    }
                })
            }))
        }
        updatePrebidConfig() {
            freestar.log(Ki, "Updating Prebid config for video player...", `\nbaseAdTagUrl: ${this.baseAdTagUrl}`);
            const e = window.fsprebid.getConfig("ortb2");
            e && e.ext && e.ext.prebid && (e.ext.prebid.storedrequest.id = window.freestar.fsdata.videoTopLevelStoredRequestId);
            const t = window.fsprebid.getConfig("s2sConfig");
            Math.random() <= .98 && (t.bidders = []), window.fsprebid.mergeConfig({
                s2sConfig: t,
                ortb2: e,
                video: {
                    providers: [{
                        divId: "fsOutstreamPlayer_" + this.uuid,
                        vendorCode: 2,
                        playerConfig: {
                            params: {
                                adPluginConfig: {
                                    numRedirects: 10,
                                    adLabel: "&nbsp;&nbsp;Ad length:"
                                },
                                vendorConfig: {
                                    controls: !1,
                                    autoplay: !1,
                                    preload: "auto",
                                    loadingSpinner: !1
                                }
                            }
                        },
                        adServer: {
                            vendorCode: "gam",
                            baseAdTagUrl: this.baseAdTagUrl + this.getAPSBids()
                        }
                    }]
                },
                cache: {
                    url: "https://prebid.adnxs.com/pbc/v1/cache",
                    ignoreBidderCacheKey: !0
                },
                targetingControls: {
                    allowTargetingKeys: ["BIDDER", "AD_ID", "PRICE_BUCKET", "SIZE", "DEAL", "SOURCE", "FORMAT", "UUID", "CACHE_ID", "CACHE_HOST", "ADOMAIN"]
                }
            })
        }
        addVideoPlayer() {
            freestar.log(Ki, "Activating video player..."), this.videoPlayer = window.videojs("fsOutstreamPlayer_" + this.uuid), this.videoPlayer.muted(!0), this.videoPlayer.fill(!0)
        }
        requestBids() {
            freestar.log(Ki, "Requesting bids..."), this.requestCount += 1, this.requestTimestamp = Date.now(), window.fsprebid.requestBids({
                adUnitCodes: [this.prebidAdUnit.code]
            })
        }
        toggleDisplay() {
            document.getElementById("fs-player-container").classList.toggle("fs-hide"), document.getElementById("fs-player-container").classList.toggle("fs-show")
        }
        remove({
            params: e = {
                ended: !0
            }
        }) {
            freestar.log(Ki, "Removing video player..."), this.toggleDisplay();
            const t = document.getElementById("fs-player-container");
            t && t.remove(), window.fsprebid.removeAdUnit(this.prebidAdUnit.code);
            const n = window.fsprebid.getConfig("s2sConfig");
            n.bidders = this.ogPBSBidders, window.fsprebid.mergeConfig({
                s2sConfig: n,
                video: {}
            }), !this.playing && this.options.rebid ? tr({
                callback: this.callback,
                placement: this.ogPlacement,
                videoAd: this.videoAd,
                options: {
                    rebid: !1,
                    baseAdTagUrl: `https://pubads.g.doubleclick.net/gampad/ads?iu=${this.placement.videoGAMSlot}&description_url={player.pageUrl}&tfcd=0&npa=0&sz=1x1&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator={random}&url={player.pageUrl}&nofb=0&max_ad_duration=30000&schain=1.0,1!freestar.com,${window.freestar.fsdata.companyId},1`
                }
            }) : this.callback && (freestar.log(Ki, "Calling call back..."), this.callback(void 0, e))
        }
    }

    function rr({
        placement: e,
        product: t,
        callback: n
    }) {
        this.placement = e, this.product = t, this.productKey = t + "Options", this.incrementIteration = () => {
            this.iteration++, sessionStorage.setItem(this.key, this.iteration.toString())
        }, this.subtractIteration = () => {
            freestar.log(1, "Frequency Cap : iteration will remove this attempt as an iteration. Setting new sessionStorage item value."), this.iteration--, sessionStorage.setItem(this.key, this.iteration.toString())
        }, this.fetchCap = () => this.placement[this.productKey] && e[this.productKey].cap > 0 ? e[this.productKey].cap : -1, this.fetchIteration = () => {
            const e = sessionStorage.getItem(this.key);
            return Number(e) ? Number(e) : 0
        }, this.allowProduct = () => this.cap > 0 && (this.iteration >= this.cap ? (freestar.log(1, `Frequency Cap: iteration of ${this.iteration} is higher than cap of ${this.cap}. ${this.product} will not run again until this session ends.`), !1) : (freestar.log(1, `Frequency Cap: iteration of ${this.iteration+1} is lower than or equal to the cap of ${this.cap}. Continue with  ${this.product}.`), !0)), this.cap = this.fetchCap(), this.key = `fs.${this.product}.frequencycap`, this.iteration = this.fetchIteration(), this.callback = n
    }

    function sr() {
        return sn({
            type: "button",
            classList: [],
            attributes: [{
                "aria-label": "Close Ad"
            }, {
                tabindex: 0
            }]
        })
    }

    function ar(e) {
        this.body = document.body, this.placement = e, this.iteration = 0, this.STICKYFOOTER_KEY = "stickyFooterOptions", this.FOOTER_CORDIAL_KEY = "fs.stickyfooter.cordial", this.stickyFooterId = "fs-sticky-footer", this.stickyElement = void 0, this.stickySlotElement = void 0, this.slotWrapper = void 0, this.closeButton = void 0, this.brandingElement = void 0, this.error = !1, this.disabled = !1, this.options = be({
            placement: this.placement,
            type: this.STICKYFOOTER_KEY
        }), this.errorSet = () => {
            this.error = !0
        }, this.disabledSet = () => {
            this.disabled = !0
        }, this.cordial = {
            set: () => {
                if (this.cordial.isCordial()) {
                    freestar.log({
                        title: "STICKYFOOTER"
                    }, "Cordial is being set in local storage with the following time : " + this.options.session);
                    const e = this.options.session && this.options.session > 0 ? this.options.session : 180,
                        t = Date.now() + 6e4 * e;
                    localStorage.setItem(this.FOOTER_CORDIAL_KEY, t.toString())
                }
            },
            isCordial: () => (this.options.cordial ? freestar.log({
                title: "STICKYFOOTER"
            }, "Cordial is active.") : freestar.log({
                title: "STICKYFOOTER"
            }, "Cordial is not active."), this.options.cordial),
            isActivated: () => {
                const e = localStorage.getItem(this.FOOTER_CORDIAL_KEY);
                return e ? e && Date.now() > e ? (freestar.log({
                    title: "STICKYFOOTER"
                }, "Cordial storage item found, but time has lapsed and storage item will be removed."), localStorage.removeItem(this.FOOTER_CORDIAL_KEY), !1) : (freestar.log({
                    title: "STICKYFOOTER"
                }, "Cordial is activated. Exiting process"), !0) : (freestar.log({
                    title: "STICKYFOOTER"
                }, "Cordial storage item not found. Cordial not activated."), !1)
            }
        }, this.isAdhesionDisabled = () => {
            if (!(this.placement && this.options && this.placement.sizes.length && this.body)) return freestar.log({
                title: "STICKYFOOTER"
            }, "No document body, placement, options, or sizes found! Exiting process."), this.errorSet(), !0;
            if (Nn({
                    name: "stickyFooter"
                })) return this.disabledSet(), !0;
            if (this.options.remove) {
                if (freestar.log({
                        title: "STICKYFOOTER"
                    }, "Option to remove is true."), document.querySelector("fs-select-footer-remove") || document.querySelector(this.options.remove)) return freestar.log({
                    title: "STICKYFOOTER"
                }, "Option to remove is on DOM! Exiting process."), this.disabledSet(), !0;
                freestar.log({
                    title: "STICKYFOOTER"
                }, "Option to remove is not on DOM sticky footer will continue.")
            }
            return freestar.frequencyLibrary[this.placement.name].cap > -1 && !freestar.frequencyLibrary[this.placement.name].allowProduct() ? (freestar.log({
                title: "STICKYFOOTER"
            }, "Frequency Cap has been met. Exiting process."), this.disabledSet(), !0) : this.cordial.isCordial() && this.cordial.isActivated() ? (this.disabledSet(), !0) : (freestar.log({
                title: "STICKYFOOTER"
            }, "Placement, options, and sizes found. No rules to disable have been accepted. Process will continue."), !1)
        }, this.gumgumBidderRemoval = function() {
            this.options.gumgumSelect && !document.getElementById("adhesion-select-one") && (C(this.placement.bidders, (e => "gumgum" === e.bidder)), window.fsprebid.adUnits = window.fsprebid.adUnits.map((e => (e.code === this.placement.name && C(e.bids, (function(e) {
                return "gumgum" === e.bidder
            })), e))), freestar.log({
                title: "STICKYFOOTER"
            }, "Gumgum has been removed as a bidder"))
        }, this.createStickyElement = function() {
            this.stickyElement = sn({
                type: "div",
                id: this.stickyFooterId,
                classList: [this.stickyFooterId]
            }), this.stickyElement.style.zIndex = this.options.zindex && `${this.options.zindex}` || "", this.body.appendChild(this.stickyElement)
        }, this.setSlotMinHeight = function() {
            const {
                selectedSize: e
            } = freestar.fsdata.placements.find((e => e.name === this.placement.name)), t = e.size.map((e => e[1])), n = Math.max.apply(Math, t), i = "mobile" === freestar.deviceInfo.device.type && "CONFIANT" === on() && freestar.fsdata.adQualityOptions && freestar.fsdata.adQualityOptions.confiantReportThisAdEnabled && Pt.allowConfiant() ? n + 20 : n;
            this.stickyElement.style.minHeight = `${i}px`
        }, this.createSlotElement = function() {
            this.stickySlotElement = sn({
                type: "div",
                id: this.placement.name,
                classList: ["fs-sticky-slot-element"],
                attributes: [{
                    name: this.placement.name
                }]
            }), this.stickySlotElement.style.visibility = "inherit", De() ? jt.refreshLibraryCreator(this.placement.name) : freestar.refreshLibraryCreator(this.placement.name), this.slotWrapper = sn({
                type: "div",
                id: "fs-slot-footer-wrapper",
                classList: ["fs-sticky-parent", "fs-sticky-wrapper"]
            }), this.slotWrapper.style.visibility = "inherit", this.slotWrapper.style.zIndex = "inherit", this.slotWrapper.appendChild(this.stickySlotElement), this.stickyElement.appendChild(this.slotWrapper);
            const e = () => this.options.backgroundRgba && this.options.backgroundRgba.length ? this.options.backgroundRgba : freestar.fsdata.stickyFooterBackgroundRgba && freestar.fsdata.stickyFooterBackgroundRgba.length ? freestar.fsdata.stickyFooterBackgroundRgba : "rgba(247,247,247,.9)";
            this.setSlotMinHeight(), Pt.getFirstInit().then((() => this.setSlotMinHeight())), this.stickySlotElement.style.backgroundColor = e(), this.stickyElement.style.backgroundColor = e();
            const t = () => {
                this.stickyElement.style.minHeight = `${this.slotWrapper.offsetHeight}px`
            };
            googletag.pubads().addEventListener("slotOnload", (e => {
                if (e.slot.getSlotElementId() === this.placement.name) {
                    const e = document.getElementsByClassName("fs-sticky-slot-element")[0],
                        n = e.offsetHeight,
                        i = e.offsetWidth;
                    this.brandingElement && (n > 50 && i < 468 ? this.brandingElement.classList.add("fs-mobile-tall") : this.brandingElement.classList.remove("fs-mobile-tall")), t()
                }
            }))
        }, this.buttonEvents = {
            onPage: !1,
            clicked: !1
        }, this.closeButtonCreate = () => {
            this.closeButton = sr(), this.closeButton.setAttribute("class", "fs-close-button fs-close-button-sticky"), this.closeButton.style.visibility = "inherit", this.buttonEvents.onPage || (this.buttonEvents.onPage = !0, freestar.msg.que.push({
                eventType: "customEvent",
                args: {
                    eventName: "STICKY_BUTTON_SHOWED",
                    eventType: "STICKY_FOOTER",
                    jsonValue: JSON.stringify({
                        value: !0
                    })
                }
            })), this.slotWrapper.appendChild(this.closeButton), this.closeButton.addEventListener("click", this.closeButtonMethod)
        }, this.closeButtonMethod = () => {
            this.cordial.set(), this.removeStickyElements(), this.buttonEvents.clicked || (this.buttonEvents.clicked = !0, freestar.msg.que.push({
                eventType: "customEvent",
                args: {
                    eventName: "STICKY_CLOSE_CLICKED",
                    eventType: "STICKY_FOOTER",
                    jsonValue: JSON.stringify({
                        value: !0
                    })
                }
            }))
        }, this.createReportThisAd = function(e, t) {
            const n = document.createElement("a");
            n.textContent = "Report This Ad", n.style.color = "#999", n.addEventListener("click", (function() {
                try {
                    window.confiant.services().reportSingleAd(e)
                } catch (e) {
                    alert("Unable to report the ad: " + e.toString())
                }
            })), t.appendChild(n)
        }, this.createBranding = () => {
            const e = this.placement.name,
                t = ii();
            if (t) {
                this.brandingElement = sn({
                    type: "div",
                    classList: ["__fs-branding"]
                });
                const n = sn({
                    type: "a",
                    attributes: [{
                        target: "_blank"
                    }]
                });
                this.brandingElement.style.visibility = "inherit";
                const i = sn({
                    type: "img",
                    src: `https://a.pub.network/core/imgs/fslogo-${t.toLowerCase()}.svg`,
                    attributes: [{
                        alt: "Freestar"
                    }]
                });
                n.style.cursor.pointer, n.appendChild(i), this.brandingElement.appendChild(n), this.slotWrapper.appendChild(this.brandingElement);
                const r = document.createElement("div");
                r.className = "fs-sticky-popup-container", r.style.display = "none";
                const s = document.createElement("a");
                s.href = "https://ads.freestar.com/?utm_campaign=branding&utm_medium=${product}&utm_source=${window.freestar.fsdata.domain}&utm_content=${this.placement.name}", s.target = "_blank", s.textContent = "Freestar.com", s.style.color = "#999", r.appendChild(s), ri() && this.placement.adQualityOptions && !this.placement.adQualityOptions.disabled && Pt.getFirstInit().then((() => {
                    Pt.allowConfiant() && this.createReportThisAd(e, r)
                }));
                const a = document.createElement("div");
                a.style.position = "relative", a.appendChild(r), document.body.appendChild(a), this.brandingElement.addEventListener("click", (function(e) {
                    e.stopPropagation(), r.style.display = "none" === r.style.display ? "grid" : "none";
                    var t = this.getBoundingClientRect();
                    r.style.position = "fixed", r.style.top = t.top - 70 + "px", r.style.left = t.left - 70 + "px", r.style.backgroundColor = (() => this.options && this.options.backgroundRgba && this.options.backgroundRgba.length ? this.options.backgroundRgba : freestar.fsdata.stickyFooterBackgroundRgba && freestar.fsdata.stickyFooterBackgroundRgba.length ? freestar.fsdata.stickyFooterBackgroundRgba : "rgba(247,247,247,.9)")()
                })), document.addEventListener("click", (function() {
                    r.style.display = "none"
                }))
            }
        }, this.closeButtonMethod.bind(this), this.frequencyCapInit = () => {
            freestar.frequencyLibrary[this.placement.name] = new rr({
                placement: this.placement,
                product: "stickyFooter"
            })
        }, this.videoAdRequest = function(e) {
            const t = Date.now();
            this.hideAdhesion(),
                function({
                    callback: e,
                    videoAd: t,
                    placement: n
                }) {
                    t && t.vendor && pr[t.vendor] && pr[t.vendor]({
                        callback: e,
                        videoAd: t,
                        placement: n
                    })
                }({
                    videoAd: e,
                    callback: (e, n) => {
                        if (this.stickyFooterDeleted) return;
                        if (n && n.userEnded) return freestar.log(1, "Sticky Footer Video: User ended video. Will not refresh sticky footer."), void this.cordial.set();
                        const i = (_e(this.placement.name) || 30) - (Date.now() - t) / 1e3;

                        function r() {
                            i >= 10 ? freestar.currentStickyFooter.fillSlot(i) : freestar.currentStickyFooter.fillSlot()
                        }
                        document.hasFocus() ? r() : freestar.focusQueue.push(r)
                    },
                    placement: this.placement
                })
        }, this.fillSlot = function(e = void 0) {
            e || this.iteration++;
            const t = function({
                iteration: e,
                placement: t
            }) {
                const n = function(e) {
                        let t = !1;
                        return e.sizeMappings.some((e => {
                            if (bn() >= e.viewport.size[0]) return t = e, !0
                        })), t
                    }(t),
                    {
                        stickyFooterOutstreamVideoPattern: i
                    } = n;
                if (i && "NO_STICKY_FOOTER_OUTSTREAM_VIDEO_PATTERN" !== i && mr[i]) {
                    const {
                        disabledVideoIterations: n,
                        enabledVideoIterations: r,
                        enabledDisplayIterations: s,
                        videoInitial: a = !1
                    } = mr[i];
                    if (a && 1 === e) return hr({
                        placement: t
                    });
                    if (s.length) {
                        return !s.map((t => e % t)).includes(0) && hr({
                            placement: t
                        })
                    }
                    if (n.length) {
                        if (n.map((t => e % t)).includes(0)) return !1
                    }
                    if (r.length) {
                        if (r.map((t => e % t)).includes(0)) return hr({
                            placement: t
                        })
                    }
                }
                return !1
            }({
                iteration: this.iteration,
                placement: this.placement
            });
            t && !e ? (this.isVideo = !0, this.hideAdhesion(), freestar.refreshLibrary && freestar.refreshLibrary[this.placement.name] && freestar.refreshLibrary[this.placement.name].refreshTime && (freestar.refreshLibrary[this.placement.name].refreshTime = -1), this.videoAdRequest(t)) : (freestar.refreshLibrary[this.placement.name] || (freestar.refreshLibrary[this.placement.name] = {}), this.isVideo = !1, freestar.refreshLibrary[this.placement.name].refreshTime = e || _e(this.placement.name), freestar.refreshLibrary[this.placement.name].refreshCounter = 0, Un([{
                slotId: this.placement.name,
                placementName: this.placement.name
            }]))
        }, this.elementToggle = e => {
            this.stickyElement && (this.stickyElement.style.setProperty("display", "block"), this.stickyElement.style.setProperty("visibility", e))
        }, this.hideAdhesion = () => {
            this.elementToggle("hidden")
        }, this.showAdhesion = () => {
            this.elementToggle("visible")
        }, this.fetchCLSElement = () => document.getElementById(this.placement.name + "-sticky-footer-cls"), this.addGumgumListener = () => {
            window.document.body.addEventListener("gumgum-inscreen-load", (() => {
                window.freestar.currentStickyFooter.hideAdhesion(), window.freestar.gumgumLoaded = !0
            }))
        }, this.init = function() {
            this.frequencyCapInit(), window.freestar.gumgumLoaded = !1, this.isAdhesionDisabled() || (we({
                slotId: this.placement.name,
                placementName: this.placement.name
            }), this.gumgumBidderRemoval(), this.options.clsEnabled ? (this.stickyElement = this.fetchCLSElement(), this.stickyElement && (this.stickyElement.className += ` ${this.stickyFooterId}`)) : this.createStickyElement(), this.stickyElement ? (this.hideAdhesion(), this.createSlotElement(), this.hideAdhesion(), this.closeButtonCreate(), this.hideAdhesion(), this.createBranding(), this.fillSlot(), this.addGumgumListener()) : freestar.log({
                title: "STICKYFOOTER"
            }, "There is no sticky element! Exiting!"))
        }, this.init(), this.eval = function(e) {
            P.logMark({
                markerName: A.pubfigStickyFooterSlotRenderEnded,
                compareTo: [A.pubfigStickyFooterSlotRequested]
            }), e.isEmpty ? this.hideAdhesion() : this.showAdhesion()
        }, this.fetchElement = ({
            selector: e
        }) => {
            try {
                return document.querySelector(e)
            } catch (e) {
                freestar.log(1, `Error: ${e}`)
            }
        }, this.removeSpecialAdhesion = () => {
            for (const e in u)
                if (Object.prototype.hasOwnProperty.call(u, e)) {
                    const t = this.fetchElement({
                        selector: u[e]
                    });
                    t && t.parentNode && t.parentNode.removeChild(t)
                }
        }, this.stickyFooterRefresh = () => {
            this.removeSpecialAdhesion(), freestar.refreshLibrary[this.placement.name].refreshTime = -1;
            const e = this.placement.name,
                t = Wt({
                    elementId: e
                });
            t && (t.setTargeting("fsrefresh", `${freestar.refreshLibrary[this.placement.name].timesRefreshed}`), freestar.refreshLibrary[e].refreshCounter = 0), this.fillSlot()
        }, this.removeStickyElements = () => {
            [this.stickySlotElement, this.stickyElement, this.slotWrapper].forEach((e => {
                try {
                    e && e.parentNode && e.parentNode.removeChild(e)
                } catch (e) {
                    freestar.log(1, `Error: ${e}`)
                }
            }))
        }, this.deleteStickyFooter = () => {
            if (this.stickyFooterDeleted = !0, this.isVideo && window.AdPlayerPro) {
                window.AdPlayerPro().remove()
            }
            this.cordial.set(), Qt({
                elementId: this.placement.name
            }), this.removeSpecialAdhesion(), this.removeStickyElements()
        }, this.removeSpecialFromBidding = () => {
            function e(e) {
                if ("gumgum" === e.bidder || "33across" === e.bidder) return e
            }
            C(fsprebid.adUnits.filter((e => e.code === this.placement.name))[0].bids, e), C(this.placement.bidders, e)
        }, this.prebidEvaluation = (e, t = !1) => {
            if (e && e.adUnitCode === this.placement.name) {
                const n = !("undertone" !== e.bidderCode || !document.querySelectorAll(u[e.bidderCode]).length),
                    i = !("33across" !== e.bidderCode || !document.getElementsByClassName("ttx-close").length),
                    r = _e(this.placement.name) || 30;
                if (n || t || i) {
                    let e = 0;
                    this.hideAdhesion(), (t || i) && this.options.singleUse && this.removeSpecialFromBidding();
                    const n = setInterval(function() {
                        e += 1, e > r && (clearInterval(n), this.stickyFooterRefresh())
                    }.bind(this), 1e3)
                }
            }
        }, this.isSticky = e => this.placement.name === e.slot.getSlotElementId()
    }
    const or = {};
    class dr {
        constructor({
            placement: e
        }) {
            this.placement = JSON.parse(JSON.stringify(e)), this.videoCount = 0, this.timer = null, this.init()
        }
        init() {
            if (this.videoAd = function({
                    placement: e
                }) {
                    const {
                        selectedSize: t
                    } = e;
                    if (t && t.videoEnabled) {
                        const n = freestar.fsdata.placementVideos.filter((e => e.id === t.videoId))[0];
                        if (n) return Object.assign(n, ur(e))
                    }
                    return !1
                }({
                    placement: this.placement
                }), this.placement.stickyFooterOptions.videoPattern = "NO_STICKY_FOOTER_OUTSTREAM_VIDEO_PATTERN", this.placement.stickyFooterOptions.video = !1, this.footer = new ar(this.placement), this.footer.showAdhesion(), Nn({
                    name: "videoAdhesion"
                })) return;
            let {
                delayTime: e = 0
            } = this.videoAd;
            e < 1 && (e = 1), freestar.log({
                title: "VIDEO"
            }, `${e}s before video loads...`), or.delay = setTimeout((() => {
                clearTimeout(or.delay), this.initVendor()
            }), 1e3 * e)
        }
        initVendor() {
            freestar.currentStickyFooter && (this.adjustCSS(), this.videoCount += 1, pr[this.videoAd.vendor]({
                callback: (e = null, t = null) => {
                    this.handleCallback(e, t)
                },
                placement: this.placement,
                videoAd: this.videoAd
            }))
        }
        adjustCSS() {
            const e = document.getElementById(`${this.placement.name}-stylesheet`);
            e && e.remove();
            const t = sn({
                type: "style",
                id: `${this.placement.name}-stylesheet`
            });
            t.textContent = `\n            #fs-player-container,\n            .orp-player-wrapper {\n                margin-bottom: ${this.footer.slotWrapper.offsetHeight+10}px !important;\n                bottom: 0px !important;\n            }\n        `, document.head.appendChild(t), or.adjust = setTimeout((() => {
                clearTimeout(or.adjust), this.adjustCSS()
            }), 500)
        }
        handleCallback(e = null, t = null) {
            if (!freestar.currentStickyFooter) return;
            if (e) return void freestar.log({
                title: "VIDEO"
            }, "ERROR", e);
            const {
                frequencyCap: n = 0
            } = this.videoAd;
            t.userEnded ? freestar.log({
                title: "VIDEO"
            }, "User exited, no longer loading videos...") : n > 0 && this.videoCount >= n ? freestar.log({
                title: "VIDEO"
            }, `Frequency cap set to ${n}, no longer loading videos...`) : document.hasFocus() ? this.callNextVideo() : freestar.focusQueue.push((() => {
                this.callNextVideo()
            }))
        }
        callNextVideo() {
            if (!freestar.currentStickyFooter) return;
            const {
                timeToWaitBetweenVideos: e = 0
            } = this.videoAd;
            freestar.log({
                title: "VIDEO"
            }, `${e}s before next video loads...`), or.delay = setTimeout((() => {
                clearTimeout(or.delay), freestar.currentStickyFooter.initVendor()
            }), 1e3 * e)
        }
        prebidEvaluation(e, t = !1) {
            this.footer.prebidEvaluation(e, t)
        }
        stickyFooterRefresh() {
            this.footer.stickyFooterRefresh()
        }
        deleteStickyFooter() {
            if (Object.keys(or).forEach((e => {
                    clearTimeout(or[e])
                })), freestar.currentStickyFooter.footer.deleteStickyFooter(), window.AdPlayerPro) {
                const e = window.AdPlayerPro();
                e && e.remove()
            }
            freestar.currentOutstreamPlayer && (freestar.currentOutstreamPlayer.videoPlayer.dispose(), document.getElementById("fs-player-container").remove()), delete freestar.currentStickyFooter
        }
        hideAdhesion() {
            freestar.currentStickyFooter.footer.hideAdhesion()
        }
    }
    let lr = !1,
        cr = !1;
    const fr = function(e) {
            lr || (lr = !0, freestar.newStickyFooter()), freestar.log(1, `${e}`)
        },
        ur = e => {
            let t = !1;
            return e.sizeMappings.some((e => {
                if (bn() >= e.viewport.size[0]) {
                    const {
                        stickyFooterOutstreamVideoPattern: n,
                        delayTime: i,
                        playerSize: r,
                        timeToWaitBetweenVideos: s,
                        videoAdhesionPosition: a,
                        videoEnabled: o,
                        videoId: d,
                        frequencyCap: l
                    } = e;
                    return t = {
                        stickyFooterOutstreamVideoPattern: n,
                        delayTime: i,
                        playerSize: r,
                        timeToWaitBetweenVideos: s,
                        videoAdhesionPosition: a,
                        videoEnabled: o,
                        videoId: d,
                        frequencyCap: l
                    }, !0
                }
            })), t
        };
    const pr = {
        SPRINGSERVE: function({
            callback: e,
            videoAd: t,
            placement: n
        }) {
            const i = window.freestar.fsdata.placementVideos.find((e => e.id === t.videoId)),
                r = freestar.deviceInfo.device.type,
                s = {
                    mobile: "625208",
                    desktop: "625207"
                },
                a = Qi(n),
                o = Qi(n),
                d = {
                    mobile: {
                        widthm: "LARGE" === t.playerSize ? "100%" : "45%",
                        heightm: "LARGE" === t.playerSize ? "175" : "112",
                        posm: o
                    },
                    desktop: {
                        widthd: "LARGE" === t.playerSize ? "400" : "312",
                        heightd: "LARGE" === t.playerSize ? "225" : "176",
                        posd: a
                    }
                };
            if (window.freestar.fsdata.networks.some((e => "amazon" === e.slug)) && i.amazonActive) {
                const e = i.amazonApsSlot || `springserve_${window.freestar.fsdata.siteId}_${location.host.split(".").length>2?location.host.split(".")[1]:location.host.split(".")[0]}`;
                d.mobile.apsSlot = e, d.desktop.apsSlot = e
            }
            const l = () => i.supplyId && i.supplyId.length ? i.supplyId : Wi({
                    type: s,
                    device: r
                }),
                c = {
                    mobile: {
                        spIdm: l()
                    },
                    desktop: {
                        spIdd: l()
                    }
                },
                f = `https://cdn.springserve.com/assets/0/playerJS/${Wi({type:{mobile:"frstrOSm_8",desktop:"frstrOSd_8"},device:r})}.js`;

            function u({
                userEnded: t = !1
            } = {}) {
                freestar.log(1, "Spring Serve Footer Video Iteration Complete", arguments), delete window.AdPlayerPro, "function" == typeof e && (e(void 0, t ? {
                    userEnded: !0
                } : {
                    ended: !0
                }), e = void 0)
            }
            window._ssPlayer = Object.assign(Wi({
                type: c,
                device: r
            }), Wi({
                type: d,
                device: r
            }));
            const p = Date.now();
            Gi({
                bidder: "springserve",
                placementId: t.videoId ? t.videoId : "",
                tagUrl: f
            });
            const h = () => {
                window.AdPlayerPro().on("AdStarted", (function() {
                    freestar.log(1, "Spring Serve Footer Video Started"), Vi({
                        bidder: "springserve",
                        videoAd: t,
                        requestTimestamp: p
                    }), freestar.frequencyLibrary[n.name] && freestar.frequencyLibrary[n.name].cap && freestar.frequencyLibrary[n.name].incrementIteration()
                })), window.AdPlayerPro().on("AdError", (function() {
                    freestar.log(1, "Spring Serve Footer Ad Fetch Error"), u({})
                })), window.AdPlayerPro().on("AdUserClose", (function() {
                    freestar.log(1, "Spring Serve Footer Ad User Ended"), u({
                        userEnded: !0
                    })
                }));
                ["AdStopped", "AdVideoComplete"].forEach((e => {
                    window.AdPlayerPro().on(e, u)
                }))
            };
            an(f, (() => {
                let e = 0;
                const t = setInterval((() => {
                    if (window.AdPlayerPro && "function" == typeof window.AdPlayerPro && "object" == typeof window.AdPlayerPro() && "function" == typeof window.AdPlayerPro().on ? (clearInterval(t), h()) : e += 1, e >= 50) try {
                        h()
                    } catch (e) {
                        freestar.log(1, "Error binding events to SpringServe Video Player", e)
                    }
                }), 10)
            }))
        },
        PREBID: tr
    };

    function hr({
        placement: e
    }) {
        if (Nn({
                name: "videoAdhesion"
            })) return !1;
        if (freestar.locData && freestar.locData.iso && -1 !== I.indexOf(freestar.locData.iso)) return !1;
        if (e.stickyFooterOptions && e.stickyFooterOptions.video) {
            const {
                selectedSize: t
            } = e;
            if (t && t.videoEnabled) {
                const n = freestar.fsdata.placementVideos.filter((e => e.id === t.videoId))[0];
                if (n) return Object.assign(n, ur(e))
            }
        }
        return !1
    }
    const mr = {
        DISPLAY_INIT_DISPLAY_CONSECUTIVE: {
            enabledDisplayIterations: [],
            disabledVideoIterations: [4, 6],
            enabledVideoIterations: [2, 5, 7]
        },
        DISPLAY_INIT_ALTERNATING: {
            enabledDisplayIterations: [],
            disabledVideoIterations: [],
            enabledVideoIterations: [2]
        },
        VIDEO_INIT_ALTERNATING: {
            enabledDisplayIterations: [2],
            disabledVideoIterations: [],
            enabledVideoIterations: [],
            videoInitial: !0
        },
        VIDEO_INIT_DISPLAY_CONSECUTIVE: {
            videoInitial: !0,
            enabledDisplayIterations: [],
            disabledVideoIterations: [10, 15, 18],
            enabledVideoIterations: [4, 5, 9, 12, 13, 17, 20, 21, 29, 33]
        },
        DISPLAY_INIT_VIDEO_CONSECUTIVE: {
            enabledDisplayIterations: [],
            disabledVideoIterations: [],
            enabledVideoIterations: [...Array(34).keys()].splice(2)
        }
    };
    const gr = {
        common: !1,
        heights: {}
    };
    let br;
    const yr = ({
            adUnit: e,
            slotId: t = null
        }) => {
            const {
                height: n,
                topPadding: i,
                type: r
            } = be({
                placement: e,
                type: "slidingUnitOptions"
            }), s = freestar.deviceInfo.device.type === r.toLowerCase();
            if (Nn({
                    name: "slidingUnit"
                }) || !s) return !1;
            const a = document.querySelector(`#${t||e.name}`);
            if (a) {
                br = [];
                if (wr({
                        element: a.parentElement
                    })) return console.error("Sliding unit initialization failed: An ancestor DOM element contains an overflow rule."), !1;
                (({
                    height: e,
                    topPadding: t = null
                }) => {
                    gr.common || (gr.common = !0, xi(`\n            .fs-su-ad > div {\n                top: 0;\n                position: sticky;\n                padding-top: ${t||0}px;\n            }\n        `)), gr.heights[`height-${e}`] || (gr.heights[`height-${e}`] = !0, xi(`\n            .fs-su-ad {\n                position: relative;\n                height: ${1.5*e}px;\n            }\n        `))
                })({
                    height: n,
                    topPadding: i
                });
                (({
                    wrapper: e,
                    node: t
                }) => {
                    e.innerHTML = t.outerHTML, t.parentNode.insertBefore(e, t), t.remove()
                })({
                    wrapper: sn({
                        classList: ["fs-su-ad"]
                    }),
                    node: a
                })
            } else console.error(`Sliding unit initialization failed: No ${a} DOM element found in page.`)
        },
        wr = ({
            element: e
        }) => {
            const t = e.parentElement;
            if (t) {
                Ri({
                    element: t
                }) ? br.push(1) : (br.push(0), wr({
                    element: t
                }))
            }
            return Math.max(...br) > 0
        },
        vr = () => {
            performance.mark("slidingUnit-initialization-start");
            const e = freestar.fsdata.placements.filter((e => (({
                placement: e
            }) => ge({
                placement: e,
                type: "slidingUnitOptions"
            }) && !ge({
                placement: e,
                type: "dynamicAdOptions"
            }))({
                placement: e
            })));
            e.length && (({
                adUnits: e
            }) => {
                e.forEach((e => {
                    yr({
                        adUnit: e
                    })
                }))
            })({
                adUnits: e
            }), performance.mark("slidingUnit-initialization-end")
        };

    function Ir(e) {
        if (freestar.log({
                title: "VIDEO"
            }, "CONNATIX ELEMENTS : video init..."), !e.scriptId) return;
        const {
            parentElement: t,
            classIndex: n
        } = e, i = n && n > -1 ? n : 0, r = t ? document.querySelectorAll(t)[i] : document.body;
        if (r) {
            freestar.log({
                title: "VIDEO"
            }, "CONNATIX ELEMENTS : video target element : ", r);
            const t = Date.now();
            ! function({
                videoAd: e
            }) {
                const t = "//cd.connatix.com/connatix.player.js?cid=f9509d53-804e-427d-a0bc-1204c0a3bcb1";
                freestar.log({
                        title: "VIDEO"
                    }, "CONNATIX ELEMENTS : script loading..."), Gi({
                        bidder: "connatix",
                        placementId: e.name,
                        tagUrl: t
                    }),
                    function(e) {
                        if (!window.cnx) {
                            window.cnx = {}, window.cnx.cmd = [];
                            var n = e.createElement("iframe");
                            n.src = "javascript:false", n.display = "none", n.onload = function() {
                                var e = n.contentWindow.document,
                                    i = e.createElement("script");
                                i.src = t, i.setAttribute("async", "1"), i.setAttribute("type", "text/javascript"), e.body.appendChild(i)
                            }, e.head.appendChild(n)
                        }
                    }(document)
            }({
                videoAd: e
            }),
            function({
                videoAd: e,
                targetElement: t
            }) {
                const n = sn({
                    type: "script",
                    id: e.scriptId
                });
                t.appendChild(n), freestar.log({
                    title: "VIDEO"
                }, "CONNATIX ELEMENTS : script element created : ", n)
            }({
                videoAd: e,
                targetElement: r
            }), window.cnx.cmd.push((function() {
                cnx(function({
                    videoAd: e
                }) {
                    const t = {
                        playerId: e.playerId,
                        settings: {
                            defaultSoundMode: window.cnx.configEnums.DefaultSoundModeEnum.Off
                        }
                    };
                    return (!e.parentElement.length || e.toFloat || e.adType && "SLIDER" === e.adType) && (t.settings.customization = {
                        floating: {
                            mode: window.cnx.configEnums.FloatingModeEnum[e.parentElement && "SLIDER" !== e.adType ? "AfterInView" : "Always"],
                            fixedPosition: window.cnx.configEnums.FloatingFixedPositionModeEnum.Page,
                            scrollPosition: window.cnx.configEnums.FloatingScrollPositionEnum.BottomRight,
                            floatingWidth: e.width && e.width > 100 ? e.width : 401,
                            floatingGutterX: 5,
                            floatingGutterY: 100
                        }
                    }), t
                }({
                    videoAd: e
                })).render(e.scriptId, (function(n, i) {
                    i && i.on && window.cnx.configEvents && window.cnx.configEvents.AdPlay && i.on(window.cnx.configEvents.AdPlay, (() => {
                        Vi({
                            bidder: "connatix",
                            videoAd: e,
                            requestTimestamp: t
                        })
                    }))
                }))
            }))
        } else freestar.log({
            title: "VIDEO"
        }, "CONNATIX ELEMENTS : video ad parent element not found. Skipping...")
    }
    const Ar = "freestarPrimisPlayer",
        kr = "freestarPrimisScript",
        Sr = ({
            videoAd: e,
            container: t
        }) => {
            if (t && t.appendChild) {
                const {
                    primisToken: t,
                    device: n
                } = e, i = "DESKTOP" === n || window.innerWidth > 768 ? 400 : 300, r = parseInt(i / 1.470588235, 10), s = Math.round((new Date).getTime() / 1e3), a = encodeURI(window.location.href), o = `${window.location.protocol}//live.primis.tech/live/liveView.php?s=${t}&cbuster=${s}&pubUrl=${a}&x=${i}&y=${r}&playerApiId=${Ar}&schain=1.0,1!freestar.com,${window.freestar.fsdata.companyId},1`;
                Gi({
                        bidder: "primis",
                        tagUrl: o,
                        placementId: e.name
                    }),
                    function({
                        scriptSrc: e,
                        target: t = null,
                        callback: n,
                        id: i
                    }) {
                        if (t) try {
                            const r = sn({
                                type: "script",
                                src: e
                            });
                            r.async = !0, r.type = "text/javascript", n && (r.onload = n), i && (r.id = i), t.appendChild(r)
                        } catch (e) {}
                    }({
                        scriptSrc: o,
                        target: xr({
                            videoAd: e
                        }),
                        id: kr
                    }), window.top.sekindoFlowingPlayerOn = !1
            }
        },
        xr = ({
            videoAd: e
        }) => {
            let t = document.querySelector("body");
            if (e.parentElement && 0 === e.parentElement.indexOf("#")) {
                if (t = document.querySelectorAll(e.parentElement)[0], e.nthElement > -1) try {
                    t = t.children[e.nthElement]
                } catch (e) {
                    return freestar.log({
                        title: "VIDEO"
                    }, "PRIMIS ELEMENT NOT FOUND ON PAGE, SKIPPING"), !1
                }
            } else if (e.nthElement > -1)
                if (e.parentElement && e.parentElement.length) {
                    const n = document.querySelectorAll(e.parentElement)[e.classIndex];
                    try {
                        t = n.children[e.nthElement]
                    } catch (e) {
                        return freestar.log({
                            title: "VIDEO"
                        }, "PRIMIS ELEMENT NOT FOUND ON PAGE, SKIPPING"), !1
                    }
                } else e.nthElement ? t = document.body[e.nthElement] : freestar.log({
                    title: "VIDEO"
                }, "COULD NOT ACQUIRE DOM NODE FOR PRIMIS VIDEO. CONFIGURATION FOR VIDEO INCORRECT!");
            return t
        },
        Er = e => {
            window.addEventListener("primisPlayerInit", (function(t) {
                t.detail.playerApiId === Ar && (({
                    player: e,
                    requestTimestamp: t,
                    videoAd: n
                }) => {
                    e.addEventListener("adStarted", (function({
                        impValue: e
                    }) {
                        Vi({
                            bidder: "primis",
                            videoAd: n,
                            requestTimestamp: t
                        })
                    })), window.freestar.deleteVideo = function() {
                        window.freestar.log({
                            title: "VIDEO"
                        }, "Video delete");
                        const e = xr({
                            videoAd: n
                        });
                        if (e) {
                            const t = document.getElementById(kr);
                            t && t.remove();
                            const n = Array.from(e.children).find((e => null !== e.querySelector("#primis_container_div") || "primis_container_div" === e.id));
                            n && e.removeChild(n)
                        }
                    }
                })({
                    player: t.detail,
                    requestTimestamp: Date.now(),
                    videoAd: e
                })
            }));
            const t = xr({
                videoAd: e
            });
            null !== t ? Sr({
                videoAd: e,
                container: t
            }) : freestar.log({
                title: "VIDEO"
            }, "COULD NOT ACQUIRE DOM NODE FOR PRIMIS VIDEO")
        },
        Or = e => {
            const {
                name: t,
                embedCode: n
            } = e;
            if (t && n) {
                const e = document.getElementById(t);
                if (e) {
                    const t = document.createRange().createContextualFragment(n);
                    e.appendChild(t)
                } else freestar.log(20, `Failed to load STN video ad. Could not find container "${t}".`)
            } else freestar.log(30, "Failed to load STN video ad. Video ad must be configured with a name and embed code.")
        };

    function _r(e) {
        if (freestar.log({
                title: "VIDEO"
            }, "CONNATIX PLAYSPACE : video init..."), !e.scriptId) return;
        const {
            parentElement: t,
            classIndex: n
        } = e, i = n && n > -1 ? n : 0, r = t ? document.querySelectorAll(t)[i] : document.body;
        if (r) {
            freestar.log({
                title: "VIDEO"
            }, "CONNATIX PLAYSPACE : video target element : ", r);
            const t = Date.now();
            ! function({
                videoAd: e
            }) {
                const t = "//cd.connatix.com/connatix.playspace.js?cid=f9509d53-804e-427d-a0bc-1204c0a3bcb1";
                freestar.log({
                        title: "VIDEO"
                    }, "CONNATIX PLAYSPACE : script loading..."), Gi({
                        bidder: "connatix",
                        placementId: e.name,
                        tagUrl: t
                    }),
                    function(e) {
                        if (!window.cnxps) {
                            window.cnxps = {}, window.cnxps.cmd = [];
                            var n = e.createElement("iframe");
                            n.src = "javascript:false", n.display = "none", n.onload = function() {
                                var e = n.contentWindow.document,
                                    i = e.createElement("script");
                                i.src = t, i.setAttribute("async", "1"), i.setAttribute("type", "text/javascript"), e.body.appendChild(i)
                            }, e.head.appendChild(n)
                        }
                    }(document)
            }({
                videoAd: e
            }),
            function({
                videoAd: e,
                targetElement: t
            }) {
                const n = sn({
                    type: "script",
                    id: e.scriptId
                });
                t.appendChild(n), freestar.log({
                    title: "VIDEO"
                }, "CONNATIX PLAYSPACE : script element created : ", n)
            }({
                videoAd: e,
                targetElement: r
            }), window.cnxps.cmd.push((function() {
                cnxps(function({
                    videoAd: e
                }) {
                    const t = {
                        playerId: e.playerId,
                        settings: {
                            defaultSoundMode: window.cnxps.configEnums.DefaultSoundModeEnum.Off
                        }
                    };
                    return (!e.parentElement.length || e.toFloat || e.adType && "SLIDER" === e.adType) && (t.settings.customization = {
                        floating: {
                            mode: window.cnxps.configEnums.FloatingModeEnum[e.parentElement && "SLIDER" !== e.adType ? "AfterInView" : "Always"],
                            fixedPosition: window.cnxps.configEnums.FloatingFixedPositionModeEnum.Page,
                            scrollPosition: window.cnxps.configEnums.FloatingScrollPositionEnum.BottomRight,
                            floatingWidth: e.width && e.width > 100 ? e.width : 401,
                            floatingGutterX: 5,
                            floatingGutterY: 100
                        }
                    }), t
                }({
                    videoAd: e
                })).render(e.scriptId, (function(n, i) {
                    i && i.on && window.cnxps.configEvents && window.cnxps.configEvents.AdPlay && i.on(window.cnxps.configEvents.AdPlay, (() => {
                        Vi({
                            bidder: "connatix",
                            videoAd: e,
                            requestTimestamp: t
                        })
                    }))
                }))
            }))
        } else freestar.log({
            title: "VIDEO"
        }, "CONNATIX PLAYSPACE : video ad parent element not found. Skipping...")
    }
    const Tr = ({
        device: e = "desktop",
        videoSelect: t
    }) => (({
        videoDeviceType: e
    }) => "all_devices" === e || freestar.deviceInfo.device.type === e || "tablet" === freestar.deviceInfo.device.type && "desktop" === e)({
        videoDeviceType: e.toLowerCase()
    }) || "ALL_DEVICES" === e && (({
        videoSelect: e
    }) => !(e && e.length && (!e.length || null === document.getElementById(e))))({
        videoSelect: t
    });

    function Cr(e) {
        if (Nn({
                name: "video"
            })) return !1;
        const {
            vendor: t,
            device: n,
            name: i,
            videoSelect: r
        } = e;
        if (t && n && Tr({
                device: n,
                videoSelect: r
            })) {
            freestar.log({
                title: "VIDEO"
            }, `${i} eligible to run with device type ${freestar.deviceInfo.device.type} and is a ${t} video.`);
            ({
                connatixInit: Ir,
                primisInit: Er,
                connatixplayspaceInit: _r,
                stnInit: Or
            })[`${t.split("_").join("").toLowerCase()}Init`](e)
        }
    }
    var Rr = {
        exports: {}
    };
    var Nr, Mr = {
            exports: {}
        },
        Dr = He(Object.freeze({
            __proto__: null,
            default: {}
        }));

    function Br() {
        return Nr || (Nr = 1, function(e, t) {
            var n;
            e.exports = (n = n || function(e, t) {
                var n;
                if ("undefined" != typeof window && window.crypto && (n = window.crypto), "undefined" != typeof self && self.crypto && (n = self.crypto), "undefined" != typeof globalThis && globalThis.crypto && (n = globalThis.crypto), !n && "undefined" != typeof window && window.msCrypto && (n = window.msCrypto), !n && void 0 !== qe && qe.crypto && (n = qe.crypto), !n) try {
                    n = Dr
                } catch (e) {}
                var i = function() {
                        if (n) {
                            if ("function" == typeof n.getRandomValues) try {
                                return n.getRandomValues(new Uint32Array(1))[0]
                            } catch (e) {}
                            if ("function" == typeof n.randomBytes) try {
                                return n.randomBytes(4).readInt32LE()
                            } catch (e) {}
                        }
                        throw new Error("Native crypto module could not be used to get secure random number.")
                    },
                    r = Object.create || function() {
                        function e() {}
                        return function(t) {
                            var n;
                            return e.prototype = t, n = new e, e.prototype = null, n
                        }
                    }(),
                    s = {},
                    a = s.lib = {},
                    o = a.Base = {
                        extend: function(e) {
                            var t = r(this);
                            return e && t.mixIn(e), t.hasOwnProperty("init") && this.init !== t.init || (t.init = function() {
                                t.$super.init.apply(this, arguments)
                            }), t.init.prototype = t, t.$super = this, t
                        },
                        create: function() {
                            var e = this.extend();
                            return e.init.apply(e, arguments), e
                        },
                        init: function() {},
                        mixIn: function(e) {
                            for (var t in e) e.hasOwnProperty(t) && (this[t] = e[t]);
                            e.hasOwnProperty("toString") && (this.toString = e.toString)
                        },
                        clone: function() {
                            return this.init.prototype.extend(this)
                        }
                    },
                    d = a.WordArray = o.extend({
                        init: function(e, n) {
                            e = this.words = e || [], this.sigBytes = n != t ? n : 4 * e.length
                        },
                        toString: function(e) {
                            return (e || c).stringify(this)
                        },
                        concat: function(e) {
                            var t = this.words,
                                n = e.words,
                                i = this.sigBytes,
                                r = e.sigBytes;
                            if (this.clamp(), i % 4)
                                for (var s = 0; s < r; s++) {
                                    var a = n[s >>> 2] >>> 24 - s % 4 * 8 & 255;
                                    t[i + s >>> 2] |= a << 24 - (i + s) % 4 * 8
                                } else
                                    for (var o = 0; o < r; o += 4) t[i + o >>> 2] = n[o >>> 2];
                            return this.sigBytes += r, this
                        },
                        clamp: function() {
                            var t = this.words,
                                n = this.sigBytes;
                            t[n >>> 2] &= 4294967295 << 32 - n % 4 * 8, t.length = e.ceil(n / 4)
                        },
                        clone: function() {
                            var e = o.clone.call(this);
                            return e.words = this.words.slice(0), e
                        },
                        random: function(e) {
                            for (var t = [], n = 0; n < e; n += 4) t.push(i());
                            return new d.init(t, e)
                        }
                    }),
                    l = s.enc = {},
                    c = l.Hex = {
                        stringify: function(e) {
                            for (var t = e.words, n = e.sigBytes, i = [], r = 0; r < n; r++) {
                                var s = t[r >>> 2] >>> 24 - r % 4 * 8 & 255;
                                i.push((s >>> 4).toString(16)), i.push((15 & s).toString(16))
                            }
                            return i.join("")
                        },
                        parse: function(e) {
                            for (var t = e.length, n = [], i = 0; i < t; i += 2) n[i >>> 3] |= parseInt(e.substr(i, 2), 16) << 24 - i % 8 * 4;
                            return new d.init(n, t / 2)
                        }
                    },
                    f = l.Latin1 = {
                        stringify: function(e) {
                            for (var t = e.words, n = e.sigBytes, i = [], r = 0; r < n; r++) {
                                var s = t[r >>> 2] >>> 24 - r % 4 * 8 & 255;
                                i.push(String.fromCharCode(s))
                            }
                            return i.join("")
                        },
                        parse: function(e) {
                            for (var t = e.length, n = [], i = 0; i < t; i++) n[i >>> 2] |= (255 & e.charCodeAt(i)) << 24 - i % 4 * 8;
                            return new d.init(n, t)
                        }
                    },
                    u = l.Utf8 = {
                        stringify: function(e) {
                            try {
                                return decodeURIComponent(escape(f.stringify(e)))
                            } catch (e) {
                                throw new Error("Malformed UTF-8 data")
                            }
                        },
                        parse: function(e) {
                            return f.parse(unescape(encodeURIComponent(e)))
                        }
                    },
                    p = a.BufferedBlockAlgorithm = o.extend({
                        reset: function() {
                            this._data = new d.init, this._nDataBytes = 0
                        },
                        _append: function(e) {
                            "string" == typeof e && (e = u.parse(e)), this._data.concat(e), this._nDataBytes += e.sigBytes
                        },
                        _process: function(t) {
                            var n, i = this._data,
                                r = i.words,
                                s = i.sigBytes,
                                a = this.blockSize,
                                o = s / (4 * a),
                                l = (o = t ? e.ceil(o) : e.max((0 | o) - this._minBufferSize, 0)) * a,
                                c = e.min(4 * l, s);
                            if (l) {
                                for (var f = 0; f < l; f += a) this._doProcessBlock(r, f);
                                n = r.splice(0, l), i.sigBytes -= c
                            }
                            return new d.init(n, c)
                        },
                        clone: function() {
                            var e = o.clone.call(this);
                            return e._data = this._data.clone(), e
                        },
                        _minBufferSize: 0
                    });
                a.Hasher = p.extend({
                    cfg: o.extend(),
                    init: function(e) {
                        this.cfg = this.cfg.extend(e), this.reset()
                    },
                    reset: function() {
                        p.reset.call(this), this._doReset()
                    },
                    update: function(e) {
                        return this._append(e), this._process(), this
                    },
                    finalize: function(e) {
                        return e && this._append(e), this._doFinalize()
                    },
                    blockSize: 16,
                    _createHelper: function(e) {
                        return function(t, n) {
                            return new e.init(n).finalize(t)
                        }
                    },
                    _createHmacHelper: function(e) {
                        return function(t, n) {
                            return new h.HMAC.init(e, n).finalize(t)
                        }
                    }
                });
                var h = s.algo = {};
                return s
            }(Math), n)
        }(Mr, Mr.exports)), Mr.exports
    }
    Mr.exports;
    var Pr, zr = {
        exports: {}
    };

    function Lr() {
        return Pr || (Pr = 1, function(e, t) {
            var n, i, r, s, a, o, d;
            e.exports = (d = Br(), r = (i = d).lib, s = r.Base, a = r.WordArray, (o = i.x64 = {}).Word = s.extend({
                init: function(e, t) {
                    this.high = e, this.low = t
                }
            }), o.WordArray = s.extend({
                init: function(e, t) {
                    e = this.words = e || [], this.sigBytes = t != n ? t : 8 * e.length
                },
                toX32: function() {
                    for (var e = this.words, t = e.length, n = [], i = 0; i < t; i++) {
                        var r = e[i];
                        n.push(r.high), n.push(r.low)
                    }
                    return a.create(n, this.sigBytes)
                },
                clone: function() {
                    for (var e = s.clone.call(this), t = e.words = this.words.slice(0), n = t.length, i = 0; i < n; i++) t[i] = t[i].clone();
                    return e
                }
            }), d)
        }(zr, zr.exports)), zr.exports
    }
    zr.exports;
    var jr, Fr = {
        exports: {}
    };

    function Ur() {
        return jr || (jr = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function() {
                if ("function" == typeof ArrayBuffer) {
                    var e = n.lib.WordArray,
                        t = e.init,
                        i = e.init = function(e) {
                            if (e instanceof ArrayBuffer && (e = new Uint8Array(e)), (e instanceof Int8Array || "undefined" != typeof Uint8ClampedArray && e instanceof Uint8ClampedArray || e instanceof Int16Array || e instanceof Uint16Array || e instanceof Int32Array || e instanceof Uint32Array || e instanceof Float32Array || e instanceof Float64Array) && (e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength)), e instanceof Uint8Array) {
                                for (var n = e.byteLength, i = [], r = 0; r < n; r++) i[r >>> 2] |= e[r] << 24 - r % 4 * 8;
                                t.call(this, i, n)
                            } else t.apply(this, arguments)
                        };
                    i.prototype = e
                }
            }(), n.lib.WordArray)
        }(Fr)), Fr.exports
    }
    var qr, $r = {
        exports: {}
    };

    function Hr() {
        return qr || (qr = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function() {
                var e = n,
                    t = e.lib.WordArray,
                    i = e.enc;

                function r(e) {
                    return e << 8 & 4278255360 | e >>> 8 & 16711935
                }
                i.Utf16 = i.Utf16BE = {
                    stringify: function(e) {
                        for (var t = e.words, n = e.sigBytes, i = [], r = 0; r < n; r += 2) {
                            var s = t[r >>> 2] >>> 16 - r % 4 * 8 & 65535;
                            i.push(String.fromCharCode(s))
                        }
                        return i.join("")
                    },
                    parse: function(e) {
                        for (var n = e.length, i = [], r = 0; r < n; r++) i[r >>> 1] |= e.charCodeAt(r) << 16 - r % 2 * 16;
                        return t.create(i, 2 * n)
                    }
                }, i.Utf16LE = {
                    stringify: function(e) {
                        for (var t = e.words, n = e.sigBytes, i = [], s = 0; s < n; s += 2) {
                            var a = r(t[s >>> 2] >>> 16 - s % 4 * 8 & 65535);
                            i.push(String.fromCharCode(a))
                        }
                        return i.join("")
                    },
                    parse: function(e) {
                        for (var n = e.length, i = [], s = 0; s < n; s++) i[s >>> 1] |= r(e.charCodeAt(s) << 16 - s % 2 * 16);
                        return t.create(i, 2 * n)
                    }
                }
            }(), n.enc.Utf16)
        }($r)), $r.exports
    }
    var Vr, Gr = {
        exports: {}
    };

    function Wr() {
        return Vr || (Vr = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function() {
                var e = n,
                    t = e.lib.WordArray;

                function i(e, n, i) {
                    for (var r = [], s = 0, a = 0; a < n; a++)
                        if (a % 4) {
                            var o = i[e.charCodeAt(a - 1)] << a % 4 * 2 | i[e.charCodeAt(a)] >>> 6 - a % 4 * 2;
                            r[s >>> 2] |= o << 24 - s % 4 * 8, s++
                        }
                    return t.create(r, s)
                }
                e.enc.Base64 = {
                    stringify: function(e) {
                        var t = e.words,
                            n = e.sigBytes,
                            i = this._map;
                        e.clamp();
                        for (var r = [], s = 0; s < n; s += 3)
                            for (var a = (t[s >>> 2] >>> 24 - s % 4 * 8 & 255) << 16 | (t[s + 1 >>> 2] >>> 24 - (s + 1) % 4 * 8 & 255) << 8 | t[s + 2 >>> 2] >>> 24 - (s + 2) % 4 * 8 & 255, o = 0; o < 4 && s + .75 * o < n; o++) r.push(i.charAt(a >>> 6 * (3 - o) & 63));
                        var d = i.charAt(64);
                        if (d)
                            for (; r.length % 4;) r.push(d);
                        return r.join("")
                    },
                    parse: function(e) {
                        var t = e.length,
                            n = this._map,
                            r = this._reverseMap;
                        if (!r) {
                            r = this._reverseMap = [];
                            for (var s = 0; s < n.length; s++) r[n.charCodeAt(s)] = s
                        }
                        var a = n.charAt(64);
                        if (a) {
                            var o = e.indexOf(a); - 1 !== o && (t = o)
                        }
                        return i(e, t, r)
                    },
                    _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
                }
            }(), n.enc.Base64)
        }(Gr, Gr.exports)), Gr.exports
    }
    Gr.exports;
    var Qr, Yr = {
        exports: {}
    };

    function Kr() {
        return Qr || (Qr = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function() {
                var e = n,
                    t = e.lib.WordArray;

                function i(e, n, i) {
                    for (var r = [], s = 0, a = 0; a < n; a++)
                        if (a % 4) {
                            var o = i[e.charCodeAt(a - 1)] << a % 4 * 2 | i[e.charCodeAt(a)] >>> 6 - a % 4 * 2;
                            r[s >>> 2] |= o << 24 - s % 4 * 8, s++
                        }
                    return t.create(r, s)
                }
                e.enc.Base64url = {
                    stringify: function(e, t = !0) {
                        var n = e.words,
                            i = e.sigBytes,
                            r = t ? this._safe_map : this._map;
                        e.clamp();
                        for (var s = [], a = 0; a < i; a += 3)
                            for (var o = (n[a >>> 2] >>> 24 - a % 4 * 8 & 255) << 16 | (n[a + 1 >>> 2] >>> 24 - (a + 1) % 4 * 8 & 255) << 8 | n[a + 2 >>> 2] >>> 24 - (a + 2) % 4 * 8 & 255, d = 0; d < 4 && a + .75 * d < i; d++) s.push(r.charAt(o >>> 6 * (3 - d) & 63));
                        var l = r.charAt(64);
                        if (l)
                            for (; s.length % 4;) s.push(l);
                        return s.join("")
                    },
                    parse: function(e, t = !0) {
                        var n = e.length,
                            r = t ? this._safe_map : this._map,
                            s = this._reverseMap;
                        if (!s) {
                            s = this._reverseMap = [];
                            for (var a = 0; a < r.length; a++) s[r.charCodeAt(a)] = a
                        }
                        var o = r.charAt(64);
                        if (o) {
                            var d = e.indexOf(o); - 1 !== d && (n = d)
                        }
                        return i(e, n, s)
                    },
                    _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                    _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
                }
            }(), n.enc.Base64url)
        }(Yr)), Yr.exports
    }
    var Jr, Xr = {
        exports: {}
    };

    function Zr() {
        return Jr || (Jr = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function(e) {
                var t = n,
                    i = t.lib,
                    r = i.WordArray,
                    s = i.Hasher,
                    a = t.algo,
                    o = [];
                ! function() {
                    for (var t = 0; t < 64; t++) o[t] = 4294967296 * e.abs(e.sin(t + 1)) | 0
                }();
                var d = a.MD5 = s.extend({
                    _doReset: function() {
                        this._hash = new r.init([1732584193, 4023233417, 2562383102, 271733878])
                    },
                    _doProcessBlock: function(e, t) {
                        for (var n = 0; n < 16; n++) {
                            var i = t + n,
                                r = e[i];
                            e[i] = 16711935 & (r << 8 | r >>> 24) | 4278255360 & (r << 24 | r >>> 8)
                        }
                        var s = this._hash.words,
                            a = e[t + 0],
                            d = e[t + 1],
                            p = e[t + 2],
                            h = e[t + 3],
                            m = e[t + 4],
                            g = e[t + 5],
                            b = e[t + 6],
                            y = e[t + 7],
                            w = e[t + 8],
                            v = e[t + 9],
                            I = e[t + 10],
                            A = e[t + 11],
                            k = e[t + 12],
                            S = e[t + 13],
                            x = e[t + 14],
                            E = e[t + 15],
                            O = s[0],
                            _ = s[1],
                            T = s[2],
                            C = s[3];
                        O = l(O, _, T, C, a, 7, o[0]), C = l(C, O, _, T, d, 12, o[1]), T = l(T, C, O, _, p, 17, o[2]), _ = l(_, T, C, O, h, 22, o[3]), O = l(O, _, T, C, m, 7, o[4]), C = l(C, O, _, T, g, 12, o[5]), T = l(T, C, O, _, b, 17, o[6]), _ = l(_, T, C, O, y, 22, o[7]), O = l(O, _, T, C, w, 7, o[8]), C = l(C, O, _, T, v, 12, o[9]), T = l(T, C, O, _, I, 17, o[10]), _ = l(_, T, C, O, A, 22, o[11]), O = l(O, _, T, C, k, 7, o[12]), C = l(C, O, _, T, S, 12, o[13]), T = l(T, C, O, _, x, 17, o[14]), O = c(O, _ = l(_, T, C, O, E, 22, o[15]), T, C, d, 5, o[16]), C = c(C, O, _, T, b, 9, o[17]), T = c(T, C, O, _, A, 14, o[18]), _ = c(_, T, C, O, a, 20, o[19]), O = c(O, _, T, C, g, 5, o[20]), C = c(C, O, _, T, I, 9, o[21]), T = c(T, C, O, _, E, 14, o[22]), _ = c(_, T, C, O, m, 20, o[23]), O = c(O, _, T, C, v, 5, o[24]), C = c(C, O, _, T, x, 9, o[25]), T = c(T, C, O, _, h, 14, o[26]), _ = c(_, T, C, O, w, 20, o[27]), O = c(O, _, T, C, S, 5, o[28]), C = c(C, O, _, T, p, 9, o[29]), T = c(T, C, O, _, y, 14, o[30]), O = f(O, _ = c(_, T, C, O, k, 20, o[31]), T, C, g, 4, o[32]), C = f(C, O, _, T, w, 11, o[33]), T = f(T, C, O, _, A, 16, o[34]), _ = f(_, T, C, O, x, 23, o[35]), O = f(O, _, T, C, d, 4, o[36]), C = f(C, O, _, T, m, 11, o[37]), T = f(T, C, O, _, y, 16, o[38]), _ = f(_, T, C, O, I, 23, o[39]), O = f(O, _, T, C, S, 4, o[40]), C = f(C, O, _, T, a, 11, o[41]), T = f(T, C, O, _, h, 16, o[42]), _ = f(_, T, C, O, b, 23, o[43]), O = f(O, _, T, C, v, 4, o[44]), C = f(C, O, _, T, k, 11, o[45]), T = f(T, C, O, _, E, 16, o[46]), O = u(O, _ = f(_, T, C, O, p, 23, o[47]), T, C, a, 6, o[48]), C = u(C, O, _, T, y, 10, o[49]), T = u(T, C, O, _, x, 15, o[50]), _ = u(_, T, C, O, g, 21, o[51]), O = u(O, _, T, C, k, 6, o[52]), C = u(C, O, _, T, h, 10, o[53]), T = u(T, C, O, _, I, 15, o[54]), _ = u(_, T, C, O, d, 21, o[55]), O = u(O, _, T, C, w, 6, o[56]), C = u(C, O, _, T, E, 10, o[57]), T = u(T, C, O, _, b, 15, o[58]), _ = u(_, T, C, O, S, 21, o[59]), O = u(O, _, T, C, m, 6, o[60]), C = u(C, O, _, T, A, 10, o[61]), T = u(T, C, O, _, p, 15, o[62]), _ = u(_, T, C, O, v, 21, o[63]), s[0] = s[0] + O | 0, s[1] = s[1] + _ | 0, s[2] = s[2] + T | 0, s[3] = s[3] + C | 0
                    },
                    _doFinalize: function() {
                        var t = this._data,
                            n = t.words,
                            i = 8 * this._nDataBytes,
                            r = 8 * t.sigBytes;
                        n[r >>> 5] |= 128 << 24 - r % 32;
                        var s = e.floor(i / 4294967296),
                            a = i;
                        n[15 + (r + 64 >>> 9 << 4)] = 16711935 & (s << 8 | s >>> 24) | 4278255360 & (s << 24 | s >>> 8), n[14 + (r + 64 >>> 9 << 4)] = 16711935 & (a << 8 | a >>> 24) | 4278255360 & (a << 24 | a >>> 8), t.sigBytes = 4 * (n.length + 1), this._process();
                        for (var o = this._hash, d = o.words, l = 0; l < 4; l++) {
                            var c = d[l];
                            d[l] = 16711935 & (c << 8 | c >>> 24) | 4278255360 & (c << 24 | c >>> 8)
                        }
                        return o
                    },
                    clone: function() {
                        var e = s.clone.call(this);
                        return e._hash = this._hash.clone(), e
                    }
                });

                function l(e, t, n, i, r, s, a) {
                    var o = e + (t & n | ~t & i) + r + a;
                    return (o << s | o >>> 32 - s) + t
                }

                function c(e, t, n, i, r, s, a) {
                    var o = e + (t & i | n & ~i) + r + a;
                    return (o << s | o >>> 32 - s) + t
                }

                function f(e, t, n, i, r, s, a) {
                    var o = e + (t ^ n ^ i) + r + a;
                    return (o << s | o >>> 32 - s) + t
                }

                function u(e, t, n, i, r, s, a) {
                    var o = e + (n ^ (t | ~i)) + r + a;
                    return (o << s | o >>> 32 - s) + t
                }
                t.MD5 = s._createHelper(d), t.HmacMD5 = s._createHmacHelper(d)
            }(Math), n.MD5)
        }(Xr, Xr.exports)), Xr.exports
    }
    Xr.exports;
    var es, ts = {
        exports: {}
    };

    function ns() {
        return es || (es = 1, function(e, t) {
            var n, i, r, s, a, o, d, l;
            e.exports = (l = Br(), i = (n = l).lib, r = i.WordArray, s = i.Hasher, a = n.algo, o = [], d = a.SHA1 = s.extend({
                _doReset: function() {
                    this._hash = new r.init([1732584193, 4023233417, 2562383102, 271733878, 3285377520])
                },
                _doProcessBlock: function(e, t) {
                    for (var n = this._hash.words, i = n[0], r = n[1], s = n[2], a = n[3], d = n[4], l = 0; l < 80; l++) {
                        if (l < 16) o[l] = 0 | e[t + l];
                        else {
                            var c = o[l - 3] ^ o[l - 8] ^ o[l - 14] ^ o[l - 16];
                            o[l] = c << 1 | c >>> 31
                        }
                        var f = (i << 5 | i >>> 27) + d + o[l];
                        f += l < 20 ? 1518500249 + (r & s | ~r & a) : l < 40 ? 1859775393 + (r ^ s ^ a) : l < 60 ? (r & s | r & a | s & a) - 1894007588 : (r ^ s ^ a) - 899497514, d = a, a = s, s = r << 30 | r >>> 2, r = i, i = f
                    }
                    n[0] = n[0] + i | 0, n[1] = n[1] + r | 0, n[2] = n[2] + s | 0, n[3] = n[3] + a | 0, n[4] = n[4] + d | 0
                },
                _doFinalize: function() {
                    var e = this._data,
                        t = e.words,
                        n = 8 * this._nDataBytes,
                        i = 8 * e.sigBytes;
                    return t[i >>> 5] |= 128 << 24 - i % 32, t[14 + (i + 64 >>> 9 << 4)] = Math.floor(n / 4294967296), t[15 + (i + 64 >>> 9 << 4)] = n, e.sigBytes = 4 * t.length, this._process(), this._hash
                },
                clone: function() {
                    var e = s.clone.call(this);
                    return e._hash = this._hash.clone(), e
                }
            }), n.SHA1 = s._createHelper(d), n.HmacSHA1 = s._createHmacHelper(d), l.SHA1)
        }(ts, ts.exports)), ts.exports
    }
    ts.exports;
    var is, rs = {
        exports: {}
    };

    function ss() {
        return is || (is = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function(e) {
                var t = n,
                    i = t.lib,
                    r = i.WordArray,
                    s = i.Hasher,
                    a = t.algo,
                    o = [],
                    d = [];
                ! function() {
                    function t(t) {
                        for (var n = e.sqrt(t), i = 2; i <= n; i++)
                            if (!(t % i)) return !1;
                        return !0
                    }

                    function n(e) {
                        return 4294967296 * (e - (0 | e)) | 0
                    }
                    for (var i = 2, r = 0; r < 64;) t(i) && (r < 8 && (o[r] = n(e.pow(i, .5))), d[r] = n(e.pow(i, 1 / 3)), r++), i++
                }();
                var l = [],
                    c = a.SHA256 = s.extend({
                        _doReset: function() {
                            this._hash = new r.init(o.slice(0))
                        },
                        _doProcessBlock: function(e, t) {
                            for (var n = this._hash.words, i = n[0], r = n[1], s = n[2], a = n[3], o = n[4], c = n[5], f = n[6], u = n[7], p = 0; p < 64; p++) {
                                if (p < 16) l[p] = 0 | e[t + p];
                                else {
                                    var h = l[p - 15],
                                        m = (h << 25 | h >>> 7) ^ (h << 14 | h >>> 18) ^ h >>> 3,
                                        g = l[p - 2],
                                        b = (g << 15 | g >>> 17) ^ (g << 13 | g >>> 19) ^ g >>> 10;
                                    l[p] = m + l[p - 7] + b + l[p - 16]
                                }
                                var y = i & r ^ i & s ^ r & s,
                                    w = (i << 30 | i >>> 2) ^ (i << 19 | i >>> 13) ^ (i << 10 | i >>> 22),
                                    v = u + ((o << 26 | o >>> 6) ^ (o << 21 | o >>> 11) ^ (o << 7 | o >>> 25)) + (o & c ^ ~o & f) + d[p] + l[p];
                                u = f, f = c, c = o, o = a + v | 0, a = s, s = r, r = i, i = v + (w + y) | 0
                            }
                            n[0] = n[0] + i | 0, n[1] = n[1] + r | 0, n[2] = n[2] + s | 0, n[3] = n[3] + a | 0, n[4] = n[4] + o | 0, n[5] = n[5] + c | 0, n[6] = n[6] + f | 0, n[7] = n[7] + u | 0
                        },
                        _doFinalize: function() {
                            var t = this._data,
                                n = t.words,
                                i = 8 * this._nDataBytes,
                                r = 8 * t.sigBytes;
                            return n[r >>> 5] |= 128 << 24 - r % 32, n[14 + (r + 64 >>> 9 << 4)] = e.floor(i / 4294967296), n[15 + (r + 64 >>> 9 << 4)] = i, t.sigBytes = 4 * n.length, this._process(), this._hash
                        },
                        clone: function() {
                            var e = s.clone.call(this);
                            return e._hash = this._hash.clone(), e
                        }
                    });
                t.SHA256 = s._createHelper(c), t.HmacSHA256 = s._createHmacHelper(c)
            }(Math), n.SHA256)
        }(rs, rs.exports)), rs.exports
    }
    rs.exports;
    var as, os = {
        exports: {}
    };
    var ds, ls = {
        exports: {}
    };

    function cs() {
        return ds || (ds = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Lr(), function() {
                var e = n,
                    t = e.lib.Hasher,
                    i = e.x64,
                    r = i.Word,
                    s = i.WordArray,
                    a = e.algo;

                function o() {
                    return r.create.apply(r, arguments)
                }
                var d = [o(1116352408, 3609767458), o(1899447441, 602891725), o(3049323471, 3964484399), o(3921009573, 2173295548), o(961987163, 4081628472), o(1508970993, 3053834265), o(2453635748, 2937671579), o(2870763221, 3664609560), o(3624381080, 2734883394), o(310598401, 1164996542), o(607225278, 1323610764), o(1426881987, 3590304994), o(1925078388, 4068182383), o(2162078206, 991336113), o(2614888103, 633803317), o(3248222580, 3479774868), o(3835390401, 2666613458), o(4022224774, 944711139), o(264347078, 2341262773), o(604807628, 2007800933), o(770255983, 1495990901), o(1249150122, 1856431235), o(1555081692, 3175218132), o(1996064986, 2198950837), o(2554220882, 3999719339), o(2821834349, 766784016), o(2952996808, 2566594879), o(3210313671, 3203337956), o(3336571891, 1034457026), o(3584528711, 2466948901), o(113926993, 3758326383), o(338241895, 168717936), o(666307205, 1188179964), o(773529912, 1546045734), o(1294757372, 1522805485), o(1396182291, 2643833823), o(1695183700, 2343527390), o(1986661051, 1014477480), o(2177026350, 1206759142), o(2456956037, 344077627), o(2730485921, 1290863460), o(2820302411, 3158454273), o(3259730800, 3505952657), o(3345764771, 106217008), o(3516065817, 3606008344), o(3600352804, 1432725776), o(4094571909, 1467031594), o(275423344, 851169720), o(430227734, 3100823752), o(506948616, 1363258195), o(659060556, 3750685593), o(883997877, 3785050280), o(958139571, 3318307427), o(1322822218, 3812723403), o(1537002063, 2003034995), o(1747873779, 3602036899), o(1955562222, 1575990012), o(2024104815, 1125592928), o(2227730452, 2716904306), o(2361852424, 442776044), o(2428436474, 593698344), o(2756734187, 3733110249), o(3204031479, 2999351573), o(3329325298, 3815920427), o(3391569614, 3928383900), o(3515267271, 566280711), o(3940187606, 3454069534), o(4118630271, 4000239992), o(116418474, 1914138554), o(174292421, 2731055270), o(289380356, 3203993006), o(460393269, 320620315), o(685471733, 587496836), o(852142971, 1086792851), o(1017036298, 365543100), o(1126000580, 2618297676), o(1288033470, 3409855158), o(1501505948, 4234509866), o(1607167915, 987167468), o(1816402316, 1246189591)],
                    l = [];
                ! function() {
                    for (var e = 0; e < 80; e++) l[e] = o()
                }();
                var c = a.SHA512 = t.extend({
                    _doReset: function() {
                        this._hash = new s.init([new r.init(1779033703, 4089235720), new r.init(3144134277, 2227873595), new r.init(1013904242, 4271175723), new r.init(2773480762, 1595750129), new r.init(1359893119, 2917565137), new r.init(2600822924, 725511199), new r.init(528734635, 4215389547), new r.init(1541459225, 327033209)])
                    },
                    _doProcessBlock: function(e, t) {
                        for (var n = this._hash.words, i = n[0], r = n[1], s = n[2], a = n[3], o = n[4], c = n[5], f = n[6], u = n[7], p = i.high, h = i.low, m = r.high, g = r.low, b = s.high, y = s.low, w = a.high, v = a.low, I = o.high, A = o.low, k = c.high, S = c.low, x = f.high, E = f.low, O = u.high, _ = u.low, T = p, C = h, R = m, N = g, M = b, D = y, B = w, P = v, z = I, L = A, j = k, F = S, U = x, q = E, $ = O, H = _, V = 0; V < 80; V++) {
                            var G, W, Q = l[V];
                            if (V < 16) W = Q.high = 0 | e[t + 2 * V], G = Q.low = 0 | e[t + 2 * V + 1];
                            else {
                                var Y = l[V - 15],
                                    K = Y.high,
                                    J = Y.low,
                                    X = (K >>> 1 | J << 31) ^ (K >>> 8 | J << 24) ^ K >>> 7,
                                    Z = (J >>> 1 | K << 31) ^ (J >>> 8 | K << 24) ^ (J >>> 7 | K << 25),
                                    ee = l[V - 2],
                                    te = ee.high,
                                    ne = ee.low,
                                    ie = (te >>> 19 | ne << 13) ^ (te << 3 | ne >>> 29) ^ te >>> 6,
                                    re = (ne >>> 19 | te << 13) ^ (ne << 3 | te >>> 29) ^ (ne >>> 6 | te << 26),
                                    se = l[V - 7],
                                    ae = se.high,
                                    oe = se.low,
                                    de = l[V - 16],
                                    le = de.high,
                                    ce = de.low;
                                W = (W = (W = X + ae + ((G = Z + oe) >>> 0 < Z >>> 0 ? 1 : 0)) + ie + ((G += re) >>> 0 < re >>> 0 ? 1 : 0)) + le + ((G += ce) >>> 0 < ce >>> 0 ? 1 : 0), Q.high = W, Q.low = G
                            }
                            var fe, ue = z & j ^ ~z & U,
                                pe = L & F ^ ~L & q,
                                he = T & R ^ T & M ^ R & M,
                                me = C & N ^ C & D ^ N & D,
                                ge = (T >>> 28 | C << 4) ^ (T << 30 | C >>> 2) ^ (T << 25 | C >>> 7),
                                be = (C >>> 28 | T << 4) ^ (C << 30 | T >>> 2) ^ (C << 25 | T >>> 7),
                                ye = (z >>> 14 | L << 18) ^ (z >>> 18 | L << 14) ^ (z << 23 | L >>> 9),
                                we = (L >>> 14 | z << 18) ^ (L >>> 18 | z << 14) ^ (L << 23 | z >>> 9),
                                ve = d[V],
                                Ie = ve.high,
                                Ae = ve.low,
                                ke = $ + ye + ((fe = H + we) >>> 0 < H >>> 0 ? 1 : 0),
                                Se = be + me;
                            $ = U, H = q, U = j, q = F, j = z, F = L, z = B + (ke = (ke = (ke = ke + ue + ((fe += pe) >>> 0 < pe >>> 0 ? 1 : 0)) + Ie + ((fe += Ae) >>> 0 < Ae >>> 0 ? 1 : 0)) + W + ((fe += G) >>> 0 < G >>> 0 ? 1 : 0)) + ((L = P + fe | 0) >>> 0 < P >>> 0 ? 1 : 0) | 0, B = M, P = D, M = R, D = N, R = T, N = C, T = ke + (ge + he + (Se >>> 0 < be >>> 0 ? 1 : 0)) + ((C = fe + Se | 0) >>> 0 < fe >>> 0 ? 1 : 0) | 0
                        }
                        h = i.low = h + C, i.high = p + T + (h >>> 0 < C >>> 0 ? 1 : 0), g = r.low = g + N, r.high = m + R + (g >>> 0 < N >>> 0 ? 1 : 0), y = s.low = y + D, s.high = b + M + (y >>> 0 < D >>> 0 ? 1 : 0), v = a.low = v + P, a.high = w + B + (v >>> 0 < P >>> 0 ? 1 : 0), A = o.low = A + L, o.high = I + z + (A >>> 0 < L >>> 0 ? 1 : 0), S = c.low = S + F, c.high = k + j + (S >>> 0 < F >>> 0 ? 1 : 0), E = f.low = E + q, f.high = x + U + (E >>> 0 < q >>> 0 ? 1 : 0), _ = u.low = _ + H, u.high = O + $ + (_ >>> 0 < H >>> 0 ? 1 : 0)
                    },
                    _doFinalize: function() {
                        var e = this._data,
                            t = e.words,
                            n = 8 * this._nDataBytes,
                            i = 8 * e.sigBytes;
                        return t[i >>> 5] |= 128 << 24 - i % 32, t[30 + (i + 128 >>> 10 << 5)] = Math.floor(n / 4294967296), t[31 + (i + 128 >>> 10 << 5)] = n, e.sigBytes = 4 * t.length, this._process(), this._hash.toX32()
                    },
                    clone: function() {
                        var e = t.clone.call(this);
                        return e._hash = this._hash.clone(), e
                    },
                    blockSize: 32
                });
                e.SHA512 = t._createHelper(c), e.HmacSHA512 = t._createHmacHelper(c)
            }(), n.SHA512)
        }(ls, ls.exports)), ls.exports
    }
    ls.exports;
    var fs, us = {
        exports: {}
    };
    var ps, hs = {
        exports: {}
    };

    function ms() {
        return ps || (ps = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Lr(), function(e) {
                var t = n,
                    i = t.lib,
                    r = i.WordArray,
                    s = i.Hasher,
                    a = t.x64.Word,
                    o = t.algo,
                    d = [],
                    l = [],
                    c = [];
                ! function() {
                    for (var e = 1, t = 0, n = 0; n < 24; n++) {
                        d[e + 5 * t] = (n + 1) * (n + 2) / 2 % 64;
                        var i = (2 * e + 3 * t) % 5;
                        e = t % 5, t = i
                    }
                    for (e = 0; e < 5; e++)
                        for (t = 0; t < 5; t++) l[e + 5 * t] = t + (2 * e + 3 * t) % 5 * 5;
                    for (var r = 1, s = 0; s < 24; s++) {
                        for (var o = 0, f = 0, u = 0; u < 7; u++) {
                            if (1 & r) {
                                var p = (1 << u) - 1;
                                p < 32 ? f ^= 1 << p : o ^= 1 << p - 32
                            }
                            128 & r ? r = r << 1 ^ 113 : r <<= 1
                        }
                        c[s] = a.create(o, f)
                    }
                }();
                var f = [];
                ! function() {
                    for (var e = 0; e < 25; e++) f[e] = a.create()
                }();
                var u = o.SHA3 = s.extend({
                    cfg: s.cfg.extend({
                        outputLength: 512
                    }),
                    _doReset: function() {
                        for (var e = this._state = [], t = 0; t < 25; t++) e[t] = new a.init;
                        this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32
                    },
                    _doProcessBlock: function(e, t) {
                        for (var n = this._state, i = this.blockSize / 2, r = 0; r < i; r++) {
                            var s = e[t + 2 * r],
                                a = e[t + 2 * r + 1];
                            s = 16711935 & (s << 8 | s >>> 24) | 4278255360 & (s << 24 | s >>> 8), a = 16711935 & (a << 8 | a >>> 24) | 4278255360 & (a << 24 | a >>> 8), (_ = n[r]).high ^= a, _.low ^= s
                        }
                        for (var o = 0; o < 24; o++) {
                            for (var u = 0; u < 5; u++) {
                                for (var p = 0, h = 0, m = 0; m < 5; m++) p ^= (_ = n[u + 5 * m]).high, h ^= _.low;
                                var g = f[u];
                                g.high = p, g.low = h
                            }
                            for (u = 0; u < 5; u++) {
                                var b = f[(u + 4) % 5],
                                    y = f[(u + 1) % 5],
                                    w = y.high,
                                    v = y.low;
                                for (p = b.high ^ (w << 1 | v >>> 31), h = b.low ^ (v << 1 | w >>> 31), m = 0; m < 5; m++)(_ = n[u + 5 * m]).high ^= p, _.low ^= h
                            }
                            for (var I = 1; I < 25; I++) {
                                var A = (_ = n[I]).high,
                                    k = _.low,
                                    S = d[I];
                                S < 32 ? (p = A << S | k >>> 32 - S, h = k << S | A >>> 32 - S) : (p = k << S - 32 | A >>> 64 - S, h = A << S - 32 | k >>> 64 - S);
                                var x = f[l[I]];
                                x.high = p, x.low = h
                            }
                            var E = f[0],
                                O = n[0];
                            for (E.high = O.high, E.low = O.low, u = 0; u < 5; u++)
                                for (m = 0; m < 5; m++) {
                                    var _ = n[I = u + 5 * m],
                                        T = f[I],
                                        C = f[(u + 1) % 5 + 5 * m],
                                        R = f[(u + 2) % 5 + 5 * m];
                                    _.high = T.high ^ ~C.high & R.high, _.low = T.low ^ ~C.low & R.low
                                }
                            _ = n[0];
                            var N = c[o];
                            _.high ^= N.high, _.low ^= N.low
                        }
                    },
                    _doFinalize: function() {
                        var t = this._data,
                            n = t.words;
                        this._nDataBytes;
                        var i = 8 * t.sigBytes,
                            s = 32 * this.blockSize;
                        n[i >>> 5] |= 1 << 24 - i % 32, n[(e.ceil((i + 1) / s) * s >>> 5) - 1] |= 128, t.sigBytes = 4 * n.length, this._process();
                        for (var a = this._state, o = this.cfg.outputLength / 8, d = o / 8, l = [], c = 0; c < d; c++) {
                            var f = a[c],
                                u = f.high,
                                p = f.low;
                            u = 16711935 & (u << 8 | u >>> 24) | 4278255360 & (u << 24 | u >>> 8), p = 16711935 & (p << 8 | p >>> 24) | 4278255360 & (p << 24 | p >>> 8), l.push(p), l.push(u)
                        }
                        return new r.init(l, o)
                    },
                    clone: function() {
                        for (var e = s.clone.call(this), t = e._state = this._state.slice(0), n = 0; n < 25; n++) t[n] = t[n].clone();
                        return e
                    }
                });
                t.SHA3 = s._createHelper(u), t.HmacSHA3 = s._createHmacHelper(u)
            }(Math), n.SHA3)
        }(hs)), hs.exports
    }
    var gs, bs = {
        exports: {}
    };
    var ys, ws = {
        exports: {}
    };

    function vs() {
        return ys || (ys = 1, function(e, t) {
            var n, i, r, s;
            e.exports = (n = Br(), r = (i = n).lib.Base, s = i.enc.Utf8, void(i.algo.HMAC = r.extend({
                init: function(e, t) {
                    e = this._hasher = new e.init, "string" == typeof t && (t = s.parse(t));
                    var n = e.blockSize,
                        i = 4 * n;
                    t.sigBytes > i && (t = e.finalize(t)), t.clamp();
                    for (var r = this._oKey = t.clone(), a = this._iKey = t.clone(), o = r.words, d = a.words, l = 0; l < n; l++) o[l] ^= 1549556828, d[l] ^= 909522486;
                    r.sigBytes = a.sigBytes = i, this.reset()
                },
                reset: function() {
                    var e = this._hasher;
                    e.reset(), e.update(this._iKey)
                },
                update: function(e) {
                    return this._hasher.update(e), this
                },
                finalize: function(e) {
                    var t = this._hasher,
                        n = t.finalize(e);
                    return t.reset(), t.finalize(this._oKey.clone().concat(n))
                }
            })))
        }(ws, ws.exports)), ws.exports
    }
    ws.exports;
    var Is, As = {
        exports: {}
    };
    var ks, Ss = {
        exports: {}
    };

    function xs() {
        return ks || (ks = 1, function(e, t) {
            var n, i, r, s, a, o, d, l;
            e.exports = (l = Br(), ns(), vs(), i = (n = l).lib, r = i.Base, s = i.WordArray, a = n.algo, o = a.MD5, d = a.EvpKDF = r.extend({
                cfg: r.extend({
                    keySize: 4,
                    hasher: o,
                    iterations: 1
                }),
                init: function(e) {
                    this.cfg = this.cfg.extend(e)
                },
                compute: function(e, t) {
                    for (var n, i = this.cfg, r = i.hasher.create(), a = s.create(), o = a.words, d = i.keySize, l = i.iterations; o.length < d;) {
                        n && r.update(n), n = r.update(e).finalize(t), r.reset();
                        for (var c = 1; c < l; c++) n = r.finalize(n), r.reset();
                        a.concat(n)
                    }
                    return a.sigBytes = 4 * d, a
                }
            }), n.EvpKDF = function(e, t, n) {
                return d.create(n).compute(e, t)
            }, l.EvpKDF)
        }(Ss, Ss.exports)), Ss.exports
    }
    Ss.exports;
    var Es, Os = {
        exports: {}
    };

    function _s() {
        return Es || (Es = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), xs(), void(n.lib.Cipher || function(e) {
                var t = n,
                    i = t.lib,
                    r = i.Base,
                    s = i.WordArray,
                    a = i.BufferedBlockAlgorithm,
                    o = t.enc;
                o.Utf8;
                var d = o.Base64,
                    l = t.algo.EvpKDF,
                    c = i.Cipher = a.extend({
                        cfg: r.extend(),
                        createEncryptor: function(e, t) {
                            return this.create(this._ENC_XFORM_MODE, e, t)
                        },
                        createDecryptor: function(e, t) {
                            return this.create(this._DEC_XFORM_MODE, e, t)
                        },
                        init: function(e, t, n) {
                            this.cfg = this.cfg.extend(n), this._xformMode = e, this._key = t, this.reset()
                        },
                        reset: function() {
                            a.reset.call(this), this._doReset()
                        },
                        process: function(e) {
                            return this._append(e), this._process()
                        },
                        finalize: function(e) {
                            return e && this._append(e), this._doFinalize()
                        },
                        keySize: 4,
                        ivSize: 4,
                        _ENC_XFORM_MODE: 1,
                        _DEC_XFORM_MODE: 2,
                        _createHelper: function() {
                            function e(e) {
                                return "string" == typeof e ? w : b
                            }
                            return function(t) {
                                return {
                                    encrypt: function(n, i, r) {
                                        return e(i).encrypt(t, n, i, r)
                                    },
                                    decrypt: function(n, i, r) {
                                        return e(i).decrypt(t, n, i, r)
                                    }
                                }
                            }
                        }()
                    });
                i.StreamCipher = c.extend({
                    _doFinalize: function() {
                        return this._process(!0)
                    },
                    blockSize: 1
                });
                var f = t.mode = {},
                    u = i.BlockCipherMode = r.extend({
                        createEncryptor: function(e, t) {
                            return this.Encryptor.create(e, t)
                        },
                        createDecryptor: function(e, t) {
                            return this.Decryptor.create(e, t)
                        },
                        init: function(e, t) {
                            this._cipher = e, this._iv = t
                        }
                    }),
                    p = f.CBC = function() {
                        var t = u.extend();

                        function n(t, n, i) {
                            var r, s = this._iv;
                            s ? (r = s, this._iv = e) : r = this._prevBlock;
                            for (var a = 0; a < i; a++) t[n + a] ^= r[a]
                        }
                        return t.Encryptor = t.extend({
                            processBlock: function(e, t) {
                                var i = this._cipher,
                                    r = i.blockSize;
                                n.call(this, e, t, r), i.encryptBlock(e, t), this._prevBlock = e.slice(t, t + r)
                            }
                        }), t.Decryptor = t.extend({
                            processBlock: function(e, t) {
                                var i = this._cipher,
                                    r = i.blockSize,
                                    s = e.slice(t, t + r);
                                i.decryptBlock(e, t), n.call(this, e, t, r), this._prevBlock = s
                            }
                        }), t
                    }(),
                    h = (t.pad = {}).Pkcs7 = {
                        pad: function(e, t) {
                            for (var n = 4 * t, i = n - e.sigBytes % n, r = i << 24 | i << 16 | i << 8 | i, a = [], o = 0; o < i; o += 4) a.push(r);
                            var d = s.create(a, i);
                            e.concat(d)
                        },
                        unpad: function(e) {
                            var t = 255 & e.words[e.sigBytes - 1 >>> 2];
                            e.sigBytes -= t
                        }
                    };
                i.BlockCipher = c.extend({
                    cfg: c.cfg.extend({
                        mode: p,
                        padding: h
                    }),
                    reset: function() {
                        var e;
                        c.reset.call(this);
                        var t = this.cfg,
                            n = t.iv,
                            i = t.mode;
                        this._xformMode == this._ENC_XFORM_MODE ? e = i.createEncryptor : (e = i.createDecryptor, this._minBufferSize = 1), this._mode && this._mode.__creator == e ? this._mode.init(this, n && n.words) : (this._mode = e.call(i, this, n && n.words), this._mode.__creator = e)
                    },
                    _doProcessBlock: function(e, t) {
                        this._mode.processBlock(e, t)
                    },
                    _doFinalize: function() {
                        var e, t = this.cfg.padding;
                        return this._xformMode == this._ENC_XFORM_MODE ? (t.pad(this._data, this.blockSize), e = this._process(!0)) : (e = this._process(!0), t.unpad(e)), e
                    },
                    blockSize: 4
                });
                var m = i.CipherParams = r.extend({
                        init: function(e) {
                            this.mixIn(e)
                        },
                        toString: function(e) {
                            return (e || this.formatter).stringify(this)
                        }
                    }),
                    g = (t.format = {}).OpenSSL = {
                        stringify: function(e) {
                            var t = e.ciphertext,
                                n = e.salt;
                            return (n ? s.create([1398893684, 1701076831]).concat(n).concat(t) : t).toString(d)
                        },
                        parse: function(e) {
                            var t, n = d.parse(e),
                                i = n.words;
                            return 1398893684 == i[0] && 1701076831 == i[1] && (t = s.create(i.slice(2, 4)), i.splice(0, 4), n.sigBytes -= 16), m.create({
                                ciphertext: n,
                                salt: t
                            })
                        }
                    },
                    b = i.SerializableCipher = r.extend({
                        cfg: r.extend({
                            format: g
                        }),
                        encrypt: function(e, t, n, i) {
                            i = this.cfg.extend(i);
                            var r = e.createEncryptor(n, i),
                                s = r.finalize(t),
                                a = r.cfg;
                            return m.create({
                                ciphertext: s,
                                key: n,
                                iv: a.iv,
                                algorithm: e,
                                mode: a.mode,
                                padding: a.padding,
                                blockSize: e.blockSize,
                                formatter: i.format
                            })
                        },
                        decrypt: function(e, t, n, i) {
                            return i = this.cfg.extend(i), t = this._parse(t, i.format), e.createDecryptor(n, i).finalize(t.ciphertext)
                        },
                        _parse: function(e, t) {
                            return "string" == typeof e ? t.parse(e, this) : e
                        }
                    }),
                    y = (t.kdf = {}).OpenSSL = {
                        execute: function(e, t, n, i) {
                            i || (i = s.random(8));
                            var r = l.create({
                                    keySize: t + n
                                }).compute(e, i),
                                a = s.create(r.words.slice(t), 4 * n);
                            return r.sigBytes = 4 * t, m.create({
                                key: r,
                                iv: a,
                                salt: i
                            })
                        }
                    },
                    w = i.PasswordBasedCipher = b.extend({
                        cfg: b.cfg.extend({
                            kdf: y
                        }),
                        encrypt: function(e, t, n, i) {
                            var r = (i = this.cfg.extend(i)).kdf.execute(n, e.keySize, e.ivSize);
                            i.iv = r.iv;
                            var s = b.encrypt.call(this, e, t, r.key, i);
                            return s.mixIn(r), s
                        },
                        decrypt: function(e, t, n, i) {
                            i = this.cfg.extend(i), t = this._parse(t, i.format);
                            var r = i.kdf.execute(n, e.keySize, e.ivSize, t.salt);
                            return i.iv = r.iv, b.decrypt.call(this, e, t, r.key, i)
                        }
                    })
            }()))
        }(Os, Os.exports)), Os.exports
    }
    Os.exports;
    var Ts, Cs = {
        exports: {}
    };

    function Rs() {
        return Ts || (Ts = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.mode.CFB = function() {
                var e = n.lib.BlockCipherMode.extend();

                function t(e, t, n, i) {
                    var r, s = this._iv;
                    s ? (r = s.slice(0), this._iv = void 0) : r = this._prevBlock, i.encryptBlock(r, 0);
                    for (var a = 0; a < n; a++) e[t + a] ^= r[a]
                }
                return e.Encryptor = e.extend({
                    processBlock: function(e, n) {
                        var i = this._cipher,
                            r = i.blockSize;
                        t.call(this, e, n, r, i), this._prevBlock = e.slice(n, n + r)
                    }
                }), e.Decryptor = e.extend({
                    processBlock: function(e, n) {
                        var i = this._cipher,
                            r = i.blockSize,
                            s = e.slice(n, n + r);
                        t.call(this, e, n, r, i), this._prevBlock = s
                    }
                }), e
            }(), n.mode.CFB)
        }(Cs)), Cs.exports
    }
    var Ns, Ms = {
        exports: {}
    };

    function Ds() {
        return Ns || (Ns = 1, function(e, t) {
            var n, i, r;
            e.exports = (r = Br(), _s(), r.mode.CTR = (n = r.lib.BlockCipherMode.extend(), i = n.Encryptor = n.extend({
                processBlock: function(e, t) {
                    var n = this._cipher,
                        i = n.blockSize,
                        r = this._iv,
                        s = this._counter;
                    r && (s = this._counter = r.slice(0), this._iv = void 0);
                    var a = s.slice(0);
                    n.encryptBlock(a, 0), s[i - 1] = s[i - 1] + 1 | 0;
                    for (var o = 0; o < i; o++) e[t + o] ^= a[o]
                }
            }), n.Decryptor = i, n), r.mode.CTR)
        }(Ms)), Ms.exports
    }
    var Bs, Ps = {
        exports: {}
    };

    function zs() {
        return Bs || (Bs = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.mode.CTRGladman = function() {
                var e = n.lib.BlockCipherMode.extend();

                function t(e) {
                    if (255 == (e >> 24 & 255)) {
                        var t = e >> 16 & 255,
                            n = e >> 8 & 255,
                            i = 255 & e;
                        255 === t ? (t = 0, 255 === n ? (n = 0, 255 === i ? i = 0 : ++i) : ++n) : ++t, e = 0, e += t << 16, e += n << 8, e += i
                    } else e += 1 << 24;
                    return e
                }

                function i(e) {
                    return 0 === (e[0] = t(e[0])) && (e[1] = t(e[1])), e
                }
                var r = e.Encryptor = e.extend({
                    processBlock: function(e, t) {
                        var n = this._cipher,
                            r = n.blockSize,
                            s = this._iv,
                            a = this._counter;
                        s && (a = this._counter = s.slice(0), this._iv = void 0), i(a);
                        var o = a.slice(0);
                        n.encryptBlock(o, 0);
                        for (var d = 0; d < r; d++) e[t + d] ^= o[d]
                    }
                });
                return e.Decryptor = r, e
            }(), n.mode.CTRGladman)
        }(Ps)), Ps.exports
    }
    var Ls, js = {
        exports: {}
    };

    function Fs() {
        return Ls || (Ls = 1, function(e, t) {
            var n, i, r;
            e.exports = (r = Br(), _s(), r.mode.OFB = (n = r.lib.BlockCipherMode.extend(), i = n.Encryptor = n.extend({
                processBlock: function(e, t) {
                    var n = this._cipher,
                        i = n.blockSize,
                        r = this._iv,
                        s = this._keystream;
                    r && (s = this._keystream = r.slice(0), this._iv = void 0), n.encryptBlock(s, 0);
                    for (var a = 0; a < i; a++) e[t + a] ^= s[a]
                }
            }), n.Decryptor = i, n), r.mode.OFB)
        }(js)), js.exports
    }
    var Us, qs = {
        exports: {}
    };
    var $s, Hs = {
        exports: {}
    };
    var Vs, Gs = {
        exports: {}
    };
    var Ws, Qs = {
        exports: {}
    };
    var Ys, Ks = {
        exports: {}
    };
    var Js, Xs = {
        exports: {}
    };
    var Zs, ea = {
        exports: {}
    };
    var ta, na = {
        exports: {}
    };
    var ia, ra = {
        exports: {}
    };

    function sa() {
        return ia || (ia = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Wr(), Zr(), xs(), _s(), function() {
                var e = n,
                    t = e.lib,
                    i = t.WordArray,
                    r = t.BlockCipher,
                    s = e.algo,
                    a = [57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36, 63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4],
                    o = [14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2, 41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32],
                    d = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28],
                    l = [{
                        0: 8421888,
                        268435456: 32768,
                        536870912: 8421378,
                        805306368: 2,
                        1073741824: 512,
                        1342177280: 8421890,
                        1610612736: 8389122,
                        1879048192: 8388608,
                        2147483648: 514,
                        2415919104: 8389120,
                        2684354560: 33280,
                        2952790016: 8421376,
                        3221225472: 32770,
                        3489660928: 8388610,
                        3758096384: 0,
                        4026531840: 33282,
                        134217728: 0,
                        402653184: 8421890,
                        671088640: 33282,
                        939524096: 32768,
                        1207959552: 8421888,
                        1476395008: 512,
                        1744830464: 8421378,
                        2013265920: 2,
                        2281701376: 8389120,
                        2550136832: 33280,
                        2818572288: 8421376,
                        3087007744: 8389122,
                        3355443200: 8388610,
                        3623878656: 32770,
                        3892314112: 514,
                        4160749568: 8388608,
                        1: 32768,
                        268435457: 2,
                        536870913: 8421888,
                        805306369: 8388608,
                        1073741825: 8421378,
                        1342177281: 33280,
                        1610612737: 512,
                        1879048193: 8389122,
                        2147483649: 8421890,
                        2415919105: 8421376,
                        2684354561: 8388610,
                        2952790017: 33282,
                        3221225473: 514,
                        3489660929: 8389120,
                        3758096385: 32770,
                        4026531841: 0,
                        134217729: 8421890,
                        402653185: 8421376,
                        671088641: 8388608,
                        939524097: 512,
                        1207959553: 32768,
                        1476395009: 8388610,
                        1744830465: 2,
                        2013265921: 33282,
                        2281701377: 32770,
                        2550136833: 8389122,
                        2818572289: 514,
                        3087007745: 8421888,
                        3355443201: 8389120,
                        3623878657: 0,
                        3892314113: 33280,
                        4160749569: 8421378
                    }, {
                        0: 1074282512,
                        16777216: 16384,
                        33554432: 524288,
                        50331648: 1074266128,
                        67108864: 1073741840,
                        83886080: 1074282496,
                        100663296: 1073758208,
                        117440512: 16,
                        134217728: 540672,
                        150994944: 1073758224,
                        167772160: 1073741824,
                        184549376: 540688,
                        201326592: 524304,
                        218103808: 0,
                        234881024: 16400,
                        251658240: 1074266112,
                        8388608: 1073758208,
                        25165824: 540688,
                        41943040: 16,
                        58720256: 1073758224,
                        75497472: 1074282512,
                        92274688: 1073741824,
                        109051904: 524288,
                        125829120: 1074266128,
                        142606336: 524304,
                        159383552: 0,
                        176160768: 16384,
                        192937984: 1074266112,
                        209715200: 1073741840,
                        226492416: 540672,
                        243269632: 1074282496,
                        260046848: 16400,
                        268435456: 0,
                        285212672: 1074266128,
                        301989888: 1073758224,
                        318767104: 1074282496,
                        335544320: 1074266112,
                        352321536: 16,
                        369098752: 540688,
                        385875968: 16384,
                        402653184: 16400,
                        419430400: 524288,
                        436207616: 524304,
                        452984832: 1073741840,
                        469762048: 540672,
                        486539264: 1073758208,
                        503316480: 1073741824,
                        520093696: 1074282512,
                        276824064: 540688,
                        293601280: 524288,
                        310378496: 1074266112,
                        327155712: 16384,
                        343932928: 1073758208,
                        360710144: 1074282512,
                        377487360: 16,
                        394264576: 1073741824,
                        411041792: 1074282496,
                        427819008: 1073741840,
                        444596224: 1073758224,
                        461373440: 524304,
                        478150656: 0,
                        494927872: 16400,
                        511705088: 1074266128,
                        528482304: 540672
                    }, {
                        0: 260,
                        1048576: 0,
                        2097152: 67109120,
                        3145728: 65796,
                        4194304: 65540,
                        5242880: 67108868,
                        6291456: 67174660,
                        7340032: 67174400,
                        8388608: 67108864,
                        9437184: 67174656,
                        10485760: 65792,
                        11534336: 67174404,
                        12582912: 67109124,
                        13631488: 65536,
                        14680064: 4,
                        15728640: 256,
                        524288: 67174656,
                        1572864: 67174404,
                        2621440: 0,
                        3670016: 67109120,
                        4718592: 67108868,
                        5767168: 65536,
                        6815744: 65540,
                        7864320: 260,
                        8912896: 4,
                        9961472: 256,
                        11010048: 67174400,
                        12058624: 65796,
                        13107200: 65792,
                        14155776: 67109124,
                        15204352: 67174660,
                        16252928: 67108864,
                        16777216: 67174656,
                        17825792: 65540,
                        18874368: 65536,
                        19922944: 67109120,
                        20971520: 256,
                        22020096: 67174660,
                        23068672: 67108868,
                        24117248: 0,
                        25165824: 67109124,
                        26214400: 67108864,
                        27262976: 4,
                        28311552: 65792,
                        29360128: 67174400,
                        30408704: 260,
                        31457280: 65796,
                        32505856: 67174404,
                        17301504: 67108864,
                        18350080: 260,
                        19398656: 67174656,
                        20447232: 0,
                        21495808: 65540,
                        22544384: 67109120,
                        23592960: 256,
                        24641536: 67174404,
                        25690112: 65536,
                        26738688: 67174660,
                        27787264: 65796,
                        28835840: 67108868,
                        29884416: 67109124,
                        30932992: 67174400,
                        31981568: 4,
                        33030144: 65792
                    }, {
                        0: 2151682048,
                        65536: 2147487808,
                        131072: 4198464,
                        196608: 2151677952,
                        262144: 0,
                        327680: 4198400,
                        393216: 2147483712,
                        458752: 4194368,
                        524288: 2147483648,
                        589824: 4194304,
                        655360: 64,
                        720896: 2147487744,
                        786432: 2151678016,
                        851968: 4160,
                        917504: 4096,
                        983040: 2151682112,
                        32768: 2147487808,
                        98304: 64,
                        163840: 2151678016,
                        229376: 2147487744,
                        294912: 4198400,
                        360448: 2151682112,
                        425984: 0,
                        491520: 2151677952,
                        557056: 4096,
                        622592: 2151682048,
                        688128: 4194304,
                        753664: 4160,
                        819200: 2147483648,
                        884736: 4194368,
                        950272: 4198464,
                        1015808: 2147483712,
                        1048576: 4194368,
                        1114112: 4198400,
                        1179648: 2147483712,
                        1245184: 0,
                        1310720: 4160,
                        1376256: 2151678016,
                        1441792: 2151682048,
                        1507328: 2147487808,
                        1572864: 2151682112,
                        1638400: 2147483648,
                        1703936: 2151677952,
                        1769472: 4198464,
                        1835008: 2147487744,
                        1900544: 4194304,
                        1966080: 64,
                        2031616: 4096,
                        1081344: 2151677952,
                        1146880: 2151682112,
                        1212416: 0,
                        1277952: 4198400,
                        1343488: 4194368,
                        1409024: 2147483648,
                        1474560: 2147487808,
                        1540096: 64,
                        1605632: 2147483712,
                        1671168: 4096,
                        1736704: 2147487744,
                        1802240: 2151678016,
                        1867776: 4160,
                        1933312: 2151682048,
                        1998848: 4194304,
                        2064384: 4198464
                    }, {
                        0: 128,
                        4096: 17039360,
                        8192: 262144,
                        12288: 536870912,
                        16384: 537133184,
                        20480: 16777344,
                        24576: 553648256,
                        28672: 262272,
                        32768: 16777216,
                        36864: 537133056,
                        40960: 536871040,
                        45056: 553910400,
                        49152: 553910272,
                        53248: 0,
                        57344: 17039488,
                        61440: 553648128,
                        2048: 17039488,
                        6144: 553648256,
                        10240: 128,
                        14336: 17039360,
                        18432: 262144,
                        22528: 537133184,
                        26624: 553910272,
                        30720: 536870912,
                        34816: 537133056,
                        38912: 0,
                        43008: 553910400,
                        47104: 16777344,
                        51200: 536871040,
                        55296: 553648128,
                        59392: 16777216,
                        63488: 262272,
                        65536: 262144,
                        69632: 128,
                        73728: 536870912,
                        77824: 553648256,
                        81920: 16777344,
                        86016: 553910272,
                        90112: 537133184,
                        94208: 16777216,
                        98304: 553910400,
                        102400: 553648128,
                        106496: 17039360,
                        110592: 537133056,
                        114688: 262272,
                        118784: 536871040,
                        122880: 0,
                        126976: 17039488,
                        67584: 553648256,
                        71680: 16777216,
                        75776: 17039360,
                        79872: 537133184,
                        83968: 536870912,
                        88064: 17039488,
                        92160: 128,
                        96256: 553910272,
                        100352: 262272,
                        104448: 553910400,
                        108544: 0,
                        112640: 553648128,
                        116736: 16777344,
                        120832: 262144,
                        124928: 537133056,
                        129024: 536871040
                    }, {
                        0: 268435464,
                        256: 8192,
                        512: 270532608,
                        768: 270540808,
                        1024: 268443648,
                        1280: 2097152,
                        1536: 2097160,
                        1792: 268435456,
                        2048: 0,
                        2304: 268443656,
                        2560: 2105344,
                        2816: 8,
                        3072: 270532616,
                        3328: 2105352,
                        3584: 8200,
                        3840: 270540800,
                        128: 270532608,
                        384: 270540808,
                        640: 8,
                        896: 2097152,
                        1152: 2105352,
                        1408: 268435464,
                        1664: 268443648,
                        1920: 8200,
                        2176: 2097160,
                        2432: 8192,
                        2688: 268443656,
                        2944: 270532616,
                        3200: 0,
                        3456: 270540800,
                        3712: 2105344,
                        3968: 268435456,
                        4096: 268443648,
                        4352: 270532616,
                        4608: 270540808,
                        4864: 8200,
                        5120: 2097152,
                        5376: 268435456,
                        5632: 268435464,
                        5888: 2105344,
                        6144: 2105352,
                        6400: 0,
                        6656: 8,
                        6912: 270532608,
                        7168: 8192,
                        7424: 268443656,
                        7680: 270540800,
                        7936: 2097160,
                        4224: 8,
                        4480: 2105344,
                        4736: 2097152,
                        4992: 268435464,
                        5248: 268443648,
                        5504: 8200,
                        5760: 270540808,
                        6016: 270532608,
                        6272: 270540800,
                        6528: 270532616,
                        6784: 8192,
                        7040: 2105352,
                        7296: 2097160,
                        7552: 0,
                        7808: 268435456,
                        8064: 268443656
                    }, {
                        0: 1048576,
                        16: 33555457,
                        32: 1024,
                        48: 1049601,
                        64: 34604033,
                        80: 0,
                        96: 1,
                        112: 34603009,
                        128: 33555456,
                        144: 1048577,
                        160: 33554433,
                        176: 34604032,
                        192: 34603008,
                        208: 1025,
                        224: 1049600,
                        240: 33554432,
                        8: 34603009,
                        24: 0,
                        40: 33555457,
                        56: 34604032,
                        72: 1048576,
                        88: 33554433,
                        104: 33554432,
                        120: 1025,
                        136: 1049601,
                        152: 33555456,
                        168: 34603008,
                        184: 1048577,
                        200: 1024,
                        216: 34604033,
                        232: 1,
                        248: 1049600,
                        256: 33554432,
                        272: 1048576,
                        288: 33555457,
                        304: 34603009,
                        320: 1048577,
                        336: 33555456,
                        352: 34604032,
                        368: 1049601,
                        384: 1025,
                        400: 34604033,
                        416: 1049600,
                        432: 1,
                        448: 0,
                        464: 34603008,
                        480: 33554433,
                        496: 1024,
                        264: 1049600,
                        280: 33555457,
                        296: 34603009,
                        312: 1,
                        328: 33554432,
                        344: 1048576,
                        360: 1025,
                        376: 34604032,
                        392: 33554433,
                        408: 34603008,
                        424: 0,
                        440: 34604033,
                        456: 1049601,
                        472: 1024,
                        488: 33555456,
                        504: 1048577
                    }, {
                        0: 134219808,
                        1: 131072,
                        2: 134217728,
                        3: 32,
                        4: 131104,
                        5: 134350880,
                        6: 134350848,
                        7: 2048,
                        8: 134348800,
                        9: 134219776,
                        10: 133120,
                        11: 134348832,
                        12: 2080,
                        13: 0,
                        14: 134217760,
                        15: 133152,
                        2147483648: 2048,
                        2147483649: 134350880,
                        2147483650: 134219808,
                        2147483651: 134217728,
                        2147483652: 134348800,
                        2147483653: 133120,
                        2147483654: 133152,
                        2147483655: 32,
                        2147483656: 134217760,
                        2147483657: 2080,
                        2147483658: 131104,
                        2147483659: 134350848,
                        2147483660: 0,
                        2147483661: 134348832,
                        2147483662: 134219776,
                        2147483663: 131072,
                        16: 133152,
                        17: 134350848,
                        18: 32,
                        19: 2048,
                        20: 134219776,
                        21: 134217760,
                        22: 134348832,
                        23: 131072,
                        24: 0,
                        25: 131104,
                        26: 134348800,
                        27: 134219808,
                        28: 134350880,
                        29: 133120,
                        30: 2080,
                        31: 134217728,
                        2147483664: 131072,
                        2147483665: 2048,
                        2147483666: 134348832,
                        2147483667: 133152,
                        2147483668: 32,
                        2147483669: 134348800,
                        2147483670: 134217728,
                        2147483671: 134219808,
                        2147483672: 134350880,
                        2147483673: 134217760,
                        2147483674: 134219776,
                        2147483675: 0,
                        2147483676: 133120,
                        2147483677: 2080,
                        2147483678: 131104,
                        2147483679: 134350848
                    }],
                    c = [4160749569, 528482304, 33030144, 2064384, 129024, 8064, 504, 2147483679],
                    f = s.DES = r.extend({
                        _doReset: function() {
                            for (var e = this._key.words, t = [], n = 0; n < 56; n++) {
                                var i = a[n] - 1;
                                t[n] = e[i >>> 5] >>> 31 - i % 32 & 1
                            }
                            for (var r = this._subKeys = [], s = 0; s < 16; s++) {
                                var l = r[s] = [],
                                    c = d[s];
                                for (n = 0; n < 24; n++) l[n / 6 | 0] |= t[(o[n] - 1 + c) % 28] << 31 - n % 6, l[4 + (n / 6 | 0)] |= t[28 + (o[n + 24] - 1 + c) % 28] << 31 - n % 6;
                                for (l[0] = l[0] << 1 | l[0] >>> 31, n = 1; n < 7; n++) l[n] = l[n] >>> 4 * (n - 1) + 3;
                                l[7] = l[7] << 5 | l[7] >>> 27
                            }
                            var f = this._invSubKeys = [];
                            for (n = 0; n < 16; n++) f[n] = r[15 - n]
                        },
                        encryptBlock: function(e, t) {
                            this._doCryptBlock(e, t, this._subKeys)
                        },
                        decryptBlock: function(e, t) {
                            this._doCryptBlock(e, t, this._invSubKeys)
                        },
                        _doCryptBlock: function(e, t, n) {
                            this._lBlock = e[t], this._rBlock = e[t + 1], u.call(this, 4, 252645135), u.call(this, 16, 65535), p.call(this, 2, 858993459), p.call(this, 8, 16711935), u.call(this, 1, 1431655765);
                            for (var i = 0; i < 16; i++) {
                                for (var r = n[i], s = this._lBlock, a = this._rBlock, o = 0, d = 0; d < 8; d++) o |= l[d][((a ^ r[d]) & c[d]) >>> 0];
                                this._lBlock = a, this._rBlock = s ^ o
                            }
                            var f = this._lBlock;
                            this._lBlock = this._rBlock, this._rBlock = f, u.call(this, 1, 1431655765), p.call(this, 8, 16711935), p.call(this, 2, 858993459), u.call(this, 16, 65535), u.call(this, 4, 252645135), e[t] = this._lBlock, e[t + 1] = this._rBlock
                        },
                        keySize: 2,
                        ivSize: 2,
                        blockSize: 2
                    });

                function u(e, t) {
                    var n = (this._lBlock >>> e ^ this._rBlock) & t;
                    this._rBlock ^= n, this._lBlock ^= n << e
                }

                function p(e, t) {
                    var n = (this._rBlock >>> e ^ this._lBlock) & t;
                    this._lBlock ^= n, this._rBlock ^= n << e
                }
                e.DES = r._createHelper(f);
                var h = s.TripleDES = r.extend({
                    _doReset: function() {
                        var e = this._key.words;
                        if (2 !== e.length && 4 !== e.length && e.length < 6) throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");
                        var t = e.slice(0, 2),
                            n = e.length < 4 ? e.slice(0, 2) : e.slice(2, 4),
                            r = e.length < 6 ? e.slice(0, 2) : e.slice(4, 6);
                        this._des1 = f.createEncryptor(i.create(t)), this._des2 = f.createEncryptor(i.create(n)), this._des3 = f.createEncryptor(i.create(r))
                    },
                    encryptBlock: function(e, t) {
                        this._des1.encryptBlock(e, t), this._des2.decryptBlock(e, t), this._des3.encryptBlock(e, t)
                    },
                    decryptBlock: function(e, t) {
                        this._des3.decryptBlock(e, t), this._des2.encryptBlock(e, t), this._des1.decryptBlock(e, t)
                    },
                    keySize: 6,
                    ivSize: 2,
                    blockSize: 2
                });
                e.TripleDES = r._createHelper(h)
            }(), n.TripleDES)
        }(ra)), ra.exports
    }
    var aa, oa = {
        exports: {}
    };
    var da, la = {
        exports: {}
    };
    var ca, fa = {
        exports: {}
    };
    ! function(e, t) {
        var n;
        e.exports = (n = Br(), Lr(), Ur(), Hr(), Wr(), Kr(), Zr(), ns(), ss(), as || (as = 1, function(e, t) {
            var n, i, r, s, a, o;
            e.exports = (o = Br(), ss(), i = (n = o).lib.WordArray, r = n.algo, s = r.SHA256, a = r.SHA224 = s.extend({
                _doReset: function() {
                    this._hash = new i.init([3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428])
                },
                _doFinalize: function() {
                    var e = s._doFinalize.call(this);
                    return e.sigBytes -= 4, e
                }
            }), n.SHA224 = s._createHelper(a), n.HmacSHA224 = s._createHmacHelper(a), o.SHA224)
        }(os)), cs(), fs || (fs = 1, function(e, t) {
            var n, i, r, s, a, o, d, l;
            e.exports = (l = Br(), Lr(), cs(), i = (n = l).x64, r = i.Word, s = i.WordArray, a = n.algo, o = a.SHA512, d = a.SHA384 = o.extend({
                _doReset: function() {
                    this._hash = new s.init([new r.init(3418070365, 3238371032), new r.init(1654270250, 914150663), new r.init(2438529370, 812702999), new r.init(355462360, 4144912697), new r.init(1731405415, 4290775857), new r.init(2394180231, 1750603025), new r.init(3675008525, 1694076839), new r.init(1203062813, 3204075428)])
                },
                _doFinalize: function() {
                    var e = o._doFinalize.call(this);
                    return e.sigBytes -= 16, e
                }
            }), n.SHA384 = o._createHelper(d), n.HmacSHA384 = o._createHmacHelper(d), l.SHA384)
        }(us)), ms(), gs || (gs = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), function(e) {
                var t = n,
                    i = t.lib,
                    r = i.WordArray,
                    s = i.Hasher,
                    a = t.algo,
                    o = r.create([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13]),
                    d = r.create([5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11]),
                    l = r.create([11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6]),
                    c = r.create([8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11]),
                    f = r.create([0, 1518500249, 1859775393, 2400959708, 2840853838]),
                    u = r.create([1352829926, 1548603684, 1836072691, 2053994217, 0]),
                    p = a.RIPEMD160 = s.extend({
                        _doReset: function() {
                            this._hash = r.create([1732584193, 4023233417, 2562383102, 271733878, 3285377520])
                        },
                        _doProcessBlock: function(e, t) {
                            for (var n = 0; n < 16; n++) {
                                var i = t + n,
                                    r = e[i];
                                e[i] = 16711935 & (r << 8 | r >>> 24) | 4278255360 & (r << 24 | r >>> 8)
                            }
                            var s, a, p, v, I, A, k, S, x, E, O, _ = this._hash.words,
                                T = f.words,
                                C = u.words,
                                R = o.words,
                                N = d.words,
                                M = l.words,
                                D = c.words;
                            for (A = s = _[0], k = a = _[1], S = p = _[2], x = v = _[3], E = I = _[4], n = 0; n < 80; n += 1) O = s + e[t + R[n]] | 0, O += n < 16 ? h(a, p, v) + T[0] : n < 32 ? m(a, p, v) + T[1] : n < 48 ? g(a, p, v) + T[2] : n < 64 ? b(a, p, v) + T[3] : y(a, p, v) + T[4], O = (O = w(O |= 0, M[n])) + I | 0, s = I, I = v, v = w(p, 10), p = a, a = O, O = A + e[t + N[n]] | 0, O += n < 16 ? y(k, S, x) + C[0] : n < 32 ? b(k, S, x) + C[1] : n < 48 ? g(k, S, x) + C[2] : n < 64 ? m(k, S, x) + C[3] : h(k, S, x) + C[4], O = (O = w(O |= 0, D[n])) + E | 0, A = E, E = x, x = w(S, 10), S = k, k = O;
                            O = _[1] + p + x | 0, _[1] = _[2] + v + E | 0, _[2] = _[3] + I + A | 0, _[3] = _[4] + s + k | 0, _[4] = _[0] + a + S | 0, _[0] = O
                        },
                        _doFinalize: function() {
                            var e = this._data,
                                t = e.words,
                                n = 8 * this._nDataBytes,
                                i = 8 * e.sigBytes;
                            t[i >>> 5] |= 128 << 24 - i % 32, t[14 + (i + 64 >>> 9 << 4)] = 16711935 & (n << 8 | n >>> 24) | 4278255360 & (n << 24 | n >>> 8), e.sigBytes = 4 * (t.length + 1), this._process();
                            for (var r = this._hash, s = r.words, a = 0; a < 5; a++) {
                                var o = s[a];
                                s[a] = 16711935 & (o << 8 | o >>> 24) | 4278255360 & (o << 24 | o >>> 8)
                            }
                            return r
                        },
                        clone: function() {
                            var e = s.clone.call(this);
                            return e._hash = this._hash.clone(), e
                        }
                    });

                function h(e, t, n) {
                    return e ^ t ^ n
                }

                function m(e, t, n) {
                    return e & t | ~e & n
                }

                function g(e, t, n) {
                    return (e | ~t) ^ n
                }

                function b(e, t, n) {
                    return e & n | t & ~n
                }

                function y(e, t, n) {
                    return e ^ (t | ~n)
                }

                function w(e, t) {
                    return e << t | e >>> 32 - t
                }
                t.RIPEMD160 = s._createHelper(p), t.HmacRIPEMD160 = s._createHmacHelper(p)
            }(), n.RIPEMD160)
        }(bs)), vs(), Is || (Is = 1, function(e, t) {
            var n, i, r, s, a, o, d, l, c;
            e.exports = (c = Br(), ns(), vs(), r = (i = (n = c).lib).Base, s = i.WordArray, o = (a = n.algo).SHA1, d = a.HMAC, l = a.PBKDF2 = r.extend({
                cfg: r.extend({
                    keySize: 4,
                    hasher: o,
                    iterations: 1
                }),
                init: function(e) {
                    this.cfg = this.cfg.extend(e)
                },
                compute: function(e, t) {
                    for (var n = this.cfg, i = d.create(n.hasher, e), r = s.create(), a = s.create([1]), o = r.words, l = a.words, c = n.keySize, f = n.iterations; o.length < c;) {
                        var u = i.update(t).finalize(a);
                        i.reset();
                        for (var p = u.words, h = p.length, m = u, g = 1; g < f; g++) {
                            m = i.finalize(m), i.reset();
                            for (var b = m.words, y = 0; y < h; y++) p[y] ^= b[y]
                        }
                        r.concat(u), l[0]++
                    }
                    return r.sigBytes = 4 * c, r
                }
            }), n.PBKDF2 = function(e, t, n) {
                return l.create(n).compute(e, t)
            }, c.PBKDF2)
        }(As)), xs(), _s(), Rs(), Ds(), zs(), Fs(), Us || (Us = 1, function(e, t) {
            var n, i;
            e.exports = (i = Br(), _s(), i.mode.ECB = ((n = i.lib.BlockCipherMode.extend()).Encryptor = n.extend({
                processBlock: function(e, t) {
                    this._cipher.encryptBlock(e, t)
                }
            }), n.Decryptor = n.extend({
                processBlock: function(e, t) {
                    this._cipher.decryptBlock(e, t)
                }
            }), n), i.mode.ECB)
        }(qs)), $s || ($s = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.pad.AnsiX923 = {
                pad: function(e, t) {
                    var n = e.sigBytes,
                        i = 4 * t,
                        r = i - n % i,
                        s = n + r - 1;
                    e.clamp(), e.words[s >>> 2] |= r << 24 - s % 4 * 8, e.sigBytes += r
                },
                unpad: function(e) {
                    var t = 255 & e.words[e.sigBytes - 1 >>> 2];
                    e.sigBytes -= t
                }
            }, n.pad.Ansix923)
        }(Hs)), Vs || (Vs = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.pad.Iso10126 = {
                pad: function(e, t) {
                    var i = 4 * t,
                        r = i - e.sigBytes % i;
                    e.concat(n.lib.WordArray.random(r - 1)).concat(n.lib.WordArray.create([r << 24], 1))
                },
                unpad: function(e) {
                    var t = 255 & e.words[e.sigBytes - 1 >>> 2];
                    e.sigBytes -= t
                }
            }, n.pad.Iso10126)
        }(Gs)), Ws || (Ws = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.pad.Iso97971 = {
                pad: function(e, t) {
                    e.concat(n.lib.WordArray.create([2147483648], 1)), n.pad.ZeroPadding.pad(e, t)
                },
                unpad: function(e) {
                    n.pad.ZeroPadding.unpad(e), e.sigBytes--
                }
            }, n.pad.Iso97971)
        }(Qs)), Ys || (Ys = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.pad.ZeroPadding = {
                pad: function(e, t) {
                    var n = 4 * t;
                    e.clamp(), e.sigBytes += n - (e.sigBytes % n || n)
                },
                unpad: function(e) {
                    var t = e.words,
                        n = e.sigBytes - 1;
                    for (n = e.sigBytes - 1; n >= 0; n--)
                        if (t[n >>> 2] >>> 24 - n % 4 * 8 & 255) {
                            e.sigBytes = n + 1;
                            break
                        }
                }
            }, n.pad.ZeroPadding)
        }(Ks)), Js || (Js = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), _s(), n.pad.NoPadding = {
                pad: function() {},
                unpad: function() {}
            }, n.pad.NoPadding)
        }(Xs)), Zs || (Zs = 1, function(e, t) {
            var n, i, r, s;
            e.exports = (s = Br(), _s(), i = (n = s).lib.CipherParams, r = n.enc.Hex, n.format.Hex = {
                stringify: function(e) {
                    return e.ciphertext.toString(r)
                },
                parse: function(e) {
                    var t = r.parse(e);
                    return i.create({
                        ciphertext: t
                    })
                }
            }, s.format.Hex)
        }(ea)), ta || (ta = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Wr(), Zr(), xs(), _s(), function() {
                var e = n,
                    t = e.lib.BlockCipher,
                    i = e.algo,
                    r = [],
                    s = [],
                    a = [],
                    o = [],
                    d = [],
                    l = [],
                    c = [],
                    f = [],
                    u = [],
                    p = [];
                ! function() {
                    for (var e = [], t = 0; t < 256; t++) e[t] = t < 128 ? t << 1 : t << 1 ^ 283;
                    var n = 0,
                        i = 0;
                    for (t = 0; t < 256; t++) {
                        var h = i ^ i << 1 ^ i << 2 ^ i << 3 ^ i << 4;
                        h = h >>> 8 ^ 255 & h ^ 99, r[n] = h, s[h] = n;
                        var m = e[n],
                            g = e[m],
                            b = e[g],
                            y = 257 * e[h] ^ 16843008 * h;
                        a[n] = y << 24 | y >>> 8, o[n] = y << 16 | y >>> 16, d[n] = y << 8 | y >>> 24, l[n] = y, y = 16843009 * b ^ 65537 * g ^ 257 * m ^ 16843008 * n, c[h] = y << 24 | y >>> 8, f[h] = y << 16 | y >>> 16, u[h] = y << 8 | y >>> 24, p[h] = y, n ? (n = m ^ e[e[e[b ^ m]]], i ^= e[e[i]]) : n = i = 1
                    }
                }();
                var h = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54],
                    m = i.AES = t.extend({
                        _doReset: function() {
                            if (!this._nRounds || this._keyPriorReset !== this._key) {
                                for (var e = this._keyPriorReset = this._key, t = e.words, n = e.sigBytes / 4, i = 4 * ((this._nRounds = n + 6) + 1), s = this._keySchedule = [], a = 0; a < i; a++) a < n ? s[a] = t[a] : (l = s[a - 1], a % n ? n > 6 && a % n == 4 && (l = r[l >>> 24] << 24 | r[l >>> 16 & 255] << 16 | r[l >>> 8 & 255] << 8 | r[255 & l]) : (l = r[(l = l << 8 | l >>> 24) >>> 24] << 24 | r[l >>> 16 & 255] << 16 | r[l >>> 8 & 255] << 8 | r[255 & l], l ^= h[a / n | 0] << 24), s[a] = s[a - n] ^ l);
                                for (var o = this._invKeySchedule = [], d = 0; d < i; d++) {
                                    if (a = i - d, d % 4) var l = s[a];
                                    else l = s[a - 4];
                                    o[d] = d < 4 || a <= 4 ? l : c[r[l >>> 24]] ^ f[r[l >>> 16 & 255]] ^ u[r[l >>> 8 & 255]] ^ p[r[255 & l]]
                                }
                            }
                        },
                        encryptBlock: function(e, t) {
                            this._doCryptBlock(e, t, this._keySchedule, a, o, d, l, r)
                        },
                        decryptBlock: function(e, t) {
                            var n = e[t + 1];
                            e[t + 1] = e[t + 3], e[t + 3] = n, this._doCryptBlock(e, t, this._invKeySchedule, c, f, u, p, s), n = e[t + 1], e[t + 1] = e[t + 3], e[t + 3] = n
                        },
                        _doCryptBlock: function(e, t, n, i, r, s, a, o) {
                            for (var d = this._nRounds, l = e[t] ^ n[0], c = e[t + 1] ^ n[1], f = e[t + 2] ^ n[2], u = e[t + 3] ^ n[3], p = 4, h = 1; h < d; h++) {
                                var m = i[l >>> 24] ^ r[c >>> 16 & 255] ^ s[f >>> 8 & 255] ^ a[255 & u] ^ n[p++],
                                    g = i[c >>> 24] ^ r[f >>> 16 & 255] ^ s[u >>> 8 & 255] ^ a[255 & l] ^ n[p++],
                                    b = i[f >>> 24] ^ r[u >>> 16 & 255] ^ s[l >>> 8 & 255] ^ a[255 & c] ^ n[p++],
                                    y = i[u >>> 24] ^ r[l >>> 16 & 255] ^ s[c >>> 8 & 255] ^ a[255 & f] ^ n[p++];
                                l = m, c = g, f = b, u = y
                            }
                            m = (o[l >>> 24] << 24 | o[c >>> 16 & 255] << 16 | o[f >>> 8 & 255] << 8 | o[255 & u]) ^ n[p++], g = (o[c >>> 24] << 24 | o[f >>> 16 & 255] << 16 | o[u >>> 8 & 255] << 8 | o[255 & l]) ^ n[p++], b = (o[f >>> 24] << 24 | o[u >>> 16 & 255] << 16 | o[l >>> 8 & 255] << 8 | o[255 & c]) ^ n[p++], y = (o[u >>> 24] << 24 | o[l >>> 16 & 255] << 16 | o[c >>> 8 & 255] << 8 | o[255 & f]) ^ n[p++], e[t] = m, e[t + 1] = g, e[t + 2] = b, e[t + 3] = y
                        },
                        keySize: 8
                    });
                e.AES = t._createHelper(m)
            }(), n.AES)
        }(na)), sa(), aa || (aa = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Wr(), Zr(), xs(), _s(), function() {
                var e = n,
                    t = e.lib.StreamCipher,
                    i = e.algo,
                    r = i.RC4 = t.extend({
                        _doReset: function() {
                            for (var e = this._key, t = e.words, n = e.sigBytes, i = this._S = [], r = 0; r < 256; r++) i[r] = r;
                            r = 0;
                            for (var s = 0; r < 256; r++) {
                                var a = r % n,
                                    o = t[a >>> 2] >>> 24 - a % 4 * 8 & 255;
                                s = (s + i[r] + o) % 256;
                                var d = i[r];
                                i[r] = i[s], i[s] = d
                            }
                            this._i = this._j = 0
                        },
                        _doProcessBlock: function(e, t) {
                            e[t] ^= s.call(this)
                        },
                        keySize: 8,
                        ivSize: 0
                    });

                function s() {
                    for (var e = this._S, t = this._i, n = this._j, i = 0, r = 0; r < 4; r++) {
                        n = (n + e[t = (t + 1) % 256]) % 256;
                        var s = e[t];
                        e[t] = e[n], e[n] = s, i |= e[(e[t] + e[n]) % 256] << 24 - 8 * r
                    }
                    return this._i = t, this._j = n, i
                }
                e.RC4 = t._createHelper(r);
                var a = i.RC4Drop = r.extend({
                    cfg: r.cfg.extend({
                        drop: 192
                    }),
                    _doReset: function() {
                        r._doReset.call(this);
                        for (var e = this.cfg.drop; e > 0; e--) s.call(this)
                    }
                });
                e.RC4Drop = t._createHelper(a)
            }(), n.RC4)
        }(oa)), da || (da = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Wr(), Zr(), xs(), _s(), function() {
                var e = n,
                    t = e.lib.StreamCipher,
                    i = e.algo,
                    r = [],
                    s = [],
                    a = [],
                    o = i.Rabbit = t.extend({
                        _doReset: function() {
                            for (var e = this._key.words, t = this.cfg.iv, n = 0; n < 4; n++) e[n] = 16711935 & (e[n] << 8 | e[n] >>> 24) | 4278255360 & (e[n] << 24 | e[n] >>> 8);
                            var i = this._X = [e[0], e[3] << 16 | e[2] >>> 16, e[1], e[0] << 16 | e[3] >>> 16, e[2], e[1] << 16 | e[0] >>> 16, e[3], e[2] << 16 | e[1] >>> 16],
                                r = this._C = [e[2] << 16 | e[2] >>> 16, 4294901760 & e[0] | 65535 & e[1], e[3] << 16 | e[3] >>> 16, 4294901760 & e[1] | 65535 & e[2], e[0] << 16 | e[0] >>> 16, 4294901760 & e[2] | 65535 & e[3], e[1] << 16 | e[1] >>> 16, 4294901760 & e[3] | 65535 & e[0]];
                            for (this._b = 0, n = 0; n < 4; n++) d.call(this);
                            for (n = 0; n < 8; n++) r[n] ^= i[n + 4 & 7];
                            if (t) {
                                var s = t.words,
                                    a = s[0],
                                    o = s[1],
                                    l = 16711935 & (a << 8 | a >>> 24) | 4278255360 & (a << 24 | a >>> 8),
                                    c = 16711935 & (o << 8 | o >>> 24) | 4278255360 & (o << 24 | o >>> 8),
                                    f = l >>> 16 | 4294901760 & c,
                                    u = c << 16 | 65535 & l;
                                for (r[0] ^= l, r[1] ^= f, r[2] ^= c, r[3] ^= u, r[4] ^= l, r[5] ^= f, r[6] ^= c, r[7] ^= u, n = 0; n < 4; n++) d.call(this)
                            }
                        },
                        _doProcessBlock: function(e, t) {
                            var n = this._X;
                            d.call(this), r[0] = n[0] ^ n[5] >>> 16 ^ n[3] << 16, r[1] = n[2] ^ n[7] >>> 16 ^ n[5] << 16, r[2] = n[4] ^ n[1] >>> 16 ^ n[7] << 16, r[3] = n[6] ^ n[3] >>> 16 ^ n[1] << 16;
                            for (var i = 0; i < 4; i++) r[i] = 16711935 & (r[i] << 8 | r[i] >>> 24) | 4278255360 & (r[i] << 24 | r[i] >>> 8), e[t + i] ^= r[i]
                        },
                        blockSize: 4,
                        ivSize: 2
                    });

                function d() {
                    for (var e = this._X, t = this._C, n = 0; n < 8; n++) s[n] = t[n];
                    for (t[0] = t[0] + 1295307597 + this._b | 0, t[1] = t[1] + 3545052371 + (t[0] >>> 0 < s[0] >>> 0 ? 1 : 0) | 0, t[2] = t[2] + 886263092 + (t[1] >>> 0 < s[1] >>> 0 ? 1 : 0) | 0, t[3] = t[3] + 1295307597 + (t[2] >>> 0 < s[2] >>> 0 ? 1 : 0) | 0, t[4] = t[4] + 3545052371 + (t[3] >>> 0 < s[3] >>> 0 ? 1 : 0) | 0, t[5] = t[5] + 886263092 + (t[4] >>> 0 < s[4] >>> 0 ? 1 : 0) | 0, t[6] = t[6] + 1295307597 + (t[5] >>> 0 < s[5] >>> 0 ? 1 : 0) | 0, t[7] = t[7] + 3545052371 + (t[6] >>> 0 < s[6] >>> 0 ? 1 : 0) | 0, this._b = t[7] >>> 0 < s[7] >>> 0 ? 1 : 0, n = 0; n < 8; n++) {
                        var i = e[n] + t[n],
                            r = 65535 & i,
                            o = i >>> 16,
                            d = ((r * r >>> 17) + r * o >>> 15) + o * o,
                            l = ((4294901760 & i) * i | 0) + ((65535 & i) * i | 0);
                        a[n] = d ^ l
                    }
                    e[0] = a[0] + (a[7] << 16 | a[7] >>> 16) + (a[6] << 16 | a[6] >>> 16) | 0, e[1] = a[1] + (a[0] << 8 | a[0] >>> 24) + a[7] | 0, e[2] = a[2] + (a[1] << 16 | a[1] >>> 16) + (a[0] << 16 | a[0] >>> 16) | 0, e[3] = a[3] + (a[2] << 8 | a[2] >>> 24) + a[1] | 0, e[4] = a[4] + (a[3] << 16 | a[3] >>> 16) + (a[2] << 16 | a[2] >>> 16) | 0, e[5] = a[5] + (a[4] << 8 | a[4] >>> 24) + a[3] | 0, e[6] = a[6] + (a[5] << 16 | a[5] >>> 16) + (a[4] << 16 | a[4] >>> 16) | 0, e[7] = a[7] + (a[6] << 8 | a[6] >>> 24) + a[5] | 0
                }
                e.Rabbit = t._createHelper(o)
            }(), n.Rabbit)
        }(la)), ca || (ca = 1, function(e, t) {
            var n;
            e.exports = (n = Br(), Wr(), Zr(), xs(), _s(), function() {
                var e = n,
                    t = e.lib.StreamCipher,
                    i = e.algo,
                    r = [],
                    s = [],
                    a = [],
                    o = i.RabbitLegacy = t.extend({
                        _doReset: function() {
                            var e = this._key.words,
                                t = this.cfg.iv,
                                n = this._X = [e[0], e[3] << 16 | e[2] >>> 16, e[1], e[0] << 16 | e[3] >>> 16, e[2], e[1] << 16 | e[0] >>> 16, e[3], e[2] << 16 | e[1] >>> 16],
                                i = this._C = [e[2] << 16 | e[2] >>> 16, 4294901760 & e[0] | 65535 & e[1], e[3] << 16 | e[3] >>> 16, 4294901760 & e[1] | 65535 & e[2], e[0] << 16 | e[0] >>> 16, 4294901760 & e[2] | 65535 & e[3], e[1] << 16 | e[1] >>> 16, 4294901760 & e[3] | 65535 & e[0]];
                            this._b = 0;
                            for (var r = 0; r < 4; r++) d.call(this);
                            for (r = 0; r < 8; r++) i[r] ^= n[r + 4 & 7];
                            if (t) {
                                var s = t.words,
                                    a = s[0],
                                    o = s[1],
                                    l = 16711935 & (a << 8 | a >>> 24) | 4278255360 & (a << 24 | a >>> 8),
                                    c = 16711935 & (o << 8 | o >>> 24) | 4278255360 & (o << 24 | o >>> 8),
                                    f = l >>> 16 | 4294901760 & c,
                                    u = c << 16 | 65535 & l;
                                for (i[0] ^= l, i[1] ^= f, i[2] ^= c, i[3] ^= u, i[4] ^= l, i[5] ^= f, i[6] ^= c, i[7] ^= u, r = 0; r < 4; r++) d.call(this)
                            }
                        },
                        _doProcessBlock: function(e, t) {
                            var n = this._X;
                            d.call(this), r[0] = n[0] ^ n[5] >>> 16 ^ n[3] << 16, r[1] = n[2] ^ n[7] >>> 16 ^ n[5] << 16, r[2] = n[4] ^ n[1] >>> 16 ^ n[7] << 16, r[3] = n[6] ^ n[3] >>> 16 ^ n[1] << 16;
                            for (var i = 0; i < 4; i++) r[i] = 16711935 & (r[i] << 8 | r[i] >>> 24) | 4278255360 & (r[i] << 24 | r[i] >>> 8), e[t + i] ^= r[i]
                        },
                        blockSize: 4,
                        ivSize: 2
                    });

                function d() {
                    for (var e = this._X, t = this._C, n = 0; n < 8; n++) s[n] = t[n];
                    for (t[0] = t[0] + 1295307597 + this._b | 0, t[1] = t[1] + 3545052371 + (t[0] >>> 0 < s[0] >>> 0 ? 1 : 0) | 0, t[2] = t[2] + 886263092 + (t[1] >>> 0 < s[1] >>> 0 ? 1 : 0) | 0, t[3] = t[3] + 1295307597 + (t[2] >>> 0 < s[2] >>> 0 ? 1 : 0) | 0, t[4] = t[4] + 3545052371 + (t[3] >>> 0 < s[3] >>> 0 ? 1 : 0) | 0, t[5] = t[5] + 886263092 + (t[4] >>> 0 < s[4] >>> 0 ? 1 : 0) | 0, t[6] = t[6] + 1295307597 + (t[5] >>> 0 < s[5] >>> 0 ? 1 : 0) | 0, t[7] = t[7] + 3545052371 + (t[6] >>> 0 < s[6] >>> 0 ? 1 : 0) | 0, this._b = t[7] >>> 0 < s[7] >>> 0 ? 1 : 0, n = 0; n < 8; n++) {
                        var i = e[n] + t[n],
                            r = 65535 & i,
                            o = i >>> 16,
                            d = ((r * r >>> 17) + r * o >>> 15) + o * o,
                            l = ((4294901760 & i) * i | 0) + ((65535 & i) * i | 0);
                        a[n] = d ^ l
                    }
                    e[0] = a[0] + (a[7] << 16 | a[7] >>> 16) + (a[6] << 16 | a[6] >>> 16) | 0, e[1] = a[1] + (a[0] << 8 | a[0] >>> 24) + a[7] | 0, e[2] = a[2] + (a[1] << 16 | a[1] >>> 16) + (a[0] << 16 | a[0] >>> 16) | 0, e[3] = a[3] + (a[2] << 8 | a[2] >>> 24) + a[1] | 0, e[4] = a[4] + (a[3] << 16 | a[3] >>> 16) + (a[2] << 16 | a[2] >>> 16) | 0, e[5] = a[5] + (a[4] << 8 | a[4] >>> 24) + a[3] | 0, e[6] = a[6] + (a[5] << 16 | a[5] >>> 16) + (a[4] << 16 | a[4] >>> 16) | 0, e[7] = a[7] + (a[6] << 8 | a[6] >>> 24) + a[5] | 0
                }
                e.RabbitLegacy = t._createHelper(o)
            }(), n.RabbitLegacy)
        }(fa)), n)
    }(Rr);
    var ua = Rr.exports;
    const pa = new class {
            constructor({
                freestar: e = {}
            }) {
                e.fsdata && (this.active = this.shouldRun(), window.freestar.fsdata.atsEnabledV2 && (this.version = 2))
            }
            shouldRun() {
                const e = freestar.locData && freestar.locData.iso;
                return e && w.includes(e) ? window.freestar.fsdata.atsEnabledV2 : (freestar.log(10, "LiveRamp ATS does not run for users " + (e ? `in ${e}.` : "without location data.")), !1)
            }
            start() {
                if (this.active)
                    if (window.ats) {
                        const e = ats.setAdditionalData,
                            t = this.getConfigV2();
                        this.launch({
                            callbackFunc: e,
                            obj: t
                        })
                    } else this.load()
            }
            getConfigV2() {
                let e = {};
                const t = za();
                return t && (e = {
                    id: Object.values(t),
                    type: "emailHashes"
                }), e
            }
            load() {
                const e = `https://launchpad-wrapper.privacymanager.io/${freestar.fsdata.atsV2ConfigUUID}/launchpad-liveramp.js`,
                    t = window.freestar.fsdata.identityProviders.find((e => 2 === e.id)) ? window.freestar.fsdata.identityProviders.find((e => 2 === e.id)).params.pid : 106;
                fsprebid.enableAnalytics([{
                    provider: "atsAnalytics",
                    options: {
                        pid: t
                    }
                }]);
                const n = () => {
                    if (window.ats && window.ats.setAdditionalData) {
                        const e = window.ats.setAdditionalData;
                        let t;
                        return 2 === this.version && (t = this.getConfigV2()), this.launch({
                            callbackFunc: e,
                            obj: t
                        }), !0
                    }
                    return !1
                };
                an(e, (() => {
                    if (!n()) {
                        const e = setInterval((() => {
                            n() && clearInterval(e)
                        }), 10)
                    }
                }))
            }
            launch({
                callbackFunc: e,
                obj: t
            }) {
                0 !== Object.keys(t).length && e(t)
            }
        }({
            freestar: window.freestar
        }),
        ha = "disabled",
        ma = "enabled",
        ga = "test",
        ba = {
            criteo: {
                itfPosition: 0,
                itfTestPercent: .95,
                enabled: void 0
            },
            uid2: {
                itfPosition: 1,
                itfTestPercent: .95,
                enabled: void 0
            },
            fabrickId: {
                itfPosition: 2,
                itfTestPercent: .95,
                enabled: void 0
            },
            hadronId: {
                itfPosition: 3,
                itfTestPercent: .95,
                enabled: void 0
            },
            id5Id: {
                itfPosition: 4,
                itfTestPercent: .95,
                enabled: void 0
            },
            pairId: {
                itfPosition: 5,
                itfTestPercent: .95,
                enabled: void 0
            },
            "33across": {
                itfPosition: 6,
                itfTestPercent: .95,
                enabled: void 0
            },
            sharedId: {
                itfPosition: 7,
                itfTestPercent: .95,
                enabled: void 0
            },
            connectId: {
                itfPosition: 8,
                itfTestPercent: .95,
                enabled: void 0
            },
            atsAnalytics: {
                itfPosition: 9,
                itfTestPercent: .95,
                enabled: void 0
            },
            liveIntentId: {
                itfPosition: 11,
                itfTestPercent: .95,
                enabled: void 0
            }
        },
        ya = "uid2",
        wa = "emailHash",
        va = ["serverPublicKey", "subscriptionId"];

    function Ia(e) {
        return e && void 0 !== e.sha256
    }

    function Aa(e) {
        const t = window.freestar.fsdata.identityProviders && window.freestar.fsdata.identityProviders.find((e => "fabrickId" === e.slug));
        if (Ia(e) && t) {
            return {
                name: "fabrickId",
                params: { ...t.params,
                    e: e.sha256
                },
                storage: t.storage
            }
        }
        return {}
    }

    function ka(e) {
        const t = window.freestar.fsdata.identityProviders && window.freestar.fsdata.identityProviders.findIndex((e => "connectId" === e.slug));
        if (Ia(e) && -1 !== t) {
            const n = window.freestar.fsdata.identityProviders[t];
            if (n) return {
                name: n.slug,
                params: { ...n.params,
                    he: e.sha256
                },
                storage: n.storage
            }
        }
        return {}
    }

    function Sa(e = !1) {
        const t = window.freestar.fsdata.identityProviders && window.freestar.fsdata.identityProviders.filter((e => "id5Id" === e.slug)).map((e => e.params.partner)).at(0);
        if (Ia(e) && t) {
            const n = {
                    1: e.sha256
                },
                i = Object.keys(n).map((e => e + "=" + n[e])).join("&");
            return {
                name: "id5Id",
                params: {
                    partner: t,
                    pd: btoa(i)
                }
            }
        }
        return {}
    }

    function xa(e = !1) {
        let t = window.freestar.fsdata.identityProviders && window.freestar.fsdata.identityProviders.find((e => "liveIntentId" === e.slug));
        if (e && void 0 !== e.sha1 && t) {
            return {
                name: "liveIntentId",
                params: { ...t.params,
                    emailHash: e.sha1
                }
            }
        }
        return {}
    }

    function Ea(e = !1) {
        const t = (window.freestar.fsdata.identityProviders || []).find((e => e.slug === ya));
        return t && t.params && va.every((e => !!t.params[e])) && Ia(e) ? {
            name: ya,
            params: { ...t.params,
                [wa]: e.sha256
            },
            storage: t.storage
        } : {}
    }

    function Oa(e) {
        0 !== Object.keys(e).length && fsprebid.que.push((function() {
            let t = fsprebid.getConfig("userSync");
            t.userIds = t.userIds || [];
            let n = t.userIds.find((t => t.name === e.name));
            if (n) {
                let i = t.userIds.filter((t => t.name !== e.name));
                t.userIds = [...i, Object.assign(n, e)], fsprebid.setConfig({
                    userSync: t
                })
            }
        }))
    }

    function _a(e, t = !1, n, i, r) {
        i && i !== ha && (e.isProviderEnabled(n, "amazon") && function(e, t) {
            if (Ia(e) && window.freestar.fsdata.networks.find((e => "amazon" === e.slug))) {
                const n = () => {
                    window.apstag.updateId({
                        optOut: t,
                        hashedRecords: [{
                            type: "email",
                            record: e.sha256
                        }]
                    })
                };
                if (window.apstag && window.apstag.updateId) n();
                else {
                    const e = setInterval((() => {
                        window.apstag && window.apstag.updateId && (clearInterval(e), n())
                    }), 10)
                }
            }
        }(t, r), e.isProviderEnabled(n, "atsAnalytics") && pa.start(), e.isProviderEnabled(n, "fabrickId") && Oa(Aa(t)), e.isProviderEnabled(n, "connectId") && Oa(ka(t)), e.isProviderEnabled(n, "id5Id") && Oa(Sa(t)), e.isProviderEnabled(n, "liveIntentId") && Oa(xa(t)), e.isProviderEnabled(n, ya) && Oa(Ea(t)))
    }

    function Ta(e, t = !1, n) {
        Ia(t) && n !== ha && function(e) {
            if (-1 !== window.freestar.fsdata.networks.findIndex((e => "amazon" === e.slug))) {
                const t = () => {
                    window.apstag.renewId({
                        hashedRecords: [{
                            type: "email",
                            record: e.sha256
                        }]
                    })
                };
                if (window.apstag && window.apstag.renewId) t();
                else {
                    const e = setInterval((() => {
                        window.apstag && window.apstag.renewId && (clearInterval(e), t())
                    }), 10)
                }
            }
        }(t)
    }
    class Ca {
        static EMAIL_EXTENSION_SYMBOL = "+";
        static EMAIL_DOT = ".";
        static GMAIL_DOMAIN = "gmail.com";
        static normalizeEmail(e) {
            if (!e || !e.length) return;
            const t = e.trim().toLowerCase();
            if (t.indexOf(" ") > 0) return;
            const n = this.splitEmailIntoAddressAndDomain(t);
            if (!n) return;
            const {
                address: i,
                domain: r
            } = n, s = this.isGmail(r), a = this.normalizeAddressPart(i, s, s);
            return a ? `${a}@${r}` : void 0
        }
        static splitEmailIntoAddressAndDomain(e) {
            const t = e.split("@");
            if (2 === t.length && !t.some((e => "" === e))) return {
                address: t[0],
                domain: t[1]
            }
        }
        static isGmail(e) {
            return e === this.GMAIL_DOMAIN
        }
        static dropExtension(e) {
            return e.split(this.EMAIL_EXTENSION_SYMBOL)[0]
        }
        static normalizeAddressPart(e, t, n) {
            let i = e;
            return t && (i = i.replaceAll(this.EMAIL_DOT, "")), n && (i = this.dropExtension(i)), i
        }
    }

    function Ra(e) {
        e.realTimeData = e.realTimeData || {
            auctionDelay: 50
        }, e.realTimeData.dataProviders = e.realTimeData.dataProviders || []
    }
    const Na = "hadronId";

    function Ma(e) {
        return e.find((e => e.slug && e.slug === Na))
    }
    const Da = (e, t) => (e.params || (e.params = {}), void 0 === e.params.partnerId || null === e.params.partnerId || Number.isNaN(e.params.partnerId) ? t : "number" == typeof e.params.partnerId || isNaN(Number(e.params.partnerId)) ? e.params.partnerId : Number(e.params.partnerId));
    Ba = void 0;
    var Ba = function(e) {
        return e && "[object Function]" === {}.toString.call(e)
    };
    const Pa = "fs.ident",
        za = () => {
            const e = ut({
                key: Pa,
                type: ft.object.type
            });
            return !!Object.keys(e).length && e
        };
    const La = new class {
        targeting = "----------------------------------------";
        ITF_GROUP_KEY = "fs.itf.group";
        ITF_PROVIDERS_KEY = "fs.itf.targeting";
        GAM_ITF_KEY = "fsitf";
        providersRules = [];
        prebidProviders = [];
        testGroup = void 0;
        hashedEmailsPassed = !1;
        identityData = void 0;
        constructor() {
            this.identityData = za(), this.testGroup = this.getIdentityTestGroup(), this.getSessionProviders(this.testGroup);
            const {
                identityProviders: e
            } = window.freestar && window.freestar.fsdata || [];
            this.prebidProviders = this.prebidIdentityPartnersFetch(e, this.providersRules, this.testGroup), Ta(this.providersRules, this.identityData, this.testGroup), this.targeting = this.createTargeting(this.providersRules, this.targeting), this.setTargetingGAM(this.targeting, this.testGroup)
        }
        getSessionProviders(e) {
            let t = ut({
                key: this.ITF_PROVIDERS_KEY,
                type: ft.string.type
            });
            try {
                this.providersRules = JSON.parse(atob(t))
            } catch (t) {
                this.providersRules = this.getProvidersRulesByTestGroup(e)
            }
        }
        updateTargeting(e, t) {
            return S(t.enabled) && ((e = e.split(""))[t.itfPosition] = t.enabled ? "Y" : "N", e = e.join("")), e
        }
        getPrebidProviders() {
            return this.prebidProviders
        }
        createTargeting(e, t) {
            return Object.entries(e).forEach((e => {
                let [, n] = e;
                t = this.updateTargeting(t, n)
            })), t
        }
        setTargetingGAM(e, t) {
            window.googletag = window.googletag || {}, window.googletag.cmd = window.googletag.cmd || [], t === ha && (e = "0"), window.googletag.cmd.push((() => {
                window.googletag.pubads().setTargeting(this.GAM_ITF_KEY, e)
            }))
        }
        getIdentityTestGroup() {
            let e = ut({
                key: this.ITF_GROUP_KEY,
                type: ft.string.type
            });
            return e || (e = Math.random() <= .99 ? ma : ha, e === ma && Math.random() <= .05 && (e = ga)), pt({
                key: this.ITF_GROUP_KEY,
                value: e,
                type: ft.string
            }), e
        }
        getProvidersRulesByTestGroup(e) {
            let t = {};
            if (e === ga) {
                const e = function(e, t) {
                    return t.itfTestPercent <= Math.random()
                };
                t = this.setEnabledRules(ba, e)
            }
            return e === ma && (t = this.setEnabledRules(ba, !0)), e === ha && (t = this.setEnabledRules(ba, !1)), pt({
                key: this.ITF_PROVIDERS_KEY,
                value: btoa(JSON.stringify(t)),
                type: ft.string
            }), t
        }
        setEnabledRules(e, t) {
            let n = {};
            return Object.entries(e).forEach((e => {
                let [i, r] = e;
                const s = Ba(t) ? t(i, r) : t;
                n[i] = Object.assign({}, r, {
                    enabled: s
                })
            })), n
        }
        prebidIdentityPartnersFetch(e = [], t, n) {
            if (n === ha) return [];
            const i = e.filter((e => "intentIqId" !== e.slug)).filter((e => this.isProviderEnabled(t, e.slug))).map((e => {
                const {
                    slug: t,
                    params: n,
                    storage: i
                } = e;
                let r = {
                    name: t
                };
                switch (0 !== Object.keys(n || {}).length && (r.params = n), 0 !== Object.keys(i || {}).length && (r.storage = i), t) {
                    case "fabrickId":
                    case "connectId":
                    case "liveIntentId":
                    case "id5Id":
                        this.identityData && this.identityData.sha256 && !this.hashedEmailsPassed && (this.hashedEmailsPassed = !0, r.params = Object.assign(r.params, function(e, t) {
                            switch (e) {
                                case "fabrickId":
                                    return Aa(t);
                                case "connectId":
                                    return ka(t);
                                case "id5Id":
                                    return Sa(t);
                                case "liveIntentId":
                                    return xa(t);
                                case ya:
                                    return Ea(t);
                                default:
                                    return {}
                            }
                        }(t, this.identityData)));
                        break;
                    case "merkleId":
                        r.params = Object.assign(r.params, {
                            sv_domain: window.location.hostname
                        });
                        break;
                    case "pairId":
                        if (r.params && r.params.liveramp) {
                            let e = "";
                            try {
                                e = JSON.parse(r.params.liveramp)
                            } catch (t) {
                                e = r.params.liveramp
                            }
                            r.params = Object.assign(r.params, {
                                liveramp: e
                            })
                        }
                }
                return r
            }));
            return i
        }
        addOptOut({
            selector: e = "#freestarOptOutLink",
            element: t = !1
        }) {
            if (!t && !document.querySelector(e)) return !1;
            t || (t = document.querySelector(e)), t.onclick = function(e) {
                e.preventDefault(), this.showModal()
            }
        }
        isIdentified() {
            return za()
        }
        removeIdentity() {
            za() && (ht({
                key: Pa
            }), _a(this, !1, this.providersRules, this.testGroup, !1))
        }
        setIdentity({
            email: e = !1,
            hashes: t = !1
        }) {
            let n = this.isIdentified();
            if (!n && e && (({
                    email: e
                }) => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(e))({
                    email: e
                }) && (e = Ca.normalizeEmail(e), t = {
                    sha256: ua.SHA256(e).toString(),
                    sha1: ua.SHA1(e).toString(),
                    md5: ua.MD5(e).toString()
                }, pt({
                    key: Pa,
                    value: t,
                    type: ft.object
                })), n) try {
                t = JSON.parse(ut({
                    key: Pa,
                    type: ft.object
                }))
            } catch (e) {
                console.log("We could not read the identity properly", e)
            } else t && pt({
                key: Pa,
                value: t,
                type: ft.object
            });
            return this.hashedEmailsPassed || (this.hashedEmailsPassed = !0, _a(this, t, this.providersRules, this.testGroup, !1)), !0
        }
        showModal() {
            xi("\n@import url('https://fonts.googleapis.com/css2?family=Varela+Round&display=swap');\n\n.__fs-modal__overlay {\n    position: absolute;\n    z-index: 10000;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    background-color: rgba(255,255,255,0.75);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n}\n.__fs-modal {\n    font-family: 'Varela Round', sans-serif !important;\n    font-size: 16px;\n    width: 45vw;\n    border-radius: 5px;\n    background-color: white;\n    box-shadow: 0 10px 25px 0 rgb(0 195 137 / 50%);\n    border: 1px solid rgb(0 195 137);\n}\n.__fs-modal__content {\n    margin: 1rem;\n    padding: 1rem;\n    height: calc(100% - 2rem);\n}\n.__fs-modal__header {\n    width: 100%;\n    text-align: left;\n    font-size: 2rem;\n}\nh2.__fs-modal__header {\n    border-bottom: 3px solid rgb(0 195 137);\n    margin-bottom: 1rem;\n}\nh3.__fs-modal__header {\n    font-size: 1.5rem;\n}\n.__fs-modal__description {\n    width: 100%;\n    font-size: 1rem;\n    margin-bottom: .75rem;\n}\n.__fs-modal__content span {\n    width: 100%;\n    font-size: 1.25rem;\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n}\n.__fs-modal__content span input,\n.__fs-modal__content span button {\n    width: 100%;\n    font-size: 1.25em;\n    padding: .25rem;\n}\n.__fs-modal__content span button {\n    border: 0;\n    border-radius: 5px;\n    background-color: rgb(0 195 137);\n    color: white;\n    font-family: 'Varela Round', sans-serif !important;\n}\n@media only screen and (min-device-width : 320px) and (max-device-width : 768px) {\n    .__fs-modal {\n         width: 100vw;\n         border-radius: 0;\n         background-color: white;\n         box-shadow: initial;\n         border: 0;\n         position: fixed;\n         top: 0;\n         bottom: 0;\n    }\n}\n");
            let e = document.body,
                t = sn({
                    classList: ["__fs-modal__overlay"]
                });
            t.innerHTML = '\n<div class="__fs-modal">\n    <form class="__fs-modal__content">\n        <h2 class="__fs-modal__header">Welcome!</h2>\n        <p class="__fs-modal__description">Our trusted advertising partners using the UID identifier and/or encrypted email addresses  are committed to delivering relevant advertising that also respects your choice.  Advertising enables access to your favorite content across the internet.</p>\n        <h3 class="__fs-modal__header">Opt-Out</h3>\n        <p class="__fs-modal__description">Your choice to Opt-Out will indicate to trusted advertising partners that you no longer wish to receive targeted advertising based on your UID/email.  The scope of this Opt-Out is limited to this site which use UID/email.  For choice with respect to advertising based on cookies, please visit https://optout.aboutads.info.  To opt out of UID across all sites please visit <a href="https://transparentadvertising.org/" target="_blank">https://transparentadvertising.org/</a></p>\n        <p class="__fs-modal__description">Note: this choice may limit your ability to access ad supported content.  You may be asked to Opt-In again in the future to access such content.</p>\n        <span>\n            <button type="submit" id="__fs-model__submit">OPT OUT</button>&nbsp;\n            <button id="__fs-model__cancel">CANCEL</button>\n        </span>\n    </form>\n</div>\n', e.appendChild(t);
            let n = document.getElementById("__fs-model__submit"),
                i = document.getElementById("__fs-model__cancel");
            n.onclick = e => {
                e.preventDefault(), this.removeIdentity(), t.remove(), Be({
                    name: "identityModalOptOut",
                    detail: !0
                })
            }, i.onclick = e => {
                e.preventDefault(), t.remove(), Be({
                    name: "identityModalClosed",
                    detail: !0
                })
            }
        }
        isProviderEnabled(e = {}, t) {
            return !e[t] || e[t] && !1 !== e[t].enabled
        }
        hadronInit(e = []) {
            const t = Ma(e),
                n = this.isProviderEnabled(this.providersRules, "hadronId");
            t && n && (Da(t, 474), function(e = null) {
                e ? function(e, t, n, i, r, s, a) {
                    e[s] = e[s] || function() {
                        (e[s].q = e[s].q || []).push(arguments)
                    }, e[s]({
                        config: {
                            dm: !0
                        }
                    });
                    const o = t.createElement(n);
                    t.async = !0, o.src = "https://cdn.hadronid.net/hadron.js?url=" + encodeURIComponent(e.location.href) + "&ref=" + encodeURIComponent(t.referrer) + "&_it=freestar&partner_id=" + r + "&ha=" + s;
                    const d = t.getElementsByTagName(n)[0];
                    d.parentNode.insertBefore(o, d)
                }(window, document, "script", 0, e, "_hadron") : window.freestar.log(20, "Hadron ID not configured.")
            }(t.params.partnerId))
        }
        setCriteoConfig() {
            const e = za(),
                t = this.isProviderEnabled(this.providersRules, "criteo");
            if (e && t) {
                const t = {
                    bidders: ["criteo"],
                    config: {
                        ortb2: {
                            user: {
                                ext: {
                                    data: {
                                        eids: [{
                                            source: window.location.hostname,
                                            uids: [{
                                                id: e.md5,
                                                atype: 3,
                                                ext: {
                                                    stype: "hemmd5"
                                                }
                                            }, {
                                                id: e.sha256,
                                                atype: 3,
                                                ext: {
                                                    stype: "hemsha256"
                                                }
                                            }, {
                                                id: e.sha1,
                                                atype: 3,
                                                ext: {
                                                    stype: "hemsha1"
                                                }
                                            }]
                                        }]
                                    }
                                }
                            }
                        }
                    }
                };
                window.fsprebid.setBidderConfig(t)
            }
        }
    };

    function ja(e) {
        e.sizes = e.sizes.filter((e => function(e) {
            const {
                deviceExclusive: t
            } = e;
            return !t || t.toLowerCase() === freestar.deviceInfo.device.type.toLowerCase()
        }(e)))
    }

    function Fa(e) {
        const {
            adUnitCode: t,
            bidderCode: n
        } = e;
        t && (freestar.bidsWon[t] = function(e) {
            return {
                bidder: e.bidder,
                creativeId: e.creativeId,
                cpm: e.cpm,
                mediaType: e.mediaType,
                evaluated: !1,
                ad: e.ad,
                time: Date.now()
            }
        }(e));
        if (function(e, t) {
                "gumgum" === e.bidderCode && (freestar.refreshLibrary[t] = {
                    refreshTime: 20,
                    refreshCounter: 1,
                    viewPercentage: 100,
                    disableRefresh: !1,
                    stickyOriginalSlot: Wt({
                        elementId: e.adUnitCode
                    })
                })
            }(e, freestar.dynamicSlotLibrary[t]), freestar.currentStickyFooter && "function" == typeof freestar.currentStickyFooter.prebidEvaluation) {
            const i = "gumgum" === n && t === freestar.currentStickyFooter.placement.name;
            freestar.currentStickyFooter.prebidEvaluation(e, i)
        }
    }
    const Ua = "Bid Adjustment Log : ";
    class qa {
        constructor() {
            this.ext = {
                fs_company: window.freestar.fsdata && window.freestar.fsdata.companyId || "unknown"
            }
        }
    }
    class $a {
        constructor() {
            this.data = [{
                name: "www.freestar.com",
                ext: {
                    taxonomyname: "iab_content_taxonomy"
                },
                segment: ["v2ContentCategory", "v2ContentSource", "v2ContentMediaFormat", "v2ContentChannel", "v2ContentType", "v2ContentLanguage", "v2ContentSourceGeo"].reduce(((e, t) => window.freestar.fsdata[t] ? [...e, ...window.freestar.fsdata[t]] : e), [])
            }]
        }
    }
    class Ha {
        constructor() {
            this.fs_optimized = this.getIsOptimized(window.freestar), this.fs_site = window.freestar.fsdata && window.freestar.fsdata.siteId || "unknown"
        }
        getIsOptimized({
            config: e = {}
        }) {
            return !(!e || !e.pageSpeedOptimized) && e.pageSpeedOptimized
        }
    }
    class Va {
        constructor() {
            this.data = new Ha
        }
    }
    class Ga {
        constructor(e = "") {
            this.name = window.freestar.fsdata.path || "", this.domain = window.freestar.fsdata.domain || "", this.cat = window.freestar.fsdata.categories || [], this.sectioncat = window.freestar.fsdata.categories || [], this.pagecat = window.freestar.fsdata.categories || [], this.page = window.location.href || "", this.mobile = "mobile" === e ? 1 : 0, this.ref = document.referrer || "", this.content = new $a, this.ext = new Va, this.publisher = new qa
        }
    }
    class Wa {
        constructor() {
            this.id = window.freestar.msg.fpc || ""
        }
        isValid() {
            return this.id && this.id.length && this.id !== y
        }
    }
    class Qa {
        clean() {
            for (const e in this) "string" == typeof this[e] && 0 === this[e].length && delete this[e]
        }
    }
    class Ya extends Qa {
        constructor() {
            super(), this.region = this.getRegion(), this.city = this.getCity(), this.country = this.getCountry(), this.ext = {}, this.clean()
        }
        getLocObj() {
            return !!window.freestar.locData && window.freestar.locData
        }
        getRegion() {
            return void 0 !== this.region ? this.region : this.getLocObj().state || ""
        }
        getCity() {
            return void 0 !== this.city ? this.city : this.getLocObj().city || ""
        }
        validateCountryISO(e) {
            return 2 === e.length && e
        }
        getCountry() {
            return void 0 !== this.country && this.validateCountryISO(this.country) ? this.country : this.getLocObj().iso && this.validateCountryISO(this.getLocObj().iso) ? this.getLocObj().iso : ""
        }
    }
    class Ka {
        constructor() {
            this.types = {
                unknown: 0,
                mobile: 1,
                desktop: 2,
                ctv: 3,
                phone: 4,
                tablet: 5,
                connectedDevice: 6,
                "set-top-box": 7
            }
        }
        getType() {
            if (window.freestar.deviceInfo && window.freestar.deviceInfo.device) {
                const {
                    type: e = "unknown"
                } = window.freestar.deviceInfo.device;
                if (e && this.types[e]) return this.types[e]
            }
            return this.types.unknown
        }
    }
    class Ja {
        constructor() {
            this.ua = this.fetchFromDeviceInfo("ua"), this.geo = new Ya({}), this.dnt = this.getUserDNTStatus(), this.devicetype = (new Ka).getType(), this.make = this.getMobileDeviceInfo("vendor"), this.model = this.getMobileDeviceInfo("model"), this.os = this.getOSInfo("name"), this.osv = this.getOSInfo("version")
        }
        getUserDNTStatus() {
            return window.freestar.msg.fpc === y ? 1 : 0
        }
        getOSInfo(e) {
            return this.fetchFromDeviceInfo("os")[e] || ""
        }
        fetchFromDeviceInfo(e) {
            return window.freestar && window.freestar.deviceInfo && window.freestar.deviceInfo[e] ? window.freestar.deviceInfo[e] : ""
        }
        getMobileDeviceInfo(e) {
            return this.fetchFromDeviceInfo("device")[e] || ""
        }
    }
    class Xa {
        constructor() {
            window.freestar.fsdata.topLevelStoredRequestId && (this.storedrequest = {
                id: window.freestar.fsdata.topLevelStoredRequestId
            })
        }
    }
    class Za {
        constructor() {
            this.prebid = new Xa
        }
    }
    class eo {
        constructor(e = "") {
            const t = window.freestar.config.ortb2 || {};
            this.site = this.merge(t.site, new Ga(e)), this.user = this.merge(t.user, new Wa), this.device = this.merge(t.device, new Ja), this.geo = this.merge(t.geo, new Ya), this.ext = this.merge(t.ext, new Za)
        }
        merge(e = {}, t) {
            return Ze(t, e)
        }
    }
    const to = {};
    let no = [],
        io = null;

    function ro({
        bidder: e,
        cpm: t,
        siteAdjustment: n,
        networkAdjustment: i,
        placement: r,
        bid: s
    }) {
        ! function({
            bidder: e,
            cpm: t,
            siteAdjustment: n,
            networkAdjustment: i
        }) {
            (n || i && freestar.adjustments.isLogged) && (freestar.log(Ua, "bidder : ", e), freestar.log(Ua, "cpm : ", JSON.stringify(t)), n && freestar.log(Ua, "siteAdjustment : ", n), i && freestar.log(Ua, "networkAdjustment : ", i))
        }({
            bidder: e,
            cpm: t,
            siteAdjustment: n,
            networkAdjustment: i,
            placement: r,
            bid: s
        });
        let a = t;
        const o = lt("manipulate-cpm"),
            d = lt("manipulate-bidder");
        if (o && d && e === d) return o;
        if (o) return o;

        function l({
            adj: e,
            value: t
        }) {
            const n = 100 - e;
            return t * Number("0." + (n < 10 ? "0" + n : n))
        }
        if (i && i > 0 && (a = l({
                adj: i,
                value: a
            })), n && n > 0 && (a = l({
                adj: n,
                value: a
            })), e && r && r.networks && r.networks.length) {
            const t = function({
                bidder: e,
                placement: t
            }) {
                const n = t.networks.filter((function(t) {
                    if (e === t.slug && t.placementLevelBidAdjustment && t.placementLevelBidAdjustment > 0) return t
                }))[0];
                return n ? n.placementLevelBidAdjustment : 0
            }({
                bidder: e,
                placement: r
            });
            t && t > 0 && (a = l({
                adj: t,
                value: a
            }))
        }
        return function({
            cpm: e,
            siteAdjustment: t,
            networkAdjustment: n,
            bid: i
        }) {
            (e && t || n) && (freestar.adjustments.isLogged && freestar.log(Ua, "final cpm value : ", e), i.originalCpm = i.cpm, i.adjustedCpm = e, freestar.adjustments.bids.push(he(i)))
        }({
            cpm: a,
            siteAdjustment: n,
            networkAdjustment: i,
            bid: s
        }), a
    }
    to.initiate = () => {
        var e = window.fsprebid || {};
        return e.que = e.que || [], e.retries = 0, e
    };
    let so = {};

    function ao({
        network: e
    }) {
        const {
            id: t
        } = e;
        let n = e.networkBidAdjustment || 0;
        if (freestar.networkMap && t) {
            const i = freestar.networkMap[t];
            n = i && i.bidAdjustment && Number(i.bidAdjustment) && i.bidAdjustment > 0 ? i.bidAdjustment : e.networkBidAdjustment || 0
        }
        return n
    }

    function oo(e) {
        so[e.slug] || (so[e.slug] = {
            bidCpmAdjustment: function(t, n) {
                const i = Ti({
                        name: ve({
                            slotId: n.adUnitCode
                        })
                    }),
                    r = ro({
                        bidder: e.slug,
                        cpm: t,
                        siteAdjustment: e.bidAdjustment,
                        networkAdjustment: ao({
                            network: e
                        }),
                        placement: i,
                        bid: n
                    });
                return r || t
            }
        })
    }
    to.setNetworks = () => {
        io = new qn, fsprebid.que.push((function() {
            fsprebid.onEvent("bidWon", (e => Fa(e)))
        })), freestar.fsdata.networks.forEach((e => {
            qi(e), oo(e)
        }));
        freestar.fsdata.placements.filter((e => e.networks.length)).forEach((function(e) {
            e.networks.forEach((e => {
                qi(e), oo(e)
            }))
        }))
    }, to.getBidderSettings = () => {
        so.standard = {
            alwaysUseBid: !1,
            adserverTargeting: [{
                key: "hb_bidder",
                val: function(e) {
                    return e.bidderCode
                }
            }, {
                key: "hb_adid",
                val: function(e) {
                    return e.adId
                }
            }, {
                key: "hb_pb",
                val: function(e) {
                    return "medium" === freestar.fsdata.priceGranularity ? e.pbMg : "high" === freestar.fsdata.priceGranularity ? e.pbHg : "auto" === freestar.fsdata.priceGranularity ? e.pbAg : "dense" === freestar.fsdata.priceGranularity ? e.pbDg : e.adUnitCode && e.cpm && e.cpm > 2 && freestar.gamMap[e.adUnitCode] && !0 === freestar.gamMap[e.adUnitCode] ? function({
                        cpm: e
                    }) {
                        const t = e <= 10 ? 20 : 2;
                        return (Math.ceil(e * t) / t).toFixed(2)
                    }({
                        cpm: e.cpm
                    }) : e.pbCg
                }
            }, {
                key: "hb_size",
                val: function(e) {
                    return e.size
                }
            }, {
                key: "hb_format",
                val: function(e) {
                    return e.mediaType
                }
            }, {
                key: "custom_bidder_size",
                val: function(e) {
                    return [e.bidder, e.size].join("_")
                }
            }, {
                key: "freestar_domain",
                val: function() {
                    return freestar.fsdata.domain || location.domain
                }
            }, {
                key: "freestar_path",
                val: function() {
                    return location.pathname
                }
            }, {
                key: "hb_auction_id",
                val: function(e) {
                    return `${e.auctionId}`
                }
            }]
        }, freestar.fsDfpId && so.standard.adserverTargeting.push({
            key: "fspbg",
            val: "freestar"
        }), so.concert && (so.concert.storageAllowed = !0), so.criteo && (so.criteo.storageAllowed = !0), so.taboola && (so.taboola.storageAllowed = !0)
    }, to.setBidderSettings = () => {
        fsprebid.bidderSettings = so
    };
    to.setEventListeners = () => {
        freestar.adjustments.isLogged && fsprebid.onEvent("bidResponse", (function(e) {
            const t = freestar.adjustments.bids.find((t => t.requestId === e.requestId));
            t && (freestar.log("Bid Adjustment Log: bid response after adjustment", e), freestar.log("Bid Adjustment Log: original bid", t))
        })), fsprebid.onEvent("auctionInit", (function(e) {
            P.logMark({
                markerName: A.pubfigPrebidAuctionInit
            }), e.adUnitCodes.forEach((e => {
                freestar.bidsWon[e] && delete freestar.bidsWon[e]
            }))
        }));
        ["bidAdjustment", "bidResponse", "bidWon"].forEach((e => {
            fsprebid.onEvent(e, ((t = null) => {
                window.freestar.msg && window.freestar.msg.que && window.freestar.msg.que.push({
                    eventType: e,
                    args: t
                })
            }))
        }))
    }, to.enableAnalyticsAdapter = () => {
        fsprebid.que.push((() => {
            pa.start({})
        }))
    }, to.setSChain = () => {
        const {
            companyId: e = ""
        } = window.freestar.fsdata;
        window.fsprebid.setBidderConfig({
            bidders: Ui(io),
            config: {
                schain: {
                    validation: "strict",
                    config: {
                        ver: "1.0",
                        complete: 1,
                        nodes: [{
                            asi: "freestar.com",
                            sid: `${e}`,
                            hp: 1
                        }]
                    }
                }
            }
        })
    }, to.settingConfig = (e, t) => {
        const n = (() => {
                if (window.freestar.fsdata.priceGranularity) {
                    if (!(window.freestar.fsdata.priceGranularity.length > 6)) return window.freestar.fsdata.priceGranularity;
                    try {
                        return JSON.parse(freestar.fsdata.priceGranularity)
                    } catch (e) {
                        window.freestar.log(10, `Error parsing priceGranularity  ${e}`)
                    }
                }
                return {
                    buckets: window.freestar.fsDfpId ? o.v2 : o.v1
                }
            })(),
            i = window.freestar.deviceInfo && window.freestar.deviceInfo.device.type || "",
            r = {
                ortb2: new eo(i),
                rubicon: {
                    singleRequest: !0
                },
                bidderTimeout: window.freestar.fsdata.timeout || 1500,
                userSync: {
                    auctionDelay: 100,
                    enableOverride: !1,
                    filterSettings: {
                        all: {
                            bidders: "*",
                            filter: "include"
                        }
                    },
                    userIds: [],
                    syncDelay: 3e3,
                    syncEnabled: !0,
                    syncsPerBidder: 3
                },
                enableSendAllBids: !1,
                priceGranularity: n,
                bidderSequence: "random",
                publisherDomain: `${window.location.protocol}//${window.location.host}`,
                useBidCache: !0,
                gptPreAuction: {
                    enabled: !0,
                    customPbAdSlot: function(e, t) {
                        let {
                            appendDivIdToGpid: n = !0
                        } = freestar.fsdata, i = t;
                        return n && (i += "/" + e), freestar.log({
                            title: "GPID"
                        }, "Payload is:", i), i
                    },
                    mcmEnabled: !0
                },
                firstPartyData: {
                    skipEnrichments: !0
                }
            };
        if (r.userSync.userIds = r.userSync.userIds.concat(La.getPrebidProviders()), !t.getBypassFirstAuction()) {
            window.freestar.fsdata.networks.forEach((function(e) {
                e.isPrebidServer && -1 === no.indexOf(e.slug) && no.push(e.slug)
            })), window.freestar.fsdata.placements.forEach((function(e) {
                e.networks.forEach((function(e) {
                    e.isPrebidServer && -1 === no.indexOf(e.slug) && no.push(e.slug)
                }))
            })), !no.length && io && io.hasValidStoredRequests() && no.push(io.getSlug());
            const e = t.getActiveServerBidders(),
                n = t.getActiveClientBidders(),
                i = t.getInactiveBidders();
            no = no.filter((e => -1 === n.indexOf(e) && -1 === i.indexOf(e))), no = no.concat(e), no.length && (window.freestar.log(49, "Setting s2sconfig..."), r.s2sConfig = {
                accountId: "d0cd3243-716f-4f9c-b074-f72637de26f3",
                enabled: !0,
                bidders: no,
                timeout: window.freestar.fsdata.timeout,
                adapter: "prebidServer",
                endpoint: "https://s2s.t13.io/openrtb2/auction",
                syncEndpoint: "https://s2s.t13.io/cookie_sync",
                cookieSet: !1,
                cookiesetUrl: "",
                allowUnknownBidderCodes: !0
            })
        }
        var s;
        window.freestar.fsdata.permutiveEnabled && (Ra(r), r.realTimeData.dataProviders.push({
                name: "permutive",
                waitForIt: !0,
                params: {
                    acBidders: [window.freestar.fsdata.permutiveBidders.split(",")]
                }
            })),
            function(e = [], t) {
                const n = Ma(e);
                if (n) {
                    Ra(t);
                    const e = Da(n, 474);
                    e && t.realTimeData.dataProviders.push({
                        name: "hadron",
                        waitForIt: !0,
                        params: {
                            partnerId: e
                        }
                    })
                }
            }(window.freestar.fsdata.identityProviders, r), (s = window.freestar.locData) && (l.includes(s.iso) || "QC" === s.state) && (r.consentManagement = r.consentManagement || {}, r.consentManagement.gdpr = {
                cmpApi: "iab",
                timeout: 1200,
                allowAuctionWithoutConsent: !1
            }),
            function(e) {
                return "US" === e.iso && c.includes(e.state)
            }(window.freestar.locData) && (r.consentManagement = r.consentManagement || {}, r.consentManagement.usp = {
                timeout: 1200
            }), e.setConfig(r)
    }, to.analytics = e => {
        e.enableAnalytics([{
            provider: "freestar",
            options: {}
        }])
    };
    const lo = {
            title: "sidewall",
            style: "background: orange; color: #fff; border-radius:3px; padding: 3px"
        },
        co = {
            NONE: 0,
            AUTO: 1,
            MANUAL: 2,
            TOP_RIGHT: 3,
            TOP_LEFT: 4,
            BOTTOM_LEFT: 5,
            BOTTOM_RIGHT: 6
        };
    let fo = !1;

    function uo({
        placement: e
    }) {
        const t = _(e, "selectedSize.viewport.size", !1);
        return !!(t && t[0] > 0) && t[0]
    }

    function po(e, t) {
        return x(e = e && D(e)) ? e : t
    }

    function ho(e) {
        return "left" === e.orientation ? 0 : e.boundaries.right
    }

    function mo(e, t) {
        function n(t) {
            let n, i = 0;
            for (; !(n || (i++, i > 1e3));) {
                const {
                    targetElement: t
                } = be({
                    placement: e,
                    type: "sideWallOptions"
                });
                n = document.querySelector(t)
            }
            n ? t(null, n) : t(!0)
        }
        n((function(i, r) {
            i ? t(!0) : r && (e.boundaries = r.getBoundingClientRect(), function(e, t) {
                n(((n, i) => {
                    i ? (e.targetDivX = i.getBoundingClientRect().left, t(null, e)) : t(!0)
                }))
            }(e, (function(n, i) {
                if (n) t(!0);
                else {
                    e = i;
                    const n = document.getElementsByTagName("body"),
                        r = sn({
                            type: "div",
                            id: `fs-sidewall-${e.orientation}-container`,
                            name: e.name
                        });
                    let s = function(e) {
                        return "left" === e.orientation ? e.targetDivX : window.innerWidth - e.boundaries.right
                    }(e);
                    r.style = `display: block; z-index: ${e.sideWallOptions.zindex?e.sideWallOptions.zindex:Ai("sidewall")};\n                        top: 0px;\n                        margin-top: ${function(e,t,n){const i=parseInt(t,10);return e&&i?i:n}(e.sideWallOptions.automaticTopOverride,e.sideWallOptions.topMargin,0)}vh;\n                        width: ${s}px; height: 100%;\n                        left: ${ho(e)}px;\n                        position: fixed;\n                        display:flex;\n                        align-items:center;\n                        justify-content: center;`, n[0].appendChild(r), t(null, {
                        div: r,
                        placement: e
                    })
                }
            })))
        }))
    }

    function go(e, t) {
        const n = [];
        e && Array.isArray(e) && e.length && e.forEach((e => {
            ! function(e) {
                freestar.deleteAdSlots([e]);
                let t = document.getElementById(e);
                if (!t) return;
                let n = t.parentNode;
                t && n && (t.parentNode.removeChild(t), n.parentNode.removeChild(n)), freestar.sideWallUnitControl = []
            }(e.name);
            const {
                orientation: i
            } = be({
                placement: e,
                type: "sideWallOptions"
            }), r = uo({
                placement: e
            });
            if (r && -1 === n.indexOf(i) && window.innerWidth >= r) {
                switch (i) {
                    case 1:
                        e.orientation = "left";
                        break;
                    case 2:
                        e.orientation = "right";
                        break;
                    default:
                        return
                }
                mo(e, (function(e, i) {
                    if (i) {
                        const {
                            div: e,
                            placement: r
                        } = i, s = sn({
                            type: "div",
                            id: r.name,
                            name: r.name
                        });
                        let a = sn({
                            type: "div",
                            classList: ["fs-sidewall-close-container"]
                        });
                        e.appendChild(a), e.appendChild(s), e.style.left = ho(r) + "px", e.style.visibility = "visible", e.style.position = "fixed", t(null, Ci({
                            placement: r
                        })), n.push(r.sideWallUnitOrientation), freestar.sideWallUnitControl.push(r.name)
                    }
                }))
            }
        })), fo = !0
    }

    function bo(e = !1, t) {
        if (Nn({
                name: "sideWall"
            })) return !1;
        let n = "auto",
            i = [];
        if (fo && !e) return;
        if (e && "object" == typeof e && (e = e.name), !e) {
            i = freestar.fsdata.placements.filter((function(e) {
                const {
                    orientation: t
                } = be({
                    placement: e,
                    type: "sideWallOptions"
                });
                if (t > 0) return e
            }));
            const e = i.filter((e => {
                    const {
                        select: t,
                        isOnCall: n
                    } = be({
                        placement: e,
                        type: "sideWallOptions"
                    });
                    if (!n && t && t.length && document.getElementById(t)) return e
                })),
                t = e.length > 0;
            if (e.length && (i = e), t && 0 === e.length) return
        }

        function r({
            filterType: t
        }) {
            if (e) {
                const n = Ti({
                        name: e
                    }),
                    {
                        type: i
                    } = n.sideWallOptions;
                return Array.isArray(t) && t.includes(i) || i && i === t ? [n] : []
            }
            return i.filter((e => {
                const {
                    type: n
                } = be({
                    placement: e,
                    type: "sideWallOptions"
                });
                return Array.isArray(t) && t.includes(n) || n === t ? e : void 0
            }))
        }
        let s = r({
                filterType: co.AUTO
            }),
            a = r({
                filterType: [co.MANUAL, co.BOTTOM_LEFT, co.BOTTOM_RIGHT, co.TOP_LEFT, co.TOP_RIGHT]
            });
        s.length > a.length ? i = O(s, (e => e.sideWallOptions.orientation)) : (n = "manual", i = O(a, (e => e.sideWallOptions.orientation))), "auto" === n ? go(i, t) : (matchMedia || window.matchMedia) && i.forEach((e => {
            const n = uo({
                placement: e
            });
            if (n) {
                window.matchMedia(`(min-width: ${po(n,1500)}px)`).matches && function(e, t) {
                    let n = "top";
                    const {
                        orientation: i,
                        topMargin: r,
                        leftMargin: s,
                        rightMargin: a,
                        bottomMargin: o,
                        type: d
                    } = be({
                        placement: e,
                        type: "sideWallOptions"
                    });
                    let l = 1 === i ? "left" : "right";
                    [co.TOP_LEFT, co.BOTTOM_LEFT].includes(d) ? l = "left" : [co.TOP_RIGHT, co.BOTTOM_RIGHT].includes(d) && (l = "right"), [co.BOTTOM_RIGHT, co.BOTTOM_LEFT].includes(d) && (n = "bottom"), freestar.sideWallUnitControl.push(e.name);
                    const c = document.getElementsByTagName("body"),
                        f = sn({
                            type: "div",
                            id: e.name,
                            name: e.name
                        });
                    let u = sn({
                        type: "div",
                        classList: ["fs-sidewall-container"]
                    });
                    [co.MANUAL].includes(d) ? u.style = `position:fixed;\n          ${l}:0;\n          ${n}:0;\n          margin: ${po(r,20)}vh ${po(a,20)}px ${po(o,20)}px ${po(s,20)}px;\n          z-index: ${e.sideWallOptions.zindex?e.sideWallOptions.zindex:Ai("sidewall")};\n          overflow: hidden;` : u.style = `position:fixed;\n          ${l}:0;\n          ${n}:0;\n          margin: ${po(r,20)}px ${po(a,20)}px ${po(o,20)}px ${po(s,20)}px;\n          z-index: ${e.sideWallOptions.zindex?e.sideWallOptions.zindex:Ai("sidewall")};\n          overflow: hidden;`, u.appendChild(f), c[0].appendChild(u), t(null, Ci({
                        placement: e
                    })), fo = !0
                }(e, t)
            }
        }))
    }
    const yo = (e, t) => {
            if (document.getElementById(e.name)) {
                zn([e.name]);
                const n = Jt({
                    placement: e,
                    id: e.name
                });
                Pn(n, e.name, null, {
                    fs_ad_product: Fn(e)
                }), t.push(n)
            }
        },
        wo = ({
            width: e,
            height: t
        }) => e > t ? "landscape" : "portrait",
        vo = () => {
            window.addEventListener("resize", (() => {
                setTimeout((() => {
                    const e = window.innerWidth || document.documentElement.clientWidth,
                        t = window.innerHeight || document.documentElement.clientHeight;
                    wo({
                        width: e,
                        height: t
                    }) !== freestar.deviceOrientation && (freestar.deviceOrientation = wo({
                        width: e,
                        height: t
                    }), async function() {
                        const e = [],
                            t = freestar.config.removeRefresh || [],
                            n = freestar.config.alwaysRefresh || [];
                        xn(), freestar.fsdata.placements.forEach((i => {
                            (freestar.config.enabled_slots && freestar.config.enabled_slots.indexOf(i.name) > -1 && !i.stickyFooter && -1 === t.indexOf(i.name) || n.indexOf(i.name) > -1) && yo(i, e)
                        })), De() ? freestar.AdRefresher = new jt(e) : "undefined" != typeof freestar && freestar.AdRefresher && freestar.AdRefresher(e)
                    }())
                }), 100)
            }))
        },
        Io = {
            title: "SUPERFLEX v2.0",
            styles: "background: black; color: white; border-radius: 3px; padding: 3px"
        },
        Ao = {
            title: "SUPERFLEX v2.0",
            styles: "background: lightblue; color: black; border-radius: 3px; padding: 3px"
        },
        ko = {
            title: "SUPERFLEX v2.0",
            styles: "background: green; color: white; border-radius: 3px; padding: 3px"
        },
        So = {
            title: "SUPERFLEX v2.0",
            styles: "background: gold; color: black; border-radius: 3px; padding: 3px"
        },
        xo = [
            [970, 250],
            [970, 90],
            [728, 90],
            [336, 280],
            [300, 600],
            [300, 250]
        ],
        Eo = [
            [468, 60],
            [320, 50],
            [320, 100],
            [300, 250],
            [300, 50],
            [300, 100]
        ],
        Oo = ["onemobile"];
    class _o {
        constructor({
            placements: e = []
        }) {
            this.placements = e.filter((e => {
                let t = !0;
                if (e.sizeMappings.forEach((e => {
                        e.size.forEach((e => {
                            mi(e) && (t = !1)
                        }))
                    })), t) return e
            })), this.active = 0 !== e.length || !Nn({
                name: "superflex"
            }), this.logs = new It, this.auctionEndLogStatus = Io
        }
        applyTargetElementStyling({
            targetElement: e,
            size: t
        }) {
            e.style.position = "relative", e.style.border = "0", t[0] > t[1] && (e.style.width = `${t[0]}px`), e.style.height = `${t[1]}px`, e.style.display = "inline-flex", e.style.flexDirection = this.getDirection({
                size: t
            }), e.style.justifyContent = "space-evenly", e.style.alignItems = "center", e.style.flexWrap = "wrap", e.classList.add("_fs-sf");
            const n = e.querySelector(".__fs-ancillary");
            n && n.style.setProperty("--childWidth", `${t[0]}px`)
        }
        getPlacementsNames() {
            return this.placements.map((e => e.name))
        }
        getPlacementByName({
            name: e
        }) {
            return this.placements.filter((t => t.name === e))[0]
        }
        getDirection({
            size: e
        }) {
            return e[0] - e[1] > 100 ? "row" : "column"
        }
        getRemainingSpace({
            direction: e,
            size: t
        }) {
            return "row" === e ? t[0] : t[1]
        }
        getValidBids({
            bids: e
        }) {
            return Array.isArray(e) && 0 !== e.length ? e.filter((e => "superflex" !== e.bidderCode && !Oo.includes(e.bidderCode) && (!e.status || "rendered" !== e.status && "targetingSet" !== e.status) && this.isValidBidSize({
                size: e.size
            }))).sort(((e, t) => t.cpm - e.cpm)) : []
        }
        getLargestValidTargetSize({
            placement: e
        }) {
            let t, {
                sizes: n
            } = e;
            return n = n.filter((e => Array.isArray(e) && !mi(e))).sort(((e, t) => t[0] - e[0] || t[1] - e[1])), n.some((e => {
                if (xo.map((e => e.join("x"))).includes(e.join("x"))) return t = e, !0
            })), t
        }
        getLargestPossibleDimensions({
            placement: e
        }) {
            let {
                sizes: t
            } = e;
            return [t.sort(((e, t) => t[0] - e[0]))[0][0], t.sort(((e, t) => t[1] - e[1]))[0][1]]
        }
        _renderSynthethicBid({
            placement: e,
            bids: t,
            size: n
        }, i) {
            const r = document.getElementById(i.adUnitCode).querySelector('div[id*="google_ads_iframe_"]');
            r.classList.add("_fs-sf"), n = this.getLargestPossibleDimensions({
                placement: e
            }), this.applyTargetElementStyling({
                size: n,
                targetElement: r
            }), fsprebid.markWinningBidAsUsed({
                adUnitCode: i.adUnitCode,
                adId: i.adId
            }), this.renderOptionalAds({
                placement: e,
                bids: t,
                size: n,
                path: "prebid",
                targetElement: r
            }), this.logs.add(`Superflex won the bid for ${e.name}`), this.logs.add(`Bids: ${t.length}`), this.logs.add(`CPMs: ${t.map((e=>e.cpm)).join(", ")}`), this.logs.add(`adIds: ${t.map((e=>e.adId)).join(", ")}`), this.logs.show(So)
        }
        getSyntheticBid({
            placement: e,
            size: t,
            bids: n
        }) {
            const i = function(e = 100) {
                let t = window.fsprebid.getConfig().customPriceBucket.buckets.find((t => {
                    if (e <= 1 * t.max && e >= 1 * t.min) return t
                }));
                return function(e, t, n = 1) {
                    const i = Number.isInteger(t.precision) ? t.precision : 2,
                        r = t.increment * n,
                        s = t.min * n,
                        a = Math.pow(10, i + 2),
                        o = (e * a - s * a) / (r * a),
                        d = Math.floor(o) * r + s;
                    return Number(d.toFixed(10)).toFixed(i)
                }(e, t)
            }(n.map((e => e.cpm)).reduce(((e, t) => e + t), 0));
            let r = bi(),
                s = Object.assign({}, n[0], {
                    adId: r,
                    bidder: "superflex",
                    bidderCode: "superflex",
                    cpm: i,
                    pbAg: i,
                    pbCg: i,
                    pbDg: i,
                    pbHg: i,
                    pbLg: i,
                    pbMg: i,
                    ttl: 15,
                    adserverTargeting: {
                        custom_bidder_size: `superflex_${t[0]}x${t[1]}`,
                        hb_adid: r,
                        hb_bidder: "superflex",
                        hb_format: "banner",
                        hb_pb: i,
                        hb_size: `${t[0]}x${t[1]}`
                    },
                    width: t[0],
                    height: t[1],
                    size: `${t[0]}x${t[1]}`,
                    renderer: {
                        url: "https://a.pub.network/superflex/loader.js",
                        render: this._renderSynthethicBid.bind(this, {
                            placement: e,
                            bids: n,
                            size: t
                        })
                    }
                });
            return delete s.ad, freestar.fsDfpId && (s.adserverTargeting.fspbg = "freestar"), s
        }
        getBidsBasedOnRemainingSpace({
            bids: e,
            targetingParam: t,
            remainingSpace: n
        }) {
            let i = n;
            return e.filter((e => e[t] <= i && (i -= e[t], !0))).sort(((e, t) => t.cpm - e.cpm))
        }
        isValidBidSize({
            size: e
        }) {
            return Eo.map((e => e.join("x"))).includes(e)
        }
        renderPrebidIFrame({
            targetElement: e,
            bid: t,
            iteration: n = 1
        }) {
            const i = sn({
                type: "iframe",
                id: `_fs-sf-${t.adId}-${n}`,
                classList: ["_fs-sf"],
                attributes: [{
                    width: t.width
                }, {
                    height: t.height
                }, {
                    frameBorder: 0
                }, {
                    marginHeight: 0
                }, {
                    marginWidth: 0
                }, {
                    scrolling: "no"
                }, {
                    style: `width:${t.width}px; height:${t.height}px;`
                }]
            });
            e.appendChild(i), fsprebid.renderAd(document.querySelector("#_fs-sf-" + t.adId + "-" + n).contentWindow.document, t.adId)
        }
        renderGAMDiv({
            targetElement: e,
            placement: t,
            bid: n,
            iteration: i = 1
        }) {
            const r = sn({
                type: "div",
                id: `_fs-sf-${n.adId}-${i}`,
                classList: ["_fs-sf"],
                attributes: [{
                    style: `width:${n.width}px; height:${n.height}px;`
                }]
            });
            e.appendChild(r);
            const s = {
                targeting: n.adserverTargeting
            };
            s.targeting.fs_ad_product = "superflex-child-" + i;
            const a = Jt({
                placement: t,
                sizes: [
                    [n.width, n.height]
                ],
                id: `_fs-sf-${n.adId}-${i}`,
                slotConfig: s
            });
            googletag.pubads().refresh([a])
        }
        renderOptionalAds({
            placement: e,
            bids: t,
            path: n = "gam",
            targetElement: i
        }) {
            let r, s = 1;
            for (const a of t) {
                switch (n) {
                    case "gam":
                        this.renderGAMDiv({
                            targetElement: i,
                            placement: e,
                            bid: a,
                            iteration: s
                        });
                        break;
                    case "prebid":
                        r = i.querySelector("iframe"), r.style.position = "absolute", r.style.zIndex = 100, this.renderPrebidIFrame({
                            targetElement: i,
                            placement: e,
                            bid: a,
                            iteration: s
                        })
                }
                s += 1
            }
        }
        handleAuctionEndValidBids(e, t, n, i) {
            const r = this.getLargestValidTargetSize({
                placement: e
            });
            if (!r) return;
            const s = this.getDirection({
                    size: r
                }),
                a = "row" === s ? "width" : "height",
                o = this.getRemainingSpace({
                    direction: s,
                    size: r
                });
            (n = this.getBidsBasedOnRemainingSpace({
                bids: n,
                targetingParam: a,
                remainingSpace: o
            })).length < 2 || this.createAndLogSyntheticBid(n, e, r, t, i)
        }
        createAndLogSyntheticBid(e, t, n, i, r) {
            const s = this.getSyntheticBid({
                placement: t,
                size: n,
                bids: e
            });
            r.bidsReceived.push(s);
            const a = Wt({
                    elementId: i.code
                }),
                o = a.getTargetingMap();
            o.fs_ad_product && "banner" !== o.fs_ad_product[0] || Pn(a, t.name, null, {
                fs_ad_product: "superflex"
            }), this.logs.add(`Synthetic bid created for ${t.name}`), this.logs.add(`Bids: ${e.length}`), this.logs.add(`Combined CPMs: ${s.cpm}`), this.logs.add(`CPMs: ${e.map((e=>e.cpm)).join(", ")}`), this.logs.add(`adIds: ${e.map((e=>e.adId)).join(", ")}`), this.auctionEndLogStatus = Ao
        }
        auctionEndCallback(e) {
            this.logs.add("Calling registerSuperflexCallbacks");
            const {
                adUnits: t
            } = e;
            t.forEach((t => {
                this.auctionEndLogStatus = Io;
                try {
                    const n = Ti({
                        name: ve({
                            slotId: t.code
                        })
                    });
                    if (!n || !this.getPlacementsNames().includes(n.name)) return;
                    if (n && n.sizeMappings && !this.isViewportSuperflex(n.sizeMappings)) return;
                    let i = e.bidsReceived.filter((e => e.adUnitCode === t.code));
                    const r = this.getValidBids({
                        bids: i
                    });
                    if (!r.length) return;
                    this.handleAuctionEndValidBids(n, t, r, e)
                } finally {
                    this.logs.show(this.auctionEndLogStatus)
                }
            }))
        }
        isViewportSuperflex(e) {
            let t = 0;
            for (let n = 0; n < e.length; n++) {
                let i = e[n];
                i.viewport.size[0] > t && bn() >= i.viewport.size[0] && (t = i.viewport.size[0])
            }
            return !!e.find((e => e.viewport.size[0] === t)).superflex
        }
        slotRenderEndedCallback(e) {
            try {
                if (e.isEmpty) return;
                const t = e.slot.getSlotElementId(),
                    n = Ti({
                        name: ve({
                            slotId: t
                        })
                    });
                if (!n || !this.getPlacementsNames().includes(n.name)) return;
                if (n && n.sizeMappings && !this.isViewportSuperflex(n.sizeMappings)) return;
                let {
                    bids: i
                } = fsprebid.getBidResponsesForAdUnitCode(t);
                if (i.some((e => e.adUnitCode === t && "superflex" === e.bidderCode && "rendered" === e.status))) return;
                i = this.getValidBids({
                    bids: i
                }), 0 !== i.length && setTimeout((() => this.handleSlotRenderEndedValidBids(t, n, i)), 250)
            } finally {
                this.logs.show()
            }
        }
        handleSlotRenderEndedValidBids(e, t, n) {
            const i = document.getElementById(e);
            if (!i) return;
            const r = i.querySelector('div[id*="google_ads_iframe_"]');
            if (!r || r.classList.contains("_fs-sf")) return;
            const s = i.querySelector('iframe[id*="google_ads_iframe_"]'),
                a = this.getIframeSize(s);
            if (a.width <= 1 || a.height <= 1) return;
            const o = this.getLargestPossibleDimensions({
                    placement: t
                }),
                d = this.getDirection({
                    size: o
                }),
                l = "row" === d ? "width" : "height";
            let c = this.getRemainingSpace({
                direction: d,
                size: o
            });
            c -= a[l], c <= 0 || 0 !== (n = this.getBidsBasedOnRemainingSpace({
                bids: n,
                targetingParam: l,
                remainingSpace: c
            })).length && (this.applyTargetElementStyling({
                size: o,
                targetElement: r
            }), this.renderOptionalAds({
                placement: t,
                bids: n,
                path: "gam",
                targetElement: r
            }), this.logs.add(`GAM won, sending additional ${n.length} ad(s) to GAM for ${t.name}`), this.logs.add(`Bids: ${n.length}`), this.logs.add(`CPMs: ${n.map((e=>e.cpm)).join(", ")}`), this.logs.add(`adIds: ${n.map((e=>e.adId)).join(", ")}`), this.logs.show(ko))
        }
        getIframeSize(e) {
            if (e.contentDocument && e.contentDocument.body) {
                const {
                    clientWidth: t,
                    clientHeight: n
                } = e.contentDocument.body;
                if (t > 1 && n > 1) return {
                    width: t,
                    height: n
                }
            }
            return e.getBoundingClientRect()
        }
        registerSuperflexCallbacks() {
            fsprebid.onEvent("auctionEnd", this.auctionEndCallback.bind(this)), googletag.pubads().addEventListener("slotRenderEnded", this.slotRenderEndedCallback.bind(this)), this.logs.show()
        }
    }
    let To = null,
        Co = null,
        Ro = null;

    function No() {
        (window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop) > To.topAdhesionDistanceToRemove && (freestar.deleteAdSlots(To.name), Co.parentNode.removeChild(Co), window.removeEventListener("scroll", No, !1), clearTimeout(Ro))
    }

    function Mo(e, t) {
        To = e, setTimeout((function() {
            performance.mark("topAdhesion-initialization-start");
            let n = ki(),
                i = function(e) {
                    let t = sn({
                        type: "div",
                        id: e.name
                    });
                    return Co = t, t
                }(e);
            i && n && Si(n, i, e) && (t(null, Ci({
                placement: e
            })), Ro = setTimeout((function() {
                freestar.deleteAdSlots(e.name), i.parentNode.removeChild(i), window.removeEventListener("scroll", No, !1)
            }), 1e3 * e.topAdhesionTime), window.addEventListener("scroll", No), performance.mark("topAdhesion-initialization-end"))
        }), 1e3)
    }
    class Do {
        constructor(e) {
            this.placement = e, this.options = be({
                placement: e,
                type: "pushdownOptions"
            }), this.clsEnabled = Le() || this.options.clsEnabled, this.clsElement = this.clsElementFetch(), this.pushdownElement = this.pushdownElementFetch(), this.closeButton = void 0, this.removedSticky = !1, this.optCookieName = "fs.pushdown.optout", this.initStickyTimeRemove = !1, this.initStickyType = !1
        }
        clsElementFetch() {
            return !(!Le() && !this.options.clsEnabled) && document.getElementById(this.placement.name + "-pushdown-cls")
        }
        pushdownElementFetch() {
            let e = document.getElementById(this.placement.name);
            if (e || (e = document.createElement("div"), e.id = this.placement.name, this.pushdownElement = e), e.style.backgroundColor = this.placement.pushdownOptions.backgroundRgba ? this.placement.pushdownOptions.backgroundRgba : 'rgba("247,247,247,.9")', this.options.zIndex && this.options.zIndex > 0 && (e.style.zIndex = this.options.zIndex), e.setAttribute("align", "center"), this.clsElement) {
                let t = document.createElement("div");
                t.classList.add("wrapper-" + this.placement.name), t.classList.add("fs-pushdown"), t.style.left = "-9999px", t.style.visibility = "hidden", t.appendChild(e), this.clsElement.appendChild(t)
            }
            if (!this.clsEnabled && (this.options.isBodyZero && Si(ki(), this.pushdownElement, this.placement), this.options.domElement && this.options.domElement.length > 0)) {
                const e = document.querySelectorAll(this.options.domElement)[this.options.domElementIndex && this.options.domElementIndex > 0 ? this.options.domElementIndex : 0];
                this.pushdownDomWorker(e)
            }
            return this.options.customCode && this.options.customCode.length > 1 && xi(this.options.customCode), e
        }
        pushdownDomWorker(e) {
            e && e.parentElement && (this.pushdownElement.className = "fs-pushdown", e.parentElement.insertBefore(this.pushdownElement, e))
        }
        valid() {
            return this.clsEnabled && !this.clsElement ? (freestar.log(1, `Pushdown: CLS Enabled and CLS Element ${this.placement.name+"-pushdown-cls"} is not found. Exiting Pushdown!`), !1) : this.clsEnabled && this.clsElement ? (freestar.log(1, `Pushdown: CLS Enabled and CLS Element ${this.placement.name+"-pushdown-cls"} was found. Continuing with Pushdown.`), !0) : (freestar.log(1, "Pushdown: CLS Not Enabled. Continuing with Pushdown."), !0)
        }
        userHasOptedOut() {
            return ot({
                name: this.optCookieName
            }) ? (freestar.log(1, "Pushdown: Cordial is active and the user has opted out."), !0) : (freestar.log(1, "Pushdown: Coridal is either not active or the user has not opted out. The Pushdown process may continue."), !1)
        }
        remove() {
            this.pushdownElement && this.pushdownElement.parentElement && (this.pushdownElement.parentElement.removeChild(this.pushdownElement), this.pushdownElement = void 0), this.clsEnabled && this.clsElement && this.clsElement.parentNode && (this.clsElement.parentNode.removeChild(this.clsElement), this.clsElement = void 0)
        }
        addCloseButton() {
            this.pushdownElement.querySelector("#fs-pushdown-close-button") || (this.closeButton = sr(), this.closeButton.setAttribute("id", "fs-pushdown-close-button"), this.closeButton.className = this.closeButton.className += " fs-close-button fs-close-button-pushdown"), this.pushdownElement.appendChild(this.closeButton), this.closeButton.addEventListener("click", function() {
                !0 === this.options.cordial && at({
                    name: this.optCookieName,
                    value: !0
                });
                const e = ["fs-pushdown-close-button", freestar.pushdownControl.placement.name];
                freestar.pushdownControl.clsEnabled && freestar.pushdownControl.clsElement && e.push(freestar.pushdownControl.clsElement.id), e.forEach((e => {
                    try {
                        const t = document.getElementById(e);
                        t && t.parentNode.removeChild(t)
                    } catch (e) {
                        freestar.log(1, `Error: ${e}`)
                    }
                }))
            }.bind(this))
        }
        stickyType() {
            this.pushdownElement && this.placement && !this.removedSticky && (this.clsEnabled && this.clsElement ? (this.clsElement.classList.remove("fs-pushdown"), this.clsElement.classList.add("fs-pushdown-sticky")) : this.pushdownElement.className = this.placement.pushdownOptions.isSticky ? "fs-pushdown-sticky" : "fs-pushdown")
        }
        stickyTimeRemove() {
            if (this.pushdownElement && this.options.timer && this.options.timer > 1) {
                let e = 0;
                const t = setInterval((() => {
                    document.hasFocus() && Oi(this.pushdownElement) && (e += 1, e >= this.options.timer && (this.clsEnabled && this.clsElement ? (this.clsElement.classList.remove("fs-pushdown-sticky"), this.clsElement.classList.add("fs-pushdown"), this.clsElement.style.position = "relative") : this.pushdownElement.style.position = "relative", this.pushdownElement.className = "fs-pushdown", this.removedSticky = !0, clearInterval(t)))
                }), 1e3)
            }
        }
        postGamResponse({
            event: e
        }) {
            if (this.isPushdown(e)) {
                if (e.isEmpty) return;
                this.clsElement && (this.pushdownElement.parentNode.style.left = "0", this.pushdownElement.parentNode.style.visibility = "visible"), this.initStickyType || (this.initStickyType = !0, this.stickyType()), this.initStickyTimeRemove || (this.initStickyTimeRemove = !0, this.stickyTimeRemove()), this.addCloseButton()
            }
        }
        isPushdown(e) {
            return !(!e || !e.slot) && this.placement.name === e.slot.getSlotElementId()
        }
    }
    const Bo = "Pushdown: ";

    function Po(e, t) {
        if (performance.mark("pushdown-initialization-start"), Nn({
                name: "pushdown"
            }) || !e || !e.pushdownOptions) return void window.freestar.log(1, Bo + "pushdown is either disabled or options not found. Exiting!");
        const n = new Do(e);
        if (n.valid() && !n.userHasOptedOut()) {
            freestar.pushdownControl = n;
            const i = Ci({
                placement: n.placement,
                slotId: e.slotId
            });
            t && i ? t(null, i) : t && !i ? t(!0) : i && (Fi({
                adUnits: i.bidObject
            }), ji([i.bidObject.code], [i.slot]))
        }
        performance.mark("pushdown-initialization-end")
    }
    const zo = {},
        Lo = function(e, t) {
            if (freestar.log({
                    title: "DYNAMICADS"
                }, "called", e.name), Nn({
                    name: "dynamicAds"
                })) return !1;
            let n = freestar.config.dynamicAdChannel;
            if (!e) return !1;
            if (zo[e.name] ? Date.now() - zo[e.name].called <= 750 && freestar.log({
                    title: "DYNAMICADS"
                }, e.name, "THROTTLING") : zo[e.name] = {
                    called: Date.now()
                }, n) {
                let t = freestar.config.channel;
                e.dfpId.indexOf("{{channel}}") > -1 && (t = "{{channel}}"), e.dfpId = e.dfpId.replace(t, n), freestar.log({
                    title: "DYNAMICADS"
                }, " In dynamic ads Setting the dfp id to:" + e.dfpId)
            }
            this.placement = e, this.daHelper = t, this.options = be({
                placement: e,
                type: "dynamicAdOptions"
            }), this.isPixels = !1;
            let i = 1,
                r = !0;
            if (!this.placement.stickyAdOptions.stickyAdEnabled && this.placement.sizes && Array.isArray(this.placement.sizes) && this.placement.sizes.length) {
                const e = document.getElementById("style_" + this.placement.name),
                    t = e || sn({
                        type: "style",
                        id: "style_" + this.placement.name
                    });
                t.innerHTML = `\n            div[name='${this.placement.name}']:not(div[id*='_slot']) {\n                display: flex;\n                align-items: center;\n                justify-content: center;\n                min-height: ${this.placement.sizes.slice(-1)[0][1]}px !important;\n            }\n        `;
                var s = document.querySelector("script");
                s.parentNode.insertBefore(t, s)
            }
            const a = setInterval((() => {
                if (this.parent = document.querySelector(this.options.parentElement), this.children = this.parent ? [...document.querySelectorAll(this.options.parentElement + " > " + this.options.childElement)].filter((e => !e.classList.contains("fs-dynamic"))) : "", 1 == i && freestar.log({
                        title: "DYNAMICADS"
                    }, this.placement.name, "Searching for required parent/child nodes"), i > 8 && (freestar.log({
                        title: "DYNAMICADS"
                    }, this.placement.name, "ERROR: could not get required parent/child nodes"), clearInterval(a)), i += 1, this.children && this.parent) {
                    clearInterval(a), freestar.log({
                        title: "DYNAMICADS"
                    }, e.validAdSizes, this.children, this.parent), this.validIO = !1, this.timeout = window.freestar.fsdata.timeout < e.timeout ? window.freestar.fsdata.timeout : e.timeout || window.freestar.fsdata.timeout, this.className = this.options.className || "fs-dynamic", this.slotId = e.name, this.dfpId = e.dfpId, this.pbjsObject = $n(e), this.placement = e, this.blockList = e.dynamicAdOptions.elementBlocklist, this.scrollDistance = this.daHelper.fetchScrollDistance(e);
                    try {
                        IntersectionObserver && (this.validIO = !0)
                    } catch (e) {
                        freestar.log(1, `Error: ${e}`)
                    }
                    e.validAdSizes && this.init()
                }
            }), 250);
            this.init = function() {
                performance.mark("dynamicAds-initialization-start"), this.appendSlotContainers(), (!this.validIO || this.options.ioDisabled || freestar.fsdata.dynamicIODisabled) && window.addEventListener("scroll", function(e) {
                    this.fillEmtpySlots(e)
                }.bind(this)), performance.mark("dynamicAds-initialization-end")
            }, this.appendSlotContainers = function() {
                let e = 0,
                    t = !1;
                const n = this.children.length,
                    {
                        startNth: i = 0,
                        everyNElements: r = 1
                    } = this.options;
                for (let s = 0; s < n; s++)
                    if (s > i && s % r == 0 && (0 !== s || t)) {
                        let n = this.children[s],
                            i = !0;
                        const a = n.getAttribute("fsad");
                        if ((n.classList.contains("fs-dynamic") || n.previousElementSibling && n.previousElementSibling.classList && n.previousElementSibling.classList.contains("fs-dynamic")) && (i = !1), n.previousElementSibling && n.previousElementSibling.nodeName && s > 0 && this.blockList.indexOf(n.previousElementSibling.nodeName) > -1) {
                            i = !1;
                            const e = this.children[s += 1];
                            r > 1 && e && -1 === this.blockList.indexOf(e.previousElementSibling.nodeName) && (i = !0, n = e)
                        }!a && i ? (t = !1, e++, n.setAttribute("data-inc", e.toString()), this.slotFactory(e, s)) : "no" === a && (t = !0)
                    }
            }, this.slotFactory = function(t, n) {
                if (Le() && r) {
                    if (this.children[n].getBoundingClientRect().top < window.innerHeight) return void freestar.log(49, "DynamicAds", e.name, t, "Page Speed Optimization is in effect & targeted element is in view, exiting...");
                    r = !1
                }
                const i = this.slotId + t;
                freestar.dynamicSlots.push(i);
                const s = sn({
                        type: "div",
                        id: i,
                        classList: ["fs-dynamic"],
                        attributes: [{
                            "data-slot": "waiting"
                        }, {
                            "data-freestar-ad": gi({
                                placement: e
                            })
                        }, {
                            name: e.name
                        }]
                    }),
                    a = sn({
                        type: "div",
                        id: i + "_slot"
                    });
                s.append(a), we({
                    placementName: e.name,
                    slotId: i
                }), De() ? jt.refreshLibraryCreator(i) : freestar.refreshLibraryCreator(i);
                const o = this.options.insertBefore ? this.children[n] : this.children[n].nextSibling;
                this.children[n].parentNode.insertBefore(s, o), this.validIO && this.options.ioDisabled || !freestar.fsdata.dynamicIODisabled ? this.scrollDistance ? this.daHelper.createIntersectionObserver(i, s, this.scrollDistance) : this.daHelper.loadDynamicAd({
                    placement: e,
                    slotId: a.id
                }) : this.isSlotActive(s)
            }, this.fillEmtpySlots = function(e) {
                let t = window.document.querySelectorAll('[data-slot="waiting"]');
                !t.length && e && window.removeEventListener("scroll", e);
                for (let e = 0; e < t.length; e++) this.isSlotActive(t[e])
            }, this.isSlotActive = function(e) {
                const t = e.scrollHeight,
                    n = window.innerHeight && document.documentElement.clientHeight ? Math.min(window.innerHeight, document.documentElement.clientHeight) : window.innerHeight || document.documentElement.clientHeight,
                    i = e.getBoundingClientRect().top + t - 800;
                return i >= -300 && i <= n && this.fillSlot(e), i > n
            }, this.fillSlot = function(e) {
                const t = Ti({
                    name: e.getAttribute("name")
                });
                if (null != t) {
                    let n = this.pbjsObject;
                    e.setAttribute("data-slot", "fetched"), n.code = e.id, googletag.cmd.push((function() {
                        let i = n.sizes || [];
                        n.fluidAd && !i.includes("fluid") && i.push("fluid"), Qt({
                            elementId: e.id
                        }), Pn(Jt({
                            placement: t,
                            sizes: i,
                            id: e.id
                        }), e.id, null, {
                            fs_ad_product: Fn(t)
                        }), n = $n(t), n.code = e.id, freestar.requests.que.push(n), Tn()
                    }))
                }
            }
        };
    class jo {
        constructor(e, t) {
            this.placement = e, this.daHelper = t, this.slotId = e.name, this.segmentHeight = 0, this.scrollDistance = this.daHelper.fetchScrollDistance(e), this.currentDocumentHeight = 0, this.slotIncrement = 0, this.disallowedElements = [".fs-dynamic", ...this.daHelper.options.da2ElementBlocklist]
        }
        slotFactory(e, t) {
            if (!this.placement.sizes || 0 === this.placement.sizes.length) return;
            const n = this.slotId + e,
                i = sn({
                    type: "div",
                    id: n,
                    classList: ["fs-dynamic"],
                    attributes: [{
                        "data-slot": "waiting"
                    }, {
                        "data-freestar-ad": gi({
                            placement: this.placement
                        })
                    }, {
                        name: this.placement.name
                    }, {
                        style: `min-height:${this.placement.sizes[0][1]}px;`
                    }]
                }),
                r = sn({
                    type: "div",
                    id: n + "_slot"
                });
            i.append(r), t.parentNode.insertBefore(i, t), this.scrollDistance ? this.daHelper.createIntersectionObserver(n, i, this.scrollDistance) : this.daHelper.loadDynamicAd({
                placement: this.placement,
                slotId: n
            })
        }
        segment() {
            const e = this.getTotalHeight();
            let t = null;
            for (let n = this.currentDocumentHeight + this.segmentHeight; n <= e; n += this.segmentHeight) {
                const e = n - this.segmentHeight / 2;
                let i = this.getValidElementInSegment(e);
                i && (this.slotIncrement++, this.slotFactory(this.slotIncrement, i), t = n)
            }
            if (null !== t) {
                const e = this.currentElements.findIndex((e => e.offsetTop > t)),
                    n = -1 === e ? 1 / 0 : e;
                this.currentElements.splice(0, n), this.currentDocumentHeight = t
            }
        }
        getTotalHeight() {
            return document.documentElement.scrollHeight
        }
        getDensityForHeight(e, t) {
            const n = e.filter((e => e.viewportHeight <= t)).sort(((e, t) => t.viewportHeight - e.viewportHeight));
            return n.length && n[0].density > 0 ? n[0].density : 1
        }
        getValidElementInSegment(e, t = this.currentElements) {
            if (0 === t.length) return;
            const n = !t[0].previousElementSibling && t[0].getBoundingClientRect ? t[0].getBoundingClientRect().top : 0;
            return t.find((t => t.offsetTop + t.offsetHeight >= e - this.segmentHeight / 2 && t.offsetTop + t.offsetHeight <= e + this.segmentHeight / 2 && t.offsetTop + t.offsetHeight + n > e - 10 - this.segmentHeight / 2 && !this.disallowedElements.some((e => t.previousElementSibling && t.previousElementSibling.matches(e.toLowerCase()))) && !this.disallowedElements.some((e => t.parentElement && t.parentElement.matches(e.toLowerCase())))))
        }
        init() {
            if (Nn({
                    name: "dynamicAds"
                })) return !1;
            freestar.log({
                title: "Dynamic Ads V2"
            }, "Called", this.placement.name);
            const e = this.daHelper.options.da2ViewportsDensities,
                t = window.innerHeight,
                n = this.getDensityForHeight(e, t);
            this.currentElements = [...document.querySelectorAll(this.daHelper.options.da2ElementTarget)], this.segmentHeight = Math.floor(t / n), this.segment(), this.addMutationObserver(), this.debug()
        }
        debug() {
            if (!freestar.debug) return;
            [...document.querySelectorAll(".fs-dav2-debug")].forEach((e => e.parentElement.removeChild(e)));
            const e = document.createElement("style");
            e.className = "fs-dav2-debug", this.disallowedElements.forEach((t => {
                const n = t.split(" ").pop();
                e.textContent = `\n            .fs-dynamic + ${n} {\n                position: relative;\n            }\n            .fs-dynamic + ${n}:before {\n                content: '';\n                border: 2px dotted lightgreen;\n                position: absolute;\n                width: 102%;\n                height: 102%;\n                top: -1%;\n                left: -1%;\n                background-color: rgba(144,238,144,0.15);\n            }\n            `
            })), e.textContent += "\n            .fs-dav2-debug.fs-dav2-page-marker {\n                pointer-events:none; \n                position:absolute;\n                width: 100%;\n                height: 2px;\n                background-color: lightblue;\n                margin: 0 auto; \n                display: block;\n                z-index:100;\n            }\n            .fs-dav2-debug.fs-dav2-page-marker:after {\n                content: 'END OF PAGE';\n                font-size: 10px;\n                position: absolute;\n                top: -4px;\n                left: 3px;\n            }\n            .fs-dav2-debug.fs-dav2-segment-marker {\n                pointer-events:none; \n                position: absolute; \n                width: 100%;\n            }\n            .fs-dav2-debug.fs-dav2-target-marker {\n                pointer-events:none; \n                position:absolute;\n                width: 100%;\n                height: 15px;\n                background-color: rgb(0 195 137 / 50%);\n                margin: 0 auto; \n                display: block;\n            }\n            .fs-dav2-debug.fs-dav2-target-marker:after {\n                content: 'TARGET AREA';\n                font-size: 10px;\n                position: absolute;\n                top: 2.5px;\n                left: 3px;\n            }\n        ", document.head.appendChild(e);
            const t = this.getTotalHeight();
            for (let e = window.innerHeight; e <= t; e += window.innerHeight) {
                const t = document.createElement("div");
                t.className = "fs-dav2-debug fs-dav2-page-marker", t.style = `top: ${e-3}px;`, document.body.appendChild(t)
            }
            for (let e = 0; e <= t; e += this.segmentHeight) {
                const t = document.createElement("div");
                t.className = "fs-dav2-debug fs-dav2-segment-marker", t.style = `top: ${e}px; height: ${this.segmentHeight}px;`;
                const n = document.createElement("div");
                n.className = "fs-dav2-debug fs-dav2-target-marker", n.style = `top: ${this.segmentHeight/2}px;`, t.appendChild(n), document.body.appendChild(t)
            }
        }
        addMutationObserver() {
            const e = new MutationObserver((e => {
                    (e = e.filter((e => "childList" === e.type && e.addedNodes))).forEach((e => {
                        let {
                            addedNodes: t
                        } = e;
                        if (t = [...t].filter((e => e instanceof Element)), 0 !== t.length) {
                            let e = [];
                            t.forEach((t => {
                                let n = [...t.querySelectorAll(this.daHelper.options.da2ElementTarget)];
                                0 !== n.length && (e = e.concat(n)), t.matches(this.daHelper.options.da2ElementTarget) && e.push(t)
                            })), 0 !== e.length && (this.currentElements.push(...e), this.segment(), this.debug())
                        }
                    }))
                })),
                t = document;
            e.observe(t, {
                attributes: !1,
                childList: !0,
                characterData: !1,
                subtree: !0
            })
        }
    }
    class Fo {
        constructor(e, t) {
            this.observers = {}, this.options = e, this.isPixels = !1, this.slidingAdUnitHelper = t
        }
        loadDynamicAd({
            placement: e,
            slotId: t
        }) {
            ge({
                placement: e,
                type: "slidingUnitOptions"
            }) && yr({
                adUnit: e,
                slotId: t
            }), e.stickyAdOptions && e.stickyAdOptions.stickyAdEnabled && this.slidingAdUnitHelper.attachSlidingUnit({
                adUnit: e,
                slotId: t.endsWith("_slot") ? t.slice(0, -5) : t
            }), freestar.log({
                title: "Dynamic Ad Helper"
            }, `New ad slots invoked for ${e.name} via intersection observer`), freestar.newAdSlots([{
                placementName: e.name,
                slotId: t,
                skipSAU: !0
            }])
        }
        intersectionCallback(e) {
            e.forEach((e => {
                if (e.isIntersecting) {
                    const t = e.target.id;
                    if (!t) return;
                    let n = document.getElementById(t);
                    const i = n.getAttribute("name");
                    if (!i) return;
                    if ("complete" === n.getAttribute("data-slot")) return void this.observers[t].unobserve(e.target);
                    const r = Ti({
                        name: i
                    });
                    if (!r || !r.name) return;
                    n.setAttribute("data-slot", "complete"), this.observers[t].unobserve(e.target), n.querySelector(`[id*='${n.id}_slot']`) && (n = n.querySelector(`[id*='${n.id}_slot']`)), this.loadDynamicAd({
                        placement: r,
                        slotId: n.id
                    })
                }
            }))
        }
        fetchScrollDistance(e) {
            if (e.selectedSize && e.selectedSize.dynamicAdsHeightPercentage > -1) return e.selectedSize.dynamicAdsHeightPercentage;
            this.isPixels = !0;
            const t = this.options.scrollDistance || freestar.fsdata.dynamicAdsScrollDistance;
            return t >= 0 && t
        }
        createIntersectionObserver(e, t, n) {
            const i = new IntersectionObserver(this.intersectionCallback.bind(this), {
                rootMargin: `${n}${this.isPixels?"px":"%"}`
            });
            i.observe(t), this.observers[e] = i
        }
    }
    let Uo = !1;

    function qo({
        firstAdRequestedElement: e
    }) {
        googletag.pubads().addEventListener("slotRenderEnded", (function(t) {
            e && t.slot.getSlotElementId() === e && P.logMark({
                    markerName: A.pubfigSlotRenderEnded,
                    compareTo: [A.pubfigSlotRequested]
                }),
                function({
                    event: e
                }) {
                    const t = e.slot.getSlotElementId(),
                        n = freestar.fsdata.placements.filter((e => e.name === t))[0];
                    if (n) {
                        const {
                            standAloneVideoOptions: t
                        } = n;
                        if (t && t.videoId && t.videoId.length && freestar.fsdata.placementVideos.filter((e => e.id === n.standAloneVideoOptions.videoId))[0]) {
                            freestar.standAlonePlayer && freestar.standAlonePlayer.callback && "function" == typeof freestar.standAlonePlayer.callback && (freestar.standAlonePlayer.callback(null, {
                                displayAdServed: !e.isEmpty,
                                completed: !0
                            }), freestar.standAlonePlayer.callback = void 0);
                            const t = document.getElementById(n.name);
                            if (t) {
                                const e = t.querySelector("div[id^=google_ads_iframe_]");
                                e && (e.className += "center-ad")
                            }
                        }
                    }
                }({
                    event: t
                }), Uo || (Uo = !0, freestar.fsdata.browsiEnabled && Pt.allowBrowsi() && (! function() {
                    if (window.BrowsiScriptLoaded) return;
                    const e = sn({
                        type: "script",
                        id: "browsi-tag",
                        src: "https://cdn.browsiprod.com/bootstrap/bootstrap.js",
                        attributes: [{
                            "data-pubKey": "freestar"
                        }, {
                            "data-siteKey": "d_mapping"
                        }]
                    });
                    e.type = "text/javascript", e.async = !0, e.onload = function() {
                        window.BrowsiScriptLoaded = !0
                    }, document.getElementsByTagName("head")[0].appendChild(e)
                }(), freestar.log({
                    title: "Browsi"
                }, "Script loaded")))
        }))
    }
    const $o = ({
        domSelector: e
    }) => document.querySelector(e);

    function Ho({
        placement: e
    }) {
        if (function() {
                const {
                    removeFooter: e,
                    specialAdhesionRemoved: t,
                    customFooter: n
                } = freestar.fsdata;
                if (e || t || n) {
                    const e = ["#fs-select-footer-remove", "#fs-special-remove"];
                    for (let t = 0; t < e.length; t++)
                        if ($o({
                                domSelector: e[t]
                            })) return !0
                }
                return !1
            }()) return !0;
        const {
            remove: t,
            adhesionRemove: n,
            add: i
        } = be({
            placement: e,
            type: "stickyFooterOptions"
        });
        return !(!t || !$o({
            domSelector: t
        })) || (!(!n || !$o({
            domSelector: n
        })) || !(!i || document.getElementById("fs-select-footer")))
    }
    const Vo = (e, t) => M(t) ? (t.timeCreated = function({
        time: e,
        disableUTCString: t = !1
    }) {
        const n = {
                thirtyMinutes: 18e5,
                twentyFourHours: 864e5,
                fiveYears: 15768e7,
                twentyYears: 63072e7
            },
            i = new Date,
            r = () => i.setTime(i.getTime() + n[e]);
        return t ? r() : (r(), i.toUTCString())
    }({
        time: "twentyFourHours",
        disableUTCString: !0
    }), t) : void 0;

    function Go({
        className: e,
        id: t
    }) {
        return sn({
            type: "div",
            classList: [e],
            id: t
        })
    }

    function Wo() {
        if (Nn({
                name: "interstitial"
            })) return !1;
        if ("desktop" !== window.freestar.deviceInfo.device.type || function() {
                const e = localStorage.getItem("fs_int_complete");
                return !(!e || 1 !== Number(e))
            }()) return freestar.log({
            title: "Interstitial"
        }, "Already engaged not allowed again in this session!"), !1; {
            const e = window.freestar.fsdata.placements.filter((e => e.interstitialOptions && e.interstitialOptions.active && e.interstitialOptions.networkId))[0];
            if (!e) return;
            const {
                networkId: t,
                timeToDisplay: n = 60,
                message: i = "Recommended for You"
            } = e.interstitialOptions;
            if (t && n && i) {
                window.freestar.log({
                    title: "Interstitial"
                }, "placement found ", e), window.freestar.log({
                    title: "Interstitial"
                }, "Start Time ", n), window.freestar.log({
                    title: "Interstitial"
                }, "Message ", i);
                const r = sn({
                        type: "div",
                        id: `zergnet-widget-${t}`
                    }),
                    s = Go({
                        className: "fs-interstitial-overlay"
                    }),
                    a = Go({
                        className: "fs-interstitial-container"
                    }),
                    o = Go({
                        className: "fs-interstitial-content"
                    }),
                    d = Go({
                        className: "fs-interstitial-message-container"
                    }),
                    l = Go({
                        className: "fs-interstitial-message"
                    }),
                    c = Go({
                        className: "fs-interstitial-ad-space",
                        id: e.name
                    }),
                    f = Go({
                        className: "fs-interstitial-close-container"
                    }),
                    u = function({
                        element: e
                    }) {
                        const t = sr();
                        return t.className = t.className += "fs-close-button fs-close-button-zerg-interstitial", t.addEventListener("click", (function() {
                            zn([e.id]), e.parentElement.removeChild(e)
                        })), t
                    }({
                        element: s
                    });
                f.appendChild(u), a.appendChild(f), l.innerText = i, d.appendChild(l), o.appendChild(r), a.appendChild(f), a.appendChild(d), a.appendChild(o), a.appendChild(c), s.appendChild(a);
                const p = Fn(e),
                    h = sn({
                        type: "img",
                        src: "https://a.pub.network/img/powered_by_fs.png"
                    }),
                    m = sn({
                        type: "a",
                        classList: ["fs_interstitial_branding_link"]
                    });
                m.href = `https://freestar.com/?utm_campaign=branding&utm_medium=${p}&utm_source=${window.freestar.fsdata.domain}&utm_content=${e.name}`, a.appendChild(c), m.appendChild(h), a.appendChild(m), window.document.body.appendChild(s), setTimeout((function() {
                    "mobile" !== window.freestar.deviceInfo.device.type && (window.freestar.log({
                        title: "Interstitial"
                    }, "Start Time lapsed engaging interstitial "), Vo(), window.freestar.newAdSlots([{
                        placementName: e.name,
                        slotId: e.name
                    }]), function() {
                        var e = sn({
                            type: "script"
                        });
                        e.type = "text/javascript", e.async = !0, e.src = ("https:" == document.location.protocol ? "https:" : "http:") + "//www.zergnet.com/zerg.js?id=" + t;
                        var n = document.getElementsByTagName("script")[0];
                        n.parentNode.insertBefore(e, n), s.style.visibility = "visible"
                    }())
                }), 1e3 * n)
            }
        }
    }

    function Qo(e) {
        if (Nn({
                name: "pageGrabber"
            })) return void e(!0);
        freestar.log(1, "Page Grabber: Init");
        const t = freestar.fsdata.placements.filter((e => e.interstitialOptions && e.interstitialOptions.active && "UNDERTONE_GRABBER" === e.interstitialOptions.type))[0];
        if (t) {
            performance.mark("pageGrabber-initialization-start"), freestar.log(1, "Page Grabber: placement ", t), freestar.frequencyLibrary[t.name] = new rr({
                placement: t,
                product: "interstitial",
                callback: e
            });
            const n = Number(sessionStorage.getItem("pageviews") || 1),
                {
                    interstitialPageViewsBefore: i
                } = be({
                    placement: t,
                    type: "interstitialOptions"
                });
            if (freestar.frequencyLibrary[t.name].cap > -1 && !freestar.frequencyLibrary[t.name].allowProduct()) return void e(!0);
            if (i && n < i) return void e(!0);
            const r = Jt({
                    placement: t
                }),
                s = $n(t);
            if (s && Fi({
                    adUnits: s
                }), r && t.name && document.body) {
                const n = function(n) {
                        if (n && n.data) try {
                            const s = !(!n.data || "string" != typeof n.data) && JSON.parse(n.data);
                            s.method && "close" === s.method && i({
                                slot: r,
                                callback: e,
                                name: t.name
                            })
                        } catch (e) {
                            freestar.log(1, `Error: ${e}`)
                        }
                    },
                    i = function({
                        slot: e,
                        callback: t,
                        name: i
                    }) {
                        freestar.log(1, "Page Grabber: destroying page grabber div!"), freestar.newAdSlotsAllowed = !0, document.removeEventListener("click", n, !1), googletag.destroySlots([e]), t(null, !0)
                    };
                freestar.newAdSlotsAllowed = !1;
                const s = sn({
                    type: "div",
                    id: t.name
                });
                document.body.appendChild(s), googletag.cmd.push((function() {
                    googletag.display(s.id)
                })), ji([t.name], [r]);
                let a = 0;
                const o = setInterval((function() {
                    if (a++, a > 50) clearInterval(o);
                    else {
                        const t = document.querySelectorAll('[title="Close"]')[0];
                        t && (clearInterval(o), t.addEventListener("click", (function() {
                            i({
                                slot: r,
                                callback: e
                            })
                        })))
                    }
                }), 50);
                window.addEventListener("message", n)
            } else freestar.log(1, "Page Grabber: define slot error or document.body not available skipping page grabber!"), freestar.frequencyLibrary[t.name].cap && freestar.frequencyLibrary[t.name].subtractIteration(), e(!0);
            performance.mark("pageGrabber-initialization-end")
        } else freestar.log(1, "Page Grabber: no placement aligned skipping page grabber!"), e(!0)
    }
    const Yo = function(e) {
            let t = e.slot.getSlotElementId(),
                n = document.getElementById(t);
            n && (freestar.viewableImpression[t] || (freestar.viewableImpression[t] = {}), freestar.viewableImpression[t].observer = new IntersectionObserver((function(n) {
                n.forEach((n => {
                    let {
                        isIntersecting: i,
                        target: r,
                        intersectionRatio: s
                    } = n;
                    !i || s < .5 ? clearTimeout(freestar.viewableImpression[t].timer) : freestar.viewableImpression[t].timer = setTimeout((function() {
                        clearTimeout(freestar.viewableImpression[t].timer), freestar.viewableImpression[t].timer = null, freestar.viewableImpression[t].observer.unobserve(r), freestar.msg.que.push({
                            seen: !1,
                            eventType: "viewableImpression",
                            slotId: t,
                            args: {
                                placementId: ve({
                                    slotId: t
                                }),
                                DfpId: e.slot.getAdUnitPath(),
                                advertiserId: e.advertiserId,
                                campaignId: e.campaignId,
                                isEmpty: e.isEmpty,
                                lineItemId: e.lineItemId,
                                serviceName: e.serviceName,
                                size: JSON.stringify(e.size),
                                sourceAgnosticCreativeId: e.sourceAgnosticCreativeId,
                                sourceAgnosticLineItemId: e.sourceAgnosticLineItemId,
                                parentDiv: t
                            }
                        })
                    }), 1e3)
                }))
            }), h), freestar.viewableImpression[t].observer.observe(n))
        },
        Ko = "fs.session";
    const Jo = new class {
        constructor() {
            this.session = null, this.init()
        }
        init() {
            this.session = ut({
                key: Ko
            }), this.session ? this.session = JSON.parse(this.session) : this.session = {
                id: bi()
            };
            let e = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"].map((e => ({
                key: e,
                value: lt(e)
            }))).filter((e => "" !== e.value));
            if (0 !== e.length) {
                let t = {};
                e.forEach((e => {
                    t[e.key] = e.value
                })), this.session.utm = t
            }
            pt({
                key: Ko,
                type: ft.object,
                value: this.session
            })
        }
        getSessionId() {
            return this.session.id
        }
        getUTMValue(e) {
            return this.session.utm ? this.session.utm[e] : null
        }
    };
    var Xo, Zo, ed = {
            exports: {}
        },
        td = {
            exports: {}
        };
    Xo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Zo = {
        rotl: function(e, t) {
            return e << t | e >>> 32 - t
        },
        rotr: function(e, t) {
            return e << 32 - t | e >>> t
        },
        endian: function(e) {
            if (e.constructor == Number) return 16711935 & Zo.rotl(e, 8) | 4278255360 & Zo.rotl(e, 24);
            for (var t = 0; t < e.length; t++) e[t] = Zo.endian(e[t]);
            return e
        },
        randomBytes: function(e) {
            for (var t = []; e > 0; e--) t.push(Math.floor(256 * Math.random()));
            return t
        },
        bytesToWords: function(e) {
            for (var t = [], n = 0, i = 0; n < e.length; n++, i += 8) t[i >>> 5] |= e[n] << 24 - i % 32;
            return t
        },
        wordsToBytes: function(e) {
            for (var t = [], n = 0; n < 32 * e.length; n += 8) t.push(e[n >>> 5] >>> 24 - n % 32 & 255);
            return t
        },
        bytesToHex: function(e) {
            for (var t = [], n = 0; n < e.length; n++) t.push((e[n] >>> 4).toString(16)), t.push((15 & e[n]).toString(16));
            return t.join("")
        },
        hexToBytes: function(e) {
            for (var t = [], n = 0; n < e.length; n += 2) t.push(parseInt(e.substr(n, 2), 16));
            return t
        },
        bytesToBase64: function(e) {
            for (var t = [], n = 0; n < e.length; n += 3)
                for (var i = e[n] << 16 | e[n + 1] << 8 | e[n + 2], r = 0; r < 4; r++) 8 * n + 6 * r <= 8 * e.length ? t.push(Xo.charAt(i >>> 6 * (3 - r) & 63)) : t.push("=");
            return t.join("")
        },
        base64ToBytes: function(e) {
            e = e.replace(/[^A-Z0-9+\/]/gi, "");
            for (var t = [], n = 0, i = 0; n < e.length; i = ++n % 4) 0 != i && t.push((Xo.indexOf(e.charAt(n - 1)) & Math.pow(2, -2 * i + 8) - 1) << 2 * i | Xo.indexOf(e.charAt(n)) >>> 6 - 2 * i);
            return t
        }
    }, td.exports = Zo;
    var nd = td.exports,
        id = {
            utf8: {
                stringToBytes: function(e) {
                    return id.bin.stringToBytes(unescape(encodeURIComponent(e)))
                },
                bytesToString: function(e) {
                    return decodeURIComponent(escape(id.bin.bytesToString(e)))
                }
            },
            bin: {
                stringToBytes: function(e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(255 & e.charCodeAt(n));
                    return t
                },
                bytesToString: function(e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(String.fromCharCode(e[n]));
                    return t.join("")
                }
            }
        },
        rd = id,
        sd = function(e) {
            return null != e && (ad(e) || function(e) {
                return "function" == typeof e.readFloatLE && "function" == typeof e.slice && ad(e.slice(0, 0))
            }(e) || !!e._isBuffer)
        };

    function ad(e) {
        return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
    }! function() {
        var e = nd,
            t = rd.utf8,
            n = sd,
            i = rd.bin,
            r = function(s, a) {
                s.constructor == String ? s = a && "binary" === a.encoding ? i.stringToBytes(s) : t.stringToBytes(s) : n(s) ? s = Array.prototype.slice.call(s, 0) : Array.isArray(s) || s.constructor === Uint8Array || (s = s.toString());
                for (var o = e.bytesToWords(s), d = 8 * s.length, l = 1732584193, c = -271733879, f = -1732584194, u = 271733878, p = 0; p < o.length; p++) o[p] = 16711935 & (o[p] << 8 | o[p] >>> 24) | 4278255360 & (o[p] << 24 | o[p] >>> 8);
                o[d >>> 5] |= 128 << d % 32, o[14 + (d + 64 >>> 9 << 4)] = d;
                var h = r._ff,
                    m = r._gg,
                    g = r._hh,
                    b = r._ii;
                for (p = 0; p < o.length; p += 16) {
                    var y = l,
                        w = c,
                        v = f,
                        I = u;
                    l = h(l, c, f, u, o[p + 0], 7, -680876936), u = h(u, l, c, f, o[p + 1], 12, -389564586), f = h(f, u, l, c, o[p + 2], 17, 606105819), c = h(c, f, u, l, o[p + 3], 22, -1044525330), l = h(l, c, f, u, o[p + 4], 7, -176418897), u = h(u, l, c, f, o[p + 5], 12, 1200080426), f = h(f, u, l, c, o[p + 6], 17, -1473231341), c = h(c, f, u, l, o[p + 7], 22, -45705983), l = h(l, c, f, u, o[p + 8], 7, 1770035416), u = h(u, l, c, f, o[p + 9], 12, -1958414417), f = h(f, u, l, c, o[p + 10], 17, -42063), c = h(c, f, u, l, o[p + 11], 22, -1990404162), l = h(l, c, f, u, o[p + 12], 7, 1804603682), u = h(u, l, c, f, o[p + 13], 12, -40341101), f = h(f, u, l, c, o[p + 14], 17, -1502002290), l = m(l, c = h(c, f, u, l, o[p + 15], 22, 1236535329), f, u, o[p + 1], 5, -165796510), u = m(u, l, c, f, o[p + 6], 9, -1069501632), f = m(f, u, l, c, o[p + 11], 14, 643717713), c = m(c, f, u, l, o[p + 0], 20, -373897302), l = m(l, c, f, u, o[p + 5], 5, -701558691), u = m(u, l, c, f, o[p + 10], 9, 38016083), f = m(f, u, l, c, o[p + 15], 14, -660478335), c = m(c, f, u, l, o[p + 4], 20, -405537848), l = m(l, c, f, u, o[p + 9], 5, 568446438), u = m(u, l, c, f, o[p + 14], 9, -1019803690), f = m(f, u, l, c, o[p + 3], 14, -187363961), c = m(c, f, u, l, o[p + 8], 20, 1163531501), l = m(l, c, f, u, o[p + 13], 5, -1444681467), u = m(u, l, c, f, o[p + 2], 9, -51403784), f = m(f, u, l, c, o[p + 7], 14, 1735328473), l = g(l, c = m(c, f, u, l, o[p + 12], 20, -1926607734), f, u, o[p + 5], 4, -378558), u = g(u, l, c, f, o[p + 8], 11, -2022574463), f = g(f, u, l, c, o[p + 11], 16, 1839030562), c = g(c, f, u, l, o[p + 14], 23, -35309556), l = g(l, c, f, u, o[p + 1], 4, -1530992060), u = g(u, l, c, f, o[p + 4], 11, 1272893353), f = g(f, u, l, c, o[p + 7], 16, -155497632), c = g(c, f, u, l, o[p + 10], 23, -1094730640), l = g(l, c, f, u, o[p + 13], 4, 681279174), u = g(u, l, c, f, o[p + 0], 11, -358537222), f = g(f, u, l, c, o[p + 3], 16, -722521979), c = g(c, f, u, l, o[p + 6], 23, 76029189), l = g(l, c, f, u, o[p + 9], 4, -640364487), u = g(u, l, c, f, o[p + 12], 11, -421815835), f = g(f, u, l, c, o[p + 15], 16, 530742520), l = b(l, c = g(c, f, u, l, o[p + 2], 23, -995338651), f, u, o[p + 0], 6, -198630844), u = b(u, l, c, f, o[p + 7], 10, 1126891415), f = b(f, u, l, c, o[p + 14], 15, -1416354905), c = b(c, f, u, l, o[p + 5], 21, -57434055), l = b(l, c, f, u, o[p + 12], 6, 1700485571), u = b(u, l, c, f, o[p + 3], 10, -1894986606), f = b(f, u, l, c, o[p + 10], 15, -1051523), c = b(c, f, u, l, o[p + 1], 21, -2054922799), l = b(l, c, f, u, o[p + 8], 6, 1873313359), u = b(u, l, c, f, o[p + 15], 10, -30611744), f = b(f, u, l, c, o[p + 6], 15, -1560198380), c = b(c, f, u, l, o[p + 13], 21, 1309151649), l = b(l, c, f, u, o[p + 4], 6, -145523070), u = b(u, l, c, f, o[p + 11], 10, -1120210379), f = b(f, u, l, c, o[p + 2], 15, 718787259), c = b(c, f, u, l, o[p + 9], 21, -343485551), l = l + y >>> 0, c = c + w >>> 0, f = f + v >>> 0, u = u + I >>> 0
                }
                return e.endian([l, c, f, u])
            };
        r._ff = function(e, t, n, i, r, s, a) {
            var o = e + (t & n | ~t & i) + (r >>> 0) + a;
            return (o << s | o >>> 32 - s) + t
        }, r._gg = function(e, t, n, i, r, s, a) {
            var o = e + (t & i | n & ~i) + (r >>> 0) + a;
            return (o << s | o >>> 32 - s) + t
        }, r._hh = function(e, t, n, i, r, s, a) {
            var o = e + (t ^ n ^ i) + (r >>> 0) + a;
            return (o << s | o >>> 32 - s) + t
        }, r._ii = function(e, t, n, i, r, s, a) {
            var o = e + (n ^ (t | ~i)) + (r >>> 0) + a;
            return (o << s | o >>> 32 - s) + t
        }, r._blocksize = 16, r._digestsize = 16, ed.exports = function(t, n) {
            if (null == t) throw new Error("Illegal argument " + t);
            var s = e.wordsToBytes(r(t, n));
            return n && n.asBytes ? s : n && n.asString ? i.bytesToString(s) : e.bytesToHex(s)
        }
    }();
    var od = $e(ed.exports);

    function dd() {
        freestar.msg.pageId = od(window.location.href + freestar.hitTime + freestar.msg.fpc)
    }

    function ld() {
        if (freestar.fsdata.hashEnabled) {
            const e = ot({
                name: "fs.identifier.hash"
            });
            return window.location.hash = e && e.length ? e : function() {
                const e = function() {
                    let e = (new Date).getTime();
                    return window.performance && "function" == typeof window.performance.now && (e += performance.now()), "xxxxxxxxxx".replace(/[x]/g, (function() {
                        let t = (e + 16 * Math.random()) % 16 | 0;
                        return e = Math.floor(e / 16), t.toString(16)
                    }))
                }();
                return at({
                    name: "fs.identifier.hash",
                    value: e,
                    expires: 1825,
                    path: "/"
                }), e
            }(), window.location.hash
        }
        return ""
    }

    function cd({
        placements: e
    }) {
        return e.find((e => e.revolvingRailOptions.isOnCall && !0 === e.revolvingRailOptions.isOnCall))
    }

    function fd({
        event: e
    }) {
        document.querySelector(`#${e.slot.getSlotElementId()}`).parentNode.parentNode.classList.add("fs-rr-rendered")
    }
    const ud = e => {
            new IntersectionObserver((([e]) => {
                if (e.isIntersecting) {
                    const t = [...e.target.classList].indexOf("fs-rr-rendered") > -1,
                        n = function({
                            element: e
                        }) {
                            return [...e.querySelectorAll(".fs-rr-ad-x250, .fs-rr-ad-x600")].map((e => ({
                                slotId: e.id,
                                placementName: e.getAttribute("data-ad-unit")
                            })))
                        }({
                            element: e.target
                        });
                    if (t) {
                        const e = n.map((e => e.slotId));
                        Gt().forEach((t => {
                            e.indexOf(t.getSlotElementId()) > -1 && googletag.pubads().refresh([t])
                        }))
                    } else window.freestar.newAdSlots(n),
                        function({
                            numAds: e
                        }) {
                            window.freestar.msg.que.push({
                                eventType: "customEvent",
                                args: {
                                    eventName: "revolvingRail",
                                    jsonValue: JSON.stringify({
                                        numAds: e
                                    })
                                }
                            })
                        }({
                            numAds: n.length
                        }), n.forEach((({
                            slotId: e
                        }) => {
                            window.freestar.gamImpressionCallbacks[e] = fd
                        }))
                }
            }), {
                root: null,
                rootMargin: `0px 0px ${window.innerHeight/3}px 0px`,
                threshold: 0
            }).observe(document.querySelector(e))
        },
        pd = ({
            adUnits: e
        }) => {
            const {
                container: t,
                padddingTop: n,
                paddingTop: i
            } = be({
                placement: e[0],
                type: "revolvingRailOptions"
            });
            ((e = 0) => {
                xi(`\n        .fs-rr-ads-outer {\n            position: relative;\n            height: 200vh;\n            margin-bottom: 50px;\n        }\n\n        .fs-rr-ads-inner {\n            top: ${e}px;\n            position: sticky;\n        }\n\n        .fs-rr-ad-x250 {\n            text-align: center;\n            height: 250px;\n        }\n\n        .fs-rr-ad-x250:first-child {\n            margin-bottom: 100px;\n        }\n\n        .fs-rr-ad-x600 {\n            text-align: center;\n            height: 600px;\n        }\n    `)
            })(i || n);
            const r = _i(t);
            r || console.error(`Revolving Rail initialization failed: No ${t} DOM element found in page.`);
            const s = 2 * window.innerHeight + window.innerHeight / 2 + (i || n),
                a = r.parentNode.offsetHeight,
                o = e.reduce(((e, t) => {
                    if (t.sizes.length) {
                        const {
                            sizes: n
                        } = t;
                        let i = function({
                            sizes: e
                        }) {
                            return 600 === e[0][1] && "x600"
                        }({
                            sizes: n
                        }) || function({
                            sizes: e
                        }) {
                            return 250 === e[0][1] && "x250"
                        }({
                            sizes: n
                        });
                        if (!i) return e;
                        e[i] || (e[i] = []), e[i].push(t)
                    }
                    return e
                }), {});
            if (0 === Object.keys(o).length) return window.freestar.log({
                title: "RevolvingRail",
                style: "background: orange; color: #fff; border-radius: 3px; padding: 3px"
            }, "No usable sizes from revolving rail placements"), !1;
            const d = sn({
                classList: ["fs-rr-ads"]
            });
            let l = s,
                c = 0,
                f = 0;
            const u = Object.keys(o),
                p = u.length - 1;
            for (; l < a;) {
                const e = sn({
                        classList: ["fs-rr-ads-outer"],
                        id: `fs-rr-ads-outer-${f}`
                    }),
                    t = sn({
                        classList: ["fs-rr-ads-inner"]
                    });
                e.appendChild(t);
                const n = u[c],
                    i = o[n];
                if ("x250" === n) {
                    const e = i[0].name,
                        r = i[1].name;
                    t.appendChild(sn({
                        classList: [`fs-rr-ad-${n}`],
                        id: `${e}-a-${f}`,
                        attributes: [{
                            "data-ad-unit": e
                        }]
                    })), t.appendChild(sn({
                        classList: [`fs-rr-ad-${n}`],
                        id: `${r}-b-${f}`,
                        attributes: [{
                            "data-ad-unit": r
                        }]
                    }))
                } else {
                    const e = i[0].name;
                    t.appendChild(sn({
                        classList: [`fs-rr-ad-${n}`],
                        id: `${e}-${f}`,
                        attributes: [{
                            "data-ad-unit": e
                        }]
                    }))
                }
                l += s, d.appendChild(e), f++, c = c === p ? 0 : c + 1
            }
            r.appendChild(d);
            for (let e = 0; e < f; e++) ud(`#fs-rr-ads-outer-${e}`)
        },
        hd = () => {
            if (Nn({
                    name: "revolvingRail"
                })) return window.freestar.log(1, "Revolving Rail is disabled."), !1;
            performance.mark("revolvingRail-initialization-start");
            const e = function({
                placements: e
            }) {
                let t = {};
                return e.forEach((e => {
                    const {
                        container: n
                    } = e.revolvingRailOptions;
                    Object.prototype.hasOwnProperty.call(t, n) || (t[n] = []), t[n].push(e)
                })), t
            }({
                placements: window.freestar.fsdata.placements.filter((e => ge({
                    placement: e,
                    type: "revolvingRailOptions"
                })))
            });
            for (const t in e)
                if (Object.prototype.hasOwnProperty.call(e, t)) {
                    const n = e[t],
                        i = cd({
                            placements: n
                        }),
                        r = _i(t);
                    !i && r ? Le() && !freestar.fsdata.psoDisableInteraction ? Ue({
                        name: "revolvingRail",
                        callback: pd.bind(null, {
                            adUnits: n,
                            container: r
                        })
                    }) : pd({
                        adUnits: n,
                        container: r
                    }) : window.freestar.log(1, `Revolving Rail initialization failed for the ${t} container. The Revolving Rail is onCall or  No DOM element found on page.`)
                }
            performance.mark("revolvingRail-inititialization-end")
        },
        md = ({
            placements: e
        }) => {
            e.forEach((e => {
                const {
                    name: t,
                    contextId: n
                } = e;
                window.freestar.msg.que.push({
                    eventType: "contentRecommendationPartnerImpression",
                    args: {
                        partnerName: "DIANOMI",
                        placementName: t,
                        contextId: n
                    }
                })
            })), performance.mark("dianomi-initialization-end")
        },
        gd = () => {
            const e = window.freestar.fsdata.placements.filter((e => "DIANOMI" === e.partnerName));
            if (Nn({
                    name: "dianomiContentRec"
                }) || e.length < 1) return !1;
            performance.mark("dianomi-initialization-start"), e.forEach((e => {
                (({
                    placement: e
                }) => {
                    const {
                        name: t,
                        contextId: n
                    } = e, i = document.querySelector(`#${t}`);
                    if (!i) return window.freestar.log(1, `Dianomi Target Node with ID "${t}" Does Not Exist`), !1;
                    i.appendChild(sn({
                        classList: ["dianomi_context"],
                        attributes: [{
                            "data-dianomi-context-id": n
                        }]
                    }))
                })({
                    placement: e
                })
            })), (({
                id: e
            }) => null !== document.querySelector(`#${e}`))({
                id: g
            }) ? performance.mark("dianomi-initialization-end") : an("https://www.dianomi.com/js/contextfeed.js", md.bind(null, {
                placements: e
            }), g)
        };
    let bd = !1;
    ! function(e, t) {
        void 0 === t && (t = {});
        var n = t.insertAt;
        if (e && "undefined" != typeof document) {
            var i = document.head || document.getElementsByTagName("head")[0],
                r = document.createElement("style");
            r.type = "text/css", "top" === n && i.firstChild ? i.insertBefore(r, i.firstChild) : i.appendChild(r), r.styleSheet ? r.styleSheet.cssText = e : r.appendChild(document.createTextNode(e))
        }
    }('.fs-sticky-footer {\n    display: block;\n    bottom: 0;\n    right: 0;\n    position: fixed;\n    width: 100vw;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    z-index: 2147483647;\n}\n\n.fs-sticky-slot-element > div > iframe {\n    margin: 0 !important;\n}\n\n.fs-sticky-parent {\n    z-index: 2147483647;\n    bottom: 0;\n    padding-top: 0px;\n    position: fixed;\n    left: 0;\n    right: 0;\n    text-align: center;\n}\n\n\n\n.fs-sticky-wrapper {\n    background-color: #F6F3F3;\n    display: inline-block;\n    margin: auto;\n    width: -webkit-fit-content;\n    width: -moz-fit-content;\n    width: fit-content;\n    visibility: inherit;\n    z-index: inherit;\n}\n\n.fs-overlay {\n    width: 0%;\n    height: 100%;\n    position: fixed;\n    z-index: 5000000;\n    top: 0;\n    left: 0;\n    background: #888888;\n    width: 100%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n}\n\n.canvas-boxes {\n    width: 100px;\n    height: 100px\n}\n\n.captcha-styles {\n    text-align: center;\n    width: 100%\n}\n\n.fs-dynamic {\n    text-align: center;\n    /*margin: 10px auto 10px auto;*/\n    clear: both;\n}\n\n.fs-x-btn {\n    position: absolute;\n    top: 20px;\n    right: 0px;\n    cursor: pointer;\n    border-radius: 50%;\n    width: 30px;\n    height: 30px;\n    background-color: rgba(0, 0, 0, 0.5);\n    -webkit-box-shadow: 0 0 0 rgba(0, 0, 0, 0);\n            box-shadow: 0 0 0 rgba(0, 0, 0, 0);\n}\n\n.fs-l-btn {\n    display: block;\n    position: absolute;\n    top: 14px;\n    left: 5px;\n    pointer-events: none;\n    border-radius: 2px;\n    width: 20px;\n    height: 2px;\n    background-color: rgba(0, 0, 0, 0);\n    -webkit-transform: rotate(-45deg);\n    transform: rotate(-45deg);\n}\n\n.fs-r-btn {\n    display: block;\n    pointer-events: none;\n    border-radius: 2px;\n    width: 20px;\n    height: 2px;\n    background-color: #FFFFFF;\n    -webkit-transform: rotate(45deg);\n    transform: rotate(45deg);\n}\n\n.fs-btn-wrapper {\n    display: inline-block;\n}\n\n.fs-pdu-x {\n    -moz-appearance: none;\n    -webkit-appearance: none;\n    -webkit-transition: all .3s ease-in-out;\n    background-color: #FFFFFF;\n    background-image: url(data: image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+ICAgIDxnIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPiAgICAgICAgPGcgaWQ9ImZzQ2xvc2UiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDU1LjAwMDAwMCwgLTcwLjAwMDAwMCkiIGZpbGw9IiM4ODg4ODgiPiAgICAgICAgICAgIDxnIGlkPSJjYW5jZWwtaWNvbiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTA1NS4wMDAwMDAsIDcwLjAwMDAwMCkiPiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOS40ODU5Mzc1LDAuNjE4NDM3NSBDOS4yNDI1LDAuMzc0Njg3NSA4Ljg0NzUsMC4zNzQ2ODc1IDguNjA0Mzc1LDAuNjE4NDM3NSBMNC45ODEyNSw0LjI0MDYyNSBMMS4zNTkwNjI1LDAuNjE4NDM3NSBDMS4xMTU2MjUsMC4zNzQ2ODc1IDAuNzIwMzEyNSwwLjM3NDY4NzUgMC40NzcxODc1LDAuNjE4NDM3NSBDMC4yMzQwNjI1LDAuODYxODc1IDAuMjM0MDYyNSwxLjI1Njg3NSAwLjQ3NzE4NzUsMS41MDA2MjUgTDQuMDcwNjI1LDUuMDk0Mzc1IEwwLjQ3OTM3NSw4LjY4NDY4NzUgQzAuMjM2MjUsOC45MjgxMjUgMC4yMzYyNSw5LjMyMzEyNSAwLjQ3OTM3NSw5LjU2NjU2MjUgQzAuNjAxODc1LDkuNjg4NzUgMC43NjE1NjI1LDkuNzQ5Njg3NSAwLjkyMTI1LDkuNzQ5Njg3NSBDMS4wODA5Mzc1LDkuNzQ5Njg3NSAxLjI0LDkuNjg4NzUgMS4zNjIxODc1LDkuNTY2NTYyNSBMNC45ODEyNSw1Ljk0ODEyNSBMOC42MDA5Mzc1LDkuNTY2NTYyNSBDOC43MjI4MTI1LDkuNjg4NzUgOC44ODE4NzUsOS43NDk2ODc1IDkuMDQxNTYyNSw5Ljc0OTY4NzUgQzkuMjAxNTYyNSw5Ljc0OTY4NzUgOS4zNjE1NjI1LDkuNjg4NzUgOS40ODI4MTI1LDkuNTY2NTYyNSBDOS43MjYyNSw5LjMyMzEyNSA5LjcyNjI1LDguOTI4MTI1IDkuNDgyODEyNSw4LjY4NDY4NzUgTDUuODkyNSw1LjA5NDY4NzUgTDkuNDg1OTM3NSwxLjUwMDkzNzUgQzkuNzI5Njg3NSwxLjI1Njg3NSA5LjcyOTY4NzUsMC44NjIxODc1IDkuNDg1OTM3NSwwLjYxODQzNzUgWiIgaWQ9IlBhdGgiPjwvcGF0aD4gICAgICAgICAgICA8L2c+ICAgICAgICA8L2c+ICAgIDwvZz48L3N2Zz4=);\n    background-position: 50%;\n    background-repeat: no-repeat;\n    border: none;\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n            box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    cursor: pointer;\n    display: block;\n    height: 20px;\n    outline: none;\n    padding: 0px;\n    position: absolute;\n    right: 12px;\n    top: 12px;\n    transition: all .3s ease-in-out;\n    width: 20px;\n}\n\n.fs-close-button {\n    -moz-appearance: none !important;\n    -webkit-appearance: none !important;\n    -webkit-transition: all .3s ease-in-out !important;\n    appearance: none !important;\n    background-color: #FFFFFF !important;\n    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+ICAgIDxnIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPiAgICAgICAgPGcgaWQ9ImZzQ2xvc2UiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDU1LjAwMDAwMCwgLTcwLjAwMDAwMCkiIGZpbGw9IiM4ODg4ODgiPiAgICAgICAgICAgIDxnIGlkPSJjYW5jZWwtaWNvbiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTA1NS4wMDAwMDAsIDcwLjAwMDAwMCkiPiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOS40ODU5Mzc1LDAuNjE4NDM3NSBDOS4yNDI1LDAuMzc0Njg3NSA4Ljg0NzUsMC4zNzQ2ODc1IDguNjA0Mzc1LDAuNjE4NDM3NSBMNC45ODEyNSw0LjI0MDYyNSBMMS4zNTkwNjI1LDAuNjE4NDM3NSBDMS4xMTU2MjUsMC4zNzQ2ODc1IDAuNzIwMzEyNSwwLjM3NDY4NzUgMC40NzcxODc1LDAuNjE4NDM3NSBDMC4yMzQwNjI1LDAuODYxODc1IDAuMjM0MDYyNSwxLjI1Njg3NSAwLjQ3NzE4NzUsMS41MDA2MjUgTDQuMDcwNjI1LDUuMDk0Mzc1IEwwLjQ3OTM3NSw4LjY4NDY4NzUgQzAuMjM2MjUsOC45MjgxMjUgMC4yMzYyNSw5LjMyMzEyNSAwLjQ3OTM3NSw5LjU2NjU2MjUgQzAuNjAxODc1LDkuNjg4NzUgMC43NjE1NjI1LDkuNzQ5Njg3NSAwLjkyMTI1LDkuNzQ5Njg3NSBDMS4wODA5Mzc1LDkuNzQ5Njg3NSAxLjI0LDkuNjg4NzUgMS4zNjIxODc1LDkuNTY2NTYyNSBMNC45ODEyNSw1Ljk0ODEyNSBMOC42MDA5Mzc1LDkuNTY2NTYyNSBDOC43MjI4MTI1LDkuNjg4NzUgOC44ODE4NzUsOS43NDk2ODc1IDkuMDQxNTYyNSw5Ljc0OTY4NzUgQzkuMjAxNTYyNSw5Ljc0OTY4NzUgOS4zNjE1NjI1LDkuNjg4NzUgOS40ODI4MTI1LDkuNTY2NTYyNSBDOS43MjYyNSw5LjMyMzEyNSA5LjcyNjI1LDguOTI4MTI1IDkuNDgyODEyNSw4LjY4NDY4NzUgTDUuODkyNSw1LjA5NDY4NzUgTDkuNDg1OTM3NSwxLjUwMDkzNzUgQzkuNzI5Njg3NSwxLjI1Njg3NSA5LjcyOTY4NzUsMC44NjIxODc1IDkuNDg1OTM3NSwwLjYxODQzNzUgWiIgaWQ9IlBhdGgiPjwvcGF0aD4gICAgICAgICAgICA8L2c+ICAgICAgICA8L2c+ICAgIDwvZz48L3N2Zz4=)  !important;\n    background-position: 50% !important;\n    background-repeat: no-repeat !important;\n    border: none !important;\n    border-radius: 50% !important;\n    -webkit-box-shadow: 0 0 0 1px #888888, 0 0 0 1px rgba(247, 247, 247, .75) !important;\n            box-shadow: 0 0 0 1px #888888, 0 0 0 1px rgba(247, 247, 247, .75) !important;\n    -webkit-box-sizing: border-box !important;\n            box-sizing: border-box !important;\n    cursor: pointer !important;\n    display: block !important;\n    height: 20px !important;\n    outline: none !important;\n    padding: 0px !important;\n    position: absolute !important;\n    right: 25px !important;\n    top: 25px !important;\n    transition: all .3s ease-in-out !important;\n    width: 20px !important;\n}\n\n.fs-close-button {\n    all: unset;\n}\n\n.fs-close-button:hover,\n.fs-close-button:focus {\n    background-color: #000 !important;\n}\n\n.fs-sticky-popup-container {\n    z-index: 2147483647 !important\n}\n\n.fs-sticky-popup-container {\n    font-size: .8em;\n    text-align: center;\n    font-family: \'arial\';\n    white-space: nowrap;\n    width: auto;\n    height: auto;\n    padding: 7px;\n    -webkit-filter: drop-shadow(2px 2px 2px grey);\n            filter: drop-shadow(2px 2px 2px grey)\n}\n\n.fs-sticky-popup-container a:nth-child(2) {\n    border-top: 1px solid #999;\n}\n\n\n.fs-close-button:hover {\n    -webkit-box-shadow: 0 0 0 1px #888888, 0 0 0 8px rgba(247, 247, 247, .75);\n            box-shadow: 0 0 0 1px #888888, 0 0 0 8px rgba(247, 247, 247, .75);\n}\n\n.fs-close-button-pushdown {\n    right: 12px !important;\n    top: 12px !important;\n}\n\n.fs-close-button-zerg-interstitial {\n    right: -5px !important;\n    top: -5px !important;\n}\n\n.fs-close-button-zerg-interstitial {\n    -webkit-transform: scale(1.25);\n            transform: scale(1.25);\n}\n\n@media screen and (min-width: 820px) {\n  .fs-close-button-sticky {\n      top: 9.3% !important;\n      right: 10px !important;\n  }\n}\n\n@media screen and (max-width: 820px) {\n    .fs-close-button-sticky {\n        top: 3px !important;\n        right: 10px !important;\n    }\n    .fs-close-button-pushdown {\n        top: 0 !important;\n        right: 0 !important;\n    }\n    .sticky-reportThisAd button:after {\n        top: -18px !important;\n        right: 10px !important;\n    }\n    .pushdown-reportThisAd button:after {\n        top: 30px !important;\n        right: -38px !important;\n    }\n}\n\n.fs-pushdown {\n    background-color: rgba(247, 247, 247, .9);\n    top: 0;\n    /*left: 0 !important;*/\n    text-align: center;\n    z-index: 2147483647;\n    /*position: inherit !important;*/\n    width: 100%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n/*    height: 100%;\n    max-height: 250px;*/\n}\n\n.fs-pushdown-sticky {\n    position: sticky !important;\n    left: 0 !important;\n}\n\n.fs-pushdown-sticky {\n    background-color: rgba(247, 247, 247, .9);\n    top: 0;\n    text-align: center;\n    z-index: 2147483647;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n}\n\n.freestar_report_button {\n    border: none;\n    font-family: sans-serif;\n    font-size: 9px;\n    cursor: pointer;\n    color: #646464;\n}\n\n._fsBranding {\n    position: relative;\n}\n\n._fsBranding a {\n    max-height: none;\n    max-height: initial;\n    background-color: transparent;\n    background-color: initial;\n    margin-bottom: 0;\n    margin-bottom: initial;\n    border: medium none currentcolor;\n    border: initial;\n    -moz-appearance: none;\n    -webkit-appearance: none;\n    -webkit-transition: all .3s ease-in-out;\n    appearance: none;\n    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAUCAMAAABYi/ZGAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAAASlQTFRFAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAAAAAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMKIAMOIAMOIA76FDKt7BLyEAMOIAMOIAMOIAMOIAMOIC659F5RvAMOIAMOIAMOIAsCGFJtzAMOIAMOIAMOIAMOIAMOIA7yEAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIXQtSBAAAAGN0Uk5TZ/P/+5zy67G59Nb+iAUAGtq9AcgjzsYfTpoHk+1+IgLQ+B0RjvfwluI6A1fE/M9GvPo0GZf5oh3c/917amAT2tzAtizavReR9dtQvWHu0ubCG5JZMem/DmvhFP1iGNfqyotPvfuArgAAANFJREFUeJxdztdWwkAQgOFlAyIEhypShNB772iUEnqTXgWF938IQ0g8ZP+bOfPNzSCkwPIoJVI9qPkeNcK4psVIS+ueAPQGI9wymSlkecbWlzuzYTsChxO/utySMR6vDwH4A8FQOCJalFKbeINYPJGkU2mhTDYHSLjmC0XplRKIBuVKFb+9syz78flv+lq9kW1yt0WyVrvT7fUHzL0ZhuAYjSeczPhfuK/pjLDYvLgAwpar9YY0F70Fwtw7z5403eEbZHY8rX5+/XJjzgfFRST4A0TXI5cUTyEqAAAAAElFTkSuQmCC);\n    background-position: 50%;\n    background-repeat: no-repeat;\n    border: none;\n    border-radius: 50%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    cursor: pointer;\n    display: block;\n    height: 30px;\n    outline: none;\n    position: absolute;\n    left: 6px;\n    top: 6px;\n    transition: all .3s ease-in-out;\n    width: 30px;\n    min-width: 0;\n    min-width: initial;\n}\n\n@media screen and (max-width: 820px) {\n    ._fsBranding a {\n        top: -30px;\n        background-color: rgba(247, 247, 247, .75);\n        background-size: 58%;\n    }\n}\n\n.fs-report-ad-img {\n    width: 60%;\n    margin: 9px;\n}\n\n#freestar_overlay {\n    background: rgba(0, 0, 0, 0.6);\n    width: 100%;\n    height: 100%;\n    z-index: 2147483647;\n    top: 0;\n    left: 0;\n    position: fixed;\n}\n\n#freestar_overlay_flex {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%;\n    height: 100%;\n}\n\n#freestar_report_ad {\n    background: rgba(255, 255, 255, 1)!important;\n}\n\n#freestar_report_ad {\n    width: 300px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n}\n\n#freestar_report_ad::before {\n    background: rgba(255, 255, 255, 1)!important;\n}\n\n#freestar_report_ad::before {\n    width: 300px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n}\n\n#freestar_report_ad_text_center {\n    text-align: center;\n}\n\n.freestar_close_btn {\n    position: absolute;\n    right: 0px;\n    top: 0px;\n    width: 32px;\n    height: 32px;\n    background-color: rgb(255, 255, 255);\n}\n\n.freestar_close_btn:before {\n    -webkit-transform: rotate(45deg);\n            transform: rotate(45deg);\n}\n\n.freestar_close_btn:after {\n    -webkit-transform: rotate(-45deg);\n            transform: rotate(-45deg);\n}\n\n.freestar_report_btn {\n    background: #00C389!important;\n    cursor: pointer!important;\n    border: none!important;\n    border-radius: 30px!important;\n    color: #fff!important;\n    padding: 10px 20px!important;\n    font-size: 12px!important;\n    font-weight: 500!important;\n    font-family: Arial, Helvetica, sans-serif !important;\n}\n\n.freestar_report_btn {\n    margin: 20px;\n    outline: 0;\n}\n\n.freestar_report_btn:focus {\n    outline: 0;\n}\n\n#freestar_report_div {\n    font-family: Arial, Helvetica, sans-serif !important;\n}\n\n#freestar_report_div {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n}\n\n.freestar_report_sub_header {\n    color: #00C389 !important;\n    font-size: 16px !important;\n    font-weight: 600 !important;\n}\n\n.freestar_report_sub_header {\n    margin: 23px;\n}\n\n.fs_report_container span {\n    margin-left: 10px;\n}\n\n.fs_checkbox {\n    cursor: pointer;\n    position: relative;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n}\n\n.fs_checkbox>span {\n    color: #34495E;\n    margin-left: 5px;\n    /*padding: 0.5rem 0.25rem;*/\n}\n\n.fs_checkbox>input {\n    height: 15px;\n    width: 15px;\n    -webkit-appearance: none;\n    -moz-appearance: none;\n    -o-appearance: none;\n    appearance: none;\n    border: 1px solid #34495E;\n    border-radius: 4px;\n    outline: none;\n    -webkit-transition-duration: 0.3s;\n            transition-duration: 0.3s;\n    background-color: #41B883;\n    cursor: pointer;\n    margin-bottom: 3px;\n}\n\n.fs_checkbox>input:checked {\n    border: 1px solid #41B883;\n    background-color: #34495E;\n}\n\n.fs_checkbox>input:checked+span::before {\n    display: block;\n    text-align: center;\n    color: #41B883;\n    /*position: absolute;*/\n    /*left: 0.7rem;*/\n    /*top: 0.2rem;*/\n}\n\n.fs_checkbox>input:active {\n    border: 2px solid #34495E;\n}\n\n.fs-new-close-container {\n    top: calc(50% - 250px);\n    right: calc(50% - 250px);\n    position: absolute;\n}\n\n@media screen and (max-width: 820px) {\n    .fs-new-close-container {\n        top: 15%;\n        right: calc(50% - 131px);\n    }\n}\n\n.fs-new-close {\n    margin-left: 30%;\n    margin-bottom: 5%;\n    cursor: pointer;\n}\n\n.fs-new-close:hover {\n    opacity: 1;\n}\n\n.fs-new-close:before, .fs-new-close:after {\n    position: absolute;\n    /*left: 15px;*/\n    content: \' \';\n    height: 33px;\n    width: 2px;\n    background-color: rgb(255, 255, 255);\n}\n\n.fs-new-close:before {\n    -webkit-transform: rotate(45deg);\n            transform: rotate(45deg);\n}\n\n.fs-new-close:after {\n    -webkit-transform: rotate(-45deg);\n            transform: rotate(-45deg);\n}\n\n.__fs-ancillary {\n    --childHeight: 16px;\n    width: 100%;\n    /*width: var(--childWidth);*/\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end;\n    margin: 0 auto;\n    height: 16px;\n    height: var(--childHeight);\n    visibility: hidden;\n    -webkit-box-ordinal-group: 6;\n        -ms-flex-order: 5;\n            order: 5;\n}\n\n.fs-sticky-wrapper .__fs-ancillary {\n    display: none !important;\n}\n\n.__fs-report-this-ad {\n    line-height: 0px;\n}\n\n.__fs-branding {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    /*width: var(--childHeight);*/\n    -webkit-box-flex: 1;\n        -ms-flex-positive: 1;\n            flex-grow: 1;\n}\n\n.__fs-branding>a {\n    width: 100%;\n    max-width: var(--childWidth);\n    height: var(--childHeight);\n    display: block;\n}\n\n.__fs-branding>a>img {\n    height: calc(var(--childHeight) - 2px) !important;\n    width: auto !important;\n    width: initial !important;\n}\n\n.__fs-branding>a>img {\n    max-height: none;\n    max-height: initial;\n    background-color: transparent;\n    background-color: initial;\n    background-image: none;\n    background-image: initial;\n    border: medium none currentcolor;\n    border: initial;\n    background-repeat: repeat;\n    background-repeat: initial;\n    background-position: 0 0;\n    background-position: initial;\n    margin: 5px 0;\n    display: block;\n    float: left;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n}\n\n.fs-sticky-wrapper .__fs-branding {\n    position: absolute;\n    top: 0;\n    border: none;\n    border-radius: 50%;\n    width: 30px;\n    height: 30px;\n}\n\n.fs-sticky-wrapper .__fs-branding {\n    position: absolute;\n    top: 50%;\n    right: 6px;\n    border: none;\n    border-radius: 50%;\n}\n\n.fs-mobile-tall {\n    top: 30% !important;\n}\n\n.fs-sticky-wrapper .__fs-branding>a {\n    width: 100%;\n    height: 100%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n}\n\n.fs-sticky-wrapper .__fs-branding>a>img {\n    width: 100% !important;\n    height: 100% !important;\n}\n\n.fs-sticky-wrapper .__fs-branding>a>img {\n    opacity: 1;\n}\n\n@media screen and (max-width: 820px) {\n  .fs-sticky-wrapper .__fs-branding>a>img {\n      width: 70% !important;\n      height: 70% !important;\n  }\n  .fs-sticky-wrapper .__fs-branding>a>img {\n      opacity: 1;\n  }\n}\n\n.fs-sticky-wrapper .__fs-branding {\n    /* top: -30px; */\n    background-color: rgba(247, 247, 247, .75);\n    background-size: 58%;\n}\n.fs-sticky-wrapper .__fs-branding>a>img {\n    width: 90%;\n    height: 90%;\n}\n.fs-sticky-wrapper {\n    background-color: #F6F3F3;\n    padding-right: 38px;\n    display: inline-block;\n    width: -webkit-fit-content;\n    width: -moz-fit-content;\n    width: fit-content;\n    visibility: inherit;\n    z-index: inherit;\n}\n\n.fs-interstitial-overlay {\n    background: rgba(0, 0, 0, 0.6);\n    width: 100%;\n    height: 100%;\n    z-index: 2147483647;\n    top: 0;\n    left: 0;\n    position: fixed;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    visibility: hidden;\n}\n\n.fs-interstitial-container {\n    width: 1000px;\n    height: 650px;\n    background: rgb(255, 255, 255);\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: start;\n        -ms-flex-align: start;\n            align-items: flex-start;\n}\n\n.fs-interstitial-ad-space {\n    width: 970px;\n    height: 250px;\n    -ms-flex-item-align: center;\n        align-self: center;\n    margin-bottom: 10px;\n    margin-top: 10px;\n    min-height: 250px;\n    overflow: hidden;\n}\n\n.fs-interstitial-content {\n    width: 100%;\n    height: 250px;\n    -ms-flex-item-align: center;\n        align-self: center;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: start;\n        -ms-flex-align: start;\n            align-items: flex-start;\n}\n\n.fs-interstitial-message-container {\n    width: 100%;\n    height: 100px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-align: start;\n        -ms-flex-align: start;\n            align-items: flex-start;\n    -ms-flex-item-align: center;\n        align-self: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n}\n\n.fs-interstitial-message {\n    color: #17181f;\n    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;\n    font-size: 40px;\n    -ms-flex-item-align: center;\n        align-self: center;\n    padding: 10px;\n}\n\n.fs-interstitial-close-container {\n    width: 1000px;\n    height: 50px;\n    position: relative;\n}\n\n.fs-interstitial-branding {\n    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAUCAMAAABYi/ZGAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAAASlQTFRFAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAAAAAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMKIAMOIAMOIA76FDKt7BLyEAMOIAMOIAMOIAMOIAMOIC659F5RvAMOIAMOIAMOIAsCGFJtzAMOIAMOIAMOIAMOIAMOIA7yEAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIAMOIXQtSBAAAAGN0Uk5TZ/P/+5zy67G59Nb+iAUAGtq9AcgjzsYfTpoHk+1+IgLQ+B0RjvfwluI6A1fE/M9GvPo0GZf5oh3c/917amAT2tzAtizavReR9dtQvWHu0ubCG5JZMem/DmvhFP1iGNfqyotPvfuArgAAANFJREFUeJxdztdWwkAQgOFlAyIEhypShNB772iUEnqTXgWF938IQ0g8ZP+bOfPNzSCkwPIoJVI9qPkeNcK4psVIS+ueAPQGI9wymSlkecbWlzuzYTsChxO/utySMR6vDwH4A8FQOCJalFKbeINYPJGkU2mhTDYHSLjmC0XplRKIBuVKFb+9syz78flv+lq9kW1yt0WyVrvT7fUHzL0ZhuAYjSeczPhfuK/pjLDYvLgAwpar9YY0F70Fwtw7z5403eEbZHY8rX5+/XJjzgfFRST4A0TXI5cUTyEqAAAAAElFTkSuQmCC);\n    background-position: 100%;\n    background-repeat: no-repeat;\n    height: 30px;\n    -webkit-transition: all .3s ease-in-out;\n    transition: all .3s ease-in-out;\n    width: 30px;\n    min-width: 0;\n    min-width: initial;\n    margin-left: 56%;\n}\n\n.fs-interstitial-container .zegrow {\n    display: -webkit-box !important;\n    display: -ms-flexbox !important;\n    display: flex !important;\n    -webkit-box-align: center !important;\n        -ms-flex-align: center !important;\n            align-items: center !important;\n    -webkit-box-pack: center !important;\n        -ms-flex-pack: center !important;\n            justify-content: center !important;\n}\n\n.fs-interstitial-container .zergentity {\n    width: 237px!important;\n    margin: 0px 8px 0px 5px !important;\n}\n\n.fs-interstitial-container .widget-loaded {\n    -ms-flex-item-align: center !important;\n        align-self: center !important;\n    width: 100% !important;\n    background: rgba(0, 0, 0, 0) !important;\n}\n\n.fs_interstitial_branding_link img {\n    width: 200px;\n    padding-bottom: 16px;\n}\n\n.fs_interstitial_branding_link {\n    -ms-flex-item-align: center !important;\n        align-self: center !important;\n}\n\n#freestar-video-parent, #freestar-video-child {\n    max-width: 100vw !important;\n}\n\n#freestar-video-parent, #freestar-video-child {\n    width: 100%;\n    overflow: hidden;\n}\n\n.freestar_report_comments {\n    font-family: Arial, Helvetica, sans-serif !important;\n}\n\n.freestar_report_comments {\n    padding-top: 10px;\n    margin-top: 10px;\n}\n\n#freestar_report_comment_box_wrapper {\n    width: 100%;\n    height: 90px;\n}\n\n.sticky-reportThisAd button {\n    visibility: hidden;\n    position: relative;\n}\n\n.sticky-reportThisAd button:after {\n    content: "";\n    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAVUlEQVR4Ae3OsREAEBAFUaEClKIA/SjiSlKUQrhAzAyBH+zObP4CEX3O/HFxVANlNVAVA53/AAIECBAgQIAs7EtSoFVXAzUl0HuAAAESqPi2Lj6RfBMQ53XW4UhrMwAAAABJRU5ErkJggg==);\n    background-size: 18px;\n    visibility: visible;\n    position: absolute;\n    moz-appearance: none;\n    -webkit-appearance: none;\n    -moz-appearance: none;\n         appearance: none;\n    background-color: #FFFFFF;\n    background-position: 50%;\n    background-repeat: no-repeat;\n    border: none;\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n            box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    cursor: pointer;\n    display: block;\n    height: 20px;\n    outline: none;\n    padding: 0px;\n    position: absolute;\n    right: -25px;\n    top: 38px;\n    width: 20px;\n    min-width: 0;\n    min-width: initial;\n}\n\n.sticky-reportThisAd {\n    content: "\\127987";\n    cursor: pointer;\n    background: none;\n    margin-left: auto;\n    margin-right: auto;\n    display: block;\n    border: none;\n    position: absolute;\n    right: 35px;\n    top: 5px;\n    z-index: 2147483647;\n}\n\n.pushdown-reportThisAd button {\n    visibility: hidden;\n    position: relative;\n}\n\n.pushdown-reportThisAd button:after {\n    content: "";\n    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAVUlEQVR4Ae3OsREAEBAFUaEClKIA/SjiSlKUQrhAzAyBH+zObP4CEX3O/HFxVANlNVAVA53/AAIECBAgQIAs7EtSoFVXAzUl0HuAAAESqPi2Lj6RfBMQ53XW4UhrMwAAAABJRU5ErkJggg==);\n    background-size: 18px;\n    visibility: visible;\n    position: absolute;\n    moz-appearance: none;\n    -webkit-appearance: none;\n    -moz-appearance: none;\n         appearance: none;\n    background-color: #FFFFFF;\n    background-position: 50%;\n    background-repeat: no-repeat;\n    border: none;\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n            box-shadow: 0 0 0 1px #888888, 0 0 0 6px rgba(247, 247, 247, .75);\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    cursor: pointer;\n    display: block;\n    height: 20px;\n    outline: none;\n    padding: 0px;\n    position: absolute;\n    right: -37.5px;\n    top: 35px;\n    width: 20px;\n    min-width: 0;\n    min-width: initial;\n}\n\n.pushdown-reportThisAd {\n    content: "\\127987";\n    cursor: pointer;\n    background: none;\n    margin-left: auto;\n    margin-right: auto;\n    display: block;\n    border: none;\n    position: absolute;\n    right: 50px;\n    top: 5px;\n    z-index: 2147483647;\n}\n\n.center-ad {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n}\n\n._wrapper .orp-player-wrapper {\n    width: 100% !important;\n    height: 100% !important;\n}\n');

    function yd(e) {
        return freestar.dynamicSlotLibrary[e] ? freestar.dynamicSlotLibrary[e] : e
    }

    function wd(e) {
        if (e.args && e.args.adUnitCode) {
            let t = null,
                n = !1;
            try {
                t = freestar.refreshLibrary[e.args.adUnitCode].dataRefreshId
            } catch (e) {
                freestar.log(e)
            }
            if (t) {
                let e = 0;
                const i = RegExp(t, "g");
                return freestar.refreshSlots.forEach(((t, r) => {
                    i.test(t.refreshId) && (e = r, n = !0)
                })), freestar.refreshSlots.splice(e, 1), n
            }
            return n
        }
        return !1
    }

    function vd(e) {
        const t = e.args.adUnitCode || e.args.placementId,
            n = freestar.refreshLibrary[t];
        return n && n.timesRefreshed ? n.timesRefreshed : 0
    }

    function Id(e) {
        const t = {
            isRebid: !1
        };
        if (freestar.rebidManager && e.args && e.args.adUnitCode) {
            const n = freestar.rebidManager.getStatus({
                adUnitCode: e.args.adUnitCode
            });
            n && (t.isRebid = n.count > 0, t.rebidType = n.type ? n.type : "UNKNOWN", t.rebidAttempt = n.count)
        }
        return t
    }

    function Ad(e) {
        return e.args.mediaType.length > 0 ? e.args.mediaType : "unknown"
    }
    const kd = () => {
            if (freestar.msg.fpc && null === freestar.msg.fpc || freestar.msg.processing || freestar.msg.que && 0 === freestar.msg.que.length || 0 === freestar.fsdata.accountId || 0 === freestar.fsdata.siteId) return;
            let e = (() => {
                let e = 0,
                    t = freestar.msg.que.length;
                if (0 === t) return void freestar.log(90, "Message Queue - No messages to send. Returning.");
                let n = freestar.msg.sessionId;
                if (n.indexOf("&") >= 0) {
                    let e = n.indexOf("&");
                    n = n.substr(0, e)
                }
                const i = {};
                for (; t > 0 && e < 30;) {
                    let n = freestar.msg.que.shift();
                    t--, e++, n.args && (i[n.eventType] || (i[n.eventType] = []), i[n.eventType].push(n.args));
                    const {
                        isRebid: r,
                        rebidType: s,
                        rebidAttempt: a
                    } = Id(n);
                    let o = 0;
                    if (n.args && n.args.placementId) {
                        let e = fsprebid.getBidResponsesForAdUnitCode(n.args.placementId);
                        o = e.bids.length ? e.bids.sort(((e, t) => e.cpm < t.cpm ? 1 : -1)).reduce((e => e)).cpm : 0, o = Number(o)
                    }
                    let d = null;
                    if (n.args && n.args.adUnitCode && (d = Ti({
                            name: ve({
                                slotId: n.args.adUnitCode
                            })
                        }), n.args.adUnitCode && Oe({
                            bidder: n.args.bidderCode,
                            adUnitCode: n.args.adUnitCode
                        })), n.args && n.slotId) {
                        const e = n.slotId,
                            t = googletag.pubads().getSlots().filter((t => t.getSlotElementId() === e))[0] || !1;
                        t && t.getTargeting("fs_uuid") && (n.args.fsuuid = t.getTargeting("fs_uuid").toString())
                    }
                    const l = Math.floor(1e4 * n.args.cpm) ? Math.floor(1e4 * n.args.cpm) : 0,
                        c = n.args.originalCpm ? Math.floor(1e4 * n.args.originalCpm) : 0;
                    switch (n.eventType) {
                        case "bidResponse":
                        case "bidAdjustment":
                            n.args.placementId = yd(n.args.adUnitCode), n.args.fsRefreshCount = vd(n), n.args.isRebid = r, n.args.rebidType = s, n.args.fsRebidCount = a, n.args.auctionTimeout = "desktop" == freestar.deviceInfo.device.type ? freestar.fsdata.timeout : freestar.fsdata.mobileTimeout, n.args.format = Ad(n), n.args.bidderRefresh = wd(n), n.args.fsAdProduct = Fn(d), n.args.networkCode = Number(d.dfpId.split("/")[1]);
                            break;
                        case "bidWon":
                            n.args.placementId = yd(n.args.adUnitCode), n.args.fsRefreshCount = vd(n), n.args.isRebid = r, n.args.rebidType = s, n.args.fsRebidCount = a, n.args.auctionTimeout = "desktop" == freestar.deviceInfo.device.type ? freestar.fsdata.timeout : freestar.fsdata.mobileTimeout, n.args.format = Ad(n), n.args.bidderRefresh = wd(n), n.args.fsAdProduct = Fn(d), n.args.networkCode = Number(d.dfpId.split("/")[1]), n.args.impressionId = bi(), n.args.originalCpm = c && c <= 2147483647 ? c : l && l <= 2147483647 ? l : 0, n.args.meta && (Object.keys(n.args.meta).forEach((e => {
                                n.args[e] = Array.isArray(n.args.meta[e]) ? n.args.meta[e].join(",") : n.args.meta[e]
                            })), n.args.advertiserDomains && (n.args.adomain = n.args.advertiserDomains, delete n.args.advertiserDomains)), n.args.creative_id && (n.args.creativeId = n.args.creative_id, delete n.args.creativeId);
                            break;
                        case "bidWonVideoPlayed":
                            n.args.format = Ad(n), n.args.bidderRefresh = wd(n);
                            break;
                        case "dfpResponse":
                            let e = null,
                                t = null;
                            try {
                                e = document.getElementById(n.args.parentDiv), t = freestar.refreshLibrary[n.args.parentDiv].refreshId
                            } catch (e) {
                                freestar.log(1, `Error: ${e}`)
                            }
                            let i = !1;
                            if (e && t) {
                                let e;
                                const n = RegExp(t, "g");
                                freestar.refreshSlots.forEach(((t, r) => {
                                    n.test(t.refreshId) && (e = r, i = !0)
                                })), freestar.refreshSlots.splice(e, 1)
                            }
                            n.args.advertiserId = n.args.advertiserId || 0, n.args.campaignId = n.args.campaignId || 0, n.args.lineItemId = n.args.lineItemId || 0, n.args.sourceAgnosticCreativeId = n.args.sourceAgnosticCreativeId || 0, n.args.sourceAgnosticLineItemId = n.args.sourceAgnosticLineItemId || 0, n.args.fsRefreshCount = vd(n), n.args.fsRebidCount = a, n.args.maxBid = o, n.args.dfpRefresh = i;
                            break;
                        case "viewableImpression":
                            n.args.fsRefreshCount = vd(n), n.args.fsRebidCount = a, n.args.maxBid = o
                    }
                }
                let r = i;
                return freestar.allowBidResponseCollection || (delete r.bidResponse, delete r.bidAdjustment), {
                    buffer: r,
                    msgCount: e
                }
            })();
            Object.keys(e.buffer).forEach((t => {
                e.buffer[t].forEach((e => {
                    window.freestar.analytics.track({
                        type: t,
                        args: e
                    })
                }))
            }))
        },
        Sd = {
            WAITING: "waiting",
            COMPLETE: "complete",
            NOT_ALLOWED: "not_allowed"
        },
        xd = {
            SAFARI: "safari",
            CHROME: "chrome",
            FIREFOX: "firefox",
            EDGE: "edge"
        },
        Ed = {
            ACTIVE: "ppid_active",
            INACTIVE: "ppid_inactive"
        };
    class Od {
        constructor({
            siteId: e = -1,
            allowedCountries: t = [],
            allowedBrowsers: n = [],
            restrictedBrowsers: i = []
        }) {
            this.siteId = e, this.allowedCountries = t, this.allowedBrowsers = n, this.restrictedBrowsers = i
        }
    }
    const _d = {
            allowedCountries: ["US", "AU", "CA"],
            allowedBrowsers: [xd.FIREFOX, xd.SAFARI]
        },
        Td = v.map((e => new Od({ ..._d,
            siteId: e
        })));
    class Cd {
        constructor(e = "", t = "", n = -1, i = "") {
            this.BrowserEnum = xd, this.StateEnum = Sd, this.GPTValues = Ed, this.activeKey = "gppidtv_group", this.sessionObjKey = "gppidtv", this.domainConfigs = Td, this.domainConfig = new Od({});
            const r = this.getSessionObj();
            r ? (this.publisherID = r.publisherID, this.state = r.state, this.iso = r.iso, this.userAgent = r.userAgent, this.siteId = r.siteId, this.userAgent = r.userAgent, this.state === this.StateEnum.COMPLETE && this.state !== this.StateEnum.NOT_ALLOWED && this.setGoogleTagPPID()) : (this.publisherID = "", this.state = this.StateEnum.WAITING, this.iso = e, this.userAgent = t.toLowerCase(), this.siteId = n, this.updateState(), this.state === this.StateEnum.COMPLETE && this.state !== this.StateEnum.NOT_ALLOWED && (this.setPublisherID(i), this.setGroupValue(), this.setGoogleTagPPID(), this.setSessionObj()))
        }
        setPublisherID(e) {
            e && this.verifyId(e) && (this.publisherID = e), this.updateState()
        }
        updateState() {
            const e = this.findConfigBySiteId();
            e && (this.domainConfig = e), this.state = e && this.isBrowserAllowed() && this.isCountryAllowed() ? this.StateEnum.COMPLETE : this.StateEnum.NOT_ALLOWED
        }
        findConfigBySiteId() {
            return this.domainConfigs.find((e => this.siteId === e.siteId))
        }
        isBrowserAllowed() {
            const e = Cd.getBrowserType(this.userAgent),
                t = !!this.domainConfig.restrictedBrowsers.length,
                n = !!this.domainConfig.allowedBrowsers.length;
            return !t && !n || (t ? !this.domainConfig.restrictedBrowsers.includes(e) : this.domainConfig.allowedBrowsers.includes(e))
        }
        static getBrowserType(e) {
            return [xd.EDGE, xd.CHROME, xd.SAFARI, xd.FIREFOX].find((t => e.toLowerCase().includes(t))) || ""
        }
        verifyId(e) {
            return /^([0-9a-zA-Z]{32,150})$|^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/.test(e)
        }
        isCountryAllowed() {
            return this.domainConfig.allowedCountries.includes(this.iso)
        }
        updateGoogleSlotTargeting(e) {
            this.allowFSPPID() && e && this.getGroupValue() && Vt({
                slot: e,
                key: "tg",
                value: this.getGroupValue()
            })
        }
        setGroupValue() {
            const e = Math.random() >= .5 ? this.GPTValues.ACTIVE : this.GPTValues.INACTIVE;
            sessionStorage.setItem(this.activeKey, e)
        }
        getGroupValue() {
            return sessionStorage.getItem(this.activeKey)
        }
        allowFSPPID() {
            return this.state === this.StateEnum.COMPLETE
        }
        setGoogleTagPPID() {
            googletag.cmd.push((() => {
                googletag.pubads().setPublisherProvidedId(this.publisherID)
            }))
        }
        setSessionObj() {
            sessionStorage.setItem(this.sessionObjKey, JSON.stringify(this))
        }
        getSessionObj() {
            const e = sessionStorage.getItem(this.sessionObjKey);
            return e ? JSON.parse(e) : null
        }
    }
    var Rd = {};
    Object.defineProperty(Rd, "__esModule", {
        value: !0
    }), Rd.AdblockDetector = void 0;
    class Nd {
        constructor() {
            this.bannerIds = ["AdHeader", "AdContainer", "AD_Top", "homead", "ad-lead"], this.init()
        }
        init() {
            const e = document.createElement("div");
            e.innerHTML = this.generatesBannersString(), document.body.appendChild(e)
        }
        detect() {
            return !this.bannerIds.every((e => this.checkVisibility(e)))
        }
        generatesBannersString() {
            return this.bannerIds.map((e => `<div id="${e}"></div>`)).join("")
        }
        checkVisibility(e) {
            const t = document.querySelector(`#${e}`);
            return t ? t.offsetParent : null
        }
    }
    Rd.AdblockDetector = Nd;
    var Md = Rd.default = new Nd;
    const Dd = "fs.iiq.ab.segment",
        Bd = "testGroup",
        Pd = ["US", "CA", "AU", "JP", "MX", "KR", "TH", "SG", "MY", "BR"];

    function zd(e) {
        const t = function(e) {
            try {
                if (e && e.partners && e.partners.iiq && e.partners.iiq.intentIqData) {
                    const {
                        eids: t = []
                    } = e.partners.iiq.intentIqData, n = t.find((e => "intentiq.com" === e.source));
                    if (n && n.uids) {
                        const e = n.uids.find((e => "ppuid" === e.ext.stype));
                        if (e) return e.id
                    }
                }
            } catch (e) {
                console.error("Error occurred while finding PPID by source:", e)
            }
            return null
        }(e);
        if (t) try {
            googletag.pubads().setPublisherProvidedId(t)
        } catch (e) {
            console.error("Error occurred while setting Publisher Provided ID:", e)
        }
    }

    function Ld(e, t) {
        "US" === e && googletag.cmd.push((() => {
            googletag.pubads().setTargeting(Bd, jd[t])
        }))
    }
    const jd = {
        IIQ_FALSE_FSUID_TRUE: "51861e4a4207600fb42febc4db93c0a1",
        IIQ_FALSE_FSUID_FALSE: "03b03a50ffe1284174616c225a2cde1d",
        IIQ_TRUE_IIQID_TRUE_Mobile_Safari: "1a9bdd3c7b1deea91861cbe0c3d56c69",
        IIQ_TRUE_IIQID_TRUE_Mobile_Chrome: "d90e95759df4727883c5056e2cad59b8",
        IIQ_TRUE_IIQID_TRUE_Mobile_Other: "7e73b891c362bd867396b5c62d9464ca",
        IIQ_TRUE_IIQID_TRUE_Desktop_Safari: "0e6fd97233392eaa38b850a2e320440a",
        IIQ_TRUE_IIQID_TRUE_Desktop_Chrome: "97980190ab5bcba7d244ee25fa226624",
        IIQ_TRUE_IIQID_TRUE_Desktop_Other: "b7231758161d207f16c3bc7d715dac24",
        IIQ_TRUE_FSUID_TRUE_Mobile_Safari: "b5b9116f2349c6390ab53f77c3fe12e6",
        IIQ_TRUE_FSUID_TRUE_Mobile_Chrome: "ea8dd591c8e834c7b3e63c09771843f9",
        IIQ_TRUE_FSUID_TRUE_Mobile_Other: "53d3b131dadd001f2d1003c1679655ec",
        IIQ_TRUE_FSUID_TRUE_Desktop_Safari: "21f64593bab7ef0cd53a148dd2478e44",
        IIQ_TRUE_FSUID_TRUE_Desktop_Chrome: "fdb500daf1dc11ef085938ddb39ba30e",
        IIQ_TRUE_FSUID_TRUE_Desktop_Other: "3f119cca44b8ada1d1d8cb166997c93f",
        IIQ_TRUE_NOID_TRUE_Mobile_Safari: "d2e47d0f87720084bbec2ffe9ed6e7fa",
        IIQ_TRUE_NOID_TRUE_Mobile_Chrome: "48c513f182493212f2d6484bac04273b",
        IIQ_TRUE_NOID_TRUE_Mobile_Other: "f1621f8187c9d919c38c644bde05a35e",
        IIQ_TRUE_NOID_TRUE_Desktop_Safari: "ea2803aef0f8210911a630f5be658525",
        IIQ_TRUE_NOID_TRUE_Desktop_Chrome: "b7d8bc0ebc4d63208b70a93b93d2f36e",
        IIQ_TRUE_NOID_TRUE_Desktop_Other: "c08a71d27428861829030b2a2ed124b6"
    };

    function Fd(e) {
        fsprebid.que.push((function() {
            const t = navigator.userAgent || window.navigator.userAgent;
            if (Md.detect()) return;
            const n = window.freestar.fsdata.identityProviders.filter((e => "intentIqId" === e.slug)),
                i = "fs.iiq.segment";
            let r = JSON.parse(ut({
                    key: i
                })),
                s = ut({
                    key: Dd,
                    type: ft.string.type
                });
            if (0 !== n.length && function(e) {
                    try {
                        return -1 !== Pd.indexOf(e)
                    } catch (e) {
                        return console.error("Error occurred while checking allowed geos for IIQ:", e), !1
                    }
                }(freestar.locData.iso)) {
                if (r || (r = {
                        inSegment: Math.random() <= .95
                    }), r.inSegment) {
                    s || (s = function(e, t) {
                        const n = "mobile" === e ? "Mobile" : "Desktop";
                        let i = Cd.getBrowserType(t);
                        [xd.SAFARI, xd.CHROME].includes(i) || (i = "Other"), i = i.charAt(0).toUpperCase() + i.slice(1);
                        let r = "";
                        const s = Math.random();
                        return r = "IIQ_TRUE_NOID_TRUE", s < .33 && (r = "IIQ_TRUE_IIQID_TRUE"), s > .66 && (r = "IIQ_TRUE_FSUID_TRUE"), r = `${r}_${n}_${i}`, pt({
                            key: Dd,
                            value: r,
                            type: ft.string
                        }), r
                    }(freestar.deviceInfo.device.type, t)), s && s.startsWith("IIQ_TRUE_FSUID_TRUE") && (freestar.gptppid = new Cd(freestar.locData.iso, t, window.freestar.fsdata.siteId, freestar.msg.fpc)), performance.mark("iiq-initialization-start");
                    const n = 1434517136;
                    freestar.partners || (freestar.partners = {}), window.load_script("https://a.pub.network/core/intentIQ/20230622/IIQUniversalID.js", (() => {
                        freestar.log({
                            title: "IntentIQ"
                        }, "Script loaded..."), freestar.partners.iiq = new IntentIqObject({
                            partner: n,
                            pbjs: fsprebid,
                            timeoutInMillis: 500,
                            manualWinReportEnabled: !0,
                            ABTestingConfigurationSource: "percentage",
                            abPercentage: 95,
                            domainName: location.host,
                            ppuidSourceBlackList: "adserver.org",
                            callback: () => {
                                s.startsWith("IIQ_TRUE_IIQID_TRUE") && zd(window.freestar), e()
                            }
                        }), fsprebid.onEvent("bidWon", (e => {
                            freestar.log({
                                title: "IntentIQ"
                            }, "reporting external win...");
                            const {
                                adUnitCode: t,
                                auctionId: n,
                                bidderCode: i,
                                cpm: r,
                                currency: s,
                                originalCpm: a = null,
                                originalCurrency: o = null,
                                status: d
                            } = e, l = {
                                biddingPlatformId: 1,
                                partnerAuctionId: n,
                                bidderCode: i,
                                prebidAuctionId: n,
                                cpm: r,
                                currency: s,
                                originalCpm: a,
                                originalCurrency: o,
                                status: d,
                                placementId: t
                            };
                            freestar.partners.iiq.reportExternalWin(l)
                        })), Ld(freestar.locData.iso, s), googletag.pubads().setTargeting("fs_iiq_enabled", "true"), performance.mark("iiq-initialization-end")
                    }))
                } else s || (s = function() {
                    let e = "IIQ_FALSE_FSUID_FALSE";
                    return Math.random() < .5 && (e = "IIQ_FALSE_FSUID_TRUE"), pt({
                        key: Dd,
                        value: e,
                        type: ft.string
                    }), e
                }()), Ld(freestar.locData.iso, s), s.includes("IIQ_FALSE_FSUID_TRUE") && (freestar.gptppid = new Cd(freestar.locData.iso, t, window.freestar.fsdata.siteId, freestar.msg.fpc)), googletag.pubads().setTargeting("fs_iiq_enabled", "false"), e();
                pt({
                    key: i,
                    type: ft.object,
                    value: r
                })
            } else e();
            fsprebid.setTargetingForGPTAsync(), Ii()
        }))
    }

    function Ud() {
        const e = ["Chuck Norris doesn't need a debugger, he just stares down the bug until the code confesses.", "Chuck Norris can write multi-threaded applications with a single thread.", "Chuck Norris can access private methods."],
            t = e[Math.floor(Math.random() * e.length)];
        console.log(t)
    }
    qt().initiateWatcher(fsprebid), P.pushAllPendingMarksToMsgQue(), P.logMark({
        markerName: A.pubfigEngineLoad,
        compareTo: [A.pubfigEngineLoadInit]
    }), Ot.initManager(), freestar.queue = freestar.queue || [], freestar.hasAdQualityConfiantInit = !1, freestar.config = freestar.config || {}, freestar.identity = La, freestar.log = (e, ...t) => {
        let n = "Pubfig",
            i = "background: #00C389; color: #fff; border-radius: 3px; padding: 3px";
        "object" == typeof e && (n = e.title ? e.title : n, i = e.styles ? e.styles : i, e = void 0 !== e.level ? e.level : 1), (freestar.debug >= e && 0 === yt.length || yt.includes(n.toUpperCase())) && console.info(`%c${n}: `, i, ...t)
    }, freestar.isHttps = "https:" === window.location.protocol ? 1 : 0, freestar.dynamicIdNum = freestar.dynamicIdNum || 1, freestar.refreshSlots = [], freestar.rebidSlots = [], freestar.tools = {}, freestar.requests = {}, freestar.requests.que = [], freestar.requests.process = [], freestar.requests.timestamp = void 0, freestar.url = window.location.href, freestar.bidRequestNum = 0, freestar.sideWallUnitControl = [], freestar.dfpSlotInfo = {}, freestar.func = {}, freestar.refreshLibrary = {}, freestar.pushdownControl = {}, freestar.visibilityRefresh = {}, freestar.newAdSlotIds = [], freestar.server = {}, freestar.adReportTracking = {}, freestar.bidsWon = {}, freestar.networkFloor = {}, freestar.blockedRanges = {}, freestar.requestReference = {}, freestar.dynamicSlots = [], freestar.dynamicSlotLibrary = {}, freestar.googletagCorrelatorUpdate = !0, freestar.rebidControl = {}, freestar.gamMap = {}, freestar.reportLibrary = {}, freestar.fsDfpId = freestar.fsdata.placements.filter((e => e.dfpId.indexOf("15184186") > -1)).length > 0, freestar.gamImpressionCallbacks = [], freestar.googleInterstitialPlacement, freestar.allowBidResponseCollection = !1, freestar.viewableImpression = {}, freestar.newAdSlotsAllowed = !0, freestar.frequencyLibrary = {}, freestar.newAdSlotsQueue = [], freestar.focusQueue = [], freestar.initRequested = !1, freestar.adjustments = {
        isLogged: lt("adjustment-log"),
        bids: []
    }, freestar.logPerformanceMarks = P.logPerformanceMarkers, freestar.newAdSlotsCalled = [], freestar.enabledSlotsCalled = [], freestar.standAlonePlayer = {
        callback: void 0,
        slotId: void 0
    }, freestar.currentStickyFooter = void 0, freestar.gumgumLoaded = !1, freestar.msg = freestar.msg || {}, freestar.msg.que = freestar.msg.que || [], dd(), freestar.msg.processing = freestar.msg.processing || !1, freestar.msg.round = freestar.msg.round || 0, freestar.msg.loadTime = freestar.msg.loadTime || 0, freestar.msg.hash = ld(), freestar.msg.sessionId = Jo.getSessionId(), window.fsCmpInitMessage && (freestar.msg.que.push(window.fsCmpInitMessage), freestar.log(10, window.fsCmpInitMessage.args.eventName, window.fsCmpInitMessage.args.eventType, window.fsCmpInitMessage.args.jsonValue), delete window.fsCmpInitMessage), window.load_script = an, freestar.setVideoAdhesionEnabled = function(e) {
        e ? (freestar.currentStickyFooter && (freestar.currentStickyFooter.iteration = 0), freestar.config.products.videoAdhesion.disabled = !1) : freestar.config.products.videoAdhesion.disabled = !0
    }, freestar.slotTargeting = Pn, freestar.newDynamicContent = al, freestar.requestQueInitiate = Tn, freestar.newAdSlots = Un, freestar.createAdSlot = jn, freestar.newStickyFooter = function(e) {
        const t = "stickyFooterOptions",
            n = freestar.fsdata.placements.filter((e => ge({
                placement: e,
                type: t
            }) && e[t].isOnCall));
        if (Le() && n.length && !cr) return cr = !0, void freestar.log("Sticky Footer: Sticky is on Call and PSO enabled next pub needs to call newStickyFooter");
        if (Le() && !freestar.fsdata.psoDisableInteraction && !lr) return void Ue({
            name: "stickyFooter",
            callback: fr.bind(null, {})
        });
        let i;
        if (e && e.length ? (freestar.log(1, `Sticky Footer: newStickyFooter method invoked and requesting placement with the name ${e}.`), i = Ti({
                name: e
            })) : (i = window.freestar.fsdata.placements.filter((e => e.stickyFooterOptions && e.stickyFooterOptions.active))[0], i && freestar.log(1, `Sticky Footer: newStickyFooter method invoked without a name for a placement. The default Sticky Footer ${i.name} was found and will be used.`)), i) {
            freestar.log(1, `Sticky Footer: newStickyFooter method - attempting a new sticky footer using placement ${i.name}.`), freestar.currentStickyFooter && freestar.currentStickyFooter.placement && (freestar.log(1, `Sticky Footer: newStickyFooter method - the current sticky footer will be removed ${freestar.currentStickyFooter.placement.name}.`), freestar.currentStickyFooter = void 0), freestar.currentStickyFooter && freestar.currentStickyFooter.deleteStickyFooter && freestar.currentStickyFooter.deleteStickyFooter();
            let {
                stickyFooterOutstreamVideoPattern: e
            } = ur(i);
            freestar.currentStickyFooter = "VIDEO_DISPLAY_CONCURRENT" === e ? new dr({
                placement: i
            }) : new ar(i), freestar.deleteStickyFooter = freestar.currentStickyFooter.deleteStickyFooter
        } else freestar.log(1, "Sticky Footer: newStickyFooter method - no placement found for the sticky footer!")
    }, freestar.deleteAdSlots = zn, freestar.format_pbjs = $n, freestar.freestarReloadAdSlot = De() ? jt.refreshSlots : el, freestar.reloadAllAdSlots = De() ? jt.refreshSlots : el, freestar.freestarReloadAllAdSlots = tl, freestar.func.browserInfo = yi, freestar.newPushdown = function(e) {
        window.freestar.log(1, Bo + `Selected ${e} in method newPushdown!`);
        const t = Ti({
            name: e
        });
        t ? (window.freestar.log(1, Bo + `Found ${e} in method newPushdown.`), Po(t)) : window.freestar.log(1, Bo + `Did not find ${e} in method newPushdown!`)
    }, freestar.deletePushdown = function(e) {
        window.freestar.log(1, Bo + "Request to delete pushdown");
        const t = document.getElementById(e).parentElement;
        t && (t.parentElement.removeChild(t), window.freestar.deleteAdSlots(e))
    }, freestar.newVideo = function(e) {
        const t = freestar.fsdata.videoAds.filter((t => t.name === e))[0];
        t && Cr(t)
    }, freestar.newSidewall = function(e) {
        const t = {
                elementIds: [],
                bidObjects: [],
                slots: []
            },
            n = (e, n) => {
                n && (t.elementIds.push(n.placement.name), t.bidObjects.push(n.bidObject), t.slots.push(n.slot)), t.bidObjects.length && Fi({
                    adUnits: t.bidObjects
                }), t.elementIds.length && ji(t.elementIds, t.slots)
            },
            i = Ti({
                name: e
            });
        if (i) {
            performance.mark("sidewall-initialization-start");
            const {
                orientation: e
            } = be({
                placement: i,
                type: "sideWallOptions"
            });
            if (e > 0) return void bo(i, n);
            performance.mark("sidewall-initialization-end")
        }
        freestar.log(lo, `No sidewall matched : ${e}`)
    }, freestar.deleteSidewall = function(e) {
        freestar.deleteAdSlots(e);
        const t = document.getElementById(e),
            n = t.parentElement;
        t && n && n.parentElement.removeChild(n)
    }, freestar.newStandAlonePlayer = function({
        placementName: e,
        callback: t
    }) {
        freestar.log(1, "Stand Alone Player: Invoked", arguments);
        let n = !0;
        const i = freestar.fsdata.placements.filter((t => t.name === e))[0];
        if (i) {
            freestar.log(1, "Stand Alone Player: Placement", i);
            const e = document.getElementById(i.name),
                r = document.createElement("div");
            if (r.style = e.style, r.style.width = "100%", r.style.height = "100%", r.id = "_" + e.id, r.className = "_wrapper", e.appendChild(r), freestar.log(1, "Stand Alone Player: Div", e), e) {
                const {
                    width: r
                } = e.getBoundingClientRect();
                if (r >= 300) {
                    freestar.log(1, "Stand Alone Player: eligible width!");
                    const e = freestar.fsdata.placementVideos.filter((e => e.id === i.standAloneVideoOptions.videoId))[0];
                    e && (freestar.log(1, "Stand Alone Player: videoAd", e), n = !1, function({
                        videoAd: e,
                        placement: t,
                        width: n,
                        callback: i
                    }) {
                        performance.mark("springServe-initialization-start"), window._ssPlayer = window._ssPlayer || {
                            spIdi: e.supplyId,
                            widthi: `${n}`,
                            aspecti: "16:9",
                            divi: "_" + t.name
                        };
                        const r = "https://cdn.springserve.com/assets/0/playerJS/frstrIN_2.js",
                            s = Date.now();

                        function a() {
                            i && (i(null, {
                                completed: !0
                            }), i = void 0)
                        }
                        Gi({
                            bidder: "springserve",
                            placementId: e.id ? e.id : "",
                            tagUrl: r
                        }), load_script(r, (function() {
                            window.AdPlayerPro().on("AdStarted", (function() {
                                Vi({
                                    bidder: "springserve",
                                    videoAd: e,
                                    requestTimestamp: s
                                }), i && i(null, {
                                    videoAdStarted: !0
                                }), ["AdStopped", "AdClosed"].forEach((e => {
                                    window.AdPlayerPro().on(e, (() => {
                                        a()
                                    }))
                                })), window.AdPlayerPro().on("AdSkipped", (() => {
                                    i && (i(null, {
                                        videoAdSkipped: !0,
                                        completed: !0
                                    }), i = void 0)
                                }))
                            })), window.AdPlayerPro().on("AdError", (function() {
                                freestar.log(1, "Stand Alone Player: Error loading video requesting bids via new ad slots method"), i && (i(null, {
                                    videoAdStarted: !1
                                }), freestar.standAlonePlayer.callback = i, freestar.standAlonePlayer.slotId = t.name), t.standAloneVideoOptions.backfillDisplayAd ? (freestar.log(1, "Stand Alone Player: Backfill display ad requesting."), Un([{
                                    placementName: t.name,
                                    slotId: t.name
                                }])) : (freestar.log(1, "Stand Alone Player: Backfill display not selected. Process terminating"), i(null, {
                                    completed: !0
                                }))
                            })), performance.mark("springServe-initialization-end")
                        }))
                    }({
                        videoAd: e,
                        placement: i,
                        width: r,
                        callback: t
                    }))
                } else freestar.log(1, "Stand Alone Player: width is not equal to or greater than 400px!")
            }
        }
        n && t && (freestar.log(1, "Stand Alone Player: Failure!"), t(!0))
    }, freestar.newRevolvingRail = (e = void 0) => {
        if (!e) return void window.freestar.log(1, 'newRevolvingRail - must have either a string with a placement name or an object like {placementName: "myPlacementName", slotId: "my-id-one"}');
        e = function({
            requestedRevolvingRail: e
        }) {
            return "object" != typeof e && (e = {
                placementName: e,
                slotId: e
            }), e
        }({
            requestedRevolvingRail: e
        }), window.freestar.log(1, "newRevolvingRail - requested revolving rail ", e);
        const t = window.freestar.fsdata.placements.find((t => t.name === e.placementName));
        let n = _i(e.slotId);
        n || (n = _i(t.revolvingRailOptions.container)), t && n ? pd({
            adUnits: [t],
            container: n
        }) : window.freestar.log(1, `newRevolvingRail - initialization failed for the ${e.placementName} requested placement. There is no record of this placement in fsdata or the slotId ${e.slotId} was not found on the DOM.`)
    }, freestar.deleteStandAlonePlayer = function({
        placementName: e,
        callback: t
    }) {
        const n = freestar.fsdata.placements.filter((t => t.name === e))[0];
        n && (freestar.log(1, "Stand Alone Player: Placement", n), document.getElementById(n.name).innerHTML = "", delete window.AdPlayerPro), t && t(!0)
    };
    const qd = window.innerWidth || document.documentElement.clientWidth,
        $d = window.innerHeight || document.documentElement.clientHeight;
    let Hd;
    freestar.deviceOrientation = wo({
            width: qd,
            height: $d
        }), freestar.reportingAdInfo = () => {
            console.warn("freestar.reportingAdInfo() has been deprecated")
        }, Pt.getFirstInit().then((() => {
            Pt.allowConfiant() && dn()
        })), freestar.deleteVideo = function() {
            console.warn("The deleteVideo method is not available!")
        }, freestar.deleteStickyFooter = () => {
            console.warn("The deleteStickyFooter method is not available!")
        }, freestar.modulesLoaded.engine = !0, freestar.trackPageview = () => {
            freestar.log(1, "TrackPageview invoked."), freestar.url = window.location.href, freestar.hitTime = Date.now(), ld(), dd(), yi(), dt(), al()
        }, setInterval((function() {
            window.location.href !== freestar.url && (freestar.url = window.location.href, freestar.hitTime = Date.now(), ld(), al())
        }), 1e3), freestar.Browsi = {
            pushAd: (e, t, n) => {
                freestar.newAdSlots({
                    placementName: t,
                    slotId: e,
                    targeting: {
                        browsiId: n
                    }
                })
            }
        }, freestar.func.domloaded = !1, freestar.visibilityRefresh.runRefresh = !0, freestar.visibilityRefresh.enacted = !1, freestar.visibilityRefresh.timeLeft = null, freestar.visibilityRefresh.refreshTimeMinimum = 30, freestar.videoAdsRan = !1, freestar.server.diceRoll = function() {
            let e = ot({
                name: "fs.session.servertoserver"
            });
            if (!e) return function() {
                let e = !1;
                const t = ["webdesignledger.com", "www.webdesignledger.com", "headphonereview.com", "www.headphonereview.com"];
                "mobile" === freestar.deviceInfo.device.type && t.indexOf(location.hostname) > -1 && 4 === Math.floor(10 * Math.random()) && (e = !0);
                const n = new Date((new Date).getTime() + 18e5);
                at({
                    name: "fs.session.servertoserver",
                    value: e,
                    path: "",
                    expires: n
                })
            }();
            return JSON.parse(e)
        }(), 0 != freestar.fsdata.adRefreshRate && !0 !== (freestar.fsdata.visibilityRefreshDisabled && Boolean(freestar.fsdata.visibilityRefreshDisabled)) || (freestar.visibilityRefresh.runRefresh = !1), freestar.fsdata.visibilityRefreshTime && Number(freestar.fsdata.visibilityRefreshTime) > 1 && (freestar.visibilityRefresh.refreshTimeMinimum = freestar.fsdata.visibilityRefreshTime), Pt.getFirstInit().then((() => {
            !Pt.getBypassFirstAuction() && freestar.fsdata.networks.some((e => "consumable" === e.slug)) && an("https://sync.serverbid.com/ss/2000462.js")
        })), window.addEventListener("focus", (() => {
            const e = [...freestar.focusQueue];
            freestar.focusQueue = [], e.forEach((e => e.apply()))
        })),
        function(e) {
            if (e) {
                let t = document.getElementsByTagName("head")[0],
                    n = sn({
                        type: "style",
                        attributes: [{
                            type: "text/css"
                        }]
                    });
                n.appendChild(document.createTextNode(e.replace(/(\r\n|\n|\r)/gm, ""))), t.appendChild(n)
            }
        }(window.freestar.fsdata.customCss);
    const Vd = function() {
        Hd = window.googletag || {}, Hd.cmd = Hd.cmd || [], window.googletag = Hd, Hd.cmd.push((() => {
            const e = ut({
                key: "fs.abtest.group"
            });
            e && Hd.pubads().setTargeting("tg", e), Hd.pubads().setTargeting("fs_session_id", freestar.msg.sessionId), Hd.pubads().setTargeting("fs_pageview_id", freestar.msg.pageId)
        }))
    };
    if (window.googletag && window.googletag.apiReady || an("https://securepubads.g.doubleclick.net/tag/js/gpt.js"), Vd(), Be({
            name: "pubfigLoaded",
            detail: !0
        }), (lt("blockthrough") || freestar.fsdata.blockthroughEnabled && 2 === freestar.fsdata.blockthroughVersion) && Pt.getFirstInit().then((() => {
            Pt.allowBlockthrough() && function() {
                const e = document.createElement("script");
                e.src = "https://freestar-io.videoplayerhub.com/gallery.js", document.head.insertBefore(e, document.head.firstElementChild), freestar.log("inserted blockthrough script")
            }()
        })), freestar.queue.push((() => {
            if (freestar.fsdata.placements.some((e => e.sizeMappings.some((e => !0 === e.superflex))))) {
                const e = new _o({
                    placements: window.freestar.fsdata.placements.filter((e => e.sizeMappings.some((e => !0 === e.superflex))))
                });
                freestar.queue.push((function() {
                    e.active && e.registerSuperflexCallbacks()
                }))
            }
        })), freestar.queue.push((() => {
            freestar.fsdata.secondAuctionDisabled || (Xt.registerEventListeners(), freestar.rebidManager = Xt)
        })), to.setNetworks(), to.getBidderSettings(), to.setBidderSettings(), fsprebid.que.push((function() {
            fsprebid.onEvent("auctionEnd", (function(e) {
                P.logMark({
                    markerName: A.pubfigPrebidAuctionEnd,
                    compareTo: [A.pubfigPrebidAuctionInit]
                });
                const t = he(fsprebid.getBidResponses());
                for (const e in t)
                    if (freestar.networkFloor) {
                        const n = T(t[e].bids, (function(e) {
                                return e.originalCpm
                            })),
                            i = n && n.bidderCode ? freestar.networkFloor[n.bidderCode] : null;
                        n.originalCpm && n.originalCpm > 0 && i && freestar.msg.que && (n.floorApplied = 1e6 * i, n.sendCpm = Math.floor(1e6 * n.originalCpm), n.sendBidder = n.bidderCode, freestar.msg.que.push({
                            eventType: "networkFloorHit",
                            args: n
                        }))
                    }
                Li({
                    auctionData: e
                })
            }))
        })), to.enableAnalyticsAdapter(), window.freestar.fsdata.identityProviders && -1 !== window.freestar.fsdata.identityProviders.findIndex((e => "merkleId" === e.slug))) {
        const e = document.createElement("script");
        e.src = "//js-sec.indexww.com/ht/p/184310-82987131453484.js", document.head.insertBefore(e, document.head.firstElementChild), freestar.log("inserted IX Identity Library script")
    }
    const Gd = ot({
        name: "fs.admiral.whitelisted"
    }) || !1; - 1 === [285].indexOf(freestar.fsdata.siteId) && (freestar.allowBidResponseCollection = Math.random() < (freestar.fsdata.prebidLogPercentage || 1) / 100, (50 === Math.floor(99 * Math.random()) || window.location.search.indexOf("fssniffer") > -1) && freestar.queue.push((function() {
            ! function() {
                const e = {
                    video: [],
                    script: [],
                    iframe: []
                };

                function t(e) {
                    const t = e.src;
                    return "" !== t && null != t && "about:blank" !== t
                }
                Object.keys(e).forEach((n => {
                    const i = document.querySelectorAll(n);
                    e[n] = Array.from(i).filter(t).map((({
                        src: e
                    }) => e))
                })), freestar.msg.que.push({
                    eventType: "sniffer",
                    args: {
                        scripts: e.script,
                        videos: e.video,
                        iframes: e.iframe
                    }
                })
            }(), (() => {
                if ("mobile" === freestar.deviceInfo.device.type) {
                    const e = [.1, .15, .2, .25, .3, .35, .4, .45, .5, .6, .7, .8, .9],
                        t = window.innerHeight,
                        n = document.querySelectorAll("img"),
                        i = {
                            imgs: {}
                        };
                    n.forEach((n => {
                        const {
                            width: r,
                            height: s
                        } = n.getBoundingClientRect(), {
                            src: a
                        } = n;
                        e.forEach((e => {
                            s >= t * e && (i.imgs[100 * e + "%"] || (i.imgs[100 * e + "%"] = []), i.imgs[100 * e + "%"].push({
                                width: r,
                                height: s,
                                src: a
                            }))
                        }))
                    })), i.winHeight = t, Object.keys(i.imgs).length && freestar.msg.que.push({
                        eventType: "customEvent",
                        args: {
                            eventName: "SITE_SNIFFER",
                            eventType: "IMGS",
                            jsonValue: JSON.stringify(i)
                        }
                    })
                }
            })()
        }))),
        function() {
            switch (lt("publisher-slot-op")) {
                case "ias":
                    freestar.log(1, "Publisher SlotOperations Testing IAS"),
                        function() {
                            freestar.log(1, "Publisher SlotOperations Testing IAS: loading script"), an("//cdn.adsafeprotected.com/iasPET.1.js"), window.__iasPET = window.__iasPET || {};
                            const e = window.__iasPET;
                            e.queue = e.queue || [], e.pubId = "10249"
                        }();
                    break;
                case "moat":
                    freestar.log(1, "Publisher SlotOperations Testing MOAT"), it();
                    break;
                default:
                    freestar.log(1, "No Publisher SlotOperations Testing Params")
            }
        }(), freestar.debug >= 99 && (console.clear = function() {}), freestar.log(1, "Freestar Version: " + freestar.version), Le() && (freestar.log(1, "Page Speed Optimized in effect, filtering out the following products:", s.join(",")), s.forEach((e => {
            freestar.config.products[e] || (freestar.config.products[e] = {}), freestar.config.products[e] = Object.assign(freestar.config.products[e], {
                disabled: !0
            })
        })), Hd.cmd.push((function() {
            Hd.pubads().setTargeting("fs_optimization", "true")
        }))), freestar.isIE = function() {
            var e = window.navigator.userAgent,
                t = e.indexOf("MSIE ");
            if (t > 0) return parseInt(e.substring(t + 5, e.indexOf(".", t)), 10);
            if (e.indexOf("Trident/") > 0) {
                var n = e.indexOf("rv:");
                return parseInt(e.substring(n + 3, e.indexOf(".", n)), 10)
            }
            var i = e.indexOf("Edge/");
            if (i > 0) return parseInt(e.substring(i + 5, e.indexOf(".", i)), 10);
            return !1
        }(), window.setTimeout(window.freestar.func.browserInfo, 3e4), null == freestar.fsdata.timeout && (freestar.fsdata.timeout = 1200), null == freestar.fsdata.mobileTimeout && (freestar.fsdata.mobileTimeout = 1500);
    const Wd = freestar.fsdata.retries,
        Qd = ot({
            name: "fs.direct.traffic"
        });
    freestar.fsdirect = Qd, dt(), freestar.fsdata.networks = function(e, t) {
        return e.filter((e => {
            ja(e);
            const {
                deviceExclusive: n
            } = e;
            return !n || n.toLowerCase() === t.toLowerCase()
        }))
    }(freestar.fsdata.networks, freestar.deviceInfo.device.type), (new class {
        constructor() {
            this.modifications = {
                emxdigital: {
                    modification: "emx_digital"
                },
                synacor: {
                    modification: "synacormedia"
                }
            }
        }
        slugModification(e = "") {
            return this.modifications[e] ? this.modifications[e].modification : e
        }
        reassignNetworkSlug(e = []) {
            return e.map((e => (e.slug = this.slugModification(e.slug), e)))
        }
        init() {
            window.freestar.fsdata.networks = this.reassignNetworkSlug(window.freestar.fsdata.networks), window.freestar.fsdata.placements = window.freestar.fsdata.placements.map((e => (e.networks = this.reassignNetworkSlug(e.networks), e)))
        }
    }).init(), xn(), De() || (freestar.refreshLibraryCreator = (e, t) => {
        let n;
        e && (Array.isArray(e) || (e = [e]), t = t || void 0, e.forEach((e => {
            if (freestar.refreshLibrary[e] || (freestar.refreshLibrary[e] = {}), n = freestar.refreshLibrary[e], n.refreshTime && x(n.refreshTime) || (freestar.adRefresher && freestar.adRefresher.getPlacementAdRefreshRate ? n.refreshTime = Number(freestar.adRefresher.getPlacementAdRefreshRate(e)) : n.refreshTime = Number(_e(e))), n.refreshCounter && x(n.refreshCounter) || (n.refreshCounter = t || 0), n.viewPercentage && x(n.viewPercentage) || (n.viewPercentage = 100), !n.disableRefresh || !S(n.disableRefresh)) {
                n.disableRefresh = !1;
                let t = document.getElementById(e);
                t && -1 === Number(t.getAttribute("data-refresh-time")) && (n.disableRefresh = !0)
            }
            n.timesRefreshed && x(n.timesRefreshed) || (n.timesRefreshed = 0)
        })))
    });
    const Yd = () => {
        P.logMark({
            markerName: A.pubfigEngineSetupStart,
            compareTo: [A.pubfigEngineLoad]
        }), Hd.pubads().disableInitialLoad(), vn().forEach((e => {
            if (An(e))
                if (e.pushdownUnit && ot({
                        name: "fs.pushdown.optout"
                    })) {
                    let t = document.getElementById(e.name);
                    t.parentNode.removeChild(t)
                } else if (e.validAdSizes) {
                Pn(Jt({
                    placement: e,
                    id: e.name
                }), e.name, null, {
                    fs_ad_product: Fn(e)
                })
            }
        })), Pt.getFirstInit().then(Mi);
        const e = lt("dfpkey"),
            t = lt("block");
        switch (e && Ht({
            key: "test",
            value: e
        }), t && "fsdirect" === t && (at({
            name: "fs.direct.traffic",
            value: !0
        }), freestar.fsdirect = !0, Ht({
            key: "block",
            value: "fsdirect"
        })), document.referrer.search(/facebook/i) > 0 ? Ht({
            key: "referrer",
            value: "facebook"
        }) : (document.referrer.search(/twiter/i) > 0 || document.referrer.search(/t.co/i) > 0) && Ht({
            key: "referrer",
            value: "twitter"
        }), navigator.userAgent) {
            case navigator.userAgent.search(/facebook/i) > 0:
            case navigator.userAgent.search(/facebot/i) > 0:
            case navigator.userAgent.search(/FB_IAB/i) > 0:
            case navigator.userAgent.search(/FBAN/i) > 0:
            case navigator.userAgent.search(/FBAV/i):
                Ht({
                    key: "user-agent",
                    value: "facebook"
                });
                break;
            case navigator.userAgent.search(/Twitter/i) > 0:
                Ht({
                    key: "user-agent",
                    value: "twitter"
                });
                break;
            default:
                Ht({
                    key: "user-agent",
                    value: function() {
                        const e = freestar.deviceInfo.browser.name,
                            t = freestar.deviceInfo.os.name;
                        return "Mac OS" === t && "Safari" === e ? "Safari" : "iOS" === t ? "iOS" : e
                    }()
                })
        }["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"].forEach((function(e) {
            let t = lt(e);
            t && Ht({
                key: e,
                value: t
            })
        }));
        let n = !1;
        La.hadronInit(window.freestar.fsdata.identityProviders), Fd((function() {
            n || (n = !0, fsprebid.que.push((function() {
                freestar.log(1, "fspbjs.que.push - init"), Object.keys(freestar.fsdata.aliases).forEach((function(e) {
                    fsprebid.aliasBidder(freestar.fsdata.aliases[e], e)
                })), to.setEventListeners(), window.freestar.fsdata.timeout = Pt.getMaxAuctionTimeout(), to.settingConfig(fsprebid, Pt), to.setSChain(), La.setCriteoConfig(), Fi({
                    adUnits: vn().filter((e => In(e))).map((e => $n(e)))
                }), Jd()
            })))
        })), freestar.fsdata.disableSingleRequest || Hd.pubads().enableSingleRequest();
        let i = null;
        Hd.pubads().addEventListener("impressionViewable", (function(e) {
            const t = e.slot.getSlotElementId();
            t && freestar.gamImpressionCallbacks[t] && freestar.gamImpressionCallbacks[t]({
                    event: e
                }),
                function({
                    event: e
                }) {
                    Wn({
                        event: e
                    }) && (window.freestar.msg.que.push({
                        seen: !1,
                        eventType: "dfpResponse",
                        slotId: window.freestar.googleInterstitialPlacement.placement.name,
                        args: {
                            placementId: window.freestar.googleInterstitialPlacement.placement.name,
                            DfpId: e.slot.getAdUnitPath(),
                            advertiserId: window.freestar.googleInterstitialPlacement.event.advertiserId,
                            campaignId: window.freestar.googleInterstitialPlacement.event.campaignId,
                            isEmpty: window.freestar.googleInterstitialPlacement.event.isEmpty,
                            lineItemId: window.freestar.googleInterstitialPlacement.event.lineItemId,
                            serviceName: window.freestar.googleInterstitialPlacement.event.serviceName,
                            size: JSON.stringify(window.freestar.googleInterstitialPlacement.event.size),
                            sourceAgnosticCreativeId: window.freestar.googleInterstitialPlacement.event.sourceAgnosticCreativeId,
                            sourceAgnosticLineItemId: window.freestar.googleInterstitialPlacement.event.sourceAgnosticLineItemId,
                            complete: !1
                        }
                    }), delete window.freestar.googleInterstitialPlacement.event)
                }({
                    event: e,
                    elementId: t
                })
        })), Hd.pubads().addEventListener("slotRequested", (function(e) {
            null === i && (i = e.slot.getSlotElementId(), P.logMark({
                markerName: A.pubfigSlotRequested
            })), freestar.currentStickyFooter && "function" == typeof freestar.currentStickyFooter.isSticky && freestar.currentStickyFooter.isSticky(e) && P.logMark({
                markerName: A.pubfigStickyFooterSlotRequested
            })
        })), qo({
            firstAdRequestedElement: i
        }), freestar.fsdata.collapseEmptyDivs && (freestar.log("GAM Option set to collapseEmptyDivs(true)"), Hd.pubads().collapseEmptyDivs(!0)), Hd.pubads().addEventListener("slotRenderEnded", (function(e) {
            ! function(e) {
                const t = ve({
                    slotId: e.slot.getSlotElementId()
                });
                t && freestar.frequencyLibrary[t] && freestar.frequencyLibrary[t].cap && (e.isEmpty ? e.isEmpty && freestar.frequencyLibrary[t].callback && freestar.frequencyLibrary[t].callback(!0) : freestar.frequencyLibrary[t].incrementIteration())
            }(e);
            const t = e.slot.getSlotElementId();
            if (freestar.currentStickyFooter && "function" == typeof freestar.currentStickyFooter.eval && freestar.currentStickyFooter.placement.name === t && freestar.currentStickyFooter.eval(e), e.slot.getSlotElementId() === i && P.logMark({
                    markerName: A.pubfigSlotRenderEnded,
                    compareTo: [A.pubfigSlotRequested]
                }), freestar.reportLibrary[e.slot.getSlotElementId()] = e, vi(e, !1), li({
                    event: e
                }), freestar.fsdata.customDirectAdRefresh && function(e) {
                    const t = ["advertiserId", "campaignId", "lineItemId", "creativeId"];
                    for (const n of t) {
                        const t = e[n];
                        if (null != t && window.freestar.fsdata.directAdRefreshTargeting.includes(t.toString())) return window.freestar.log(1, `found ${n} ${t} in directAdRefreshTargeting, setting refresh ${window.freestar.fsdata.directAdRefreshRate}.`), !0
                    }
                    return !1
                }(e)) {
                ke(e.slot.getSlotElementId())
            }
        })), Hd.pubads().addEventListener("slotOnload", wi), Hd.pubads().addEventListener("slotRenderEnded", Yo);
        const r = ["hb_format", "hb_size", "hb_pb", "hb_adid", "hb_bidder"];
        Hd.pubads().addEventListener("slotRenderEnded", (e => {
                const {
                    slot: t
                } = e;
                r.forEach((e => {
                    0 !== t.getTargeting(e).length && t.clearTargeting(e)
                }))
            })), freestar.fsdata.customDirectAdRefresh && setInterval(Se, 5e3), Hd.enableServices(), !Gd && window.admiral && window.admiral("after", "measure.detected", (e => {
                e.whitelisted && (at({
                    name: "fs.admiral.whitelisted",
                    value: !0,
                    path: "",
                    expires: new Date((new Date).getTime() + 31536e6)
                }), Hd.pubads().setTargeting("fs_admrl_whtlstd", "true"))
            })), Gd && Hd.pubads().setTargeting("fs_admrl_whtlstd", "true"), P.logMark({
                markerName: A.pubfigEngineSetupEnd,
                compareTo: [A.pubfigEngineSetupStart]
            }),
            function() {
                const e = lt("fs-joke");
                /true/i.test(e) && window.freestar && (window.freestar.joke = Ud)
            }()
    };
    if (On()) throw new Error("Ad serving is blocked in " + freestar.locData.iso); {
        if (performance.mark("pubfig-init"), Hd.cmd.unshift ? Hd.cmd.unshift((function() {
                freestar.log(1, " googletag.cmd.unshift - init"), $t.getInitialFloorsData().then(Yd)
            })) : (freestar.log({
                title: "WARNING!",
                styles: "background: red; color: white; border-radius: 3px; padding: 3px"
            }, " googletag.cmd.unshift not found skipping"), $t.getInitialFloorsData().then(Yd)), "complete" === document.readyState) Zd();
        else {
            let e = setInterval((function() {
                "complete" === document.readyState && (clearInterval(e), Zd())
            }), 100)
        }
        window.addEventListener("load", (function(e) {
            Zd()
        })), an(n);
        const e = t;
        let i = setTimeout((function() {
            clearTimeout(i), an(e, (() => {
                kd(), window.setInterval(kd, 500)
            }))
        }), 1e3)
    }
    const Kd = function(e) {
        this.slots = e || Gt(), this.time = {}, this.time.default = freestar.fsdata.adRefreshRate || 0, this.bidTimeout = window.freestar.fsdata.timeout, this.init = function() {
            De() || (freestar.log(25, "REFRESH V1 Enabled"), window.freestar.adRefresher = this, this.onLoad())
        }, this.onLoad = function() {
            for (let t = 0; t < this.slots.length; t++) {
                let n = this.slots[t].getSlotElementId();
                freestar.refreshLibraryCreator(n), e && this.refresh(this.slots[t].getSlotElementId(), document.getElementById(n))
            }
            window.setInterval(function() {
                if (document.hasFocus())
                    for (const e in freestar.refreshLibrary) {
                        const t = document.getElementById(e);
                        t && this.isActive(t) && this.counter(t)
                    }
            }.bind(this), 1e3)
        }, this.resetAdRefreshCounter = function() {
            for (const e in freestar.refreshLibrary) freestar.log({
                title: "REFRESH"
            }, "adRefresher.resetAdRefreshCounter", `for ${e}`), freestar.refreshLibrary[e].refreshCounter = 0
        }, this.isActive = function(e) {
            return nl(e) ? (freestar.refreshLibrary[e.id].viewPercentage = 100, !0) : (freestar.refreshLibrary[e.id].viewPercentage = 0, !1)
        }, this.counter = function(e) {
            const t = freestar.refreshLibrary[e.id],
                n = Ti({
                    name: ve({
                        slotId: e.id
                    })
                });
            if (n && n.lazyAd && !t.hasIntersectLazyAd) return;
            if (t.disableRefresh) return;
            let i = t.refreshTime;
            if ((void 0 === i || isNaN(i) || null === i) && (i = this.getPlacementAdRefreshRate(e.id), freestar.log(25, " ", "freestar.fsdata.adRefreshRate", i)), i <= 0) return;
            let r = t.refreshCounter;
            if ((void 0 === r || isNaN(r)) && (r = 0), !(r < 0)) {
                if (r += 1, window.freestar.fsdata.isTriple13Enabled && r >= .9 * i && !freestar.refreshLibrary[e.id].floorsRefreshed) {
                    const t = Ti({
                        name: e.id
                    });
                    t && (freestar.refreshLibrary[e.id].timesRefreshed += 1, $t.getFloorsData({
                        placement: t,
                        slotId: e.id,
                        callback: ({
                            result: t
                        }) => {
                            if (freestar.refreshLibrary[e.id].timesRefreshed -= 1, t) {
                                freestar.refreshLibrary[e.id].floorsRefreshed = !0;
                                const n = Wt({
                                    elementId: e.id
                                });
                                Object.keys(t).forEach((e => {
                                    n.setTargeting(e, t[e])
                                })), freestar.log({
                                    title: "FLOORS"
                                }, e.id, "Refreshed floors value.", t)
                            }
                        }
                    }))
                }
                t.refreshCounter = r, freestar.log({
                    title: "REFRESH"
                }, e.id, t.refreshCounter), r >= i && (freestar.refreshLibrary[e.id].timesRefreshed += 1, freestar.refreshLibrary[e.id].floorsRefreshed = !1, Xt.reset({
                    elementId: e.id
                }), freestar.currentStickyFooter && freestar.currentStickyFooter.placement && e.id === freestar.currentStickyFooter.placement.name ? (freestar.log({
                    title: "REFRESH"
                }, e.id, "Refreshing sticky footer ad slot..."), freestar.currentStickyFooter.stickyFooterRefresh()) : (freestar.log({
                    title: "REFRESH"
                }, e.id, "Refreshing standard ad slot..."), Ee(e), freestar.refreshLibrary[e.id].refreshCounter = 0, this.refresh(e.id)))
            }
        }, this.refresh = function(e) {
            freestar.refreshLibrary[e] || freestar.refreshLibraryCreator(e), freestar.refreshLibrary[e].dataRefreshId = bi(), freestar.refreshSlots.push({
                refreshId: freestar.refreshLibrary[e].dataRefreshId
            });
            const t = Wt({
                elementId: e
            });
            t && fsprebid.que.push((function() {
                t.setTargeting("fsrefresh", `${freestar.refreshLibrary[e].timesRefreshed}`), ji([e], t)
            }))
        }, this.getPlacementAdRefreshRate = _e, this.init()
    };

    function Jd() {
        if (freestar.log(1, " initAdserver"), !fsprebid.initAdserverSet) {
            if (!Hd.pubadsReady && fsprebid.retries <= Wd) return setTimeout(Jd, 50), void fsprebid.retries++;
            fsprebid.initAdserverSet = !0, freestar.log(1, " fsInitAdserver"), Qo((function(e, t) {
                    freestar.log(1, "Page Grabber: " + (t ? "completed page grabber session" : "either the grabber placement is failing or there is no grabber placement")), freestar.newAdSlotsAllowed = !0, freestar.newAdSlotsQueue.forEach((e => e.process())),
                        function() {
                            const e = {
                                    elementIds: [],
                                    bidObjects: [],
                                    slots: []
                                },
                                t = (t, n) => {
                                    n && (e.elementIds.push(n.placement.name), e.bidObjects.push(n.bidObject), e.slots.push(n.slot))
                                };
                            (function(e) {
                                performance.mark("pushdown-initialization-start");
                                const t = [],
                                    n = [],
                                    i = "pushdownOptions";
                                freestar.fsdata.placements.forEach((function(e) {
                                    if (ge({
                                            placement: e,
                                            type: i
                                        })) {
                                        const {
                                            micro: r,
                                            isOnCall: s,
                                            isPushdownUnit: a
                                        } = be({
                                            placement: e,
                                            type: i
                                        });
                                        a && !s && (r ? t.push(e) : n.push(e))
                                    }
                                }));
                                let r = !0;
                                if (t.length)
                                    for (let n = 0; n < t.length; n++) {
                                        const {
                                            trigger: s,
                                            isOnCall: a,
                                            isPushdownUnit: o,
                                            isBodyZero: d
                                        } = be({
                                            placement: t[n],
                                            type: i
                                        });
                                        if (!a && o && document.getElementById(s)) {
                                            Po(t[n], e), r = !1;
                                            break
                                        }
                                    }
                                r && n[0] && Po(n[0], e), performance.mark("pushdown-initialization-end")
                            })(t),
                            function(e) {
                                const t = freestar.fsdata.placements.filter((e => ge({
                                    placement: e,
                                    type: "topAdhesionOptions"
                                }) && Object.keys(be({
                                    placement: e,
                                    type: "topAdhesionOptions"
                                })).length > 0));
                                t.length > 0 && (performance.mark("topAdhesion-initialization-start"), Mo(t[0], e), performance.mark("topAdhesion-initialization-end"))
                            }(t),
                            function(e) {
                                performance.mark("sideWalls-initialization-start");
                                const t = ({
                                    select: e
                                }) => !(e && e.length && !(e && e.length && document.getElementById("fs-select-side-wall")) && !document.getElementById(e));
                                freestar.fsdata.placements.filter((function(e) {
                                    if (ge({
                                            placement: e,
                                            type: "sideWallOptions"
                                        })) {
                                        const {
                                            orientation: n,
                                            isOnCall: i,
                                            select: r
                                        } = be({
                                            placement: e,
                                            type: "sideWallOptions"
                                        }), s = uo({
                                            placement: e
                                        });
                                        if (!i && n && s && 0 !== n && s > 0 && t({
                                                select: r
                                            })) return e
                                    }
                                })).length ? bo(null, e) : e(!0), performance.mark("sideWalls-initialization-end")
                            }(t), hd(), gd(), vr();
                            const n = Bn();
                            n.init();
                            let i = !1;
                            fsprebid.onEvent("auctionInit", (() => {
                                    i || (Wo(), i = !0)
                                })), freestar.fsdata.singleLineEnabled && (freestar.log({
                                    title: "SLO"
                                }, "Single line of code enabled"), freestar.fsdata.placements.forEach((e => {
                                    (function({
                                        placement: e
                                    }) {
                                        for (const t in p) {
                                            const n = e[t.optionsPath || `${t}Options`];
                                            if (n && n.active || n && "pushdown" === t && n.isPushdownUnit || n && "sideWall" === t && n.type > 0) return !1
                                        }
                                        return !!document.getElementById(e.name)
                                    })({
                                        placement: e
                                    }) && freestar.config.enabled_slots.push({
                                        placementName: e.name,
                                        slotId: e.name
                                    })
                                }))), freestar.fsdata.placements.forEach((e => {
                                    const t = be({
                                            placement: e,
                                            type: "dynamicAdOptions"
                                        }),
                                        i = be({
                                            placement: e,
                                            type: "dynamicAdOptionsV2"
                                        });
                                    if (t.active) {
                                        freestar.log({
                                            title: "DYNAMICADS"
                                        }, "Calling", e.name);
                                        const i = new Fo(t, n);
                                        new Lo(e, i)
                                    } else if (i.dynamicAd2) {
                                        freestar.log({
                                            title: "Dynamic Ads V2"
                                        }, "Calling", e.name);
                                        const t = new Fo(i, n);
                                        new jo(e, t).init()
                                    }
                                })), freestar.fsdata.videoAds && freestar.fsdata.videoAds.length && !freestar.videoAdsRan && (performance.mark("video-initialization-start"), freestar.fsdata.videoAds.forEach((function(e) {
                                    freestar.log(1, `VIDEO: Checking to see if ${e.name} should run`), e.onCallVideo ? freestar.log(1, "VIDEO: Video is on call and will not run until the freestar.newVideo method is ran") : (freestar.log(1, `VIDEO: ${e.name} is being created!`), Cr(e))
                                })), freestar.videoAdsRan = !0, performance.mark("video-initialization-end")),
                                function() {
                                    if (void 0 !== freestar.fsdata.quantcast && !1 === freestar.fsdata.quantcast || (window._qevents = window._qevents || [], Array.isArray(window._qevents) && window._qevents.push({
                                            qacct: "p-UeXruRVtZz7w6"
                                        }), an("https://secure.quantserve.com/quant.js")), freestar.fsdata.scripts2 && Array.isArray(freestar.fsdata.scripts2)) {
                                        const e = freestar.fsdata.scripts2;
                                        for (let t = 0; t < e.length; t++)
                                            if (!0 === e[t].active) {
                                                const n = Math.floor(100 * Math.random()) + 1,
                                                    i = e[t].versions;
                                                let r = 0;
                                                freestar.log(2, `Rolled ${n} for script ${e[t].name}`);
                                                for (let s = 0; s < i.length; s++)
                                                    if (!0 === i[s].active && (r += i[s].trafficPercentage, n <= r)) {
                                                        freestar.log(2, `Selecting version ${i[s].name} for script ${e[t].name}. ${i[s].trafficPercentage}% chance.`);
                                                        try {
                                                            an(i[s].href)
                                                        } catch (e) {
                                                            console.error(e)
                                                        }
                                                        break
                                                    }
                                            }
                                    } else if (freestar.fsdata.scripts && Array.isArray(freestar.fsdata.scripts))
                                        for (let e = 0; e < freestar.fsdata.scripts.length; e++) try {
                                            an(freestar.fsdata.scripts[e])
                                        } catch (e) {
                                            console.error(e)
                                        }
                                }(), freestar.visibilityRefresh.enacted || !0 !== freestar.visibilityRefresh.runRefresh || (freestar.visibilityRefresh.enacted = !0, bd || (bd = !0, document.addEventListener("visibilitychange", (function() {
                                    return !document.hidden && freestar.visibilityRefresh.timeLeft && Date.now() - freestar.visibilityRefresh.timeLeft > 1e3 * freestar.visibilityRefresh.refreshTimeMinimum && (freestar.visibilityRefresh.timeLeft = null, freestar.refreshActiveSlots()), freestar.visibilityRefresh.timeLeft = Date.now(), !0
                                })))), freestar.loaded = !0, Le() ? (freestar.log({
                                    title: "PSO"
                                }, "Loading Page Speed Optimized Sticky Footer"), freestar.newStickyFooter()) : function() {
                                    try {
                                        performance.mark("stickyFooter-initialization-start");
                                        const e = "Sticky Footer: initStickyFooter method - ";
                                        freestar.log(1, e + " invoked looking for sticky placements!");
                                        const t = "stickyFooterOptions",
                                            n = freestar.fsdata.placements.filter((e => e.validAdSizes && ge({
                                                placement: e,
                                                type: t
                                            }) && e[t].isOnCall));
                                        if (n.length) freestar.log(1, `${e} there are ${n.length} on call sticky footer placements. There will be no standard sticky footer invoked by Pubfig.js!`);
                                        else {
                                            freestar.log(1, e + " there are no on call sticky footer placements. Attempting to find a default sticky footer placement");
                                            const n = freestar.fsdata.placements.filter((e => e.validAdSizes && ge({
                                                placement: e,
                                                type: t
                                            }) && !e[t].isOnCall))[0];
                                            if (n && !Ho({
                                                    placement: n
                                                })) {
                                                freestar.log(1, `${e} ${n.name} is not blocked invoking AddStickyFooter.`);
                                                let {
                                                    stickyFooterOutstreamVideoPattern: t
                                                } = ur(n);
                                                "VIDEO_DISPLAY_CONCURRENT" === t && n.stickyFooterOptions.video ? freestar.currentStickyFooter = new dr({
                                                    placement: n
                                                }) : freestar.currentStickyFooter = new ar(n), freestar.deleteStickyFooter = freestar.currentStickyFooter.deleteStickyFooter || freestar.currentStickyFooter.footer.deleteStickyFooter
                                            } else freestar.log(1, e + "no default sticky placement found or it is blocked due to rules found in the footerIsBlocked method. There will be no standard sticky footer invoked by Pubfig.js!")
                                        }
                                        performance.mark("stickyFooter-initialization-end")
                                    } catch (e) {
                                        freestar.log({
                                            title: "STICKY FOOTER",
                                            styles: "background: red; color: white; border-radius: 3px; padding: 3px"
                                        }, e.message)
                                    }
                                }();
                            let r = rl({
                                queue: []
                            }, freestar);
                            freestar.queue = {
                                push: function(e) {
                                    Hd.cmd.push(e)
                                }
                            };
                            for (let e = 0; e < r.queue.length; e++) freestar.queue.push(r.queue[e]);
                            r = {}, Xd(), (!freestar.initCallback || freestar.initCallback && "function" == typeof freestar.initCallback && -1 === freestar.initCallback.toString().indexOf("enabled_slots")) && freestar.config && freestar.config.enabled_slots && freestar.config.enabled_slots.length && (performance.mark("check-ad-enabled-slots-start"), freestar.config.enabled_slots.forEach((function(t) {
                                "object" != typeof t && (t = {
                                    placementName: t,
                                    slotId: t
                                });
                                const n = Ti({
                                        name: ve({
                                            slotId: t.placementName
                                        })
                                    }),
                                    i = document.getElementById(t.slotId),
                                    {
                                        targeting: r = {}
                                    } = t;
                                if (i && n && n.validAdSizes)
                                    if (i.setAttribute("name", n.name), n.lazyAd && n.selectedSize && n.selectedSize.lazyLoadViewportHeight > 0) Rn({
                                        element: i,
                                        placement: n
                                    });
                                    else {
                                        const i = Ci({
                                            placement: n,
                                            slotId: t.slotId,
                                            targeting: r
                                        });
                                        i && (e.elementIds.push(t.slotId), i.bidObject && e.bidObjects.push(i.bidObject), i.slot && e.slots.push(i.slot))
                                    }
                            })), performance.mark("check-ad-enabled-slots-end"), freestar.config.enabled_slots = [], e.bidObjects = e.bidObjects.filter((e => -1 === fsprebid.adUnits.map((e => e.code)).indexOf(e.code)))), e.bidObjects.length && Fi({
                                adUnits: e.bidObjects
                            }), e.elementIds.length && ji(e.elementIds, e.slots), void 0 !== freestar.fsdata.adRefreshRate && void 0 === window.freestar.adRefresher && (De() ? freestar.adRefresher = new jt : new Kd)
                        }()
                })),
                function() {
                    if (window.innerWidth > 2500 || Nn({
                            name: "googleInterstitial"
                        })) return !1;
                    const e = Gn();
                    e && (performance.mark("interstitial-initialization-start"), window.freestar.googleInterstitialPlacement = {
                        placement: e
                    }, window.googletag.cmd.push((() => {
                        const t = Kt({
                            dfpId: e.dfpId,
                            elementId: window.googletag.enums.OutOfPageFormat.INTERSTITIAL
                        });
                        t && (Vt({
                            slot: t,
                            key: "fs_ad_product",
                            value: "googleInterstitial"
                        }), window.googletag.pubads().refresh([t]), ye({
                            placementName: e.name,
                            slotId: t.getSlotElementId()
                        }))
                    })), performance.mark("interstitial-initialization-end"))
                }()
        }
    }

    function Xd() {
        if (freestar.callbackIntervalCount++, fsprebid.initAdserverSet && void 0 !== freestar.initCallback && void 0 === freestar.initCallbackCalled && "function" == typeof freestar.initCallback) {
            return freestar.initCallbackCalled = !0, clearInterval(freestar.callbackInterval), freestar.initCallback(),
                function(e, t) {
                    e.push = function(n) {
                        Array.prototype.push.call(e, n), t(e)
                    }
                }(freestar.config.enabled_slots, (function(e) {
                    Un([e[e.length - 1]])
                })), !0
        }
        return freestar.callbackIntervalCount > 50 && clearInterval(freestar.callbackInterval), !1
    }

    function Zd() {
        if (freestar.func.domloaded) return;
        const e = document.getElementsByTagName("body")[0],
            t = ni() || freestar.fsdata.reportThisAd ? "var(--use)" : "var(--doNotUse)";
        e.style.setProperty("--fsAncillary", t), yi(), freestar.fsdata.addIsFreestar && !e.classList.contains("is-freestar") && (e => {
                const t = document.getElementsByTagName("body")[0]; - 1 == t.className.indexOf(`${e}`) && (t.className += t.className.length ? ` ${e}` : e)
            })("is-freestar"), freestar.fsdata.reorientationRefresh && !freestar.config.disableReorientation && (freestar.config.alwaysRefresh || (freestar.config.alwaysRefresh = freestar.fsdata.placements.map((e => e.name))), vo()), freestar.func.domloaded = !0, freestar.callbackIntervalCount = 0, freestar.callbackInterval = window.setInterval(Xd, 200), "mobile" === freestar.deviceInfo.device.type && window.addEventListener("orientationchange", il),
            function(e = new Date((new Date).getTime() + 33696e6)) {
                function t(e, t, n) {
                    return n.substring(0, e) + t + n.substring(e + t.length)
                }
                if ("FREESTAR" === window.freestar.fsdata.cmpType && "US" === window.freestar.locData.iso) {
                    const n = "usprivacy",
                        i = ot({
                            name: n
                        });
                    if (c.includes(window.freestar.locData.state))
                        if (i) {
                            const r = "//a[text()='Do Not Sell My Personal Information']",
                                s = document.evaluate(r, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                            "N" === i[1] && at(s ? {
                                name: n,
                                value: t(1, "Y", i),
                                domain: `.${window.location.host}`,
                                expires: e
                            } : {
                                name: n,
                                value: t(1, "-", i),
                                domain: `.${window.location.host}`,
                                expires: e
                            })
                        } else at({
                            name: n,
                            value: "1-N-",
                            domain: `.${window.location.host}`,
                            expires: e
                        })
                }
            }()
    }

    function el(e, t = !0) {
        t && console.warn("freestar.freestarReloadAdSlot() has been deprecated and will be removed in the future use freestar.refresh()"), freestar.queue.push((function() {
            De() ? jt.refreshSlots({
                slotIds: "string" == typeof e ? [e] : e
            }, t) : tl({
                slotIds: "string" == typeof e ? [e] : e
            }, t)
        }))
    }

    function tl({
        slotIds: e
    } = {
        slotIds: null
    }, t = !0) {
        t && console.warn("freestar.freestarReloadAdSlot() has been deprecated and will be removed in the future use freestar.refreshAllSlots()"), freestar.log(1, `${e?"freestar.refresh":"freestar.refreshAllSlots"}${e?" : "+e:null}`);
        const n = [],
            i = Gt().map((function(t) {
                let i = t.getSlotElementId();
                if (freestar.refreshLibrary[i]) {
                    if (-1 === freestar.refreshLibrary[i].refreshTime) return;
                    try {
                        freestar.refreshLibrary[i].refreshCounter > -1 ? freestar.refreshLibrary[i].refreshCounter++ : freestar.refreshLibrary[i].refreshCounter = 1
                    } catch (e) {
                        freestar.log(1, "freestar.refreshAllSlots slot not found", i)
                    }
                }
                if (!e || e.indexOf(i) > -1) return n.push(i), freestar.refreshLibrary[i] && (freestar.refreshLibrary[i].refreshCounter = 1), t
            })).filter((e => void 0 !== e));
        e && !n.length || (n.forEach((e => {
            Xt.reset({
                elementId: e
            })
        })), ji(n, i))
    }

    function nl(e) {
        let t = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
            n = e.getBoundingClientRect().top + Math.trunc(e.scrollHeight / 2);
        return n > 0 && n <= t
    }

    function il() {
        void 0 !== freestar.resizetimer && window.clearTimeout(freestar.resizetimer), freestar.resizetimer = window.setTimeout((function() {
            xn(), freestar.currentStickyFooter && freestar.currentStickyFooter.eval && "function" == typeof freestar.currentStickyFooter.eval && freestar.currentStickyFooter.eval({
                isEmpty: !0
            })
        }), 300)
    }

    function rl() {
        let e = {},
            t = !1,
            n = 0,
            i = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (t = arguments[0], n++);
        let r = function(n) {
            for (let i in n) Object.prototype.hasOwnProperty.call(n, i) && (t && "[object Object]" === Object.prototype.toString.call(n[i]) ? e[i] = rl(!0, e[i], n[i]) : e[i] = n[i])
        };
        for (; n < i; n++) r(arguments[n]);
        return e
    }
    freestar.disableRefresh = function() {
        Ce() && Me({
            disableRefresh: !0
        })
    }, freestar.disableRefreshOn = function({
        slotId: e,
        placementName: t
    }) {
        t ? Ne({
            placementName: t,
            disableRefresh: !1
        }) : e && Re({
            slotId: e,
            methodName: "disableRefreshKey"
        }) && Te({
            slotId: e,
            disableRefresh: !0
        })
    }, freestar.enableRefresh = function() {
        Ce() && Me({
            disableRefresh: !1
        })
    }, freestar.enableRefreshOn = function({
        slotId: e,
        placementName: t
    }) {
        t ? Ne({
            placementName: t,
            disableRefresh: !1
        }) : e && Re({
            slotId: e,
            methodName: "enableRefreshOn"
        }) && Te({
            slotId: e,
            disableRefresh: !1
        })
    }, freestar.DynamicAds = Lo, freestar.fsRequestBids = ji, freestar.refresh = e => {
        el(e, !1)
    }, freestar.refreshAllSlots = ({
        slotIds: e
    } = {
        slotIds: null
    }) => {
        De() ? jt.refreshSlots({
            slotIds: e
        }, !1) : tl({
            slotIds: e
        }, !1)
    }, freestar.refreshActiveSlots = () => {
        let e = [];
        Gt().map((function(t) {
            const n = t.getSlotElementId(),
                i = document.getElementById(n);
            i && nl(i) && e.push(n)
        })), freestar.refreshAllSlots({
            slotIds: e
        }, !1)
    };
    let sl = !1;

    function al() {
        if (sl) return;
        sl = !0, freestar.log(49, "newDynamicContent called", Date.now()), freestar.fsdata.placements.forEach((e => {
            const t = be({
                placement: e,
                type: "dynamicAdOptions"
            });
            if (t.active) {
                freestar.log({
                    title: "DYNAMICADS"
                }, "Calling", e.name);
                const n = new Fo(t, Bn());
                new Lo(e, n)
            }
        }));
        let e = setTimeout((function() {
            freestar.log(49, "newDynamicContentCalled cleared", Date.now()), sl = !1, clearTimeout(e)
        }), 1e3)
    }
}();