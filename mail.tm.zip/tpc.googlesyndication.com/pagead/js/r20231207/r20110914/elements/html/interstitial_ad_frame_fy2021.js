(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var n = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = n, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    }

    function ba(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ca(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function q(a, b, c) {
        q = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ba : ca;
        return q.apply(null, arguments)
    };
    var da = aa(610401301, !1),
        fa = aa(572417392, !0);
    var r;
    const ha = n.navigator;
    r = ha ? ha.userAgentData || null : null;

    function ia(a) {
        return da ? r ? r.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function w(a) {
        var b;
        a: {
            if (b = n.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function x() {
        return da ? !!r && 0 < r.brands.length : !1
    }

    function ja() {
        return x() ? ia("Chromium") : (w("Chrome") || w("CriOS")) && !(x() ? 0 : w("Edge")) || w("Silk")
    };

    function ka(a) {
        ka[" "](a);
        return a
    }
    ka[" "] = function() {};
    !w("Android") || ja();
    ja();
    w("Safari") && (ja() || (x() ? 0 : w("Coast")) || (x() ? 0 : w("Opera")) || (x() ? 0 : w("Edge")) || (x() ? ia("Microsoft Edge") : w("Edg/")) || x() && ia("Opera"));
    var la = !fa;
    let ma = !fa;
    let y = 0,
        A = 0;

    function na(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        if (b) {
            b = c;
            c = ~a;
            b ? b = ~b + 1 : c += 1;
            const [d, e] = [b, c];
            a = e;
            c = d
        }
        y = c >>> 0;
        A = a >>> 0
    };
    var B = Symbol();

    function oa(a) {
        const b = a[B] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), a[B] = b | 1)
    }

    function pa() {
        var a = [];
        a[B] |= 1;
        return a
    }

    function C(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var qa = {},
        ra = {};

    function sa(a) {
        return !(!a || "object" !== typeof a || a.aa !== ra)
    }

    function E(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let va = !fa;

    function wa(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[B] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[B] = d | 1;
        return !0
    }
    var F;
    const xa = [];
    xa[B] = 55;
    F = Object.freeze(xa);
    class ya {}
    class za {}
    Object.freeze(new ya);
    Object.freeze(new za);
    const Aa = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function H(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function Ba(a) {
        if (null == a) return a;
        var b = typeof a;
        if ("number" === b ? Number.isFinite(a) : "string" !== b ? 0 : Aa.test(a)) {
            if ("number" === typeof a) {
                var c = Math.trunc(a);
                if (!Number.isSafeInteger(c)) {
                    na(c);
                    a = y;
                    b = A;
                    if (c = b & 2147483648) a = ~a + 1 >>> 0, b = ~b >>> 0, 0 == a && (b = b + 1 >>> 0);
                    a = 4294967296 * b + (a >>> 0);
                    c = c ? -a : a
                }
            } else b = Math.trunc(Number(a)), Number.isSafeInteger(b) ? c = String(b) : (b = a.indexOf("."), -1 !== b && (a = a.substring(0, b)), ("-" === a[0] ? 20 > a.length || 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length || 19 === a.length &&
                922337 > Number(a.substring(0, 6))) ? c = a : (16 > a.length ? na(Number(a)) : (a = BigInt(a), y = Number(a & BigInt(4294967295)) >>> 0, A = Number(a >> BigInt(32) & BigInt(4294967295))), a = y, b = A, b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b >>>= 0, a >>>= 0, 2097151 >= b ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a)))));
            return c
        }
    };
    let I;

    function Ca(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return va || !wa(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                }
        }
        return a
    };

    function Da(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[B] | 0) & 1 ? void 0 : f && (a[B] | 0) & 2 ? a : Ea(a, b, c, void 0 !== d, e, f);
            else if (E(a)) {
                const g = {};
                for (let k in a) g[k] = Da(a[k], b, c, d, e, f);
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function Ea(a, b, c, d, e, f) {
        const g = d || c ? a[B] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = Array.prototype.slice.call(a);
        for (let k = 0; k < a.length; k++) a[k] = Da(a[k], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function Fa(a) {
        return a.Z === qa ? a.toJSON() : Ca(a)
    };

    function J(a, b) {
        a = a.m;
        return Ga(a, a[B], b)
    }

    function Ga(a, b, c) {
        if (-1 === c) return null;
        if (c >= C(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else if (b = c + (+!!(b & 512) - 1), b < a.length) return a[b]
    }

    function Ha(a) {
        var b = a.m;
        let c = b[B];
        var d = Ga(b, c, 13);
        a = null == d || "number" === typeof d ? d : "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        if (null != a && a !== d) a: {
            var e = C(c);
            if (13 >= e) {
                d = c;
                if (c & 256) e = b[b.length - 1];
                else {
                    if (null == a) break a;
                    e = b[e + (+!!(c & 512) - 1)] = {};
                    d |= 256
                }
                e[13] = a;
                d !== c && (b[B] = d)
            } else b[13 + (+!!(c & 512) - 1)] = a,
            c & 256 && (b = b[b.length - 1], 13 in b && delete b[13])
        }
        return a
    }

    function L(a) {
        return a ? ? 0
    }

    function M(a, b) {
        a = J(a, b);
        return (null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0) ? ? !1
    }

    function N(a, b) {
        a = J(a, b);
        return (null == a || "string" === typeof a ? a : void 0) ? ? ""
    };
    var Ja = class {
        constructor(a) {
            a: {
                null == a && (a = I);I = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[B] | 0;
                    if (b & 64) break a;
                    b |= 64;
                    var c = a.length;
                    if (c && (--c, E(a[c]))) {
                        b |= 256;
                        c -= +!!(b & 512) - 1;
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[B] = b
            }
            this.m = a
        }
        toJSON() {
            var a = Ea(this.m, Fa, void 0, void 0, !1, !1);
            return Ia(this, a, !0)
        }
    };
    Ja.prototype.Z = qa;
    Ja.prototype.toString = function() {
        return Ia(this, this.m, !1).toString()
    };

    function Ia(a, b, c) {
        const d = a.constructor.ba;
        var e = (c ? a.m : b)[B],
            f = C(e),
            g = !1;
        if (d && va) {
            if (!c) {
                b = Array.prototype.slice.call(b);
                var k;
                if (b.length && E(k = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, k);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            k = a.m[B];
            a = C(k);
            k = +!!(k & 512) - 1;
            var h;
            for (let G = 0; G < d.length; G++) {
                var l = d[G];
                if (l < a) {
                    l += k;
                    var p = f[l];
                    null == p ? f[l] = c ? F : pa() : c && p !== F && oa(p)
                } else {
                    if (!h) {
                        var m = void 0;
                        f.length && E(m = f[f.length - 1]) ? h = m : f.push(h = {})
                    }
                    p = h[l];
                    null == h[l] ? h[l] = c ? F : pa() : c && p !== F &&
                        oa(p)
                }
            }
        }
        h = b.length;
        if (!h) return b;
        let u, Y;
        if (E(m = b[h - 1])) {
            a: {
                var v = m;f = {};c = !1;
                for (var z in v) {
                    a = v[z];
                    if (Array.isArray(a)) {
                        k = a;
                        if (!ma && wa(a, d, +z) || !la && sa(a) && 0 === a.size) a = null;
                        a != k && (c = !0)
                    }
                    null != a ? f[z] = a : c = !0
                }
                if (c) {
                    for (let G in f) {
                        v = f;
                        break a
                    }
                    v = null
                }
            }
            v != m && (u = !0);h--
        }
        for (e = +!!(e & 512) - 1; 0 < h; h--) {
            z = h - 1;
            m = b[z];
            if (!(null == m || !ma && wa(m, d, z - e) || !la && sa(m) && 0 === m.size)) break;
            Y = !0
        }
        if (!u && !Y) return b;
        var K;
        g ? K = b : K = Array.prototype.slice.call(b, 0, h);
        b = K;
        g && (b.length = h);
        v && b.push(v);
        return b
    };
    var Ka = function(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b[B] |= 32;
                I = b;
                b = new a(b);
                I = void 0
            }
            return b
        }
    }(class extends Ja {});

    function La(a = window) {
        return a
    };
    var O = window;

    function P(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function Q(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    };
    var Ma = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Na(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    let R = [];
    const Oa = () => {
        const a = R;
        R = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var Pa = (a, b) => {
        "complete" === a.readyState || "interactive" === a.readyState ? (R.push(b), 1 == R.length && (window.Promise ? Promise.resolve().then(Oa) : window.setImmediate ? setImmediate(Oa) : setTimeout(Oa, 0))) : a.addEventListener("DOMContentLoaded", b)
    };

    function Qa(a = document) {
        return a.createElement("img")
    };

    function Ra(a, b, c = null, d = !1) {
        Sa(a, b, c, d)
    }

    function Sa(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = Qa(a.document);
        if (c || d) {
            const f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    const k = Array.prototype.indexOf.call(g, e, void 0);
                    0 <= k && Array.prototype.splice.call(g, k, 1)
                }
                Q(e, "load", f);
                Q(e, "error", f)
            };
            P(e, "load", f);
            P(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function Ta(a, b) {
        var c;
        if (c = a.navigator) c = a.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
        c && a.navigator.sendBeacon ? a.navigator.sendBeacon(b) : Ra(a, b, void 0, !1)
    };
    let Ua = 0;

    function Va(a) {
        return (a = Wa(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function Wa(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[${"data-jc"}="${a}"]`)
    };
    class $a {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const ab = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var bb = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        cb = class {
            constructor(a, b) {
                this.url = a;
                this.X = !!b;
                this.depth = null
            }
        };
    let db = null;

    function eb() {
        const a = n.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function fb() {
        const a = n.performance;
        return a && a.now ? a.now() : null
    };
    var gb = class {
        constructor(a, b) {
            var c = fb() || eb();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const S = n.performance,
        hb = !!(S && S.mark && S.measure && S.clearMarks),
        T = function(a) {
            let b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        }(() => {
            var a;
            if (a = hb) {
                var b;
                if (null === db) {
                    db = "";
                    try {
                        a = "";
                        try {
                            a = n.top.location.hash
                        } catch (c) {
                            a = n.location.hash
                        }
                        a && (db = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = db;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        });

    function ib(a) {
        a && S && T() && (S.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), S.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }
    class jb {
        constructor() {
            var a = window;
            this.i = [];
            this.j = a || n;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = T() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new gb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            S && T() && S.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (fb() || eb()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                S && T() && S.mark(b);
                !this.g || 2048 <
                    this.i.length || this.i.push(a)
            }
        }
    };

    function kb(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function lb(a, b, c, d, e) {
        const f = [];
        Na(a, function(g, k) {
            (g = mb(g, b, c, d, e)) && f.push(k + "=" + g)
        });
        return f.join(b)
    }

    function mb(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(mb(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(lb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function nb(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function ob(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = nb(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                k = a.i[g];
            for (let h = 0; h < k.length; h++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let l = lb(k[h], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class pb {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };

    function qb(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }

    function rb(a, b, c) {
        let d, e;
        try {
            a.i && a.i.g ? (e = a.i.start(b.toString(), 3), d = c(), a.i.end(e)) : d = c()
        } catch (f) {
            c = !0;
            try {
                ib(e), c = a.l(b, new $a(f, {
                    message: qb(f)
                }), void 0, void 0)
            } catch (g) {
                a.B(217, g)
            }
            if (c) window.console ? .error ? .(f);
            else throw f;
        }
        return d
    }

    function sb(a, b) {
        var c = U;
        return (...d) => rb(c, a, () => b.apply(void 0, d))
    }

    function tb(a) {
        var b = U;
        a.catch(c => {
            c = c ? c : "unknown rejection";
            b.B(967, c instanceof Error ? c : Error(c), void 0, b.g || void 0)
        })
    }
    var wb = class {
        constructor(a = null) {
            this.pinger = ub;
            this.i = a;
            this.g = null;
            this.j = !1;
            this.l = this.B
        }
        B(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const t = new pb;
                t.g.push(1);
                t.i[1] = kb("context", a);
                b.error && b.meta && b.id || (b = new $a(b, {
                    message: qb(b)
                }));
                if (b.msg) {
                    var g = b.msg.substring(0, 512);
                    t.g.push(2);
                    t.i[2] = kb("msg", g)
                }
                var k = b.meta || {};
                if (this.g) try {
                    this.g(k)
                } catch (D) {}
                if (d) try {
                    d(k)
                } catch (D) {}
                b = [k];
                t.g.push(3);
                t.i[3] = b;
                g = n;
                b = [];
                let ea;
                k = null;
                do {
                    var h = g;
                    d = void 0;
                    try {
                        if (d = !!h && null != h.location.href) b: {
                            try {
                                ka(h.foo);
                                d = !0;
                                break b
                            } catch (D) {}
                            d = !1
                        }
                        var l = d
                    } catch {
                        l = !1
                    }
                    l ? (ea = h.location.href, k = h.document && h.document.referrer || null) : (ea = k, k = null);
                    b.push(new cb(ea || ""));
                    try {
                        g = h.parent
                    } catch (D) {
                        g = null
                    }
                } while (g && h != g);
                for (let D = 0, Xa = b.length - 1; D <= Xa; ++D) b[D].depth = Xa - D;
                h = n;
                if (h.location && h.location.ancestorOrigins && h.location.ancestorOrigins.length == b.length - 1)
                    for (l = 1; l < b.length; ++l) {
                        var p = b[l];
                        p.url || (p.url = h.location.ancestorOrigins[l - 1] || "", p.X = !0)
                    }
                var m = b;
                let ta = new cb(n.location.href, !1);
                h = null;
                const ua = m.length - 1;
                for (p = ua; 0 <= p; --p) {
                    var u = m[p];
                    !h && ab.test(u.url) && (h = u);
                    if (u.url && !u.X) {
                        ta = u;
                        break
                    }
                }
                u = null;
                const Nb = m.length && m[ua].url;
                0 != ta.depth && Nb && (u = m[ua]);
                f = new bb(ta, u);
                if (f.i) {
                    var Y = f.i.url || "";
                    t.g.push(4);
                    t.i[4] = kb("top", Y)
                }
                var v = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    var z = f.g.url.match(Ma),
                        K = z[1],
                        G = z[3],
                        Ya = z[4];
                    m = "";
                    K && (m += K + ":");
                    G && (m += "//", m += G, Ya && (m += ":" + Ya));
                    var Za = m
                } else Za = "";
                v = [v, {
                    url: Za
                }];
                t.g.push(5);
                t.i[5] = v;
                vb(this.pinger, e, t, this.j, c)
            } catch (t) {
                try {
                    vb(this.pinger, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: qb(t),
                        url: f && f.g.url
                    }, this.j, c)
                } catch (ea) {}
            }
            return !0
        }
    };
    class xb {};

    function vb(a, b, c, d = !1, e, f) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let g;
            c instanceof pb ? g = c : (g = new pb, Na(c, (h, l) => {
                var p = g;
                const m = p.l++;
                h = kb(l, h);
                p.g.push(m);
                p.i[m] = h
            }));
            const k = ob(g, a.j + b + "&");
            k && ("undefined" !== typeof f ? Ra(n, k, f) : a.i ? Ta(n, k) : Ra(n, k))
        } catch (g) {}
    }

    function yb() {
        var a = ub,
            b = window.google_srt;
        0 <= b && 1 >= b && (a.g = b)
    }
    class zb {
        constructor(a, b = !1) {
            this.j = a;
            this.i = b;
            this.g = Math.random()
        }
    };
    let ub, U;
    const V = new jb;
    var Ab = () => {
        window.google_measure_js_timing || (V.g = !1, V.i != V.j.google_js_reporting_queue && (T() && Array.prototype.forEach.call(V.i, ib, void 0), V.i.length = 0))
    };
    (a => {
        ub = a ? ? new zb("/pagead/gen_204?id=");
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        yb();
        U = new wb(V);
        U.g = b => {
            const c = Ua;
            0 !== c && (b.jc = String(c), b.shv = Va(c))
        };
        U.j = !0;
        "complete" == window.document.readyState ? Ab() : V.g && P(window, "load", () => {
            Ab()
        })
    })();
    var W = (a, b) => sb(a, b),
        Bb = (a, b, c) => {
            var d = xb;
            var e = "W";
            d.W && d.hasOwnProperty(e) || (e = new d, d.W = e);
            d = [];
            !b.eid && d.length && (b.eid = d.toString());
            vb(ub, a, b, !0, c, void 0)
        };
    class Cb {
        constructor() {
            this.promise = new Promise(a => {
                this.resolve = a
            })
        }
    };

    function Db(a, b) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let c = b[a];
        if (c) return c;
        const {
            promise: d,
            resolve: e
        } = new Cb;
        c = {
            promise: d,
            resolve: e
        };
        return b[a] = c
    };
    async function Eb() {
        return Db(10, n).promise
    };

    function X(a, b, c = {}) {
        c.msg_type = b;
        c.googMsgType = "sth";
        b = JSON.stringify(c);
        a.parent.postMessage(b, "*")
    }

    function Fb(a) {
        if (a.F || M(a.config, 2)) return !0;
        let b = !0;
        const c = Gb(a);
        c && (b = 36E5 <= c);
        if (b) try {
            a.g.localStorage.removeItem("LAST_INTERSTITIAL_TIME")
        } catch (d) {}
        return b
    }

    function Z(a, b, c) {
        N(a.config, 3) && (b.qid = N(a.config, 3));
        N(a.config, 10) && (b.eid = N(a.config, 10));
        b.rtype = L(H(J(a.config, 12)));
        b.req = O.location.href;
        if (M(a.config, 28)) {
            var d = vb;
            a.L || (a.L = new zb("/pagead/gen204?id=", !0));
            d(a.L, a.G(), b, !0, c ? ? .01)
        } else Bb(a.G(), b, c)
    }

    function Gb(a) {
        try {
            const b = +a.g.localStorage.getItem("LAST_INTERSTITIAL_TIME"),
                c = Date.now();
            if (b && b < c) return c - b
        } catch (b) {}
        return null
    }

    function Hb(a) {
        if (!M(a.config, 27)) {
            var b = L(Ba(J(a.config, 26))),
                c = () => {
                    for (const d of a.o.document.getElementsByClassName("GoogleActiveViewElement")) d.removeAttribute("data-google-av-dm")
                };
            0 < b ? setTimeout(() => c(), b) : c();
            Z(a, {
                isfsapi: !!a.i,
                avp: eb() - a.Y
            }, .01)
        }
    }
    var Ib = class {
        constructor(a, b, c) {
            this.g = O;
            this.o = a;
            this.u = !1;
            this.C = null;
            this.l = 0;
            this.config = b;
            this.Y = eb();
            this.L = null;
            this.F = M(this.config, 11) || 10 === L(H(J(this.config, 12))) || 11 === L(H(J(this.config, 12)));
            this.i = c;
            c ? .enableCustomCloseButton()
        }
        G() {}
        J() {
            (this.u = Fb(this)) ? (this.K(), N(this.config, 1) && this.g.parent.postMessage(N(this.config, 1), "*")) : this.i ? .notifyError("freq_cap")
        }
        v() {
            if (!this.l) {
                this.C && Q(this.g, "storage", this.C);
                this.l = Date.now();
                if (!M(this.config, 2) && !this.F) try {
                    this.g.localStorage.setItem("LAST_INTERSTITIAL_TIME",
                        "" + this.l)
                } catch (b) {}
                this.V();
                if (this.o) {
                    var a = this.g.document.createEvent("Event");
                    a.initEvent("i-creative-view", !0, !1);
                    this.o.dispatchEvent(a);
                    a = this.g.document.createEvent("Event");
                    a.initEvent("onshow", !0, !1);
                    this.g.dispatchEvent(a)
                }
            }
        }
        H() {}
        K() {
            let a = !1;
            if (this.i) {
                const b = this.i.waitForOnShow().then(() => {
                    this.v();
                    Hb(this)
                });
                tb(b);
                this.i.listenToBackButton(() => {
                    this.H()
                })
            } else this.g.IntersectionObserver && .01 < L(Ha(this.config)) && (a = !0, (new this.g.IntersectionObserver((b, c) => {
                b.forEach(d => {
                    0 >= d.intersectionRatio ||
                        (this.v(), Hb(this), c.disconnect())
                })
            }, {
                threshold: L(Ha(this.config))
            })).observe(this.g.document.documentElement));
            P(this.g, "message", W(262, b => {
                a: {
                    var c = a;
                    if (b && (this.g.parent == b.source || this.g.parent.parent == b.source)) {
                        var d = {};
                        try {
                            d = this.g.JSON.parse(b.data)
                        } catch (e) {
                            b = void 0;
                            break a
                        }
                        switch (d ? .msg_type) {
                            case "i-view":
                                this.u && !c && this.v();
                                Z(this, {
                                    type: "viewmsg",
                                    has_iobs: !!this.g.IntersectionObserver
                                });
                                break;
                            case "r-back-button":
                                null == this.i && this.H()
                        }
                    }
                    b = void 0
                }
                return b
            }));
            this.F || (this.C = W(263, () => {
                this.u = Fb(this);
                if (!this.u) {
                    var b = {
                        i_tslv: Gb(this)
                    };
                    X(this.g, "i-no", b)
                }
            }), P(this.g, "storage", this.C));
            this.i || X(this.g, "i-adframe-load")
        }
        V(a) {
            let b;
            try {
                const c = La(this.o);
                c.vv ? c.vv() : b = !0
            } catch (c) {
                U.B(533, c, void 0, void 0);
                return
            }
            a = a || 1;
            b ? (Z(this, {
                vf: a
            }), 3 <= a || this.g.setTimeout(q(Ib.prototype.V, this, a + 1), 3E3)) : 1 < a && Z(this, {
                vs: a
            })
        }
    };

    function Jb(a) {
        window.parent.postMessage(JSON.stringify({
            type: "rewarded",
            message: a
        }), "*")
    };

    function Kb(a) {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };

    function Lb(a, b, c) {
        a = {
            context: "iaf::itf",
            req: O.location.href,
            db: a ? 1 : 0,
            ls: b ? 1 : 0,
            eid: N(c, 10),
            qid: N(c, 3),
            rtype: L(H(J(c, 12)))
        };
        Bb("jserror", a)
    }

    function Mb(a, b) {
        Ob(a, b) && (a.j.style.background = "rgba(192,192,192, .3)", n.setTimeout(() => {
            a.j.style.background = "transparent";
            a.dismiss(2)
        }, 750))
    }

    function Pb(a, b) {
        b.some(c => "intervention" === c.type && "HeavyAdIntervention" === c.body ? .id) && (Z(a, {
            hai: "1"
        }, 1), a.l ? a.dismiss(8) : a.i ? a.i.notifyError("heavy_ads") : X(a.g, "i_iif"))
    }

    function Qb(a) {
        const b = W(259, q(function() {
            X(this.g, "i-blur");
            Q(this.g, "blur", b)
        }, a));
        P(a.g, "blur", b)
    }

    function Rb(a) {
        a.s || 0 === a.l || (a.j.setAttribute("aria-label", N(a.config, 7)), a.j.setAttribute("role", "button"), a.j.setAttribute("tabindex", "0"), a.j.focus())
    }

    function Sb(a, b) {
        M(a.config, 15) ? (Jb("canceled"), Jb("closed")) : a.i ? a.i.closeAd() : X(a.g, b)
    }

    function Tb(a, b) {
        const c = a.g.document.getElementById("creative");
        a.g.goog_vignette_survey && (a.g.goog_vignette_survey.display(c, () => {
            a.dismiss(3)
        }, () => {}, 1), b && b.stopPropagation())
    }

    function Ub(a) {
        !1 === a.s && a.enableDismissListeners();
        a.U && P(a.U, "click", W(261, c => Tb(a, c)));
        const b = a.g.document.getElementById("card");
        b && b.addEventListener("click", W(909, c => {
            c ? .stopPropagation()
        }))
    }

    function Vb(a) {
        P(a.g, "resize", () => {
            var b = a.g;
            b = b.innerHeight >= b.innerWidth ? 1 : 2;
            a.I ? (a.I = !1, a.N = 2 === b) : (a.N ? 1 === b : 2 === b) && a.dismiss(4)
        })
    }

    function Wb(a) {
        a.g.addEventListener("message", b => {
            if (b.source === a.o) try {
                const c = JSON.parse(b.data);
                "rewarded" === c.type && "closed" === c.message && a.dismiss(11 === L(H(J(a.config, 12))) ? 6 : 1)
            } catch (c) {}
        })
    }

    function Ob(a, b) {
        if (!b) return !0;
        if ((b.preventDefault ? b.defaultPrevented : !1 === b.returnValue) || b.target && b.target.ownerDocument == a.o.document) return !1;
        for (a = b.target; a;) {
            if ("creative" == a.id) return !1;
            a = a.parentElement
        }
        return !0
    }
    var Xb = class extends Ib {
        constructor(a, b, c, d, e) {
            super(a, d, e);
            this.j = b;
            this.U = c;
            this.O = 0;
            this.T = W(260, f => {
                this.dismiss(1);
                f && f.stopPropagation()
            });
            this.R = f => Mb(this, f);
            this.M = [];
            this.D = [];
            this.s = !1;
            this.P = () => {};
            this.I = this.N = !1;
            this.A = null
        }
        J() {
            super.J();
            (this.A = this.g.ReportingObserver ? new this.g.ReportingObserver((a, b) => {
                Pb(this, a) && b.disconnect()
            }, {
                buffered: !0
            }) : null) && P(this.g, "pagehide", () => {
                Pb(this, this.A.takeRecords());
                this.A.disconnect()
            })
        }
        G() {
            return "ia_evt"
        }
        H() {
            this.s ? this.P() : this.dismiss(9)
        }
        addViewListener(a) {
            a =
                sb(483, a);
            this.l ? a() : this.M.push(a)
        }
        addDismissListener(a) {
            this.D.push(sb(484, a))
        }
        disableDismissListeners(a) {
            this.s = !0;
            this.P = a;
            Q(this.j, "click", this.T);
            Q(this.g.document, "click", this.R)
        }
        enableDismissListeners() {
            this.s = !1;
            P(this.j, "click", this.T);
            P(this.g.document, "click", this.R);
            Rb(this)
        }
        dismiss(a) {
            document.body.setAttribute("aria-hidden", "true");
            Z(this, {
                ttd: Date.now() - this.l,
                req: O.location.href,
                pda: this.O,
                ds: a,
                idrw: M(this.config, 15) ? 1 : 0
            });
            this.O++ || Qb(this);
            let b = 0;
            for (let d = 0; d < this.D.length; d++) b =
                Math.max(b, this.D[d]());
            b = Math.min(b, 1E3);
            let c = "i-dismiss";
            6 === a ? c = "r-dismiss-before-reward" : 7 === a && (c = "r-dismiss-after-reward");
            0 === b ? Sb(this, c) : n.setTimeout(() => Sb(this, c), b)
        }
        K() {
            super.K();
            Ub(this)
        }
        v() {
            super.v();
            var a = this.g;
            this.N = 2 === (a.innerHeight >= a.innerWidth ? 1 : 2);
            this.I = 0 === this.g.innerWidth && 0 === this.g.innerHeight;
            Vb(this);
            Rb(this);
            var b = this.j.getBoundingClientRect(),
                c = b.bottom,
                d = b.right;
            a = Kb(this.g).clientHeight;
            var e = Kb(this.g).clientWidth;
            const f = Math.floor(c - a),
                g = Math.floor(d - e);
            if (0 <=
                f || 5 < g) c -= b.top, d -= b.left, b = this.g, Z(this, {
                dhb: f >= c ? 1 : 0,
                dhr: g >= d ? 1 : 0,
                h: a,
                w: e,
                bh: c,
                bw: d,
                opb: f,
                opr: g,
                pt: b.innerHeight >= b.innerWidth ? 1 : 0,
                req: this.g.location.href
            });
            document.getElementById("ad_iframe").contentWindow.postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            for (a = 0; a < this.M.length; a++) this.M[a]();
            Wb(this);
            .01 < Math.random() || (a = Wa(24, document.currentScript), a = `https://${a&&"true"===a.getAttribute("data-jc-rcd")?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${24}&version=${Va(24)}&sample=${.01}`,
                Ta(window, a));
            a = this.g.navigator ? !0 === this.g.navigator.standalone : !1;
            e = window.matchMedia("(display-mode: standalone)").matches;
            Z(this, {
                wapp: a || e
            })
        }
    };
    Ua = 24;
    const Yb = Wa(24, document.currentScript);
    if (null == Yb) throw Error("JSC not found 24");
    const Zb = {},
        $b = Yb.attributes;
    for (let a = $b.length - 1; 0 <= a; a--) {
        const b = $b[a].name;
        0 === b.indexOf("data-jcp-") && (Zb[b.substring(9)] = $b[a].value)
    }
    (async function(a) {
        const b = Ka(a.config),
            c = W(258, async () => {
                var d = null;
                M(b, 25) && (d = await Eb()); {
                    var e = document.getElementById("ad_iframe").contentWindow;
                    var f = O.document;
                    const g = e.document,
                        k = J(b, 5) ? ? 0,
                        h = 0 === k || 2 === k ? g.getElementById(N(b, 6)) : f.getElementById(N(b, 6));
                    f = 0 === k ? g.getElementById(N(b, 8)) : f.getElementById(N(b, 8));
                    let l;
                    try {
                        l = !!O.localStorage
                    } catch (p) {}
                    h ? (l || Lb(h, l, b), e = new Xb(e, h, f, b, d), e.J()) : (Lb(h, l, b), d ? d.notifyError("no_dismiss_button") : X(O, "i_iif"), e = null)
                }
                window.interstitialAdFrame = e;
                Db(9, window).resolve(e)
            });
        a = document.getElementById("ad_iframe");
        null != a.contentDocument && Pa(a.contentDocument, () => void c())
    })(Zb);
}).call(this);