(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var m = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = m, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    }

    function ba(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ca(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function t(a, b, c) {
        t = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ba : ca;
        return t.apply(null, arguments)
    }

    function da(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.O = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.P = function(d, e, f) {
            for (var h = Array(arguments.length - 2), g = 2; g < arguments.length; g++) h[g - 2] = arguments[g];
            return b.prototype[e].apply(d, h)
        }
    };
    var ea = aa(610401301, !1),
        fa = aa(572417392, !0);
    var u;
    const ha = m.navigator;
    u = ha ? ha.userAgentData || null : null;

    function ia(a) {
        return ea ? u ? u.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function x(a) {
        var b;
        a: {
            if (b = m.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function y() {
        return ea ? !!u && 0 < u.brands.length : !1
    }

    function la() {
        return y() ? ia("Chromium") : (x("Chrome") || x("CriOS")) && !(y() ? 0 : x("Edge")) || x("Silk")
    };

    function z(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    !x("Android") || la();
    la();
    x("Safari") && (la() || (y() ? 0 : x("Coast")) || (y() ? 0 : x("Opera")) || (y() ? 0 : x("Edge")) || (y() ? ia("Microsoft Edge") : x("Edg/")) || y() && ia("Opera"));
    var ma = !fa;
    let na = !fa;

    function B(a) {
        return Array.prototype.slice.call(a)
    };
    var D = Symbol();

    function oa(a) {
        const b = a[D] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = B(a)), a[D] = b | 1)
    }

    function E(a, b, c) {
        return c ? a | b : a & ~b
    }

    function pa() {
        var a = [];
        a[D] |= 1;
        return a
    }

    function qa(a, b) {
        b[D] = (a | 0) & -14591
    }

    function ra(a, b) {
        b[D] = (a | 34) & -14557
    }

    function sa(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var ta = {},
        ua = {};

    function va(a) {
        return !(!a || "object" !== typeof a || a.R !== ua)
    }

    function F(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let wa = !fa;

    function xa(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[D] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[D] = d | 1;
        return !0
    }
    var G;
    const ya = [];
    ya[D] = 55;
    G = Object.freeze(ya);
    class za {}
    class Ca {}
    Object.freeze(new za);
    Object.freeze(new Ca);

    function Da(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function H(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Ea(a, b, c) {
        if (null != a && "object" === typeof a && a.G === ta) return a;
        if (Array.isArray(a)) {
            var d = a[D] | 0,
                e = d;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== d && (a[D] = e);
            return new b(a)
        }
    };
    let Fa;

    function Ga(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return wa || !xa(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                }
        }
        return a
    };

    function Ha(a, b, c) {
        a = B(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) b[f] = c(e[f])
        }
        return a
    }

    function Ia(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[D] | 0) & 1 ? void 0 : f && (a[D] | 0) & 2 ? a : Ja(a, b, c, void 0 !== d, e, f);
            else if (F(a)) {
                const h = {};
                for (let g in a) h[g] = Ia(a[g], b, c, d, e, f);
                a = h
            } else a = b(a, d);
            return a
        }
    }

    function Ja(a, b, c, d, e, f) {
        const h = d || c ? a[D] | 0 : 0;
        d = d ? !!(h & 32) : void 0;
        a = B(a);
        for (let g = 0; g < a.length; g++) a[g] = Ia(a[g], b, c, d, e, f);
        c && c(h, a);
        return a
    }

    function Ka(a) {
        return a.G === ta ? a.toJSON() : Ga(a)
    };

    function La(a, b, c = ra) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[D] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[D] = (d | 34) & -12293, a) : Ja(a, La, d & 4 ? ra : c, !0, !1, !0)
            }
            a.G === ta && (c = a.l, d = c[D], a = d & 2 ? a : Ma(a, c, d, !0));
            return a
        }
    }

    function Ma(a, b, c, d) {
        a = a.constructor;
        Fa = b = Na(b, c, d);
        b = new a(b);
        Fa = void 0;
        return b
    }

    function Na(a, b, c) {
        const d = c || b & 2 ? ra : qa,
            e = !!(b & 32);
        a = Ha(a, b, f => La(f, e, d));
        a[D] = a[D] | 32 | (c ? 2 : 0);
        return a
    }

    function Oa(a) {
        const b = a.l,
            c = b[D];
        return c & 2 ? Ma(a, b, c, !1) : a
    };

    function J(a, b) {
        a = a.l;
        return Pa(a, a[D], b)
    }

    function Pa(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= sa(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function Qa(a, b, c, d) {
        var e = sa(b);
        if (1 >= e || d) {
            d = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == c) return d;
                e = a[e + (+!!(b & 512) - 1)] = {};
                d |= 256
            }
            e[1] = c;
            d !== b && (a[D] = d);
            return d
        }
        a[1 + (+!!(b & 512) - 1)] = c;
        b & 256 && (a = a[a.length - 1], 1 in a && delete a[1]);
        return b
    }

    function Ra(a) {
        var b = a.l,
            c = b[D],
            d = Pa(b, c, 1, !1);
        const e = Ea(d, Sa, c);
        e !== d && null != e && Qa(b, c, e, !1);
        b = e;
        if (null == b) return b;
        a = a.l;
        c = a[D];
        c & 2 || (d = Oa(b), d !== b && (b = d, Qa(a, c, b, !1)));
        return b
    }

    function Ta(a, b) {
        a = E(a, 2, !!(2 & b));
        a = E(a, 32, !!(32 & b) && !1);
        return a = E(a, 2048, !1)
    }

    function K(a, b) {
        a = J(a, b);
        return (null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0) ? ? !1
    }

    function L(a, b) {
        return Da(J(a, b)) ? ? 0
    };
    var N = class {
        constructor(a) {
            a: {
                null == a && (a = Fa);Fa = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[D] | 0;
                    if (b & 64) break a;
                    b |= 64;
                    var c = a.length;
                    if (c && (--c, F(a[c]))) {
                        b |= 256;
                        c -= +!!(b & 512) - 1;
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[D] = b
            }
            this.l = a
        }
        toJSON() {
            var a = Ja(this.l, Ka, void 0, void 0, !1, !1);
            return Ua(this, a, !0)
        }
    };
    N.prototype.G = ta;
    N.prototype.toString = function() {
        return Ua(this, this.l, !1).toString()
    };

    function Ua(a, b, c) {
        const d = a.constructor.N;
        var e = (c ? a.l : b)[D],
            f = sa(e),
            h = !1;
        if (d && wa) {
            if (!c) {
                b = B(b);
                var g;
                if (b.length && F(g = b[b.length - 1]))
                    for (h = 0; h < d.length; h++)
                        if (d[h] >= f) {
                            Object.assign(b[b.length - 1] = {}, g);
                            break
                        }
                h = !0
            }
            f = b;
            c = !c;
            g = a.l[D];
            a = sa(g);
            g = +!!(g & 512) - 1;
            var l;
            for (let C = 0; C < d.length; C++) {
                var k = d[C];
                if (k < a) {
                    k += g;
                    var n = f[k];
                    null == n ? f[k] = c ? G : pa() : c && n !== G && oa(n)
                } else {
                    if (!l) {
                        var p = void 0;
                        f.length && F(p = f[f.length - 1]) ? l = p : f.push(l = {})
                    }
                    n = l[k];
                    null == l[k] ? l[k] = c ? G : pa() : c && n !== G && oa(n)
                }
            }
        }
        l = b.length;
        if (!l) return b;
        let q, A;
        if (F(p = b[l - 1])) {
            a: {
                var r = p;f = {};c = !1;
                for (var v in r) {
                    a = r[v];
                    if (Array.isArray(a)) {
                        g = a;
                        if (!na && xa(a, d, +v) || !ma && va(a) && 0 === a.size) a = null;
                        a != g && (c = !0)
                    }
                    null != a ? f[v] = a : c = !0
                }
                if (c) {
                    for (let C in f) {
                        r = f;
                        break a
                    }
                    r = null
                }
            }
            r != p && (q = !0);l--
        }
        for (e = +!!(e & 512) - 1; 0 < l; l--) {
            v = l - 1;
            p = b[v];
            if (!(null == p || !na && xa(p, d, v - e) || !ma && va(p) && 0 === p.size)) break;
            A = !0
        }
        if (!q && !A) return b;
        var w;
        h ? w = b : w = Array.prototype.slice.call(b, 0, l);
        b = w;
        h && (b.length = l);
        r && b.push(r);
        return b
    };
    var Va = class extends N {};

    function Wa(a) {
        a = a.l;
        var b = a[D];
        var c = !!(2 & b);
        var d = b,
            e = c ? 1 : 2;
        b = 1 === e;
        e = 2 === e;
        var f = !!(2 & d) && e,
            h = d & 2,
            g = Pa(a, d, 1);
        Array.isArray(g) || (g = G);
        var l = g[D] | 0;
        0 === l && d & 32 && !h ? (l |= 33, g[D] = l) : l & 1 || (l |= 1, g[D] = l);
        h && (d = !1, l & 2 || (g[D] |= 34, d = !!(4 & l)), d && Object.freeze(g));
        d = a[D];
        var k = g[D] | 0,
            n = !!(2 & k);
        l = !!(4 & k);
        h = !!(32 & k);
        let p = n && l || !!(2048 & k);
        if (!l) {
            var q = g,
                A = d;
            const r = !!(2 & k);
            r && (A = E(A, 2, !0));
            let v = !r,
                w = !0,
                C = 0,
                V = 0;
            for (; C < q.length; C++) {
                const I = Ea(q[C], Va, A);
                if (I instanceof Va) {
                    if (!r) {
                        const M = !!((I.l[D] | 0) & 2);
                        v &&
                            (v = !M);
                        w && (w = M)
                    }
                    q[V++] = I
                }
            }
            V < C && (q.length = V);
            k = E(k, 4, !0);
            k = E(k, 16, w);
            k = E(k, 8, v);
            q[D] = k;
            n && !f && (Object.freeze(g), p = !0)
        }
        f = k;
        n = !!(8 & k) || b && !g.length;
        if (!c && !n) {
            p && (g = B(g), p = !1, f = 0, k = Ta(k, d), d = Qa(a, d, g));
            c = g;
            n = k;
            for (q = 0; q < c.length; q++) k = c[q], A = Oa(k), k !== A && (c[q] = A);
            n = E(n, 8, !0);
            k = n = E(n, 16, !c.length)
        }
        p || (b ? k = E(k, !g.length || 16 & k && (!l || h) ? 2 : 2048, !0) : k = E(k, 32, !1), k !== f && (g[D] = k), b && (Object.freeze(g), p = !0));
        e && p && (g = B(g), k = Ta(k, d), g[D] = k, Qa(a, d, g));
        return g
    }
    var Sa = class extends N {};
    Sa.N = [1];
    var Xa = class extends N {};

    function Ya() {}

    function Za(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var $a = {
            capture: !0
        },
        ab = {
            passive: !0
        },
        bb = Za(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                m.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function cb(a) {
        return a ? a.passive && bb() ? a : a.capture || !1 : !1
    }

    function O(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, cb(d))
    };
    var P = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };
    P.prototype.i = !0;
    P.prototype.h = function() {
        return this.g.toString()
    };
    var db = {},
        eb = new P("about:invalid#zClosurez", db);

    function fb(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) fb(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    class gb {
        constructor(a) {
            this.M = a
        }
    }

    function Q(a) {
        return new gb(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const hb = new gb(a => /^[^:]*([/?#]|$)/.test(a));
    var ib = Q("http"),
        jb = Q("https"),
        kb = Q("ftp"),
        lb = Q("mailto");
    const mb = [Q("data"), ib, jb, lb, kb, hb];

    function nb(a = mb) {
        for (let b = 0; b < a.length; ++b) {
            const c = a[b];
            if (c instanceof gb && c.M("#")) return new P("#", db)
        }
    }

    function ob(a = mb) {
        return nb(a) || eb
    };

    function pb(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    let qb = [];
    const rb = () => {
        const a = qb;
        qb = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var sb = a => {
        var b = R;
        "complete" === b.readyState || "interactive" === b.readyState ? (qb.push(a), 1 == qb.length && (window.Promise ? Promise.resolve().then(rb) : window.setImmediate ? setImmediate(rb) : setTimeout(rb, 0))) : b.addEventListener("DOMContentLoaded", a)
    };

    function tb(a = document) {
        return a.createElement("img")
    };

    function ub(a, b, c = null, d = !1) {
        vb(a, b, c, d)
    }

    function vb(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = tb(a.document);
        if (c || d) {
            const f = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    var g = Array.prototype.indexOf.call(h, e, void 0);
                    0 <= g && Array.prototype.splice.call(h, g, 1)
                }
                e.removeEventListener && e.removeEventListener("load", f, cb());
                e.removeEventListener && e.removeEventListener("error", f, cb())
            };
            O(e, "load", f);
            O(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    };

    function wb(a = null) {
        return a && "23" === a.getAttribute("data-jc") ? a : document.querySelector('[data-jc="23"]')
    }

    function xb() {
        if (!(.01 < Math.random())) {
            var a = wb(document.currentScript);
            a = a && "true" === a.getAttribute("data-jc-rcd") ? "pagead2.googlesyndication-cn.com" : "pagead2.googlesyndication.com";
            var b = (b = wb(document.currentScript)) && b.getAttribute("data-jc-version") || "unknown";
            a = `https://${a}/pagead/gen_204?id=jca&jc=${23}&version=${b}&sample=${.01}`;
            b = window;
            var c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && b.navigator.sendBeacon ? b.navigator.sendBeacon(a) : ub(b, a, void 0, !1)
        }
    };
    var R = document,
        S = window;
    var yb = (a = []) => {
        m.google_logging_queue || (m.google_logging_queue = []);
        m.google_logging_queue.push([12, a])
    };
    const zb = [ib, jb, lb, kb, hb, Q("market"), Q("itms"), Q("intent"), Q("itms-appss")];
    var Ab = () => {
        var a = `${"http:"===S.location.protocol?"http:":"https:"}//${"pagead2.googlesyndication.com"}/pagead/gen_204`;
        return b => {
            b = {
                id: "unsafeurl",
                ctx: 625,
                url: b
            };
            var c = [];
            for (d in b) fb(d, b[d], c);
            var d = c.join("&");
            if (d) {
                b = a.indexOf("#");
                0 > b && (b = a.length);
                c = a.indexOf("?");
                if (0 > c || c > b) {
                    c = b;
                    var e = ""
                } else e = a.substring(c + 1, b);
                b = [a.slice(0, c), e, a.slice(b)];
                c = b[1];
                b[1] = d ? c ? c + "&" + d : d : c;
                d = b[0] + (b[1] ? "?" + b[1] : "") + b[2]
            } else d = a;
            navigator.sendBeacon && navigator.sendBeacon(d, "")
        }
    };
    var Bb = () => {
            var a = R;
            try {
                return a.querySelectorAll("*[data-ifc]")
            } catch (b) {
                return []
            }
        },
        Cb = (a, b) => {
            a && pb(b, (c, d) => {
                a.style[d] = c
            })
        },
        Db = a => {
            var b = R.body;
            const c = document.createDocumentFragment(),
                d = a.length;
            for (let e = 0; e < d; ++e) c.appendChild(a[e]);
            b.appendChild(c)
        };
    let Eb = null;

    function Fb() {
        const a = m.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Gb() {
        const a = m.performance;
        return a && a.now ? a.now() : null
    };
    var Hb = class {
        constructor(a, b) {
            var c = Gb() || Fb();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const T = m.performance,
        Ib = !!(T && T.mark && T.measure && T.clearMarks),
        U = Za(() => {
            var a;
            if (a = Ib) {
                var b;
                if (null === Eb) {
                    Eb = "";
                    try {
                        a = "";
                        try {
                            a = m.top.location.hash
                        } catch (c) {
                            a = m.location.hash
                        }
                        a && (Eb = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Eb;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        });

    function Jb(a) {
        a && T && U() && (T.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), T.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }
    class Kb {
        constructor() {
            var a = window;
            this.g = [];
            this.i = a || m;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.g = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.h = U() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Hb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            T && U() && T.mark(b);
            return a
        }
        end(a) {
            if (this.h && "number" === typeof a.value) {
                a.duration = (Gb() || Fb()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                T && U() && T.mark(b);
                !this.h || 2048 <
                    this.g.length || this.g.push(a)
            }
        }
    };

    function Lb(a, b, c, d, e) {
        const f = [];
        pb(a, function(h, g) {
            (h = Mb(h, b, c, d, e)) && f.push(g + "=" + h)
        });
        return f.join(b)
    }

    function Mb(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let h = 0; h < a.length; h++) f.push(Mb(a[h], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(Lb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Nb(a) {
        let b = 1;
        for (const c in a.h) b = c.length > b ? c.length : b;
        return 3997 - b - a.i.length - 1
    }

    function Ob(a) {
        let b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=fccs&",
            c = Nb(a) - 24;
        if (0 > c) return "";
        a.g.sort(function(f, h) {
            return f - h
        });
        let d = null,
            e = "";
        for (let f = 0; f < a.g.length; f++) {
            const h = a.g[f],
                g = a.h[h];
            for (let l = 0; l < g.length; l++) {
                if (!c) {
                    d = null == d ? h : d;
                    break
                }
                let k = Lb(g[l], a.i, ",$");
                if (k) {
                    k = e + k;
                    if (c >= k.length) {
                        c -= k.length;
                        b += k;
                        e = a.i;
                        break
                    }
                    d = null == d ? h : d
                }
            }
        }
        a = "";
        null != d && (a = e + "trn=" + d);
        return b + a
    }
    class Pb {
        constructor() {
            this.i = "&";
            this.h = {};
            this.m = 0;
            this.g = []
        }
    };
    class Qb {};

    function Rb() {
        var a = Sb,
            b = window.google_srt;
        0 <= b && 1 >= b && (a.g = b)
    }

    function Tb(a) {
        if (1 > Sb.g) try {
            let b;
            a instanceof Pb ? b = a : (b = new Pb, pb(a, (d, e) => {
                var f = b;
                const h = f.m++,
                    g = {};
                g[e] = d;
                d = [g];
                f.g.push(h);
                f.h[h] = d
            }));
            const c = Ob(b);
            c && ub(m, c)
        } catch (b) {}
    }
    class Ub {
        constructor() {
            this.g = Math.random()
        }
    };
    let Sb;
    const W = new Kb;
    var Vb = () => {
        window.google_measure_js_timing || (W.h = !1, W.g != W.i.google_js_reporting_queue && (U() && z(W.g, Jb), W.g.length = 0))
    };
    (a => {
        Sb = a ? ? new Ub;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Rb();
        "complete" == window.document.readyState ? Vb() : W.h && O(window, "load", () => {
            Vb()
        })
    })();
    var Wb = a => {
        O(S, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || "ig" !== c.googMsgType || a(c, b)
        })
    };

    function Xb() {
        this.h = this.h;
        this.i = this.i
    }
    Xb.prototype.h = !1;

    function Yb(a) {
        a.h || (a.h = !0, a.m())
    }
    Xb.prototype.m = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function X(a, b, c) {
        Xb.call(this);
        this.o = a;
        this.C = b || 0;
        this.s = c;
        this.v = t(this.A, this)
    }
    da(X, Xb);
    X.prototype.g = 0;
    X.prototype.m = function() {
        X.O.m.call(this);
        this.isActive() && m.clearTimeout(this.g);
        this.g = 0;
        delete this.o;
        delete this.s
    };
    X.prototype.start = function(a) {
        this.isActive() && m.clearTimeout(this.g);
        this.g = 0;
        var b = this.v;
        a = void 0 !== a ? a : this.C;
        if ("function" !== typeof b)
            if (b && "function" == typeof b.handleEvent) b = t(b.handleEvent, b);
            else throw Error("Invalid listener argument");
        this.g = 2147483647 < Number(a) ? -1 : m.setTimeout(b, a || 0)
    };
    X.prototype.isActive = function() {
        return 0 != this.g
    };
    X.prototype.A = function() {
        this.g = 0;
        this.o && this.o.call(this.s)
    };
    const Zb = {
            display: "inline-block",
            position: "absolute"
        },
        $b = {
            display: "none",
            width: "100%",
            height: "100%",
            top: "0",
            left: "0"
        },
        Y = (a, b) => {
            a && (a.style.display = b ? "inline-block" : "none")
        };

    function ac(a = "") {
        const b = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        a && (a = a.split(","), 4 === a.length && a.reduce((c, d) => c && !isNaN(+d), !0) && ([b.top, b.right, b.bottom, b.left] = a.map(c => +c)));
        return b
    }

    function bc(a, b, c = 2147483647) {
        const d = R.createElement("div");
        Cb(d, { ...Zb,
            "z-index": String(c),
            ...b
        });
        K(a.data, 10) && O(d, "click", Ya);
        if (K(a.data, 11)) {
            a = R.createElement("a");
            b = Ab();
            c = ob(zb);
            c === eb && b("#");
            b = c;
            if (b instanceof P) var e = b;
            else if (b instanceof P) e = b;
            else {
                b = "object" == typeof b && b.i ? b.h() : String(b);
                b: {
                    try {
                        e = new URL(b)
                    } catch (f) {
                        e = "https:";
                        break b
                    }
                    e = e.protocol
                }
                "javascript:" === e && (b = "about:invalid#zClosurez");
                e = new P(b, db)
            }
            a.href = e instanceof P && e.constructor === P ? e.g : "type_error:SafeUrl";
            a.appendChild(d);
            return a
        }
        return d
    }

    function cc(a, b) {
        switch (J(b.j, 5) ? ? 1) {
            case 2:
                S.AFMA_Communicator ? .addEventListener ? .("onshow", () => {
                    Z(a, b)
                });
                break;
            case 10:
                O(S, "i-creative-view", () => {
                    Z(a, b)
                });
                break;
            case 4:
                O(R, "DOMContentLoaded", () => {
                    Z(a, b)
                });
                break;
            case 8:
                Wb(c => {
                    c.rr && Z(a, b)
                });
                break;
            case 9:
                if ("IntersectionObserver" in S) {
                    const c = new IntersectionObserver(d => {
                        for (const e of d)
                            if (0 < e.intersectionRatio) {
                                Z(a, b);
                                break
                            }
                    });
                    c.observe(R.body);
                    a.L.push(c)
                }
                break;
            case 11:
                S.AFMA_Communicator ? .addEventListener ? .("onAdVisibilityChanged", () => {
                    Z(a, b)
                })
        }
    }

    function dc(a, b) {
        b = ac(b);
        const c = L(a.data, 9);
        a.m = [{
            width: "100%",
            height: b.top + c + "px",
            top: -c + "px",
            left: "0"
        }, {
            width: b.right + c + "px",
            height: "100%",
            top: "0",
            right: -c + "px"
        }, {
            width: "100%",
            height: b.bottom + c + "px",
            bottom: -c + "px",
            left: "0"
        }, {
            width: b.left + c + "px",
            height: "100%",
            top: "0",
            left: -c + "px"
        }].map(d => bc(a, d, 9019))
    }

    function ec(a) {
        var b = 0;
        for (const d of a.K) {
            const e = d.j,
                f = a.A[J(e, 5) ? ? 1];
            d.u || void 0 === f || (b = Math.max(b, f + L(e, 2)))
        }
        a.o && Yb(a.o);
        b -= Date.now();
        const c = a.h;
        0 < b ? (Y(c, !0), a.o = new X(() => {
            Y(c, !1)
        }, b), a.o.start()) : Y(c, !1)
    }

    function Z(a, b) {
        b.u || (a.A[J(b.j, 5) ? ? 1] = Date.now(), K(b.j, 9) && (a.K.push(b), ec(a)))
    }

    function fc(a, b, c) {
        if (!a.g || !a.v || 300 <= b.timeStamp - a.g.timeStamp) return !1;
        const d = new Map;
        z(a.v.changedTouches, e => {
            d.set(e.identifier, {
                x: e.clientX,
                y: e.clientY
            })
        });
        b = L(c.j, 11) || 10;
        for (const e of a.g.changedTouches)
            if (a = d.get(e.identifier), !a || Math.abs(a.x - e.clientX) > b || Math.abs(a.y - e.clientY) > b) return !0;
        return !1
    }
    var hc = class {
        constructor() {
            var a = gc;
            this.m = [];
            this.o = this.h = null;
            this.K = [];
            this.data = null;
            this.C = [];
            this.i = [];
            this.s = [];
            this.A = {};
            this.L = [];
            this.v = this.g = null;
            this.H = "";
            this.I = "true" === a["send-fccs"];
            this.H = a.qid || ""
        }
        init(a) {
            yb([a]);
            this.data = new Xa(a);
            a = Ra(this.data);
            z(Wa(a), f => {
                this.s.push({
                    D: 0,
                    u: !1,
                    F: 0,
                    j: f,
                    B: -1
                })
            });
            this.i = Bb();
            let b = !1;
            a = this.i.length;
            for (let f = 0; f < a; ++f) {
                var c = new Sa(JSON.parse(this.i[f].getAttribute("data-ifc") || "[]"));
                z(Wa(c), h => {
                    this.s.push({
                        D: 0,
                        u: !1,
                        F: 0,
                        j: h,
                        B: f
                    });
                    1 === (J(h,
                        4) ? ? 1) && (b = !0)
                })
            }
            c = a = !1;
            let d = K(this.data, 12);
            for (var e of this.s) {
                const f = e.j;
                0 < L(f, 2) && 0 < (J(f, 5) ? ? 1) ? (!this.h && K(f, 9) && (this.h = bc(this, $b)), cc(this, e)) : (H(J(f, 1)) ? ? "") && K(f, 9) && dc(this, H(J(f, 1)) ? ? "");
                (H(J(f, 1)) ? ? "") && (a = !0);
                0 < L(f, 11) && (c = !0);
                K(f, 12) && (d = !0)
            }
            e = [];
            this.h && e.push(this.h);
            !b && e.push(...this.m);
            R.body && Db(e);
            K(this.data, 13) && sb(() => {
                const f = R.body.querySelectorAll(".amp-fcp, .amp-bcp");
                for (let g = 0; g < f.length; ++g) {
                    var h = (h = f[g]) ? S.getComputedStyle(h).getPropertyValue("position") : void 0;
                    "absolute" === h && Y(f[g], !1)
                }
            });
            O(R, "click", f => {
                if (this.I) {
                    var h = {
                        cx: f.clientX,
                        cy: f.clientY,
                        et: Date.now(),
                        qid: this.H
                    };
                    var g = Qb;
                    var l = "J";
                    g.J && g.hasOwnProperty(l) || (l = new g, g.J = l);
                    g = [];
                    !h.eid && g.length && (h.eid = g.toString());
                    Tb(h);
                    this.I = !1
                }
                if (!1 === f.isTrusted && K(this.data, 15)) f.preventDefault ? f.preventDefault() : f.returnValue = !1, f.stopImmediatePropagation(), xb();
                else {
                    h = -1;
                    g = [];
                    for (var k of this.s) {
                        l = k.B;
                        var n = -1 !== l;
                        if (!(L(k.j, 3) <= h || k.u || n && !1 === g[l])) {
                            var p = !n || g[l] || this.i[l].contains(f.target);
                            n &&
                                p && (g[l] = !0);
                            if (l = p)
                                if (l = f, n = k.j, 0 < L(n, 2) && 0 < (J(n, 5) ? ? 1)) l = this.A[J(n, 5) ? ? 1], l = void 0 !== l && Date.now() < l + L(n, 2);
                                else if (H(J(n, 1)) ? ? "") {
                                {
                                    n = (0 <= k.B ? this.i[k.B] : R.body).getBoundingClientRect();
                                    p = Number;
                                    var q = (q = R.body) ? S.getComputedStyle(q).getPropertyValue("zoom") : void 0;
                                    const w = p(q || "1"),
                                        [C, V] = [l.clientX, l.clientY],
                                        [I, M, Aa, Ba] = [C / w - n.left, V / w - n.top, n.width, n.height];
                                    if (!(0 < Aa && 0 < Ba) || isNaN(I) || isNaN(M) || 0 > I || 0 > M) l = !1;
                                    else {
                                        p = ac(H(J(k.j, 1)) ? ? "");
                                        q = !(I >= p.left && Aa - I > p.right && M >= p.top && Ba - M > p.bottom);
                                        var A =
                                            K(k.j, 12);
                                        if (this.g && (K(this.data, 12) || A) && 300 > l.timeStamp - this.g.timeStamp) {
                                            l = this.g.changedTouches[0];
                                            const [ja, ka] = [l.clientX / w - n.left, l.clientY / w - n.top];
                                            !isNaN(ja) && !isNaN(ka) && 0 <= ja && 0 <= ka && (q = (q = K(this.data, 16) || A ? q : !1) || !(ja >= p.left && Aa - ja > p.right && ka >= p.top && Ba - ka > p.bottom))
                                        }
                                        l = q
                                    }
                                }
                            } else l = 0 < L(n, 11) ? fc(this, l, k) : !0;
                            if (l) {
                                var r = k;
                                h = L(k.j, 3)
                            }
                        }
                    }
                    if (r) switch (k = r.j, J(k, 4) ? ? 1) {
                        case 2:
                        case 3:
                            f.preventDefault ? f.preventDefault() : f.returnValue = !1;
                            h = Date.now();
                            500 < h - r.F && (r.F = h, ++r.D);
                            h = r.j;
                            if (L(h, 8) &&
                                r.D >= L(h, 8))
                                if (r.u = !0, this.h && 0 < L(h, 2)) ec(this);
                                else if (0 < this.m.length && (H(J(h, 1)) ? ? ""))
                                for (var v of this.m) Y(v, !1);
                            xb();
                            v = k.toJSON();
                            for (const w of this.C) w(f, v)
                    }
                }
            }, $a);
            c && O(R, "touchstart", f => {
                this.v = f
            }, ab);
            (a && d || c) && O(R, "touchend", f => {
                this.g = f
            }, ab)
        }
        registerCallback(a) {
            this.C.push(a)
        }
    };
    const ic = wb(document.currentScript);
    if (null == ic) throw Error("JSC not found 23");
    var gc;
    const jc = {},
        kc = ic.attributes;
    for (let a = kc.length - 1; 0 <= a; a--) {
        const b = kc[a].name;
        0 === b.indexOf("data-jcp-") && (jc[b.substring(9)] = kc[a].value)
    }
    gc = jc;
    const lc = window;
    lc.googqscp = new hc;
    gc["init-data"] && lc.googqscp.init(JSON.parse(gc["init-data"]));
}).call(this);