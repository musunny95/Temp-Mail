(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var m = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = m, f = 0; f < c.length; f++)
                if (d = d[c[f]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    }

    function ba(a) {
        return a
    };
    var ca = aa(610401301, !1),
        da = aa(572417392, !0);
    var n;
    const ea = m.navigator;
    n = ea ? ea.userAgentData || null : null;

    function fa(a) {
        return ca ? n ? n.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function q(a) {
        var b;
        a: {
            if (b = m.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return -1 != b.indexOf(a)
    };

    function t() {
        return ca ? !!n && 0 < n.brands.length : !1
    }

    function ia() {
        return t() ? fa("Chromium") : (q("Chrome") || q("CriOS")) && !(t() ? 0 : q("Edge")) || q("Silk")
    };

    function ja(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };

    function ka(a) {
        ka[" "](a);
        return a
    }
    ka[" "] = function() {};
    !q("Android") || ia();
    ia();
    q("Safari") && (ia() || (t() ? 0 : q("Coast")) || (t() ? 0 : q("Opera")) || (t() ? 0 : q("Edge")) || (t() ? fa("Microsoft Edge") : q("Edg/")) || t() && fa("Opera"));
    var la = !da;
    let ma = !da;
    var x = Symbol();

    function na(a) {
        const b = a[x] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), a[x] = b | 1)
    }

    function oa() {
        var a = [];
        a[x] |= 1;
        return a
    }

    function pa(a, b) {
        b[x] = (a | 0) & -14591
    }

    function qa(a, b) {
        b[x] = (a | 34) & -14557
    }

    function y(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var A = {},
        ra = {};

    function sa(a) {
        return !(!a || "object" !== typeof a || a.ba !== ra)
    }

    function C(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let ta, ua = !da;

    function va(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[x] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[x] = d | 1;
        return !0
    }
    var D;
    const wa = [];
    wa[x] = 55;
    D = Object.freeze(wa);
    class xa {}
    class ya {}
    Object.freeze(new xa);
    Object.freeze(new ya);

    function G(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    };
    let za;

    function Aa(a, b) {
        za = b;
        a = new a(b);
        za = void 0;
        return a
    };

    function Ba(a, b) {
        return Ca(b)
    }

    function Ca(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return ua || !va(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                }
        }
        return a
    };

    function Da(a, b, c) {
        a = Array.prototype.slice.call(a);
        var d = a.length;
        const f = b & 256 ? a[d - 1] : void 0;
        d += f ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (f) {
            b = a[b] = {};
            for (const e in f) b[e] = c(f[e])
        }
        return a
    }

    function Ga(a, b, c, d, f, e) {
        if (null != a) {
            if (Array.isArray(a)) a = f && 0 == a.length && (a[x] | 0) & 1 ? void 0 : e && (a[x] | 0) & 2 ? a : Ha(a, b, c, void 0 !== d, f, e);
            else if (C(a)) {
                const g = {};
                for (let h in a) g[h] = Ga(a[h], b, c, d, f, e);
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function Ha(a, b, c, d, f, e) {
        const g = d || c ? a[x] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = Array.prototype.slice.call(a);
        for (let h = 0; h < a.length; h++) a[h] = Ga(a[h], b, c, d, f, e);
        c && c(g, a);
        return a
    }

    function Ia(a) {
        return a.v === A ? a.toJSON() : Ca(a)
    };

    function Ja(a, b, c = qa) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[x] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[x] = (d | 34) & -12293, a) : Ha(a, Ja, d & 4 ? qa : c, !0, !1, !0)
            }
            a.v === A && (c = a.l, d = c[x], a = d & 2 ? a : Aa(a.constructor, Ka(c, d, !0)));
            return a
        }
    }

    function Ka(a, b, c) {
        const d = c || b & 2 ? qa : pa,
            f = !!(b & 32);
        a = Da(a, b, e => Ja(e, f, d));
        a[x] = a[x] | 32 | (c ? 2 : 0);
        return a
    };

    function H(a, b) {
        a = a.l;
        return La(a, a[x], b)
    }

    function La(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= y(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var f = a.length;
            if (d && b & 256 && (d = a[f - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < f) return a[b]
        }
    }

    function Ma(a, b, c, d, f) {
        var e = y(b);
        if (c >= e || f) {
            f = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return;
                e = a[e + (+!!(b & 512) - 1)] = {};
                f |= 256
            }
            e[c] = d;
            f !== b && (a[x] = f)
        } else a[c + (+!!(b & 512) - 1)] = d, b & 256 && (a = a[a.length - 1], c in a && delete a[c])
    }

    function Na(a) {
        var b = Oa;
        a = a.l;
        let c = a[x];
        const d = La(a, c, 1, !1);
        if (null != d && "object" === typeof d && d.v === A) b = d;
        else if (Array.isArray(d)) {
            const f = d[x] | 0;
            let e = f;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== f && (d[x] = e);
            b = new b(d)
        } else b = void 0;
        b !== d && null != b && Ma(a, c, 1, b, !1);
        return b
    }

    function Pa(a) {
        let b = Na(a);
        if (null == b) return b;
        a = a.l;
        let c = a[x];
        if (!(c & 2)) {
            var d = b;
            const f = d.l,
                e = f[x];
            d = e & 2 ? Aa(d.constructor, Ka(f, e, !1)) : d;
            d !== b && (b = d, Ma(a, c, 1, b, !1))
        }
        return b
    }

    function I(a, b) {
        a = H(a, b);
        return null == a || "string" === typeof a ? a : void 0
    }

    function K(a, b) {
        a = H(a, b);
        return (null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0) ? ? !1
    }

    function L(a, b, c) {
        if (null != c && "string" !== typeof c) throw Error();
        a = a.l;
        let d = a[x];
        if (d & 2) throw Error();
        Ma(a, d, b, c)
    };
    var Ra = class {
        constructor(a) {
            a: {
                null == a && (a = za);za = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[x] | 0;
                    if (b & 64) break a;
                    var c = a;
                    b |= 64;
                    var d = c.length;
                    if (d && (--d, C(c[d]))) {
                        b |= 256;
                        c = d - (+!!(b & 512) - 1);
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[x] = b
            }
            this.l = a
        }
        toJSON() {
            if (ta) var a = Qa(this, this.l, !1);
            else a = Ha(this.l, Ia, void 0, void 0, !1, !1), a = Qa(this, a, !0);
            return a
        }
    };
    Ra.prototype.v = A;

    function Qa(a, b, c) {
        const d = a.constructor.N;
        var f = (c ? a.l : b)[x],
            e = y(f),
            g = !1;
        if (d && ua) {
            if (!c) {
                b = Array.prototype.slice.call(b);
                var h;
                if (b.length && C(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= e) {
                            Object.assign(b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            e = b;
            c = !c;
            h = a.l[x];
            a = y(h);
            h = +!!(h & 512) - 1;
            var l;
            for (let B = 0; B < d.length; B++) {
                var k = d[B];
                if (k < a) {
                    k += h;
                    var u = e[k];
                    null == u ? e[k] = c ? D : oa() : c && u !== D && na(u)
                } else {
                    if (!l) {
                        var p = void 0;
                        e.length && C(p = e[e.length - 1]) ? l = p : e.push(l = {})
                    }
                    u = l[k];
                    null == l[k] ? l[k] = c ? D : oa() : c && u !== D &&
                        na(u)
                }
            }
        }
        l = b.length;
        if (!l) return b;
        let z, w;
        if (C(p = b[l - 1])) {
            a: {
                var r = p;e = {};c = !1;
                for (var v in r) {
                    a = r[v];
                    if (Array.isArray(a)) {
                        h = a;
                        if (!ma && va(a, d, +v) || !la && sa(a) && 0 === a.size) a = null;
                        a != h && (c = !0)
                    }
                    null != a ? e[v] = a : c = !0
                }
                if (c) {
                    for (let B in e) {
                        r = e;
                        break a
                    }
                    r = null
                }
            }
            r != p && (z = !0);l--
        }
        for (f = +!!(f & 512) - 1; 0 < l; l--) {
            v = l - 1;
            p = b[v];
            if (!(null == p || !ma && va(p, d, v - f) || !la && sa(p) && 0 === p.size)) break;
            w = !0
        }
        if (!z && !w) return b;
        var J;
        g ? J = b : J = Array.prototype.slice.call(b, 0, l);
        b = J;
        g && (b.length = l);
        r && b.push(r);
        return b
    };
    var Oa = class extends Ra {};
    Oa.N = [28];
    var Sa = class extends Ra {},
        Ta = function(a) {
            return b => {
                if (null == b || "" == b) b = new a;
                else {
                    b = JSON.parse(b);
                    if (!Array.isArray(b)) throw Error(void 0);
                    b[x] |= 32;
                    b = Aa(a, b)
                }
                return b
            }
        }(Sa);
    Sa.N = [21];
    var Ua = class extends Ra {
        constructor() {
            super()
        }
    };

    function Va(a = window) {
        return a
    };

    function Wa(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var Xa = {
            passive: !0
        },
        Ya = Wa(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                m.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Za(a) {
        return a ? a.passive && Ya() ? a : a.capture || !1 : !1
    }

    function M(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, Za(d))
    };
    var $a;
    var ab = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g + ""
            }
        },
        bb = {};

    function N(a) {
        var b = document;
        return "string" === typeof a ? b.getElementById(a) : a
    }

    function cb(a) {
        var b = document;
        b.getElementsByClassName ? a = b.getElementsByClassName(a)[0] : (b = document, a = b.querySelectorAll && b.querySelector && a ? b.querySelector(a ? "." + a : "") : db(b, a)[0] || null);
        return a || null
    }

    function db(a, b) {
        var c, d;
        if (a.querySelectorAll && a.querySelector && b) return a.querySelectorAll(b ? "." + b : "");
        if (b && a.getElementsByClassName) {
            var f = a.getElementsByClassName(b);
            return f
        }
        f = a.getElementsByTagName("*");
        if (b) {
            var e = {};
            for (c = d = 0; a = f[c]; c++) {
                var g = a.className,
                    h;
                if (h = "function" == typeof g.split) h = 0 <= ja(g.split(/\s+/), b);
                h && (e[d++] = a)
            }
            e.length = d;
            return e
        }
        return f
    }

    function eb(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    };
    var fb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        gb = /#|$/;

    function hb(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function ib(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function jb(a, b, c = null, d = !1) {
        kb(a, b, c, d)
    }

    function kb(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = ib("IMG", a.document);
        if (c || d) {
            const e = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    const h = ja(g, f);
                    0 <= h && Array.prototype.splice.call(g, h, 1)
                }
                f.removeEventListener && f.removeEventListener("load", e, Za());
                f.removeEventListener && f.removeEventListener("error", e, Za())
            };
            M(f, "load", e);
            M(f, "error", e)
        }
        f.src = b;
        a.google_image_requests.push(f)
    };
    let lb = 0;

    function mb(a) {
        return (a = nb(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function nb(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[${"data-jc"}="${a}"]`)
    }

    function ob() {
        if (!(.01 < Math.random())) {
            var a = nb(60, document.currentScript);
            a = `https://${a&&"true"===a.getAttribute("data-jc-rcd")?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${60}&version=${mb(60)}&sample=${.01}`;
            var b = window,
                c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && b.navigator.sendBeacon ? b.navigator.sendBeacon(a) : jb(b, a, void 0, !1)
        }
    };
    var pb = document,
        O = window;

    function qb(a) {
        return "string" == typeof a.className ? a.className : a.getAttribute && a.getAttribute("class") || ""
    }

    function vb(a, b) {
        a.classList ? b = a.classList.contains(b) : (a = a.classList ? a.classList : qb(a).match(/\S+/g) || [], b = 0 <= ja(a, b));
        return b
    }

    function P(a, b) {
        if (a.classList) a.classList.add(b);
        else if (!vb(a, b)) {
            var c = qb(a);
            b = c + (0 < c.length ? " " + b : b);
            "string" == typeof a.className ? a.className = b : a.setAttribute && a.setAttribute("class", b)
        }
    };
    var wb = class {
        constructor(a) {
            this.serializedAttributionData = a.toJSON();
            var b = a.l;
            this.g = Aa(a.constructor, Ka(b, b[x], !1));
            this.isMutableImpression = void 0 !== Na(this.g) && !!K(Pa(this.g), 33);
            this.X = !!K(this.g, 11);
            this.hasUserFeedbackData = !!this.g && void 0 !== Na(this.g);
            this.R = !!K(this.g, 4);
            this.U = !!K(this.g, 6);
            this.P = !!K(this.g, 13);
            G(H(this.g, 8));
            this.creativeIndexSuffix = 1 < (G(H(this.g, 8)) ? ? 0) ? (G(H(this.g, 7)) ? ? 0).toString() : "";
            null != I(this.g, 34) && (this.creativeIndexSuffix = (I(this.g, 34) ? ? "") + "_" + this.creativeIndexSuffix);
            this.Y = !!K(this.g, 17);
            this.W = !!K(this.g, 18);
            this.O = !!K(this.g, 14);
            this.F = !!K(this.g, 15);
            this.Z = !!K(this.g, 31);
            this.V = 1 == K(this.g, 9);
            this.openAttributionInline = 1 == K(this.g, 10);
            this.isMobileDevice = !!K(this.g, 12);
            this.u = null;
            this.T = (a = pb.querySelector("[data-slide]")) ? "true" === a.getAttribute("data-slide") : !1;
            (this.H = 1 < (G(H(this.g, 8)) ? ? 0)) && void 0 === O.goog_multislot_cache && (O.goog_multislot_cache = {});
            if (this.H && !this.T) {
                if (a = O.goog_multislot_cache.hd, void 0 === a) {
                    a = !1;
                    if (b = pb.querySelector("[data-dim]"))
                        if (b =
                            b.getBoundingClientRect(), 150 <= b.right - b.left && 150 <= b.bottom - b.top) a = !1;
                        else {
                            var c = document.body.getBoundingClientRect();
                            150 > (1 >= Math.abs(c.left - b.left) && 1 >= Math.abs(c.right - b.right) ? b.bottom - b.top : b.right - b.left) && (a = !0)
                        }
                    else a = !1;
                    window.goog_multislot_cache.hd = a
                }
            } else a = !1;
            this.G = a;
            this.B = N("abgcp" + this.creativeIndexSuffix);
            this.A = N("abgc" + this.creativeIndexSuffix);
            this.h = N("abgs" + this.creativeIndexSuffix);
            N("abgl" + this.creativeIndexSuffix);
            this.s = N("abgb" + this.creativeIndexSuffix);
            this.D = N("abgac" +
                this.creativeIndexSuffix);
            N("mute_panel" + this.creativeIndexSuffix);
            this.C = cb("goog_delegate_attribution" + this.creativeIndexSuffix);
            this.isDelegateAttributionActive = !!this.C && !!this.O && !cb("goog_delegate_disabled") && !this.F;
            if (this.h) a: for (a = this.h, b = a.childNodes, c = 0; c < b.length; c++) {
                const d = b.item(c);
                if ("undefined" != typeof d.tagName && "A" == d.tagName.toUpperCase()) {
                    a = d;
                    break a
                }
            } else a = null;
            this.m = a;
            this.j = this.isDelegateAttributionActive ? this.C : N("cbb" + this.creativeIndexSuffix);
            this.S = this.G ? "0" === this.creativeIndexSuffix :
                !0;
            this.enableDelegateDismissableMenu = !!this.j && vb(this.j, "goog_dismissable_menu");
            this.o = null;
            this.I = 0;
            this.i = this.isDelegateAttributionActive ? this.C : this.U && this.B ? this.B : this.A;
            this.autoExpandOnLoad = !!K(this.g, 19);
            this.adbadgeEnabled = !!K(this.g, 24);
            this.enableNativeJakeUi = !!K(this.g, 27)
        }
    };
    var xb = class {
        constructor(a, b) {
            if (!a) throw Error("bad conv util ctor args");
            this.g = a;
            this.h = b
        }
    };
    var Q = (a, b) => {
        a && hb(b, (c, d) => {
            a.style[d] = c
        })
    };
    class yb {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const zb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Ab = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        Bb = class {
            constructor(a, b) {
                this.url = a;
                this.L = !!b;
                this.depth = null
            }
        };
    let Cb = null;

    function Db() {
        const a = m.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Eb() {
        const a = m.performance;
        return a && a.now ? a.now() : null
    };
    var Fb = class {
        constructor(a, b) {
            var c = Eb() || Db();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const R = m.performance,
        Gb = !!(R && R.mark && R.measure && R.clearMarks),
        S = Wa(() => {
            var a;
            if (a = Gb) {
                var b;
                if (null === Cb) {
                    Cb = "";
                    try {
                        a = "";
                        try {
                            a = m.top.location.hash
                        } catch (c) {
                            a = m.location.hash
                        }
                        a && (Cb = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Cb;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        });

    function Hb(a) {
        a && R && S() && (R.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), R.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }
    class Ib {
        constructor() {
            var a = window;
            this.h = [];
            this.i = a || m;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.h = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = S() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Fb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            R && S() && R.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (Eb() || Db()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                R && S() && R.mark(b);
                !this.g || 2048 <
                    this.h.length || this.h.push(a)
            }
        }
    };

    function Jb(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Kb(a, b, c, d, f) {
        const e = [];
        hb(a, function(g, h) {
            (g = Lb(g, b, c, d, f)) && e.push(h + "=" + g)
        });
        return e.join(b)
    }

    function Lb(a, b, c, d, f) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const e = [];
                for (let g = 0; g < a.length; g++) e.push(Lb(a[g], b, c, d + 1, f));
                return e.join(c[d])
            }
        } else if ("object" == typeof a) return f = f || 0, 2 > f ? encodeURIComponent(Kb(a, b, c, d, f + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Mb(a) {
        let b = 1;
        for (const c in a.h) b = c.length > b ? c.length : b;
        return 3997 - b - a.i.length - 1
    }

    function Nb(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = Mb(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(e, g) {
            return e - g
        });
        b = null;
        let f = "";
        for (let e = 0; e < a.g.length; e++) {
            const g = a.g[e],
                h = a.h[g];
            for (let l = 0; l < h.length; l++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let k = Kb(h[l], a.i, ",$");
                if (k) {
                    k = f + k;
                    if (d >= k.length) {
                        d -= k.length;
                        c += k;
                        f = a.i;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = f + "trn=" + b);
        return c + a
    }
    class Ob {
        constructor() {
            this.i = "&";
            this.h = {};
            this.j = 0;
            this.g = []
        }
    };

    function Pb(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }

    function Qb(a, b, c) {
        let d, f;
        try {
            a.g && a.g.g ? (f = a.g.start(b.toString(), 3), d = c(), a.g.end(f)) : d = c()
        } catch (e) {
            c = !0;
            try {
                Hb(f), c = a.m(b, new yb(e, {
                    message: Pb(e)
                }), void 0, void 0)
            } catch (g) {
                a.j(217, g)
            }
            if (c) window.console ? .error ? .(e);
            else throw e;
        }
        return d
    }

    function Rb(a, b) {
        var c = T;
        return (...d) => Qb(c, a, () => b.apply(void 0, d))
    }
    var Ub = class {
        constructor(a = null) {
            this.pinger = Sb;
            this.g = a;
            this.h = null;
            this.i = !1;
            this.m = this.j
        }
        j(a, b, c, d, f) {
            f = f || "jserror";
            let e;
            try {
                const E = new Ob;
                var g = E;
                g.g.push(1);
                g.h[1] = Jb("context", a);
                b.error && b.meta && b.id || (b = new yb(b, {
                    message: Pb(b)
                }));
                if (b.msg) {
                    g = E;
                    var h = b.msg.substring(0, 512);
                    g.g.push(2);
                    g.h[2] = Jb("msg", h)
                }
                var l = b.meta || {};
                b = l;
                if (this.h) try {
                    this.h(b)
                } catch (F) {}
                if (d) try {
                    d(b)
                } catch (F) {}
                d = E;
                l = [l];
                d.g.push(3);
                d.h[3] = l;
                d = m;
                l = [];
                let ha;
                b = null;
                do {
                    var k = d;
                    try {
                        var u;
                        if (u = !!k && null != k.location.href) b: {
                            try {
                                ka(k.foo);
                                u = !0;
                                break b
                            } catch (F) {}
                            u = !1
                        }
                        var p = u
                    } catch {
                        p = !1
                    }
                    p ? (ha = k.location.href, b = k.document && k.document.referrer || null) : (ha = b, b = null);
                    l.push(new Bb(ha || ""));
                    try {
                        d = k.parent
                    } catch (F) {
                        d = null
                    }
                } while (d && k != d);
                for (let F = 0, rb = l.length - 1; F <= rb; ++F) l[F].depth = rb - F;
                k = m;
                if (k.location && k.location.ancestorOrigins && k.location.ancestorOrigins.length == l.length - 1)
                    for (p = 1; p < l.length; ++p) {
                        var z = l[p];
                        z.url || (z.url = k.location.ancestorOrigins[p - 1] || "", z.L = !0)
                    }
                var w = l;
                let Ea = new Bb(m.location.href, !1);
                k = null;
                const Fa = w.length - 1;
                for (z = Fa; 0 <= z; --z) {
                    var r = w[z];
                    !k && zb.test(r.url) && (k = r);
                    if (r.url && !r.L) {
                        Ea = r;
                        break
                    }
                }
                r = null;
                const cc = w.length && w[Fa].url;
                0 != Ea.depth && cc && (r = w[Fa]);
                e = new Ab(Ea, r);
                if (e.h) {
                    w = E;
                    var v = e.h.url || "";
                    w.g.push(4);
                    w.h[4] = Jb("top", v)
                }
                var J = {
                    url: e.g.url || ""
                };
                if (e.g.url) {
                    var B = e.g.url.match(fb),
                        V = B[1],
                        sb = B[3],
                        tb = B[4];
                    v = "";
                    V && (v += V + ":");
                    sb && (v += "//", v += sb, tb && (v += ":" + tb));
                    var ub = v
                } else ub = "";
                V = E;
                J = [J, {
                    url: ub
                }];
                V.g.push(5);
                V.h[5] = J;
                Tb(this.pinger, f, E, this.i, c)
            } catch (E) {
                try {
                    Tb(this.pinger, f, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Pb(E),
                        url: e && e.g.url
                    }, this.i, c)
                } catch (ha) {}
            }
            return !0
        }
    };

    function Tb(a, b, c, d = !1, f) {
        if ((d ? a.g : Math.random()) < (f || .01)) try {
            let e;
            c instanceof Ob ? e = c : (e = new Ob, hb(c, (h, l) => {
                var k = e;
                const u = k.j++;
                h = Jb(l, h);
                k.g.push(u);
                k.h[u] = h
            }));
            const g = Nb(e, "/pagead/gen_204?id=" + b + "&");
            g && jb(m, g)
        } catch (e) {}
    }

    function Vb() {
        var a = Sb,
            b = window.google_srt;
        0 <= b && 1 >= b && (a.g = b)
    }
    class Wb {
        constructor() {
            this.g = Math.random()
        }
    };
    let Sb, T;
    const U = new Ib;
    var Xb = () => {
        window.google_measure_js_timing || (U.g = !1, U.h != U.i.google_js_reporting_queue && (S() && Array.prototype.forEach.call(U.h, Hb, void 0), U.h.length = 0))
    };
    (a => {
        Sb = a ? ? new Wb;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Vb();
        T = new Ub(U);
        T.h = b => {
            const c = lb;
            0 !== c && (b.jc = String(c), b.shv = mb(c))
        };
        T.i = !0;
        "complete" == window.document.readyState ? Xb() : U.g && M(window, "load", () => {
            Xb()
        })
    })();
    var W = (a, b) => Rb(a, b);

    function Yb(a) {
        if (a.g.m && a.g.W) {
            const b = Pa(a.g.g);
            b && null != I(b, 5) && null != I(b, 6) && (a.i = new xb(I(b, 5) ? ? "", I(b, 19) ? ? ""));
            M(a.g.m, "click", W(452, () => {
                if (!a.j && (a.j = !0, a.i)) {
                    var c = a.i;
                    var d = c.g;
                    var f = d.search(gb),
                        e;
                    b: {
                        for (e = 0; 0 <= (e = d.indexOf("ad_signals", e)) && e < f;) {
                            var g = d.charCodeAt(e - 1);
                            if (38 == g || 63 == g)
                                if (g = d.charCodeAt(e + 10), !g || 61 == g || 38 == g || 35 == g) break b;
                            e += 11
                        }
                        e = -1
                    }
                    if (0 > e) d = null;
                    else {
                        g = d.indexOf("&", e);
                        if (0 > g || g > f) g = f;
                        d = decodeURIComponent(d.slice(e + 11, -1 !== g ? g : 0).replace(/\+/g, " "))
                    }
                    if (d) {
                        if (d = {
                                J: d,
                                label: "closebutton_whythisad_click",
                                M: "1",
                                K: ""
                            }, c = new Ua, null != d && (null != d.J && L(c, 1, d.J), null != d.aa && L(c, 3, d.aa), null != d.label && L(c, 6, d.label), null != d.M && L(c, 7, d.M), null != d.K && L(c, 8, d.K)), null != (d = Va(m).fence)) {
                            f = d.reportEvent;
                            a: {
                                ta = !0;
                                try {
                                    var h = JSON.stringify(c.toJSON(), Ba);
                                    break a
                                } finally {
                                    ta = !1
                                }
                                h = void 0
                            }
                            f.call(d, {
                                eventType: "interaction",
                                eventData: h,
                                destination: ["buyer"]
                            })
                        }
                    } else h = c.g + "&label=closebutton_whythisad_click", h += "&label_instance=1", c.h && (h += "&cid=" + c.h), jb(window, h)
                }
            }))
        }
    }

    function Zb(a) {
        if (a.g.X) M(a.g.i, "click", W(365, b => {
            const c = O.goog_interstitial_display;
            c && (c(b), b && (b.stopPropagation(), b.preventDefault()))
        }));
        else if (a.g.isMutableImpression && a.g.isMobileDevice) M(a.g.i, "click", () => a.h());
        else if (a.g.isMutableImpression && !a.g.isMobileDevice && (a.g.j && (M(a.g.j, "click", () => a.h()), M(a.g.j, "keydown", b => {
                "Enter" !== b.code && "Space" !== b.code || a.h()
            })), a.g.Z && a.g.h && M(a.g.h, "click", () => a.h())), a.g.R) $b(a);
        else {
            M(a.g.i, "mouseover", W(367, () => $b(a)));
            M(a.g.i, "mouseout", W(369,
                () => ac(a, 500)));
            M(a.g.i, "touchstart", W(368, () => $b(a)), Xa);
            const b = W(370, () => ac(a, 4E3));
            M(a.g.i, "mouseup", b);
            M(a.g.i, "touchend", b);
            M(a.g.i, "touchcancel", b);
            a.g.m && M(a.g.m, "click", W(371, c => a.preventDefault(c)))
        }
    }

    function $b(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.h && "block" == a.g.h.style.display || (a.g.I = Date.now(), a.g.s && a.g.h && (a.g.s.style.display = "none", a.g.h.style.display = "block"))
    }

    function ac(a, b) {
        window.clearTimeout(a.g.o);
        a.g.o = window.setTimeout(() => bc(a), b)
    }

    function dc(a) {
        const b = a.g.D;
        void 0 !== b && (b.style.display = "block", a.g.enableNativeJakeUi && window.requestAnimationFrame(() => {
            P(b, "abgacfo")
        }))
    }

    function bc(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.s && a.g.h && (a.g.s.style.display = "block", a.g.h.style.display = "none")
    }
    class ec {
        constructor(a, b) {
            this.g = a;
            this.h = b;
            this.g.Y || (this.j = !1, this.i = null, !this.g.G || this.g.adbadgeEnabled || this.g.S ? Yb(this) : (a = {
                display: "none"
            }, b = {
                width: "15px",
                height: "15px"
            }, this.g.isMobileDevice ? (Q(this.g.s, a), Q(this.g.h, a), Q(this.g.B, b), Q(this.g.A, b)) : Q(this.g.A, a)), Zb(this), this.g.enableNativeJakeUi && P(this.g.D, "abgnac"), this.g.isDelegateAttributionActive ? (P(document.body, "goog_delegate_active"), P(document.body, "jaa")) : (!this.g.isMutableImpression && this.g.j && eb(this.g.j), setTimeout(() => {
                P(document.body,
                    "jar")
            }, this.g.P ? 750 : 100)), this.g.F && P(document.body, "goog_delegate_disabled"), this.g.autoExpandOnLoad && O.addEventListener("load", () => this.h()))
        }
        preventDefault(a) {
            if (this.g.h && "block" == this.g.h.style.display && 500 > Date.now() - this.g.I) a.preventDefault ? a.preventDefault() : a.returnValue = !1;
            else if (this.g.openAttributionInline) {
                var b = this.g.m.getAttribute("href");
                window.adSlot ? window.adSlot.openAttribution(b) && (a.preventDefault ? a.preventDefault() : a.returnValue = !1) : window.openAttribution && (window.openAttribution(b),
                    a.preventDefault ? a.preventDefault() : a.returnValue = !1)
            } else this.g.V && (b = this.g.m.getAttribute("href"), window.adSlot ? window.adSlot.openSystemBrowser(b) && (a.preventDefault ? a.preventDefault() : a.returnValue = !1) : window.openSystemBrowser && (window.openSystemBrowser(b), a.preventDefault ? a.preventDefault() : a.returnValue = !1))
        }
    };

    function fc(a) {
        if (!a.g && (a.g = !0, O.goog_delegate_deferred_token = void 0, a.h)) {
            var b = a.i;
            a = Ta(JSON.stringify(a.h));
            if (!a) throw Error("bad attrdata");
            a = new wb(a);
            new b(a)
        }
    }
    class gc {
        constructor(a) {
            var b = hc;
            if (!b) throw Error("bad ctor");
            this.i = b;
            this.h = a;
            this.g = !1;
            cb("goog_delegate_deferred") ? void 0 !== O.goog_delegate_deferred_token ? fc(this) : (a = () => {
                fc(this)
            }, O.goog_delegate_deferred_token = a, setTimeout(a, 5E3)) : fc(this)
        }
    };
    var ic = (a = []) => {
        m.google_logging_queue || (m.google_logging_queue = []);
        m.google_logging_queue.push([11, a])
    };
    class jc {
        constructor() {
            this.promise = new Promise(a => {
                this.resolve = a
            })
        }
    };

    function kc() {
        const {
            promise: a,
            resolve: b
        } = new jc;
        return {
            promise: a,
            resolve: b
        }
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function lc(a, b = () => {}) {
        a.google_llp || (a.google_llp = {});
        a = a.google_llp;
        let c = a[5];
        if (c) return c;
        c = kc();
        a[5] = c;
        b();
        return c
    }

    function mc(a, b) {
        return lc(a, () => {
            var c = a.document;
            const d = ib("SCRIPT", c);
            d.src = b instanceof ab && b.constructor === ab ? b.g : "type_error:TrustedResourceUrl";
            if (!(void 0) ? .ca) {
                var f;
                (f = (f = (d.ownerDocument && d.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? f.nonce || f.getAttribute("nonce") || "" : "") && d.setAttribute("nonce", f)
            }(c = c.getElementsByTagName("script")[0]) && c.parentNode && c.parentNode.insertBefore(d, c)
        }).promise
    };

    function nc(a) {
        a = null === a ? "null" : void 0 === a ? "undefined" : a;
        if (void 0 === $a) {
            var b = null;
            var c = m.trustedTypes;
            if (c && c.createPolicy) {
                try {
                    b = c.createPolicy("goog#html", {
                        createHTML: ba,
                        createScript: ba,
                        createScriptURL: ba
                    })
                } catch (d) {
                    m.console && m.console.error(d.message)
                }
                $a = b
            } else $a = b
        }
        a = (b = $a) ? b.createScriptURL(a) : a;
        return new ab(a, bb)
    };

    function oc(a) {
        ic([a]);
        new gc(a)
    }

    function pc(a) {
        a.g.u ? a.g.u.expandAttributionCard() : (Qb(T, 373, () => {
            bc(a.h);
            dc(a.h)
        }), mc(window, nc(`https://${"pagead2.googlesyndication.com"}${"/pagead/js/"+(I(a.g.g,33)??"")+"/abg_survey.js"}`)).then(b => {
            b.createAttributionCard(a.g);
            a.g.u = b;
            b.expandAttributionCard()
        }), ob())
    }
    var hc = class {
        constructor(a) {
            this.g = a;
            this.h = new ec(this.g, W(359, () => pc(this)))
        }
    };
    lb = 60;
    const qc = nb(60, document.currentScript);
    if (null == qc) throw Error("JSC not found 60");
    const rc = {},
        sc = qc.attributes;
    for (let a = sc.length - 1; 0 <= a; a--) {
        const b = sc[a].name;
        0 === b.indexOf("data-jcp-") && (rc[b.substring(9)] = sc[a].value)
    }
    if (rc["attribution-data"]) oc(JSON.parse(rc["attribution-data"]));
    else {
        var X = ["buildAttribution"],
            Y = m;
        X[0] in Y || "undefined" == typeof Y.execScript || Y.execScript("var " + X[0]);
        for (var Z; X.length && (Z = X.shift());) X.length || void 0 === oc ? Y[Z] && Y[Z] !== Object.prototype[Z] ? Y = Y[Z] : Y = Y[Z] = {} : Y[Z] = oc
    };
}).call(this);