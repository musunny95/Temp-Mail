(function() {
    var n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        da =
        ca(this),
        p = function(a, b) {
            if (b) a: {
                var c = da;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.Ng = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.Ng
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("b");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ea(aa(this))
                }
            })
        }
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var ea = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        fa = function(a) {
            return a.raw = a
        },
        ha = function(a, b) {
            a.raw = b;
            return a
        },
        t = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if ("number" == typeof a.length) return {
                next: aa(a)
            };
            throw Error("c`" + String(a));
        },
        u = function(a) {
            if (!(a instanceof Array)) {
                a = t(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ja = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a,
                b)
        },
        ka = "function" == typeof Object.assign ? Object.assign : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) ja(d, e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ka
    });
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ma;
    if ("function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                qa = {};
            try {
                qa.__proto__ = oa;
                na = qa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("d`" + a);
            return a
        } : null
    }
    var ra = ma,
        x = function(a, b) {
            a.prototype = la(b.prototype);
            a.prototype.constructor = a;
            if (ra) ra(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Yi = b.prototype
        },
        sa = function() {
            this.qc = !1;
            this.ib = null;
            this.ff = void 0;
            this.ka = 1;
            this.La = this.kb = 0;
            this.ie = this.ea = null
        };
    sa.prototype.Va = function() {
        if (this.qc) throw new TypeError("f");
        this.qc = !0
    };
    sa.prototype.vc = function(a) {
        this.ff = a
    };
    sa.prototype.Fc = function(a) {
        this.ea = {
            Ef: a,
            Xf: !0
        };
        this.ka = this.kb || this.La
    };
    sa.prototype.return = function(a) {
        this.ea = {
            return: a
        };
        this.ka = this.La
    };
    var ta = function(a, b, c) {
        a.ka = c;
        return {
            value: b
        }
    };
    sa.prototype.qb = function(a) {
        this.ka = a
    };
    var ua = function(a, b, c) {
            c = a.ie.splice(c || 0)[0];
            (c = a.ea = a.ea || c) ? c.Xf ? a.ka = a.kb || a.La : void 0 != c.qb && a.La < c.qb ? (a.ka = c.qb, a.ea = null) : a.ka = a.La: a.ka = b
        },
        va = function(a) {
            this.s = new sa;
            this.Ci = a
        };
    va.prototype.vc = function(a) {
        this.s.Va();
        if (this.s.ib) return wa(this, this.s.ib.next, a, this.s.vc);
        this.s.vc(a);
        return xa(this)
    };
    var ya = function(a, b) {
        a.s.Va();
        var c = a.s.ib;
        if (c) return wa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.s.return);
        a.s.return(b);
        return xa(a)
    };
    va.prototype.Fc = function(a) {
        this.s.Va();
        if (this.s.ib) return wa(this, this.s.ib["throw"], a, this.s.vc);
        this.s.Fc(a);
        return xa(this)
    };
    var wa = function(a, b, c, d) {
            try {
                var e = b.call(a.s.ib, c);
                if (!(e instanceof Object)) throw new TypeError("e`" + e);
                if (!e.done) return a.s.qc = !1, e;
                var f = e.value
            } catch (g) {
                return a.s.ib = null, a.s.Fc(g), xa(a)
            }
            a.s.ib = null;
            d.call(a.s, f);
            return xa(a)
        },
        xa = function(a) {
            for (; a.s.ka;) try {
                var b = a.Ci(a.s);
                if (b) return a.s.qc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.s.ff = void 0, a.s.Fc(c)
            }
            a.s.qc = !1;
            if (a.s.ea) {
                b = a.s.ea;
                a.s.ea = null;
                if (b.Xf) throw b.Ef;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        za = function(a) {
            this.next =
                function(b) {
                    return a.vc(b)
                };
            this.throw = function(b) {
                return a.Fc(b)
            };
            this.return = function(b) {
                return ya(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Aa = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Ba = function(a) {
            return Aa(new za(new va(a)))
        },
        Ca = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            void 0 !== a["throw"] && (this["throw"] = function(b) {
                return Promise.resolve(a["throw"](b))
            });
            void 0 !== a["return"] && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        y = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("Promise", function(a) {
        function b() {
            this.Xa = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(k) {
                k(g)
            })
        }
        if (a) return a;
        b.prototype.qf = function(g) {
            if (null == this.Xa) {
                this.Xa = [];
                var k = this;
                this.rf(function() {
                    k.uh()
                })
            }
            this.Xa.push(g)
        };
        var d = da.setTimeout;
        b.prototype.rf = function(g) {
            d(g, 0)
        };
        b.prototype.uh = function() {
            for (; this.Xa && this.Xa.length;) {
                var g = this.Xa;
                this.Xa = [];
                for (var k = 0; k < g.length; ++k) {
                    var h = g[k];
                    g[k] = null;
                    try {
                        h()
                    } catch (l) {
                        this.ah(l)
                    }
                }
            }
            this.Xa = null
        };
        b.prototype.ah = function(g) {
            this.rf(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.Yb = 0;
            this.Cc = void 0;
            this.Tb = [];
            this.ag = !1;
            var k = this.Zd();
            try {
                g(k.resolve, k.reject)
            } catch (h) {
                k.reject(h)
            }
        };
        e.prototype.Zd = function() {
            function g(l) {
                return function(m) {
                    h || (h = !0, l.call(k, m))
                }
            }
            var k = this,
                h = !1;
            return {
                resolve: g(this.Mi),
                reject: g(this.Pe)
            }
        };
        e.prototype.Mi = function(g) {
            if (g === this) this.Pe(new TypeError("g"));
            else if (g instanceof e) this.Ri(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var k = null != g;
                        break a;
                    case "function":
                        k = !0;
                        break a;
                    default:
                        k = !1
                }
                k ? this.Li(g) : this.If(g)
            }
        };
        e.prototype.Li = function(g) {
            var k = void 0;
            try {
                k = g.then
            } catch (h) {
                this.Pe(h);
                return
            }
            "function" == typeof k ? this.Si(k, g) : this.If(g)
        };
        e.prototype.Pe = function(g) {
            this.ug(2, g)
        };
        e.prototype.If = function(g) {
            this.ug(1, g)
        };
        e.prototype.ug = function(g, k) {
            if (0 != this.Yb) throw Error("h`" + g + "`" + k + "`" + this.Yb);
            this.Yb = g;
            this.Cc = k;
            2 === this.Yb && this.Oi();
            this.vh()
        };
        e.prototype.Oi = function() {
            var g = this;
            d(function() {
                if (g.ni()) {
                    var k = da.console;
                    "undefined" !== typeof k && k.error(g.Cc)
                }
            }, 1)
        };
        e.prototype.ni = function() {
            if (this.ag) return !1;
            var g = da.CustomEvent,
                k = da.Event,
                h = da.dispatchEvent;
            if ("undefined" === typeof h) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof k ? g = new k("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Cc;
            return h(g)
        };
        e.prototype.vh = function() {
            if (null != this.Tb) {
                for (var g = 0; g < this.Tb.length; ++g) f.qf(this.Tb[g]);
                this.Tb = null
            }
        };
        var f = new b;
        e.prototype.Ri = function(g) {
            var k =
                this.Zd();
            g.Sc(k.resolve, k.reject)
        };
        e.prototype.Si = function(g, k) {
            var h = this.Zd();
            try {
                g.call(k, h.resolve, h.reject)
            } catch (l) {
                h.reject(l)
            }
        };
        e.prototype.then = function(g, k) {
            function h(q, v) {
                return "function" == typeof q ? function(w) {
                    try {
                        l(q(w))
                    } catch (A) {
                        m(A)
                    }
                } : v
            }
            var l, m, r = new e(function(q, v) {
                l = q;
                m = v
            });
            this.Sc(h(g, l), h(k, m));
            return r
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Sc = function(g, k) {
            function h() {
                switch (l.Yb) {
                    case 1:
                        g(l.Cc);
                        break;
                    case 2:
                        k(l.Cc);
                        break;
                    default:
                        throw Error("i`" +
                            l.Yb);
                }
            }
            var l = this;
            null == this.Tb ? f.qf(h) : this.Tb.push(h);
            this.ag = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(k, h) {
                h(g)
            })
        };
        e.race = function(g) {
            return new e(function(k, h) {
                for (var l = t(g), m = l.next(); !m.done; m = l.next()) c(m.value).Sc(k, h)
            })
        };
        e.all = function(g) {
            var k = t(g),
                h = k.next();
            return h.done ? c([]) : new e(function(l, m) {
                function r(w) {
                    return function(A) {
                        q[w] = A;
                        v--;
                        0 == v && l(q)
                    }
                }
                var q = [],
                    v = 0;
                do q.push(void 0), v++, c(h.value).Sc(r(q.length - 1), m), h = k.next(); while (!h.done)
            })
        };
        return e
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ja(b, d) && c.push(b[d]);
            return c
        }
    });
    var Da = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Da(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(h) {
            var l = typeof h;
            return "object" === l && null !== h || "function" === l
        }

        function d(h) {
            if (!ja(h, f)) {
                var l = new b;
                ba(h, f, {
                    value: l
                })
            }
        }

        function e(h) {
            var l = Object[h];
            l && (Object[h] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var h = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [h, 2],
                            [l, 3]
                        ]);
                    if (2 != m.get(h) || 3 != m.get(l)) return !1;
                    m.delete(h);
                    m.set(l, 4);
                    return !m.has(h) && 4 == m.get(l)
                } catch (r) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            k = function(h) {
                this.oc = (g += Math.random() + 1).toString();
                if (h) {
                    h = t(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        k.prototype.set = function(h, l) {
            if (!c(h)) throw Error("j");
            d(h);
            if (!ja(h, f)) throw Error("k`" + h);
            h[f][this.oc] = l;
            return this
        };
        k.prototype.get = function(h) {
            return c(h) && ja(h, f) ? h[f][this.oc] : void 0
        };
        k.prototype.has = function(h) {
            return c(h) && ja(h, f) && ja(h[f], this.oc)
        };
        k.prototype.delete = function(h) {
            return c(h) &&
                ja(h, f) && ja(h[f], this.oc) ? delete h[f][this.oc] : !1
        };
        return k
    });
    p("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var k = Object.seal({
                            x: 4
                        }),
                        h = new a(t([
                            [k, "s"]
                        ]));
                    if ("s" != h.get(k) || 1 != h.size || h.get({
                            x: 4
                        }) || h.set({
                            x: 4
                        }, "t") != h || 2 != h.size) return !1;
                    var l = h.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != k || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (r) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(k) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (k) {
                    k = t(k);
                    for (var h; !(h = k.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        c.prototype.set = function(k, h) {
            k = 0 === k ? 0 : k;
            var l = d(this, k);
            l.list || (l.list = this[0][l.id] = []);
            l.R ? l.R.value = h : (l.R = {
                next: this[1],
                Sa: this[1].Sa,
                head: this[1],
                key: k,
                value: h
            }, l.list.push(l.R), this[1].Sa.next = l.R, this[1].Sa = l.R, this.size++);
            return this
        };
        c.prototype.delete = function(k) {
            k = d(this, k);
            return k.R && k.list ? (k.list.splice(k.index, 1), k.list.length || delete this[0][k.id], k.R.Sa.next = k.R.next, k.R.next.Sa = k.R.Sa,
                k.R.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Sa = f();
            this.size = 0
        };
        c.prototype.has = function(k) {
            return !!d(this, k).R
        };
        c.prototype.get = function(k) {
            return (k = d(this, k).R) && k.value
        };
        c.prototype.entries = function() {
            return e(this, function(k) {
                return [k.key, k.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(k) {
                return k.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(k) {
                return k.value
            })
        };
        c.prototype.forEach = function(k, h) {
            for (var l = this.entries(),
                    m; !(m = l.next()).done;) m = m.value, k.call(h, m[1], m[0], this)
        };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(k, h) {
                var l = h && typeof h;
                "object" == l || "function" == l ? b.has(h) ? l = b.get(h) : (l = "" + ++g, b.set(h, l)) : l = "p_" + h;
                var m = k[0][l];
                if (m && ja(k[0], l))
                    for (k = 0; k < m.length; k++) {
                        var r = m[k];
                        if (h !== h && r.key !== r.key || h === r.key) return {
                            id: l,
                            list: m,
                            index: k,
                            R: r
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    R: void 0
                }
            },
            e = function(k, h) {
                var l = k[1];
                return ea(function() {
                    if (l) {
                        for (; l.head != k[1];) l = l.Sa;
                        for (; l.next != l.head;) return l =
                            l.next, {
                                done: !1,
                                value: h(l)
                            };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var k = {};
                return k.Sa = k.next = k.head = k
            },
            g = 0;
        return c
    });
    var Ea = function(a, b, c) {
        if (null == a) throw new TypeError("l`" + c);
        if (b instanceof RegExp) throw new TypeError("m`" + c);
        return a + ""
    };
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ea(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Da(this, function(b, c) {
                return c
            })
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Ea(this, b, "includes").indexOf(b, c || 0)
        }
    });
    p("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(t([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.Ca = new Map;
            if (c) {
                c =
                    t(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.Ca.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.Ca.set(c, c);
            this.size = this.Ca.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.Ca.delete(c);
            this.size = this.Ca.size;
            return c
        };
        b.prototype.clear = function() {
            this.Ca.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.Ca.has(c)
        };
        b.prototype.entries = function() {
            return this.Ca.entries()
        };
        b.prototype.values = function() {
            return this.Ca.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.Ca.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Da(this, function(b, c) {
                return [b, c]
            })
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(k) {
                return k
            };
            var e = [],
                f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    var Fa = function(a) {
        return a ? a : Array.prototype.fill
    };
    p("Int8Array.prototype.fill", Fa);
    p("Uint8Array.prototype.fill", Fa);
    p("Uint8ClampedArray.prototype.fill", Fa);
    p("Int16Array.prototype.fill", Fa);
    p("Uint16Array.prototype.fill", Fa);
    p("Int32Array.prototype.fill", Fa);
    p("Uint32Array.prototype.fill", Fa);
    p("Float32Array.prototype.fill", Fa);
    p("Float64Array.prototype.fill", Fa);
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ja(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ja = this || self,
        Ka = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Ja, e = 0; e < c.length; e++)
                    if (d = d[c[e]], null == d) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return null != a ? a : b
        },
        La = function(a) {
            var b = typeof a;
            return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ma = function(a) {
            var b = La(a);
            return "array" == b || "object" == b && "number" == typeof a.length
        },
        Na = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        Oa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Yi = b.prototype;
            a.prototype = new c;
            a.prototype.constructor =
                a;
            a.Oj = function(d, e, f) {
                for (var g = Array(arguments.length - 2), k = 2; k < arguments.length; k++) g[k - 2] = arguments[k];
                return b.prototype[e].apply(d, g)
            }
        },
        Pa = function(a) {
            return a
        };
    var Qa = function() {
        this.Cg = 0
    };
    Qa.prototype.Zb = function(a, b) {
        var c = this;
        return function() {
            var d = y.apply(0, arguments);
            c.Cg = a;
            return b.apply(null, u(d))
        }
    };
    var Ra = function() {
            var a = {};
            this.Ea = (a[3] = [], a[2] = [], a[1] = [], a);
            this.ze = !1
        },
        Ta = function(a, b, c) {
            var d = Sa(a, c);
            a.Ea[c].push(b);
            d && 1 === a.Ea[c].length && a.flush()
        },
        Sa = function(a, b) {
            return Object.keys(a.Ea).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return 0 === a.Ea[c].length
            })
        };
    Ra.prototype.flush = function() {
        if (!this.ze) {
            this.ze = !0;
            try {
                for (; Object.values(this.Ea).some(function(a) {
                        return 0 < a.length
                    });) Ua(this, 3), Ua(this, 2), Ua(this, 1)
            } catch (a) {
                throw Object.values(this.Ea).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.ze = !1
            }
        }
    };
    var Ua = function(a, b) {
        for (; Sa(a, b) && 0 < a.Ea[b].length;) a.Ea[b][0](), a.Ea[b].shift()
    };
    da.Object.defineProperties(Ra.prototype, {
        qg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.Ea).some(function(a) {
                    return 0 < a.length
                })
            }
        }
    });

    function Va(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Va);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    Oa(Va, Error);
    Va.prototype.name = "CustomError";
    var Wa;

    function Xa(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Va.call(this, c + a[d])
    }
    Oa(Xa, Va);
    Xa.prototype.name = "AssertionError";

    function Ya(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Xa("" + e, f || []);
    }
    var z = function(a, b, c) {
            a || Ya("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Za = function(a, b, c) {
            null == a && Ya("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        $a = function(a, b) {
            throw new Xa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        ab = function(a, b, c) {
            "number" !== typeof a && Ya("Expected number but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        bb = function(a, b, c) {
            "string" !== typeof a && Ya("Expected string but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        cb = function(a, b, c) {
            "function" !== typeof a && Ya("Expected function but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        db = function(a, b, c) {
            Na(a) || Ya("Expected object but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        F = function(a, b, c) {
            Array.isArray(a) || Ya("Expected array but got %s: %s.", [La(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        fb = function(a, b, c, d) {
            a instanceof b || Ya("Expected instanceof %s but got %s.", [eb(b), eb(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function eb(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : null === a ? "null" : typeof a
    };
    var gb = Array.prototype.forEach ? function(a, b) {
            z(null != a.length);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        hb = Array.prototype.map ? function(a, b) {
            z(null != a.length);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = "string" === typeof a ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        ib = Array.prototype.some ? function(a, b) {
            z(null !=
                a.length);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function jb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function mb(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function nb(a, b, c) {
        if (!Ma(a) || !Ma(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || ob;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function ob(a, b) {
        return a === b
    }

    function pb(a, b) {
        return jb.apply([], hb(a, b))
    };
    var qb;
    var sb = function(a, b) {
        if (b !== rb) throw Error("n");
        this.lg = a
    };
    sb.prototype.toString = function() {
        return this.lg + ""
    };
    var rb = {},
        tb = function(a) {
            if (void 0 === qb) {
                var b = null;
                var c = Ja.trustedTypes;
                if (c && c.createPolicy) try {
                    b = c.createPolicy("goog#html", {
                        createHTML: Pa,
                        createScript: Pa,
                        createScriptURL: Pa
                    })
                } catch (d) {
                    Ja.console && Ja.console.error(d.message)
                }
                qb = b
            }
            a = (b = qb) ? b.createScriptURL(a) : a;
            return new sb(a, rb)
        };
    var ub = function(a, b) {
        return -1 != a.toLowerCase().indexOf(b.toLowerCase())
    };
    var yb = function(a) {
        if (vb !== vb) throw Error("o");
        this.Bi = a
    };
    yb.prototype.toString = function() {
        return this.Bi.toString()
    };
    var vb = {};
    new yb("about:invalid#zClosurez");
    new yb("about:blank");
    var zb = {},
        Ab = function() {
            if (zb !== zb) throw Error("p");
            this.Ai = ""
        };
    Ab.prototype.toString = function() {
        return this.Ai.toString()
    };
    new Ab;
    var Bb = {},
        Cb = function() {
            if (Bb !== Bb) throw Error("q");
            this.zi = ""
        };
    Cb.prototype.toString = function() {
        return this.zi.toString()
    };
    new Cb;
    var Db = Ka(610401301, !1),
        Eb = Ka(572417392, !0);

    function Fb() {
        var a = Ja.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Gb, Hb = Ja.navigator;
    Gb = Hb ? Hb.userAgentData || null : null;

    function Ib(a) {
        return Db ? Gb ? Gb.brands.some(function(b) {
            return (b = b.brand) && -1 != b.indexOf(a)
        }) : !1 : !1
    }

    function H(a) {
        return -1 != Fb().indexOf(a)
    };

    function Jb() {
        return Db ? !!Gb && 0 < Gb.brands.length : !1
    }

    function Kb() {
        return Jb() ? !1 : H("Opera")
    }

    function Lb() {
        return Jb() ? !1 : H("Trident") || H("MSIE")
    }

    function Mb() {
        return H("Safari") && !(Nb() || (Jb() ? 0 : H("Coast")) || Kb() || (Jb() ? 0 : H("Edge")) || (Jb() ? Ib("Microsoft Edge") : H("Edg/")) || (Jb() ? Ib("Opera") : H("OPR")) || H("Firefox") || H("FxiOS") || H("Silk") || H("Android"))
    }

    function Nb() {
        return Jb() ? Ib("Chromium") : (H("Chrome") || H("CriOS")) && !(Jb() ? 0 : H("Edge")) || H("Silk")
    }

    function Ob() {
        return H("Android") && !(Nb() || H("Firefox") || H("FxiOS") || Kb() || H("Silk"))
    }

    function Pb() {
        var a = Fb();
        if (Lb()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
        } else a = "";
        return a
    }

    function Qb() {
        if (Jb()) {
            var a = Gb.brands.find(function(b) {
                return "Internet Explorer" === b.brand
            });
            if (!a || !a.version) return NaN;
            a = a.version.split(".")
        } else {
            a = Pb();
            if ("" === a) return NaN;
            a = a.split(".")
        }
        return 0 === a.length ? NaN : Number(a[0])
    };
    var Rb = {},
        Tb = function() {
            var a = Ja.trustedTypes && Ja.trustedTypes.emptyHTML || "";
            if (Rb !== Rb) throw Error("r");
            this.yi = a
        };
    Tb.prototype.toString = function() {
        return this.yi.toString()
    };
    new Tb;
    var Ub = function() {
        this.names = new Map
    };
    Ub.prototype.Ma = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = null != (c = a.description) ? c : Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var Vb = !1,
        Xb = {
            set xa(a) {
                a ? console.warn("s`" + Error().stack) : Vb && console.log("t");
                Vb = a
            },
            get xa() {
                return Vb
            }
        };
    var Yb = "function" === typeof Symbol && Symbol.observable || "@@observable";

    function Zb(a) {
        setTimeout(function() {
            throw a;
        }, 0)
    };
    var $b = {
        closed: !0,
        next: function() {},
        error: function(a) {
            if (Xb.xa) throw a;
            Zb(a)
        },
        complete: function() {}
    };
    var ac = function() {
        function a(b) {
            this.message = b ? b.length + " errors occurred during unsubscription:\n" + b.map(function(c, d) {
                return d + 1 + ") " + c.toString()
            }).join("\n  ") : "";
            this.name = "UnsubscriptionError";
            this.errors = b;
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    var bc = Array.isArray || function(a) {
        return a && "number" === typeof a.length
    };

    function cc(a) {
        return "function" === typeof a
    };

    function dc(a) {
        return null !== a && "object" === typeof a
    };
    var I = function(a) {
        this.closed = !1;
        this.Ab = this.bc = null;
        a && (this.Pg = !0, this.Ha = a)
    };
    I.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.bc,
                b = this.Pg,
                c = this.Ha,
                d = this.Ab;
            this.closed = !0;
            this.Ab = this.bc = null;
            if (a instanceof I) a.remove(this);
            else if (null !== a)
                for (var e = 0; e < a.length; ++e) a[e].remove(this);
            if (cc(c)) {
                b && (this.Ha = void 0);
                try {
                    c.call(this)
                } catch (h) {
                    var f = h instanceof ac ? ec(h.errors) : [h]
                }
            }
            if (bc(d)) {
                e = -1;
                for (var g = d.length; ++e < g;) {
                    var k = d[e];
                    if (dc(k)) try {
                        k.unsubscribe()
                    } catch (h) {
                        f = f || [], h instanceof ac ? f = f.concat(ec(h.errors)) : f.push(h)
                    }
                }
            }
            if (f) throw new ac(f);
        }
    };
    I.prototype.add = function(a) {
        var b = a;
        if (!a) return I.EMPTY;
        switch (typeof a) {
            case "function":
                b = new I(a);
            case "object":
                if (b === this || b.closed || "function" !== typeof b.unsubscribe) return b;
                if (this.closed) return b.unsubscribe(), b;
                b instanceof I || (a = b, b = new I, b.Ab = [a]);
                break;
            default:
                throw Error("u`" + a);
        }
        var c = b.bc;
        if (null === c) b.bc = this;
        else if (c instanceof I) {
            if (c === this) return b;
            b.bc = [c, this]
        } else if (-1 === c.indexOf(this)) c.push(this);
        else return b;
        a = this.Ab;
        null === a ? this.Ab = [b] : a.push(b);
        return b
    };
    I.prototype.remove = function(a) {
        var b = this.Ab;
        b && (a = b.indexOf(a), -1 !== a && b.splice(a, 1))
    };
    var fc = new I;
    fc.closed = !0;
    I.EMPTY = fc;

    function gc(a) {
        return a instanceof I || a && "closed" in a && "function" === typeof a.remove && "function" === typeof a.add && "function" === typeof a.unsubscribe
    }

    function ec(a) {
        return a.reduce(function(b, c) {
            return b.concat(c instanceof ac ? c.errors : c)
        }, [])
    };
    var J = function(a, b, c) {
        I.call(this);
        this.yd = null;
        this.F = this.ma = this.xd = !1;
        switch (arguments.length) {
            case 0:
                this.destination = $b;
                break;
            case 1:
                if (!a) {
                    this.destination = $b;
                    break
                }
                if ("object" === typeof a) {
                    a instanceof J ? (this.ma = a.ma, this.destination = a, a.add(this)) : (this.ma = !0, this.destination = new hc(this, a));
                    break
                }
            default:
                this.ma = !0, this.destination = new hc(this, a, b, c)
        }
    };
    x(J, I);
    J.EMPTY = I.EMPTY;
    J.create = function(a, b, c) {
        a = new J(a, b, c);
        a.ma = !1;
        return a
    };
    n = J.prototype;
    n.next = function(a) {
        this.F || this.o(a)
    };
    n.error = function(a) {
        this.F || (this.F = !0, this.Z(a))
    };
    n.complete = function() {
        this.F || (this.F = !0, this.D())
    };
    n.unsubscribe = function() {
        this.closed || (this.F = !0, I.prototype.unsubscribe.call(this))
    };
    n.o = function(a) {
        this.destination.next(a)
    };
    n.Z = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.D = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var hc = function(a, b, c, d) {
        J.call(this);
        this.cc = a;
        var e = this;
        if (cc(b)) var f = b;
        else b && (f = b.next, c = b.error, d = b.complete, b !== $b && (e = Object.create(b), gc(b) && b.add(this.unsubscribe.bind(this)), e.unsubscribe = this.unsubscribe.bind(this)));
        this.Ga = e;
        this.o = f;
        this.Z = c;
        this.D = d
    };
    x(hc, J);
    hc.EMPTY = J.EMPTY;
    hc.create = J.create;
    n = hc.prototype;
    n.next = function(a) {
        if (!this.F && this.o) {
            var b = this.cc;
            Xb.xa && b.ma ? this.Hd(b, this.o, a) && this.unsubscribe() : this.Id(this.o, a)
        }
    };
    n.error = function(a) {
        if (!this.F) {
            var b = this.cc,
                c = Xb.xa;
            if (this.Z) c && b.ma ? this.Hd(b, this.Z, a) : this.Id(this.Z, a), this.unsubscribe();
            else if (b.ma) c ? (b.yd = a, b.xd = !0) : Zb(a), this.unsubscribe();
            else {
                this.unsubscribe();
                if (c) throw a;
                Zb(a)
            }
        }
    };
    n.complete = function() {
        var a = this;
        if (!this.F) {
            var b = this.cc;
            if (this.D) {
                var c = function() {
                    return a.D.call(a.Ga)
                };
                Xb.xa && b.ma ? this.Hd(b, c) : this.Id(c)
            }
            this.unsubscribe()
        }
    };
    n.Id = function(a, b) {
        try {
            a.call(this.Ga, b)
        } catch (c) {
            this.unsubscribe();
            if (Xb.xa) throw c;
            Zb(c)
        }
    };
    n.Hd = function(a, b, c) {
        if (!Xb.xa) throw Error("v");
        try {
            b.call(this.Ga, c)
        } catch (d) {
            return Xb.xa ? (a.yd = d, a.xd = !0) : Zb(d), !0
        }
        return !1
    };
    n.Ha = function() {
        var a = this.cc;
        this.cc = this.Ga = null;
        a.unsubscribe()
    };

    function ic(a) {
        return a
    };

    function K() {
        return jc(y.apply(0, arguments))
    }

    function jc(a) {
        return 0 === a.length ? ic : 1 === a.length ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };

    function kc(a) {
        return a && "function" === typeof a.next && "function" === typeof a.error && "function" === typeof a.complete
    }
    var lc = function(a) {
        J.call(this);
        this.destination = a
    };
    x(lc, J);
    lc.EMPTY = J.EMPTY;
    lc.create = J.create;
    var L = function(a) {
        a && (this.da = a)
    };
    n = L.prototype;
    n.Pb = function(a) {
        var b = new L;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        var d = this.operator;
        a: {
            if (a) {
                if (a instanceof J || kc(a) && gc(a)) break a;
                if (kc(a)) {
                    a = new lc(a);
                    break a
                }
            }
            a = a || b || c ? new J(a, b, c) : new J($b)
        }
        d ? a.add(d.call(a, this.source)) : a.add(this.source || Xb.xa && !a.ma ? this.da(a) : this.Nd(a));
        if (Xb.xa && a.ma && (a.ma = !1, a.xd)) throw a.yd;
        return a
    };
    n.Nd = function(a) {
        try {
            return this.da(a)
        } catch (e) {
            Xb.xa && (a.xd = !0, a.yd = e);
            var b;
            a: {
                for (b = a; b;) {
                    var c = b.destination,
                        d = b.F;
                    if (b.closed || d) {
                        b = !1;
                        break a
                    }
                    b = c && c instanceof J ? c : null
                }
                b = !0
            }
            b ? a.error(e) : console.warn(e)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = mc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (k) {
                    e(k), f && f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.da = function(a) {
        var b = this.source;
        return b && b.subscribe(a)
    };
    L.prototype[Yb] = function() {
        return this
    };
    L.prototype.g = function() {
        var a = y.apply(0, arguments);
        return 0 === a.length ? this : jc(a)(this)
    };
    L.create = function(a) {
        return new L(a)
    };

    function mc(a) {
        a || (a = Promise);
        if (!a) throw Error("w");
        return a
    };
    var nc = function(a, b) {
        I.call(this);
        this.xg = a;
        this.Ue = b;
        this.closed = !1
    };
    x(nc, I);
    nc.EMPTY = I.EMPTY;
    nc.prototype.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.xg,
                b = a.Qa;
            this.xg = null;
            !b || 0 === b.length || a.F || a.closed || (a = b.indexOf(this.Ue), -1 !== a && b.splice(a, 1))
        }
    };
    var oc = function() {
        function a() {
            this.message = "object unsubscribed";
            this.name = "ObjectUnsubscribedError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    var M = function() {
        this.Qa = [];
        this.lc = this.F = this.closed = !1;
        this.zd = null
    };
    x(M, L);
    n = M.prototype;
    n.Pb = function(a) {
        var b = new pc(this, this);
        b.operator = a;
        return b
    };
    n.next = function(a) {
        if (this.closed) throw new oc;
        if (!this.F) {
            var b = this.Qa,
                c = b.length;
            b = b.slice();
            for (var d = 0; d < c; d++) b[d].next(a)
        }
    };
    n.error = function(a) {
        if (this.closed) throw new oc;
        this.lc = !0;
        this.zd = a;
        this.F = !0;
        var b = this.Qa,
            c = b.length;
        b = b.slice();
        for (var d = 0; d < c; d++) b[d].error(a);
        this.Qa.length = 0
    };
    n.complete = function() {
        if (this.closed) throw new oc;
        this.F = !0;
        var a = this.Qa,
            b = a.length;
        a = a.slice();
        for (var c = 0; c < b; c++) a[c].complete();
        this.Qa.length = 0
    };
    n.unsubscribe = function() {
        this.closed = this.F = !0;
        this.Qa = null
    };
    n.Nd = function(a) {
        if (this.closed) throw new oc;
        return L.prototype.Nd.call(this, a)
    };
    n.da = function(a) {
        if (this.closed) throw new oc;
        if (this.lc) return a.error(this.zd), I.EMPTY;
        if (this.F) return a.complete(), I.EMPTY;
        this.Qa.push(a);
        return new nc(this, a)
    };
    n.O = function() {
        var a = new L;
        a.source = this;
        return a
    };
    M.create = function(a, b) {
        return new pc(a, b)
    };
    var pc = function(a, b) {
        M.call(this);
        this.destination = a;
        this.source = b
    };
    x(pc, M);
    pc.create = M.create;
    pc.prototype.next = function(a) {
        var b = this.destination;
        b && b.next && b.next(a)
    };
    pc.prototype.error = function(a) {
        var b = this.destination;
        b && b.error && this.destination.error(a)
    };
    pc.prototype.complete = function() {
        var a = this.destination;
        a && a.complete && this.destination.complete()
    };
    pc.prototype.da = function(a) {
        return this.source ? this.source.subscribe(a) : I.EMPTY
    };
    var qc = function(a) {
        M.call(this);
        this.Od = a
    };
    x(qc, M);
    qc.create = M.create;
    qc.prototype.da = function(a) {
        var b = M.prototype.da.call(this, a);
        b && !b.closed && a.next(this.Od);
        return b
    };
    qc.prototype.getValue = function() {
        if (this.lc) throw this.zd;
        if (this.closed) throw new oc;
        return this.Od
    };
    qc.prototype.next = function(a) {
        M.prototype.next.call(this, this.Od = a)
    };
    da.Object.defineProperties(qc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var rc = new L(function(a) {
        return a.complete()
    });

    function sc(a, b) {
        return new L(function(c) {
            var d = new I,
                e = 0;
            d.add(b.C(function() {
                e === a.length ? c.complete() : (c.next(a[e++]), c.closed || d.add(this.C()))
            }));
            return d
        })
    };
    var tc = function(a) {
        return function(b) {
            for (var c = 0, d = a.length; c < d && !b.closed; c++) b.next(a[c]);
            b.complete()
        }
    };

    function uc(a, b) {
        return b ? sc(a, b) : new L(tc(a))
    };

    function vc(a) {
        return a && "function" === typeof a.C
    };

    function N() {
        var a = y.apply(0, arguments),
            b = a[a.length - 1];
        return vc(b) ? (a.pop(), sc(a, b)) : uc(a)
    };

    function wc(a) {
        return new L(function(b) {
            return b.error(a)
        })
    };
    var xc = {
        now: function() {
            return (xc.oh || Date).now()
        },
        oh: void 0
    };
    var zc = function(a, b, c) {
        a = void 0 === a ? Infinity : a;
        b = void 0 === b ? Infinity : b;
        c = void 0 === c ? xc : c;
        M.call(this);
        this.cj = c;
        this.Kc = [];
        this.mf = !1;
        this.gf = 1 > a ? 1 : a;
        this.Vg = 1 > b ? 1 : b;
        Infinity === b ? (this.mf = !0, this.next = this.ki) : this.next = this.mi
    };
    x(zc, M);
    zc.create = M.create;
    n = zc.prototype;
    n.ki = function(a) {
        var b = this.Kc;
        b.push(a);
        b.length > this.gf && b.shift();
        M.prototype.next.call(this, a)
    };
    n.mi = function(a) {
        this.Kc.push({
            time: this.kf(),
            value: a
        });
        this.nf();
        M.prototype.next.call(this, a)
    };
    n.da = function(a) {
        var b = this.mf,
            c = b ? this.Kc : this.nf(),
            d = c.length;
        if (this.closed) throw new oc;
        if (this.F || this.lc) var e = I.EMPTY;
        else this.Qa.push(a), e = new nc(this, a);
        if (b)
            for (var f = 0; f < d && !a.closed; f++) a.next(c[f]);
        else
            for (f = 0; f < d && !a.closed; f++) a.next(c[f].value);
        this.lc ? a.error(this.zd) : this.F && a.complete();
        return e
    };
    n.kf = function() {
        var a = this.cj;
        return a ? a.now() : xc.now()
    };
    n.nf = function() {
        for (var a = this.kf(), b = this.gf, c = this.Vg, d = this.Kc, e = d.length, f = 0; f < e && !(a - d[f].time < c);) f++;
        e > b && (f = Math.max(f, e - b));
        0 < f && d.splice(0, f);
        return d
    };
    var Bc = function(a, b) {
        b = void 0 === b ? Ac : b;
        this.Og = a;
        this.now = b
    };
    Bc.prototype.C = function(a, b, c) {
        b = void 0 === b ? 0 : b;
        return (new this.Og(this, a)).C(c, b)
    };
    var Ac = xc.now;
    var Cc = function() {
        function a() {
            this.message = "no elements in sequence";
            this.name = "EmptyError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();

    function O(a, b) {
        if (a && "function" === typeof a.Pb) return a.Pb(b);
        throw new TypeError("x");
    };

    function Dc() {
        return function(a) {
            return O(a, new Ec)
        }
    }
    var Ec = function() {};
    Ec.prototype.call = function(a, b) {
        b.dc++;
        a = new Fc(a, b);
        var c = b.subscribe(a);
        a.closed || (a.connection = b.connect());
        return c
    };
    var Fc = function(a, b) {
        J.call(this, a);
        this.Cb = b;
        this.connection = null
    };
    x(Fc, J);
    Fc.EMPTY = J.EMPTY;
    Fc.create = J.create;
    Fc.prototype.Ha = function() {
        var a = this.Cb;
        if (a) {
            this.Cb = null;
            var b = a.dc;
            0 >= b ? this.connection = null : (a.dc = b - 1, 1 < b ? this.connection = null : (b = this.connection, a = a.zb, this.connection = null, !a || b && a !== b || a.unsubscribe()))
        } else this.connection = null
    };
    var Gc = function(a, b) {
        this.source = a;
        this.yg = b;
        this.dc = 0;
        this.Lc = !1
    };
    x(Gc, L);
    Gc.create = L.create;
    Gc.prototype.da = function(a) {
        return this.cd().subscribe(a)
    };
    Gc.prototype.cd = function() {
        var a = this.Mc;
        if (!a || a.F) this.Mc = this.yg();
        return this.Mc
    };
    Gc.prototype.connect = function() {
        var a = this.zb;
        a || (this.Lc = !1, a = this.zb = new I, a.add(this.source.subscribe(new Hc(this.cd(), this))), a.closed && (this.zb = null, a = I.EMPTY));
        return a
    };
    Gc.prototype.ng = function() {
        return Dc()(this)
    };
    var Ic, Jc = Gc.prototype;
    Ic = {
        operator: {
            value: null
        },
        dc: {
            value: 0,
            writable: !0
        },
        Mc: {
            value: null,
            writable: !0
        },
        zb: {
            value: null,
            writable: !0
        },
        da: {
            value: Jc.da
        },
        Lc: {
            value: Jc.Lc,
            writable: !0
        },
        cd: {
            value: Jc.cd
        },
        connect: {
            value: Jc.connect
        },
        ng: {
            value: Jc.ng
        }
    };
    var Hc = function(a, b) {
        J.call(this);
        this.destination = a;
        this.Cb = b
    };
    x(Hc, J);
    Hc.EMPTY = J.EMPTY;
    Hc.create = J.create;
    Hc.prototype.Z = function(a) {
        this.Ha();
        J.prototype.Z.call(this, a)
    };
    Hc.prototype.D = function() {
        this.Cb.Lc = !0;
        this.Ha();
        J.prototype.D.call(this)
    };
    Hc.prototype.Ha = function() {
        var a = this.Cb;
        if (a) {
            this.Cb = null;
            var b = a.zb;
            a.dc = 0;
            a.Mc = null;
            a.zb = null;
            b && b.unsubscribe()
        }
    };

    function P(a) {
        return function(b) {
            if ("function" !== typeof a) throw new TypeError("y");
            return O(b, new Kc(a))
        }
    }
    var Kc = function(a) {
        this.L = a;
        this.na = void 0
    };
    Kc.prototype.call = function(a, b) {
        return b.subscribe(new Lc(a, this.L, this.na))
    };
    var Lc = function(a, b, c) {
        J.call(this, a);
        this.L = b;
        this.count = 0;
        this.na = c || this
    };
    x(Lc, J);
    Lc.EMPTY = J.EMPTY;
    Lc.create = J.create;
    Lc.prototype.o = function(a) {
        try {
            var b = this.L.call(this.na, a, this.count++)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Mc = "function" === typeof Symbol && Symbol.iterator ? Symbol.iterator : "@@iterator";
    var Nc = function(a) {
        return a && "number" === typeof a.length && "function" !== typeof a
    };

    function Oc(a) {
        return !!a && "function" !== typeof a.subscribe && "function" === typeof a.then
    };

    function Pc(a) {
        return function(b) {
            Qc(a, b).catch(function(c) {
                return b.error(c)
            })
        }
    }

    function Qc(a, b) {
        var c, d, e, f, g, k;
        return Ba(function(h) {
            switch (h.ka) {
                case 1:
                    h.kb = 2;
                    h.La = 3;
                    var l = a[Symbol.asyncIterator];
                    f = void 0 !== l ? l.call(a) : new Ca(t(a));
                case 5:
                    return ta(h, f.next(), 8);
                case 8:
                    d = h.ff;
                    if (d.done) {
                        h.qb(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    h.qb(5);
                    break;
                case 3:
                    h.ie = [h.ea];
                    h.kb = 0;
                    h.La = 0;
                    h.kb = 0;
                    h.La = 9;
                    if (!d || d.done || !(e = f.return)) {
                        h.qb(9);
                        break
                    }
                    return ta(h, e.call(f), 9);
                case 9:
                    h.ie[1] = h.ea;
                    h.kb = 0;
                    h.La = 0;
                    if (c) throw c.error;
                    ua(h, 10, 1);
                    break;
                case 10:
                    ua(h, 4);
                    break;
                case 2:
                    h.kb = 0;
                    l = h.ea.Ef;
                    h.ea = null;
                    k = l;
                    c = {
                        error: k
                    };
                    h.qb(3);
                    break;
                case 4:
                    b.complete(), h.ka = 0
            }
        })
    };
    var Rc = function(a) {
        return function(b) {
            var c = a[Mc]();
            do {
                var d = void 0;
                try {
                    d = c.next()
                } catch (e) {
                    b.error(e);
                    return
                }
                if (d.done) {
                    b.complete();
                    break
                }
                b.next(d.value);
                if (b.closed) break
            } while (1);
            "function" === typeof c.return && b.add(function() {
                c.return && c.return()
            });
            return b
        }
    };
    var Sc = function(a) {
        return function(b) {
            var c = a[Yb]();
            if ("function" !== typeof c.subscribe) throw new TypeError("z");
            return c.subscribe(b)
        }
    };
    var Tc = function(a) {
        return function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, Zb);
            return b
        }
    };
    var Uc = function(a) {
        if (a && "function" === typeof a[Yb]) return Sc(a);
        if (Nc(a)) return tc(a);
        if (Oc(a)) return Tc(a);
        if (a && "function" === typeof a[Mc]) return Rc(a);
        if (Symbol && Symbol.asyncIterator && a && "function" === typeof a[Symbol.asyncIterator]) return Pc(a);
        throw new TypeError("A`" + (dc(a) ? "an invalid object" : "'" + a + "'"));
    };
    var Vc = function(a) {
        J.call(this);
        this.parent = a
    };
    x(Vc, J);
    Vc.EMPTY = J.EMPTY;
    Vc.create = J.create;
    Vc.prototype.o = function(a) {
        this.parent.ta(a)
    };
    Vc.prototype.Z = function(a) {
        this.parent.cb(a);
        this.unsubscribe()
    };
    Vc.prototype.D = function() {
        this.parent.U();
        this.unsubscribe()
    };
    var Wc = function(a, b, c) {
        J.call(this);
        this.parent = a;
        this.kg = b;
        this.xi = c
    };
    x(Wc, J);
    Wc.EMPTY = J.EMPTY;
    Wc.create = J.create;
    Wc.prototype.o = function(a) {
        this.parent.ta(this.kg, a, this.xi, this)
    };
    Wc.prototype.Z = function(a) {
        this.parent.cb(a);
        this.unsubscribe()
    };
    Wc.prototype.D = function() {
        this.parent.U(this);
        this.unsubscribe()
    };
    var Q = function() {
        J.apply(this, arguments)
    };
    x(Q, J);
    Q.EMPTY = J.EMPTY;
    Q.create = J.create;
    Q.prototype.ta = function(a) {
        this.destination.next(a)
    };
    Q.prototype.cb = function(a) {
        this.destination.error(a)
    };
    Q.prototype.U = function() {
        this.destination.complete()
    };
    var Xc = function() {
        J.apply(this, arguments)
    };
    x(Xc, J);
    Xc.EMPTY = J.EMPTY;
    Xc.create = J.create;
    Xc.prototype.ta = function(a, b) {
        this.destination.next(b)
    };
    Xc.prototype.cb = function(a) {
        this.destination.error(a)
    };
    Xc.prototype.U = function() {
        this.destination.complete()
    };

    function Yc(a, b) {
        if (!b.closed) return a instanceof L ? a.subscribe(b) : Uc(a)(b)
    };
    var Zc = {};

    function S() {
        var a = y.apply(0, arguments),
            b = void 0,
            c = void 0,
            d = void 0;
        vc(a[a.length - 1]) && (c = a.pop());
        "function" === typeof a[a.length - 1] && (b = a.pop());
        if (1 === a.length) {
            var e = a[0];
            bc(e) && (a = e);
            dc(e) && Object.getPrototypeOf(e) === Object.prototype && (d = Object.keys(e), a = d.map(function(f) {
                return e[f]
            }))
        }
        return O(uc(a, c), new $c(b, d))
    }
    var $c = function(a, b) {
        this.Ua = a;
        this.keys = b
    };
    $c.prototype.call = function(a, b) {
        return b.subscribe(new ad(a, this.Ua, this.keys))
    };
    var ad = function(a, b, c) {
        Xc.call(this, a);
        this.Ua = b;
        this.keys = c;
        this.active = 0;
        this.values = [];
        this.eb = []
    };
    x(ad, Xc);
    ad.EMPTY = Xc.EMPTY;
    ad.create = Xc.create;
    n = ad.prototype;
    n.o = function(a) {
        this.values.push(Zc);
        this.eb.push(a)
    };
    n.D = function() {
        var a = this.eb,
            b = a.length;
        if (0 === b) this.destination.complete();
        else {
            this.yb = this.active = b;
            for (var c = 0; c < b; c++) this.add(Yc(a[c], new Wc(this, null, c)))
        }
    };
    n.U = function() {
        0 === --this.active && this.destination.complete()
    };
    n.ta = function(a, b, c) {
        var d = this.values,
            e = d[c];
        e = this.yb ? e === Zc ? --this.yb : this.yb : 0;
        d[c] = b;
        0 === e && (this.Ua ? this.Rg(d) : this.destination.next(this.keys ? this.keys.reduce(function(f, g, k) {
            return f[g] = d[k], f
        }, {}) : d.slice()))
    };
    n.Rg = function(a) {
        try {
            var b = this.Ua.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };

    function bd(a, b) {
        if (!a) throw Error("B");
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.C(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.C())
                    })
                }))
            }));
            return d
        })
    };

    function cd(a, b) {
        if (!a) throw Error("B");
        return new L(function(c) {
            var d = new I,
                e;
            d.add(function() {
                e && "function" === typeof e.return && e.return()
            });
            d.add(b.C(function() {
                e = a[Mc]();
                d.add(b.C(function() {
                    if (!c.closed) {
                        try {
                            var f = e.next();
                            var g = f.value;
                            var k = f.done
                        } catch (h) {
                            c.error(h);
                            return
                        }
                        k ? c.complete() : (c.next(g), this.C())
                    }
                }))
            }));
            return d
        })
    };

    function dd(a, b) {
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                var e = a[Yb]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.C(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.C(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.C(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function ed(a, b) {
        return new L(function(c) {
            var d = new I;
            d.add(b.C(function() {
                return a.then(function(e) {
                    d.add(b.C(function() {
                        c.next(e);
                        d.add(b.C(function() {
                            return c.complete()
                        }))
                    }))
                }, function(e) {
                    d.add(b.C(function() {
                        return c.error(e)
                    }))
                })
            }));
            return d
        })
    };

    function fd(a) {
        var b = gd;
        if (null != a) {
            if (a && "function" === typeof a[Yb]) return dd(a, b);
            if (Oc(a)) return ed(a, b);
            if (Nc(a)) return sc(a, b);
            if (a && "function" === typeof a[Mc] || "string" === typeof a) return cd(a, b);
            if (Symbol && Symbol.asyncIterator && "function" === typeof a[Symbol.asyncIterator]) return bd(a, b)
        }
        throw new TypeError("C`" + (null !== a && typeof a || a));
    };

    function hd(a) {
        return a instanceof L ? a : new L(Uc(a))
    };

    function id(a, b) {
        var c = void 0 === c ? Infinity : c;
        if ("function" === typeof b) return function(d) {
            return d.g(id(function(e, f) {
                return hd(a(e, f)).g(P(function(g, k) {
                    return b(e, g, f, k)
                }))
            }, c))
        };
        "number" === typeof b && (c = b);
        return function(d) {
            return O(d, new jd(a, c))
        }
    }
    var jd = function(a, b) {
        b = void 0 === b ? Infinity : b;
        this.L = a;
        this.Wd = b
    };
    jd.prototype.call = function(a, b) {
        return b.subscribe(new kd(a, this.L, this.Wd))
    };
    var kd = function(a, b, c) {
        c = void 0 === c ? Infinity : c;
        Q.call(this, a);
        this.destination = a;
        this.L = b;
        this.Wd = c;
        this.Kb = !1;
        this.buffer = [];
        this.index = this.active = 0
    };
    x(kd, Q);
    kd.EMPTY = Q.EMPTY;
    kd.create = Q.create;
    kd.prototype.o = function(a) {
        if (this.active < this.Wd) {
            var b = this.index++;
            try {
                var c = this.L(a, b)
            } catch (d) {
                this.destination.error(d);
                return
            }
            this.active++;
            a = new Vc(this);
            this.destination.add(a);
            Yc(c, a)
        } else this.buffer.push(a)
    };
    kd.prototype.D = function() {
        this.Kb = !0;
        0 === this.active && 0 === this.buffer.length && this.destination.complete();
        this.unsubscribe()
    };
    kd.prototype.ta = function(a) {
        this.destination.next(a)
    };
    kd.prototype.U = function() {
        var a = this.buffer;
        this.active--;
        0 < a.length ? this.o(a.shift()) : 0 === this.active && this.Kb && this.destination.complete()
    };

    function ld(a) {
        a = void 0 === a ? Infinity : a;
        return id(ic, a)
    };

    function md() {
        return ld(1)(N.apply(null, u(y.apply(0, arguments))))
    };

    function nd(a, b, c) {
        if (cc(c)) {
            var d = c;
            c = void 0
        }
        return d ? nd(a, b, c).g(P(function(e) {
            return bc(e) ? d.apply(null, u(e)) : d(e)
        })) : new L(function(e) {
            od(a, b, function(f) {
                1 < arguments.length ? e.next(Array.prototype.slice.call(arguments)) : e.next(f)
            }, e, c)
        })
    }

    function od(a, b, c, d, e) {
        if (a && "function" === typeof a.addEventListener && "function" === typeof a.removeEventListener) {
            a.addEventListener(b, c, e);
            var f = function() {
                return a.removeEventListener(b, c, e)
            }
        } else if (a && "function" === typeof a.ri && "function" === typeof a.pi) a.ri(b, c), f = function() {
            return a.pi(b, c)
        };
        else if (a && "function" === typeof a.addListener && "function" === typeof a.removeListener) a.addListener(b, c), f = function() {
            return a.removeListener(b, c)
        };
        else if (a && a.length)
            for (var g = 0, k = a.length; g < k; g++) od(a[g], b,
                c, d, e);
        else throw new TypeError("D");
        d.add(f)
    };
    var pd = function() {
        I.call(this)
    };
    x(pd, I);
    pd.EMPTY = I.EMPTY;
    pd.prototype.C = function() {
        return this
    };
    var qd = function(a, b) {
        return setInterval.apply(null, [a, b].concat(u(y.apply(2, arguments))))
    };
    var rd = function(a, b) {
        I.call(this);
        this.scheduler = a;
        this.Fd = b;
        this.pending = !1
    };
    x(rd, pd);
    rd.EMPTY = pd.EMPTY;
    n = rd.prototype;
    n.C = function(a, b) {
        b = void 0 === b ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        null != a && (this.id = this.zc(c, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.Bc(c, this.id, b);
        return this
    };
    n.Bc = function(a, b, c) {
        return qd(a.flush.bind(a, this), void 0 === c ? 0 : c)
    };
    n.zc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && this.delay === c && !1 === this.pending) return b;
        clearInterval(b)
    };
    n.execute = function(a, b) {
        if (this.closed) return Error("E");
        this.pending = !1;
        if (a = this.hf(a, b)) return a;
        !1 === this.pending && null != this.id && (this.id = this.zc(this.scheduler, this.id, null))
    };
    n.hf = function(a) {
        var b = !1,
            c = void 0;
        try {
            this.Fd(a)
        } catch (d) {
            b = !0, c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    n.Ha = function() {
        var a = this.id,
            b = this.scheduler,
            c = b.actions,
            d = c.indexOf(this);
        this.state = this.Fd = null;
        this.pending = !1;
        this.scheduler = null; - 1 !== d && c.splice(d, 1);
        null != a && (this.id = this.zc(b, a, null));
        this.delay = null
    };
    var sd = function(a, b) {
        b = void 0 === b ? Ac : b;
        Bc.call(this, a, b);
        this.actions = [];
        this.active = !1;
        this.vd = void 0
    };
    x(sd, Bc);
    sd.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function td() {
        var a = y.apply(0, arguments),
            b = Infinity,
            c = void 0,
            d = a[a.length - 1];
        vc(d) ? (c = a.pop(), 1 < a.length && "number" === typeof a[a.length - 1] && (b = a.pop())) : "number" === typeof d && (b = a.pop());
        return !c && 1 === a.length && a[0] instanceof L ? a[0] : ld(b)(uc(a, c))
    };

    function ud() {};
    var vd = new L(ud);

    function T(a) {
        return function(b) {
            return O(b, new wd(a))
        }
    }
    var wd = function(a) {
        this.va = a;
        this.na = void 0
    };
    wd.prototype.call = function(a, b) {
        return b.subscribe(new xd(a, this.va, this.na))
    };
    var xd = function(a, b, c) {
        J.call(this, a);
        this.va = b;
        this.na = c;
        this.count = 0
    };
    x(xd, J);
    xd.EMPTY = J.EMPTY;
    xd.create = J.create;
    xd.prototype.o = function(a) {
        try {
            var b = this.va.call(this.na, a, this.count++)
        } catch (c) {
            this.destination.error(c);
            return
        }
        b && this.destination.next(a)
    };

    function yd() {
        var a = y.apply(0, arguments);
        if (1 === a.length)
            if (bc(a[0])) a = a[0];
            else return hd(a[0]);
        return O(uc(a), new zd)
    }
    var zd = function() {};
    zd.prototype.call = function(a, b) {
        return b.subscribe(new Ad(a))
    };
    var Ad = function(a) {
        Xc.call(this, a);
        this.nc = !1;
        this.eb = [];
        this.Ec = []
    };
    x(Ad, Xc);
    Ad.EMPTY = Xc.EMPTY;
    Ad.create = Xc.create;
    n = Ad.prototype;
    n.o = function(a) {
        this.eb.push(a)
    };
    n.D = function() {
        var a = this.eb,
            b = a.length;
        if (0 === b) this.destination.complete();
        else {
            for (var c = 0; c < b && !this.nc; c++) {
                var d = Yc(a[c], new Wc(this, null, c));
                this.Ec && this.Ec.push(d);
                this.add(d)
            }
            this.eb = null
        }
    };
    n.ta = function(a, b, c) {
        if (!this.nc) {
            this.nc = !0;
            for (var d = 0; d < this.Ec.length; d++)
                if (d !== c) {
                    var e = this.Ec[d];
                    e.unsubscribe();
                    this.remove(e)
                }
            this.Ec = null
        }
        this.destination.next(b)
    };
    n.U = function(a) {
        this.nc = !0;
        Xc.prototype.U.call(this, a)
    };
    n.cb = function(a) {
        this.nc = !0;
        Xc.prototype.cb.call(this, a)
    };

    function Bd() {
        var a = y.apply(0, arguments),
            b = void 0;
        "function" === typeof a[a.length - 1] && (b = a.pop());
        return O(uc(a), new Cd(b))
    }
    var Cd = function(a) {
        this.Ua = a
    };
    Cd.prototype.call = function(a, b) {
        return b.subscribe(new Dd(a, this.Ua))
    };
    var Dd = function(a, b, c) {
        void 0 === c && Object.create(null);
        J.call(this, a);
        this.De = [];
        this.active = 0;
        this.Ua = b
    };
    x(Dd, J);
    Dd.EMPTY = J.EMPTY;
    Dd.create = J.create;
    Dd.prototype.o = function(a) {
        var b = this.De;
        bc(a) ? b.push(new Ed(a)) : "function" === typeof a[Mc] ? b.push(new Fd(a[Mc]())) : b.push(new Gd(this.destination, this, a))
    };
    Dd.prototype.D = function() {
        var a = this.De,
            b = a.length;
        this.unsubscribe();
        if (0 === b) this.destination.complete();
        else {
            this.active = b;
            for (var c = 0; c < b; c++) {
                var d = a[c];
                d.Wi ? this.destination.add(d.subscribe()) : this.active--
            }
        }
    };
    Dd.prototype.Sg = function(a) {
        try {
            var b = this.Ua.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Fd = function(a) {
        this.iterator = a;
        this.Ie = a.next()
    };
    Fd.prototype.mb = function() {
        return !0
    };
    Fd.prototype.next = function() {
        var a = this.Ie;
        this.Ie = this.iterator.next();
        return a
    };
    Fd.prototype.Kb = function() {
        var a = this.Ie;
        return a && !!a.done
    };
    var Ed = function(a) {
        this.Rd = a;
        this.length = this.index = 0;
        this.length = a.length
    };
    Ed.prototype[Mc] = function() {
        return this
    };
    Ed.prototype.next = function() {
        var a = this.index++,
            b = this.Rd;
        return a < this.length ? {
            value: b[a],
            done: !1
        } : {
            value: null,
            done: !0
        }
    };
    Ed.prototype.mb = function() {
        return this.Rd.length > this.index
    };
    Ed.prototype.Kb = function() {
        return this.Rd.length === this.index
    };
    var Gd = function(a, b, c) {
        Q.call(this, a);
        this.parent = b;
        this.observable = c;
        this.Wi = !0;
        this.buffer = [];
        this.nb = !1
    };
    x(Gd, Q);
    Gd.EMPTY = Q.EMPTY;
    Gd.create = Q.create;
    Gd.prototype[Mc] = function() {
        return this
    };
    n = Gd.prototype;
    n.next = function() {
        var a = this.buffer;
        return 0 === a.length && this.nb ? {
            value: null,
            done: !0
        } : {
            value: a.shift(),
            done: !1
        }
    };
    n.mb = function() {
        return 0 < this.buffer.length
    };
    n.Kb = function() {
        return 0 === this.buffer.length && this.nb
    };
    n.U = function() {
        if (0 < this.buffer.length) {
            this.nb = !0;
            var a = this.parent;
            a.active--;
            0 === a.active && a.destination.complete()
        } else this.destination.complete()
    };
    n.ta = function(a) {
        this.buffer.push(a);
        a: {
            a = this.parent;
            for (var b = a.De, c = b.length, d = a.destination, e = 0; e < c; e++) {
                var f = b[e];
                if ("function" === typeof f.mb && !f.mb()) break a
            }
            e = !1;f = [];
            for (var g = 0; g < c; g++) {
                var k = b[g],
                    h = k.next();
                k.Kb() && (e = !0);
                if (h.done) {
                    d.complete();
                    break a
                }
                f.push(h.value)
            }
            a.Ua ? a.Sg(f) : d.next(f);e && d.complete()
        }
    };
    n.subscribe = function() {
        return Yc(this.observable, new Vc(this))
    };
    (function() {
        function a(b) {
            this.message = "Timeout has occurred";
            this.name = "TimeoutError";
            this.info = void 0 === b ? null : b;
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    var Hd = 1,
        Id, Jd = {};

    function Kd(a) {
        return a in Jd ? (delete Jd[a], !0) : !1
    }
    var Ld = function(a) {
        var b = Hd++;
        Jd[b] = !0;
        Id || (Id = Promise.resolve());
        Id.then(function() {
            return Kd(b) && a()
        });
        return b
    };
    var Md = function() {
        return Ld.apply(null, u(y.apply(0, arguments)))
    };
    var Nd = function(a, b) {
        rd.call(this, a, b);
        this.scheduler = a;
        this.Fd = b
    };
    x(Nd, rd);
    Nd.EMPTY = rd.EMPTY;
    Nd.prototype.Bc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && 0 < c) return rd.prototype.Bc.call(this, a, b, c);
        a.actions.push(this);
        return a.vd || (a.vd = Md(a.flush.bind(a, void 0)))
    };
    Nd.prototype.zc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        if (null !== c && 0 < c || null === c && 0 < this.delay) return rd.prototype.zc.call(this, a, b, c);
        0 === a.actions.length && (Kd(b), a.vd = void 0)
    };
    var Od = function() {
        sd.apply(this, arguments)
    };
    x(Od, sd);
    Od.prototype.flush = function(a) {
        this.active = !0;
        this.vd = void 0;
        var b = this.actions,
            c, d = -1;
        a = a || b.shift();
        var e = b.length;
        do
            if (c = a.execute(a.state, a.delay)) break; while (++d < e && (a = b.shift()));
        this.active = !1;
        if (c) {
            for (; ++d < e && (a = b.shift());) a.unsubscribe();
            throw c;
        }
    };
    var Pd = new Od(Nd);
    var Qd = function(a, b) {
        rd.call(this, a, b);
        this.scheduler = a;
        this.Fd = b
    };
    x(Qd, rd);
    Qd.EMPTY = rd.EMPTY;
    Qd.prototype.C = function(a, b) {
        b = void 0 === b ? 0 : b;
        if (0 < b) return rd.prototype.C.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    Qd.prototype.execute = function(a, b) {
        return 0 < b || this.closed ? rd.prototype.execute.call(this, a, b) : this.hf(a, b)
    };
    Qd.prototype.Bc = function(a, b, c) {
        c = void 0 === c ? 0 : c;
        return null !== c && 0 < c || null === c && 0 < this.delay ? rd.prototype.Bc.call(this, a, b, c) : a.flush(this)
    };
    var Rd = function() {
        sd.apply(this, arguments)
    };
    x(Rd, sd);
    var gd = new Rd(Qd);
    var Sd = function() {
        function a() {
            this.message = "argument out of range";
            this.name = "ArgumentOutOfRangeError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    }();
    (function() {
        function a(b) {
            this.message = b;
            this.name = "NotFoundError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    (function() {
        function a(b) {
            this.message = b;
            this.name = "SequenceError";
            return this
        }
        a.prototype = Object.create(Error.prototype);
        return a
    })();
    var Td = function() {
        this.B = new Qa;
        this.h = new Ra;
        this.Qh = Symbol();
        this.jc = new Ub
    };
    Td.prototype.le = function() {
        return vd
    };
    var Ud = function(a, b) {
        null !== a.Ja && a.Ja.next(b)
    };
    da.Object.defineProperties(Td.prototype, {
        xb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Qh
            }
        }
    });
    var Vd = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = Vd.prototype;
        this.name = String(a)
    };
    x(Vd, Error);
    var Wd = function(a) {
        Vd.call(this, 1E3, 'sfr:"' + a + '"');
        this.ei = a;
        this.__proto__ = Wd.prototype
    };
    x(Wd, Vd);
    var Xd = function() {
        Vd.call(this, 1003);
        this.__proto__ = Xd.prototype
    };
    x(Xd, Vd);
    var Yd = function() {
        Vd.call(this, 1009);
        this.__proto__ = Yd.prototype
    };
    x(Yd, Vd);
    var Zd = function() {
        Vd.call(this, 1011);
        this.__proto__ = Zd.prototype
    };
    x(Zd, Vd);
    var $d = function() {
        Vd.call(this, 1007);
        this.__proto__ = Xd.prototype
    };
    x($d, Vd);
    var ae = function() {
        Vd.call(this, 1008);
        this.__proto__ = Xd.prototype
    };
    x(ae, Vd);
    var be = function() {
        Vd.call(this, 1001);
        this.__proto__ = be.prototype
    };
    x(be, Vd);
    var ce = function(a) {
        Vd.call(this, 1004, String(a));
        this.Nh = a;
        this.__proto__ = ce.prototype
    };
    x(ce, Vd);
    var ee = function(a) {
        Vd.call(this, 1010, a);
        this.__proto__ = de.prototype
    };
    x(ee, Vd);
    var de = function(a) {
        Vd.call(this, 1005, a);
        this.__proto__ = de.prototype
    };
    x(de, Vd);
    var fe = function(a) {
        var b = y.apply(1, arguments),
            c = this;
        this.Ub = [];
        this.Ub.push(a);
        b.forEach(function(d) {
            c.Ub.push(d)
        })
    };
    fe.prototype.K = function(a) {
        return this.Ub.some(function(b) {
            return b.K(a)
        })
    };
    fe.prototype.T = function(a, b) {
        for (var c = 0; c < this.Ub.length; c++)
            if (this.Ub[c].K(b)) return this.Ub[c].T(a, b);
        throw new Yd;
    };

    function ge(a) {
        var b, c, d;
        return !!a && "boolean" === typeof a.active && "function" === typeof(null == (b = a.clock) ? void 0 : b.now) && void 0 !== (null == (c = a.clock) ? void 0 : c.timeline) && !(null == (d = a.A) || !d.timestamp) && "function" === typeof a.ha && "function" === typeof a.ia && "function" === typeof a.pa && "function" === typeof a.map && "function" === typeof a.sa
    };
    var je = Symbol("time-origin"),
        ke = Symbol("date"),
        le = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        me = function(a, b) {
            if (b.timeline !== a.timeline) throw new $d;
        },
        ne = function(a, b) {
            me(a, b);
            return a.value - b.value
        };
    n = le.prototype;
    n.equals = function(a) {
        return 0 === ne(this, a)
    };
    n.maximum = function(a) {
        me(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new le(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new le(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function oe(a) {
        function b(c) {
            return "boolean" === typeof c || "string" === typeof c || "number" === typeof c || void 0 === c || null === c
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : "object" === typeof a ? Object.keys(a).every(function(c) {
            return "string" === typeof c
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function pe(a) {
        if (oe(a)) return a;
        if (ge(a)) return {
            A: {
                value: pe(a.A.value),
                timestamp: ne(a.A.timestamp, new le(0, a.A.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var qe = ["sessionStart", "sessionError", "sessionFinish"],
        re = function(a, b) {
            this.ba = a;
            this.Ed = b;
            this.ready = !1;
            this.sb = [];
            this.sg = function() {};
            this.Ig = function() {};
            this.Jf = function() {};
            this.Qf = function() {};
            this.td = function() {}
        },
        se = function(a, b) {
            a.sg = b
        },
        te = function(a, b) {
            a.Ig = b
        },
        ue = function(a, b) {
            a.Jf = b
        },
        ve = function(a, b) {
            a.Qf = b
        },
        we = function(a, b) {
            a.td = b;
            a.td(a.sb.length)
        },
        Ce = function() {
            for (var a = xe.gb, b = t("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                    c = b.next(); !c.done; c = b.next()) a.ba.addEventListener(c.value, function(d) {
                ye(a, d)
            });
            ze(a.ba, function(d) {
                "sessionStart" !== d.type && ye(a, d)
            }, a.Ed);
            ze(a.ba, function(d) {
                "sessionStart" === d.type && (ye(a, d), Ae(a), Be(a))
            }, a.Ed)
        },
        ye = function(a, b) {
            a.sb.push(b);
            a.td(a.sb.length);
            Be(a)
        },
        Be = function(a) {
            if (a.ready)
                for (; 0 < a.sb.length;) {
                    var b = a.sb.pop();
                    void 0 !== b && ("geometryChange" === b.type ? a.Jf(b) : "impression" === b.type ? a.Qf(b) : qe.includes(b.type) ? a.sg(b) : a.Ig(b));
                    a.td(a.sb.length)
                }
        },
        Ae = function(a) {
            a.ready || (a.ready = !0, a.sb.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function De(a) {
        return function(b) {
            return O(b, function(c) {
                var d = this,
                    e = new I,
                    f = null,
                    g = !1,
                    k;
                f = c.subscribe({
                    next: function(h) {
                        return d.next(h)
                    },
                    error: function(h) {
                        try {
                            k = hd(a(h, De(a)(c)))
                        } catch (l) {
                            d.error(l)
                        }
                        k && (f ? (f.unsubscribe(), f = null, e.add(k.subscribe(d))) : g = !0)
                    },
                    complete: function() {
                        return d.complete()
                    }
                });
                g ? (f.unsubscribe(), f = null, e.add(k.subscribe(d))) : e.add(f);
                return e
            })
        }
    };

    function Ee() {
        var a = y.apply(0, arguments),
            b = void 0;
        "function" === typeof a[a.length - 1] && (b = a.pop());
        1 === a.length && bc(a[0]) && (a = a[0].slice());
        return function(c) {
            var d = hd([c].concat(u(a))),
                e = new $c(b);
            if (c && "function" === typeof c.Pb) c = c.Pb.call(d, e);
            else throw new TypeError("x");
            return c
        }
    }

    function Fe() {
        return Ee.apply(null, u(y.apply(0, arguments)))
    };

    function Ge(a) {
        a = void 0 === a ? null : a;
        return function(b) {
            return O(b, new He(a))
        }
    }
    var He = function(a) {
        this.defaultValue = a
    };
    He.prototype.call = function(a, b) {
        return b.subscribe(new Ie(a, this.defaultValue))
    };
    var Ie = function(a, b) {
        J.call(this, a);
        this.defaultValue = b;
        this.ld = !0
    };
    x(Ie, J);
    Ie.EMPTY = J.EMPTY;
    Ie.create = J.create;
    Ie.prototype.o = function(a) {
        this.ld = !1;
        this.destination.next(a)
    };
    Ie.prototype.D = function() {
        this.ld && this.destination.next(this.defaultValue);
        this.destination.complete()
    };

    function Je(a) {
        return function(b) {
            return O(b, new Ke(a))
        }
    }
    var Ke = function(a) {
        this.de = a
    };
    Ke.prototype.call = function(a, b) {
        return b.subscribe(new Le(a, this.de))
    };
    var Le = function(a, b) {
        Xc.call(this, a);
        this.de = b;
        this.ga = !1;
        this.Yc = [];
        this.index = 0
    };
    x(Le, Xc);
    Le.EMPTY = Xc.EMPTY;
    Le.create = Xc.create;
    n = Le.prototype;
    n.ta = function(a, b, c, d) {
        this.destination.next(a);
        Me(this, d);
        Ne(this)
    };
    n.cb = function(a) {
        this.Z(a)
    };
    n.U = function(a) {
        (a = Me(this, a)) && this.destination.next(a);
        Ne(this)
    };
    n.o = function(a) {
        var b = this.index++;
        try {
            var c = this.de(a, b);
            if (c) {
                var d = Yc(c, new Wc(this, a, 0));
                d && !d.closed && (this.destination.add(d), this.Yc.push(d))
            }
        } catch (e) {
            this.destination.error(e)
        }
    };
    n.D = function() {
        this.ga = !0;
        Ne(this);
        this.unsubscribe()
    };
    var Me = function(a, b) {
            b.unsubscribe();
            var c = a.Yc.indexOf(b); - 1 !== c && a.Yc.splice(c, 1);
            return b.kg
        },
        Ne = function(a) {
            a.ga && 0 === a.Yc.length && a.destination.complete()
        };

    function Oe(a) {
        return function(b) {
            return O(b, new Pe(a))
        }
    }
    var Pe = function(a) {
        this.bb = a;
        this.Dh = void 0
    };
    Pe.prototype.call = function(a, b) {
        return b.subscribe(new Qe(a, this.bb, this.Dh))
    };
    var Qe = function(a, b, c) {
        Q.call(this, a);
        this.bb = b;
        this.values = new Set;
        c && this.add(Yc(c, new Vc(this)))
    };
    x(Qe, Q);
    Qe.EMPTY = Q.EMPTY;
    Qe.create = Q.create;
    n = Qe.prototype;
    n.ta = function() {
        this.values.clear()
    };
    n.cb = function(a) {
        this.Z(a)
    };
    n.o = function(a) {
        this.bb ? this.Tg(a) : this.jf(a, a)
    };
    n.Tg = function(a) {
        var b = this.destination;
        try {
            var c = this.bb(a)
        } catch (d) {
            b.error(d);
            return
        }
        this.jf(c, a)
    };
    n.jf = function(a, b) {
        var c = this.values;
        c.has(a) || (c.add(a), this.destination.next(b))
    };

    function V(a) {
        return function(b) {
            return O(b, new Re(a))
        }
    }
    var Re = function(a) {
        this.compare = a;
        this.bb = void 0
    };
    Re.prototype.call = function(a, b) {
        return b.subscribe(new Se(a, this.compare, this.bb))
    };
    var Se = function(a, b, c) {
        J.call(this, a);
        this.bb = c;
        this.Pf = !1;
        "function" === typeof b && (this.compare = b)
    };
    x(Se, J);
    Se.EMPTY = J.EMPTY;
    Se.create = J.create;
    Se.prototype.compare = function(a, b) {
        return a === b
    };
    Se.prototype.o = function(a) {
        try {
            var b = this.bb;
            var c = b ? b(a) : a
        } catch (e) {
            return this.destination.error(e)
        }
        b = !1;
        if (this.Pf) try {
            var d = this.compare;
            b = d(this.key, c)
        } catch (e) {
            return this.destination.error(e)
        } else this.Pf = !0;
        b || (this.key = c, this.destination.next(a))
    };

    function Te(a) {
        if (isNaN(a)) throw new TypeError("F");
        if (0 > a) throw new Sd;
        return function(b) {
            return 0 === a ? rc : O(b, new Ue(a))
        }
    }
    var Ue = function(a) {
        this.count = a
    };
    Ue.prototype.call = function(a, b) {
        return b.subscribe(new Ve(a, this.count))
    };
    var Ve = function(a, b) {
        J.call(this, a);
        this.count = b;
        this.Ug = 0
    };
    x(Ve, J);
    Ve.EMPTY = J.EMPTY;
    Ve.create = J.create;
    Ve.prototype.o = function(a) {
        var b = this.count,
            c = ++this.Ug;
        c <= b && (this.destination.next(a), c === b && (this.destination.complete(), this.unsubscribe()))
    };

    function We(a) {
        a = void 0 === a ? Xe : a;
        return function(b) {
            return O(b, new Ye(a))
        }
    }
    var Ye = function(a) {
        this.ge = a
    };
    Ye.prototype.call = function(a, b) {
        return b.subscribe(new Ze(a, this.ge))
    };
    var Ze = function(a, b) {
        J.call(this, a);
        this.ge = b;
        this.mb = !1
    };
    x(Ze, J);
    Ze.EMPTY = J.EMPTY;
    Ze.create = J.create;
    Ze.prototype.o = function(a) {
        this.mb = !0;
        this.destination.next(a)
    };
    Ze.prototype.D = function() {
        if (this.mb) return this.destination.complete();
        try {
            var a = this.ge()
        } catch (b) {
            a = b
        }
        this.destination.error(a)
    };

    function Xe() {
        return new Cc
    };

    function $e() {
        var a = y.apply(0, arguments);
        return function(b) {
            return md(b, N.apply(null, u(a)))
        }
    };

    function af(a) {
        return function(b) {
            return O(b, new bf(a, b))
        }
    }
    var bf = function(a, b) {
        this.va = a;
        this.na = void 0;
        this.source = b
    };
    bf.prototype.call = function(a, b) {
        return b.subscribe(new cf(a, this.va, this.na, this.source))
    };
    var cf = function(a, b, c, d) {
        J.call(this, a);
        this.va = b;
        this.na = c;
        this.source = d;
        this.index = 0;
        this.na = c || this
    };
    x(cf, J);
    cf.EMPTY = J.EMPTY;
    cf.create = J.create;
    cf.prototype.U = function(a) {
        this.destination.next(a);
        this.destination.complete()
    };
    cf.prototype.o = function(a) {
        var b = !1;
        try {
            b = this.va.call(this.na, a, this.index++, this.source)
        } catch (c) {
            this.destination.error(c);
            return
        }
        b || this.U(!1)
    };
    cf.prototype.D = function() {
        this.U(!0)
    };

    function df() {
        return function(a) {
            return O(a, new ef)
        }
    }
    var ef = function() {};
    ef.prototype.call = function(a, b) {
        return b.subscribe(new ff(a))
    };
    var ff = function() {
        J.apply(this, arguments)
    };
    x(ff, J);
    ff.EMPTY = J.EMPTY;
    ff.create = J.create;
    ff.prototype.o = function() {};

    function gf() {
        if (isNaN(1)) throw new TypeError("F");
        return function(a) {
            return O(a, new hf)
        }
    }
    var hf = function() {
        this.total = 1
    };
    hf.prototype.call = function(a, b) {
        return b.subscribe(new jf(a, this.total))
    };
    var jf = function(a, b) {
        J.call(this, a);
        this.total = b;
        this.pg = [];
        this.count = 0
    };
    x(jf, J);
    jf.EMPTY = J.EMPTY;
    jf.create = J.create;
    jf.prototype.o = function(a) {
        var b = this.pg,
            c = this.total,
            d = this.count++;
        b.length < c ? b.push(a) : b[d % c] = a
    };
    jf.prototype.D = function() {
        var a = this.destination,
            b = this.count;
        if (0 < b)
            for (var c = this.count >= this.total ? this.total : this.count, d = this.pg, e = 0; e < c; e++) {
                var f = b++ % c;
                a.next(d[f])
            }
        a.complete()
    };

    function kf(a, b) {
        var c = 2 <= arguments.length;
        return function(d) {
            return d.g(a ? T(function(e, f) {
                return a(e, f, d)
            }) : ic, gf(), c ? Ge(b) : We(function() {
                return new Cc
            }))
        }
    };

    function lf(a) {
        return function(b) {
            return O(b, new mf(a))
        }
    }
    var mf = function(a) {
        this.value = a
    };
    mf.prototype.call = function(a, b) {
        return b.subscribe(new nf(a, this.value))
    };
    var nf = function(a, b) {
        J.call(this, a);
        this.value = b
    };
    x(nf, J);
    nf.EMPTY = J.EMPTY;
    nf.create = J.create;
    nf.prototype.o = function() {
        this.destination.next(this.value)
    };

    function of (a, b) {
        var c = !1;
        2 <= arguments.length && (c = !0);
        return function(d) {
            return O(d, new pf(a, b, c))
        }
    }
    var pf = function(a, b, c) {
        this.Pd = a;
        this.seed = b;
        this.Kh = void 0 === c ? !1 : c
    };
    pf.prototype.call = function(a, b) {
        return b.subscribe(new qf(a, this.Pd, this.seed, this.Kh))
    };
    var qf = function(a, b, c, d) {
        J.call(this, a);
        this.Pd = b;
        this.Jd = c;
        this.lf = d;
        this.index = 0
    };
    x(qf, J);
    qf.EMPTY = J.EMPTY;
    qf.create = J.create;
    qf.prototype.o = function(a) {
        var b = this.destination;
        if (this.lf) {
            var c = this.index++;
            try {
                var d = this.Pd(this.Jd, a, c)
            } catch (e) {
                b.error(e);
                return
            }
            this.Jd = d;
            b.next(d)
        } else this.Jd = a, this.lf = !0, b.next(a)
    };

    function rf(a) {
        return function(b) {
            var c = "function" === typeof a ? a : function() {
                return a
            };
            var d = Object.create(b, Ic);
            d.source = b;
            d.yg = c;
            return d
        }
    };

    function sf() {
        var a = y.apply(0, arguments);
        1 === a.length && bc(a[0]) && (a = a[0]);
        return function(b) {
            return O(b, new tf(a))
        }
    }
    var tf = function(a) {
        this.Je = a
    };
    tf.prototype.call = function(a, b) {
        return b.subscribe(new uf(a, this.Je))
    };
    var uf = function(a, b) {
        Q.call(this, a);
        this.destination = a;
        this.Je = b
    };
    x(uf, Q);
    uf.EMPTY = Q.EMPTY;
    uf.create = Q.create;
    uf.prototype.cb = function() {
        vf(this)
    };
    uf.prototype.U = function() {
        vf(this)
    };
    uf.prototype.Z = function() {
        vf(this);
        this.unsubscribe()
    };
    uf.prototype.D = function() {
        vf(this);
        this.unsubscribe()
    };
    var vf = function(a) {
        var b = a.Je.shift();
        if (b) {
            var c = new Vc(a);
            a.destination.add(c);
            Yc(b, c)
        } else a.destination.complete()
    };

    function wf(a) {
        var b = new zc(a, void 0, void 0);
        return function(c) {
            return rf(function() {
                return b
            })(c)
        }
    };

    function xf() {
        var a = void 0 === a ? Infinity : a;
        return function(b) {
            return 0 >= a ? rc : O(b, function(c) {
                var d = this,
                    e = 0,
                    f = new I,
                    g, k = function() {
                        var h = !1;
                        g = c.subscribe({
                            next: function(l) {
                                return d.next(l)
                            },
                            error: function(l) {
                                return d.error(l)
                            },
                            complete: function() {
                                ++e < a ? g ? (g.unsubscribe(), g = null, k()) : h = !0 : d.complete()
                            }
                        });
                        h ? (g.unsubscribe(), g = null, k()) : f.add(g)
                    };
                k();
                return f
            })
        }
    };

    function yf() {
        return new M
    }

    function zf() {
        return function(a) {
            return Dc()(rf(yf)(a))
        }
    };

    function W() {
        var a = y.apply(0, arguments),
            b = a[a.length - 1];
        return vc(b) ? (a.pop(), function(c) {
            return md(a, c, b)
        }) : function(c) {
            return md(a, c)
        }
    };
    var Af = function(a, b, c) {
        b = void 0 === b ? 0 : b;
        c = void 0 === c ? Pd : c;
        this.source = a;
        this.delayTime = b;
        this.scheduler = c;
        0 > b && (this.delayTime = 0);
        vc(c) || (this.scheduler = Pd)
    };
    x(Af, L);
    Af.create = L.create;
    Af.ph = function(a) {
        return this.add(a.source.subscribe(a.Ue))
    };
    Af.prototype.da = function(a) {
        return this.scheduler.C(Af.ph, this.delayTime, {
            source: this.source,
            Ue: a
        })
    };

    function Bf() {
        var a = void 0 === a ? 0 : a;
        return function(b) {
            return O(b, new Cf(a))
        }
    }
    var Cf = function(a) {
        this.scheduler = gd;
        this.delay = a
    };
    Cf.prototype.call = function(a, b) {
        return (new Af(b, this.delay, this.scheduler)).subscribe(a)
    };

    function X(a) {
        return function(b) {
            return O(b, new Df(a))
        }
    }
    var Df = function(a) {
        this.L = a
    };
    Df.prototype.call = function(a, b) {
        return b.subscribe(new Ef(a, this.L))
    };
    var Ef = function(a, b) {
        Q.call(this, a);
        this.destination = a;
        this.L = b;
        this.index = 0
    };
    x(Ef, Q);
    Ef.EMPTY = Q.EMPTY;
    Ef.create = Q.create;
    n = Ef.prototype;
    n.o = function(a) {
        var b = this.index++;
        try {
            var c = this.L(a, b)
        } catch (d) {
            this.destination.error(d);
            return
        }(a = this.hd) && a.unsubscribe();
        a = new Vc(this);
        this.destination.add(a);
        this.hd = a;
        Yc(c, a)
    };
    n.D = function() {
        var a = this.hd;
        a && !a.closed || Q.prototype.D.call(this);
        this.unsubscribe()
    };
    n.Ha = function() {
        this.hd = void 0
    };
    n.U = function() {
        this.hd = void 0;
        this.F && Q.prototype.D.call(this)
    };
    n.ta = function(a) {
        this.destination.next(a)
    };

    function Ff(a, b) {
        b = void 0 === b ? !1 : b;
        return function(c) {
            return O(c, new Gf(a, b))
        }
    }
    var Gf = function(a, b) {
        this.va = a;
        this.ue = b
    };
    Gf.prototype.call = function(a, b) {
        return b.subscribe(new Hf(a, this.va, this.ue))
    };
    var Hf = function(a, b, c) {
        J.call(this, a);
        this.va = b;
        this.ue = c;
        this.index = 0
    };
    x(Hf, J);
    Hf.EMPTY = J.EMPTY;
    Hf.create = J.create;
    Hf.prototype.o = function(a) {
        var b = this.destination;
        try {
            var c = this.va(a, this.index++)
        } catch (d) {
            b.error(d);
            return
        }
        b = this.destination;
        c ? b.next(a) : (this.ue && b.next(a), b.complete())
    };

    function If(a, b, c) {
        return function(d) {
            return O(d, new Jf(a, b, c))
        }
    }
    var Jf = function(a, b, c) {
        this.li = a;
        this.error = b;
        this.complete = c
    };
    Jf.prototype.call = function(a, b) {
        return b.subscribe(new Kf(a, this.li, this.error, this.complete))
    };
    var Kf = function(a, b, c, d) {
        J.call(this, a);
        this.Kd = this.Ld = this.Md = ud;
        this.Ld = c || ud;
        this.Kd = d || ud;
        cc(b) ? (this.Ga = this, this.Md = b) : b && (this.Ga = b, this.Md = b.next || ud, this.Ld = b.error || ud, this.Kd = b.complete || ud)
    };
    x(Kf, J);
    Kf.EMPTY = J.EMPTY;
    Kf.create = J.create;
    Kf.prototype.o = function(a) {
        try {
            this.Md.call(this.Ga, a)
        } catch (b) {
            this.destination.error(b);
            return
        }
        this.destination.next(a)
    };
    Kf.prototype.Z = function(a) {
        try {
            this.Ld.call(this.Ga, a)
        } catch (b) {
            this.destination.error(b);
            return
        }
        this.destination.error(a)
    };
    Kf.prototype.D = function() {
        try {
            this.Kd.call(this.Ga)
        } catch (a) {
            this.destination.error(a);
            return
        }
        return this.destination.complete()
    };

    function Lf() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c;
            "function" === typeof a[a.length - 1] && (c = a.pop());
            return O(b, new Mf(a, c))
        }
    }
    var Mf = function(a, b) {
        this.eb = a;
        this.L = b
    };
    Mf.prototype.call = function(a, b) {
        return b.subscribe(new Nf(a, this.eb, this.L))
    };
    var Nf = function(a, b, c) {
        Xc.call(this, a);
        this.L = c;
        this.yb = [];
        a = b.length;
        this.values = Array(a);
        for (c = 0; c < a; c++) this.yb.push(c);
        for (c = 0; c < a; c++) this.add(Yc(b[c], new Wc(this, void 0, c)))
    };
    x(Nf, Xc);
    Nf.EMPTY = Xc.EMPTY;
    Nf.create = Xc.create;
    Nf.prototype.ta = function(a, b, c) {
        this.values[c] = b;
        b = this.yb;
        0 < b.length && (c = b.indexOf(c), -1 !== c && b.splice(c, 1))
    };
    Nf.prototype.U = function() {};
    Nf.prototype.o = function(a) {
        0 === this.yb.length && (a = [a].concat(u(this.values)), this.L ? this.Qg(a) : this.destination.next(a))
    };
    Nf.prototype.Qg = function(a) {
        try {
            var b = this.L.apply(this, a)
        } catch (c) {
            this.destination.error(c);
            return
        }
        this.destination.next(b)
    };
    var Pf = function(a) {
        this.ba = a
    };
    Pf.prototype.K = function(a) {
        return (null == a ? 0 : a.Qc) ? !0 : "POST" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Fb) || (null == a ? 0 : a.ce) ? !1 : this.ba.K()
    };
    Pf.prototype.ping = function() {
        var a = this,
            b = N.apply(null, u(y.apply(0, arguments))).g(id(function(c) {
                return Qf(a, c)
            }), af(function(c) {
                return c
            }), wf(1));
        b.connect();
        return b
    };
    var Qf = function(a, b) {
        var c = new zc(1);
        Rf(a.ba, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    Pf.prototype.sd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Sf(a, b) {
        var c = !1;
        return new L(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var Tf = function(a) {
        this.ba = a;
        this.timeline = ke
    };
    n = Tf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.ba.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.ba.clearTimeout(a)
    };
    n.now = function() {
        return new le(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        return Sf(this, a).g(xf(), of (function(b) {
            return b + 1
        }, -1))
    };
    n.fa = function() {
        return !0
    };
    var Uf = function(a, b) {
        this.context = a;
        this.Vb = b
    };
    Uf.prototype.K = function(a) {
        return this.Vb.K(a)
    };
    Uf.prototype.T = function(a, b) {
        if (!this.K(b)) throw new Yd;
        return new Vf(this.context, this.Vb, null != b ? b : void 0, a)
    };
    var Vf = function(a, b, c, d) {
        var e = this;
        this.Vb = b;
        this.properties = c;
        this.url = d;
        this.kd = !0;
        this.Fb = new Map;
        this.body = void 0;
        var f;
        this.method = null != (f = null == c ? void 0 : c.Bb) ? f : "GET";
        this.bh = a.le().subscribe(function() {
            e.sendNow()
        })
    };
    Vf.prototype.deactivate = function() {
        this.kd = !1
    };
    Vf.prototype.sendNow = function() {
        if (this.kd)
            if (this.bh.unsubscribe(), this.Vb.K(this.properties)) try {
                if (0 < this.Fb.size || void 0 !== this.body) {
                    var a, b;
                    this.Vb.sd(null != (a = this.properties) ? a : {}, this.Fb, null != (b = this.body) ? b : "", this.url)
                } else this.Vb.ping(this.url);
                this.kd = !1
            } catch (c) {} else this.kd = !1
    };
    var Xf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.i = b;
            this.setTime = c;
            this.Ac = d;
            this.bj = e;
            this.gh = f;
            this.ga = !1;
            this.id = 0 === this.mode ? Wf(this) : 0
        },
        Wf = function(a) {
            return a.i.setTimeout(function() {
                Yf(a)
            }, a.Ac)
        },
        Zf = function(a, b) {
            var c = ne(b, a.setTime);
            c >= a.Ac ? Yf(a) : (a.setTime = b, a.Ac -= c)
        },
        Yf = function(a) {
            try {
                a.bj(a.setTime.add(a.Ac))
            } finally {
                a.ga = !0, a.gh()
            }
        };
    Xf.prototype.Ye = function(a, b) {
        this.ga || (1 === this.mode && 1 === a ? Zf(this, b) : 1 === this.mode && 0 === a ? (this.mode = a, Zf(this, this.i.now()), this.ga || (this.id = Wf(this))) : 0 === this.mode && 1 === a && (this.mode = a, this.clear(), Zf(this, b)))
    };
    Xf.prototype.clear = function() {
        this.ga || this.i.clearTimeout(this.id)
    };
    var $f = function(a) {
        this.Xc = a;
        this.Oh = this.mode = 0;
        this.Nb = {};
        this.timeline = a.timeline;
        this.rb = a.now()
    };
    n = $f.prototype;
    n.Ye = function(a, b) {
        this.mode = a;
        me(this.rb, b);
        this.rb = b;
        Object.values(this.Nb).forEach(function(c) {
            return void c.Ye(a, b)
        })
    };
    n.now = function() {
        return 1 === this.mode ? this.rb : this.Xc.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.Oh,
            e = 1 === this.mode ? this.rb : this.Xc.now();
        this.Nb[d] = new Xf(this.mode, this.Xc, e, b, function(f) {
            var g = c.rb;
            1 === c.mode && (c.rb = f);
            a();
            c.rb = g
        }, function() {
            delete c.Nb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Nb[a] && (this.Nb[a].clear(), delete this.Nb[a])
    };
    n.interval = function() {
        throw Error("G");
    };
    n.Oa = function() {
        throw Error("H");
    };
    n.fa = function() {
        return this.Xc.fa()
    };

    function ag(a, b) {
        var c = new $f(a);
        a = b.subscribe(function(d) {
            c.Ye(d.value ? 1 : 0, d.timestamp)
        });
        return {
            i: c,
            Vj: a
        }
    };

    function bg(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new le(a.timestamp, ke),
            value: b
        }
    };

    function cg(a) {
        return void 0 !== a && "number" === typeof a.x && "number" === typeof a.y && "number" === typeof a.width && "number" === typeof a.height
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var dg = fa([""]),
        eg = ha(["\x00"], ["\\0"]),
        fg = ha(["\n"], ["\\n"]),
        gg = ha(["\x00"], ["\\u0000"]),
        hg = fa([""]),
        ig = ha(["\x00"], ["\\0"]),
        jg = ha(["\n"], ["\\n"]),
        kg = ha(["\x00"], ["\\u0000"]);

    function lg(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function mg(a) {
        return -1 === a.toString().indexOf("`")
    }
    var ng = mg(function(a) {
            return a(dg)
        }) || mg(function(a) {
            return a(eg)
        }) || mg(function(a) {
            return a(fg)
        }) || mg(function(a) {
            return a(gg)
        }),
        og = lg(hg) && lg(ig) && lg(jg) && lg(kg);
    var pg = function(a, b) {
        this.name = a;
        this.value = b
    };
    pg.prototype.toString = function() {
        return this.name
    };
    var qg = new pg("OFF", Infinity),
        rg = new pg("WARNING", 900),
        sg = new pg("INFO", 800),
        tg = new pg("CONFIG", 700),
        ug = function() {
            this.Tc = 0;
            this.clear()
        },
        vg;
    ug.prototype.clear = function() {
        this.tf = Array(this.Tc);
        this.yf = -1;
        this.Yf = !1
    };
    var wg = function(a, b, c) {
        this.reset(a || qg, b, c, void 0, void 0)
    };
    wg.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.ji = b
    };
    wg.prototype.getMessage = function() {
        return this.ji
    };
    var xg = function(a, b) {
            this.level = null;
            this.Hh = [];
            this.parent = (void 0 === b ? null : b) || null;
            this.children = [];
            this.dg = {
                Ma: function() {
                    return a
                }
            }
        },
        yg = function(a) {
            if (a.level) return a.level;
            if (a.parent) return yg(a.parent);
            $a("Root logger has no level set.");
            return qg
        },
        zg = function(a, b) {
            for (; a;) a.Hh.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        Ag = function() {
            this.entries = {};
            var a = new xg("");
            a.level = tg;
            this.entries[""] = a
        },
        Bg, Cg = function(a, b, c) {
            var d = a.entries[b];
            if (d) return void 0 !== c && (d.level = c), d;
            d = Cg(a, b.slice(0,
                Math.max(b.lastIndexOf("."), 0)));
            var e = new xg(b, d);
            a.entries[b] = e;
            d.children.push(e);
            void 0 !== c && (e.level = c);
            return e
        },
        Dg = function() {
            Bg || (Bg = new Ag);
            return Bg
        },
        Eg = function(a, b) {
            var c = rg,
                d;
            if (d = a)
                if (d = a && c) {
                    d = c.value;
                    var e = a ? yg(Cg(Dg(), a.Ma())) : qg;
                    d = d >= e.value
                }
            if (d) {
                c = c || qg;
                d = Cg(Dg(), a.Ma());
                "function" === typeof b && (b = b());
                vg || (vg = new ug);
                e = vg;
                a = a.Ma();
                if (0 < e.Tc) {
                    var f = (e.yf + 1) % e.Tc;
                    e.yf = f;
                    e.Yf ? (e = e.tf[f], e.reset(c, b, a), a = e) : (e.Yf = f == e.Tc - 1, a = e.tf[f] = new wg(c, b, a))
                } else a = new wg(c, b, a);
                zg(d, a)
            }
        };
    var Fg = [],
        Gg = function(a) {
            var b = Cg(Dg(), "safevalues").dg;
            b && Eg(b, "A URL with content '" + a + "' was sanitized away.")
        }; - 1 === Fg.indexOf(Gg) && Fg.push(Gg);

    function Hg(a) {
        var b = y.apply(1, arguments);
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !ng && a === a.raw || !(ng && !og || lg(a)) || b.length + 1 !== a.length) throw new TypeError("I");
        if (0 === b.length) return tb(a[0]);
        var c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("P");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("J");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("K");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("L");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("M");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if ("/" === c || 1 < c.length && "/" !== c[1] && "\\" !== c[1]) d = !0;
                else throw Error("O");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if ("about:blank" !== c && !/^about:blank#/.test(c)) throw Error("N");
                d = !0
            } else d = !1;
        if (!d) throw Error("Q");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return tb(c)
    };
    var Ig = fa(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Jg = fa(["./reach_worklet.js"]),
        Kg = fa(["./reach_worklet.js"]),
        Lg = fa(["./reach_worklet.html"]),
        Mg = fa(["./reach_worklet.js"]),
        Ng = fa(["./reach_worklet.js"]);

    function Og(a) {
        var b = {};
        return b[0] = Hg(Ig, a), b[1] = Hg(Jg), b[2] = Hg(Kg), b
    }
    Hg(Lg);
    Hg(Mg);
    Hg(Ng);
    var Qg = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? Og("current") : d;
        Td.call(this);
        this.ba = a;
        this.Ed = b;
        this.Ja = c;
        this.wg = d;
        this.gb = null;
        this.Re = new zc(3);
        this.Re.g(T(function(e) {
            return "sessionStart" === e.value.type
        }));
        this.Qi = this.Re.g(T(function(e) {
            return "sessionFinish" === e.value.type
        }));
        this.Rf = new zc(1);
        this.hj = new zc;
        this.Kf = new zc(10);
        this.J = new Uf(this, new Pf(a));
        this.Wh = this.ba.K();
        this.i = Pg(this, new Tf(this.ba))
    };
    x(Qg, Td);
    Qg.prototype.validate = function() {
        return this.Wh
    };
    var Pg = function(a, b) {
        a.gb = new re(a.ba, a.Ed);
        var c = new zc;
        se(a.gb, function(f) {
            f = bg(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Re.next(f)
        });
        ue(a.gb, function(f) {
            if (void 0 === f) var g = !1;
            else {
                g = f.data;
                var k;
                (k = void 0 === g) || (k = g.viewport, k = void 0 === k || void 0 !== k && "number" === typeof k.width && "number" === typeof k.height);
                k ? (g = g.adView, g = void 0 !== g && "number" === typeof g.percentageInView && (void 0 === g.geometry || cg(g.geometry)) && (void 0 === g.onScreenGeometry || cg(g.onScreenGeometry))) : g = !1
            }
            g ? (f = bg(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.Kf.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.J.T(f).sendNow())
        });
        te(a.gb, function(f) {
            f = bg(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.hj.next(f)
        });
        ve(a.gb, function(f) {
            f = bg(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Rf.next(f)
        });
        var d = 0;
        we(a.gb, function(f) {
            d += f;
            0 < d && 0 === f && c.next({
                timestamp: a.i.now(),
                value: !1
            })
        });
        var e = c.g(Ff(function(f) {
            return f.value
        }, !0));
        return ag(b,
            e).i
    };
    da.Object.defineProperties(Qg.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Rg
            }
        }
    });
    var Rg = {};

    function Sg(a, b) {
        return function(c) {
            return new L(function(d) {
                return c.subscribe(function(e) {
                    a.Zb(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.Zb(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.Zb(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var Ug = function() {
        for (var a = t(y.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.fa()) {
                this.i = b;
                return
            }
        this.i = new Tg
    };
    n = Ug.prototype;
    n.fa = function() {
        return this.i.fa()
    };
    n.now = function() {
        return this.i.now()
    };
    n.setTimeout = function(a, b) {
        return this.i.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.i.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        return this.i.Oa(a)
    };
    da.Object.defineProperties(Ug.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.i.timeline
            }
        }
    });
    var Tg = function() {
        this.timeline = Symbol()
    };
    n = Tg.prototype;
    n.fa = function() {
        return !1
    };
    n.now = function() {
        return new le(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Oa = function() {
        return vd
    };
    var Vg = function(a, b) {
        this.I = a;
        this.B = b
    };
    n = Vg.prototype;
    n.setTimeout = function(a, b) {
        return this.I.setTimeout(this.B.Zb(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.I.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Oa(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Oa = function(a) {
        var b = this;
        return new L(function(c) {
            var d = 0,
                e = b.I.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.I.clearInterval(e)
            }
        })
    };
    n.fa = function() {
        return !!this.I.clearTimeout && "setTimeout" in this.I && "setInterval" in this.I && !!this.I.clearInterval
    };
    var Wg = function(a, b) {
        Vg.call(this, a, b);
        this.timeline = ke
    };
    x(Wg, Vg);
    Wg.prototype.now = function() {
        return new le(this.I.Date.now(), this.timeline)
    };
    Wg.prototype.fa = function() {
        return !!this.I.Date && !!this.I.Date.now && Vg.prototype.fa.call(this)
    };
    var Xg = function(a, b) {
        Vg.call(this, a, b);
        this.timeline = je
    };
    x(Xg, Vg);
    Xg.prototype.now = function() {
        return new le(this.I.performance.now(), this.timeline)
    };
    Xg.prototype.fa = function() {
        return !!this.I.performance && !!this.I.performance.now && Vg.prototype.fa.call(this)
    };
    var Yg = function(a) {
        this.context = a
    };
    Yg.prototype.K = function() {
        return !Zg(this.context) && !!this.context.global.fetch
    };
    Yg.prototype.ping = function() {
        var a = this;
        return td.apply(null, u(y.apply(0, arguments).map(function(b) {
            return hd(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(P(function(c) {
                return 200 === c.status
            }))
        }))).g(af(function(b) {
            return b
        }), kf())
    };
    Yg.prototype.sd = function(a, b, c) {
        for (var d = y.apply(3, arguments), e = this, f = new Headers, g = t(b.entries()), k = g.next(); !k.done; k = g.next()) {
            var h = t(k.value);
            k = h.next().value;
            h = h.next().value;
            f.set(k, h)
        }
        var l, m = null != (l = a.cg) ? l : !1;
        td.apply(null, u(d.map(function(r) {
            return hd(e.context.global.fetch(r, Object.assign({}, {
                method: String(a.Bb),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(P(function(q) {
                return 200 === q.status
            }))
        }))).g(af(function(r) {
            return r
        }), kf())
    };
    var $g = function(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    };
    var ah = function(a) {
        ah[" "](a);
        return a
    };
    ah[" "] = function() {};
    var bh = function(a, b) {
        try {
            return ah(a[b]), !0
        } catch (c) {}
        return !1
    };
    var ch = Kb(),
        dh = Lb(),
        eh = H("Edge"),
        fh = H("Gecko") && !(ub(Fb(), "WebKit") && !H("Edge")) && !(H("Trident") || H("MSIE")) && !H("Edge"),
        gh = ub(Fb(), "WebKit") && !H("Edge"),
        hh = function() {
            var a = Ja.document;
            return a ? a.documentMode : void 0
        },
        ih;
    a: {
        var jh = "",
            kh = function() {
                var a = Fb();
                if (fh) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (eh) return /Edge\/([\d\.]+)/.exec(a);
                if (dh) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (gh) return /WebKit\/(\S+)/.exec(a);
                if (ch) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();kh && (jh = kh ? kh[1] : "");
        if (dh) {
            var lh = hh();
            if (null != lh && lh > parseFloat(jh)) {
                ih = String(lh);
                break a
            }
        }
        ih = jh
    }
    var mh = ih,
        nh;
    if (Ja.document && dh) {
        var oh = hh();
        nh = oh ? oh : parseInt(mh, 10) || void 0
    } else nh = void 0;
    var ph = nh;
    var qh = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    n = qh.prototype;
    n.clone = function() {
        return new qh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof qh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof qh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), "number" === typeof b && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= "number" === typeof b ? b : a;
        return this
    };
    var rh = function(a, b) {
        this.width = a;
        this.height = b
    };
    n = rh.prototype;
    n.clone = function() {
        return new rh(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.ld = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= "number" === typeof b ? b : a;
        return this
    };
    var uh = function(a) {
            return a ? new sh(th(a)) : Wa || (Wa = new sh)
        },
        vh = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : gh || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
            a = a.parentWindow || a.defaultView;
            return dh && a.pageYOffset != b.scrollTop ? new qh(b.scrollLeft, b.scrollTop) : new qh(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
        },
        wh = function(a, b, c) {
            function d(k) {
                k && b.appendChild("string" === typeof k ? a.createTextNode(k) : k)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Ma(f) ||
                    Na(f) && 0 < f.nodeType) d(f);
                else {
                    a: {
                        if (f && "number" == typeof f.length) {
                            if (Na(f)) {
                                var g = "function" == typeof f.item || "string" == typeof f.item;
                                break a
                            }
                            if ("function" === typeof f) {
                                g = "function" == typeof f.item;
                                break a
                            }
                        }
                        g = !1
                    }
                    gb(g ? mb(f) : f, d)
                }
            }
        },
        th = function(a) {
            z(a, "Node cannot be null or undefined.");
            return 9 == a.nodeType ? a : a.ownerDocument || a.document
        },
        xh = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                z("parentNode" != a.name);
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        sh = function(a) {
            this.Gb = a || Ja.document ||
                document
        };
    n = sh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.Gb).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.Gb;
        a = String(a);
        "application/xhtml+xml" === b.contentType && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.Gb.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        z(null != a && null != b, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        wh(th(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    var zh = function() {
            return Db && Gb ? Gb.mobile : !yh() && (H("iPod") || H("iPhone") || H("Android") || H("IEMobile"))
        },
        yh = function() {
            return Db && Gb ? !Gb.mobile && (H("iPad") || H("Android") || H("Silk")) : H("iPad") || H("Android") && !H("Mobile") || H("Silk")
        };
    var Ah = function(a) {
        try {
            return !!a && null != a.location.href && bh(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var Bh = function(a) {
        this.context = a
    };
    Bh.prototype.K = function(a) {
        return (null == a ? 0 : a.Qc) || "POST" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Fb) || (null == a ? 0 : a.ce) || (null == a ? 0 : a.cg) ? !1 : !Zg(this.context)
    };
    Bh.prototype.ping = function() {
        var a = this;
        return N(y.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = void 0 === d ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    Bh.prototype.sd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Ch(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Dh = function(a) {
        this.context = a
    };
    Dh.prototype.K = function(a) {
        return Eh && !Zg(this.context) && void 0 !== Ch(this.context) && !(null == a ? 0 : a.Qc) && "POST" !== (null == a ? void 0 : a.Bb) && !(null == a ? 0 : a.Fb) && !(null == a ? 0 : a.ce)
    };
    Dh.prototype.T = function(a, b) {
        if (!this.K(b)) throw new Yd;
        return new Fh(this.context, a)
    };
    var Eh = !1,
        Fh = function(a, b) {
            this.context = a;
            this.Ze = b;
            a = Ch(this.context);
            if (void 0 === a) throw Error();
            this.ef = new a(Gh(this), {})
        },
        Gh = function(a) {
            a = a.Ze;
            return ("&" === a.slice(-1)[0] ? a : a + "&") + "pbapi=1"
        };
    Fh.prototype.deactivate = function() {
        this.ef.deactivate()
    };
    Fh.prototype.sendNow = function() {
        this.ef.sendNow()
    };
    da.Object.defineProperties(Fh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ze
            },
            set: function(a) {
                this.Ze = a;
                this.ef.setURL(Gh(this))
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if ("GET" !== a) throw new Yd;
            }
        }
    });
    var Hh = function(a) {
        this.context = a
    };
    Hh.prototype.K = function(a) {
        if ((null == a ? 0 : a.Qc) || "GET" === (null == a ? void 0 : a.Bb) || (null == a ? 0 : a.Fb) || (null == a ? 0 : a.ce) || (null == a ? 0 : a.cg)) return !1;
        var b;
        return !Zg(this.context) && void 0 !== (null == (b = this.context.global.navigator) ? void 0 : b.sendBeacon)
    };
    Hh.prototype.ping = function() {
        var a = this;
        return N(y.apply(0, arguments).map(function(b) {
            var c;
            return null == (c = a.context.global.navigator) ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Hh.prototype.sd = function(a, b, c) {
        this.ping.apply(this, u(y.apply(3, arguments)))
    };

    function Ih(a) {
        return function(b) {
            return b.g(Jh(a, rf(new M)))
        }
    }

    function Y(a, b) {
        return function(c) {
            return c.g(Jh(a, wf(b)))
        }
    }

    function Jh(a, b) {
        function c(d) {
            return new L(function(e) {
                return d.subscribe(function(f) {
                    Ta(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Ta(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Ta(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return K(c, Bf(), b, Dc(), c)
    };
    var Z = function(a) {
        this.value = a
    };
    Z.prototype.O = function(a) {
        return N(this.value).g(Y(a, 1))
    };
    var Kh = new Z(!1);
    Ob();
    Nb();
    Mb();
    var Lh = {},
        Mh = null,
        Nh = fh || gh || "function" == typeof Ja.btoa,
        Ph = function(a) {
            var b;
            z(Ma(a), "encodeByteArray takes an array as a parameter");
            void 0 === b && (b = 0);
            Oh();
            b = Lh[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    k = a[e + 1],
                    h = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | k >> 4];
                k = b[(k & 15) << 2 | h >> 6];
                h = b[h & 63];
                c[f++] = "" + l + g + k + h
            }
            l = 0;
            h = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], h = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + h + d
            }
            return c.join("")
        },
        Th = function(a) {
            var b =
                a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : -1 != "=.".indexOf(a[b - 1]) && (c = -1 != "=.".indexOf(a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Qh(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Qh = function(a, b) {
            function c(h) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Mh[l];
                    if (null != m) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("S`" + l);
                }
                return h
            }
            Oh();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    k = c(64);
                if (64 === k && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != k && b(g << 6 & 192 | k))
            }
        },
        Oh = function() {
            if (!Mh) {
                Mh = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    Lh[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e],
                            g = Mh[f];
                        void 0 === g ? Mh[f] = e : z(g === e)
                    }
                }
            }
        };

    function Uh(a) {
        var b = Vh(a);
        return null === b ? new Z(null) : b.g(P(function(c) {
            c = c.hb();
            if (Nh) c = Ja.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (255 < g) throw Error("R");
                    d[e++] = g
                }
                c = Ph(d)
            }
            return c
        }), Te(1), Y(a.h, 1))
    };

    function Wh(a) {
        var b = void 0 === b ? {} : b;
        if ("function" === typeof Event) return new Event(a, b);
        if ("undefined" !== typeof document) {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var Xh = function(a) {
        this.value = a;
        this.Qe = new M
    };
    Xh.prototype.release = function() {
        this.Qe.next();
        this.Qe.complete();
        this.value = void 0
    };
    da.Object.defineProperties(Xh.prototype, {
        j: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Qe
            }
        }
    });
    var Yh = ["FRAME", "IMG", "IFRAME"],
        Zh = /^[01](px)?$/;

    function $h(a) {
        return "string" === typeof a ? document.getElementById(a) : a
    }

    function ai(a, b) {
        var c = !0,
            d = !0,
            e = void 0,
            f = !0;
        c = void 0 === c ? !0 : c;
        d = void 0 === d ? !1 : d;
        f = void 0 === f ? !1 : f;
        var g = void 0 === g ? !1 : g;
        if (a = $h(a)) {
            e || (e = function(ia, E, B) {
                ia.addEventListener(E, B)
            });
            for (var k = !1, h = function(ia) {
                    k || (k = !0, b(ia))
                }, l, m, r = 0; r < Yh.length; ++r)
                if (Yh[r] == a.tagName) {
                    m = 3;
                    l = [a];
                    break
                }
            l || (l = a.querySelectorAll(Yh.join(",")), m = 2);
            var q = 0,
                v = 0,
                w = !g,
                A = a = !1;
            r = {};
            for (var D = 0; D < l.length; r = {
                    md: void 0
                }, D++) {
                var C = l[D];
                if (!("IMG" == C.tagName && (C.complete && (!C.naturalWidth || !C.naturalHeight) || (void 0 === g ? 0 :
                        g) && C.style && "none" === C.style.display) || Zh.test(C.getAttribute("width")) && Zh.test(C.getAttribute("height")))) {
                    r.md = "IMG" === C.tagName;
                    if ("IMG" == C.tagName) var R = C.naturalWidth && C.naturalHeight ? !0 : !1;
                    else try {
                        R = "complete" === (C.readyState ? C.readyState : C.contentWindow && C.contentWindow.document && C.contentWindow.document.readyState) ? !0 : !1
                    } catch (ia) {
                        R = void 0 === d ? !1 : d
                    }
                    if (R) a = !0, r.md && (w = !0);
                    else {
                        q++;
                        var pa = function(ia) {
                            return function(E) {
                                q--;
                                !q && w && h(m);
                                ia.md && (E = E && "error" === E.type, v--, E || (w = !0), !v && A && w &&
                                    h(m))
                            }
                        }(r);
                        e(C, "load", pa);
                        r.md && (v++, e(C, "error", pa))
                    }
                }
            }
            0 === v && (w = !0);
            l = null;
            if (0 === q && !a && "complete" === Ja.document.readyState) m = 5;
            else if (q || !a) {
                e(Ja, "load", function() {
                    !f || !v && w ? h(4) : A = !0
                });
                return
            }
            c && h(m)
        }
    };

    function bi(a, b, c) {
        if (a)
            for (var d = 0; null != a && 500 > d && !c(a); ++d) a = b(a)
    }

    function ci(a, b) {
        bi(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function di(a, b) {
        if ("IFRAME" == a.tagName) b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function ei(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function fi(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if ("object" === typeof d && d && "creativeLoad" === d.type) {
            var e = ei(a);
            if (c.source && e) {
                var f;
                ci(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (k) {}
                });
                f && di(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function gi(a) {
        return "string" === typeof a ? document.getElementById(a) : a
    }
    var hi = function(a, b) {
        var c = gi(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (k) {}
                        d = {
                            push: function(k) {
                                k(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ja.addEventListener("message", function(f) {
                    fi(c, e, f)
                })
            }
    };
    var ii = function(a, b) {
            var c = this;
            this.global = a;
            this.rd = b;
            this.vi = this.document ? td(N(!0), nd(this.document, "visibilitychange")).g(Sg(this.rd.B, 748), P(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), V()) : N("visible");
            this.si = this.document ? nd(this.document, "DOMContentLoaded").g(Sg(this.rd.B, 739), Te(1)) : N(Wh("DOMContentLoaded"))
        },
        ji = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        ki = function(a) {
            return null !== a.document && void 0 !== a.document.visibilityState
        };
    ii.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    ii.prototype.querySelectorAll = function(a) {
        return this.document ? mb(this.document.querySelectorAll(a)) : []
    };
    var li = function(a) {
        return null !== a.document && "function" === typeof a.document.elementFromPoint
    };
    ii.prototype.elementFromPoint = function(a, b) {
        if (!this.document || !li(this)) return null;
        a = this.document.elementFromPoint(a, b);
        return null === a ? null : new Xh(a)
    };
    var mi = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            if (void 0 === b.j || !a.document) return N(b).g(Sg(a.rd.B, 749));
            var d = new zc(1),
                e = function() {
                    d.next(b)
                };
            c || hi(b.j, e);
            ai(b.j, e);
            return d.g(Sg(a.rd.B, 749), Te(1))
        },
        ni = function(a, b, c) {
            var d, e, f;
            return Ba(function(g) {
                if (1 == g.ka) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(h) {
                        d.onload = h;
                        d.onerror = h
                    });
                    if (b instanceof sb && b.constructor === sb) var k = b.lg;
                    else $a("expected object of type TrustedResourceUrl, got '%s' of type %s", b, La(b)), k = "type_error:TrustedResourceUrl";
                    d.src = k.toString();
                    a.document && a.document.body.appendChild(d);
                    d.style.display = "none";
                    return ta(g, e, 2)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    da.Object.defineProperties(ii.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return bh(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var oi = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function pi(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function qi(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function ri(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };
    var si = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    n = si.prototype;
    n.me = function() {
        return this.right - this.left
    };
    n.ke = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new si(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof si ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        Na(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof qh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (ab(a), this.left += a, this.right += a, "number" === typeof b && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = "number" === typeof b ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function ti(a, b) {
        if (a) throw Error("T");
        b.push(65533)
    }

    function ui(a, b) {
        b = String.fromCharCode.apply(null, b);
        return null == a ? b : a + b
    }
    var vi = void 0,
        wi, xi, yi = "undefined" !== typeof TextDecoder;
    var zi = "undefined" !== typeof Uint8Array,
        Ai = !dh && "function" === typeof btoa;

    function Bi(a) {
        if (!Ai) return Ph(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    var Ci = /[-_.]/g,
        Di = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Ei(a) {
        return Di[a] || ""
    }

    function Fi(a) {
        if (!Ai) return Th(a);
        var b = a;
        Ci.test(b) && (b = b.replace(Ci, Ei));
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("U`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Gi, Hi = {};
    var Ii, Ki = function(a, b) {
        if (b !== Hi) throw Error("V");
        this.Jc = a;
        if (null != a && 0 === a.length) throw Error("W");
        this.dontPassByteStringToStructuredClone = Ji
    };
    Ki.prototype.ld = function() {
        return null == this.Jc
    };

    function Ji() {};

    function Li(a) {
        return Array.prototype.slice.call(a)
    };

    function Mi(a, b) {
        return "function" === typeof Symbol && "symbol" === typeof Symbol() ? Symbol(a) : b
    }
    var Ni = Mi("INTERNAL_ARRAY_STATE"),
        Oi = Mi("defaultInstance", "0di");
    z(13 === Math.round(Math.log2(Math.max.apply(Math, u(Object.values({
        Cj: 1,
        Aj: 2,
        zj: 4,
        Gj: 8,
        Fj: 16,
        Ej: 32,
        nj: 64,
        Jj: 128,
        yj: 256,
        xj: 512,
        Bj: 1024,
        rj: 2048,
        Ij: 4096,
        sj: 8192
    }))))));

    function Pi(a) {
        z((a & 16777215) == a)
    }
    var Qi = Ni ? function(a, b) {
        Pi(b);
        F(a, "state is only maintained on arrays.");
        a[Ni] |= b
    } : function(a, b) {
        Pi(b);
        F(a, "state is only maintained on arrays.");
        void 0 !== a.ra ? a.ra |= b : Object.defineProperties(a, {
            ra: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };

    function Ri(a) {
        var b = Si(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Li(a)), Ti(a, b | 1))
    }
    var Ui = Ni ? function(a, b) {
        Pi(b);
        F(a, "state is only maintained on arrays.");
        a[Ni] &= ~b
    } : function(a, b) {
        Pi(b);
        F(a, "state is only maintained on arrays.");
        void 0 !== a.ra && (a.ra &= ~b)
    };

    function Vi(a, b, c) {
        return c ? a | b : a & ~b
    }
    var Wi = Object.getOwnPropertyDescriptor(Array.prototype, "Xh");
    Object.defineProperties(Array.prototype, {
        Xh: {
            get: function() {
                function a(e, f) {
                    e & b && c.push(f)
                }
                var b = Si(this),
                    c = [];
                a(1, "IS_REPEATED_FIELD");
                a(2, "IS_IMMUTABLE_ARRAY");
                a(4, "IS_API_FORMATTED");
                a(4096, "STRING_FORMATTED");
                a(8192, "GBIGINT_FORMATTED");
                a(8, "ONLY_MUTABLE_VALUES");
                a(32, "MUTABLE_REFERENCES_ARE_OWNED");
                a(64, "CONSTRUCTED");
                a(128, "TRANSFERRED");
                a(256, "HAS_SPARSE_OBJECT");
                a(512, "HAS_MESSAGE_ID");
                a(2048, "FROZEN_ARRAY");
                var d = Xi(b);
                536870912 !== d && c.push("pivot: " + d);
                d = c.join(",");
                return Wi ? Wi.get.call(this) +
                    "|" + d : d
            },
            configurable: !0,
            enumerable: !1
        }
    });
    var Si = Ni ? function(a) {
        F(a, "state is only maintained on arrays.");
        return a[Ni] | 0
    } : function(a) {
        F(a, "state is only maintained on arrays.");
        return a.ra | 0
    };

    function Yi(a, b) {
        z(b & 64, "state for messages must be constructed");
        z(0 === (b & 5), "state for messages should not contain repeated field state");
        var c = Xi(b),
            d = a.length;
        z(c + (+!!(b & 512) - 1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
        b & 512 && z("string" === typeof a[0], "arrays with a message_id bit must have a string in the first position, got: %s", a[0]);
        a = d ? a[d - 1] : void 0;
        z((null != a && "object" === typeof a && a.constructor === Object) === !!(b & 256), "arraystate and array disagree on sparseObject presence")
    }
    var Zi = Ni ? function(a) {
            F(a, "state is only maintained on arrays.");
            var b = a[Ni];
            Yi(a, b);
            return b
        } : function(a) {
            F(a, "state is only maintained on arrays.");
            var b = a.ra;
            Yi(a, b);
            return b
        },
        Ti = Ni ? function(a, b) {
            F(a, "state is only maintained on arrays.");
            Pi(b);
            a[Ni] = b
        } : function(a, b) {
            F(a, "state is only maintained on arrays.");
            Pi(b);
            void 0 !== a.ra ? a.ra = b : Object.defineProperties(a, {
                ra: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };

    function $i() {
        var a = [];
        Qi(a, 1);
        return a
    }

    function aj(a) {
        return !!(Si(a) & 2)
    }

    function bj(a, b) {
        Ti(b, (a | 0) & -14591)
    }

    function cj(a, b) {
        Ti(b, (a | 34) & -14557)
    }

    function dj(a, b) {
        ab(b);
        z(0 < b && 1023 >= b || 536870912 === b);
        return a & -16760833 | (b & 1023) << 14
    }

    function Xi(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var ej, fj = {};

    function gj(a) {
        var b = a.gi === fj;
        z(!ej || b === a instanceof ej);
        return b
    }
    var hj = {};

    function ij(a) {
        var b = !(!a || "object" !== typeof a || a.Tj !== hj);
        z(b === a instanceof Map);
        return b && 0 === fb(a, Map).size
    }

    function jj(a, b) {
        ab(a);
        z(0 < a);
        z(0 === b || -1 === b);
        return a + b
    }

    function kj(a, b) {
        ab(a);
        z(0 <= a);
        z(0 === b || -1 === b);
        return a - b
    }

    function lj(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    var mj, nj = !Eb;

    function oj(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = Si(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        Ti(a, d | 1);
        return !0
    }
    var pj, qj = [];
    Ti(qj, 55);
    pj = Object.freeze(qj);

    function rj(a) {
        if (a & 2) throw Error("X");
    }
    var sj = "undefined" != typeof Symbol && "undefined" != typeof Symbol.hasInstance;

    function tj() {}
    var uj;

    function vj(a, b) {
        F(a);
        if (b) {
            uj || (uj = Symbol("unknownBinaryFields"));
            var c = a[uj];
            c ? c.push(b) : a[uj] = [b]
        }
    }

    function wj(a, b) {
        F(a);
        F(b);
        (b = uj ? F(b)[uj] : void 0) && (a[uj] = Li(b))
    }
    var xj, yj;

    function zj() {
        return yj || (yj = Symbol("JSPB_COMPARISON_TYPE_INFO"))
    }

    function Aj(a, b) {
        var c = Si(F(a));
        b || z(!(c & 2 && c & 4 || c & 2048) || Object.isFrozen(a));
        b = !!(c & 8);
        c = !!(c & 16 && c & 32);
        if (b || c) {
            var d, e, f;
            a.forEach(function(g) {
                Array.isArray(g) ? f = !0 : g && gj(g) && (aj(g.u) ? e = !0 : d = !0)
            });
            f && z(!e && !d);
            c && z(!f && !d);
            b && z(!f && !e)
        }
        Bj(a)
    }

    function Bj(a) {
        var b = Si(a),
            c = b & 4,
            d = (4096 & b ? 1 : 0) + (8192 & b ? 1 : 0);
        z(c && 1 >= d || !c && 0 === d, "Expected at most 1 type-specific formatting bit, but got " + d + " with state: " + b);
        if (4096 & Si(a))
            for (b = 0; b < a.length; b++) "string" !== typeof a[b] && $a("Unexpected element of type " + typeof a[b] + " in string formatted repeated 64-bit int field")
    }
    var Cj = Object.freeze(new function() {});
    Object.freeze(new function() {});
    var Dj = "function" === typeof Uint8Array.prototype.slice,
        Ej = 0,
        Fj = 0;

    function Gj(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = t(Hj(c, a)), b = c.next().value, a = c.next().value, c = b);
        Ej = c >>> 0;
        Fj = a >>> 0
    }

    function Ij() {
        var a = Ej,
            b = Fj;
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else "function" === typeof BigInt ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), z(b), c = b + Jj(c) + Jj(a));
        return c
    }

    function Jj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function Hj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function Kj(a) {
        a = Error(a);
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = "warning";
        return a
    };

    function Lj(a) {
        if (null == a || "number" === typeof a) return a;
        if ("NaN" === a || "Infinity" === a || "-Infinity" === a) return Number(a)
    }

    function Mj(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function Nj(a) {
        if ("boolean" !== typeof a) throw Error("Y`" + La(a) + "`" + a);
        return a
    }

    function Oj(a) {
        if (null == a || "boolean" === typeof a) return a;
        if ("number" === typeof a) return !!a
    }
    var Pj = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Qj(a) {
        var b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : Pj.test(a)
    }

    function Rj(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function Sj(a) {
        return "Expected uint32 as finite number but got " + La(a) + ": " + a
    }

    function Tj(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function Uj(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    }

    function Vj(a) {
        z(0 > a || !(0 < a && a < Number.MAX_SAFE_INTEGER));
        z(Number.isInteger(a));
        if (0 > a) {
            Gj(a);
            var b = Ij();
            a = Number(b);
            return Number.isSafeInteger(a) ? a : b
        }
        if (Uj(String(a))) return a;
        Gj(a);
        return 4294967296 * Fj + (Ej >>> 0)
    }

    function Wj(a) {
        if (null == a) return a;
        if (Qj(a)) {
            if ("string" === typeof a) {
                z(Qj(a));
                z(!0);
                var b = Math.trunc(Number(a));
                if (Number.isSafeInteger(b) && 0 <= b) a = String(b);
                else if (b = a.indexOf("."), -1 !== b && (a = a.substring(0, b)), z(-1 === a.indexOf(".")), !Uj(a)) {
                    z(0 < a.length);
                    if (16 > a.length) Gj(Number(a));
                    else if ("function" === typeof BigInt) a = BigInt(a), Ej = Number(a & BigInt(4294967295)) >>> 0, Fj = Number(a >> BigInt(32) & BigInt(4294967295));
                    else {
                        z(0 < a.length);
                        b = +("-" === a[0]);
                        Fj = Ej = 0;
                        for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e,
                            e += 6) d = Number(a.slice(d, e)), Fj *= 1E6, Ej = 1E6 * Ej + d, 4294967296 <= Ej && (Fj += Math.trunc(Ej / 4294967296), Fj >>>= 0, Ej >>>= 0);
                        b && (b = t(Hj(Ej, Fj)), a = b.next().value, b = b.next().value, Ej = a, Fj = b)
                    }
                    a = Ij()
                }
                return a
            }
            if ("number" === typeof a) return z(Qj(a)), z(!0), a = Math.trunc(a), 0 <= a && Number.isSafeInteger(a) ? a : Vj(a)
        }
    }

    function Xj(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Yj(a, b, c) {
        if (null != a && "object" === typeof a && gj(a)) return a;
        if (Array.isArray(a)) {
            var d = Si(a),
                e = d;
            0 === e && (e |= c & 32);
            e |= c & 2;
            e !== d && Ti(a, e);
            return new b(a)
        }
    };
    var Zj = function() {
        throw Error("aa");
    };
    if (sj) {
        var ak = function() {
                throw Error("ba");
            },
            bk = {};
        Object.defineProperties(Zj, (bk[Symbol.hasInstance] = {
            value: ak,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, bk));
        z(Zj[Symbol.hasInstance] === ak, "defineProperties did not work: was it monkey-patched?")
    };
    var ck;

    function dk(a, b) {
        z(!!(Si(b) & 32));
        ck = b;
        a = new a(b);
        ck = void 0;
        return a
    }
    var ek, fk;

    function gk(a) {
        switch (typeof a) {
            case "boolean":
                return ek || (ek = [0, void 0, !0]);
            case "number":
                return 0 < a ? void 0 : 0 === a ? fk || (fk = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return F(a), z(2 === a.length || 3 === a.length && !0 === a[2]), z(null == a[0] || "number" === typeof a[0] && 0 <= a[0]), z(null == a[1] || "string" === typeof a[1]), a
        }
    }

    function hk(a, b) {
        F(b);
        return ik(a, b[0], b[1])
    }

    function ik(a, b, c) {
        null == a && (a = ck);
        ck = void 0;
        if (null != a)
            for (var d = 0; d < a.length; d++) {
                var e = a[d];
                Array.isArray(e) && Aj(e)
            }
        if (null == a) e = 96, c ? (a = [c], e |= 512) : a = [], b && (e = dj(e, b));
        else {
            if (!Array.isArray(a)) throw Error("ca`" + JSON.stringify(a) + "`" + La(a));
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("da");
            e = Si(a);
            if (e & 64) return Yi(a, e), yj && delete a[yj], a;
            e |= 64;
            if (c && (e |= 512, c !== a[0])) throw Error("ea`" + c + "`" + JSON.stringify(a[0]) + "`" + La(a[0]));
            a: {
                d = a;c = e;
                if (e = d.length) {
                    var f =
                        e - 1;
                    if (lj(d[f])) {
                        c |= 256;
                        b = kj(f, +!!(c & 512) - 1);
                        if (1024 <= b) throw Error("fa`" + b);
                        e = dj(c, b);
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, kj(e, +!!(c & 512) - 1));
                    if (1024 < b) throw Error("ga`" + e);
                    e = dj(c, b)
                } else e = c
            }
        }
        Ti(a, e);
        z(e & 64);
        return a
    };

    function jk(a, b) {
        return kk(b)
    }

    function kk(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return nj || !oj(a, void 0, 9999) ? a : void 0;
                    if (zi && null != a && a instanceof Uint8Array) return Bi(a);
                    if (a instanceof Ki) {
                        var b = a.Jc;
                        return null == b ? "" : "string" === typeof b ? b : a.Jc = Bi(b)
                    }
                }
        }
        return a
    };

    function lk(a, b, c) {
        var d = Li(a),
            e = d.length,
            f = b & 256 ? d[e - 1] : void 0;
        e += f ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < e; b++) d[b] = c(d[b]);
        if (f) {
            b = d[b] = {};
            for (var g in f) z(!isNaN(g), "should not have non-numeric keys in sparse objects after a constructor is called."), b[g] = c(f[g])
        }
        wj(d, a);
        return d
    }

    function mk(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Si(a) & 1 ? void 0 : f && Si(a) & 2 ? a : nk(a, b, c, void 0 !== d, e, f);
            else if (lj(a)) {
                var g = {},
                    k;
                for (k in a) g[k] = mk(a[k], b, c, d, e, f);
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function nk(a, b, c, d, e, f) {
        var g = d || c ? Si(a) : 0;
        d = d ? !!(g & 32) : void 0;
        for (var k = Li(a), h = 0; h < k.length; h++) k[h] = mk(k[h], b, c, d, e, f);
        c && (wj(k, a), c(g, k));
        return k
    }

    function ok(a) {
        return gj(a) ? a.toJSON() : kk(a)
    };

    function pk(a, b, c) {
        c = void 0 === c ? cj : c;
        if (null != a) {
            if (zi && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Si(a);
                if (d & 2) return a;
                Aj(a);
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Ti(a, (d | 34) & -12293), a) : nk(a, pk, d & 4 ? cj : c, !0, !1, !0)
            }
            gj(a) && (z(gj(a)), c = a.u, d = Zi(c), a = d & 2 ? a : dk(a.constructor, qk(c, d, !0)));
            return a
        }
    }

    function qk(a, b, c) {
        var d = c || b & 2 ? cj : bj,
            e = !!(b & 32);
        a = lk(a, b, function(f) {
            return pk(f, e, d)
        });
        Qi(a, 32 | (c ? 2 : 0));
        return a
    }

    function rk(a) {
        var b = a.u,
            c = Zi(b);
        return c & 2 ? dk(a.constructor, qk(b, c, !1)) : a
    };
    var tk = function(a, b) {
            a = a.u;
            return sk(a, Zi(a), b)
        },
        sk = function(a, b, c, d) {
            if (-1 === c) return null;
            if (c >= Xi(b)) {
                if (b & 256) return a[a.length - 1][c]
            } else {
                var e = a.length;
                if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
                b = jj(c, +!!(b & 512) - 1);
                if (b < e) return a[b]
            }
        },
        vk = function(a, b, c) {
            var d = a.u,
                e = Zi(d);
            rj(e);
            uk(d, e, b, c);
            return a
        };

    function uk(a, b, c, d) {
        z(!lj(d), "Invalid object passed to a setter");
        var e = Xi(b);
        if (c >= e) {
            z(536870912 !== e);
            var f = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return;
                e = jj(e, +!!(b & 512) - 1);
                z(e >= a.length && Number.isInteger(e) && 4294967295 > e, "Expected sparseObjectIndex (%s) to be >= %s and a valid array index", e, a.length);
                e = a[e] = {};
                f |= 256
            }
            e[c] = d;
            f !== b && Ti(a, f)
        } else a[jj(c, +!!(b & 512) - 1)] = d, b & 256 && (a = a[a.length - 1], c in a && delete a[c])
    }
    var xk = function(a, b, c, d) {
        return void 0 !== wk(a, b, c, void 0 === d ? !1 : d)
    };

    function yk(a, b) {
        if (!a) return a;
        z(aj(b) ? aj(a.u) : !0);
        return a
    }

    function zk(a, b, c, d) {
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? !1 : d;
        Aj(a, c);
        z(!!(Si(a) & 1));
        c || (d || z(Object.isFrozen(a) || !(Si(a) & 32)), z(aj(b) ? Object.isFrozen(a) : !0));
        return a
    }

    function Ak(a, b, c, d, e) {
        z((d & 3) === d);
        var f = b & 2;
        e = sk(a, b, c, e);
        Array.isArray(e) || (e = pj);
        var g = !(d & 2);
        d = !(d & 1);
        var k = !!(b & 32),
            h = Si(e);
        0 !== h || !k || f || g ? h & 1 || (h |= 1, Ti(e, h)) : (h |= 33, Ti(e, h));
        f ? (a = !1, h & 2 || (Qi(e, 34), a = !!(4 & h)), (d || a) && Object.freeze(e)) : (f = !!(2 & h) || !!(2048 & h), d && f ? (e = Li(e), f = 1, k && !g && (f |= 32), Ti(e, f), uk(a, b, c, e)) : g && h & 32 && !f && Ui(e, 32));
        return e
    }
    var Bk = function(a, b) {
            var c = void 0 === c ? !1 : c;
            return zk(Ak(a, Zi(a), b, 2, c), a, !1, !0)
        },
        Ck = function(a, b, c, d) {
            var e = Zi(a);
            rj(e);
            d = sk(a, e, c, d);
            if (null != d && gj(d)) return b = rk(d), b !== d && uk(a, e, c, b), b.u;
            if (Array.isArray(d)) {
                var f = Si(d);
                f = f & 2 ? qk(d, f, !1) : d;
                f = hk(f, b)
            } else f = hk(void 0, b);
            f !== d && uk(a, e, c, f);
            return f
        },
        wk = function(a, b, c, d) {
            a = a.u;
            var e = Zi(a);
            d = sk(a, e, c, d);
            b = Yj(d, b, e);
            b !== d && null != b && uk(a, e, c, b);
            return yk(b, a)
        },
        Ek = function(a) {
            var b = Dk;
            (a = wk(a, b, 2, !1)) ? b = a: (a = b[Oi]) ? b = a : (a = new b, Qi(a.u, 34), b = b[Oi] = a);
            return b
        },
        Fk = function(a, b, c) {
            b = wk(a, b, c, !1);
            if (null == b) return b;
            a = a.u;
            var d = Zi(a);
            if (!(d & 2)) {
                var e = rk(b);
                e !== b && (b = e, uk(a, d, c, b))
            }
            return yk(b, a)
        },
        Ik = function(a) {
            var b = Gk;
            a = a.u;
            var c = Zi(a),
                d;
            var e = !!e;
            d && (d = !(2 & c));
            var f = sk(a, c, 10);
            f = Array.isArray(f) ? f : pj;
            var g = Si(f),
                k = !!(4 & g);
            if (!k) {
                var h = g;
                0 === h && (h = Hk(h, c, e));
                h = Vi(h, 1, !0);
                g = f;
                var l = c,
                    m;
                (m = !!(2 & h)) && (l = Vi(l, 2, !0));
                for (var r = !m, q = !0, v = 0, w = 0; v < g.length; v++) {
                    var A = Yj(g[v], b, l);
                    if (A instanceof b) {
                        if (!m) {
                            var D = aj(A.u);
                            r && (r = !D);
                            q && (q = D)
                        }
                        g[w++] = A
                    }
                }
                w < v && (g.length =
                    w);
                h = Vi(h, 4, !0);
                h = Vi(h, 16, q);
                h = Vi(h, 8, r);
                Ti(g, h);
                m && Object.freeze(g);
                g = h
            }
            b = !!(8 & g) || !f.length;
            if (d && !b) {
                if (2 & g && 4 & g || 2048 & g) f = Li(f), g = Hk(g, c, e), uk(a, c, 10, f);
                d = f;
                b = g;
                for (c = 0; c < d.length; c++) g = d[c], h = rk(g), g !== h && (d[c] = h);
                b = Vi(b, 8, !0);
                b = Vi(b, 16, !d.length);
                Ti(d, b);
                g = b
            }
            2 & g && 4 & g || 2048 & g || (d = g, g = Vi(g, !f.length || 16 & g && (!k || 32 & g) ? 2 : 2048, !0), g !== d && Ti(f, g), Object.freeze(f));
            if (e) a = f;
            else {
                e = f;
                f = !1;
                f = void 0 === f ? !1 : f;
                k = aj(a);
                d = aj(e);
                b = Object.isFrozen(e) && d;
                zk(e, a, f);
                if (k || d) f ? z(d) : z(b);
                z(!!(Si(e) & 4));
                if (d && e.length)
                    for (f =
                        0; 1 > f; f++) yk(e[f], a);
                a = e
            }
            return a
        };

    function Hk(a, b, c) {
        a = Vi(a, 2, !!(2 & b));
        a = Vi(a, 32, !!(32 & b) && c);
        return a = Vi(a, 2048, !1)
    }

    function Jk(a, b) {
        return null != a ? a : b
    }
    var Kk = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            return Jk(Oj(tk(a, b)), c)
        },
        Lk = function(a, b) {
            var c = void 0 === c ? 0 : c;
            return Jk(Rj(tk(a, b)), c)
        },
        Mk = function(a) {
            var b = void 0 === b ? "" : b;
            return Jk(Xj(tk(a, 2)), b)
        },
        Nk = function(a) {
            a = Oj(tk(a, 5));
            return null == a ? void 0 : a
        },
        Ok = function(a, b) {
            a = Xj(tk(a, b));
            return null == a ? void 0 : a
        },
        Pk = function(a, b) {
            if (null != b) {
                if ("number" !== typeof b) throw Kj(Sj(b));
                if (!Number.isFinite(b)) throw Kj(Sj(b));
                b >>>= 0
            }
            vk(a, 1, b)
        },
        Qk = function(a, b, c) {
            if (null != c && "string" !== typeof c) throw Error("Z`" + c + "`" +
                La(c));
            return vk(a, b, c)
        };
    if ("undefined" !== typeof Proxy) {
        var Sk = Rk;
        new Proxy({}, {
            getPrototypeOf: Sk,
            setPrototypeOf: Sk,
            isExtensible: Sk,
            preventExtensions: Sk,
            getOwnPropertyDescriptor: Sk,
            defineProperty: Sk,
            has: Sk,
            get: Sk,
            set: Sk,
            deleteProperty: Sk,
            apply: Sk,
            construct: Sk
        })
    }

    function Rk() {
        throw Error("ha");
        throw Error();
    };
    var Tk = function(a, b, c) {
        fb(this, Tk, "The message constructor should only be used by subclasses");
        z(this.constructor !== Tk, "Message is an abstract class and cannot be directly constructed");
        this.u = ik(a, b, c);
        this.preventPassingToStructuredClone = tj
    };
    n = Tk.prototype;
    n.toJSON = function() {
        if (mj) var a = Uk(this, this.u, !1);
        else a = this.u, F(a), a = nk(a, ok, void 0, void 0, !1, !1), a = Uk(this, a, !0);
        return a
    };
    n.hb = function() {
        mj = !0;
        try {
            return JSON.stringify(this.toJSON(), jk)
        } finally {
            mj = !1
        }
    };
    n.getExtension = function(a) {
        fb(this, a.xh);
        var b = fb(this, Tk);
        b = a.Eb ? a.Ae ? a.kc(b, a.Eb, a.Ib, void 0 !== Cj ? 1 : 2, !0) : a.kc(b, a.Eb, a.Ib, !0) : a.Ae ? a.kc(b, a.Ib, void 0 !== Cj ? 1 : 2, !0) : a.kc(b, a.Ib, a.defaultValue, !0);
        return a.Sj && null == b ? a.defaultValue : b
    };
    n.hasExtension = function(a) {
        z(!a.Ae, "repeated extensions don't support hasExtension");
        if (a.Eb) a = xk(this, a.Eb, a.Ib, !0);
        else {
            z(!a.Ae, "repeated extensions don't support getExtensionOrUndefined");
            fb(this, a.xh);
            var b = fb(this, Tk);
            a = a.Eb ? a.kc(b, a.Eb, a.Ib, !0) : a.kc(b, a.Ib, null, !0);
            a = void 0 !== (null === a ? void 0 : a)
        }
        return a
    };
    n.clone = function() {
        var a = fb(this, Tk);
        z(gj(a));
        var b = a.u,
            c = Zi(b);
        return dk(a.constructor, qk(b, c, !1))
    };
    n.ob = function() {
        return aj(this.u)
    };
    ej = Tk;
    Tk.prototype.gi = fj;
    Tk.prototype.toString = function() {
        return Uk(this, this.u, !1).toString()
    };

    function Uk(a, b, c) {
        var d = a.constructor.og,
            e = Zi(c ? a.u : b),
            f = Xi(e),
            g = !1;
        if (d && nj) {
            if (!c) {
                b = Li(b);
                var k;
                if (b.length && lj(k = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, k);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            k = Zi(a.u);
            a = Xi(k);
            k = +!!(k & 512) - 1;
            for (var h, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l = jj(l, k);
                    var r = f[l];
                    null == r ? f[l] = c ? pj : $i() : c && r !== pj && Ri(r)
                } else h || (r = void 0, f.length && lj(r = f[f.length - 1]) ? h = r : f.push(h = {})), r = h[l], null == h[l] ? h[l] = c ? pj : $i() : c && r !== pj && Ri(r)
        }
        h = b.length;
        if (!h) return b;
        var q;
        if (lj(f = b[h - 1])) {
            a: {
                var v = f;c = {};a = !1;
                for (var w in v) {
                    k = v[w];
                    if (Array.isArray(k)) {
                        m = k;
                        if (oj(k, d, +w) || ij(k)) k = null;
                        k != m && (a = !0)
                    }
                    null != k ? c[w] = k : a = !0
                }
                if (a) {
                    for (var A in c) {
                        v = c;
                        break a
                    }
                    v = null
                }
            }
            v != f && (q = !0);h--
        }
        for (e = +!!(e & 512) - 1; 0 < h; h--) {
            w = h - 1;
            f = b[w];
            if (null != f && !oj(f, d, w - e) && !ij(f)) break;
            var D = !0
        }
        if (!q && !D) return b;
        b = g ? b : Array.prototype.slice.call(b, 0, h);
        g && (b.length = h);
        v && b.push(v);
        return b
    };

    function Vk(a) {
        if ("string" === typeof a) return {
            buffer: Fi(a),
            ob: !1
        };
        if (Array.isArray(a)) return {
            buffer: new Uint8Array(a),
            ob: !1
        };
        if (a.constructor === Uint8Array) return {
            buffer: a,
            ob: !1
        };
        if (a.constructor === ArrayBuffer) return {
            buffer: new Uint8Array(a),
            ob: !1
        };
        if (a.constructor === Ki) {
            fb(a, Ki);
            if (Hi !== Hi) throw Error("V");
            var b = a.Jc;
            null == b || zi && null != b && b instanceof Uint8Array || ("string" === typeof b ? b = Fi(b) : ($a("Cannot coerce to Uint8Array: " + La(b)), b = null));
            return {
                buffer: (null == b ? b : a.Jc = b) || Gi || (Gi = new Uint8Array(0)),
                ob: !0
            }
        }
        if (a instanceof Uint8Array) return {
            buffer: new Uint8Array(a.buffer, a.byteOffset, a.byteLength),
            ob: !1
        };
        throw Error("sa");
    };
    var Wk = function(a, b) {
        this.ya = null;
        this.Sd = !1;
        this.H = this.za = this.Va = 0;
        this.pc(a, void 0, void 0, b)
    };
    n = Wk.prototype;
    n.pc = function(a, b, c, d) {
        d = void 0 === d ? {} : d;
        this.Pc = void 0 === d.Pc ? !1 : d.Pc;
        a && (a = Vk(a), this.ya = a.buffer, this.Sd = a.ob, this.Va = b || 0, this.za = void 0 !== c ? this.Va + c : this.ya.length, this.H = this.Va)
    };
    n.Hf = function() {
        this.clear();
        100 > Xk.length && Xk.push(this)
    };
    n.clear = function() {
        this.ya = null;
        this.Sd = !1;
        this.H = this.za = this.Va = 0;
        this.Pc = !1
    };
    n.setEnd = function(a) {
        this.za = a
    };
    n.reset = function() {
        this.H = this.Va
    };
    n.W = function() {
        return this.H
    };
    n.advance = function(a) {
        Yk(this, this.H + a)
    };
    var Zk = function(a) {
            var b = 0,
                c = 0,
                d = 0,
                e = a.ya,
                f = a.H;
            do {
                var g = e[f++];
                b |= (g & 127) << d;
                d += 7
            } while (32 > d && g & 128);
            32 < d && (c |= (g & 127) >> 4);
            for (d = 3; 32 > d && g & 128; d += 7) g = e[f++], c |= (g & 127) << d;
            Yk(a, f);
            if (128 > g) return 4294967296 * (c >>> 0) + (b >>> 0 >>> 0);
            throw Error("pa");
        },
        Yk = function(a, b) {
            a.H = b;
            if (b > a.za) throw Error("qa`" + b + "`" + a.za);
        },
        $k = function(a) {
            var b = a.ya,
                c = a.H,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("pa");
            Yk(a, c);
            return e
        },
        al = function(a) {
            return $k(a) >>> 0
        },
        bl = function(a) {
            return Zk(a)
        },
        cl = function(a) {
            var b = a.ya,
                c = a.H,
                d = b[c + 0],
                e = b[c + 1],
                f = b[c + 2];
            b = b[c + 3];
            a.advance(4);
            return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
        },
        dl = function(a) {
            for (var b = 0, c = a.H, d = c + 10, e = a.ya; c < d;) {
                var f = e[c++];
                b |= f;
                if (0 === (f & 128)) return Yk(a, c), !!(b & 127)
            }
            throw Error("pa");
        },
        el = function(a, b) {
            if (0 > b) throw Error("ra`" + b);
            var c = a.H,
                d = c + b;
            if (d > a.za) throw Error("qa`" + (a.za - c) + "`" + b);
            a.H = d;
            return c
        };
    Wk.prototype.mg = function(a, b) {
        var c = el(this, a),
            d = z(this.ya);
        if (yi) {
            var e;
            b ? (e = wi) || (e = wi = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = xi) || (e = xi = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = 0 === c && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (void 0 === vi) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (r) {}
                        try {
                            e.decode(new Uint8Array([97])), vi = !0
                        } catch (r) {
                            vi = !1
                        }
                    }
                    b = !vi
                }
                b && (wi = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var k = null, h, l; c < a;) h = d[c++], 128 > h ? g.push(h) : 224 > h ? c >= a ? ti(b, g) : (l =
                d[c++], 194 > h || 128 !== (l & 192) ? (c--, ti(b, g)) : (h = (h & 31) << 6 | l & 63, z(128 <= h && 2047 >= h), g.push(h))) : 240 > h ? c >= a - 1 ? ti(b, g) : (l = d[c++], 128 !== (l & 192) || 224 === h && 160 > l || 237 === h && 160 <= l || 128 !== ((e = d[c++]) & 192) ? (c--, ti(b, g)) : (h = (h & 15) << 12 | (l & 63) << 6 | e & 63, z(2048 <= h && 65535 >= h), z(55296 > h || 57343 < h), g.push(h))) : 244 >= h ? c >= a - 2 ? ti(b, g) : (l = d[c++], 128 !== (l & 192) || 0 !== (h << 28) + (l - 144) >> 30 || 128 !== ((e = d[c++]) & 192) || 128 !== ((f = d[c++]) & 192) ? (c--, ti(b, g)) : (h = (h & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, z(65536 <= h && 1114111 >= h), h -= 65536, g.push((h >>
                10 & 1023) + 55296, (h & 1023) + 56320))) : ti(b, g), 8192 <= g.length && (k = ui(k, g), g.length = 0);
            z(c === a, "expected " + c + " === " + a);
            g = ui(k, g)
        }
        return g
    };
    Wk.prototype.Ne = function(a) {
        if (0 == a) return Ii || (Ii = new Ki(null, Hi));
        var b = el(this, a);
        if (this.Pc && this.Sd) b = this.ya.subarray(b, b + a);
        else {
            var c = z(this.ya);
            a = b + a;
            b = b === a ? Gi || (Gi = new Uint8Array(0)) : Dj ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        fb(b, Uint8Array);
        return 0 == b.length ? Ii || (Ii = new Ki(null, Hi)) : new Ki(b, Hi)
    };
    var Xk = [];
    z(!0);
    var gl = function(a, b) {
            if (Xk.length) {
                var c = Xk.pop();
                c.pc(a, void 0, void 0, b);
                a = c
            } else a = new Wk(a, b);
            this.l = a;
            this.Ka = this.l.W();
            this.m = this.Da = this.Sb = -1;
            fl(this, b)
        },
        fl = function(a, b) {
            b = void 0 === b ? {} : b;
            a.ee = void 0 === b.ee ? !1 : b.ee
        };
    gl.prototype.Hf = function() {
        this.l.clear();
        this.m = this.Sb = this.Da = -1;
        100 > hl.length && hl.push(this)
    };
    gl.prototype.W = function() {
        return this.l.W()
    };
    gl.prototype.reset = function() {
        this.l.reset();
        this.Ka = this.l.W();
        this.m = this.Sb = this.Da = -1
    };
    gl.prototype.advance = function(a) {
        this.l.advance(a)
    };
    var il = function(a) {
            var b = a.l;
            if (b.H == b.za) return !1; - 1 !== a.Da && (b = a.l.W(), a.l.H = a.Ka, al(a.l), 4 === a.m || 3 === a.m ? z(b === a.l.W(), "Expected to not advance the cursor.  Group tags do not have values.") : z(b > a.l.W(), "Expected to read the field, did you forget to call a read or skip method?"), a.l.H = b);
            a.Ka = a.l.W();
            b = al(a.l);
            var c = b >>> 3,
                d = b & 7;
            if (!(0 <= d && 5 >= d)) throw Error("ka`" + d + "`" + a.Ka);
            if (1 > c) throw Error("la`" + c + "`" + a.Ka);
            a.Da = b;
            a.Sb = c;
            a.m = d;
            return !0
        },
        kl = function(a) {
            if (2 != a.m) $a("Invalid wire type for skipDelimitedField"),
                jl(a);
            else {
                var b = al(a.l);
                a.l.advance(b)
            }
        },
        jl = function(a) {
            switch (a.m) {
                case 0:
                    0 != a.m ? ($a("Invalid wire type for skipVarintField"), jl(a)) : dl(a.l);
                    break;
                case 1:
                    z(1 === a.m);
                    a.l.advance(8);
                    break;
                case 2:
                    kl(a);
                    break;
                case 5:
                    z(5 === a.m);
                    a.l.advance(4);
                    break;
                case 3:
                    var b = a.Sb;
                    do {
                        if (!il(a)) throw Error("na");
                        if (4 == a.m) {
                            if (a.Sb != b) throw Error("oa");
                            break
                        }
                        jl(a)
                    } while (1);
                    break;
                default:
                    throw Error("ka`" + a.m + "`" + a.Ka);
            }
        },
        ml = function(a) {
            var b = a.Ka;
            jl(a);
            return ll(a, b)
        },
        ll = function(a, b) {
            if (!a.ee) {
                var c = a.l.W();
                a.l.H = b;
                b = a.l.Ne(c - b);
                z(c == a.l.W());
                return b
            }
        },
        nl = function(a, b, c) {
            z(2 == a.m);
            var d = a.l.za,
                e = al(a.l),
                f = a.l.W() + e,
                g = f - d;
            0 >= g && (a.l.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.l.W());
            if (g) throw Error("ja`" + e + "`" + (e - g));
            a.l.H = f;
            a.l.setEnd(d)
        },
        pl = function(a, b) {
            z(11 === a.Da);
            for (var c = 0, d = 0; il(a) && 4 != a.m;) 16 !== a.Da || c ? 26 !== a.Da || d ? jl(a) : c ? (d = -1, nl(a, c, b)) : (d = a.Ka, kl(a)) : (c = ol(a), d && (z(0 < d), a.Da = -1, a.m = -1, a.l.H = d, d = 0));
            if (12 !== a.Da || !d || !c) throw Error("ma");
        },
        ol = function(a) {
            z(0 == a.m);
            return al(a.l)
        },
        ql = function(a) {
            z(0 ==
                a.m);
            return Zk(a.l)
        };
    gl.prototype.mg = function() {
        return rl(this)
    };
    var rl = function(a) {
        z(2 == a.m);
        var b = al(a.l);
        return a.l.mg(b, !0)
    };
    gl.prototype.Ne = function() {
        z(2 == this.m);
        var a = al(this.l);
        return this.l.Ne(a)
    };
    var sl = function(a, b, c) {
            z(2 == a.m);
            var d = al(a.l);
            for (d = a.l.W() + d; a.l.W() < d;) c.push(b(a.l))
        },
        hl = [];
    var tl = function(a, b, c, d) {
        this.Gd = a;
        this.Mg = c;
        this.Lg = d
    };

    function ul(a) {
        return Array.isArray(a) ? a[0] instanceof tl ? (z(2 === a.length), vl(a[1]), a) : [wl, vl(a)] : [fb(a, tl), void 0]
    }
    var zl = function(a, b, c) {
            F(a);
            for (var d = c.Ff, e = {}; il(b) && 4 != b.m;)
                if (e = {
                        Xe: void 0
                    }, 11 === b.Da) {
                    var f = b.Ka;
                    e.Xe = !1;
                    pl(b, function(g) {
                        return function(k, h) {
                            var l = c[k];
                            if (!l) {
                                var m = d[k];
                                if (m) {
                                    l = vl(m);
                                    var r = xl(l),
                                        q = yl(l).Rb;
                                    l = c[k] = function(v, w, A) {
                                        return r(Ck(w, q, A, !0), v)
                                    }
                                }
                            }
                            l ? l(h, a, k) : (g.Xe = !0, h.l.H = h.l.za)
                        }
                    }(e));
                    e.Xe && vj(a, ll(b, f))
                } else vj(a, ml(b))
        },
        Bl = function(a, b) {
            return function(c, d, e) {
                return c.lk(e, Al(d, a), b)
            }
        };

    function Cl(a, b, c) {
        if (Array.isArray(b)) {
            var d = Si(b);
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                null != g && (b[f++] = g)
            }
            f < e && (b.length = f);
            c && (Ti(b, (d | 5) & -12289), d & 2 && Object.freeze(b));
            return b
        }
    }

    function Al(a, b) {
        return a instanceof Tk ? a.u : Array.isArray(a) ? hk(a, b) : void 0
    }
    var Dl = Symbol("deserializeBinaryFromReaderCache");

    function xl(a) {
        var b = a[Dl];
        if (!b) {
            var c = El(a),
                d = yl(a),
                e = d.zf;
            b = e ? function(f, g) {
                return e(f, g, d)
            } : function(f, g) {
                for (; il(g) && 4 != g.m;) {
                    var k = g.Sb,
                        h = d[k];
                    if (!h) {
                        var l = d.Ff;
                        l && (l = l[k]) && (h = d[k] = Fl(l))
                    }
                    h && h(g, f, k) || vj(f, ml(g))
                }
                c === Gl || c === Hl || c.jg || (f[zj()] = c)
            };
            a[Dl] = b
        }
        return b
    }

    function Fl(a) {
        a = ul(a);
        var b = fb(a[0], tl).Gd;
        if (a = a[1]) {
            vl(a);
            var c = xl(a),
                d = yl(z(a)).Rb;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    }
    var Gl, Hl, Il = Symbol("comparisonTypeInfoCache");

    function Jl(a, b, c) {
        var d = c[1];
        if (d) {
            var e = d[Il];
            var f = e ? e.Rb : z(gk(d[0]));
            a[b] = null != e ? e : d
        }
        f && f === ek ? F(a.od || (a.od = [])).push(b) : c[0] && F(a.ud || (a.ud = [])).push(b)
    }

    function Kl(a, b) {
        return [a.Mg, !b || 0 < b[0] ? void 0 : b]
    }

    function El(a) {
        var b = a[Il];
        if (b) return b;
        b = Ll(a, a[Il] = {}, Kl, Kl, Jl);
        if (!b.ud && !b.od) {
            var c = !0,
                d;
            for (d in b) {
                isNaN(d) || (c = !1);
                break
            }
            c ? (b = z(gk(a[0])) === ek, b = a[Il] = b ? Hl || (Hl = {
                Rb: z(gk(!0))
            }) : Gl || (Gl = {})) : b.jg = !0
        }
        return b
    }

    function Ml(a, b, c, d) {
        var e;
        (e = b[a]) ? Array.isArray(e) && (b[a] = e = El(e)): e = void 0;
        if (e) {
            var f = b.ud;
            (f = (f ? Array.isArray(f) ? b.ud = new Set(f) : f : xj || (xj = new Set)).has(a)) || (f = b.od, f = (f ? Array.isArray(f) ? b.od = new Set(f) : f : xj || (xj = new Set)).has(a));
            if (f) {
                if (Array.isArray(c))
                    for (f = 0; f < c.length; f++) {
                        var g = c[f];
                        d = !1;
                        if (g instanceof Tk) d = !0, g = g.u;
                        else if (!Array.isArray(g)) throw Error("ta`" + g + "`" + a + "`" + JSON.stringify(b));
                        Nl(g, e, d)
                    }
            } else {
                if (c instanceof Tk) d = !0, c = c.u;
                else if (!Array.isArray(c)) throw Error("ua");
                Nl(c,
                    e, d)
            }
        }
    }

    function Nl(a, b, c) {
        F(a);
        if (b !== Gl && b !== Hl) {
            b.jg || (a[zj()] = b);
            var d = a.length;
            var e = z(b.Rb);
            F(e);
            e = e[1] ? 0 : -1;
            for (var f = 0; f < a.length; f++) {
                var g = a[f];
                if (g && "object" === typeof g)
                    if (f === d - 1 && lj(g))
                        for (var k in g) {
                            var h = +k;
                            if (Number.isNaN(h)) {
                                var l = g[k];
                                l && "object" === typeof l && Ml(h, b, l, c)
                            }
                        } else h = kj(f, e), Ml(h, b, g, c)
            }
        }
    }
    var Ol = Symbol("makeCrossSerializerComparisonsCompatible");

    function Pl(a) {
        var b = a[Ol];
        if (!b) {
            var c = El(a);
            b = function(d) {
                return Nl(d, c, !0)
            };
            a[Ol] = b
        }
        return b
    }

    function vl(a) {
        F(a);
        var b;
        if (!(b = Ql in a || Rl in a) && (b = 0 < a.length)) {
            b = a[0];
            var c = gk(b);
            null != c && c !== b && (a[0] = c);
            b = null != c
        }
        z(b);
        return a
    }

    function Sl(a, b, c) {
        a[b] = c
    }

    function Ll(a, b, c, d, e) {
        e = void 0 === e ? Sl : e;
        b.Rb = z(gk(a[0]));
        var f = 0,
            g = a[++f];
        g && g.constructor === Object && (b.Ff = g, g = a[++f], "function" === typeof g && (b.zf = g, b.ai = cb(a[++f]), z(b.zf === zl), z(b.ai === Bl), g = a[++f]));
        for (var k = {}; Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];) {
            for (var h = 0; h < g.length; h++) k[g[h]] = g;
            g = a[++f]
        }
        for (h = 1; void 0 !== g;) {
            "number" === typeof g && (z(0 < g), h += g, g = a[++f]);
            var l = void 0;
            if (g instanceof tl) var m = g;
            else m = Tl, f--;
            if (m.Lg) {
                g = a[++f];
                l = a;
                var r = f;
                "function" == typeof g && (z(0 === g.length),
                    g = g(), l[r] = g);
                vl(g);
                l = g
            }
            g = a[++f];
            r = h + 1;
            "number" === typeof g && 0 > g && (r -= g, g = a[++f]);
            for (; h < r; h++) {
                var q = k[h];
                e(b, h, l ? d(m, l, q) : c(m, q))
            }
        }
        return b
    }
    var Rl = Symbol("serializerFnCache"),
        Ql = Symbol("deserializerFnCache");

    function Ul(a, b) {
        var c = a.Gd;
        return b ? function(d, e, f) {
            return c(d, e, f, b)
        } : c
    }

    function Vl(a, b, c) {
        var d = a.Gd,
            e, f;
        return function(g, k, h) {
            return d(g, k, h, f || (f = yl(b).Rb), e || (e = xl(b)), c)
        }
    }

    function yl(a) {
        var b = a[Ql];
        if (b) return b;
        El(a);
        b = Ll(a, a[Ql] = {}, Ul, Vl);
        Ql in a && Rl in a && (a.length = 0);
        return b
    }

    function Wl(a, b) {
        return new tl(a, b, !1, !1)
    }

    function Xl(a, b, c) {
        uk(a, Zi(a), b, c)
    }

    function Yl(a, b, c, d, e) {
        a.kk(c, Al(b, d), e)
    }
    var Zl = Wl(function(a, b, c) {
            if (1 !== a.m) return !1;
            z(1 == a.m);
            var d = a.l;
            a = cl(d);
            var e = cl(d);
            d = 2 * (e >> 31) + 1;
            var f = e >>> 20 & 2047;
            a = 4294967296 * (e & 1048575) + a;
            Xl(b, c, 2047 == f ? a ? NaN : Infinity * d : 0 == f ? d * Math.pow(2, -1074) * a : d * Math.pow(2, f - 1075) * (a + 4503599627370496));
            return !0
        }, function(a, b, c) {
            a.gk(c, Lj(b))
        }),
        bm = Wl(function(a, b, c) {
                if (5 !== a.m) return !1;
                z(5 == a.m);
                var d = cl(a.l);
                a = 2 * (d >> 31) + 1;
                var e = d >>> 23 & 255;
                d &= 8388607;
                Xl(b, c, 255 == e ? d ? NaN : Infinity * a : 0 == e ? a * Math.pow(2, -149) * d : a * Math.pow(2, e - 150) * (d + Math.pow(2, 23)));
                return !0
            },
            function(a, b, c) {
                a.ik(c, Lj(b))
            }),
        cm = Wl(function(a, b, c) {
            if (0 !== a.m) return !1;
            Xl(b, c, ql(a));
            return !0
        }, function(a, b, c) {
            a.rk(c, Wj(b))
        }),
        dm;
    dm = new tl(function(a, b, c) {
        if (0 !== a.m && 2 !== a.m) return !1;
        b = Bk(b, c);
        2 == a.m ? sl(a, bl, b) : b.push(ql(a));
        return !0
    }, function(a, b, c) {
        a.nk(c, Cl(Wj, b, !1))
    }, !0, !1);
    var em = Wl(function(a, b, c) {
            if (0 !== a.m) return !1;
            z(0 == a.m);
            a = $k(a.l);
            Xl(b, c, a);
            return !0
        }, function(a, b, c) {
            a.jk(c, Rj(b))
        }),
        fm = Wl(function(a, b, c) {
            if (0 !== a.m) return !1;
            z(0 == a.m);
            a = dl(a.l);
            Xl(b, c, a);
            return !0
        }, function(a, b, c) {
            a.fk(c, Oj(b))
        }),
        gm = Wl(function(a, b, c) {
            if (2 !== a.m) return !1;
            Xl(b, c, rl(a));
            return !0
        }, function(a, b, c) {
            a.pk(c, Xj(b))
        }),
        wl = new tl(function(a, b, c, d, e) {
            if (2 !== a.m) return !1;
            nl(a, Ck(b, d, c, !0), e);
            return !0
        }, Yl, !1, !0),
        Tl = new tl(function(a, b, c, d, e) {
            if (2 !== a.m) return !1;
            nl(a, Ck(b, d, c), e);
            return !0
        }, Yl, !1, !0),
        hm;
    hm = new tl(function(a, b, c, d, e) {
        if (2 !== a.m) return !1;
        d = hk(void 0, d);
        var f = Zi(b);
        rj(f);
        var g = Ak(b, f, c, 3);
        f = Zi(b);
        if (Si(g) & 4) {
            g = Li(g);
            var k = Si(g);
            Ti(g, (k | 1) & -2079);
            uk(b, f, c, g)
        }
        g.push(d);
        nl(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) Yl(a, b[f], c, d, e)
    }, !0, !0);
    var im = Wl(function(a, b, c) {
            if (0 !== a.m) return !1;
            Xl(b, c, ol(a));
            return !0
        }, function(a, b, c) {
            a.qk(c, Tj(b))
        }),
        jm;
    jm = new tl(function(a, b, c) {
        if (0 !== a.m && 2 !== a.m) return !1;
        b = Bk(b, c);
        2 == a.m ? sl(a, al, b) : b.push(ol(a));
        return !0
    }, function(a, b, c) {
        a.mk(c, Cl(Tj, b, !0))
    }, !0, !1);
    var km = Wl(function(a, b, c) {
        if (0 !== a.m) return !1;
        z(0 == a.m);
        a = $k(a.l);
        Xl(b, c, a);
        return !0
    }, function(a, b, c) {
        a.hk(c, Rj(b))
    });

    function lm(a) {
        if (a instanceof Tk) return a.constructor.Ba
    };

    function mm(a, b) {
        b = void 0 === b ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return mm(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = nm(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = t(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + mm(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = nm(c.constructor)), "function" === typeof a.toString && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + nm(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function nm(a) {
        var b = a.name;
        b || (b = (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)");
        return b
    };

    function om(a, b) {
        a.Nf = "function" === typeof b ? b : function() {
            return b
        };
        return a
    }
    var pm = void 0;

    function qm() {
        throw Error(y.apply(0, arguments).map(function(a) {
            return "function" === typeof a ? a() : a
        }).filter(function(a) {
            return a
        }).join("\n").trim().replace(/:$/, ""));
    };
    (function() {
        var a = Ja.jspbGetTypeName;
        Ja.jspbGetTypeName = a ? function(b) {
            return a(b) || lm(b)
        } : lm
    })();
    var rm = Tk;

    function sm(a, b) {
        return function(c) {
            c = fb(fb(c, a), Tk);
            Pl(b)(fb(c, Tk).u)
        }
    };
    var Gk = function(a) {
        rm.call(this, a)
    };
    x(Gk, rm);
    Gk.prototype.Mf = function() {
        return Mk(this)
    };
    Gk.Ba = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var tm = [0, gm, -1];
    Gk.makeCrossSerializerComparisonsCompatible = sm(Gk, tm);
    var um = function(a) {
        rm.call(this, a)
    };
    x(um, rm);
    var vm = function(a, b) {
            return Qk(a, 2, b)
        },
        wm = function(a, b) {
            return Qk(a, 3, b)
        },
        xm = function(a, b) {
            return Qk(a, 4, b)
        },
        ym = function(a, b) {
            return Qk(a, 5, b)
        },
        zm = function(a, b) {
            return Qk(a, 9, b)
        },
        Am = function(a, b) {
            var c = Gk,
                d = a.u,
                e = Zi(d);
            rj(e);
            if (null == b) uk(d, e, 10);
            else {
                F(b);
                var f = Si(b),
                    g = f,
                    k = !!(2 & f) || !!(2048 & f);
                z(!k || Object.isFrozen(b));
                var h = k || Object.isFrozen(b),
                    l;
                if (l = !h) l = !1;
                for (var m = !0, r = !0, q = 0; q < b.length; q++) {
                    var v = b[q],
                        w = v,
                        A = Za(c);
                    if (!(w instanceof A)) throw Error("$`" + Mj(A) + "`" + (w && Mj(w.constructor)));
                    k || (v =
                        aj(v.u), m && (m = !v), r && (r = v))
                }
                k || (f = Vi(f, 5, !0), f = Vi(f, 8, m), f = Vi(f, 16, r));
                if (l || h && f !== g) b = Li(b), g = 0, f = Hk(f, e, !0);
                f !== g && Ti(b, f);
                Aj(b);
                uk(d, e, 10, b)
            }
            return a
        },
        Bm = function(a, b) {
            return vk(a, 11, null == b ? b : Nj(b))
        },
        Cm = function(a, b) {
            return Qk(a, 1, b)
        },
        Dm = function(a, b) {
            return vk(a, 7, null == b ? b : Nj(b))
        };
    um.Ba = "wireless.mdl.UserAgentClientHints";
    um.og = [10, 6];
    um.makeCrossSerializerComparisonsCompatible = sm(um, [0, gm, -4, hm, tm, fm, km, gm, hm, tm, fm]);
    var Em = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Fm(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    }

    function Gm(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    }

    function Hm(a) {
        if (!Gm(a)) return null;
        var b = Fm(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Em).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Im(a) {
        var b;
        return Bm(Am(ym(vm(Cm(xm(Dm(zm(wm(new um, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Gk;
            d = Qk(d, 1, c.brand);
            return Qk(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Jm(a) {
        var b, c;
        return null != (c = null == (b = Hm(a)) ? void 0 : b.then(function(d) {
            return Im(d)
        })) ? c : null
    };
    var Km = function(a, b, c, d) {
        a = void 0 === a ? window : a;
        b = void 0 === b ? null : b;
        c = void 0 === c ? new Qa : c;
        d = void 0 === d ? Og("current") : d;
        Td.call(this);
        this.global = a;
        this.Ja = b;
        this.B = c;
        this.wg = d;
        this.ti = nd(this.global, "pagehide").g(Sg(this.B, 941));
        this.ig = nd(this.global, "load").g(Sg(this.B, 738), Te(1));
        this.ui = nd(this.global, "resize").g(Sg(this.B, 741));
        this.onMessage = nd(this.global, "message").g(Sg(this.B, 740));
        this.document = new ii(this.global, this);
        this.i = new Ug(new Xg(this.I, this.B), new Wg(this.I, this.B));
        this.J = new fe(new Dh(this),
            new Uf(this, new Yg(this)), new Uf(this, new Hh(this)), new Uf(this, new Bh(this)))
    };
    x(Km, Td);
    var Zg = function(a) {
        var b = a.global;
        return !!a.global.HTMLFencedFrameElement && !!b.fence && "function" === typeof b.fence.reportEvent
    };
    Km.prototype.ub = function(a) {
        Zg(this) && this.global.fence.reportEvent(a)
    };
    Km.prototype.le = function() {
        return this.ti.g(Sg(this.B, 942), Y(this.h, 1), P(function() {}))
    };
    var Lm = function(a) {
            var b = new Km(a.global.top, a.Ja);
            b.J = a.J;
            return b
        },
        Mm = function(a, b) {
            b.start();
            return nd(b, "message").g(Sg(a.B, 740))
        };
    Km.prototype.postMessage = function(a, b, c) {
        c = void 0 === c ? [] : c;
        this.global.postMessage(a, b, c)
    };
    Km.prototype.me = function() {
        return Ah(this.global) ? this.global.width : 0
    };
    Km.prototype.ke = function() {
        return Ah(this.global) ? this.global.height : 0
    };
    var Nm = function(a, b) {
        try {
            var c = a.global;
            try {
                b && (c = c.top);
                a = c;
                var d = yh() || zh();
                b && null !== a && a != a.top && (a = a.top);
                try {
                    if (void 0 === d ? 0 : d) var e = (new rh(a.innerWidth, a.innerHeight)).round();
                    else {
                        var f = (a || window).document,
                            g = "CSS1Compat" == f.compatMode ? f.documentElement : f.body;
                        e = (new rh(g.clientWidth, g.clientHeight)).round()
                    }
                    var k = e
                } catch (w) {
                    k = new rh(-12245933, -12245933)
                }
                b = k;
                var h = b.height,
                    l = b.width;
                if (-12245933 === l) var m = new si(l, l, l, l);
                else {
                    var r = vh(uh(c.document).Gb),
                        q = r.x,
                        v = r.y;
                    m = new si(v, q + l, v + h, q)
                }
            } catch (w) {
                m =
                    new si(-12245933, -12245933, -12245933, -12245933)
            }
            return {
                left: m.left,
                top: m.top,
                width: m.me(),
                height: m.ke()
            }
        } catch (w) {
            return oi
        }
    };
    Km.prototype.validate = function() {
        var a = this.J.K() || Zg(this);
        return this.global && this.i.fa() && a
    };
    var Vh = function(a) {
        return (a = Jm(a.global)) ? hd(a) : null
    };
    da.Object.defineProperties(Km.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.sharedStorage
            }
        },
        I: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        Mb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !Ah(this.global.top)
            }
        },
        te: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Mb || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.I.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.I.ResizeObserver
            }
        },
        Uh: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                z(!0, "Major version must be an integer");
                return 8 <= Qb()
            }
        },
        fh: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var Om = !dh && !Mb(),
        Pm = function(a, b) {
            if (/-[a-z]/.test(b)) return null;
            if (Om && a.dataset) {
                if (Ob() && !(b in a.dataset)) return null;
                a = a.dataset[b];
                return void 0 === a ? null : a
            }
            return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
        };
    var Qm = {},
        Rm = (Qm["data-google-av-cxn"] = "_avicxn_", Qm["data-google-av-cpmav"] = "_cvu_", Qm["data-google-av-metadata"] = "_avm_", Qm["data-google-av-adk"] = "_adk_", Qm["data-google-av-btr"] = void 0, Qm["data-google-av-override"] = void 0, Qm["data-google-av-dm"] = void 0, Qm["data-google-av-immediate"] = void 0, Qm["data-google-av-aid"] = void 0, Qm["data-google-av-naid"] = void 0, Qm["data-google-av-inapp"] = void 0, Qm["data-google-av-slift"] = void 0, Qm["data-google-av-itpl"] = void 0, Qm["data-google-av-ext-cxn"] = void 0, Qm["data-google-av-rs"] =
            void 0, Qm["data-google-av-flags"] = void 0, Qm["data-google-av-turtlex"] = void 0, Qm["data-google-av-ufs-integrator-metadata"] = void 0, Qm["data-google-av-vattr"] = void 0, Qm["data-google-av-vrus"] = void 0, Qm),
        Sm = {},
        Tm = (Sm["data-google-av-adk"] = "googleAvAdk", Sm["data-google-av-btr"] = "googleAvBtr", Sm["data-google-av-cpmav"] = "googleAvCpmav", Sm["data-google-av-dm"] = "googleAvDm", Sm["data-google-av-ext-cxn"] = "googleAvExtCxn", Sm["data-google-av-immediate"] = "googleAvImmediate", Sm["data-google-av-inapp"] = "googleAvInapp",
            Sm["data-google-av-itpl"] = "googleAvItpl", Sm["data-google-av-metadata"] = "googleAvMetadata", Sm["data-google-av-naid"] = "googleAvNaid", Sm["data-google-av-override"] = "googleAvOverride", Sm["data-google-av-rs"] = "googleAvRs", Sm["data-google-av-slift"] = "googleAvSlift", Sm["data-google-av-cxn"] = "googleAvCxn", Sm["data-google-av-aid"] = void 0, Sm["data-google-av-flags"] = "googleAvFlags", Sm["data-google-av-turtlex"] = "googleAvTurtlex", Sm["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Sm["data-google-av-vattr"] =
            "googleAvVattr", Sm["data-google-av-vrus"] = "googleAvVurs", Sm);

    function Um(a, b) {
        if (void 0 === a.j) return null;
        try {
            var c;
            var d = null != (c = a.j.getAttribute(b)) ? c : null;
            if (null !== d) return d
        } catch (g) {}
        try {
            var e = Rm[b];
            if (e && (d = a.j[e], void 0 !== d)) return d
        } catch (g) {}
        try {
            var f = Tm[b];
            if (f) return Pm(a.j, f)
        } catch (g) {}
        return null
    }

    function Vm(a) {
        return P(function(b) {
            return Um(b, a)
        })
    };
    var Wm = K(function(a) {
        return P(function(b) {
            return a.map(function(c) {
                return Um(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), P(function(a) {
        var b = t(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (null !== b) return [];
            throw new be;
        }
        return a.split("|")
    }));
    var Xm = function() {
        return K(id(function(a) {
            return a.element.g(Wm, De(function() {
                return N([""])
            })).g(P(function(b) {
                return {
                    Fa: b,
                    Vc: a
                }
            }))
        }), Oe(function(a) {
            return a.Fa.sort().join(";")
        }), P(function(a) {
            return a.Vc
        }))
    };
    var Zm = function() {
            return id(function(a) {
                return hd(Ym(a)).g(Ih(a.h))
            })
        },
        Ym = function(a) {
            return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
                return new Xh(b)
            })
        };

    function $m(a) {
        var b = a.ig,
            c = a.document.si;
        return td(N({}), c, b).g(P(function() {
            return a
        }))
    };
    var bn = P(an);

    function an(a) {
        var b = Number(Um(a, "data-google-av-rs"));
        if (!isNaN(b) && 0 !== b) return b;
        var c;
        return (a = null == (c = a.j) ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function cn() {
        return K(T(function(a) {
            return void 0 !== a
        }), P(function(a) {
            return a
        }))
    };

    function dn() {
        return function(a) {
            var b = [];
            return a.g(T(function(c) {
                if (void 0 === c.j || b.some(function(d) {
                        return d.j === c.j
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function en(a, b) {
        b = void 0 === b ? rc : b;
        return td($m(a), b).g(Zm(), dn(), cn(), Y(a.h, 1))
    };

    function fn(a, b) {
        return new L(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                k = function(r, q) {
                    a.qg ? (e[q] = r, f.add(q), d || (d = !0, Ta(a, function() {
                        d = !1;
                        c.next(mb(e))
                    }, 1))) : c.error(new ce(q))
                },
                h = function(r, q) {
                    g.add(q);
                    f.add(q);
                    Ta(a, function() {
                        c.error(r)
                    }, 1)
                },
                l = function(r) {
                    g.add(r);
                    Ta(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(r, q) {
                    return r.subscribe(function(v) {
                        return void k(v, q)
                    }, function(v) {
                        return void h(v, q)
                    }, function() {
                        return void l(q)
                    })
                });
            return function() {
                m.forEach(function(r) {
                    return void r.unsubscribe()
                })
            }
        })
    };

    function gn(a, b, c) {
        function d() {
            if (b.Ja) {
                var D = b.Ja,
                    C = D.next;
                var R = {
                    creativeId: b.jc.Ma(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: k,
                    erroredSignalKey: h
                };
                R = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: ne(b.i.now(), new le(0, b.i.timeline)),
                    instanceId: b.jc.Ma(b.xb),
                    creativeState: R
                };
                C.call(D, R)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, k = null, h = null, l = {}, m = new Set, r = [], q = [], v = t(e), w = v.next(), A = {}; !w.done; A = {
                ja: void 0
            }, w = v.next()) A.ja = w.value, w = a[A.ja], w instanceof
        Z ? (l[A.ja] = w.value, m.add(A.ja), b.Ja && (f[String(A.ja)] = pe(w.value))) : (w = w.g(V(function(D, C) {
                return ge(D) || ge(C) ? !1 : D === C
            }), P(function(D) {
                return function(C) {
                    b.Ja && (f[String(D.ja)] = pe(C), d());
                    var R = {};
                    return R[D.ja] = C, R
                }
            }(A)), De(function(D) {
                return function(C) {
                    if (C instanceof ce) throw new ee(String(D.ja));
                    throw C;
                }
            }(A)), If(function(D) {
                return function() {
                    m.add(D.ja)
                }
            }(A), function(D) {
                return function(C) {
                    h = String(D.ja);
                    k = String(C);
                    d()
                }
            }(A), function(D) {
                return function() {
                    m.has(D.ja) || (g = !0, d())
                }
            }(A))), q.push(A.ja),
            r.push(w));
        (a = 0 < Object.keys(f).length) && d();
        v = fn(b.h, r).g(De(function(D) {
            if (D instanceof ce) throw new de(String(q[D.Nh]));
            throw D;
        }), P(function(D) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(u(D))))
        }));
        return (r = 0 < r.length) && a ? td(N(Object.freeze(l)), v) : r ? v : N(Object.freeze(l))
    };

    function hn(a, b, c, d) {
        var e = jn(kn(ln(), mn), nn, on);
        return a.B.Zb.bind(a.B)(733, function() {
            var f = {};
            try {
                return b.g(De(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return rc
                }), id(function(g) {
                    try {
                        var k = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), rc
                    }
                    var h = {};
                    return gn(k, a, g.xb).g(If(function(l) {
                        h = l
                    }), wf(1), Dc()).g(e, De(function(l) {
                        d(Object.assign({}, h, {
                            error: l
                        }));
                        return rc
                    }), $e(void 0), P(function() {
                        return !0
                    }))
                })).g( of (function(g) {
                    return g + 1
                }, 0), De(function(g) {
                    d(Object.assign({},
                        f, {
                            error: g
                        }));
                    return rc
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), rc
            }
        })()
    };

    function pn(a, b) {
        return K(X(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new L(function(g) {
                e(d, f, function(k) {
                    g.next(Object.assign({}, c, {
                        jb: k
                    }));
                    g.complete()
                });
                return function() {}
            }) : vd
        }), T(function(c) {
            return c.jb
        }))
    };
    var nn = K(T(function(a) {
            var b = a.J,
                c = a.Rc,
                d = a.ac,
                e = a.ub,
                f = a.pb,
                g = a.fc;
            return void 0 !== a.Hb && void 0 !== g && void 0 !== b && void 0 !== c && void 0 !== d && (!f || void 0 !== e)
        }), Ff(function(a) {
            return !(!1 === a.Wf && void 0 !== a.Bf)
        }, !1), T(function(a) {
            var b = a.qe;
            return a.ij ? !!b : !!a.Wf
        }), pn(function(a) {
            return a.fc
        }, function(a) {
            return a.Hb
        }), P(function(a) {
            if (a.pb) {
                var b;
                a.ub({
                    eventType: "active-view-begin-to-render",
                    eventData: null != (b = a.Cd) ? b : "",
                    destination: ["buyer"]
                })
            } else a.ac(a.Rc, a).forEach(function(c) {
                a.J.T(c).sendNow()
            })
        }),
        Te(1), df());

    function qn(a) {
        var b = new Map;
        if ("object" !== typeof a || null === a) return b;
        Object.values(a).forEach(function(c) {
            c && "function" === typeof c.ia && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function rn(a, b) {
        var c = sn,
            d = tn,
            e = un;
        b = void 0 === b ? .01 : b;
        return function(f) {
            0 < b && Math.random() <= b && (a.global.HTMLFencedFrameElement && a.global.fence && "function" === typeof a.global.fence.reportEvent && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                Cf: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                rh: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                qh: String(a.B.Cg)
            }), d(Object.assign({}, f, {
                ua: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (k) {
                            return {}
                        }
                    }
                }(),
                Fa: [c]
            }), qn(f)).forEach(function(g) {
                a.J.T(g).sendNow()
            }))
        }
    };
    var on = K(P(function(a) {
        var b = a.J,
            c = a.yh;
        if (void 0 === b || void 0 === c) return !1;
        if (void 0 !== a.Bf) return !0;
        if (null === c) return !1;
        for (a = 0; a < c; a++) b.T("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(1E7 * Math.random())).sendNow();
        return !0
    }), Ff(function(a) {
        return !a
    }), df());
    var un = function(a) {
        return {
            id: a.Me,
            mcvt: a.tc,
            p: a.Wc,
            asp: a.Lj,
            mtos: a.uc,
            tos: a.Gc,
            v: a.eh,
            bin: a.dh,
            avms: a.gg,
            bs: a.sf,
            mc: a.eg,
            "if": a.kh,
            vu: a.nh,
            app: a.ab,
            mse: a.Ge,
            mtop: a.He,
            itpl: a.ve,
            adk: a.Qd,
            exk: a.Nj,
            rs: a.Ta,
            la: a.Zf,
            cr: a.ye,
            uach: a.Ic,
            vs: a.af,
            r: a.Oe,
            pay: a.Ih,
            rst: a.Xg,
            rpt: a.Wg,
            isd: a.Mh,
            lsd: a.Zh,
            context: a.qh,
            msg: a.errorMessage,
            stack: a.Cf,
            name: a.rh,
            ec: a.Jh,
            sfr: a.Te,
            met: a.ic,
            wmsd: a.df,
            pv: a.Wj,
            epv: a.Qj,
            pbe: a.Vf,
            vae: a.Lh,
            spb: a.zg,
            ffslot: a.Th,
            reach: a.Ti,
            io2: a.Dd,
            rxdbg: a.ak
        }
    };

    function jn() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c = b.g(wf(1), Dc());
            b = a.map(function(d) {
                return c.g(d, $e(!0))
            });
            return S(b).g(Te(1), df())
        }
    };

    function kn() {
        var a = y.apply(0, arguments);
        return function(b) {
            var c = b.g(wf(1), Dc());
            b = a.map(function(d) {
                return c.g(d, $e(!0))
            });
            return td.apply(null, u(b)).g(Te(1), df())
        }
    };

    function ln() {
        var a = vn,
            b = wn;
        return function(c) {
            var d = c.g(wf(1), Dc());
            c = d.g(a, $e(!0));
            d = d.g(K(b, wf(), Dc()), $e(!0));
            c = S([c, d]);
            return yd(c, d).g(Te(1), df())
        }
    };
    var wn = function(a) {
        var b = [];
        return a.g(P(function(c) {
            var d = c.J,
                e = c.Bh,
                f = c.Gc,
                g = c.aj,
                k = c.ua,
                h = c.Zi,
                l = c.Ag,
                m = c.Hc,
                r = c.bf,
                q = c.qe,
                v = c.Vf,
                w = c.zg,
                A = c.Cd;
            if (!c.Lf || !q || void 0 === c.uc || void 0 === f || void 0 === g || void 0 === k || void 0 === h || void 0 === m || void 0 === d) return !1;
            if (c.pb) {
                if (void 0 === l) return !1;
                g = c.ub;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: null != A ? A : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!v && !l) return !1;
            A = qn(c);
            var D;
            r = null != (D = null == r ? void 0 : r.qa(A).value) ? D : !1;
            c = m(Object.assign({},
                c, {
                    Me: h,
                    af: r ? 4 : 3,
                    Oe: null != l ? l : "u",
                    ua: k,
                    Fa: g
                }), A);
            if (v) {
                for (; b.length > g.length;) v = void 0, null == (v = b.shift()) || v.deactivate();
                c.forEach(function(C, R) {
                    R >= b.length ? b.push(d.T(C)) : b[R].url = C
                });
                return w && e && void 0 !== l ? (c.forEach(function(C) {
                    e.T(C).sendNow()
                }), !0) : void 0 !== l
            }
            return w && e && void 0 !== l ? (c.forEach(function(C) {
                e.T(C).sendNow()
            }), !0) : void 0 !== l ? (c.forEach(function(C) {
                d.T(C).sendNow()
            }), !0) : !1
        }), Ff(function(c) {
            return !c
        }), df())
    };

    function xn(a) {
        return function(b) {
            return b.g(P(function(c) {
                a.qg || $a("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function yn(a) {
        return function(b) {
            return new L(function(c) {
                var d = !1,
                    e = b.g(xn(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Ta(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function zn(a, b) {
        return function(c) {
            return c.g(X(function(d) {
                return new L(function(e) {
                    function f() {
                        k.disconnect();
                        h.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && void 0 !== d.j) {
                        var k = new g(function(l) {
                            e.next(l)
                        });
                        k.observe(d.j, b);
                        var h = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var An = {
        Kj: 0,
        oj: 1,
        qj: 2,
        pj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function Bn(a, b) {
        var c = b.g(zn(a, {
            attributes: !0
        }), Y(a.h, 1));
        return S([b, c.g(Y(a.h, 1), yn(a.h))]).g(P(function(d) {
            return t(d).next().value
        }), Vm("data-google-av-dm"), P(Cn))
    }

    function Cn(a) {
        return a && a in An ? Number(a) : 2
    };

    function Dn(a) {
        if (3 === a.di) return null;
        if (void 0 !== a.Ag) {
            var b = !1 === a.jh ? "n" : null;
            if (null !== b) return b
        }
        return a.ad instanceof Wd ? "msf" : a.Xd instanceof Xd ? "c" : !1 === a.ih ? "pv" : a.ad || a.Xd ? "x" : null
    }
    var mn = K(T(function(a) {
        return void 0 !== a.ed && void 0 !== a.ua && void 0 !== a.Hc && void 0 !== a.fd && void 0 !== a.J
    }), T(function(a) {
        return null !== Dn(a)
    }), pn(function(a) {
        return a.Nc
    }, function(a) {
        return a.Hb
    }), P(function(a) {
        if (a.pb) {
            var b = a.ub;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: null != (c = a.Cd) ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = Dn(a);
            if ("x" === d) {
                var e, f = null != (e = a.ad) ? e : a.Xd;
                f && (b = f.stack, c = f.message)
            }
            a.Hc(Object.assign({}, a, {
                Fa: a.ed,
                ua: a.ua,
                Me: a.fd,
                af: 2,
                Oe: d,
                errorMessage: c,
                Cf: b
            }), qn(a)).forEach(function(g) {
                a.J.T(g).sendNow()
            })
        }
    }), Te(1), df());

    function En(a, b) {
        return "string" === typeof a ? encodeURIComponent(a) : "number" === typeof a ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return En(c, b)
        }).join(",") : a instanceof le ? a.toString() : a && "function" === typeof a.ia ? En(a.qa(b).value, b) : !0 === a ? "1" : !1 === a ? "0" : void 0 === a || null === a ? null : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function Fn(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = t(c);
            c = d.next().value;
            d = d.next().value;
            d = En(d, b);
            return null === d ? "" : c + "=" + d
        }).filter(function(c) {
            return "" !== c
        });
        return a.length ? a.join("&") : ""
    };
    var Gn = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        Hn = Cg(Dg(), "google3.javascript.ads.common.url_macros_substitutor", sg).dg;

    function In(a, b) {
        return a.replace(Gn, function(c, d) {
            try {
                var e = null !== b && d in b ? b[d] : void 0;
                if (null == e) return Hn && Eg(Hn, "No value supplied for unsupported macro: " + d), c;
                if (null == e.toString()) return Hn && Eg(Hn, "The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if ("" == e || !/^[\s\xa0]*$/.test(null == e ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                Hn && Eg(Hn, "Null value supplied for macro: " + d)
            } catch (f) {
                Hn && Eg(Hn, "Failed to set macro: " + d)
            }
            return c
        })
    };

    function Jn(a, b) {
        var c = Object.assign({}, a),
            d = a.Ic;
        c = (delete c.Ic, c);
        c = a.ua(c);
        var e = Fn(c, b);
        return hb(a.Fa, function(f) {
            var g = "";
            "string" === typeof d && (g = "&" + Fn({
                uach: d
            }, b));
            var k = {};
            return In(f, (k.VIEWABILITY = e, k)) + g
        })
    };

    function tn(a, b) {
        var c = a.ua(a),
            d = Fn(c, b);
        return d ? hb(a.Fa, function(e) {
            e = 0 <= e.indexOf("?") ? e : e + "?";
            e = 0 <= "?&".indexOf(e.slice(-1)) ? e : e + "&";
            return e + d
        }) : a.Fa
    };

    function Kn(a, b) {
        return hb(a, function(c) {
            if ("string" === typeof b.Ic) {
                var d = "&" + Fn({
                    uach: b.Ic
                }, new Map);
                return "&adurl=" == c.substring(c.length - 7) ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var vn = K(T(function(a) {
        return void 0 !== a.ua && void 0 !== a.ed && void 0 !== a.Hc && void 0 !== a.fd && void 0 !== a.J
    }), P(function(a) {
        return Object.assign({}, a, {
            Dg: qn(a)
        })
    }), T(function(a) {
        var b = a.bf,
            c = a.Dg,
            d;
        return !!a.qe && (null != (d = null == b ? void 0 : b.qa(c).value) ? d : !1)
    }), pn(function(a) {
        return a.Oc
    }, function(a) {
        return a.Hb
    }), P(function(a) {
        var b = a.J,
            c = a.Cd;
        if (a.pb) {
            var d = a.ub;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: null != c ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.Hc(Object.assign({}, a, {
            Fa: a.ed,
            ua: a.ua,
            Me: a.fd,
            af: 4,
            Oe: "v"
        }), a.Dg);
        (d = a.Yd) && 0 < d.length && a.ac && a.ac(d, a).forEach(function(e) {
            b.T(e).sendNow()
        });
        (d = a.cf) && 0 < d.length && a.ac && a.ac(d, a).forEach(function(e) {
            b.T(e).sendNow()
        });
        c.forEach(function(e) {
            b.T(e, {
                Qc: a.Ce
            }).sendNow()
        });
        return !0
    }), Ff(function(a) {
        return !a
    }), df());

    function Ln(a) {
        var b = Math.pow(10, 2);
        return Math.round(a * b) / b
    };

    function Mn(a, b, c, d) {
        var e = Object.keys(c).map(function(k) {
                return k
            }),
            f = e.filter(function(k) {
                var h = c[k];
                k = d[k];
                return h instanceof Z && k instanceof Z && h.value === k.value
            }),
            g = f.reduce(function(k, h) {
                var l = {};
                return Object.assign({}, k, (l[h] = c[h], l))
            }, {});
        return e.reduce(function(k, h) {
            if (0 <= f.indexOf(h)) return k;
            var l = {};
            return Object.assign({}, k, (l[h] = b.g(X(function(m) {
                return (m = m ? c[h] : d[h]) && (m instanceof L || "function" === typeof m.Pb && "function" === typeof m.subscribe) ? m : m.O(a)
            })), l))
        }, g)
    };

    function Nn(a) {
        return K(P(function() {
            return !0
        }), W(!1), Y(a, 1))
    };

    function On(a) {
        return 0 >= a.length ? rc : S(a.map(function(b) {
            var c = 0;
            return b.g(P(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(T(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), P(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function Pn(a, b) {
        a.Ia && (a.tb = a.Ia);
        a.Ia = b;
        a.tb && a.tb.value ? (b = Math.max(0, ne(b.timestamp, a.tb.timestamp)), a.totalTime += b, a.oa += b) : a.oa = 0;
        return a
    }

    function Qn() {
        return K( of (Pn, {
            totalTime: 0,
            oa: 0
        }), P(function(a) {
            return a.totalTime
        }))
    }

    function Rn() {
        return K( of (Pn, {
            totalTime: 0,
            oa: 0
        }), P(function(a) {
            return a.oa
        }))
    };

    function Sn(a, b) {
        return K(Vm("data-google-av-metadata"), P(function(c) {
            if (null === c) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            return 0 === c.length ? b(void 0) : b(c[0].slice(1).join("="))
        }))
    };
    var Tn = {
        lj: "asmreq",
        mj: "asmres"
    };
    var Un = function(a) {
        rm.call(this, a)
    };
    x(Un, rm);
    Un.prototype.tg = function(a) {
        Pk(this, a)
    };
    Un.Ba = "tagging.common.osd.AdSpeedMetricsRequest";
    Un.makeCrossSerializerComparisonsCompatible = sm(Un, [0, im]);
    var Vn = function(a) {
        rm.call(this, a)
    };
    x(Vn, rm);
    Vn.Ba = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var Wn = [0, em, -3];
    Vn.makeCrossSerializerComparisonsCompatible = sm(Vn, Wn);
    var Xn = function(a) {
        rm.call(this, a)
    };
    x(Xn, rm);
    Xn.prototype.tg = function(a) {
        Pk(this, a)
    };
    var Yn = function(a) {
        return function(b) {
            cb(a);
            if (null == b || "" == b) b = fb(new a, Tk);
            else {
                bb(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("ia`" + La(b) + "`" + b);
                Qi(b, 32);
                b = dk(a, b)
            }
            return b
        }
    }(Xn);
    Xn.Ba = "tagging.common.osd.AdSpeedMetricsResponse";
    Xn.makeCrossSerializerComparisonsCompatible = sm(Xn, [0, im, fm, Wn, em, -1]);

    function Zn(a, b) {
        var c = void 0 === c ? Lm(a) : c;
        var d = new MessageChannel;
        b = b.g(P(function(f) {
            return Number(f)
        }), T(function(f) {
            return !isNaN(f) && 0 !== f
        }), If(function(f) {
            var g = new Un;
            g.tg(f);
            f = {
                type: "asmreq",
                payload: g.hb()
            };
            c.postMessage(f, "*", [d.port2])
        }), Te(1));
        var e = Mm(a, d.port1).g(T(function(f) {
                return "object" === typeof f.data
            }), P(function(f) {
                var g = f.data,
                    k = Object.values(Tn).includes(g.type);
                g = "string" === typeof g.payload;
                if (!k || !g || "asmres" !== f.data.type) return null;
                try {
                    return Yn(f.data.payload)
                } catch (h) {
                    return null
                }
            }),
            T(function(f) {
                return null !== f
            }), P(function(f) {
                return f
            }));
        return b.g(X(function(f) {
            return N(f).g(Fe(e))
        }), T(function(f) {
            var g = t(f);
            f = g.next().value;
            g = g.next().value;
            if (null != Tj(tk(g, 1))) {
                var k = void 0 === k ? 0 : k;
                k = Jk(Tj(tk(g, 1)), k) === f
            } else k = !1;
            return k
        }), P(function(f) {
            f = t(f);
            f.next();
            return f.next().value
        }), Ih(a.h))
    };

    function $n(a, b, c) {
        var d = b.rc.g(Te(1), X(function() {
            return Zn(a, c)
        }), T(function(f) {
            return Kk(f, 2) && xk(f, Vn, 3) && null != Rj(tk(f, 4)) && null != Rj(tk(f, 5))
        }), Te(1), Ih(a.h));
        b = d.g(P(function(f) {
            return {
                x: Lk(Fk(f, Vn, 3), 2),
                y: Lk(Fk(f, Vn, 3), 1)
            }
        }), V(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), Y(a.h, 1));
        var e = d.g(P(function(f) {
            return Lk(f, 4)
        }), Y(a.h, 1));
        d = d.g(P(function(f) {
            return Lk(f, 5)
        }), Y(a.h, 1));
        return {
            Mh: e,
            Zg: b,
            Zh: d
        }
    };

    function ao(a, b) {
        return b.rc.g(Te(1), P(function() {
            return a.i.now().round()
        }))
    };
    var bo = P(function(a) {
        return [a.value.M.width, a.value.M.height]
    });

    function co(a, b) {
        return function(c) {
            return On(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function eo() {
        var a;
        return K(If(function(b) {
            return void(a = b.timestamp)
        }), Rn(), P(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var fo = function(a, b) {
            this.uf = a;
            this.options = b;
            this.xe = this.we = null
        },
        go = function(a, b) {
            b ? a.xe || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.xe = new IntersectionObserver(a.uf, b)) : a.we || (a.we = new IntersectionObserver(a.uf, a.options))
        },
        ho = function(a, b) {
            a = b ? a.xe : a.we;
            if (!a) throw new Zd;
            return a
        };
    fo.prototype.observe = function(a, b) {
        ho(this, a).observe(b)
    };
    fo.prototype.unobserve = function(a, b) {
        ho(this, a).unobserve(b)
    };
    fo.prototype.disconnect = function(a) {
        ho(this, a).disconnect()
    };
    fo.prototype.takeRecords = function(a) {
        return ho(this, a).takeRecords()
    };
    var io = {
        Y: "ns",
        aa: oi,
        M: oi,
        X: new M,
        P: "ns",
        G: oi,
        S: oi,
        ca: {
            x: 0,
            y: 0
        }
    };

    function jo(a, b) {
        return pi(a.M, b.M) && pi(a.G, b.G) && pi(a.aa, b.aa) && pi(a.S, b.S) && a.P === b.P && a.X === b.X && a.Y === b.Y && a.ca.x === b.ca.x && a.ca.y === b.ca.y
    };
    var ko = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function lo(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g(rf(new M), Dc());
                d = c.element.g(V());
                e = e.g(P(function(f) {
                    return f.value
                }));
                return S([d, e, b]).g(P(function(f) {
                    var g = t(f);
                    f = g.next().value;
                    var k = g.next().value;
                    g = g.next().value;
                    if (void 0 === f.j) var h = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        h = f.j.getBoundingClientRect();
                        var l = f.j,
                            m = a.global,
                            r = new qh(0, 0);
                        var q = (q = th(l)) ? q.parentWindow || q.defaultView : window;
                        if (bh(q, "parent")) {
                            do {
                                if (q == m) {
                                    var v = l,
                                        w = th(v);
                                    db(v, "Parameter is required");
                                    var A = new qh(0,
                                        0);
                                    var D = w ? th(w) : document;
                                    D = !dh || 9 <= Number(ph) || "CSS1Compat" == uh(D).Gb.compatMode ? D.documentElement : D.body;
                                    v != D && (v = ko(v), w = vh(uh(w).Gb), A.x = v.left + w.x, A.y = v.top + w.y)
                                } else A = z(l), A = ko(A), A = new qh(A.left, A.top);
                                r.x += A.x;
                                r.y += A.y
                            } while (q && q != m && q != q.parent && (l = q.frameElement) && (q = q.parent))
                        }
                        h = {
                            top: r.y,
                            left: r.x,
                            width: h.width,
                            height: h.height
                        }
                    }
                    h = ri(h, k.ca);
                    m = qi(h, k.aa);
                    r = a.i.now();
                    q = Object;
                    l = q.assign;
                    if (2 !== g || a.Mb || 0 >= m.width || 0 >= m.height) var C = !1;
                    else try {
                        var R = a.document.elementFromPoint(m.left + m.width /
                            2, m.top + m.height / 2);
                        C = R ? !mo(R, f) : !1
                    } catch (pa) {
                        C = !1
                    }
                    return {
                        timestamp: r,
                        value: l.call(q, {}, k, {
                            P: "geo",
                            S: C ? io.S : m,
                            G: h
                        })
                    }
                }), Ih(a.h))
            }
        }
    }

    function mo(a, b, c) {
        c = void 0 === c ? 0 : c;
        return void 0 === a.j || void 0 === b.j ? !1 : a.j === b.j || xh(b.j, function(d) {
            return d === a.j
        }) ? !0 : b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView === b.j.ownerDocument.defaultView.top ? !1 : 10 > c && b.j.ownerDocument && b.j.ownerDocument.defaultView && b.j.ownerDocument.defaultView.frameElement ? mo(a, new Xh(b.j.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function no(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? oo(a) : po(a), wf(1), Dc())
        }
    }

    function oo(a) {
        return function(b) {
            return b.g(X(function(c) {
                var d = a.ResizeObserver;
                if (!d || void 0 === c.j) return N(io.G);
                var e = (new L(function(f) {
                    function g() {
                        void 0 !== c.j && k.unobserve(c.j);
                        k.disconnect();
                        h.unsubscribe()
                    }
                    if (void 0 === c.j) return f.complete(),
                        function() {};
                    var k = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    k.observe(c.j);
                    var h = c.released.subscribe(g);
                    return g
                })).g(Sg(a.B, 736), P(function(f) {
                    return f.contentRect
                }));
                return td(N(c.j.getBoundingClientRect()), e)
            }), V(pi))
        }
    }

    function po(a) {
        return function(b) {
            var c = b.g(zn(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.ui;
            c = td(b.g(P(function() {
                return Wh("resize")
            })), c, d);
            return S(b, c).g(Sg(a.B, 737), P(function(e) {
                e = t(e).next().value;
                return void 0 === e.j ? void 0 : e.j.getBoundingClientRect()
            }), cn(), V(pi))
        }
    };

    function qo(a, b) {
        var c = ro(a, b).g(wf(1), Dc());
        return function(d) {
            return function(e) {
                e = e.g(X(function(f) {
                    return f.element
                }), V());
                return S([c, e]).g(X(function(f) {
                    var g = t(f);
                    f = g.next().value;
                    g = g.next().value;
                    return so(a, f.Rh, no(a), f.oi, d, f.Ch, g)
                }), Ih(a.h))
            }
        }
    }

    function to(a, b, c) {
        var d = qo(a, c)(b);
        return function(e) {
            var f = d(N(e));
            return function(g) {
                return S([g, f]).g(P(function(k) {
                    var h = t(k);
                    k = h.next().value;
                    h = h.next().value;
                    var l = ri(h.value.G, k.value.ca),
                        m = qi(ri(h.value.S, k.value.ca), k.value.aa);
                    return {
                        timestamp: k.timestamp.maximum(h.timestamp),
                        value: Object.assign({}, k.value, {
                            P: "nio",
                            S: m,
                            G: l
                        })
                    }
                }))
            }
        }
    }

    function uo(a) {
        return P(function(b) {
            return "nio" !== b.value.Y ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    aa: Nm(a, !0),
                    M: Nm(a, !0)
                })
            })
        })
    }

    function vo(a, b) {
        return N(b).g(a, P(function() {
            return b
        }))
    }

    function ro(a, b) {
        return a.i.timeline !== je ? wc(new Wd(2)) : a.MutationObserver ? "undefined" === typeof IntersectionObserver ? wc(new Wd(0)) : (new L(function(c) {
            var d = new M,
                e = new fo(d.next.bind(d), {
                    threshold: [].concat(u(b))
                });
            c.next({
                oi: d.g(Sg(a.B, 735)),
                Rh: e,
                Ch: function(f) {
                    f = e.takeRecords(f);
                    0 < f.length && d.next(f)
                }
            })
        })).g(Te(1), wf(1), Dc()) : wc(new Wd(1))
    }

    function wo(a) {
        return fd(a.sort(function(b, c) {
            return b.time - c.time
        }))
    }

    function so(a, b, c, d, e, f, g) {
        return new L(function(k) {
            function h() {
                w || (w = !0, void 0 !== g.j && b.unobserve(e, g.j), m.unsubscribe(), v.unsubscribe(), q.unsubscribe(), A.unsubscribe())
            }
            if (void 0 !== g.j) {
                go(b, e);
                b.observe(e, g.j);
                var l = new qc({
                        timestamp: a.i.now(),
                        value: Object.assign({}, io, {
                            Y: "nio",
                            P: "nio"
                        })
                    }),
                    m = d.g(id(function(D) {
                        return wo(D)
                    }), T(function(D) {
                        return D.target === g.j
                    }), P(function(D) {
                        return {
                            timestamp: new le(D.time, je),
                            value: {
                                Y: "nio",
                                aa: D.rootBounds || oi,
                                M: D.rootBounds || Nm(a, !0),
                                X: r,
                                P: "nio",
                                S: D.intersectionRect,
                                G: D.boundingClientRect,
                                ca: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: D.isIntersecting,
                                bg: D.isVisible
                            }
                        }
                    }), rf(l), Dc()).subscribe(k),
                    r = new M,
                    q = r.subscribe(function() {
                        f(e);
                        k.next({
                            timestamp: a.i.now(),
                            value: l.value.value
                        });
                        void 0 !== g.j && (b.unobserve(e, g.j), b.observe(e, g.j))
                    }),
                    v = vo(c, g).subscribe(function() {
                        r.next()
                    }),
                    w = !1,
                    A = g.released.subscribe(function() {
                        return h()
                    });
                return h
            }
        })
    };

    function xo(a, b) {
        var c = a.le().g(P(function() {
            return "b"
        }));
        return yd(b, c).g(Te(1), Y(a.h, 1))
    };

    function yo(a) {
        return function(b) {
            var c;
            return b.g(If(function(d) {
                return void(c = d.timestamp)
            }), P(function(d) {
                return d.value
            }), a, P(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };
    var zo = function(a) {
            return a.S.width * a.S.height / (a.G.width * a.G.height)
        },
        Ao = yo(K(P(function(a) {
            var b;
            return null != (b = a.Zc) ? b : zo(a)
        }), P(function(a) {
            return isFinite(a) ? a : 0
        }))),
        Bo = yo(K(P(function(a) {
            var b;
            return null != (b = a.Zc) ? b : zo(a)
        }), P(function(a) {
            return isFinite(a) ? a : -1
        })));
    var Co = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    Co.prototype.ha = function(a) {
        return a instanceof Co ? this.a.ha(a.a) && this.b.ha(a.b) : !1
    };
    Co.prototype.pa = function(a) {
        var b = this.a.pa(a).value,
            c = this.b.pa(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    da.Object.defineProperties(Co.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        A: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.A.timestamp.maximum(this.b.A.timestamp),
                    b = this.a.A.timestamp.equals(a) ? this.a.A.value : this.a.pa(a).value,
                    c = this.b.A.timestamp.equals(a) ? this.b.A.value : this.b.pa(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var Do = function(a, b) {
        this.input = a;
        this.pd = b;
        this.A = {
            timestamp: this.input.A.timestamp,
            value: this.pd(this.input.A.value)
        }
    };
    Do.prototype.ha = function(a) {
        return a instanceof Do ? this.input.ha(a.input) && this.pd === a.pd : !1
    };
    Do.prototype.pa = function(a) {
        a = this.input.pa(a);
        return {
            timestamp: a.timestamp,
            value: this.pd(a.value)
        }
    };
    da.Object.defineProperties(Do.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function Eo(a, b, c) {
        c = void 0 === c ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var Fo = function(a, b, c) {
        this.clock = a;
        this.A = b;
        this.active = c
    };
    Fo.prototype.ha = function(a) {
        return a instanceof Fo ? this.active === a.active && this.clock.timeline === a.clock.timeline && Eo(this.A, a.A) : !1
    };
    Fo.prototype.pa = function(a) {
        return {
            timestamp: a,
            value: this.A.value + (this.active ? Math.max(0, ne(a, this.A.timestamp)) : 0)
        }
    };
    var Go = function() {};
    Go.prototype.ia = function() {
        return this.pa(this.clock.now())
    };
    Go.prototype.qa = function(a) {
        var b = this.clock.timeline,
            c, d = null != (c = a.get(b)) ? c : this.clock.now();
        a.set(b, d);
        return this.pa(d)
    };
    Go.prototype.map = function(a) {
        return new Ho(this, a)
    };
    Go.prototype.sa = function(a) {
        return new Io(this, a)
    };
    var Io = function() {
        Co.apply(this, arguments);
        this.map = Go.prototype.map;
        this.sa = Go.prototype.sa;
        this.ia = Go.prototype.ia;
        this.qa = Go.prototype.qa
    };
    x(Io, Co);
    var Jo = function() {
        Fo.apply(this, arguments);
        this.map = Go.prototype.map;
        this.sa = Go.prototype.sa;
        this.ia = Go.prototype.ia;
        this.qa = Go.prototype.qa
    };
    x(Jo, Fo);
    var Ho = function() {
        Do.apply(this, arguments);
        this.map = Go.prototype.map;
        this.sa = Go.prototype.sa;
        this.ia = Go.prototype.ia;
        this.qa = Go.prototype.qa
    };
    x(Ho, Do);

    function Ko(a, b) {
        a.Ia && (a.tb = a.Ia);
        a.Ia = b;
        a.tb && a.tb.value ? (b = Math.max(0, ne(b.timestamp, a.tb.timestamp)), a.totalTime += b, a.oa += b) : a.oa = 0;
        return a
    }

    function Lo(a) {
        return K( of (Ko, {
            totalTime: 0,
            oa: 0
        }), P(function(b) {
            return new Jo(a, {
                timestamp: b.Ia.timestamp,
                value: b.totalTime
            }, b.Ia.value)
        }))
    }

    function Mo(a) {
        return K( of (Ko, {
            totalTime: 0,
            oa: 0
        }), P(function(b) {
            return new Jo(a, {
                timestamp: b.Ia.timestamp,
                value: b.oa
            }, b.Ia.value)
        }))
    };

    function No(a) {
        return K(Mo(a), P(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var Oo = function(a, b) {
        this.A = b;
        this.ia = Go.prototype.ia;
        this.qa = Go.prototype.qa;
        this.map = Go.prototype.map;
        this.sa = Go.prototype.sa;
        this.clock = a
    };
    Oo.prototype.ha = function(a) {
        return a.active
    };
    Oo.prototype.pa = function() {
        return this.A
    };
    da.Object.defineProperties(Oo.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function Po(a, b) {
        return b.g(P(function(c) {
            return new Oo(a.i, {
                timestamp: a.i.now(),
                value: c
            })
        }))
    };

    function Qo(a, b) {
        return 1 <= a ? !0 : 0 >= a ? !1 : a >= b
    };

    function Ro(a) {
        return function(b) {
            return b.g(Lf(a), P(function(c) {
                var d = t(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: Qo(c.value, d)
                }
            }))
        }
    };
    var So = P(function(a) {
        if ("omid" === a.value.Y) {
            if ("nio" === a.value.P) return "omio";
            if ("geo" === a.value.P) return "omgeo"
        }
        return "geo" === a.value.P || "nio" === a.value.P ? a.value.Y : a.value.P
    });

    function To() {
        return K(T(function(a, b) {
            return 0 < b
        }), Uo, W(-1), V())
    }
    var Uo = K(T(function(a) {
        return !isNaN(a)
    }), of (function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), V());
    var Vo = yo(K(P(function(a) {
        return a.S.width * a.S.height / (a.aa.width * a.aa.height)
    }), P(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function Wo(a, b, c) {
        return a ? S([b, c]).g(T(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), P(function(d) {
            var e = t(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function Xo(a) {
        return function(b) {
            var c = b.g(Ao),
                d = b.g(Vo);
            return a instanceof L ? a.g(X(function(e) {
                return Wo(e, c, d)
            })) : Wo(a.value, c, d)
        }
    };
    var Yo = K(yo(P(function(a) {
        a = a.Zc ? a.Zc * a.G.width * a.G.height / (a.M.width * a.M.height) : a.S.width * a.S.height / (a.M.width * a.M.height);
        return isFinite(a) ? a : 0
    })));

    function Zo(a, b, c, d) {
        var e = d.bd,
            f = d.he,
            g = d.Kg,
            k = d.pf,
            h = d.Ee,
            l = d.fg,
            m = d.dd;
        d = d.Fg;
        b = $o(a, c, b);
        c = ap(a, c);
        d = bp(b, d);
        var r = cp(a, e, l, b),
            q = r.g(P(function(B) {
                return B.value
            }), V(), Y(a, 1), of (function(B, U) {
                return Math.max(B, U)
            }, 0)),
            v = r.g(P(function(B) {
                return B.value
            }), To(), Y(a, 1)),
            w = b.g(Bo, P(function(B) {
                return B.value
            }), Te(2), V(), Y(a, 1));
        g = dp(a, b, g, k);
        var A = g.g(W(!1), V(), P(function(B) {
            return B ? h : f
        }));
        k = r.g(Ro(A), V(), Y(a, 1));
        var D = S([k, b]).g(T(function(B) {
                var U = t(B);
                B = U.next().value;
                U = U.next().value;
                return B.timestamp.equals(U.timestamp)
            }),
            P(function(B) {
                var U = t(B);
                B = U.next().value;
                U = U.next().value;
                return {
                    visible: B.value,
                    geometry: U.value.G
                }
            }), of (function(B, U) {
                return !U.visible && B.visible ? B : U
            }, {
                visible: !1,
                geometry: oi
            }), P(function(B) {
                return B.geometry
            }), W(oi), Y(a, 1), V(pi));
        l = l instanceof L ? l.g(V(), lf()) : vd;
        A = S([l, A]).g(lf());
        var C = b.g(T(function(B) {
                return "ns" !== B.value.Y && "ns" !== B.value.P
            }), of (function(B) {
                return B + 1
            }, 0), W(0), Y(a, 1)),
            R = c.g(lf(!0), W(!1), Y(a, 1));
        R = S([m, R]).g(P(function(B) {
            var U = t(B);
            B = U.next().value;
            U = U.next().value;
            return B &&
                !U
        }), Y(a, 1));
        var pa = b.g(Yo, V()),
            ia = pa.g(P(function(B) {
                return B.value
            }), of (function(B, U) {
                return Math.max(B, U)
            }, 0), V(), Y(a, 1)),
            E = pa.g(P(function(B) {
                return B.value
            }), To(), Y(a, 1));
        return {
            Se: l,
            Dc: A,
            Aa: {
                Fi: b,
                gg: b.g(So),
                Wc: D.g(V(pi)),
                visible: k.g(V(Eo)),
                Ve: r.g(V(Eo)),
                eg: q,
                ii: v,
                sf: b.g(bo, V(nb)),
                dj: pa,
                bi: ia,
                hi: E,
                ad: c,
                X: (new Z(new M)).O(a),
                Zf: g,
                bd: e,
                dd: m,
                Lf: R,
                fj: C,
                Yh: w,
                Dd: d
            }
        }
    }

    function ap(a, b) {
        return b.g(T(function() {
            return !1
        }), P(function(c) {
            return c
        }), De(function(c) {
            return (new Z(c)).O(a)
        }))
    }

    function bp(a, b) {
        a = S([a, b]).g(P(function(d) {
            d = t(d);
            var e = d.next().value;
            if (d.next().value && e.value.isIntersecting) return e.value.bg
        }), V());
        b = a.g(P(function(d) {
            return void 0 === d ? !0 : d
        }), of (function(d, e) {
            return d || !e
        }, !1));
        var c = a.g( of (function(d, e) {
            return void 0 === e ? d : e ? !1 : null != d ? d : !0
        }, void 0), P(function(d) {
            return !!d
        }));
        return Bd(a, b, c).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            var g = 0;
            if (void 0 === d) return 0;
            d && (g |= 1);
            d || (g |= 2);
            f && (g |= 4);
            e && (g |= 8);
            return g
        }))
    }

    function $o(a, b, c) {
        return b.g(sf(vd), Y(a, 1)).g(V(function(d, e) {
            return Eo(d, e, jo)
        }), W({
            timestamp: c.now(),
            value: io
        }), Y(a, 1))
    }

    function cp(a, b, c, d) {
        c = d.g(Xo(c), yo(P(function(e) {
            return Ln(e)
        })), Y(a, 1));
        return b instanceof Z ? c : S([c, b]).g(P(function(e) {
            var f = t(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), V(Eo), Y(a, 10))
    }

    function dp(a, b, c, d) {
        b = [b.g(P(function(e) {
            return 242500 <= e.value.G.width * e.value.G.height
        }))];
        c instanceof L && b.push(c.g(P(function(e) {
            return !!e
        })));
        c = S(b);
        return d ? c.g(P(function(e) {
            return e.some(function(f) {
                return f
            })
        }), W(!1), V(), Y(a, 1)) : (new Z(!1)).O(a)
    };
    var ep = function(a) {
            this.i = a;
            this.Ad = null;
            this.timeout = new M
        },
        gp = function(a, b) {
            fp(a);
            a.Ad = a.i.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        fp = function(a) {
            null !== a.Ad && (a.i.clearTimeout(a.Ad), a.Ad = null)
        };

    function hp(a, b, c, d) {
        var e = ip.Bg,
            f = new ep(b);
        c = c.g(W(void 0), X(function() {
            fp(f);
            return d
        })).g(P(function(g) {
            fp(f);
            var k = g.A,
                h = g.active;
            k.value >= e || !h || (h = b.now(), h = Math.max(0, ne(h, k.timestamp)), gp(f, Math.max(0, e - k.value - h)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return S([c, td(f.timeout, N(void 0))]).g(P(function(g) {
            return t(g).next().value
        }), Ff(function(g) {
            return !g.ia().value
        }, !0), Y(a, 1))
    };

    function jp(a) {
        var b = new Jo(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return K(Mo(a), of (function(c, d) {
            return c.A.value > d.A.value ? new Jo(a, c.A, !1) : d
        }, b), P(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function kp(a) {
        return function(b) {
            return K(Ro(N(b)), jp(a))
        }
    };

    function lp(a) {
        return function(b) {
            return K(yo(P(function(c) {
                return Qo(c, b)
            })), Lo(a), P(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function mp(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.sa(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function np(a, b) {
        return a.sa(b).map(function(c) {
            var d = t(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function op(a, b, c, d, e, f) {
        var g = pp;
        if (1 < g.length)
            for (var k = 0; k < g.length - 1; k++)
                if (g[k] < g[k + 1]) throw Error();
        k = f.g(W(void 0), X(function() {
            return d.g(No(a))
        }), V(function(h, l) {
            return h.ha(l)
        }), Y(b, 1));
        f = f.g(W(void 0), X(function() {
            return d.g(jp(a))
        }), V(function(h, l) {
            return h.ha(l)
        }), Y(b, 1));
        return {
            uc: e.g(W(void 0), X(function() {
                return c.g(co(kp(a), g))
            }), P(mp), V(function(h, l) {
                return h.ha(l)
            }), Y(b, 1)),
            Gc: e.g(W(void 0), X(function() {
                return c.g(co(lp(a), g), P(function(h) {
                    return h.map(function(l, m) {
                        return 0 < m ?
                            np(l, h[m - 1]) : l
                    })
                }))
            }), P(mp), V(function(h, l) {
                return h.ha(l)
            }), Y(b, 1)),
            tc: f,
            lb: k.g(V(function(h, l) {
                return h.ha(l)
            }), Y(b, 1))
        }
    };

    function qp(a) {
        var b;
        if (b = rp(a)) b = !sp(a, "abgcp") && !sp(a, "abgc") && !("string" === typeof a.id && "abgb" === a.id) && !("string" === typeof a.id && "mys-abgc" === a.id) && !sp(a, "cbb");
        return b
    }

    function sp(a, b) {
        return a.classList ? a.classList.contains(b) : -1 < (" " + a.className + " ").indexOf(" " + b + " ")
    }

    function rp(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && 30 <= b.height && 30 <= b.width
        } catch (c) {
            return !1
        }
    }

    function tp(a, b) {
        if (void 0 === a.j || !a.j.children) return a;
        for (var c = mb(a.j.children); c.length;) {
            var d = b ? c.filter(qp) : c.filter(rp);
            if (1 === d.length) return new Xh(d[0]);
            if (1 < d.length) break;
            c = pb(c, function(e) {
                return mb(e.children)
            })
        }
        return a
    }

    function up(a, b, c, d, e) {
        if (c) return {
            Vc: b,
            vb: N(null)
        };
        c = b.element.g(P(function(f) {
            a: if (void 0 === f.j || rp(f.j)) f = {
                    qd: f,
                    vb: "mue"
                };
                else {
                    var g = tp(f, e);
                    if (void 0 !== g.j && rp(g.j)) f = {
                        qd: g,
                        vb: "ie"
                    };
                    else {
                        if (d || a.te)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    qd: new Xh(g),
                                    vb: "ce"
                                };
                                break a
                            }
                        f = {
                            qd: f,
                            vb: "mue"
                        }
                    }
                }return f
        }), zf());
        return {
            Vc: {
                xb: b.xb,
                element: c.g(P(function(f) {
                    return f.qd
                }))
            },
            vb: c.g(P(function(f) {
                return f.vb
            }))
        }
    };

    function vp(a, b, c, d) {
        var e = d.bd,
            f = d.he,
            g = d.Kg,
            k = d.pf,
            h = d.Ee,
            l = d.fg,
            m = d.dd;
        d = d.Fg;
        b = wp(a, c, b);
        c = xp(a, c);
        d = yp(b, d);
        var r = zp(a, e, l, b),
            q = r.g(P(function(E) {
                return E.value
            }), V(), Y(a, 1), of (function(E, B) {
                return Math.max(E, B)
            }, 0)),
            v = r.g(P(function(E) {
                return E.value
            }), To(), Y(a, 1)),
            w = b.g(Bo, P(function(E) {
                return E.value
            }), Te(2), V(), Y(a, 1));
        g = Ap(a, b, g, k);
        var A = g.g(W(!1), V(), P(function(E) {
            return E ? h : f
        }));
        k = r.g(Ro(A), V(), Y(a, 1));
        var D = S([k, b]).g(T(function(E) {
                var B = t(E);
                E = B.next().value;
                B = B.next().value;
                return E.timestamp.equals(B.timestamp)
            }),
            P(function(E) {
                var B = t(E);
                E = B.next().value;
                B = B.next().value;
                return {
                    visible: E.value,
                    geometry: B.value.G
                }
            }), of (function(E, B) {
                return !B.visible && E.visible ? E : B
            }, {
                visible: !1,
                geometry: oi
            }), P(function(E) {
                return E.geometry
            }), W(oi), Y(a, 1), V(pi));
        l = l instanceof L ? l.g(V(), lf()) : vd;
        A = S([l, A]).g(lf());
        var C = b.g(T(function(E) {
                return "ns" !== E.value.Y && "ns" !== E.value.P
            }), of (function(E) {
                return E + 1
            }, 0), W(0), Y(a, 1)),
            R = c.g(lf(!0), W(!1), Y(a, 1));
        R = S([m, R]).g(P(function(E) {
            var B = t(E);
            E = B.next().value;
            B = B.next().value;
            return E &&
                !B
        }), Y(a, 1));
        var pa = b.g(Yo, V()),
            ia = pa.g(P(function(E) {
                return E.value
            }), of (function(E, B) {
                return Math.max(E, B)
            }, 0), V(), Y(a, 1));
        a = pa.g(P(function(E) {
            return E.value
        }), To(), Y(a, 1));
        return {
            Se: l,
            Dc: A,
            Aa: {
                Fi: b,
                gg: b.g(So),
                Wc: D.g(V(pi)),
                visible: k.g(V(Eo)),
                Ve: r.g(V(Eo)),
                eg: q,
                ii: v,
                sf: b.g(bo, V(nb)),
                dj: pa,
                bi: ia,
                hi: a,
                ad: c,
                X: b.g(P(function(E) {
                    return E.value.X
                })),
                Zf: g,
                bd: e,
                dd: m,
                Lf: R,
                fj: C,
                Yh: w,
                Dd: d
            }
        }
    }

    function xp(a, b) {
        return b.g(T(function() {
            return !1
        }), P(function(c) {
            return c
        }), De(function(c) {
            return (new Z(c)).O(a)
        }))
    }

    function wp(a, b, c) {
        return b.g(sf(vd), Y(a, 1)).g(V(function(d, e) {
            return Eo(d, e, jo)
        }), W({
            timestamp: c.now(),
            value: io
        }), Y(a, 1))
    }

    function zp(a, b, c, d) {
        c = d.g(Xo(c), yo(P(function(e) {
            return Ln(e)
        })), Y(a, 1));
        return b instanceof Z ? c : S([c, b]).g(P(function(e) {
            var f = t(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), V(Eo), Y(a, 1))
    }

    function Ap(a, b, c, d) {
        b = [b.g(P(function(e) {
            return 242500 <= e.value.G.width * e.value.G.height
        }))];
        c instanceof L && b.push(c.g(P(function(e) {
            return !!e
        })));
        c = S(b);
        return d ? c.g(P(function(e) {
            return e.some(function(f) {
                return f
            })
        }), W(!1), V(), Y(a, 1)) : (new Z(!1)).O(a)
    }

    function yp(a, b) {
        a = S([a, b]).g(P(function(d) {
            d = t(d);
            var e = d.next().value;
            if (d.next().value && e.value.isIntersecting) return e.value.bg
        }), V());
        b = a.g(P(function(d) {
            return void 0 === d ? !0 : d
        }), of (function(d, e) {
            return d || !e
        }, !1));
        var c = a.g( of (function(d, e) {
            return void 0 === e ? d : e ? !1 : null != d ? d : !0
        }, void 0), P(function(d) {
            return !!d
        }));
        return Bd(a, b, c).g(P(function(d) {
            var e = t(d);
            d = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            var g = 0;
            if (void 0 === d) return 0;
            d && (g |= 1);
            d || (g |= 2);
            f && (g |= 4);
            e && (g |= 8);
            return g
        }))
    };
    var Bp = K(Vm("data-google-av-itpl"), P(function(a) {
        return Number(a)
    }), P(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var Cp = {
            kj: "addEventListener",
            tj: "getMaxSize",
            uj: "getScreenSize",
            vj: "getState",
            wj: "getVersion",
            Hj: "removeEventListener",
            Dj: "isViewable"
        },
        Dp = function(a, b) {
            this.wa = null;
            this.Ph = new M;
            b = b || this.gj;
            var c = a.te,
                d = !a.Mb;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.Uc = b(e);
                    this.wa = e;
                    this.wb = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.Uc = b(a), this.wa = a, this.wb = c ? d ? 2 : 1 : 0) : (this.wb = -1, this.Uc = 2)
        };
    Dp.prototype.addEventListener = function(a, b) {
        return this.Wb("addEventListener", a, b)
    };
    Dp.prototype.removeEventListener = function(a, b) {
        return this.Wb("removeEventListener", a, b)
    };
    Dp.prototype.Mf = function() {
        var a = this.Wb("getVersion");
        return "string" === typeof a ? a : ""
    };
    Dp.prototype.getState = function() {
        var a = this.Wb("getState");
        return "string" === typeof a ? a : ""
    };
    var Ep = function(a) {
            a = a.Wb("isViewable");
            return "boolean" === typeof a ? a : !1
        },
        Fp = function(a) {
            if (a.wa) return a = a.wa.AFMA_LIDAR, "string" === typeof a ? a : void 0
        };
    Dp.prototype.gj = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(Cp).every(function(b) {
            return "function" === typeof a[b]
        }) ? 0 : 1 : 2 : 1
    };
    Dp.prototype.Wb = function(a) {
        var b = y.apply(1, arguments);
        if (this.wa) try {
            return this.wa[a].apply(this.wa, u(b))
        } catch (c) {
            this.Ph.next(a)
        }
    };
    da.Object.defineProperties(Dp.prototype, {
        Af: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.wa) {
                    var a = this.wa.AFMA_LIDAR_EXP_1;
                    return void 0 === a ? void 0 : !!a
                }
            },
            set: function(a) {
                this.wa && (this.wa.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function Gp(a, b) {
        return -1 !== (new Dp(a)).wb ? (new Z(!0)).O(a.h) : b.g(Vm("data-google-av-inapp"), P(function(c) {
            return null !== c
        }), Y(a.h, 1))
    };
    var Ip = function(a, b) {
            var c = this;
            this.i = a;
            this.Fe = this.nd = null;
            this.Ji = b.g(V()).subscribe(function(d) {
                Hp(c);
                c.Fe = d
            })
        },
        Jp = function(a, b) {
            Hp(a);
            a.nd = a.i.setTimeout(function() {
                var c;
                return void(null == (c = a.Fe) ? void 0 : c.next())
            }, b)
        },
        Hp = function(a) {
            null !== a.nd && a.i.clearTimeout(a.nd);
            a.nd = null
        };
    Ip.prototype.V = function() {
        Hp(this);
        this.Ji.unsubscribe();
        this.Fe = null
    };

    function Kp(a, b, c, d, e) {
        var f = ip.Bg;
        var g = void 0 === g ? new Ip(b, d) : g;
        return (new L(function(k) {
            var h = c.g(W(void 0), X(function() {
                return Lp(e)
            })).g(P(function(l) {
                var m = l.value;
                l = l.timestamp;
                var r = m.visible;
                m = m.lb;
                var q = m >= f;
                q || !r ? Hp(g) : (l = Math.max(0, ne(b.now(), l)), Jp(g, Math.max(0, f - m - l)));
                return q
            }), of (function(l, m) {
                return m || l
            }, !1), V()).subscribe(k);
            return function() {
                g.V();
                h.unsubscribe()
            }
        })).g(Ff(function(k) {
            return !k
        }, !0), Y(a, 1))
    }

    function Lp(a) {
        return On([a, a.g(eo())]).g(P(function(b) {
            var c = t(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    lb: c.value
                }
            }
        }), V(function(b, c) {
            return Eo(b, c, function(d, e) {
                return d.lb === e.lb && d.visible === e.visible
            })
        }))
    };

    function Mp(a, b) {
        return {
            Qd: b.g(Vm("data-google-av-adk")),
            Rc: b.g(Vm("data-google-av-btr"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            Yd: b.g(Vm("data-google-av-cpmav"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            cf: b.g(Vm("data-google-av-vrus"), V(), P(function(c) {
                return null === c ? [] : c.split("|").filter(function(d) {
                    return "" !== d
                })
            })),
            mh: Bn(a, b),
            flags: b.g(Vm("data-google-av-flags"), V()),
            ab: Gp(a, b),
            ye: b.g(Sn("cr", function(c) {
                return "1" ===
                    c
            }), V()),
            Vh: b.g(Sn("omid", function(c) {
                return "1" === c
            }), V()),
            ve: b.g(Bp),
            metadata: b.g(Vm("data-google-av-metadata")),
            Ta: b.g(bn),
            Fa: b.g(Wm),
            jj: b.g(Sn("la", function(c) {
                return "1" === c
            }), V()),
            pb: b.g(Vm("data-google-av-turtlex"), P(function(c) {
                return null !== c
            }), V()),
            Ce: b.g(Vm("data-google-av-vattr"), P(function(c) {
                return null !== c
            }), V())
        }
    };

    function Np() {
        return K(Rn(), of (function(a, b) {
            return Math.max(a, b)
        }, 0), P(function(a) {
            return Math.round(a)
        }))
    };

    function Op(a) {
        return K(Ro(N(a)), Np())
    };

    function Pp(a, b, c, d, e) {
        c = c.g(P(function() {
            return !1
        }));
        d = S([e, d]).g(X(function(f) {
            f = t(f).next().value;
            return Qp(b, f)
        }));
        return td(N(!1), c, d).g(V(), Y(a.h, 1))
    }

    function Qp(a, b) {
        return a.g(P(function(c) {
            return b || 0 === c || 2 === c
        }))
    };
    var Rp = [33, 32],
        Sp = K(Bp, P(function(a) {
            return 0 <= Rp.indexOf(a)
        }), V());

    function Tp(a, b, c, d, e, f) {
        var g = c.g(P(function(h) {
                return 9 === h
            })),
            k = b.element.g(Sp);
        c = e.g(T(function(h) {
            return h
        }), X(function() {
            return S([g, k])
        }), P(function(h) {
            h = t(h);
            var l = h.next().value;
            return !h.next().value || l
        }), V());
        f = S([c, d.g(V()), f]).g(P(function(h) {
            var l = t(h);
            h = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return up(a, b, !h, m, l)
        }), wf(1), Dc());
        d = f.g(P(function(h) {
            return h.Vc
        }));
        f = f.g(X(function(h) {
            return h.vb
        }), W(null), V(), Y(a.h, 1));
        return {
            Pa: d,
            ic: f
        }
    };

    function Up(a) {
        var b = void 0 === b ? !1 : b;
        return K(X(function(c) {
            return mi(a.document, c, b)
        }), Y(a.h, 1))
    };
    var Vp = function(a, b, c, d, e, f) {
        this.rc = b.element.g(Up(a), Y(a.h, 1));
        this.vg = Pp(a, c, b.element, this.rc, d);
        c = Tp(a, b, e, d, this.vg, f);
        d = c.ic;
        this.Pa = c.Pa;
        this.ic = d;
        this.df = td((new Z(1)).O(a.h), b.element.g(Te(1), P(function() {
            return 2
        }), Y(a.h, 1)), this.rc.g(Te(1), P(function() {
            return 3
        }), Y(a.h, 1)), this.vg.g(T(Boolean), Te(1), P(function() {
            return 0
        }), Y(a.h, 1))).g(Ff(function(g) {
            return 0 !== g
        }, !0), Y(a.h, 0))
    };

    function Wp(a, b) {
        return a && 0 === b ? 15 : a || 1 !== b ? null : 14
    }

    function Xp(a, b, c) {
        return b instanceof L ? b.g(X(function(d) {
            return (d = Wp(d, c)) ? wc(new Wd(d)) : a
        })) : (b = Wp(b.value, c)) ? wc(new Wd(b)) : a
    };

    function Yp(a) {
        var b = new Wd(13);
        if (1 > a.length) return {
            vf: rc,
            Ud: rc
        };
        var c = new M;
        return {
            vf: a.slice(1).reduce(function(d, e) {
                return d.g(De(function(f) {
                    c.next(f);
                    return e
                }))
            }, a[0]).g(De(function(d) {
                c.next(d);
                return wc(b)
            }), rf(new M), Dc()),
            Ud: c
        }
    };
    var Zp = function() {};
    var $p = function(a, b) {
        this.context = a;
        this.Xi = b
    };
    x($p, Zp);
    $p.prototype.Ya = function(a, b) {
        var c = this.Xi.map(function(f) {
                return f.Ya(a, b)
            }),
            d = Yp(c.map(function(f) {
                return f.Za
            })),
            e = d.Ud.g(aq());
        return {
            Za: d.vf.g(Y(this.context.h, 1)),
            Wa: Object.assign.apply(Object, [{
                Te: e,
                ck: d.Ud
            }].concat(u(c.map(function(f) {
                return f.Wa
            }))))
        }
    };
    var aq = function() {
        return of(function(a, b) {
            b instanceof Wd ? a.push(b.ei) : a.push(-1);
            return a
        }, [])
    };

    function bq(a, b) {
        var c = a.g(rf(new M), Dc());
        return X(function(d) {
            return c.g(b(d))
        })
    };

    function cq(a, b) {
        var c = void 0 === c ? function() {
            var f = (Ah(a.global) ? a.global.innerWidth : 0) || a.me() || 0,
                g = (Ah(a.global) ? a.global.innerHeight : 0) || a.ke() || 0;
            return {
                left: 0,
                top: 0,
                width: f,
                height: g
            }
        } : c;
        var d = a.Mb ? li(a.document) ? a.Uh ? null : wc(new Wd(5)) : wc(new Wd(4)) : wc(new Wd(3));
        if (d) return d;
        var e = new M;
        return td(N({}), b, e).g(P(function() {
            var f = dq(a, c);
            return {
                timestamp: a.i.now(),
                value: {
                    Y: "iem",
                    aa: f,
                    M: f,
                    X: e,
                    ca: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Y(a.h, 1))
    }

    function dq(a, b) {
        b = b();
        var c = vh(document),
            d = function(q, v) {
                return !!a.document.elementFromPoint(q, v)
            },
            e = Math.floor(b.left - c.x),
            f = Math.floor(b.top - c.y),
            g = Math.floor(b.left + b.width - c.x),
            k = Math.floor(b.top + b.height - c.y);
        b = d(e, f);
        c = d(g, k);
        if (b && c) return {
            top: f,
            left: e,
            width: g - e,
            height: k - f
        };
        var h = d(g, f),
            l = d(e, k);
        if (b) k = eq(f, k, function(q) {
            return d(e, q)
        }), g = eq(e, g, function(q) {
            return d(q, f)
        });
        else if (h) k = eq(f, k, function(q) {
            return d(g, q)
        }), e = eq(g, e, function(q) {
            return d(q, f)
        });
        else if (l) f = eq(k, f, function(q) {
            return d(e,
                q)
        }), g = eq(e, g, function(q) {
            return d(q, k)
        });
        else if (c) f = eq(k, f, function(q) {
            return d(g, q)
        }), e = eq(g, e, function(q) {
            return d(q, k)
        });
        else {
            var m = Math.floor((e + g) / 2),
                r = Math.floor((f + k) / 2);
            if (!d(m, r)) return {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            };
            f = eq(r, f, function(q) {
                return d(m, q)
            });
            k = eq(r, k, function(q) {
                return d(m, q)
            });
            e = eq(m, e, function(q) {
                return d(q, r)
            });
            g = eq(m, g, function(q) {
                return d(q, r)
            })
        }
        return {
            top: f,
            left: e,
            width: g - e,
            height: k - f
        }
    }

    function eq(a, b, c) {
        if (c(b)) return b;
        for (var d = 15; d--;) {
            var e = Math.floor((a + b) / 2);
            if (e === a || e === b) break;
            c(e) ? a = e : b = e
        }
        return a
    };
    var fq = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x(fq, Zp);
    fq.prototype.Ya = function(a, b) {
        var c = bq(cq(this.context, this.Ra), lo(this.context, b.Ta));
        return {
            Za: Xp(a.Pa.g(c), b.ab, 0),
            Wa: {}
        }
    };

    function gq(a, b) {
        if (a.Mb) return wc(new Wd(6));
        var c = new M;
        return td(N({}), b, c).g(P(function() {
            return {
                timestamp: a.i.now(),
                value: {
                    Y: "geo",
                    aa: hq(a),
                    M: Nm(a, !0),
                    X: c,
                    ca: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Ih(a.h))
    }

    function hq(a) {
        var b = Nm(a, !1);
        if (!a.te || !Ah(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Km(a.global.parent, a.Ja);
        c.J = a.J;
        c = hq(c);
        a = a.global.frameElement.getBoundingClientRect();
        return qi(ri(qi(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var iq = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x(iq, Zp);
    iq.prototype.Ya = function(a, b) {
        var c = bq(gq(this.context, this.Ra), lo(this.context, b.Ta));
        return {
            Za: Xp(a.Pa.g(c), b.ab, 0),
            Wa: {}
        }
    };
    var jq = function(a, b, c) {
        c = void 0 === c ? qo(a, b) : c;
        this.context = a;
        this.Sh = c
    };
    x(jq, Zp);
    jq.prototype.Ya = function(a, b) {
        var c = this.Sh(b.Hg);
        return {
            Za: Xp(a.Pa.g(c, uo(this.context)), b.ab, 0),
            Wa: {}
        }
    };

    function kq(a, b, c, d, e) {
        var f = void 0 === f ? new Dp(a) : f;
        var g = void 0 === g ? Sf(a.i, 500) : g;
        var k = void 0 === k ? Sf(a.i, 100) : k;
        e = N(f).g(lq(c), If(function(h) {
            d.next(h.wb)
        }), mq(a, k), nq(a), oq(a, e), wf(1), Dc());
        f = new M;
        b = td(N({}), b, f);
        return e.g(pq(a, f, b, g, c), Y(a.h, 1))
    }

    function oq(a, b) {
        return K(function(c) {
            return S([c, b])
        }, Je(function(c) {
            c = t(c);
            var d = c.next().value;
            return 9 !== c.next().value || Ep(d) ? N(!0) : qq(a, d, "viewableChange").g(T(function(e) {
                return t(e).next().value
            }), Te(1))
        }), P(function(c) {
            return t(c).next().value
        }))
    }

    function lq(a) {
        return X(function(b) {
            if (-1 === b.wb) return a.next("if"), wc(new Wd(7));
            if (0 !== b.Uc) switch (b.Uc) {
                case 1:
                    return a.next("mm"), wc(new Wd(18));
                case 2:
                    return a.next("ng"), wc(new Wd(17));
                default:
                    return a.next("i"), wc(new Wd(8))
            }
            return N(b)
        })
    }

    function mq(a, b) {
        return Je(function() {
            var c = a.ig;
            return "complete" === ji(a.document) ? N(!0) : c.g(Je(function() {
                return b
            }))
        })
    }
    var nq = function(a) {
        return X(function(b) {
            return "loading" !== b.getState() ? N(b) : qq(a, b, "ready").g(P(function() {
                return b
            }))
        })
    };

    function pq(a, b, c, d, e) {
        return X(function(f) {
            var g = Fp(f);
            if ("string" !== typeof g) return e.next("nc"), wc(new Wd(9));
            void 0 !== f.Af && (f.Af = !0);
            g = qq(a, f, g, rq);
            var k = {
                version: f.Mf(),
                wb: f.wb
            };
            g = g.g(P(function(l) {
                return sq.apply(null, [a, b, f, k].concat(u(l)))
            }));
            var h = d.g(If(function() {
                e.next("mt")
            }), X(function() {
                return wc(new Wd(10))
            }));
            g = yd(g, h);
            return S([g, c]).g(P(function(l) {
                l = t(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.i.now()
                })
            }))
        })
    }

    function rq(a, b) {
        return (null === b || "number" === typeof b) && (null === a || !!a && "number" === typeof a.height && "number" === typeof a.width && "number" === typeof a.x && "number" === typeof a.y)
    }

    function sq(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : oi;
        c = c.Wb("getMaxSize");
        var g = null != c && "number" === typeof c.width && "number" === typeof c.height ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var k = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(k) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: k,
                height: g
            }
        }
        a = {
            value: {
                aa: e,
                M: c,
                Y: "mraid",
                X: b,
                ca: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.i.now()
        };
        return Object.assign({}, a, d, {
            Mj: f
        })
    }

    function qq(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        return (new L(function(e) {
            var f = a.B.Zb(745, function() {
                e.next(y.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(T(function(e) {
            return d.apply(null, u(e))
        }))
    };
    var tq = function(a, b) {
        this.context = a;
        this.Ra = b
    };
    x(tq, Zp);
    tq.prototype.Ya = function(a, b) {
        var c = new zc(1),
            d = new zc(1),
            e = bq(kq(this.context, this.Ra, c, d, b.Ta), lo(this.context, b.Ta));
        return {
            Za: Xp(a.Pa.g(e), b.ab, 1),
            Wa: {
                Ge: c.g(Y(this.context.h, 1)),
                He: d.g(Y(this.context.h, 1))
            }
        }
    };

    function uq(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function vq() {
        var a = Error;
        return om(function(b) {
            return b instanceof a
        }, function() {
            return nm(a)
        })
    };

    function wq(a, b) {
        var c = void 0 === c ? null : c;
        var d = new M,
            e = void 0,
            f = a.Kf,
            g = d.g(P(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.i.now()
                }) : null
            }), T(function(h) {
                return null !== h
            }), P(function(h) {
                return h
            }));
        b = S([td(f, g), b]);
        var k = c;
        return b.g(T(function(h) {
            h = t(h).next().value;
            null === k && (k = h.value.Yg);
            return h.value.Yg === k
        }), If(function(h) {
            return void(e = t(h).next().value)
        }), P(function(h) {
            var l = t(h);
            h = l.next().value;
            l = l.next().value;
            try {
                var m = h.value.data,
                    r = h.timestamp,
                    q = m.viewport,
                    v, w, A = Object.assign({},
                        q, {
                            width: null != (v = null == q ? void 0 : q.width) ? v : 0,
                            height: null != (w = null == q ? void 0 : q.height) ? w : 0,
                            x: 0,
                            y: 0,
                            Xj: q ? q.width * q.height : 0
                        }),
                    D = xq(A),
                    C = m.adView,
                    R = C.measuringElement && C.containerGeometry ? xq(C.containerGeometry) : xq(C.geometry),
                    pa = xq(C.geometry),
                    ia = C.reasons.some(uq),
                    E = ia ? oi : xq(C.onScreenGeometry),
                    B;
                l && (B = C.percentageInView / 100);
                l && ia && (B = 0);
                return {
                    timestamp: r,
                    value: {
                        Y: "omid",
                        aa: R,
                        M: D,
                        X: d,
                        P: "omid",
                        G: pa,
                        ca: {
                            x: R.left,
                            y: R.top
                        },
                        S: E,
                        Zc: B
                    }
                }
            } catch (Sb) {
                w = Sb;
                m = vq();
                r = pm;
                pm = void 0;
                q = [];
                v = m(w, q);
                !v && q && (w = "Expected " +
                    m.Nf() + ", got " + mm(w), q.push(w));
                v || qm.apply(null, [void 0, r, "Guard " + m.Nf() + " failed:"].concat(u(q.reverse())));
                var U, wb;
                m = null != (wb = null == (U = Sb) ? void 0 : U.message) ? wb : "An unknown error occurred";
                U = "Error while processing geometryChange event: " + JSON.stringify(h.value) + "; " + m;
                throw Error(U);
            }
        }), wf(1), Dc())
    }

    function xq(a) {
        var b, c, d, e;
        return {
            left: Math.floor(null != (b = null == a ? void 0 : a.x) ? b : 0),
            top: Math.floor(null != (c = null == a ? void 0 : a.y) ? c : 0),
            width: Math.floor(null != (d = null == a ? void 0 : a.width) ? d : 0),
            height: Math.floor(null != (e = null == a ? void 0 : a.height) ? e : 0)
        }
    };

    function yq(a, b, c, d) {
        c = void 0 === c ? vd : c;
        var e = a.h;
        if (null === b) return wc(new Wd(20));
        if (!b.validate()) return wc(new Wd(21));
        var f;
        d = zq(e, b, d).g(P(function(g) {
            var k = g.value;
            g = g.timestamp;
            var h = b.i,
                l = a.i;
            if (h.timeline !== g.timeline) throw new ae;
            g = new le(g.value - h.now().value + l.now().value, l.timeline);
            return f = {
                value: k,
                timestamp: g
            }
        }));
        return td(d, c.g(P(function() {
            return f
        }))).g(T(function(g) {
            return void 0 !== g
        }), P(function(g) {
            return g
        }), Y(a.h, 1))
    }

    function zq(a, b, c) {
        return wq(b, c).g(Y(a, 1), P(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    ca: {
                        x: d.value.G.left,
                        y: d.value.G.top
                    },
                    aa: d.value.S,
                    M: d.value.M,
                    Y: d.value.P,
                    X: d.value.X
                }
            }
        }))
    };
    var Aq = function(a, b, c) {
        this.fb = a;
        this.N = b;
        this.Ra = c
    };
    x(Aq, Zp);
    Aq.prototype.Ya = function(a, b) {
        var c = b.Ta;
        b = yq(this.N, this.fb, this.Ra, b.hg);
        c = bq(b, lo(this.N, c));
        return {
            Za: a.Pa.g(c),
            Wa: {}
        }
    };
    var Bq = function(a, b, c) {
        this.fb = a;
        this.N = b;
        this.wh = c
    };
    x(Bq, Zp);
    Bq.prototype.Ya = function(a, b) {
        var c = yq(this.N, this.fb, void 0, b.hg);
        b = to(this.N, b.Hg, this.wh);
        c = bq(c, b);
        return {
            Za: a.Pa.g(c),
            Wa: {}
        }
    };
    var Cq = function(a) {
            return a.prerendering ? 3 : {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5
            }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
        },
        Dq = function(a) {
            var b;
            a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
            return b
        };

    function Eq(a) {
        return a.document.vi.g(P(function(b) {
            return "visible" === b
        }), V(), Y(a.h, 1))
    };
    var Fq;
    Fq = ["av.key", "js", "20231213"].slice(-1)[0].substring(0, 8);

    function Gq(a, b, c) {
        var d;
        return b.g(V(), X(function(e) {
            return c.g(P(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), W(!1), Y(a.h, 1))
    };

    function Hq(a) {
        return K(yo(P(function(b) {
            return Qo(b, a)
        })), Qn(), P(function(b) {
            return Math.round(b)
        }))
    };

    function Iq(a, b, c, d, e) {
        var f = pp;
        if (1 < f.length)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(W(void 0), X(function() {
            return c.g(eo())
        }), V(), Y(a, 1));
        e = e.g(W(void 0), X(function() {
            return c.g(Np())
        }), V(), Y(a, 1));
        return {
            uc: d.g(W(void 0), X(function() {
                return b.g(co(Op, f))
            }), V(nb), Y(a, 1)),
            Gc: d.g(W(void 0), X(function() {
                return b.g(co(Hq, f), P(function(k) {
                    return k.map(function(h, l) {
                        return 0 < l ? h - k[l - 1] : h
                    })
                }))
            }), V(nb), Y(a, 1)),
            tc: e,
            lb: g.g(V(Eo), Y(a, 1))
        }
    };

    function Jq(a, b, c) {
        var d = c.g(P(function(e) {
            return {
                value: e,
                timestamp: a.i.now()
            }
        }), V(Eo));
        return b instanceof L ? b.g(V(), X(function(e) {
            return e ? (new Z({
                value: !1,
                timestamp: a.i.now()
            })).O(a.h) : d
        })) : !1 === b.value ? d : new Z(!1)
    }

    function Kq(a, b, c, d, e, f, g) {
        var k = ip;
        b = b instanceof L ? b.g(W(!1), V()) : b;
        var h = !(yh() || zh());
        c = Jq(a, c, d);
        a = g.Pa.g(Nn(a.h));
        return Object.assign({}, k, {
            bd: c,
            Kg: e,
            pf: h,
            fg: b,
            dd: a,
            Fg: f
        })
    };

    function Lq(a) {
        a = a.global;
        if ("undefined" === typeof a.__google_lidar_) return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if ("number" === typeof b && 0 < b && (a = a.__google_lidar_radf_, "function" === typeof a)) try {
            a()
        } catch (c) {}
        return !0
    }

    function Mq(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (void 0 !== b.__google_lidar_radf_) return rc;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new M;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(Sg(a.B, 743))
    };
    var Nq = function(a) {
            var b = this;
            this.Be = !1;
            this.Le = [];
            this.Ke = [];
            a(function(c) {
                b.Be = !0;
                b.Ki = c;
                b.evaluate()
            }, function(c) {
                b.Gi = c;
                b.evaluate()
            })
        },
        Oq = function(a) {
            return new Nq(function(b, c) {
                var d = [],
                    e = 0;
                a.forEach(function(f, g) {
                    f.then(function(k) {
                        d[g] = k;
                        ++e === a.length && b(d)
                    }).catch(function(k) {
                        c(k)
                    })
                })
            })
        };
    Nq.prototype.evaluate = function() {
        var a = this.Ki,
            b = this.Gi;
        if (void 0 !== b || this.Be) this.Be && this.Le.forEach(function(c) {
            return void c(a)
        }), void 0 !== b && this.Ke.forEach(function(c) {
            return void c(b)
        }), this.Le = [], this.Ke = []
    };
    Nq.prototype.then = function(a) {
        this.Le.push(a);
        this.evaluate();
        return this
    };
    Nq.prototype.catch = function(a) {
        this.Ke.push(a);
        this.evaluate();
        return this
    };
    var Pq = function(a) {
        this.children = a;
        this.nb = !1;
        this.Vd = []
    };
    Pq.prototype.complete = function() {
        var a = this;
        this.nb = !0;
        this.Vd.forEach(function(b) {
            return void b(a)
        });
        this.Vd.splice(0)
    };
    Pq.prototype.onComplete = function(a) {
        this.nb ? a(this) : this.Vd.push(a)
    };
    Pq.prototype.jb = function(a) {
        var b = this.children.map(function(c) {
            return c.jb(a)
        });
        return void 0 === b.find(function(c) {
            return 2 !== c
        }) ? 2 : this.ga ? 0 : b.some(function(c) {
            return 1 === c
        }) ? 1 : 0
    };
    da.Object.defineProperties(Pq.prototype, {
        ga: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.nb
            }
        }
    });
    var Qq = function() {
        var a = y.apply(0, arguments);
        Pq.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                0 === --c && b.complete()
            })
        })
    };
    x(Qq, Pq);
    Qq.prototype.clone = function() {
        return new(Function.prototype.bind.apply(Qq, [null].concat(u(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    Qq.prototype.We = function(a, b) {
        var c = this;
        if (!this.ga) {
            var d = this.events.find(function(e) {
                return 1 === e.jb(a)
            });
            void 0 !== d && d.We(a, function() {
                c.ga || b()
            })
        }
    };
    var Rq = function(a, b) {
        Pq.call(this, []);
        this.fe = a;
        this.jd = Symbol(b);
        this.wi = a
    };
    x(Rq, Pq);
    Rq.prototype.clone = function() {
        var a = new Rq(this.wi, this.jd.description);
        a.jd = this.jd;
        return a
    };
    Rq.prototype.jb = function(a) {
        return a !== this.event ? 2 : this.ga || 0 === this.fe ? 0 : 1
    };
    Rq.prototype.We = function(a, b) {
        1 === this.jb(a) && (this.fe--, b(), 0 === this.fe && this.complete())
    };
    da.Object.defineProperties(Rq.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.jd
            }
        }
    });
    var Sq = function(a) {
        Rq.call(this, 1, a)
    };
    x(Sq, Rq);
    var Tq = function(a, b, c) {
        var d = y.apply(3, arguments);
        this.Db = a;
        this.th = b;
        this.ae = c;
        this.sc = new Set;
        this.Qb = d;
        if (!this.Db.N) throw Error("va");
        this.context = this.Db.N;
        var e = d.reduce(function(k, h) {
            h.subscribedEvents.forEach(function(l) {
                return void k.add(l)
            });
            return k
        }, new Set);
        e = t(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                Df: void 0
            }, f = e.next()) {
            g.Df = f.value;
            f = d.filter(function(k) {
                return function(h) {
                    return 0 <= h.controlledEvents.indexOf(k.Df)
                }
            }(g));
            if (0 === f.length) throw Error("wa");
            if (1 < f.length) throw Error("xa");
        }
    };
    Tq.prototype.start = function() {
        var a = this;
        this.Qb.forEach(function(b) {
            return void b.start(a.Db)
        });
        this.ae.start(this.Db, this.Eh.bind(this), this.Jb.bind(this), function() {})
    };
    Tq.prototype.V = function() {
        var a = this;
        this.ae.V();
        this.sc.forEach(function(b) {
            return void a.Jb(b)
        });
        this.Qb.forEach(function(b) {
            return void b.V()
        })
    };
    var Uq = function(a, b) {
        b = {
            measuringCreativeIds: [].concat(u(a.sc.values())).map(function(c) {
                return a.context.jc.Ma(c)
            }),
            hasCreativeSourceCompleted: !!a.ae.wd,
            colleagues: a.Qb.map(function(c) {
                return {
                    name: c.name,
                    controlledEvents: c.controlledEvents.map(function(d) {
                        var e;
                        return null != (e = d.description) ? e : "n/a"
                    }),
                    subscribedEvents: c.subscribedEvents.map(function(d) {
                        var e;
                        return null != (e = d.description) ? e : "n/a"
                    })
                }
            }),
            ephemeralCreativeStateChanges: b
        };
        b = {
            specMajor: 2,
            specMinor: 0,
            specPatch: 0,
            instanceId: a.context.jc.Ma(a.context.xb),
            timestamp: ne(a.context.i.now(), new le(0, a.context.i.timeline)),
            mediatorState: b
        };
        Ud(a.context, b)
    };
    Tq.prototype.Eh = function(a, b, c) {
        var d = this;
        if (!this.sc.has(a)) {
            var e = this.th.clone();
            this.sc.add(a);
            Uq(this, {});
            this.Qb.forEach(function(f) {
                f.pe(a, b, c, function(g, k, h) {
                    var l = d.context.jc.Ma(a),
                        m = ne(d.context.i.now(), new le(0, d.context.i.timeline)),
                        r, q = null != (r = g.description) ? r : "n/a";
                    if (0 > f.controlledEvents.indexOf(g) || 1 !== e.jb(g)) return h(!1), r = {}, Uq(d, (r[l] = {
                        events: [{
                            timestamp: m,
                            description: q,
                            status: 1
                        }]
                    }, r)), new Nq(function(w) {
                        return void w()
                    });
                    var v = new Nq(function(w) {
                        e.We(g, function() {
                            d.Qb.filter(function(A) {
                                return 0 <=
                                    A.subscribedEvents.indexOf(g)
                            }).forEach(function(A) {
                                return void A.handleEvent(a, g, k)
                            });
                            w()
                        })
                    });
                    return new Nq(function(w) {
                        v.then(function() {
                            h(!0);
                            var A = {};
                            Uq(d, (A[l] = {
                                events: [{
                                    timestamp: m,
                                    description: q,
                                    status: 2
                                }]
                            }, A));
                            w()
                        })
                    })
                })
            })
        }
    };
    Tq.prototype.Jb = function(a) {
        this.sc.delete(a);
        this.Qb.forEach(function(b) {
            b.Jb(a)
        });
        Uq(this, {})
    };
    var Vq = function(a) {
            this.key = a;
            this.defaultValue = !1;
            this.valueType = "boolean"
        },
        Wq = function(a) {
            this.key = a;
            this.defaultValue = 0;
            this.valueType = "number"
        };
    var Xq = new Vq("45430027"),
        Yq = new Vq("100006"),
        Zq = new Wq("45362137"),
        $q = new Vq("45377435"),
        ar = new Vq("45372163"),
        br = new Vq("45407241"),
        cr = new Vq("45382077"),
        dr = new Vq("45407239"),
        er = new Vq("45407240"),
        fr = new Vq("45430682"),
        gr = new Vq("45427308");
    var hr = new Wq("45389692");
    var Dk = function(a) {
        rm.call(this, a)
    };
    x(Dk, rm);
    Dk.prototype.je = function() {
        return Kk(this, 4, !0)
    };
    Dk.Ba = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var ir = [0, gm, -2, fm, -1];
    Dk.makeCrossSerializerComparisonsCompatible = sm(Dk, ir);
    var jr = [0, em, -3];
    var kr = [0, cm, em, -1, km, bm, cm];
    var lr = function(a) {
        rm.call(this, a)
    };
    x(lr, rm);
    lr.prototype.getType = function() {
        var a = 0;
        a = void 0 === a ? 0 : a;
        var b = tk(this, 6);
        b = null == b ? b : Number.isFinite(b) ? b | 0 : void 0;
        return Jk(b, a)
    };
    lr.Ba = "ads.geo.GeoTargetMessage";
    lr.og = [17, 18];
    var mr = [0, im, -4, km, fm, em, bm, im, bm, im, em, im, -1, jr, jm, dm, im, cm, -1, em, -1, cm, bm, kr, Zl];
    lr.makeCrossSerializerComparisonsCompatible = sm(lr, mr);
    var nr = function(a) {
        rm.call(this, a)
    };
    x(nr, rm);
    nr.prototype.je = function() {
        return Kk(this, 3, !0)
    };
    nr.Ba = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var or = [0, gm, -1, fm, mr];
    nr.makeCrossSerializerComparisonsCompatible = sm(nr, or);
    var pr = function(a) {
        rm.call(this, a)
    };
    x(pr, rm);
    pr.Ba = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var qr = [0, or, ir],
        rr = function(a, b) {
            return function(c, d) {
                a: {
                    if (hl.length) {
                        var e = hl.pop();
                        fl(e, d);
                        e.l.pc(c, void 0, void 0, d);
                        c = e
                    } else c = new gl(c, d);
                    try {
                        var f = new a,
                            g = f.u;
                        xl(b)(g, c);
                        yj && delete g[yj];
                        var k = f;
                        break a
                    } finally {
                        c.Hf()
                    }
                    k = void 0
                }
                return k
            }
        }(pr, qr);
    pr.makeCrossSerializerComparisonsCompatible = sm(pr, qr);
    var sr = function() {
            this.Gf = {}
        },
        tr = function(a, b) {
            a = a.Gf[b.key];
            if ("proto" === b.valueType) {
                try {
                    var c = JSON.parse(a);
                    if (Array.isArray(c)) return c
                } catch (d) {}
                return b.defaultValue
            }
            return typeof a === typeof b.defaultValue ? a : b.defaultValue
        };
    var ur = function() {
        this.xf = new Map
    };
    ur.prototype.start = function(a, b, c, d) {
        var e = this;
        if (void 0 === this.wd && a.N) {
            var f = a.N;
            this.wf = d;
            a = Lq(f);
            c = Mq(f);
            c = en(f, c);
            this.wd = (a ? rc : c.g(P(function(g) {
                var k = void 0 === k ? Symbol() : k;
                return Object.freeze({
                    xb: k,
                    element: (new Z(g)).O(f.h)
                })
            }), Xm())).subscribe(function(g) {
                var k = g.xb;
                e.xf.set(k, g);
                g.element.g(Te(1)).subscribe(function(h) {
                    var l = Um(h, "data-google-av-flags"),
                        m = new sr;
                    if (null !== l) try {
                        var r = JSON.parse(l)[0];
                        l = "";
                        for (var q = 0; q < r.length; q++) l += String.fromCharCode(r.charCodeAt(q) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(q %
                            10));
                        m.Gf = JSON.parse(l)
                    } catch (Ga) {}
                    var v, w, A, D, C, R, pa, ia, E, B, U, wb;
                    r = {
                        hh: null != (v = null == m ? void 0 : tr(m, Yq)) ? v : !1,
                        zh: null != (w = null == m ? void 0 : tr(m, Zq)) ? w : 0,
                        Ah: null != (A = null == m ? void 0 : tr(m, $q)) ? A : !1,
                        Ni: null != (D = null == m ? void 0 : tr(m, ar)) ? D : !1,
                        Vi: null != (C = null == m ? void 0 : tr(m, cr)) ? C : !1,
                        lh: null != (R = null == m ? void 0 : tr(m, hr)) ? R : 0,
                        ej: null != (pa = null == m ? void 0 : tr(m, dr)) ? pa : !1,
                        Gg: null != (ia = null == m ? void 0 : tr(m, er)) ? ia : !1,
                        Pi: null != (E = null == m ? void 0 : tr(m, br)) ? E : !1,
                        ek: null != (B = null == m ? void 0 : tr(m, gr)) ? B : !1,
                        Pj: null != (U =
                            null == m ? void 0 : tr(m, Xq)) ? U : !1,
                        Jg: null != (wb = null == m ? void 0 : tr(m, fr)) ? wb : !1
                    };
                    h = Um(h, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (null !== h) try {
                            var Sb = rr(h);
                            break a
                        } catch (Ga) {}
                        Sb = new pr
                    }
                    b(k, Sb, r)
                })
            });
            a && this.V()
        }
    };
    ur.prototype.V = function() {
        var a, b;
        null == (a = this.wd) || null == (b = a.unsubscribe) || b.call(a);
        this.wd = void 0;
        var c;
        null == (c = this.wf) || c.call(this);
        this.wf = void 0
    };
    var vr = function(a) {
        rm.call(this, a)
    };
    x(vr, rm);
    var wr = function(a, b) {
        return Qk(a, 1, b)
    };
    vr.Ba = "contentads.bow.rendering.client.TurtleDoveReportingData";
    vr.makeCrossSerializerComparisonsCompatible = sm(vr, [0, gm, em, gm, -5, km, gm]);

    function xr() {
        var a = Fb();
        return a ? ib("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), function(b) {
            return ub(a, b)
        }) || ub(a, "OMI/") && !ub(a, "XiaoMi/") ? !0 : ub(a, "Presto") && ub(a, "Linux") && !ub(a, "X11") && !ub(a, "Android") && !ub(a, "Mobi") : !1
    };
    var ip = Object.freeze({
            Bg: 1E3,
            he: .5,
            Ee: .3
        }),
        pp = Object.freeze([1, .75, ip.he, ip.Ee, 0]),
        sn = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=7&v=" + Fq,
        yr = function(a, b, c, d, e, f) {
            this.Di = a;
            this.Ob = b;
            this.Lb = c;
            this.fc = d;
            this.Nc = e;
            this.Oc = f;
            this.name = "rxlidar";
            this.ci = new zc;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.be = new zc;
            this.Na = new zc;
            this.controlledEvents.push(this.fc, this.Nc, this.Oc);
            this.subscribedEvents.push(this.Lb)
        };
    n = yr.prototype;
    n.start = function(a) {
        if (void 0 === this.ne && a.N) {
            var b;
            if (null != (b = this.Ob)) var c = b;
            else {
                b = a.N;
                var d = null != (c = a.fb) ? c : null;
                c = {
                    sh: .01,
                    fi: Sf(b.i, 36E5),
                    Ra: b.i.Oa(100).g(Y(b.h, 1)),
                    fb: d
                }
            }
            this.Ob = c;
            a = a.N;
            this.ne = zr(a, this.be.g(Y(a.h, 1)), this.Ob.sh, this.Ob.fi, this.Ob.Ra, this.Ob.fb, this.Na.g(W(!1), Y(a.h, 1)), this.fc, this.Nc, this.Oc).subscribe(this.ci)
        }
    };
    n.V = function() {
        this.be.complete();
        this.Na.complete();
        var a;
        null == (a = this.ne) || a.unsubscribe();
        this.ne = void 0
    };
    n.pe = function(a, b, c, d) {
        xk(b, Dk, 2) && !Fk(b, Dk, 2).je() || this.be.next(Object.assign({}, this.Di.xf.get(a), {
            metadata: b,
            experimentState: c,
            dk: a,
            Hb: d
        }))
    };
    n.Jb = function() {};
    n.handleEvent = function(a, b) {
        b === this.Lb && (this.Na.next(!0), this.Na.complete())
    };

    function zr(a, b, c, d, e, f, g, k, h, l) {
        var m = Eq(a).g(P(function(q) {
                return !q
            })),
            r = new $p(a, [new jq(a, pp), new iq(a, e), new fq(a, e), new Bq(f, a, pp), new Aq(f, a, e), new tq(a, e)]);
        return hn(a, b, function(q, v) {
            var w = Mp(q, v.element),
                A = w.Qd,
                D = w.Rc,
                C = w.Yd,
                R = w.cf,
                pa = w.mh,
                ia = w.ab,
                E = w.Vh,
                B = w.ve,
                U = w.ye,
                wb = w.Ta,
                Sb = w.Fa,
                Ga = w.jj,
                $l = w.pb;
            w = w.Ce;
            var Of, kb = null != (Of = Ok(Ek(v.metadata), 3)) ? Of : "";
            Of = wr(new vr, atob(kb)).hb();
            kb = (new Z(v.experimentState)).O(q.h);
            var he = kb.g(P(function(G) {
                    return G.Vi
                })),
                Ha = ia.g(Fe(E), P(function(G) {
                    var xb =
                        t(G);
                    G = xb.next().value;
                    xb = xb.next().value;
                    (G = G || xb) || ((G = ub(Fb(), "CrKey") || ub(Fb(), "PlayStation") || ub(Fb(), "Roku") || xr() || ub(Fb(), "Xbox")) || (G = Fb(), G = ub(G, "AppleTV") || ub(G, "Apple TV") || ub(G, "CFNetwork") || ub(G, "tvOS")), G || (G = Fb(), G = ub(G, "sdk_google_atv_x86") || ub(G, "Android TV")));
                    return G
                }));
            E = new Vp(q, v, pa, ia, wb, he);
            he = kb.g(P(function(G) {
                return G.hh
            }));
            var yc, lb = null != (yc = Nk(Ek(v.metadata))) ? yc : !1;
            yc = r.Ya(E, {
                ab: ia,
                Hg: lb,
                Ta: wb,
                hg: he
            });
            var Ia = yc.Za,
                ie = yc.Wa;
            yc = ie.Ge;
            he = ie.He;
            ie = ie.Te;
            lb = (new Z(lb)).O(q.h);
            var Wb = Kq(q, U, Ha, m, Ga, lb, E);
            Ga = vp(q.h, q.i, Ia, Wb);
            Ha = Iq(q.h, Ga.Aa.Ve, Ga.Aa.visible, Ga.Se, Ga.Dc);
            lb = Kp(q.h, q.i, Ga.Dc, Ga.Aa.X, Ga.Aa.visible);
            Ia = Zo(q.h, q.i, Ia, Wb);
            Wb = op(q.i, q.h, Ia.Aa.Ve, Ia.Aa.visible, Ia.Se, Ia.Dc);
            var Rh = {
                    bf: hp(q.h, q.i, Ia.Dc, Wb.tc)
                },
                Sh = kb.g(P(function(G) {
                    return G.Ah
                }), W(!1));
            Ia = Mn(q.h, Sh, Object.assign({}, Ia.Aa, Wb, Rh), Object.assign({}, Ga.Aa, {
                bf: Po(q, lb),
                uc: Po(q, Ha.uc),
                Gc: Po(q, Ha.Gc),
                tc: Po(q, Ha.tc),
                lb: Ha.lb.g(P(function(G) {
                    return new Oo(q.i, G)
                }))
            }));
            Ha = xo(q, d.g(lf("t")));
            lb = (null !== f && f.validate() ?
                f.Qi : vd).g(Y(q.h, 1), lf("u"));
            Ha = yd(Ha, lb);
            lb = Gq(q, Ia.X, Ha.g(T(function(G) {
                return null !== G
            })));
            Wb = Ar(q, E, A);
            Rh = Br(q, Ha, v.element);
            Sh = Wb.Zg.g(W({
                x: 0,
                y: 0
            }));
            var bs = kb.g(P(function(G) {
                    return G.Ni
                }), W(!1), V(), If(function(G) {
                    Eh = G
                }), Y(q.h, 1)),
                am = B.g(P(function(G) {
                    return 40 === G || 41 === G
                })),
                cs = kb.g(P(function(G) {
                    return G.Jg
                }), W(!1), V(), Y(q.h, 1));
            return Object.assign({}, {
                J: new Z(q.J),
                fd: new Z("lidar2"),
                Zi: new Z("lidartos"),
                eh: new Z(Fq),
                dh: new Z(7),
                Xd: new Z(q.validate() ? null : new Xd),
                ih: new Z(ki(q.document)),
                ua: new Z(un),
                Bf: Ha,
                Ag: Ha,
                Zj: lb,
                qe: g,
                ij: cs,
                Hb: new Z(v.Hb),
                fc: new Z(k),
                Nc: new Z(h),
                Oc: new Z(l),
                kh: new Z(q.Mb ? 1 : void 0),
                nh: new Z(q.fh ? 1 : void 0),
                ab: ia,
                pb: $l,
                Cd: new Z(Of),
                ub: $l.g(T(function(G) {
                    return G
                }), P(function() {
                    return q.ub.bind(q)
                })),
                Ge: yc.g(Y(q.h, 1)),
                He: he.g(Y(q.h, 1)),
                yh: kb.g(P(function(G) {
                    return G.zh
                })),
                Vf: bs,
                Ce: w,
                Th: am,
                Lh: kb.g(P(function(G) {
                    return G.lh
                })),
                Bh: new Z(new Uf(q, new Yg(q))),
                zg: new Z(Eh && (new Dh(q)).K({
                    Bb: "GET"
                })),
                Ti: new Z(Number(v.experimentState.Gg) << 0 + Number(v.experimentState.ej) <<
                    1 + Number(v.experimentState.Pi) << 2),
                jh: v.element.g(P(function(G) {
                    return null !== G
                })),
                ed: Sb,
                aj: Sb,
                Yd: C.g(W([])),
                cf: R.g(W([])),
                Ih: C.g(P(function(G) {
                    return 0 < G.length ? !0 : null
                }), W(null), V()),
                Rc: D.g(W([]), Y(q.h, 1)),
                Uj: kb,
                Qd: A,
                ic: E.ic,
                ve: B.g(W(0), Y(q.h, 1)),
                di: pa,
                Ta: wb.g(W(0), Y(q.h, 1)),
                Hc: am.g(P(function(G) {
                    return G ? Jn : tn
                })),
                ac: new Z(Kn),
                ye: U,
                Wf: E.rc.g(Nn(q.h)),
                df: E.df
            }, Ia, {
                Wc: S([Ia.Wc, Sh]).g(P(function(G) {
                    var xb = t(G);
                    G = xb.next().value;
                    xb = xb.next().value;
                    return ri(G, xb)
                }), V(pi))
            }, Wb, {
                Ic: Uh(q),
                Jh: Rh,
                Te: ie,
                Dd: Ga.Aa.Dd
            })
        }, rn(a, c))
    }

    function Ar(a, b, c) {
        var d = void 0 === d ? Ja : d;
        var e, f;
        d = (null == (e = d.performance) ? void 0 : null == (f = e.timing) ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            Xg: new Z(d),
            Wg: ao(a, b)
        }, $n(a, b, c))
    }

    function Br(a, b, c) {
        return b.g(T(function(d) {
            return null !== d
        }), X(function() {
            return c
        }), P(function(d) {
            var e = Ym(a);
            return 0 < e.length && 0 <= e.indexOf(d)
        }), P(function(d) {
            return !d
        }))
    };
    var Cr = function(a) {
        var b = void 0 === b ? [] : b;
        var c = void 0 === c ? [a] : c;
        this.Lb = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.se = new Map
    };
    n = Cr.prototype;
    n.start = function(a) {
        this.Db = a
    };
    n.V = function() {
        this.se.clear()
    };
    n.pe = function(a, b, c, d) {
        if (b = this.Db) c = new Dr(b, c, this.Lb, d), this.se.set(a, c)
    };
    n.Jb = function(a) {
        this.se.delete(a)
    };
    n.handleEvent = function() {};
    var Dr = function(a, b, c, d) {
        var e = this;
        this.context = a;
        this.Lb = c;
        this.Eg = function() {};
        this.Uf = [];
        this.Sf = "&avradf=1";
        this.Tf = Oq([]);
        this.Na = new zc;
        c = a.fb;
        var f = null !== c && (null == c ? void 0 : c.validate()),
            g, k = null == (g = a.N) ? void 0 : g.h;
        this.Na.g(W(!b.Jg), Y(k, 1));
        this.Ui = f ? null == c ? void 0 : c.Rf.g(Te(1), lf(!0), W(!1)) : (new Z(!0)).O(k);
        this.Eg = function(h, l) {
            e.Na.next(!0);
            e.Na.complete();
            S([e.Na, e.Ui]).subscribe(function(m) {
                var r = t(m);
                m = r.next().value;
                r = r.next().value;
                if (!r) return vd;
                m && r && d(e.Lb, h, l);
                return !0
            })
        };
        this.pc(a.N)
    };
    Dr.prototype.pc = function(a) {
        var b = this;
        this.xc = a.global.document;
        this.Uf.push(Er(this));
        var c = {};
        this.Tf = Oq(this.Uf);
        this.Tf.then(function() {
            b.Sf = "&vis=" + Cq(b.xc) + "&uach=0&ms=0";
            c.paramString = b.Sf;
            c.view_type = "DELAYED_IMPRESSION";
            b.Eg(c, function() {})
        })
    };
    var Er = function(a) {
        return new Nq(function(b) {
            var c = Dq(a.xc);
            if (c)
                if (3 === Cq(a.xc)) {
                    var d = function() {
                        var e = a.xc;
                        e.removeEventListener && e.removeEventListener(c, d, !1);
                        b(!0)
                    };
                    $g(a.xc, c, d)
                } else b(!0)
        })
    };

    function Fr(a) {
        var b = Vh(a);
        return b ? b.g(P(function(c) {
            var d;
            c = null == (d = Ik(c).find(function(g) {
                return "Google Chrome" === Ok(g, 1)
            })) ? void 0 : Ok(d, 2);
            if (!c) return !1;
            var e = t(c.split(".").map(function(g) {
                return Number(g)
            }));
            d = e.next().value;
            c = e.next().value;
            var f = e.next().value;
            e = e.next().value;
            return void 0 === d || void 0 === c || void 0 === f || void 0 === e ? !1 : 117 === d && 5938 === f && 149 <= e || 118 === d && 5993 === f && 32 <= e || 119 === d && 6034 <= f || 120 <= d ? !0 : !1
        })) : Kh.O(a.h)
    };
    var Gr = function(a) {
        var b = void 0 === b ? [] : b;
        var c = void 0 === c ? [a] : c;
        this.Ei = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.yc = new Map
    };
    n = Gr.prototype;
    n.start = function(a) {
        this.context = a.N
    };
    n.V = function() {
        this.yc.forEach(function(a) {
            return void a.V()
        });
        this.yc.clear()
    };
    n.pe = function(a, b, c, d) {
        var e = this;
        if (!xk(b, nr, 1) || Fk(b, nr, 1).je()) {
            var f = this.context;
            f && c.Gg && f.sharedStorage && Fr(f).g(Te(1)).subscribe(function(g) {
                g && (g = new Hr(f, b, e.Ei, c, d), e.yc.set(a, g))
            })
        }
    };
    n.Jb = function(a) {
        var b;
        null == (b = this.yc.get(a)) || b.V();
        this.yc.delete(a)
    };
    n.handleEvent = function() {};
    var Hr = function(a, b, c, d, e) {
            var f = this;
            this.context = a;
            this.metadata = b;
            this.experimentState = d;
            e(c, {}, function(g) {
                g && (Ir(f, 2), Ir(f, 1))
            })
        },
        Ir = function(a, b) {
            var c, d, e, f, g, k, h, l, m;
            Ba(function(r) {
                h = {
                    canaryMode: b,
                    experimentState: a.experimentState,
                    escapedQueryId: null != (g = null == (c = Fk(a.metadata, nr, 1)) ? void 0 : Mk(c)) ? g : "",
                    clientsideModelFilename: null == (d = Fk(a.metadata, nr, 1)) ? void 0 : Ok(d, 1),
                    geoTargetMessage: null != (k = null == (e = Fk(a.metadata, nr, 1)) ? void 0 : null == (f = Fk(e, lr, 4)) ? void 0 : f.hb()) ? k : void 0
                };
                l = btoa(JSON.stringify(h));
                m = a.context.wg[0];
                return ta(r, ni(a.context.document, m, l), 0)
            })
        };
    Hr.prototype.V = function() {};

    function Jr(a, b) {
        if (!b) throw Error("ya`" + a);
        if ("string" !== typeof b && !(b instanceof String)) throw Error("za`" + a);
        if ("" === b.trim()) throw Error("Aa`" + a);
    }

    function Kr(a) {
        if (!a) throw Error("Da`functionToExecute");
    }

    function Lr(a, b) {
        if (null == b) throw Error("Ba`" + a);
        if ("number" !== typeof b || isNaN(b)) throw Error("Ca`" + a);
        if (0 > b) throw Error("Ea`" + a);
    };

    function Mr() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.4.8-google_20230803")
    }

    function Nr() {
        for (var a = ["1", "4", "8"], b = ["1", "0", "3"], c = 0; 3 > c; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var Or = function(a, b, c, d) {
            this.Of = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Pr = function(a) {
            return !!a && void 0 !== a.omid_message_guid && void 0 !== a.omid_message_method && void 0 !== a.omid_message_version && "string" === typeof a.omid_message_guid && "string" === typeof a.omid_message_method && "string" === typeof a.omid_message_version && (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
        },
        Qr = function(a) {
            return new Or(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    Or.prototype.hb = function() {
        var a = {};
        a = (a.omid_message_guid = this.Of, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        void 0 !== this.args && (a.omid_message_args = this.args);
        return a
    };
    var Rr = function(a) {
        this.Bd = a
    };
    Rr.prototype.hb = function() {
        return JSON.stringify(void 0)
    };
    var Sr = function(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
            try {
                var c = a.frames && !!a.frames[b]
            } catch (d) {
                c = !1
            }
            return c
        })
    };

    function Tr(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function Ur() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = 16 * Math.random() | 0;
            return "y" === a ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function Vr() {
        var a = y.apply(0, arguments);
        Wr(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(u(a))));
        }, function() {
            return console.error.apply(console, u(a))
        })
    }

    function Wr(a, b) {
        "undefined" !== typeof jasmine && jasmine ? a() : "undefined" !== typeof console && console && console.error && b()
    };
    var Xr = function() {
        if ("undefined" !== typeof omidGlobal && omidGlobal) return omidGlobal;
        if ("undefined" !== typeof global && global) return global;
        if ("undefined" !== typeof window && window) return window;
        if ("undefined" !== typeof globalThis && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Fa");
    }();
    var Yr = function(a) {
        this.Bd = a;
        this.handleExportedMessage = Yr.prototype.Fh.bind(this)
    };
    x(Yr, Rr);
    Yr.prototype.sendMessage = function(a, b) {
        b = void 0 === b ? this.Bd : b;
        if (!b) throw Error("Ga");
        b.handleExportedMessage(a.hb(), this)
    };
    Yr.prototype.Fh = function(a, b) {
        if (Pr(a) && this.onMessage) this.onMessage(Qr(a), b)
    };

    function Zr(a) {
        return null != a && "undefined" !== typeof a.top && null != a.top
    }

    function $r(a) {
        if (a === Xr) return !1;
        try {
            if ("undefined" === typeof a.location.hostname) return !0
        } catch (b) {
            return !0
        }
        return !1
    };
    var as = function(a, b) {
        this.Bd = b = void 0 === b ? Xr : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if ("object" === typeof d.data) {
                var e = d.data;
                if (Pr(e) && d.source && c.onMessage) c.onMessage(Qr(e), d.source)
            }
        })
    };
    x(as, Rr);
    as.prototype.sendMessage = function(a, b) {
        b = void 0 === b ? this.Bd : b;
        if (!b) throw Error("Ga");
        b.postMessage(a.hb(), "*")
    };
    var ds = ["omid", "v1_VerificationServiceCommunication"],
        es = ["omidVerificationProperties", "serviceWindow"];

    function fs(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var gs = function(a) {
        if (!a) {
            var b;
            "undefined" === typeof b && "undefined" !== typeof window && window && (b = window);
            b = Zr(b) ? b : Xr;
            var c = void 0 === c ? Sr : c;
            a = [];
            var d = fs(b, es);
            d && a.push(d);
            a.push(Zr(b) ? b.top : Xr);
            a: {
                a = t(a);
                for (var e = a.next(); !e.done; e = a.next()) {
                    b: {
                        d = b;e = e.value;
                        var f = c;
                        if (!$r(e)) try {
                            var g = fs(e, ds);
                            if (g) {
                                var k = new Yr(g);
                                break b
                            }
                        } catch (h) {}
                        k = f(e) ? new as(d, e) : null
                    }
                    if (d = k) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.hc = a) this.hc.onMessage = this.Gh.bind(this);
        else if (c = (c = Xr.omid3p) && "function" === typeof c.registerSessionObserver &&
            "function" === typeof c.addEventListener ? c : null) this.wc = c;
        this.Hi = this.Ii = 0;
        this.Td = {};
        this.re = [];
        this.gd = (c = Xr.omidVerificationProperties) ? c.injectionId : void 0
    };
    gs.prototype.K = function() {
        return !(!this.hc && !this.wc)
    };
    var ze = function(a, b, c) {
        Kr(b);
        a.wc ? a.wc.registerSessionObserver(b, c, a.gd) : a.Xb("addSessionListener", b, c, a.gd)
    };
    gs.prototype.addEventListener = function(a, b) {
        Jr("eventType", a);
        Kr(b);
        this.wc ? this.wc.addEventListener(a, b, this.gd) : this.Xb("addEventListener", b, a, this.gd)
    };
    var Rf = function(a, b, c, d) {
            Jr("url", b);
            Xr.document && Xr.document.createElement ? hs(a, b, c, d) : a.Xb("sendUrl", function(e) {
                e && c ? c() : !e && d && d()
            }, b)
        },
        hs = function(a, b, c, d) {
            var e = Xr.document.createElement("img");
            a.re.push(e);
            var f = function(g) {
                var k = a.re.indexOf(e);
                0 <= k && a.re.splice(k, 1);
                g && g()
            };
            e.addEventListener("load", f.bind(a, c));
            e.addEventListener("error", f.bind(a, d));
            e.src = b
        };
    gs.prototype.setTimeout = function(a, b) {
        Kr(a);
        Lr("timeInMillis", b);
        if (is()) return Xr.setTimeout(a, b);
        var c = this.Ii++;
        this.Xb("setTimeout", a, c, b);
        return c
    };
    gs.prototype.clearTimeout = function(a) {
        Lr("timeoutId", a);
        is() ? Xr.clearTimeout(a) : this.rg("clearTimeout", a)
    };
    gs.prototype.setInterval = function(a, b) {
        Kr(a);
        Lr("timeInMillis", b);
        if (js()) return Xr.setInterval(a, b);
        var c = this.Hi++;
        this.Xb("setInterval", a, c, b);
        return c
    };
    gs.prototype.clearInterval = function(a) {
        Lr("intervalId", a);
        js() ? Xr.clearInterval(a) : this.rg("clearInterval", a)
    };
    var is = function() {
            return "function" === typeof Xr.setTimeout && "function" === typeof Xr.clearTimeout
        },
        js = function() {
            return "function" === typeof Xr.setInterval && "function" === typeof Xr.clearInterval
        };
    gs.prototype.Gh = function(a) {
        var b = a.method,
            c = a.Of;
        a = a.args;
        if ("response" === b && this.Td[c]) {
            var d = Mr() && Nr() ? a ? a : [] : a && "string" === typeof a ? JSON.parse(a) : [];
            this.Td[c].apply(this, d)
        }
        "error" === b && window.console && Vr(a)
    };
    gs.prototype.rg = function(a) {
        this.Xb.apply(this, [a, null].concat(u(y.apply(1, arguments))))
    };
    gs.prototype.Xb = function(a, b) {
        var c = y.apply(2, arguments);
        if (this.hc) {
            var d = Ur();
            b && (this.Td[d] = b);
            var e = "VerificationService." + a;
            c = Mr() && Nr() ? c : JSON.stringify(c);
            this.hc.sendMessage(new Or(d, e, "1.4.8-google_20230803", c))
        }
    };
    var ks = void 0;
    if (ks = void 0 === ks ? "undefined" === typeof omidExports ? null : omidExports : ks) {
        var ls = ["OmidVerificationClient"];
        ls.slice(0, ls.length - 1).reduce(Tr, ks)[ls[ls.length - 1]] = gs
    };
    var ms = Og(null !== "av.key_js_20231213_RC00".match(/^m\d{10}$/g) ? "av.key_js_20231213_RC00" : "current"),
        ns;
    a: {
        try {
            var os = new gs;
            ns = new Qg(os, "doubleclickbygoogle.com-omid", void 0, ms);
            break a
        } catch (a) {}
        ns = void 0
    }
    var xe = ns;
    (function(a, b) {
        var c = new Sq("impression"),
            d = new Sq("begin to render"),
            e = new Sq("unmeasurable"),
            f = new Sq("viewable"),
            g = new Sq("reach vpid"),
            k = new Qq(c, g, d, f, e),
            h = new ur,
            l = new Cr(c.event);
        b = new yr(h, b, c.event, d.event, e.event, f.event);
        g = new Gr(g.event);
        var m = new Tq(a, k, h, l, b, g);
        m.start();
        return {
            V: function() {
                return void m.V()
            },
            colleagues: {
                Rj: l,
                bk: b,
                Yj: g
            }
        }
    })({
        N: new Km(void 0, void 0, void 0, ms),
        fb: xe
    });
    xe && null !== xe.gb && Ce();
}).call(this);